# -*- coding: utf-8 -*-
"""Builds report.html for ALADIN Driver v4.0 / DRV-01 from DRV01_RESULTS.json (every number in the tables comes from the JSON)."""
import json, html
R = json.load(open("/home/claude/drv/tests/DRV01_RESULTS.json"))
C = {t["id"]: t for t in R["legs"]["cpu"]}; G1 = {t["id"]: t for t in R["legs"]["gpu_run1"]}; G = {t["id"]: t for t in R["legs"]["gpu_run2"]}
A = R["addendum_A1"]; F = R["final"]; ENV = R["env"]
css = open("/home/claude/gyropdf/report.html").read().split("<style>")[1].split("</style>")[0]
e = html.escape
def f(x, d=2):
    if x == 0: return "0"
    return f"{x:.{d}e}".replace("e-0", "e-").replace("e+0", "e+").replace("e+", "e")
def pill(v):
    k = "" if v == "PASS" else "red"; return f'<span class="pill {k}">{e(v.replace("NOT QUALIFIED (CRASHED)", "CRASHED"))}</span>'
def ck(t):
    if t is None: return "—"
    out = []
    for k, c in t["checks"].items():
        v = c["value"]; vs = f(v, 3) if isinstance(v, (int, float)) else e(str(v))
        mark = "" if c["result"] == "PASS" else " ✗"
        out.append(f"{e(k)}: <b>{vs}</b> {e(c['op'])} {f(c['threshold'], 0) if isinstance(c['threshold'], (int, float)) else c['threshold']}{mark}")
    return "<br>".join(out)
TITLES = dict(
    D01=("README pinch stays exactly static", "well-balanced Driver, 16×8×4, 2000 CFL steps (t = 3.8), outer boundary fixed and conducting wall"),
    D02=("Conservation in a closed pinch", "README pinch + sausage eigenmode (ε = 1e-3), 32×4×16, conducting wall, periodic z, 1000 steps"),
    D03=("Resistive decay rate", "transverse field ε sin kz, η = 0.05, k = 2π: exact rate η k²; nz 16/32/64 at a 4×8 cross-section"),
    D04=("Hall-MHD circularly polarised wave", "exact ω² + Hω = v<sub>A</sub>²k², both roots, Hall 0.1; nz 16/32/64 at 4×8"),
    D05=("Sod shock tube along z", "γ = 1.4, t = 0.2, against the exact Riemann solution; nz 100/200/400; must stay 1-D across r and φ"),
    D06=("Ideal circularly polarised Alfvén wave", "exact ω = v<sub>A</sub>k; nz 16/32/64 at 4×8"),
    D07=("Sausage instability of the README pinch", "growth rate vs an independent linear eigen-solver (oracle, γ = 0.28248, m = 0, k = 4π, wall at r = 1); 32×16, 64×32, 128×64"),
    D08=("Bit-identical restart", "checkpoint at half time, NEW Driver, continue: equals the uninterrupted run bit for bit, incl. t; ideal pinch and resistive + Hall tube"),
    D09=("Failure rules", "negative density → FAILED at step 0; blast → local recovery; NaN injected → FAILED; recovery off → explicit STOP"),
    D10=("Every kernel slot matters (ablation)", "switch one slot off at a time: the error of a physics test must grow ≥ 10×; well-balancing off must break D01"),
    D11=("GPU = CPU", "every final state of every DRV-01 run, GPU leg vs CPU leg, FP64: 112 arrays"),
    D12=("Memory manager", "GPU pool peak ≤ estimate at 32³, 64³, 128³ and the held-out 96³; throughput"),
    D13=("Energy of the non-ideal terms", "off-axis flux tube; resistive heating = η J², Hall heating = 0 (Hall does no work), 32², 64², 128²"),
)
rows = []
for i in ["D01", "D02", "D05", "D07", "D08", "D09", "D10", "D11", "D12", "D03", "D04", "D06", "D13"]:
    ti, cond = TITLES[i]
    rows.append(f"<tr><td>{i}</td><td><b>{ti}</b><br><span class='note'>{cond}</span></td><td class='mono'>{ck(C.get(i)) if i not in ('D11',) else '— (needs both legs)'}</td>"
                f"<td class='mono'>{ck(G[i])}</td><td>{pill(F[i])}</td></tr>")
TABLE = "\n".join(rows)
hist = "".join(f"<tr><td>{i}</td><td>{pill(C[i]['verdict']) if i in C else '—'}</td><td>{pill(G1[i]['verdict'])}</td><td>{pill(G[i]['verdict'])}</td></tr>"
               for i in ["D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10", "D11", "D12", "D13"])
def a1row(name, key, pre_list):
    d = A[key]; rr = "".join(f"{e(k.split(' ', 1)[1])}: {f(v['rel_err'])} · " for k, v in d["rows"].items() if "(" in k)
    return f"<tr><td>{name}</td><td class='mono'>{rr[:-3]}</td><td class='mono'><b>{f(d['err'])}</b>, order <b>{d['order']:.2f}</b></td><td>{pill(d['result'])}</td></tr>"
A1T = a1row("D03 resistive decay (CPU)", "D03_cpu", None) + a1row("D04 Hall wave, both branches (GPU, L4)", "D04_gpu", None) + a1row("D06 Alfvén wave (CPU)", "D06_cpu", None)
d12 = G["D12"]["data"]["rows"]; d12r = "".join(f"<tr><td>{k}{' (held out)' if k.startswith('96') else ''}</td><td>{v['memory_measured_MiB']:.0f}</td><td>{v['memory_estimate_MiB']:.0f}</td>"
                                            f"<td>{v['memory_measured_MiB']/v['memory_estimate_MiB']:.2f}</td><td>{v['seconds_per_step']:.3f}</td><td>{v['cell_updates_per_s']/1e6:.2f}</td></tr>" for k, v in d12.items())
d13 = G["D13"]["data"]["res"]
d10 = G["D10"]["data"]["rows"]; d10r = "".join(f"<tr><td>{e(k)}</td><td>{e(v['test'])}</td><td>{f(v['error_normal'])}</td><td>{f(v['error_ablated'])}</td><td><b>{v['factor']:.1f}×</b></td></tr>" if "factor" in v else
                                                f"<tr><td>{e(k)}</td><td>{e(v['test'])}</td><td>{f(v['error_normal'])}</td><td>{f(v['error_ablated'])}</td><td>no longer static</td></tr>" for k, v in d10.items())
files = R["files"]; filerows = "".join(f"<tr><td class='mono'>{e(k)}</td><td class='hash'>{v}</td></tr>" for k, v in files.items() if not k.startswith("kernels/") or True)
kern = R["kernels"]; kernrows = "".join(f"<tr><td>{e(k)}</td><td class='mono'>{e(v['record'])}</td></tr>" for k, v in kern.items())
eg, ec, e1 = ENV["gpu_run2"], ENV["cpu"], ENV["gpu_run1"]
d07 = C["D07"]["data"]["runs"]
body = f"""
<section class="cover">
  <div class="kicker">ALADIN Plasma Cosmology · the Driver · campaign DRV-01</div>
  <h1>ALADIN Driver v4.0</h1>
  <div class="subtitle">The native-cylindrical GPU / CPU MHD Driver for Z-pinch and J × B research, built on eleven certified kernels: thirteen predeclared tests against references independent of the Driver, the same bits on GPU and CPU</div>
  <div class="rule"></div>
  <div class="meta">
    <b>Author:</b> Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X<br>
    <b>Release:</b> ALADIN Driver v4.0 ({e(R['driver'])}) · certification campaign DRV-01 · 20–22 November 2026<br>
    <b>Driver file SHA-256:</b> <span class="hash">{files['aladin_driver_v40.py']}</span><br>
    <b>Thresholds SHA-256</b> (identical in all three legs): <span class="hash">{R['thresholds_sha256']}</span><br>
    <b>Legs:</b> CPU (x86-64, g++ 13.3, NumPy {ec['numpy']}) · GPU run 1 ({e(e1['gpu'])}) · GPU run 2 ({e(eg['gpu'])}, CuPy {eg['cupy']}, NumPy {eg['numpy']}); FP64; one source per kernel for both backends
  </div>
  <div class="hero">
    <div class="lbl">GPU = CPU, bit for bit, across the whole campaign</div>
    <div class="eq">D11: 0 values differing in 112 final-state arrays (FP64) &nbsp;·&nbsp; README pinch static: max |ΔU| = max |ΔB| = 0</div>
    <div class="cap">The saved final state of every DRV-01 test, from the static pinch to the Hall wave and the sausage instability, is exactly the same on an NVIDIA GPU and on an x86 CPU. The README Z-pinch (B<sub>φ</sub> = r/2, J<sub>z</sub> = 1, P = P<sub>0</sub> − r²/4, μ<sub>0</sub> = 1) stays exactly static for 2000 steps, with fixed outer boundary and with a conducting wall, on both.</div>
  </div>
  <div class="cards">
    <div class="card"><div class="big">{R['counts'].get('PASS', 0)} / 13</div><div class="t">DRV-01 tests PASS against thresholds frozen before the runs; the 4 FAILs are kept as FAIL and explained (Section 6)</div></div>
    <div class="card"><div class="big">0.83 %</div><div class="t">sausage growth rate of the README pinch vs an independent eigen-solver, converging at order 2.65 (D07)</div></div>
    <div class="card"><div class="big">16.7×</div><div class="t">the weakest ablation factor: every one of the six kernel slots is needed for the physics (D10)</div></div>
    <div class="card"><div class="big">4.8 M</div><div class="t">cell-updates per second at 128³ on a Tesla T4 (7.5 M on an L4); GPU memory inside the recalibrated estimate at every size, 96³ held out (D12)</div></div>
  </div>
  <div class="cover-foot">Every number is generated from DRV01_RESULTS.json, built from the raw outputs of the three legs; every test left a checksummed bundle.</div>
</section>

<h2 class="pb">1. What the Driver is</h2>
<ul>
<li><b>A conductor and its managers.</b> aladin_driver_v40.py reads one Config, asks the build manager for the certified kernels and wires twelve managers: config, build (registry, hash check, precision policy, GPU IEEE self-test), grid, memory, boundary, pipeline, timestep, integrator, diagnostics, checkpoint, initial conditions and the MakeReport bundle manager.</li>
<li><b>One right-hand side, in the certified order.</b> fill → PRIM (01) → HLLD-R / HLLD-φ / HLLD-Z (04–06, one kernel in three slots) → RESIDUAL (07) → UCT-CURL (09, when η or Hall ≠ 0) → UCT-EMF (08) → update, constrained transport and axis closure (11). SSP-RK3 in time.</li>
<li><b>Native cylindrical, axis included.</b> Axis reflection, staggered φ seams, z periodic or outflow, outer r fixed, outflow or conducting wall. Well-balanced for a static equilibrium: HLLD sees the equilibrium state and faces, RESIDUAL its residual, and the induction step its ideal edge EMF; resistive and Hall EMFs are never subtracted, because their action on the equilibrium is physics. Resistive and Hall energy enter through the non-ideal Poynting flux ∇·(E<sub>ni</sub> × B).</li>
<li><b>Admissible by design.</b> Every kernel is hash-checked against its Zenodo record before a run, and a mismatch refuses to start; the grid must fit in memory; every stage is checked; a step is transactional, recovery is local (first-order faces), then dt halving, then an explicit STOP, never a silent continue. Restart is bit-identical.</li>
<li><b>Two backends, one code.</b> backend = "cpu" (NumPy + the kernels' g++ builds, -ffp-contract=off) or "cupy" (NVRTC, -fmad=false -ftz=false, IEEE division and square root). FP64 by default.</li>
</ul>
<table><tr><th>Slot</th><th>Certified kernel (Zenodo record)</th></tr>{kernrows}</table>

<h2 class="pb">2. The README benchmark, through the Driver</h2>
<p>Normalised Z-pinch, μ<sub>0</sub> = 1: B<sub>φ</sub> = r/2, J<sub>z</sub> = 1, f<sub>r</sub> = −r/2, ∇·B = 0, P = P<sub>0</sub> − r²/4, built by the Driver's initial-conditions manager and evaluated with the Driver's own kernels, then advanced 100 CFL steps by the well-balanced Driver:</p>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:7.6pt;text-align:left;white-space:pre-wrap">{e(R['readme_benchmark'])}</div>
<p>The stencils reproduce this field exactly, so what is left in J<sub>z</sub> and f<sub>r</sub> is floating-point rounding (2 ε at 16×8×4); the pressure is exact to 1 ulp, the divergence is 0 and the Driver holds the equilibrium to the last bit. D01 repeats the static test for 2000 steps with both outer boundaries, on GPU and CPU.</p>

<h2>3. How DRV-01 was run</h2>
<ul>
<li><b>Independent references only.</b> Exact solutions (resistive decay, the Hall and Alfvén circularly polarised waves, the Sod Riemann problem), conservation laws, an independent 1-D linear eigen-solver for the sausage instability (oracle_linear_pinch.py: staggered finite differences, written without any Driver or kernel code, validated on sound waves to 1e-6), and bit-level identities (restart, GPU = CPU).</li>
<li><b>Thresholds frozen first.</b> Every threshold was declared on 21 November 2026 before the test was run; drv01.py was hashed before the CPU leg; the threshold set is byte-identical in all three legs (SHA-256 above). Each test ran inside the MakeReport bundle manager and left a checksummed bundle (status, thresholds, results, log, report).</li>
<li><b>Disclosed previews:</b> D07 at 16×8, 32×16, 64×32 before the freeze (which is why its rule sits at an untested 128×64, with convergence), and D13 on a different field (the frozen D13 uses an off-axis tube never run before the freeze).</li>
<li><b>Changes after the quick plumbing run, before any full run</b> (thresholds unchanged): (1) Driver: with a conducting wall the well-balancing equilibrium gets the same mirrored ghosts as the state (the quick D02 leaked mass at 1.3e-6; now exactly conserved); (2) D03 design: η 0.01 → 0.05 and p<sub>0</sub> 100 → 1, because the quick run showed the decay set by numerical dissipation, not by η.</li>
<li><b>Changes after GPU run 1, before GPU run 2</b> (thresholds unchanged): (a) four measurement helpers called PRIM without backend= and crashed on GPU arrays (D07, D09, D10, D13 not qualified in run 1); (b) D12 freed CuPy's shared pool before each size; (c) memory estimate recalibrated from run 1 (120 → 180 arrays per step) with 96³ added as a held-out size; (d) frozen eigenmodes and (e) the timestep fix, Section 5.</li>
</ul>
<table><tr><th>Test</th><th>CPU leg</th><th>GPU run 1 ({e(e1['gpu'])})</th><th>GPU run 2 ({e(eg['gpu'])})</th></tr>{hist}</table>

<h2 class="pb">4. Results</h2>
<table class="camp"><tr><th>ID</th><th>Test and conditions</th><th>CPU leg</th><th>GPU leg (run 2)</th><th>Final</th></tr>
{TABLE}
</table>
<p class="note">The CPU leg ran the run-1 code; the only Driver change since is the timestep line of Section 5, which leaves every CPU result bit-identical (per-step hashes unchanged; and D11 = 0 compares run-2 GPU states with the CPU leg's). Measured quantities computed from the identical states agree between legs to ≤ 1e-12 relative (the measurement's own sums run in a different order on CuPy); D02's energy change, 0 on the CPU and 2.1e-16 on the GPU, is that reduction order, 10 000 × below its threshold.</p>

<figure><img src="drv01_fig.png"><figcaption>Figure 1. (a) D07: the Driver's sausage growth rate against the independent oracle. (b) The frozen wave and decay tests refine z only at a 4×8 cross-section (dashed, FAIL); refining r, φ and z together (addendum A1, declared after the CPU leg) converges. (c) D13: heating by the non-ideal terms, with and without the Poynting energy flux. (d) D12: GPU memory against the estimate, and throughput, FP64.</figcaption></figure>

<h2 class="pb">5. GPU = CPU, and how it was earned</h2>
<ul>
<li><b>GPU run 1 (NVIDIA L4): D11 FAIL.</b> 103 471 values differed, at ≤ 6.4e-14, in three runs: D02, D08-pinch and D04. Everything else, including every ideal run, matched bit for bit.</li>
<li><b>KW-01</b> fed every kernel identical inputs on both backends along the D02 and D04 trajectories for 40 steps: every kernel identical, the two Drivers in lockstep. The kernels were cleared.</li>
<li><b>Cause 1, between machines (test setup).</b> D02, D07, D08 and D09 start from the oracle's eigenmode, computed with LAPACK. LAPACK's eigenvectors differ in the last bits between NumPy builds (σ = 0.282449097916112<b>45</b> on Colab, …111<b>17</b> on the CPU-leg machine); cos and sin matched. So the two legs started from different states. Fix (d): the modes are computed once on the CPU-leg machine and frozen in drv01_frozen_modes.npz. KW-02: D02 from the frozen mode is identical CPU-leg vs Colab CPU vs Colab GPU at every one of 1000 steps.</li>
<li><b>Cause 2, GPU vs CPU (one line of Driver code).</b> KW-02 replayed D04 (2365 steps) on one machine: GPU and CPU split at step 924, by 1e-18 in m<sub>r</sub>, m<sub>φ</sub>, B<sub>r</sub>, B<sub>φ</sub>, while Colab's CPU matched the CPU leg at every step. The timestep manager computed b² = Σ x ** 2: NumPy evaluates x ** 2 as x · x, CuPy calls CUDA pow(x, 2.0). KW-03: the two differed in 358 of 2365 states; the Hall limit uses √b² at its maximum directly, so at step 924 one ulp moved dt. Fix (e): Σ x · x. With it: D04 GPU = CPU at every step, and every CPU result unchanged.</li>
<li><b>GPU run 2 (Tesla T4): D11 PASS, 0 values differing</b> in 112 arrays, every run of the campaign. The same bits now hold on a second GPU model.</li>
</ul>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:7.2pt;text-align:left;white-space:pre-wrap">{e(chr(10).join(R['probes']['KW02'] + R['probes']['KW03']))}</div>
<p class="note">Probe lines quoted verbatim from the GPU machine's console. The run-1 D11 FAIL stays in the record.</p>

<h2 class="pb">6. The four FAILs: what they measure</h2>
<ul>
<li><b>D03, D04, D06: z-refinement at a fixed 4×8 cross-section.</b> These tests refine z only and keep 45° cells across the axis. The transverse field crosses the axis, and its discrete curl carries an error set by the cross-section, which z-refinement cannot remove. D06's error is 0.72 % (inside 1 %) but does not converge; D04 reaches 2.4 %; D03 1.02 %. Same numbers on GPU and CPU.</li>
<li><b>Addendum A1 (declared after the CPU leg; D03, D04, D06 stay FAIL).</b> Refining r, φ and z together with the original thresholds:
<table><tr><th>Test</th><th>levels (4,8,16) · (8,16,32) · (16,32,64)</th><th>finest, order</th><th>A1</th></tr>{A1T}</table>
D04 converges at second order (both branches, 0.32 % and 0.19 %). D06 falls 15× to 3.4e-4 but its last step flattens (order 0.85). D03 lands at 0.64 %: inside 1 %, order 1.40. Post-hoc diagnosis of D03: two errors of opposite sign, the scheme's own numerical decay (falling from 27 % to 3.3 % of η k² across the levels) and the resistive part (12.9 % → 3.3 %), so their sum is not monotone; near the inner annulus the resistive decay is slower than exact (19.7 % → 10.5 %), first order there. Open.</li>
<li><b>D13: the energy of the non-ideal terms.</b> Without the non-ideal Poynting flux the resistive heating was off by 12.6–16 × η J² and the Hall heating by 99 %: the Driver lost that energy. With it, resistive heating converges at order {G['D13']['checks']['res_order']['value']:.2f} to {100*d13['resistive']['128']['rel_err']:.1f} % at 128² (threshold 1 %: FAIL, order PASS); Hall heating, exactly zero in nature, falls to {100*d13['hall']['128']['rel']:.1f} % of the Hall energy flux at 128² (threshold 5 %) at order {G['D13']['checks']['hall_order']['value']:.2f} (threshold 0.9). The energy is now accounted for and converges; the rate falls short of what was declared.</li>
</ul>

<h2 class="pb">7. Ablation, memory and speed</h2>
<table><tr><th>Slot switched off</th><th>measured by</th><th>error, normal</th><th>error, ablated</th><th>factor</th></tr>{d10r}</table>
<p class="note">D10, GPU run 2. Every kernel slot carries physics the tests can see; well-balancing off breaks the exact static pinch at 2.0e-4.</p>
<table><tr><th>D12 grid ({e(eg['gpu'])}, FP64)</th><th>measured MiB</th><th>estimate MiB</th><th>ratio</th><th>s / step</th><th>M cell-updates / s</th></tr>{d12r}</table>
<p class="note">The estimate (180 arrays per step) was recalibrated from run 1's L4 measurement; 96³ was never measured before it and holds (0.83). Small grids are launch-bound: below about 10⁵ cells the GPU is slower than the CPU (D04: 416 s vs 139 s), from about 10⁶ cells it is the faster backend (D07 at 128×64: 792 s vs 2617 s).</p>

<h2>8. Limitations and open regimes</h2>
<ul>
<li><b>Accuracy (Section 6):</b> transverse fields across the axis need the cross-section refined with z; resistive decay near the inner annulus is first order; the Alfvén error flattens near 3.4e-4 at 16×32×64; Hall heating converges at order 0.82; resistive heating at order 1.89 but 2.2 % at 128².</li>
<li><b>Not coupled in v4.0:</b> GYRO (02; needs anisotropic pressure evolution, HLLD is isotropic; enabling it refuses), gravity, the v3.1 ScienceManager. Code units with μ<sub>0</sub> = 1, declared in every manifest; physical units are a planned units manager.</li>
<li><b>Reproducibility claim:</b> GPU = CPU bit for bit in FP64 on an NVIDIA L4 and a Tesla T4 against x86-64 g++ 13.3, within one machine and across machines once the initial states are frozen. Initial conditions built with LAPACK are not portable across NumPy builds; the campaign ships its frozen modes. Other GPUs and compilers: expected (IEEE basic operations only), not tested.</li>
<li><b>FP32:</b> the kernels' FP32 paths are IEEE on both backends; the Driver's own FP32 arithmetic on CuPy flushes subnormals and has not been audited. FP64 is the default and the only precision DRV-01 certifies.</li>
<li><b>Tested regime:</b> code-unit pinches, waves and shocks at moderate β and modest grids; strongly magnetised, relativistic-speed or extreme-scale runs (e.g. J<sub>0</sub> ~ 1e18 A/m² in physical units) are open and need the units manager first.</li>
</ul>

<h2>9. Integrity and reproduction</h2>
<table><tr><th>File</th><th>SHA-256</th></tr>{filerows}</table>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:8.6pt;text-align:left">sha256sum -c SHA256SUMS.txt<br>cd drv/tests &amp;&amp; python drv01.py cpu &nbsp;·&nbsp; python drv01.py gpu &nbsp;&nbsp;(GPU leg needs drv01_states_cpu.npz and drv01_frozen_modes.npz)<br>A1_TESTS="D03 D06" python drv01_addendum_A1.py cpu &nbsp;·&nbsp; A1_TESTS=D04 python drv01_addendum_A1.py gpu<br>python probe_kw02.py cupy &nbsp;·&nbsp; python probe_kw03.py cupy &nbsp;·&nbsp; python readme_benchmark_driver.py cpu|cupy<br>python make_results_drv01.py</div>
<p class="note">CPU leg {e(ec['utc'])}, {e(ec['platform'])}, Python {ec['python']}. GPU run 1 {e(e1['utc'])}, {e(e1['gpu'])}. GPU run 2 {e(eg['utc'])}, {e(eg['gpu'])}, {e(eg['platform'])}, Python {eg['python']}, CuPy {eg['cupy']}. {len(R['bundles'])} bundles (CPU leg and GPU run 2) with SHA-256 in DRV01_RESULTS.json.</p>

<h2>10. What it is for</h2>
<p>ALADIN Driver v4.0 is the instrument for the Z-pinch and J × B experiments of ALADIN Plasma Cosmology: a native-cylindrical, axis-inclusive MHD code whose every kernel is certified, whose runs refuse rather than continue when something is wrong, and whose results are the same bits on a laptop CPU and on a cloud GPU, so that a result can be checked by anyone. Next: a units manager and a J<sub>0</sub>-scale test, then gravity and the galactic disk.</p>
<p class="note">Credits: Mihai Alexandru Bucurenciu (ALADIN): the Driver's design and its GPU = CPU rule, the README Z-pinch benchmark, the eleven kernels, and all GPU runs. DRV-01, the probes and the evidence tooling developed with AI assistance. Independent review by a human third party is pending.</p>
<p class="note"><b>AI assistant Team:</b> SuperGrok, Claude, ChatGPT</p>
"""
css += "\n.hero{break-inside:avoid;page-break-inside:avoid} .hero .eq{font-size:9.6pt} .pill.red{background:#a33b3b} .camp td{font-size:8pt} .camp td.mono{font-size:7.2pt;line-height:1.35} table{break-inside:auto} tr{break-inside:avoid}"
open("/home/claude/drv01pdf/report.html", "w").write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>ALADIN Driver v4.0</title><style>{css}</style></head><body>{body}</body></html>')
print("ok")
