import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
R = json.load(open("/home/claude/drv/tests/DRV01_RESULTS.json")); c = {t["id"]: t for t in R["legs"]["cpu"]}; g2 = {t["id"]: t for t in R["legs"]["gpu_run2"]}; g1 = {t["id"]: t for t in R["legs"]["gpu_run1"]}
A = R["addendum_A1"]
plt.rcParams.update({"font.size": 8.5, "font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False})
C1, C2, C3, C4, GR = "#1f5f8b", "#c0603a", "#4f8f4f", "#7a5c9e", "#888"
fig, ax = plt.subplots(2, 2, figsize=(7.4, 5.9))
# (a) D07
r = c["D07"]["data"]["runs"]; n = [32, 64, 128]; e = [r[f"{k}x{k//2}"]["rel_err"] for k in n]
a = ax[0, 0]; a.loglog(n, e, "o-", color=C1, label="Driver vs oracle"); a.loglog(n, [e[0] * (32 / k) ** 2 for k in n], "--", color=GR, lw=0.8, label="2nd order")
a.axhline(0.02, color=C2, lw=0.8, ls=":"); a.text(34, 0.023, "threshold 2 % (at 128×64)", color=C2, fontsize=7.5)
for k, v in zip(n, e): a.annotate(f"{100*v:.2g} %", (k, v), textcoords="offset points", xytext=(5, 4), fontsize=7.5)
a.set_xticks(n); a.set_xticklabels(["32×16", "64×32", "128×64"]); a.minorticks_off(); a.set_xlabel("grid (nr × nz)"); a.set_ylabel("relative error of growth rate")
a.set_title("(a) D07 sausage instability, README pinch\nγ = 0.28248 (independent oracle): PASS, order 2.65", fontsize=8.5, loc="left"); a.legend(frameon=False, fontsize=7.5, loc="lower left")
# (b) z-only vs joint refinement
a = ax[0, 1]; lv = [1, 2, 3]
def rows(d, pre): return [d["rows"][k]["rel_err"] for k in d["rows"] if k.startswith(pre + " (")]
for name, zo, jo, col in (("D03 resistive decay", [c["D03"]["data"]["runs"][k]["rel_err"] for k in ("16", "32", "64")], rows(A["D03_cpu"], "branch+1"), C1),
                          ("D04 Hall wave (worst branch)", [c["D04"]["data"]["runs"]["branch-1"][k]["rel_err"] for k in ("16", "32", "64")], rows(A["D04_gpu"], "branch+1"), C2),
                          ("D06 Alfvén wave", [c["D06"]["data"]["runs"]["branch+1"][k]["rel_err"] for k in ("16", "32", "64")], rows(A["D06_cpu"], "branch+1"), C3)):
    a.semilogy(lv, zo, "o--", color=col, alpha=0.55, lw=0.9); a.semilogy(lv, jo, "o-", color=col, label=name)
a.axhline(0.01, color=GR, lw=0.8, ls=":"); a.text(1.02, 0.0112, "threshold 1 %", color=GR, fontsize=7.5)
a.set_xticks(lv); a.set_xticklabels(["nz 16\n4×8×16", "nz 32\n8×16×32", "nz 64\n16×32×64"], fontsize=7.2)
a.set_ylabel("relative error"); a.set_title("(b) dashed: z only at 4×8 (frozen, FAIL)\nsolid: r, φ, z together (addendum A1, post hoc)", fontsize=8.5, loc="left")
a.legend(frameon=False, fontsize=7.2, loc="lower left")
# (c) D13
d = c["D13"]["data"]["res"]; n = [32, 64, 128]
a = ax[1, 0]; a.loglog(n, [d["resistive"][str(k)]["rel_err"] for k in n], "o-", color=C1, label="resistive heating vs η J²")
a.loglog(n, [d["resistive"][str(k)]["rel_err_without_fix"] for k in n], "x:", color=C1, alpha=0.6, label="… without Poynting term")
a.loglog(n, [d["hall"][str(k)]["rel"] for k in n], "s-", color=C2, label="Hall heating (exact: 0)")
a.loglog(n, [d["hall"][str(k)]["rel_without_fix"] for k in n], "x:", color=C2, alpha=0.6, label="… without Poynting term")
a.axhline(0.01, color=C1, lw=0.7, ls=":"); a.axhline(0.05, color=C2, lw=0.7, ls=":")
a.set_xticks(n); a.set_xticklabels(["32²", "64²", "128²"]); a.minorticks_off(); a.set_xlabel("cross-section"); a.set_ylabel("relative error")
a.set_title("(c) D13 energy of the non-ideal terms, flux tube\nresistive order 1.89 (FAIL at 2.2 %), Hall 5.3 % (FAIL)", fontsize=8.5, loc="left"); a.set_ylim(5e-3, 3e3); a.set_yticks([1e-2, 1e-1, 1, 10]); a.legend(frameon=False, fontsize=6.8, loc="upper right", ncol=2, bbox_to_anchor=(1.02, 1.02))
# (d) D12
a = ax[1, 1]; rr2 = g2["D12"]["data"]["rows"]; rr1 = g1["D12"]["data"]["rows"]
k2 = list(rr2); x = [rr2[k]["cells"] for k in k2]
a.loglog(x, [rr2[k]["memory_measured_MiB"] for k in k2], "o-", color=C1, label="measured, T4 (run 2)")
a.loglog(x, [rr2[k]["memory_estimate_MiB"] for k in k2], "--", color=C1, lw=0.9, label="estimate (180 arrays/step)")
k1 = list(rr1); a.loglog([rr1[k]["cells"] for k in k1], [rr1[k]["memory_measured_MiB"] for k in k1], "s", color=C4, mfc="none", label="measured, L4 (run 1)")
a.set_xlabel("cells"); a.set_ylabel("GPU memory (MiB)")
b = a.twinx(); b.semilogx(x, [rr2[k]["cell_updates_per_s"] / 1e6 for k in k2], "^-", color=C3, label="T4 throughput"); b.semilogx([rr1[k]["cells"] for k in k1], [rr1[k]["cell_updates_per_s"] / 1e6 for k in k1], "^", color=C4, mfc="none", label="L4 throughput")
b.set_ylabel("million cell-updates / s", color=C3); b.spines["top"].set_visible(False)
h1, l1 = a.get_legend_handles_labels(); h2, l2 = b.get_legend_handles_labels(); a.legend(h1 + h2, l1 + l2, frameon=False, fontsize=6.8, loc="upper left")
a.set_title("(d) D12 memory and speed, FP64\n96³ held out: estimate holds (PASS)", fontsize=8.5, loc="left")
fig.tight_layout(); fig.savefig("drv01_fig.png", dpi=220)
