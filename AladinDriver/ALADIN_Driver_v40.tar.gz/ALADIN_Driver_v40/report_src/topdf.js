const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  await p.goto('file:///home/claude/drv01pdf/report.html', { waitUntil: 'networkidle' });
  await p.pdf({ path: '/home/claude/drv01pdf/ALADIN_Driver_v40_DRV01_Report.pdf', format: 'A4', printBackground: true,
    displayHeaderFooter: true, headerTemplate: '<span></span>',
    footerTemplate: '<div style="font-size:7px;color:#5b6475;width:100%;padding:0 17mm;display:flex;justify-content:space-between;font-family:DejaVu Sans"><span>ALADIN Driver v4.0 — DRV-01 certification report · 22 November 2026</span><span class="pageNumber"></span></div>',
    margin: { top: '18mm', bottom: '20mm', left: '17mm', right: '17mm' } });
  await b.close();
})();
