# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0 -- certification campaign DRV-01.        python drv01.py cpu | gpu  [quick]
Every test compares the Driver with a reference INDEPENDENT of the Driver; every threshold below was declared on
2026-11-21 before the test was run.  Disclosed previews (run before the freeze, and the only ones): D07 at 16x8, 32x16,
64x32 (growth error 137 %, 34.1 %, 5.0 %), which is why D07's rule is set at an untested 128x64 with convergence; D13 on an
axisymmetric B_z bump (the frozen D13 uses an off-axis tube that was not run before the freeze).
Each test runs inside the MakeReport bundle manager (runs_drv01_<leg>/<test>_...), so each leaves a checksummed bundle.
"quick" = plumbing check at small sizes: NOT results, never reported.

CHANGES MADE AFTER THE QUICK PLUMBING RUN, BEFORE ANY FULL RUN (thresholds unchanged; disclosed):
  1. Driver: with a conducting wall, the well-balancing equilibrium handed to HLLD now gets the same mirrored ghosts as the
     state (the quick D02 showed mass leaking through the wall at 1.3e-6: an inconsistency, now exactly conserved).
  2. D03 design: eta 0.01 -> 0.05 and p0 100 -> 1.  The quick run showed the decay set by the upwind EMF's numerical
     dissipation (fast speed ~13 at p0 = 100), not by eta: the test could not measure what it claims.  eps = 1e-3 keeps the
     eps^2 magnetic force negligible at p0 = 1.  The threshold (1 % at nz = 64, order >= 1.8) is unchanged.
"""
import os, sys, json, time, math, platform, datetime, hashlib, traceback
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT); sys.path.insert(0, HERE)
import aladin_driver_v40 as D
from managers import bundle_manager as BM, initial_conditions as IC
from managers.integrator import _dilate
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; BK = "cupy" if LEG == "gpu" else "cpu"; QUICK = "quick" in sys.argv[2:]
ONLY = [a for a in sys.argv[2:] if a.startswith("D")]
RUNS = os.path.join(HERE, f"runs_drv01_{LEG}{'_quick' if QUICK else ''}"); os.makedirs(RUNS, exist_ok=True)
H = D.host; STATES = {}

TH = dict(
    D01_static_dU=0.0, D01_static_dB=0.0,
    D02_mass_rel=1e-12, D02_energy_rel=1e-12, D02_pz_abs=1e-12, D02_L_abs=1e-12, D02_divB=1e-12,
    D03_rate_rel_64=0.01, D03_order=1.8,
    D04_omega_rel_64=0.01, D04_order=1.8,
    D05_L1_rho_400=1e-2, D05_order=0.6, D05_uniformity=1e-12,
    D06_omega_rel_64=0.01, D06_order=1.8,
    D07_growth_rel_128=0.02, D07_order=1.5, D07_monotone=1.0,
    D08_restart_values=0.0,
    D09_rules=1.0,
    D10_ablation_factor=10.0, D10_wb_off_dU=1e-6,
    D11_gpu_cpu_values=0.0,
    D12_memory_estimate_holds=1.0,
    D13_resistive_rel_128=0.01, D13_resistive_order=1.5, D13_hall_rel_128=0.05, D13_hall_order=0.9,
)
K = 2 * np.pi

# =========================================================================================================== helpers
def cfg(**kw):
    base = dict(backend=BK, label=kw.pop("label", "DRV-01")); base.update(kw); return D.Config(**base)

def interior(d, a): return H(a)[d.grids.I]

def cellB(d):
    Br, Bp, Bz = (H(x) for x in d.B)
    return 0.5 * (Br[:-1] + Br[1:]), 0.5 * (Bp[:, :-1] + Bp[:, 1:]), 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])

def transverse_amp(d, k):
    """complex amplitude of (b_x + i b_y) e^{-ikz} over the interior (cell-centred B)"""
    Brc, Bpc, _ = cellB(d); I = d.grids.I; ph = d.GE.phi_c[None, :, None]; z = d.GE.z_c[None, None, :]
    bx = Brc * np.cos(ph) - Bpc * np.sin(ph); by = Brc * np.sin(ph) + Bpc * np.cos(ph)
    return complex(((bx + 1j * by) * np.exp(-1j * k * z))[I].mean())

def order(e1, e2): return math.log2(e1 / e2) if e1 > 0 and e2 > 0 else float("nan")

def save_state(name, d):
    for i, x in enumerate(d.U + d.B): STATES[f"{name}_{i}"] = H(x).copy()

def bundled(tid, thresholds, fn):
    """run fn(rb) inside a RunBundle with the test's thresholds; fn returns (data, measured {check: value})"""
    rb = BM.RunBundle(RUNS, tid, thresholds=thresholds)
    data, measured = {}, {}
    try:
        with rb:
            data, measured = fn(rb)
            for k_, v in measured.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    return dict(id=tid, bundle=os.path.basename(rb.dir), verdict=res["verdict"], checks=res["checks"], data=data)

def T(op, key, meaning): return (op, TH[key], meaning)

# =========================================================================================================== D01 static
def D01():
    def fn(rb):
        out = {}
        for bc in ("fixed", "wall"):
            n = 200 if QUICK else 2000
            d = D.Driver(cfg(nr=32, nphi=16, nz=16, well_balanced=True, r_outer_bc=bc), D.ic_zpinch()) if bc == "fixed" else rb.driver(cfg(nr=32, nphi=16, nz=16, well_balanced=True, r_outer_bc=bc), D.ic_zpinch())
            U0 = [H(x).copy() for x in d.U]; B0 = [H(x).copy() for x in d.B]
            (rb.run(nsteps=n) if bc == "wall" else d.run(nsteps=n))
            out[bc] = dict(steps=d.step, t=d.t, dU=max(float(np.abs(H(a) - b).max()) for a, b in zip(d.U, U0)), dB=max(float(np.abs(H(a) - b).max()) for a, b in zip(d.B, B0)))
            save_state(f"D01_{bc}", d)
        return out, dict(dU=max(v["dU"] for v in out.values()), dB=max(v["dB"] for v in out.values()))
    return bundled("D01", dict(dU=T("<=", "D01_static_dU", "README pinch (well-balanced) stays exactly static: max |U(t) - U(0)|, fixed and wall boundaries"),
                               dB=T("<=", "D01_static_dB", "max |B(t) - B(0)| on every CT face")), fn)

# =========================================================================================================== D02 conservation
def pinch_mode(N=400, k=2 * K):
    import oracle_linear_pinch as O
    M = O.eigenmode(N, 0, k); M["k"] = k; return M

def D02():
    def fn(rb):
        M = pinch_mode(200)
        d = rb.driver(cfg(nr=32, nphi=4, nz=16, z_len=2 * np.pi / M["k"], well_balanced=True, r_outer_bc="wall"), IC.ic_pinch_mode(M, 1e-3))
        t0 = d.totals(); rb.run(nsteps=100 if QUICK else 1000); t1 = d.totals(); save_state("D02", d)
        rel = lambda k_: abs(t1[k_] - t0[k_]) / abs(t0[k_])
        data = dict(steps=d.step, t=d.t, totals0=t0, totals1=t1)
        return data, dict(mass=rel("mass"), energy=rel("energy"), pz=abs(t1["pz"] - t0["pz"]), L=abs(t1["L"] - t0["L"]), divB=t1["divB_norm"])
    return bundled("D02", dict(mass=T("<=", "D02_mass_rel", "relative change of total mass (closed: conducting wall, periodic z)"),
                               energy=T("<=", "D02_energy_rel", "relative change of total energy"), pz=T("<=", "D02_pz_abs", "change of total z-momentum"),
                               L=T("<=", "D02_L_abs", "change of total angular momentum sum V rbar m_phi"), divB=T("<=", "D02_divB", "max normalised div B")), fn)

# =========================================================================================================== D03 resistive decay
def decay_run(nz, eta=0.05, ablate=(), t_end=0.5, rb=None):
    c = cfg(nr=4, nphi=8, nz=nz, eta=eta, r_outer_bc="outflow", ablate=tuple(ablate))
    d = rb.driver(c, IC.ic_resistive_decay(K, 1e-3, p0=1.0)) if rb else D.Driver(c, IC.ic_resistive_decay(K, 1e-3, p0=1.0))
    ts, amp = [0.0], [abs(transverse_amp(d, K))]
    def rec(dd, r): ts.append(dd.t); amp.append(abs(transverse_amp(dd, K)))
    (rb.run(t_end=t_end, on_step=rec) if rb else d.run(t_end=t_end, on_step=rec))
    ts, amp = np.array(ts), np.array(amp); rate = -np.polyfit(ts, np.log(amp), 1)[0]
    return d, rate, abs(rate - eta * K * K) / (eta * K * K)

def D03():
    def fn(rb):
        res = {}
        for nz in ((16, 32) if QUICK else (16, 32, 64)):
            d, rate, err = decay_run(nz, rb=rb if nz == (32 if QUICK else 64) else None, t_end=0.1 if QUICK else 0.5); res[nz] = dict(rate=rate, rel_err=err, steps=d.step)
        save_state("D03", d); n = sorted(res)
        return dict(exact_rate=0.05 * K * K, runs=res), dict(err=res[n[-1]]["rel_err"], order=order(res[n[-2]]["rel_err"], res[n[-1]]["rel_err"]))
    return bundled("D03", dict(err=T("<=", "D03_rate_rel_64", "resistive decay rate vs exact eta k^2 (eta = 0.05, k = 2 pi), relative, nz = 64"),
                               order=T(">=", "D03_order", "observed order, nz 32 -> 64")), fn)

# =========================================================================================================== D04 / D06 circular waves
def wave_run(nz, hall, branch=+1, ablate=(), periods=1.0, rb=None):
    ic = IC.ic_circular_wave(K, 1e-2, hall=hall, branch=branch); w = ic.omega
    c = cfg(nr=4, nphi=8, nz=nz, hall=hall, r_outer_bc="outflow", ablate=tuple(ablate))
    d = rb.driver(c, ic) if rb else D.Driver(c, ic)
    ts, ph = [0.0], [np.angle(transverse_amp(d, K))]
    def rec(dd, r): ts.append(dd.t); ph.append(np.angle(transverse_amp(dd, K)))
    t_end = periods * 2 * np.pi / abs(w)
    (rb.run(t_end=t_end, on_step=rec) if rb else d.run(t_end=t_end, on_step=rec))
    ph = np.unwrap(np.array(ph)); wm = -np.polyfit(np.array(ts), ph, 1)[0]
    return d, wm, w, abs(wm - w) / abs(w)

def wave_test(tid, hall, key_err, key_ord, meaning):
    def fn(rb):
        res = {}; worst = {}
        branches = (+1, -1) if hall else (+1,)
        for br in branches:
            r = {}
            for nz in ((16, 32) if QUICK else (16, 32, 64)):
                d, wm, w, err = wave_run(nz, hall, br, rb=rb if (nz == (32 if QUICK else 64) and br == branches[-1]) else None, periods=0.25 if QUICK else 1.0)
                r[nz] = dict(omega_measured=wm, omega_exact=w, rel_err=err, steps=d.step)
            res[f"branch{br:+d}"] = r; n = sorted(r)
            worst[br] = (r[n[-1]]["rel_err"], order(r[n[-2]]["rel_err"], r[n[-1]]["rel_err"]))
        save_state(tid, d)
        return dict(runs=res), dict(err=max(v[0] for v in worst.values()), order=min(v[1] for v in worst.values()))
    return bundled(tid, dict(err=T("<=", key_err, meaning + ", relative frequency error at nz = 64 (worst branch)"),
                             order=T(">=", key_ord, "observed order nz 32 -> 64 (worst branch)")), fn)

def D04(): return wave_test("D04", 0.1, "D04_omega_rel_64", "D04_order", "Hall MHD circularly polarised wave (exact w^2 + H w = vA^2 k^2, both roots)")
def D06(): return wave_test("D06", 0.0, "D06_omega_rel_64", "D06_order", "ideal circularly polarised Alfven wave (exact w = vA k)")

# =========================================================================================================== D05 Sod
def sod_exact(x, t, x0=0.5, g=1.4, L=(1.0, 0.0, 1.0), R=(0.125, 0.0, 0.1)):
    """exact Riemann solution (Toro, ch. 4), independent of the Driver: rho(x) at time t"""
    rl, ul, pl = L; rr, ur, pr = R; cl, cr = math.sqrt(g * pl / rl), math.sqrt(g * pr / rr)
    def f(p, rk, pk, ck):
        if p > pk:
            A, B = 2 / ((g + 1) * rk), (g - 1) / (g + 1) * pk; return (p - pk) * math.sqrt(A / (p + B))
        return 2 * ck / (g - 1) * ((p / pk) ** ((g - 1) / (2 * g)) - 1)
    lo, hi = 1e-12, 10 * max(pl, pr)
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if f(mid, rl, pl, cl) + f(mid, rr, pr, cr) + ur - ul > 0: hi = mid
        else: lo = mid
    ps = 0.5 * (lo + hi); us = 0.5 * (ul + ur) + 0.5 * (f(ps, rr, pr, cr) - f(ps, rl, pl, cl))
    out = np.empty_like(x)
    for i, xi in enumerate(x):
        s = (xi - x0) / t
        if s < us:                                                           # left of contact (rarefaction for Sod)
            rls = rl * (ps / pl) ** (1 / g); cls = cl * (ps / pl) ** ((g - 1) / (2 * g))
            if s < ul - cl: out[i] = rl
            elif s > us - cls: out[i] = rls
            else: out[i] = rl * (2 / (g + 1) + (g - 1) / ((g + 1) * cl) * (ul - s)) ** (2 / (g - 1))
        else:                                                                # right: shock
            rrs = rr * ((ps / pr + (g - 1) / (g + 1)) / ((g - 1) / (g + 1) * ps / pr + 1)); S = ur + cr * math.sqrt((g + 1) / (2 * g) * ps / pr + (g - 1) / (2 * g))
            out[i] = rrs if s < S else rr
    return out

def sod_run(nz, ablate=(), rb=None, t_end=0.2):
    c = cfg(nr=4, nphi=4, nz=nz, z_bc="outflow", r_outer_bc="outflow", gamma=1.4, ablate=tuple(ablate))
    d = rb.driver(c, IC.ic_sod_z()) if rb else D.Driver(c, IC.ic_sod_z())
    (rb.run(t_end=t_end) if rb else d.run(t_end=t_end))
    rho = interior(d, d.U[0]); prof = rho.mean(axis=(0, 1)); ex = sod_exact(d.GE.z_c[d.g:d.g + nz], d.t)
    unif = float(np.abs(rho - prof[None, None, :]).max() / np.abs(prof).max())
    return d, float(np.abs(prof - ex).mean()), unif

def D05():
    def fn(rb):
        res = {}
        for nz in ((50, 100) if QUICK else (100, 200, 400)):
            d, l1, u = sod_run(nz, rb=rb if nz == (100 if QUICK else 400) else None); res[nz] = dict(L1_rho=l1, uniformity=u, steps=d.step, t=d.t)
        save_state("D05", d); n = sorted(res)
        return dict(runs=res), dict(L1=res[n[-1]]["L1_rho"], order=order(res[n[-2]]["L1_rho"], res[n[-1]]["L1_rho"]), uniformity=max(v["uniformity"] for v in res.values()))
    return bundled("D05", dict(L1=T("<=", "D05_L1_rho_400", "Sod along z (gamma = 1.4, t = 0.2): L1(rho) vs the exact Riemann solution, nz = 400"),
                               order=T(">=", "D05_order", "observed L1 order nz 200 -> 400"), uniformity=T("<=", "D05_uniformity", "max deviation across r and phi (the solution is 1-D)")), fn)

# =========================================================================================================== D07 sausage growth
def growth_run(nr, nz, M, eps=1e-6, t_end=20.0, ablate=(), rb=None):
    c = cfg(nr=nr, nphi=4, nz=nz, z_len=2 * np.pi / M["k"], well_balanced=True, r_outer_bc="wall", ablate=tuple(ablate))
    d = rb.driver(c, IC.ic_pinch_mode(M, eps)) if rb else D.Driver(c, IC.ic_pinch_mode(M, eps))
    V, _ = d.grids.volumes(); V = H(V); ts, ke = [], []
    def rec(dd, r):
        pr = dd.PR.primitives(dd.GP, *dd.U, *dd.B, gamma=dd.cfg.gamma)
        ke.append(float((V * interior(dd, pr["rho"]) * (interior(dd, pr["vr"]) ** 2 + interior(dd, pr["vz"]) ** 2)).sum())); ts.append(dd.t)
    (rb.run(t_end=t_end, on_step=rec) if rb else d.run(t_end=t_end, on_step=rec))
    ts, ke = np.array(ts), np.array(ke); w = (ts > 4) & (ts <= t_end)
    gam = float(np.polyfit(ts[w], np.log(ke[w]), 1)[0] / 2) if w.sum() > 2 else float("nan")
    return d, gam

def D07():
    def fn(rb):
        M = pinch_mode(400); gx = float(M["sigma"].real); res = {}
        grids = ((16, 8), (32, 16)) if QUICK else ((32, 16), (64, 32), (128, 64))
        for nr, nz in grids:
            d, gm = growth_run(nr, nz, M, rb=rb if (nr, nz) == grids[-1] else None, t_end=6.0 if QUICK else 20.0)
            res[f"{nr}x{nz}"] = dict(growth=gm, rel_err=abs(gm - gx) / gx, steps=d.step)
        save_state("D07", d); e = [res[f"{a}x{b}"]["rel_err"] for a, b in grids]
        return dict(oracle_growth=gx, oracle="oracle_linear_pinch.py, N = 400, m = 0, k = 4 pi, wall at r = 1", runs=res), \
            dict(err=e[-1], order=order(e[-2], e[-1]), monotone=float(all(e[i + 1] < e[i] for i in range(len(e) - 1))))
    return bundled("D07", dict(err=T("<=", "D07_growth_rel_128", "sausage (m = 0) growth rate vs the independent linear oracle (relative), 128 x 64"),
                               order=T(">=", "D07_order", "observed order 64x32 -> 128x64"), monotone=T("==", "D07_monotone", "error decreases at every refinement")), fn)

# =========================================================================================================== D08 restart
def D08():
    def fn(rb):
        M = pinch_mode(200); out = {}; n = 20 if QUICK else 200
        cases = dict(pinch=(dict(nr=32, nphi=4, nz=16, z_len=2 * np.pi / M["k"], well_balanced=True, r_outer_bc="wall"), IC.ic_pinch_mode(M, 1e-3)),
                     tube_eta_hall=(dict(nr=16, nphi=16, nz=4, z_len=0.25, eta=0.01, hall=0.02, r_outer_bc="outflow"), IC.ic_flux_tube()))
        worst = 0
        for name, (kw, ic) in cases.items():
            a = D.Driver(cfg(**kw), ic); a.run(nsteps=n)
            b = D.Driver(cfg(**kw), ic); b.run(nsteps=n // 2); ck = os.path.join(rb.dir, f"ckpt_{name}"); b.save(ck)
            c = D.Driver(cfg(**kw), ic); c.load(ck); c.run(nsteps=n)
            nd = sum(int((H(x) != H(y)).sum()) for x, y in zip(a.U + a.B, c.U + c.B)) + int(a.t != c.t); worst += nd
            out[name] = dict(steps=n, values_differing=nd, t=a.t); save_state(f"D08_{name}", c)
            for f in os.listdir(rb.dir):
                if f.startswith("ckpt_"): os.remove(os.path.join(rb.dir, f))
        return out, dict(values=float(worst))
    return bundled("D08", dict(values=T("<=", "D08_restart_values", "restart at half time in a NEW Driver == uninterrupted run, bit for bit (incl. t)")), fn)

# =========================================================================================================== D09 failures
def D09():
    def fn(rb):
        rules = {}
        def ic_neg(d):
            x = D.ic_zpinch()(d); x["U"][0][5, 5, 5] = -1.0; return x
        d = D.Driver(cfg(nr=16, nphi=8, nz=8), ic_neg); st = d.run(nsteps=3); rules["negative density -> explicit FAILED at step 0"] = st == "FAILED" and d.step == 0
        def ic_blast(d):
            x = D.ic_zpinch()(d); G = d.GE; rc = G.r_centers[:, None, None]; zc = G.z_c[None, None, :]; ph = G.phi_c[None, :, None]
            hot = ((rc * np.cos(ph) - 0.45) ** 2 + (rc * np.sin(ph)) ** 2 + (zc - 0.5) ** 2) < 0.15 ** 2
            p = np.where(hot, 200.0, 1e-3 + 0 * rc * np.ones(x["U"][0].shape)); x["U"][4] = p / (2 / 3) + 0.5 * (0.5 * rc) ** 2 * np.ones_like(p); return x
        d = D.Driver(cfg(nr=32, nphi=16, nz=16), ic_blast); st = d.run(nsteps=10 if QUICK else 30)
        pr = d.PR.primitives(d.GP, *d.U, *d.B, gamma=d.cfg.gamma); adm = not bool(((H(pr["flags"]) & 11) > 0)[d.grids.I].any())
        nrec = sum(e["event"] == "recovery_pass" for e in d.events)
        rules["blast: completes with local recovery, final state admissible"] = st == "COMPLETED" and nrec > 0 and adm
        d = D.Driver(cfg(nr=16, nphi=8, nz=8), D.ic_zpinch())
        def poison(dd, r):
            if dd.step == 3: dd.U[4][dd.g + 4, dd.g + 2, dd.g + 2] = np.nan
        st = d.run(nsteps=10, on_step=poison); rules["NaN injected at step 3 -> explicit FAILED, never a silent continue"] = st == "FAILED" and d.step == 3
        d = D.Driver(cfg(nr=16, nphi=8, nz=8, max_passes=0), ic_blast); st = d.run(nsteps=10)
        rules["recovery disabled (max_passes = 0) on the blast -> explicit STOP event"] = st == "FAILED" and any(e["event"] == "STOP" for e in d.events)
        save_state("D09", d)
        return dict(rules={k_: bool(v) for k_, v in rules.items()}, blast_recovery_passes=nrec), dict(rules=float(all(rules.values())))
    return bundled("D09", dict(rules=T("==", "D09_rules", "every failure rule holds")), fn)

# =========================================================================================================== D10 ablation
def D10():
    def fn(rb):
        M = pinch_mode(200); rows = {}
        nz_w = 16 if QUICK else 32
        _, _, _, e_wave = wave_run(nz_w, 0.0, periods=0.25 if QUICK else 1.0)
        _, _, e_dec = decay_run(nz_w, t_end=0.1 if QUICK else 0.5)
        _, l1_sod, _ = sod_run(50 if QUICK else 100)
        gx = float(M["sigma"].real); _, g_ok = growth_run(32 if QUICK else 64, 16 if QUICK else 32, M, t_end=6.0 if QUICK else 20.0)
        e_gr = abs(g_ok - gx) / gx
        for slot, test, base, run in [
            ("04 HLLD-R", "D07 growth", e_gr, lambda: abs(growth_run(32 if QUICK else 64, 16 if QUICK else 32, M, ablate=("04 HLLD-R",), t_end=6.0 if QUICK else 20.0)[1] - gx) / gx),
            ("05 HLLD-phi", "D06 Alfven frequency", e_wave, lambda: wave_run(nz_w, 0.0, ablate=("05 HLLD-phi",), periods=0.25 if QUICK else 1.0)[3]),
            ("06 HLLD-Z", "D05 Sod L1", l1_sod, lambda: sod_run(50 if QUICK else 100, ablate=("06 HLLD-Z",))[1]),
            ("07 RESIDUAL", "D06 Alfven frequency", e_wave, lambda: wave_run(nz_w, 0.0, ablate=("07 RESIDUAL",), periods=0.25 if QUICK else 1.0)[3]),
            ("08+11 UCT-EMF", "D03 decay rate", e_dec, lambda: decay_run(nz_w, ablate=("08+11 UCT-EMF",), t_end=0.1 if QUICK else 0.5)[2]),
            ("09 UCT-CURL", "D03 decay rate", e_dec, lambda: decay_run(nz_w, ablate=("09 UCT-CURL",), t_end=0.1 if QUICK else 0.5)[2])]:
            try: abl = float(run())
            except Exception as x: abl = float("inf"); rows[slot] = dict(note=f"ablated run stopped: {x!r}")
            rows[slot] = dict(rows.get(slot, {}), test=test, error_normal=base, error_ablated=abl, factor=(abl / base if base > 0 else float("inf")))
        d = D.Driver(cfg(nr=32, nphi=16, nz=16, well_balanced=False), D.ic_zpinch()); U0 = [H(x).copy() for x in d.U]; d.run(nsteps=20 if QUICK else 200)
        wb = max(float(np.abs(H(a) - b).max()) for a, b in zip(d.U, U0))
        rows["well-balancing off"] = dict(test="D01 static", error_normal=0.0, error_ablated=wb)
        fmin = min(v["factor"] for k_, v in rows.items() if "factor" in v)
        return dict(rows=rows), dict(factor=fmin, wb=wb)
    return bundled("D10", dict(factor=T(">=", "D10_ablation_factor", "smallest (ablated error / normal error) over the six kernel slots"),
                               wb=T(">=", "D10_wb_off_dU", "well-balancing off: the static pinch is no longer static (max |dU|)")), fn)

# =========================================================================================================== D12 performance (GPU leg; CPU informational)
def D12():
    def fn(rb):
        rows = {}; holds = True
        sizes = ((16, 16, 16), (32, 32, 32)) if (QUICK or BK == "cpu") else ((32, 32, 32), (64, 64, 64), (128, 128, 128))
        for n in sizes:
            d = D.Driver(cfg(nr=n[0], nphi=n[1], nz=n[2], well_balanced=True), D.ic_zpinch())
            d.advance(); d.advance()
            if BK == "cupy":
                import cupy as cp; cp.cuda.Device().synchronize()
            t0 = time.time(); m = 5
            for _ in range(m): d.advance()
            if BK == "cupy": cp.cuda.Device().synchronize()
            dt = (time.time() - t0) / m; use = d.memory.usage(); est = d.memory.estimate()
            meas = use.get("gpu_pool_peak_bytes", use.get("host_peak_rss_bytes"))
            ok = (BK != "cupy") or (meas <= est); holds &= ok
            rows["x".join(map(str, n))] = dict(cells=int(np.prod(n)), seconds_per_step=dt, cell_updates_per_s=float(np.prod(n) / dt), memory_estimate_MiB=est / 2**20, memory_measured_MiB=meas / 2**20, estimate_holds=ok)
        return dict(rows=rows, note="GPU: pool peak vs estimate; CPU: peak RSS of the whole process (informational)"), dict(memory=float(holds))
    return bundled("D12", dict(memory=T("==", "D12_memory_estimate_holds", "GPU memory pool peak <= the memory manager's estimate at every size")), fn)

# =========================================================================================================== D13 energy accounting
def heat_stage(n, eta=0.0, hall=0.0, fix=True, dt=1e-6):
    d = D.Driver(cfg(nr=n, nphi=n, nz=4, z_len=0.25, eta=eta, hall=hall, r_outer_bc="outflow", eglm="monitor"), IC.ic_flux_tube())
    if not fix: d.pipeline.poynting_divergence = lambda Eni, B: 0.0
    def eint(U, B): return interior(d, d.PR.primitives(d.GP, *U, *B, gamma=d.cfg.gamma)["p"]) / (d.cfg.gamma - 1)
    U = [x.copy() for x in d.U]; B = [x.copy() for x in d.B]; e0 = eint(U, B)
    Un, Bn, R = d.integrator.stage(U, B, dt, (d.U0, d.B0)); d.fill(Un, Bn)
    return d, (eint(Un, Bn) - e0) / dt

def D13():
    def fn(rb):
        res = dict(resistive={}, hall={}); sizes = (16, 32) if QUICK else (32, 64, 128)
        for n in sizes:
            d0, h0 = heat_stage(n)
            d, he = heat_stage(n, eta=0.01); _, hn = heat_stage(n, eta=0.01, fix=False)
            G = d.GE; rc = G.r_centers[d.g:d.g + n][:, None, None]; ph = G.phi_c[d.g:d.g + n][None, :, None]
            X, Y = rc * np.cos(ph), rc * np.sin(ph); ex = 0.5 * np.exp(-((X - 0.4) ** 2 + Y ** 2) / 0.04) * (2 / 0.04)
            J2 = ex ** 2 * ((X - 0.4) ** 2 + Y ** 2) * np.ones_like(he)              # |grad B_z|^2 = |J|^2
            ref = 0.01 * J2
            res["resistive"][n] = dict(rel_err=float(np.abs(he - h0 - ref).max() / ref.max()), rel_err_without_fix=float(np.abs(hn - h0 - ref).max() / ref.max()))
            dh, hh = heat_stage(n, hall=0.02); _, hhn = heat_stage(n, hall=0.02, fix=False)
            Ub = [x.copy() for x in dh.U]; Bb = [x.copy() for x in dh.B]; dh.fill(Ub, Bb)
            pr = dh.PR.primitives(dh.GP, *Ub, *Bb, gamma=dh.cfg.gamma); P = [pr[k_] for k_ in ("rho", "vr", "vphi", "vz", "p")]
            J, _ = dh.UC.run_curl(*Bb, G.r_faces, G.r_centers, G.dr, G.dphi, G.dz, n, n, 4, dh.g, backend=BK); J = [dh.xp.ascontiguousarray(dh.xp.asarray(x)) for x in J]; dh.boundary.fill_cells(J, vector=True)
            Em = dh.E.compute_emf(dh.GE, *Bb, P[1], P[2], P[3], P[0], P[4], J=J, gamma=dh.cfg.gamma, hall=0.02, backend=BK)
            Ei = dh.E.compute_emf(dh.GE, *Bb, P[1], P[2], P[3], P[0], P[4], J=None, gamma=dh.cfg.gamma, backend=BK)
            divS = H(dh.pipeline.poynting_divergence([a - b for a, b in zip(Em, Ei)], Bb))
            res["hall"][n] = dict(rel=float(np.abs(hh - h0).max() / np.abs(divS).max()), rel_without_fix=float(np.abs(hhn - h0).max() / np.abs(divS).max()), max_divS=float(np.abs(divS).max()))
            save_state(f"D13_{n}", d)
        r = res["resistive"]; h = res["hall"]; n = sorted(r)
        return dict(res=res, note="single SSP stage, dt = 1e-6, same dt for every run; heat = (e_int(after) - e_int(before))/dt; the eta-only / Hall-only parts are differences against the eta = hall = 0 run"), \
            dict(res=r[n[-1]]["rel_err"], res_order=order(r[n[-2]]["rel_err"], r[n[-1]]["rel_err"]), hall=h[n[-1]]["rel"], hall_order=order(h[n[-2]]["rel"], h[n[-1]]["rel"]))
    return bundled("D13", dict(res=T("<=", "D13_resistive_rel_128", "resistive heating per cell vs eta J^2 (rel. to max eta J^2), off-axis flux tube, 128^2"),
                               res_order=T(">=", "D13_resistive_order", "observed order 64 -> 128"),
                               hall=T("<=", "D13_hall_rel_128", "Hall heating per cell (Hall does no work: 0) rel. to max |div S_Hall|, 128^2"),
                               hall_order=T(">=", "D13_hall_order", "observed order 64 -> 128")), fn)

# =========================================================================================================== D11 GPU = CPU
def D11():
    def fn(rb):
        p = os.path.join(HERE, "drv01_states_cpu.npz")
        if not os.path.exists(p): raise RuntimeError("drv01_states_cpu.npz (the CPU leg's final states) is missing")
        c = np.load(p); rows = {}; n = 0
        for k_ in c.files:
            if k_ not in STATES: rows[k_] = "missing on this leg"; n += 1; continue
            x, y = STATES[k_], c[k_]; nd = int(((x != y) & ~(np.isnan(x) & np.isnan(y))).sum()); n += nd
            if nd: rows[k_] = dict(differing=nd, max_abs=float(np.nanmax(np.abs(x - y))))
        return dict(arrays=len(c.files), differing_arrays=rows), dict(values=float(n))
    return bundled("D11", dict(values=T("<=", "D11_gpu_cpu_values", "final states of every DRV-01 run, GPU vs CPU leg, values differing (FP64)")), fn)

# =========================================================================================================== main
if __name__ == "__main__":
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, quick=QUICK, platform=platform.platform(), python=platform.python_version(), numpy=np.__version__)
    if BK == "cupy":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    probe = D.Driver(cfg(nr=8, nphi=4, nz=4), D.ic_zpinch())
    print(f"DRV-01 leg={LEG}{' QUICK (plumbing only)' if QUICK else ''} | {D.VERSION} | kernels: " + ", ".join(f"{k} {v['record'].split('.')[-1]}" for k, v in probe.build.report.items()))
    tests = [D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D13, D12] + ([D11] if LEG == "gpu" else [])
    if ONLY: tests = [t for t in tests if t.__name__ in ONLY]
    out = []
    for f in tests:
        t0 = time.time(); r = f(); r["seconds"] = round(time.time() - t0, 1); out.append(r)
        print(f"{r['id']:4s} {r['verdict']:24s} {r['seconds']:8.1f}s  " + "; ".join(f"{k}={c['value']:.3e} {c['op']} {c['threshold']:.1e} {c['result']}" if isinstance(c.get("value"), (int, float)) else f"{k}={c.get('value')} {c['result']}" for k, c in r["checks"].items()), flush=True)
        if "exception" in r["data"]: print(r["data"]["exception"])
    if LEG == "cpu" and not QUICK and not ONLY: np.savez_compressed(os.path.join(HERE, "drv01_states_cpu.npz"), **STATES)
    counts = {}
    for r in out: counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    print("SUMMARY", counts)
    json.dump(D.jsonable(dict(campaign="DRV-01", driver=D.VERSION, leg=LEG, quick=QUICK, thresholds=TH, env=env, kernels=probe.build.report, managers=D.manager_hashes(),
                              campaign_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(), tests=out)),
              open(os.path.join(HERE, f"drv01_{LEG}{'_quick' if QUICK else ''}_results.json"), "w"), indent=1, default=str)
