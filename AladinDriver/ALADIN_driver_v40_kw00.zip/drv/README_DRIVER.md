# ALADIN Driver v4.0 — layout
Author: Mihai Alexandru Bucurenciu (ALADIN) · AI assistant Team: SuperGrok, Claude, ChatGPT

Backends: `backend="cpu"` or `backend="cupy"` (GPU); same code, same certified kernels.

```
aladin_driver_v40.py      the conductor: Config -> BuildManager -> wires the managers
managers/
  config.py               every setting of a run (recorded in each bundle)
  build_manager.py        kernel registry, certified-hash check, precision policy, GPU IEEE self-test, environment
  grid_manager.py         one grid for every kernel; axis / annulus; even-nphi rule; volumes, rbar
  memory_manager.py       GPU memory pool + pinned pool; refuses a grid that cannot fit; peak usage per step
  boundary_manager.py     axis reflection, staggered phi seams, z periodic/outflow, outer r fixed/outflow, J ghosts
  pipeline.py             one RHS in the certified order: PRIM -> HLLD-R/phi/Z -> RESIDUAL -> UCT-CURL -> UCT-EMF
  timestep_manager.py     CFL (fast speed, r dphi at the axis, resistive and Hall limits)
  integrator.py           SSP-RK3, transactional, local recovery -> dt halving -> explicit STOP
  diagnostics_manager.py  mass, energy, pz, L, div B, G2 (read-only)
  checkpoint_manager.py   bit-identical restart; refuses wrong grid / precision / modified files
  initial_conditions.py   README Z-pinch (exact equilibrium) + perturbations
  bundle_manager.py       MakeReport: bundles, predeclared thresholds, reports, GPU-vs-CPU comparison
  common.py               shared helpers (no physics)
kernels/                  the certified kernels, unmodified (hash-checked at every start)
tests/
  smoke_drv00.py          SMK-00 (8)    bm_selftest.py  BM-00 (10)    managers_selftest.py  MG-00 (5)
  zp_step.py              CHAIN-01 harness (reference for S1)
  smk00_states_cpu.npz    CPU final states for the GPU = CPU comparison
```
Not yet: GravityManager, ScienceManager (re-attach from v3.1), GYRO coupling (anisotropic pressure).
