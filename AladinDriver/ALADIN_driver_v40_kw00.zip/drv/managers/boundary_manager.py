# -*- coding: utf-8 -*-
"""BOUNDARY MANAGER — every ghost fill of the Driver:
  phi : periodic, staggered-correct (the B_phi seam face g+nphi is the face g)
  z   : periodic (staggered-correct for B_z) | outflow (zero gradient, faces beyond the boundary face too)
  r   : axis -> reflection (uct_emf_v02.fill_axis_ghosts: scalars even, vectors r/phi odd, z even; needs even nphi);
        outer (and the inner edge of an annulus) -> 'fixed' = held at the initial state | 'outflow' = zero gradient
  J   : cell vectors for Hall / resistive EMF (periodic / outflow / axis reflection, outer zero gradient)"""


class BoundaryManager:
    def __init__(self, cfg, grids, E):
        self.cfg = cfg; self.gm = grids; self.E = E; self.g = grids.g; self.axis = grids.axis

    def fill(self, U, B, held):
        """U = [rho, m_r, m_phi, m_z, E], B = [Br, Bphi, Bz] (in place); held = (U0, B0) the state held at a 'fixed' boundary"""
        cfg, g = self.cfg, self.g; nr, P, Z = cfg.nr, cfg.nphi, cfg.nz
        U0, B0 = held
        def phi_periodic(a, kind):
            if kind == "Bphi":
                a[:, g + P, :] = a[:, g, :]; a[:, :g, :] = a[:, P:P + g, :]; a[:, g + P + 1:, :] = a[:, g + 1:g + 1 + g, :]
            else:
                a[:, :g, :] = a[:, P:P + g, :]; a[:, g + P:, :] = a[:, g:g + g, :]
        def z_fill(a, kind):
            if cfg.z_bc == "periodic":
                if kind == "Bz":
                    a[:, :, g + Z] = a[:, :, g]; a[:, :, :g] = a[:, :, Z:Z + g]; a[:, :, g + Z + 1:] = a[:, :, g + 1:g + 1 + g]
                else:
                    a[:, :, :g] = a[:, :, Z:Z + g]; a[:, :, g + Z:] = a[:, :, g:g + g]
            else:
                lo, hi = (g, g + Z) if kind == "Bz" else (g, g + Z - 1)
                a[:, :, :lo] = a[:, :, lo:lo + 1]; a[:, :, hi + 1:] = a[:, :, hi:hi + 1]
        kinds = ["cell"] * 5 + ["Br", "Bphi", "Bz"]; arrs = list(U) + list(B)
        for a, k in zip(arrs, kinds): phi_periodic(a, k); z_fill(a, k)
        # outer radial boundary
        if cfg.r_outer_bc == "fixed":
            for a, a0 in zip(U, U0): a[g + nr:] = a0[g + nr:]
            B[0][g + nr + 1:] = B0[0][g + nr + 1:]; B[1][g + nr:] = B0[1][g + nr:]; B[2][g + nr:] = B0[2][g + nr:]
        else:
            for a in U: a[g + nr:] = a[g + nr - 1:g + nr]
            B[0][g + nr + 1:] = B[0][g + nr:g + nr + 1]; B[1][g + nr:] = B[1][g + nr - 1:g + nr]; B[2][g + nr:] = B[2][g + nr - 1:g + nr]
        # inner radial boundary: axis reflection, or the outer rule at the inner edge of an annulus
        if self.axis:
            self.E.fill_axis_ghosts(self.gm.GE, cells_scalar=(U[0], U[4]), cells_vector=[(U[1], U[2], U[3])], Br=B[0], Bphi=B[1], Bz=B[2])
        elif cfg.r_outer_bc == "fixed":
            for a, a0 in zip(U, U0): a[:g] = a0[:g]
            B[0][:g] = B0[0][:g]; B[1][:g] = B0[1][:g]; B[2][:g] = B0[2][:g]
        else:
            for a in U: a[:g] = a[g:g + 1]
            B[0][:g] = B[0][g:g + 1]; B[1][:g] = B[1][g:g + 1]; B[2][:g] = B[2][g:g + 1]
        for a, k in zip(arrs, kinds): phi_periodic(a, k); z_fill(a, k)

    def fill_cells(self, arrs, vector=False):
        """ghost fill for cell arrays (J): periodic / outflow / axis reflection, outer zero gradient"""
        cfg, g = self.cfg, self.g; P, Z, nr = cfg.nphi, cfg.nz, cfg.nr
        for a in arrs:
            a[:, :g] = a[:, P:P + g]; a[:, g + P:] = a[:, g:2 * g]
            if cfg.z_bc == "periodic": a[:, :, :g] = a[:, :, Z:Z + g]; a[:, :, g + Z:] = a[:, :, g:2 * g]
            else: a[:, :, :g] = a[:, :, g:g + 1]; a[:, :, g + Z:] = a[:, :, g + Z - 1:g + Z]
            a[g + nr:] = a[g + nr - 1:g + nr]
        if self.axis: self.E.fill_axis_ghosts(self.gm.GE, cells_vector=[tuple(arrs)] if vector else [], cells_scalar=() if vector else tuple(arrs))
        for a in arrs: a[:, :g] = a[:, P:P + g]; a[:, g + P:] = a[:, g:2 * g]
