# -*- coding: utf-8 -*-
"""BUILD MANAGER — the gatekeeper.  Loads every kernel from kernels/, checks it against its CERTIFIED hash (Zenodo record),
enforces the precision policy, runs the GPU IEEE self-test, records the environment.  Nothing runs unless all of this passes."""
import os, sys, hashlib, platform, subprocess, importlib.util
import numpy as np
from .common import AdmissibilityError

# slot -> (file, kind of hash, certified hash, record, FP32-IEEE on GPU)
# Slots 04, 05, 06 are ONE certified source (hlld_v05.py, the same HLLD solver per direction, Zenodo 24401083).  The pipeline
# calls each slot separately (directions=(0,), (1,), (2,)); verified bit-identical to one call with directions=(0, 1, 2).
HLLD_DIR = {"04 HLLD-R": 0, "05 HLLD-phi": 1, "06 HLLD-Z": 2}
REGISTRY = {
    "01 PRIM":            ("prim_v01.py",       "source", "1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535", "10.5281/zenodo.24403809", True),
    "02 GYRO":            ("gyro_v03.py",       "source", "b70afa36f7e9873872107c34ac99062c8b44d9e9ad74e5a840c37eb929bf2c90", "10.5281/zenodo.24383948", False),
    "03 G2":              ("g2_karnel_v01.py",  "file",   "98c8680baaf318d4461602f6ab927a87693a6e525eab35dfcda4eff4c0ddf823", "10.5281/zenodo.24369578", False),
    "04 HLLD-R":          ("hlld_v05.py",       "source", "16f555aea33100e9159e950da8afc2d5c182461965d67dc50f3d34a6b9775fe4", "10.5281/zenodo.24401083", False),
    "05 HLLD-phi":        ("hlld_v05.py",       "source", "16f555aea33100e9159e950da8afc2d5c182461965d67dc50f3d34a6b9775fe4", "10.5281/zenodo.24401083", False),
    "06 HLLD-Z":          ("hlld_v05.py",       "source", "16f555aea33100e9159e950da8afc2d5c182461965d67dc50f3d34a6b9775fe4", "10.5281/zenodo.24401083", False),
    "07 RESIDUAL":        ("residual_v01.py",   "source", "51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4", "10.5281/zenodo.24404520", True),
    "08+11 UCT-EMF":      ("uct_emf_v02.py",    "source", "341ebaf6c26706fe8679579a58af8382cbfc96c94386f2c509dd31c3ba958aa0", "10.5281/zenodo.24405701", True),
    "09 UCT-CURL":        ("uct_curl.py",       "file",   "e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e", "10.5281/zenodo.24377625", False),
    "10 E-GLM":           ("eglm_v02.py",       "source", "d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713", "10.5281/zenodo.24395791", False),
}


class BuildManager:
    def __init__(self, cfg, kdir):
        self.cfg = cfg; self.kdir = kdir; self.mods = {}; self.report = {}
        if kdir not in sys.path: sys.path.insert(0, kdir)
        for slot, (fname, kind, sha, rec, fp32_ieee) in REGISTRY.items():
            path = os.path.join(kdir, fname)
            if not os.path.exists(path): raise AdmissibilityError(f"slot {slot}: {fname} missing in {kdir}")
            file_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            name = fname[:-3]
            if name in self.mods:                                                # one source, several slots (HLLD 04/05/06)
                self.report[slot] = dict(self.report[[k for k, v in self.report.items() if v["file"] == fname][0]]); continue
            spec = importlib.util.spec_from_file_location(name, path); mod = importlib.util.module_from_spec(spec)
            sys.modules[name] = mod; spec.loader.exec_module(mod)
            got = getattr(mod, "SOURCE_SHA256", None) if kind == "source" else file_sha
            if got != sha: raise AdmissibilityError(f"slot {slot}: {fname} is not the certified kernel ({kind} hash {got} != {sha})")
            self.mods[name] = mod
            self.report[slot] = dict(file=fname, file_sha256=file_sha, certified_hash=sha, hash_kind=kind, record=rec,
                                     build_sha256=getattr(mod, "BUILD_SHA256", None), fp32_gpu_ieee=fp32_ieee)
        # precision policy
        if cfg.precision == "float32":
            if cfg.backend == "cupy" and not cfg.allow_fp32_ftz:
                bad = [s for s, r in self.report.items() if not r["fp32_gpu_ieee"] and s not in ("02 GYRO", "03 G2")]
                if bad: raise AdmissibilityError("FP32 on the GPU refused: these kernels still compile through cupy.RawModule (forced -ftz=true): "
                                                 + ", ".join(bad) + ".  Use FP64, or set allow_fp32_ftz=True (recorded in the manifest).")
            print("WARNING: FP32 state.  PRIM-01: FP32 keeps 3 digits of p only down to beta ~ 1e-4; watch PRIM flag-4 counts.")
        if cfg.gyro: raise AdmissibilityError("GYRO coupling is not defined in v4.0 (isotropic HLLD; needs anisotropic pressure evolution).")
        self.ieee_selftest = None
        if cfg.backend == "cupy":
            self.ieee_selftest = bool(self.mods["uct_emf_v02"].gpu_ieee_selftest())
            if not self.ieee_selftest: raise AdmissibilityError("GPU IEEE self-test failed (subnormal arithmetic): refusing to run")

    def kernels(self):
        m = self.mods
        return dict(PR=m["prim_v01"], H=m["hlld_v05"], RS=m["residual_v01"], E=m["uct_emf_v02"], GL=m["eglm_v02"], UC=m["uct_curl"], G2=m["g2_karnel_v01"])

    def environment(self):
        e = dict(python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform())
        try: e["gxx"] = subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
        except Exception as x: e["gxx"] = repr(x)
        if self.cfg.backend == "cupy":
            import cupy as cp
            e.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode(), cuda_runtime=cp.cuda.runtime.runtimeGetVersion())
        return e
