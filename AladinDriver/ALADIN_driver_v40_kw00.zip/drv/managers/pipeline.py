# -*- coding: utf-8 -*-
"""PIPELINE — one right-hand side of the equations, in the certified order (the kernel order is the physics):
  PRIM (01)  ->  HLLD-R (04), HLLD-phi (05), HLLD-Z (06)  ->  RESIDUAL (07, all geometric sources)
  ->  UCT-CURL (09, J, only if eta or hall)  ->  UCT-EMF (08, edge EMF; slot 11 CT + axis closure is applied by the integrator)
and the refusal flags of every slot: PRIM 1/2/8, HLLD 32 (per direction), RESIDUAL 1.  Well-balancing (W_eq, W_eq_faces,
R_eq) and the first-order recovery mask are passed through to HLLD / RESIDUAL here."""
import numpy as np
from .build_manager import HLLD_DIR
from .common import host


class Pipeline:
    def __init__(self, cfg, K, grids, boundary, xp):
        self.cfg = cfg; self.K = K; self.gm = grids; self.bm = boundary; self.xp = xp; self.bk = cfg.backend
        self.W_eq = self.W_eq_faces = self.R_eq = None

    def rhs(self, U, B, first_order=None):
        cfg, K, gm = self.cfg, self.K, self.gm
        pr = K["PR"].primitives(gm.GP, *U, *B, gamma=cfg.gamma, backend=self.bk)
        prims = [pr[k] for k in ("rho", "vr", "vphi", "vz", "p")]
        kw = {}
        if self.W_eq is not None: kw["W_eq"] = self.W_eq
        if self.W_eq_faces is not None: kw["W_eq_faces"] = self.W_eq_faces
        if first_order is not None: kw["first_order_cells"] = first_order
        F, fl = {}, {}
        for slot, k in HLLD_DIR.items():                                         # slots 04, 05, 06: one call per direction
            Fk, flk = K["H"].fluxes(gm.GH, *prims, *B, gamma=cfg.gamma, limiter=cfg.limiter, backend=self.bk, directions=(k,), **kw)
            F[k], fl[k] = Fk[k], flk[k]
        r = K["RS"].residual(gm.GR, F[0], F[1], F[2], *prims, *B, R_eq=self.R_eq, backend=self.bk)
        J = None
        if cfg.eta or cfg.hall:
            Bh = [np.asarray(host(x)) for x in B]; G = gm.GE
            Jl, _ = K["UC"].run_curl(*Bh, G.r_faces, G.r_centers, G.dr, G.dphi, G.dz, cfg.nr, cfg.nphi, cfg.nz, gm.g)
            J = [self.xp.ascontiguousarray(self.xp.asarray(x)) for x in Jl]; self.bm.fill_cells(J, vector=True)   # on the backend before the axis fill
        Em = K["E"].compute_emf(gm.GE, *B, prims[1], prims[2], prims[3], prims[0], prims[4], J=J, gamma=cfg.gamma, eta=cfg.eta,
                                hall=cfg.hall, limiter=cfg.limiter, backend=self.bk)
        bad = self.xp.zeros(gm.GP.shape("cell"), dtype=bool)
        bad |= (pr["flags"] & 11) > 0                                            # PRIM refusals 1, 2, 8 (ghosts included)
        bad[gm.I] |= r["flags"] == 1                                             # RESIDUAL refusal (incl. HLLD flag 32 via NaN fluxes)
        nref = dict(prim=int((pr["flags"] & 11).astype(bool).sum()), residual=int((r["flags"] == 1).sum()),
                    hlld=sum(int(((f & 32) > 0).sum()) for f in fl.values()),
                    hlld_by_slot={slot: int(((fl[k] & 32) > 0).sum()) for slot, k in HLLD_DIR.items()}, prim_unresolved=int(((pr["flags"] & 4) > 0).sum()))
        return dict(dU=r["dU"], EMF=Em, prims=prims, bad=bad, refused=nref)
