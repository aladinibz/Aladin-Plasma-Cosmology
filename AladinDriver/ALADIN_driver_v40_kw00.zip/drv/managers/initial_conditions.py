# -*- coding: utf-8 -*-
"""INITIAL CONDITIONS — each returns ic(driver) -> dict(U=[rho, m_r, m_phi, m_z, E], B=[Br, Bphi, Bz]) on the ghost-extended grid
(NumPy), optionally with the equilibrium for the well-balanced mode: U_eq, B_eq, prim_eq [rho, vr, vphi, vz, p] (exact),
W_eq_faces {0: (8, radial faces)} (exact face values for HLLD)."""
import numpy as np


def ic_zpinch(P0=1.0, perturb=None):
    """README normalised Z-pinch (mu0 = 1): rho = 1, v = 0, B_phi = r/2, J_z = 1, P = P0 - r^2/4, div B = 0.
    perturb(driver, rc, phc, zc) -> dp, an optional pressure perturbation added to E as dp / (gamma - 1)."""
    def ic(d):
        G = d.GE; g = G.g; sh = G.shape("cell"); rc = G.r_centers
        Bp = np.zeros(G.shape("Bphi")); Bp[:] = (0.5 * rc)[:, None, None]; B = [np.zeros(G.shape("Br")), Bp, np.zeros(G.shape("Bz"))]
        p = (P0 - 0.25 * rc ** 2)[:, None, None] * np.ones(sh); one = np.ones(sh); z0 = np.zeros(sh)
        Gp = d.PR.Grid(d.cfg.nr, d.cfg.nphi, d.cfg.nz, d.cfg.r_min, d.cfg.r_max, zlen=d.cfg.z_len, g=g)
        Ue = d.PR.conserved(Gp, one, z0, z0, z0, p, *B, gamma=d.cfg.gamma); U_eq = [Ue[k] for k in ("rho", "m_r", "m_phi", "m_z", "E")]
        U = [x.copy() for x in U_eq]
        if perturb is not None:
            dp = perturb(d, rc[:, None, None], G.phi_c[None, :, None], G.z_c[None, None, :]); U[4] = U[4] + dp / (d.cfg.gamma - 1)
        rfi = G.r_faces[g:g + d.cfg.nr + 1][:, None, None]; Wf = np.zeros(d.GH.shape("F_r"))
        Wf[0] = 1; Wf[4] = P0 - 0.25 * rfi ** 2; Wf[6] = 0.5 * rfi
        return dict(U=U, B=B, U_eq=U_eq, B_eq=[x.copy() for x in B], prim_eq=[one, z0, z0, z0, p], W_eq_faces={0: Wf})
    return ic
