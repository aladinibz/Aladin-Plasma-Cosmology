# -*- coding: utf-8 -*-
"""TIMESTEP MANAGER — the CFL time step:
  ideal MHD : dt = cfl / max over cells of max( (|vr|+cf)/dr , (|vphi|+cf)/(r_c dphi) , (|vz|+cf)/dz ),  cf = sqrt((gamma p + B^2)/rho)
              (cf bounds the fast speed in every direction; r_c dphi makes the cells next to the axis set the limit)
  resistive : dt <= cfl h^2 / (2 eta)            Hall : dt <= cfl h / v_w,  v_w = hall |B|max / rho_min * pi / h  (whistler at the grid scale)
  h = min(dr, r_c(first cell) dphi, dz);  dt <= dt_max.   Refuses a step that starts from an inadmissible state."""
import numpy as np
from .common import AdmissibilityError


class TimestepManager:
    def __init__(self, cfg, K, grids, xp):
        self.cfg = cfg; self.K = K; self.gm = grids; self.xp = xp; self.bk = cfg.backend

    def dt_cfl(self, U, B):
        cfg, xp, gm = self.cfg, self.xp, self.gm; I = gm.I; g = gm.g; G = gm.GE
        pr = self.K["PR"].primitives(gm.GP, *U, *B, gamma=cfg.gamma, backend=self.bk)
        if bool(((pr["flags"] & 11) > 0)[I].any()): raise AdmissibilityError("inadmissible state at the start of a step")
        bc = self.K["PR"].cell_B(gm.GP, *B); b2 = sum(x[I] ** 2 for x in bc); rho = pr["rho"][I]
        cf = xp.sqrt((cfg.gamma * pr["p"][I] + b2) / rho)
        rc = xp.asarray(G.r_centers[g:g + cfg.nr])[:, None, None]
        inv = xp.maximum(xp.maximum((xp.abs(pr["vr"][I]) + cf) / G.dr, (xp.abs(pr["vphi"][I]) + cf) / (rc * G.dphi)), (xp.abs(pr["vz"][I]) + cf) / G.dz)
        dt = cfg.cfl / float(inv.max())
        h = min(G.dr, float(G.r_centers[g]) * G.dphi, G.dz)
        if cfg.eta: dt = min(dt, cfg.cfl * h * h / (2 * cfg.eta))
        if cfg.hall:
            vw = cfg.hall * float(xp.sqrt(b2).max() / rho.min()) * np.pi / h
            dt = min(dt, cfg.cfl * h / vw)
        return min(dt, cfg.dt_max)
