# -*- coding: utf-8 -*-
"""KW-00: kernel-wise GPU vs CPU probe on the SMK-00 S6 (hot blob, recovery) and S7 (resistive + Hall) trajectories.
At every step of the CPU trajectory, every kernel is fed IDENTICAL inputs (the CPU's) on both backends, and its outputs are
compared bit for bit (NaN == NaN).  So a difference is pinned to ONE kernel, not to the chain.
  kernels: PRIM, HLLD-R/phi/Z (without and with the recovery first-order mask), RESIDUAL, UCT-CURL, UCT-EMF compute_emf, ct_update
  driver : dt_cfl on both backends;  lockstep: a CPU Driver and a GPU Driver advanced side by side, first step where they differ
  what-if: UCT-CURL compiled with -fmad=false (the kernel file is NOT modified; the probe only swaps the compiled kernel)
Note: uct_curl.run_curl uses the GPU whenever CuPy is installed, whatever the Driver backend.  The probe calls the NumPy path
(curl_numpy_flat) and the GPU path (launch_current_curl) explicitly.
Usage: python probe_kw00.py cupy      (python probe_kw00.py dry  = plumbing test without a GPU: both sides on the CPU, all diffs 0)"""
import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
import aladin_driver_v40 as D
from managers.integrator import _dilate
MODE = sys.argv[1] if len(sys.argv) > 1 else "cupy"
NSTEPS = int(sys.argv[2]) if len(sys.argv) > 2 else 30
DRY = MODE == "dry"
if DRY:
    xg = np; GB = "cpu"; G2H = lambda a: np.asarray(a)
else:
    import cupy as cp; xg = cp; GB = "cupy"; G2H = lambda a: cp.asnumpy(a)
H2G = lambda a: xg.ascontiguousarray(xg.asarray(a))
H = lambda a: np.asarray(D.host(a))

def cmp(c, g):
    """bitwise comparison (NaN == NaN) -> (identical, max |diff| over finite, n differing, first index, values)"""
    c = H(c); g = G2H(g) if not isinstance(g, np.ndarray) else g
    same = (c == g) | (np.isnan(c) & np.isnan(g)) if c.dtype.kind == "f" else (c == g)
    if same.all(): return dict(identical=True, max_abs=0.0, n=0)
    idx = tuple(int(v) for v in np.argwhere(~same)[0]); fin = ~same & np.isfinite(c) & np.isfinite(g)
    return dict(identical=False, max_abs=float(np.abs(c[fin] - g[fin]).max()) if fin.any() else float("nan"), n=int((~same).sum()),
                first=idx, cpu=repr(c[idx].item()), gpu=repr(g[idx].item()), nan_mismatch=int((~same & ~fin).sum()))

SUMMARY = {}
def note(traj, kernel, step, tag, r):
    s = SUMMARY.setdefault(traj, {}).setdefault(kernel, dict(calls=0, differ=0, max_abs=0.0, first=None))
    s["calls"] += 1
    if not r["identical"]:
        s["differ"] += 1
        if r["max_abs"] == r["max_abs"]: s["max_abs"] = max(s["max_abs"], r["max_abs"])
        if s["first"] is None: s["first"] = dict(step=step, tag=tag, **{k: v for k, v in r.items() if k != "identical"})

UC_FMADOFF = None
def curl_gpu(dg, B, fmad_off=False):
    UC = dg.UC; cfg = dg.cfg; G = dg.GE
    if DRY:
        J = [np.zeros(dg.GE.shape("cell")) for _ in range(3)]
        UC.curl_numpy_flat(*[H(x) for x in B], *J, G.r_faces, G.r_centers, G.dr, G.dphi, G.dz, cfg.nr, cfg.nphi, cfg.nz, dg.g); return J
    global UC_FMADOFF
    saved = dict(UC._kernels)
    if fmad_off:
        if UC_FMADOFF is None: UC_FMADOFF = cp.RawKernel(UC._KERNEL_SRC.replace("REAL_T", "double"), "current_curl_kernel", options=("-fmad=false",))
        UC._kernels["float64"] = UC_FMADOFF
    a = [cp.asarray(H(x)) for x in B] + [cp.asarray(G.r_faces), cp.asarray(G.r_centers)]
    J = [cp.zeros(dg.GE.shape("cell"), np.float64) for _ in range(3)]
    UC.launch_current_curl(a[0], a[1], a[2], *J, a[3], a[4], G.dr, G.dphi, G.dz, cfg.nr, cfg.nphi, cfg.nz, dg.g, True, True)
    UC._kernels.clear(); UC._kernels.update(saved)
    return J

def kernel_chain(traj, step, dc, dg, U, B, mask, tag):
    """CPU chain on (U, B); every GPU kernel gets the CPU's inputs"""
    cfg = dc.cfg; gm_c, gm_g = dc.grids, dg.grids
    pc = dc.PR.primitives(gm_c.GP, *U, *B, gamma=cfg.gamma, backend="cpu")
    pg = dg.PR.primitives(gm_g.GP, *map(H2G, U), *map(H2G, B), gamma=cfg.gamma, backend=GB)
    for k in ("rho", "vr", "vphi", "vz", "p", "flags"): note(traj, "01 PRIM", step, tag, cmp(pc[k], pg[k]))
    P = [pc[k] for k in ("rho", "vr", "vphi", "vz", "p")]; Pg = list(map(H2G, P)); Bg = list(map(H2G, B))
    kw_c = {} if mask is None else dict(first_order_cells=mask); kw_g = {} if mask is None else dict(first_order_cells=H2G(mask))
    if dc.pipeline.W_eq is not None:
        kw_c.update(W_eq=dc.pipeline.W_eq, W_eq_faces=dc.pipeline.W_eq_faces); kw_g.update(W_eq=dg.pipeline.W_eq, W_eq_faces=dg.pipeline.W_eq_faces)
    F = {}
    for slot, k in D.HLLD_DIR.items():
        Fc, flc = dc.H.fluxes(gm_c.GH, *P, *B, gamma=cfg.gamma, limiter=cfg.limiter, backend="cpu", directions=(k,), **kw_c)
        Fg, flg = dg.H.fluxes(gm_g.GH, *Pg, *Bg, gamma=cfg.gamma, limiter=cfg.limiter, backend=GB, directions=(k,), **kw_g)
        note(traj, slot + " flux" + (" [first-order mask]" if mask is not None else ""), step, tag, cmp(Fc[k], Fg[k]))
        note(traj, slot + " flags" + (" [first-order mask]" if mask is not None else ""), step, tag, cmp(flc[k], flg[k])); F[k] = Fc[k]
    rc = dc.RS.residual(gm_c.GR, F[0], F[1], F[2], *P, *B, R_eq=dc.pipeline.R_eq, backend="cpu")
    rg = dg.RS.residual(gm_g.GR, *[H2G(F[k]) for k in (0, 1, 2)], *Pg, *Bg, R_eq=dg.pipeline.R_eq, backend=GB)
    note(traj, "07 RESIDUAL dU", step, tag, cmp(rc["dU"], rg["dU"])); note(traj, "07 RESIDUAL flags", step, tag, cmp(rc["flags"], rg["flags"]))
    J = None
    if cfg.eta or cfg.hall:
        G = dc.GE; Jc = [np.zeros(G.shape("cell")) for _ in range(3)]
        dc.UC.curl_numpy_flat(*[H(x) for x in B], *Jc, G.r_faces, G.r_centers, G.dr, G.dphi, G.dz, cfg.nr, cfg.nphi, cfg.nz, dc.g)
        Jg = curl_gpu(dg, B); Jg0 = curl_gpu(dg, B, fmad_off=True)
        for i, n in enumerate(("Jr", "Jphi", "Jz")):
            note(traj, "09 UCT-CURL (as shipped)", step, tag, cmp(Jc[i], Jg[i])); note(traj, "09 UCT-CURL what-if -fmad=false", step, tag, cmp(Jc[i], Jg0[i]))
        dc.boundary.fill_cells(Jc, vector=True); J = Jc
    Ec = dc.E.compute_emf(gm_c.GE, *B, P[1], P[2], P[3], P[0], P[4], J=J, gamma=cfg.gamma, eta=cfg.eta, hall=cfg.hall, limiter=cfg.limiter, backend="cpu")
    Eg = dg.E.compute_emf(gm_g.GE, *Bg, Pg[1], Pg[2], Pg[3], Pg[0], Pg[4], J=None if J is None else list(map(H2G, J)), gamma=cfg.gamma, eta=cfg.eta,
                          hall=cfg.hall, limiter=cfg.limiter, backend=GB)
    for i, n in enumerate(("Er", "Ephi", "Ez")): note(traj, "08 UCT-EMF compute_emf", step, tag, cmp(Ec[i], Eg[i]))
    dt = 1e-3
    Bc2 = [np.ascontiguousarray(x.copy()) for x in B]; Bg2 = list(map(H2G, B))
    dc.E.ct_update(gm_c.GE, *Bc2, *Ec, dt, backend="cpu"); dg.E.ct_update(gm_g.GE, *Bg2, *map(H2G, Ec), dt, backend=GB)
    for i in range(3): note(traj, "11 ct_update + axis closure", step, tag, cmp(Bc2[i], Bg2[i]))

def trajectory(traj, cfg_kw, ic):
    dc = D.Driver(D.Config(backend="cpu", **cfg_kw), ic); dg = D.Driver(D.Config(backend=GB, **cfg_kw), ic)
    # the two Drivers must start from the same bits
    for i, (a, b) in enumerate(zip(dc.U + dc.B, dg.U + dg.B)): note(traj, "initial state", 0, "", cmp(a, b))
    ls = D.Driver(D.Config(backend=GB, **cfg_kw), ic); first_div = None
    for step in range(NSTEPS):
        U = [x.copy() for x in dc.U]; B = [np.ascontiguousarray(x.copy()) for x in dc.B]; dc.fill(U, B)
        note(traj, "driver dt_cfl", step, "", cmp(np.array(dc.dt_cfl(U, B)), np.array(dg.timestep.dt_cfl(list(map(H2G, U)), list(map(H2G, B))))))
        kernel_chain(traj, step, dc, dg, U, B, None, "no mask")
        # the recovery mask the Driver would build for this step (pass 1)
        _, _, bad, _ = dc.integrator.try_step(dc.U, dc.B, dc.dt_cfl(dc.U, dc.B), (dc.U0, dc.B0))
        if bool(bad.any()): kernel_chain(traj, step, dc, dg, U, B, _dilate(bad).astype(np.int32), "recovery mask")
        dc.advance(); ls.advance()
        if first_div is None:
            r = [cmp(a, b) for a, b in zip(dc.U + dc.B, ls.U + ls.B)]
            if not all(x["identical"] for x in r):
                first_div = dict(step=dc.step, arrays={n: x for n, x in zip(("rho", "m_r", "m_phi", "m_z", "E", "Br", "Bphi", "Bz"), r) if not x["identical"]})
    SUMMARY[traj]["LOCKSTEP Driver(cpu) vs Driver(gpu)"] = dict(first_divergence=first_div,
        note="on a CuPy machine the cpu Driver's UCT-CURL also runs on the GPU (run_curl picks the GPU whenever CuPy exists)")

def ic_blast(d):
    x = D.ic_zpinch()(d); G = d.GE; rc = G.r_centers[:, None, None]; zc = G.z_c[None, None, :]; ph = G.phi_c[None, :, None]
    xx, yy = rc * np.cos(ph) - 0.45, rc * np.sin(ph); hot = (xx ** 2 + yy ** 2 + (zc - 0.5) ** 2) < 0.15 ** 2
    p = np.where(hot, 200.0, 1e-3 + 0 * rc * np.ones(x["U"][0].shape))
    x["U"][4] = p / (2 / 3) + 0.5 * (0.5 * rc) ** 2 * np.ones_like(p); return x
bump = lambda d, rc, ph, zc: 0.01 * np.exp(-((rc - 0.4) ** 2) / 0.01) * np.cos(ph) * np.cos(2 * np.pi * zc)

trajectory("S6 hot blob + recovery", dict(cfl=0.4), ic_blast)
trajectory("S7 resistive + Hall", dict(eta=0.01, hall=0.02), D.ic_zpinch(perturb=bump))

print(f"\nKW-00 kernel-wise GPU vs CPU ({MODE}, {NSTEPS} steps per trajectory)")
for traj, ks in SUMMARY.items():
    print(f"\n== {traj}")
    for k, s in ks.items():
        if k.startswith("LOCKSTEP"): print(f"  {k}: first divergence = {s['first_divergence']}"); continue
        tagv = "IDENTICAL" if s["differ"] == 0 else f"DIFFERS in {s['differ']}/{s['calls']} calls, max |diff| {s['max_abs']:.3e}, first {s['first']}"
        print(f"  {k:44s} {tagv}")
json.dump(D.jsonable(SUMMARY), open(os.path.join(HERE, f"kw00_{MODE}.json"), "w"), indent=1, default=str)
