# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0 — the native-cylindrical GPU / CPU MHD Driver built around the eleven certified kernels.
Author: Mihai Alexandru Bucurenciu (ALADIN).  Successor of Aladin_Driver_v3.1_AIL (new numbered file: the numerical core is rebuilt;
the frame — config, experiment identity / manifest, checkpoints, health, rollback, diagnostics-only science — is kept).

This file is the CONDUCTOR: it reads the Config, asks the BuildManager for the certified kernels and wires the managers:
  managers/config.py               every setting                  managers/build_manager.py      kernel registry + hashes + precision
  managers/grid_manager.py         one grid for every kernel      managers/memory_manager.py     memory pools, fit check, peak usage
  managers/boundary_manager.py     all ghost fills                managers/pipeline.py           the kernel order (one RHS)
  managers/timestep_manager.py     CFL                            managers/integrator.py         SSP-RK3, transactional, recovery
  managers/diagnostics_manager.py  totals, div B, G2 (read-only)  managers/checkpoint_manager.py  bit-identical restart
  managers/initial_conditions.py   README Z-pinch (+ perturbed)   managers/bundle_manager.py     MakeReport bundles
Backends: backend="cpu" (NumPy + the kernels' C++ paths) or backend="cupy" (GPU).  Same code, same kernels, same bits (goal).

ADMISSIBLE BY DESIGN
  * every kernel is hash-checked against its certified Zenodo version before the run; a mismatch refuses to start;
  * the precision policy is enforced (FP64 default); the grid must fit in memory before the run starts;
  * every stage is checked (PRIM 1/2/8, HLLD 32, RESIDUAL 1, non-finite); a step is TRANSACTIONAL; recovery is local
    (first-order faces), then dt halving, then an explicit STOP — never a silent continue.

NOT COUPLED IN v4.0 (stated, not hidden)
  * GYRO (02): a gyrotropic closure; coupling needs anisotropic pressure evolution (HLLD v05.1 is isotropic).  Enabling it refuses.
  * Gravity and the v3.1 ScienceManager: re-attach later as their own managers.
  * Units: code units with mu0 = 1 (the README benchmark), declared in every manifest.
"""
import os, sys, json, hashlib
from dataclasses import asdict
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path: sys.path.insert(0, HERE)
KDIR = os.path.join(HERE, "kernels")
VERSION = "ALADIN Driver v4.0 2026-11-20"

from managers.common import AdmissibilityError, host, now, jsonable
from managers.config import Config
from managers.build_manager import BuildManager, REGISTRY, HLLD_DIR
from managers.grid_manager import GridManager
from managers.memory_manager import MemoryManager
from managers.boundary_manager import BoundaryManager
from managers.pipeline import Pipeline
from managers.timestep_manager import TimestepManager
from managers.integrator import Integrator
from managers.diagnostics_manager import DiagnosticsManager
from managers.checkpoint_manager import CheckpointManager
from managers.initial_conditions import ic_zpinch

_host, _jsonable, _now = host, jsonable, now            # names used by the tests and the bundle manager
MANAGER_FILES = ["common.py", "config.py", "build_manager.py", "grid_manager.py", "memory_manager.py", "boundary_manager.py", "pipeline.py",
                 "timestep_manager.py", "integrator.py", "diagnostics_manager.py", "checkpoint_manager.py", "initial_conditions.py", "bundle_manager.py"]
PIPELINE = "fill -> PRIM (01) -> HLLD-R (04) -> HLLD-phi (05) -> HLLD-Z (06) -> RESIDUAL (07) -> UCT-CURL (09, if eta/hall) -> UCT-EMF (08) -> update + CT + axis closure (11)"


def manager_hashes():
    d = os.path.join(HERE, "managers")
    return {f: hashlib.sha256(open(os.path.join(d, f), "rb").read()).hexdigest() for f in MANAGER_FILES if os.path.exists(os.path.join(d, f))}


class Driver:
    def __init__(self, cfg: Config, ic, kdir=KDIR, memory_limit_bytes=None):
        """ic(driver) -> initial state (see managers/initial_conditions.py)"""
        self.cfg = cfg
        self.build = BuildManager(cfg, kdir); K = self.build.kernels(); self.K = K
        self.PR, self.H, self.RS, self.E, self.GL, self.UC, self.G2 = K["PR"], K["H"], K["RS"], K["E"], K["GL"], K["UC"], K["G2"]
        self.bk = cfg.backend
        if self.bk == "cupy":
            import cupy as cp; self.xp = cp
        else:
            self.xp = np
        self.grids = GridManager(cfg, K, self.xp)
        gm = self.grids; self.GP, self.GH, self.GR, self.GE, self.GG = gm.GP, gm.GH, gm.GR, gm.GE, gm.GG; self.g = gm.g; self.axis = gm.axis
        self.memory = MemoryManager(cfg, limit_bytes=memory_limit_bytes); mem0 = self.memory.check_fits()
        self.boundary = BoundaryManager(cfg, gm, self.E)
        self.pipeline = Pipeline(cfg, K, gm, self.boundary, self.xp)
        self.timestep = TimestepManager(cfg, K, gm, self.xp)
        self.integrator = Integrator(cfg, K, gm, self.boundary, self.pipeline, self.timestep, self.xp)
        self.diagnostics = DiagnosticsManager(cfg, K, gm, self.xp)
        self.checkpoints = CheckpointManager(cfg, gm, self.xp)
        # initial state
        init = ic(self)
        T = lambda a: self.xp.asarray(np.ascontiguousarray(np.asarray(a, dtype=cfg.dtype)))
        self.U = [T(a) for a in init["U"]]; self.B = [T(a) for a in init["B"]]
        self.U0 = [x.copy() for x in self.U]; self.B0 = [x.copy() for x in self.B]          # held boundary state ("fixed")
        self.t = 0.0; self.step = 0; self.events = []; self.history = []; self.status = "CREATED"
        # well-balancing: the equilibrium seen by HLLD (W_eq, W_eq_faces) and its residual R_eq (same ghost fill)
        if cfg.well_balanced:
            Ue = [T(a) for a in init.get("U_eq", init["U"])]; Be = [T(a) for a in init.get("B_eq", init["B"])]
            if cfg.r_outer_bc == "wall": self.fill(Ue, Be)               # wall: the equilibrium seen by HLLD gets the SAME mirrored ghosts
            if "prim_eq" in init: pe = dict(zip(("rho", "vr", "vphi", "vz", "p"), [T(a) for a in init["prim_eq"]]))
            else: pe = self.PR.primitives(self.GP, *Ue, *Be, gamma=cfg.gamma, backend=self.bk)
            if cfg.r_outer_bc == "wall":
                pe = {k: v.copy() for k, v in pe.items()}
                self.boundary.mirror_wall([pe["rho"], pe["vr"], pe["vphi"], pe["vz"], pe["p"]], (1, -1, 1, 1, 1))
            self.pipeline.W_eq = self.H.pack(self.GH, pe["rho"], pe["vr"], pe["vphi"], pe["vz"], pe["p"], *Be)
            if "W_eq_faces" in init: self.pipeline.W_eq_faces = {k: T(v) for k, v in init["W_eq_faces"].items()}
            self.fill(Ue, Be); self.pipeline.R_eq = self.rhs(Ue, Be)["dU"]
            # well-balanced induction: the IDEAL edge EMF of the equilibrium (eta = hall = 0, same ghost fill).  For a static
            # equilibrium the physical -v x B is zero, so this is pure numerical dissipation; it is subtracted every stage.
            # Resistive and Hall EMFs are never subtracted (their action on the equilibrium is physics).
            pe2 = self.PR.primitives(self.GP, *Ue, *Be, gamma=cfg.gamma, backend=self.bk)
            self.pipeline.E_eq = tuple(self.E.compute_emf(self.GE, *Be, pe2["vr"], pe2["vphi"], pe2["vz"], pe2["rho"], pe2["p"], J=None, gamma=cfg.gamma,
                                                          eta=0.0, hall=0.0, limiter=cfg.limiter, backend=self.bk))
        self.fill(self.U, self.B)
        if cfg.eglm == "project_monitor":
            rep = self.GL.project(self.GG, *self.B, backend=self.bk); self.events.append(dict(step=0, event="eglm_project", report=jsonable(rep)))
            self.fill(self.U, self.B)
        self.manifest = dict(driver=VERSION, label=cfg.label, created=now(), config=asdict(cfg), kernels=self.build.report,
                             managers=manager_hashes(), environment=self.build.environment(), gpu_ieee_selftest=self.build.ieee_selftest,
                             memory=mem0, stage_pipeline=PIPELINE,
                             not_coupled=["GYRO (anisotropic coupling undefined)", "gravity", "v3.1 ScienceManager"])
        self.tot0 = self.totals()

    # ------------------------------------------------------------------ delegation (stable API for tests and bundles)
    def fill(self, U, B): self.boundary.fill(U, B, (self.U0, self.B0))
    def rhs(self, U, B): return self.pipeline.rhs(U, B, self.integrator.first_order)
    def dt_cfl(self, U, B): return self.timestep.dt_cfl(U, B)
    def advance(self, t_end=None, dt=None): return self.integrator.advance(self, t_end=t_end, dt=dt)
    def totals(self): return self.diagnostics.totals(self.U, self.B)
    def g2_diagnostics(self): return self.diagnostics.g2(self.U, self.B)
    def save(self, path): self.checkpoints.save(self, path)
    def load(self, path): self.checkpoints.load(self, path)

    def run(self, t_end=None, nsteps=None, monitor_every=1, checkpoint=None, on_step=None):
        self.status = "RUNNING"
        try:
            while (t_end is None or self.t < t_end - 1e-14) and (nsteps is None or self.step < nsteps):
                rec = self.advance(t_end=t_end)
                if monitor_every and self.step % monitor_every == 0:
                    rec.update(self.totals()); rec.update(self.memory.usage()); self.history.append(rec)
                if self.cfg.g2_interval and self.step % self.cfg.g2_interval == 0: rec["g2"] = self.g2_diagnostics()
                if on_step: on_step(self, rec)
                if checkpoint and self.step % checkpoint[0] == 0: self.save(checkpoint[1])
            self.status = "COMPLETED"
        except AdmissibilityError as x:
            self.status = "FAILED"; self.events.append(dict(step=self.step, t=self.t, event="FAILED", reason=str(x)))
        return self.status

    def write_manifest(self, path):
        m = dict(self.manifest); m.update(status=self.status, t=self.t, step=self.step, events=self.events, history=self.history[-2000:],
                                          totals0=self.tot0, totals=self.totals(), memory_peak=self.memory.usage(), finished=now())
        with open(path, "w") as f: json.dump(jsonable(m), f, indent=1, default=str)
        return m


if __name__ == "__main__":
    d = Driver(Config(well_balanced=True, label="README Z-pinch, static"), ic_zpinch())
    print(VERSION, "| kernels verified:", ", ".join(d.build.report))
    print(d.run(nsteps=20), d.history[-1])
