"""
uct_zp04_mini.py
VERSION: 2026-11-14-ZP04-energy-v2
Minimal explicit cylindrical evolution
Continuity + momentum + simple induction for B_phi
Takes vr = 1e-3 * sin(pi * r) perturbation
"""

import cupy as cp

_KERNEL_SRC = r"""
extern "C" __global__
void uct_jxb_kernel(
    const double* Jr, const double* Jth, const double* Jz,
    const double* Br, const double* Bth, const double* Bz,
    double* fr, double* fth, double* fz,
    int Nr, int Nth, int Nz
) {
    const int k = blockIdx.x * blockDim.x + threadIdx.x;
    const int j = blockIdx.y;
    const int i = blockIdx.z;
    if (i >= Nr || j >= Nth || k >= Nz) return;
    const int idx = i * (Nth * Nz) + j * Nz + k;
    double Jr_c = Jr[idx], Jth_c = Jth[idx], Jz_c = Jz[idx];
    double Br_c = Br[idx], Bth_c = Bth[idx], Bz_c = Bz[idx];
    if (i == 0) { Jr_c = 0.0; Br_c = 0.0; }
    fr[idx]  = Jth_c * Bz_c - Jz_c * Bth_c;
    fth[idx] = Jz_c * Br_c - Jr_c * Bz_c;
    fz[idx]  = Jr_c * Bth_c - Jth_c * Br_c;
}
"""
_jxb = cp.RawKernel(_KERNEL_SRC, "uct_jxb_kernel")
print("LOADED: ZP-04-v2-ENERGY")


def launch_jxb(Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz):
    Nr, Nth, Nz = Jr.shape
    _jxb(((Nz+255)//256, Nth, Nr), (256,1),
         (Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz,
          cp.int32(Nr), cp.int32(Nth), cp.int32(Nz)))


def run_zp04_v2(Nr=64, Nth=4, Nz=4, r_max=1.0, nsteps=300, dt=5e-5):
    print(f"ZP-04 perturbation run | {nsteps} steps | dt={dt}")
    dr = r_max / Nr
    r_faces = cp.arange(Nr+1, dtype=cp.float64)*dr
    r_centers = (cp.arange(Nr, dtype=cp.float64)+0.5)*dr
    shape = (Nr, Nth, Nz)

    # Equilibrium + perturbation
    rho = cp.ones(shape, dtype=cp.float64)
    vr = cp.zeros(shape, dtype=cp.float64)
    for i in range(Nr):
        vr[i] = 1e-3 * cp.sin(cp.pi * r_centers[i])
    vth = cp.zeros(shape, dtype=cp.float64)
    vz = cp.zeros(shape, dtype=cp.float64)

    Bth = cp.zeros(shape, dtype=cp.float64)
    for i in range(Nr):
        Bth[i] = 0.5 * float(r_centers[i])
    Br = Bz = cp.zeros(shape, dtype=cp.float64)

    # J from faces (recomputed if B changes, but simple for now)
    def update_J(Bth_arr):
        Jz = cp.zeros(shape, dtype=cp.float64)
        for i in range(Nr):
            # approximate using current Bth at centers for this mini version
            r_c = float(r_centers[i])
            # simple: keep analytic J=1 scaled, or recompute roughly
            Jz[i] = 1.0
        return Jz

    Jr = Jth = cp.zeros(shape, dtype=cp.float64)
    Jz = update_J(Bth)

    P0 = 1.0 - 0.25 * r_centers**2
    f_press_base = 0.5 * r_centers   # +0.5 r

    f_mag_r = cp.zeros(shape)
    f_mag_th = cp.zeros(shape)
    f_mag_z = cp.zeros(shape)

    hist_vr = []
    hist_rho = []
    hist_B = []
    hist_E = []

    # Initial energy (kinetic + magnetic + simple internal)
    def total_energy(rho, vr, Bth, r_centers):
        ke = 0.5 * rho * vr**2
        me = 0.5 * Bth**2          # magnetic
        # internal ~ P / (gamma-1), P from original profile scaled by rho
        ie = (1.0 - 0.25 * r_centers[:,None,None]**2) * rho / 0.4
        return float((ke + me + ie).mean())

    E0 = total_energy(rho, vr, Bth, r_centers)

    for step in range(nsteps):
        launch_jxb(Jr, Jth, Jz, Br, Bth, Bz, f_mag_r, f_mag_th, f_mag_z)
        f_press = f_press_base[:,None,None]
        f_tot_r = f_mag_r + f_press

        # Momentum
        vr += dt * f_tot_r / rho

        # Simple continuity (radial advection, very reduced)
        # rho_new = rho - dt * d(rho*vr)/dr   (axisym approx)
        flux = rho * vr
        drho = cp.zeros_like(rho)
        for i in range(1, Nr-1):
            drho[i] = -(flux[i+1] - flux[i-1]) / (2*dr)
        rho += dt * drho
        rho = cp.maximum(rho, 0.1)  # floor

        # Simple induction: B_phi stretched by compression (very reduced ideal)
        # dB/dt ~ -B * dvr/dr
        dvr_dr = cp.zeros(Nr)
        for i in range(1, Nr-1):
            dvr_dr[i] = (vr[i+1,0,0] - vr[i-1,0,0]) / (2*dr)
        for i in range(Nr):
            Bth[i] -= dt * Bth[i] * dvr_dr[i]

        if step % 50 == 0 or step == nsteps-1:
            hist_vr.append(float(cp.abs(vr).max()))
            hist_rho.append(float(cp.abs(rho-1).max()))
            hist_B.append(float(cp.abs(Bth - 0.5*r_centers[:,None,None]).max()))
            E = total_energy(rho, vr, Bth, r_centers)
            hist_E.append(E)

    print(f"final max|vr|     = {hist_vr[-1]:.3e}")
    print(f"final max|rho-1|  = {hist_rho[-1]:.3e}")
    print(f"final max|dB|     = {hist_B[-1]:.3e}")
    print(f"energy drift      = {hist_E[-1] - E0:.3e}")
    print(f"vr history: {hist_vr}")
    print(f"E  history: {hist_E}")
    return vr, rho, Bth, r_centers, hist_vr, hist_E
