"""
uct_zp07_volume.py
VERSION: 2026-11-14-ZP07
Volume-weighted cylindrical L2 on perturbation fields
Mini-pipeline
"""

import cupy as cp
from uct_zp04_mini import run_zp04_v2

def cell_volumes(Nr, r_max=1.0):
    dr = r_max / Nr
    r_faces = cp.arange(Nr + 1, dtype=cp.float64) * dr
    # V_i ∝ r_{i+1/2}^2 - r_{i-1/2}^2
    V = r_faces[1:]**2 - r_faces[:-1]**2
    return V, r_faces

def extract(Nr, nsteps, dt):
    vr, rho, Bth, r_centers, hist_vr, hist_E = run_zp04_v2(
        Nr=Nr, Nth=8, Nz=4, r_max=1.0, nsteps=nsteps, dt=dt
    )
    r = r_centers
    B0 = 0.5 * r
    dB   = (Bth[:,0,0] - B0).get()
    drho = (rho[:,0,0] - 1.0).get()
    dvr  = (vr[:,0,0] - 1e-3 * cp.sin(cp.pi * r)).get()
    V, _ = cell_volumes(Nr)
    return {
        "Nr": Nr,
        "dB": dB, "drho": drho, "dvr": dvr,
        "V": V.get(),
        "E0": hist_E[0], "Ef": hist_E[-1],
    }

def vol_weighted_l2(a, b, V):
    # volume-weighted RMS
    diff2 = (a - b)**2
    return float(cp.sqrt(cp.sum(diff2 * V) / cp.sum(V)))

def zp07():
    print("ZP-07 — VOLUME-WEIGHTED CYLINDRICAL NORMS")
    print("V_i ∝ r_right^2 - r_left^2\n")

    configs = [
        (32,  150, 1e-4),
        (64,  300, 5e-5),
        (128, 600, 2.5e-5),
        (256, 1200, 1.25e-5),
    ]
    results = [extract(*c) for c in configs]

    print("========== VOLUME-WEIGHTED L2 ON DELTAS ==========")
    for i in range(len(results)-1):
        c = results[i]
        f = results[i+1]
        ratio = f["Nr"] // c["Nr"]
        # volume-weighted restriction: average fine cells that map into each coarse cell
        def restrict(fine_arr):
            out = cp.zeros(c["Nr"])
            Vf = cp.asarray(f["V"])
            Vc = cp.asarray(c["V"])
            for ic in range(c["Nr"]):
                sl = slice(ic*ratio, (ic+1)*ratio)
                w = Vf[sl]
                out[ic] = cp.sum(cp.asarray(fine_arr[sl]) * w) / cp.sum(w)
            return out.get()

        dB_r   = restrict(f["dB"])
        drho_r = restrict(f["drho"])
        dvr_r  = restrict(f["dvr"])

        l2B   = vol_weighted_l2(cp.asarray(c["dB"]),   cp.asarray(dB_r),   cp.asarray(c["V"]))
        l2rho = vol_weighted_l2(cp.asarray(c["drho"]), cp.asarray(drho_r), cp.asarray(c["V"]))
        l2vr  = vol_weighted_l2(cp.asarray(c["dvr"]),  cp.asarray(dvr_r),  cp.asarray(c["V"]))

        # interior only (drop first and last cell)
        def interior_l2(a, b, V):
            return vol_weighted_l2(a[1:-1], b[1:-1], V[1:-1])

        iB   = interior_l2(cp.asarray(c["dB"]),   cp.asarray(dB_r),   cp.asarray(c["V"]))
        irho = interior_l2(cp.asarray(c["drho"]), cp.asarray(drho_r), cp.asarray(c["V"]))
        ivr  = interior_l2(cp.asarray(c["dvr"]),  cp.asarray(dvr_r),  cp.asarray(c["V"]))

        print(f"Nr {c['Nr']:>3} vs {f['Nr']:>3}:")
        print(f"  full     L2(dB)={l2B:.3e}  L2(drho)={l2rho:.3e}  L2(dvr)={l2vr:.3e}")
        print(f"  interior L2(dB)={iB:.3e}  L2(drho)={irho:.3e}  L2(dvr)={ivr:.3e}")

    print("\nEnergy still uses the same diagnostic mean (no Jacobian, no boundary flux).")
    return results

if __name__ == "__main__":
    zp07()
