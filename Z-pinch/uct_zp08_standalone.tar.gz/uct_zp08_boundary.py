"""
uct_zp08_boundary.py
VERSION: 2026-11-14-ZP08-standalone
Self-contained radial error distribution
"""

import cupy as cp

# ---- embedded mini evolution (same as ZP-04 v2) ----
_KERNEL_SRC = r"""
extern "C" __global__
void uct_jxb_kernel(
    const double* Jr, const double* Jth, const double* Jz,
    const double* Br, const double* Bth, const double* Bz,
    double* fr, double* fth, double* fz,
    int Nr, int Nth, int Nz
) {
    const int k = blockIdx.x * blockDim.x + threadIdx.x;
    const int j = blockIdx.y;
    const int i = blockIdx.z;
    if (i >= Nr || j >= Nth || k >= Nz) return;
    const int idx = i * (Nth * Nz) + j * Nz + k;
    double Jr_c = Jr[idx], Jth_c = Jth[idx], Jz_c = Jz[idx];
    double Br_c = Br[idx], Bth_c = Bth[idx], Bz_c = Bz[idx];
    if (i == 0) { Jr_c = 0.0; Br_c = 0.0; }
    fr[idx]  = Jth_c * Bz_c - Jz_c * Bth_c;
    fth[idx] = Jz_c * Br_c - Jr_c * Bz_c;
    fz[idx]  = Jr_c * Bth_c - Jth_c * Br_c;
}
"""
_jxb = cp.RawKernel(_KERNEL_SRC, "uct_jxb_kernel")

def launch_jxb(Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz):
    Nr, Nth, Nz = Jr.shape
    _jxb(((Nz+255)//256, Nth, Nr), (256,1),
         (Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz,
          cp.int32(Nr), cp.int32(Nth), cp.int32(Nz)))

def run_mini(Nr, nsteps, dt):
    dr = 1.0 / Nr
    r_faces = cp.arange(Nr+1, dtype=cp.float64)*dr
    r_centers = (cp.arange(Nr, dtype=cp.float64)+0.5)*dr
    shape = (Nr, 8, 4)
    rho = cp.ones(shape)
    vr = cp.zeros(shape)
    for i in range(Nr):
        vr[i] = 1e-3 * cp.sin(cp.pi * r_centers[i])
    Bth = cp.zeros(shape)
    for i in range(Nr):
        Bth[i] = 0.5 * float(r_centers[i])
    Br = Bz = Jr = Jth = cp.zeros(shape)
    Jz = cp.ones(shape)
    f_press = (0.5 * r_centers)[:,None,None]
    fmr = cp.zeros(shape); fmth = cp.zeros(shape); fmz = cp.zeros(shape)
    for step in range(nsteps):
        launch_jxb(Jr, Jth, Jz, Br, Bth, Bz, fmr, fmth, fmz)
        vr += dt * (fmr + f_press) / rho
        flux = rho * vr
        drho = cp.zeros_like(rho)
        for i in range(1, Nr-1):
            drho[i] = -(flux[i+1] - flux[i-1]) / (2*dr)
        rho += dt * drho
        rho = cp.maximum(rho, 0.1)
        dvr_dr = cp.zeros(Nr)
        for i in range(1, Nr-1):
            dvr_dr[i] = (vr[i+1,0,0] - vr[i-1,0,0]) / (2*dr)
        for i in range(Nr):
            Bth[i] -= dt * Bth[i] * dvr_dr[i]
    return vr, rho, Bth, r_centers

def cell_volumes(Nr):
    dr = 1.0 / Nr
    r_faces = cp.arange(Nr+1)*dr
    V = (r_faces[1:]**2 - r_faces[:-1]**2).get()
    return V

def zp08():
    print("ZP-08 STANDALONE — RADIAL ERROR MAP")
    configs = [(32,150,1e-4),(64,300,5e-5),(128,600,2.5e-5),(256,1200,1.25e-5)]
    results = []
    for Nr, ns, dt in configs:
        print(f"running Nr={Nr}...")
        vr, rho, Bth, rc = run_mini(Nr, ns, dt)
        dB = (Bth[:,0,0] - 0.5*rc).get()
        results.append({"Nr":Nr, "dB":dB, "V":cell_volumes(Nr)})

    print("\n========== ERROR BY REGION ==========")
    for i in range(len(results)-1):
        c = results[i]; f = results[i+1]
        ratio = f["Nr"]//c["Nr"]
        def restrict(arr):
            out = []
            for ic in range(c["Nr"]):
                sl = slice(ic*ratio,(ic+1)*ratio)
                w = f["V"][sl]
                out.append(float(cp.sum(cp.asarray(arr[sl])*cp.asarray(w))/cp.sum(w)))
            return cp.asarray(out)
        err = cp.abs(cp.asarray(c["dB"]) - restrict(f["dB"]))
        V = cp.asarray(c["V"])
        def wrms(mask):
            return float(cp.sqrt(cp.sum(err[mask]**2 * V[mask]) / cp.sum(V[mask]))) if cp.any(mask) else 0.0
        print(f"\nNr {c['Nr']} vs {f['Nr']}:")
        print(f"  first  = {wrms(cp.arange(c['Nr'])==0):.3e}")
        print(f"  last   = {wrms(cp.arange(c['Nr'])==c['Nr']-1):.3e}")
        print(f"  interior = {wrms((cp.arange(c['Nr'])>0)&(cp.arange(c['Nr'])<c['Nr']-1)):.3e}")
        for k in [1,2,4]:
            m = (cp.arange(c['Nr'])>=k)&(cp.arange(c['Nr'])<c['Nr']-k)
            print(f"  drop {k} = {wrms(m):.3e}")
    return results

if __name__ == "__main__":
    zp08()
