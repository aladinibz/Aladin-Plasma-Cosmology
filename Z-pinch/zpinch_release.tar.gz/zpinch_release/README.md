# Cylindrical HLLD Stack for Z-Pinch and Rotating-Disk MHD

## Title
Cylindrical HLLD Riemann Solver Stack for Z-Pinch and Rotating-Disk Experiments (ALADIN Plasma Drive)

## Description
A standalone, verified cylindrical HLLD (Harten–Lax–van Leer–Discontinuities) Riemann solver stack for ideal MHD on a staggered cylindrical mesh. The package provides three directional kernels (radial, azimuthal, axial), a finite-volume residual operator, and a complete verification suite covering force identity, sign coupling, independent current reconstruction, momentum closure, and rotating-disk evolution. Designed as a drop-in component for the ALADIN Plasma Drive and as a reproducible starting point for Z-pinch and magnetized-disk research.

## Overview
This deposit contains a pure CuPy RawKernel implementation of the Miyoshi–Kusano (2005) HLLD solver in explicit cylindrical geometry, together with the residual operator that differences the face fluxes onto cells and a twelve-test verification suite.

The stack has been checked for:
- Lorentz force identity \(f_{L,r} + J_z B_\phi = 0\)
- Reverse-current sign coupling (force remains inward under consistent reversal)
- Independent \(J_z\) reconstruction (core agreement ~\(10^{-7}\))
- Independent Lorentz force from the reconstructed current
- Exact radial momentum closure against the flux divergence
- Density-floor insensitivity of the core solution
- Axis regularity of the discrete current
- Rotating-disk evolution with centrifugal and Lorentz terms both active

Outer-boundary velocity growth is retained as a physical kinetic-energy channel and is optionally limited by a floor-density velocity cap for numerical safety.

## Files
| File | Content |
|------|---------|
| `hlld_x_kernel.py` | HLLD on radial faces |
| `hlld_y_kernel.py` | HLLD on azimuthal faces |
| `hlld_z_kernel.py` | HLLD on axial faces |
| `residual_cylindrical.py` | Finite-volume residual and velocity cap |
| `test_zpinch_full.py` | Individual verification routines |
| `test_suite.py` | Single entry point for the full suite |
| `README.md` | This document |

## Requirements
- Python 3.8+
- CuPy (CUDA)
- NVIDIA GPU (tested on Colab Pro A100)

## Quick start
```python
import test_suite
test_suite.run_all()
```

## Citation
If you use this stack, please cite the Zenodo record and the ALADIN Plasma Drive v2.1 release.

## License
Released for research use. See the ALADIN Plasma Drive repository for the full driver context.
