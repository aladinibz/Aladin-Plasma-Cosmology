"""
ALADIN — Z-pinch test with CFL, force balance, and extended diagnostics

Requires:
  hlld_x_kernel.py
  hlld_y_kernel.py
  hlld_z_kernel.py
  residual_cylindrical.py
"""

import numpy as np

try:
    import cupy as cp
    HAS_CUPY = True
except ImportError:
    cp = np
    HAS_CUPY = False

class Config:
    nr, nphi, nz = 48, 8, 8
    ghost_width = 2
    xp = cp if HAS_CUPY else np
    dtype = np.float32
    cfl = 0.3
    gamma = 5.0/3.0

class Geometry:
    def __init__(self, cfg):
        xp = cfg.xp
        g = cfg.ghost_width
        self.r_faces_phys = xp.linspace(0.0, 1.0, cfg.nr + 1, dtype=cfg.dtype)
        self.r_centers = 0.5 * (self.r_faces_phys[:-1] + self.r_faces_phys[1:])
        self.dr = self.r_faces_phys[1:] - self.r_faces_phys[:-1]
        self.dphi = xp.full(cfg.nphi, 2*np.pi / cfg.nphi, dtype=cfg.dtype)
        self.dz = xp.full(cfg.nz, 1.0 / cfg.nz, dtype=cfg.dtype)
        r_out = self.r_faces_phys[1:]
        r_in = self.r_faces_phys[:-1]
        self.cell_volumes = (0.5*(r_out**2 - r_in**2))[:, None, None] * \
                            self.dphi[None, :, None] * self.dz[None, None, :]
        self.area_r = self.r_faces_phys[:, None, None] * self.dphi[None, :, None] * self.dz[None, None, :]
        self.area_phi = (r_out - r_in)[:, None, None] * self.dz[None, None, :]
        self.area_z = 0.5*(r_out**2 - r_in**2)[:, None, None] * self.dphi[None, :, None] * xp.ones((1, 1, cfg.nz + 1), dtype=cfg.dtype)
        self.r_faces = xp.concatenate([
            xp.full(g, 0.0, dtype=cfg.dtype),
            self.r_faces_phys,
            xp.full(g, 1.0, dtype=cfg.dtype)
        ])

class State:
    def __init__(self, cfg, geometry):
        self.cfg = cfg
        xp = cfg.xp
        g = cfg.ghost_width
        nr, nphi, nz = cfg.nr, cfg.nphi, cfg.nz
        shape_c = (nr + 2*g, nphi + 2*g, nz + 2*g)
        shape_fr = (nr + 1 + 2*g, nphi + 2*g, nz + 2*g)
        shape_fp = (nr + 2*g, nphi + 1 + 2*g, nz + 2*g)
        shape_fz = (nr + 2*g, nphi + 2*g, nz + 1 + 2*g)
        self.fields = {
            "rho":      xp.ones(shape_c, dtype=cfg.dtype),
            "rho_vr":   xp.zeros(shape_c, dtype=cfg.dtype),
            "rho_vphi": xp.zeros(shape_c, dtype=cfg.dtype),
            "rho_vz":   xp.zeros(shape_c, dtype=cfg.dtype),
            "E":        xp.ones(shape_c, dtype=cfg.dtype) * 1.0,
            "Br":       xp.zeros(shape_fr, dtype=cfg.dtype),
            "Bphi":     xp.zeros(shape_c, dtype=cfg.dtype),
            "Bz":       xp.zeros(shape_c, dtype=cfg.dtype),
        }
        class _Grid:
            def interior_slice(self, centering="cell"):
                return (slice(g, -g), slice(g, -g), slice(g, -g))
        self.grid = _Grid()
        self._shapes = {"r": shape_fr, "phi": shape_fp, "z": shape_fz}

    def get(self, name):
        return self.fields[name]

def set_zpinch(state, geometry, cfg, B0=0.5, rho0=1.0, p0=0.1):
    xp = cfg.xp
    sl = state.grid.interior_slice()
    r = geometry.r_centers[:, None, None]
    rho = rho0 * xp.exp(-(r / 0.3)**2)
    state.get("rho")[sl] = rho
    Bphi = B0 * (r / 0.25) * xp.exp(-(r / 0.4)**2)
    state.get("Bphi")[sl] = Bphi
    state.get("E")[sl] = p0 / (cfg.gamma - 1.0) + 0.5 * Bphi**2

def cfl_dt(state, geometry, cfg):
    xp = cfg.xp
    sl = state.grid.interior_slice()
    rho = xp.maximum(state.get("rho")[sl], 1e-6)
    vr = state.get("rho_vr")[sl] / rho
    vphi = state.get("rho_vphi")[sl] / rho
    vz = state.get("rho_vz")[sl] / rho
    Bphi = state.get("Bphi")[sl]
    Bz = state.get("Bz")[sl]
    p = xp.maximum((cfg.gamma - 1.0) * (state.get("E")[sl] - 0.5*rho*(vr**2+vphi**2+vz**2) - 0.5*(Bphi**2+Bz**2)), 1e-8)
    cs2 = cfg.gamma * p / rho
    ca2 = (Bphi**2 + Bz**2) / rho
    cf = xp.sqrt(xp.maximum(cs2 + ca2, 0.0))
    speed = xp.abs(vr) + cf
    dr = geometry.dr[:, None, None]
    dt_local = cfg.cfl * dr / xp.maximum(speed, 1e-6)
    return float(xp.min(dt_local))

def diagnostics(state, geometry, cfg):
    """Four requested measurements + radial momentum residual."""
    xp = cfg.xp
    sl = state.grid.interior_slice()
    r = geometry.r_centers
    rho = state.get("rho")[sl]
    vr  = state.get("rho_vr")[sl] / xp.maximum(rho, 1e-12)
    vphi = state.get("rho_vphi")[sl] / xp.maximum(rho, 1e-12)
    Bphi = state.get("Bphi")[sl]
    Bz   = state.get("Bz")[sl]
    # pressure from energy (thermal part)
    ke = 0.5 * rho * (vr**2 + vphi**2 + state.get("rho_vz")[sl]**2 / xp.maximum(rho, 1e-12)**2)
    be = 0.5 * (Bphi**2 + Bz**2)
    p = xp.maximum((cfg.gamma - 1.0) * (state.get("E")[sl] - ke - be), 0.0)

    # 1. rho_min with cell index
    rho_flat = rho.ravel()
    idx = int(xp.argmin(rho_flat))
    ir = idx // (cfg.nphi * cfg.nz)
    print(f"ρ_min = {float(rho_flat[idx]):.3e}  at ir={ir}  r={float(r[ir]):.3f}")

    # 2. p_min, p_max
    print(f"p_min = {float(xp.min(p)):.3e}   p_max = {float(xp.max(p)):.3e}")

    # 3. vphi_max, vr_max with locations
    def extremum(arr, name):
        flat = arr.ravel()
        i = int(xp.argmax(xp.abs(flat)))
        ir_ = i // (cfg.nphi * cfg.nz)
        print(f"{name}_max = {float(flat[i]):+.3e}  at ir={ir_}  r={float(r[ir_]):.3f}")
    extremum(vr, "vr")
    extremum(vphi, "vphi")

    # 4. Bφ, Jz, full f_L,r versus radius (mid-plane)
    # Jz ≈ (1/r) d(r Bφ)/dr   (axisymmetric)
    rB = r * Bphi[:, 0, 0]
    d_rB_dr = xp.gradient(rB, r)
    Jz = d_rB_dr / (r + 1e-6)
    # full radial Lorentz: (J × B)_r ≈ Jz * Bφ - Jφ * Bz
    # Jφ ≈ -dBz/dr (approx)
    dBz_dr = xp.gradient(Bz[:, 0, 0], r)
    Jphi = -dBz_dr
    f_Lr = -Jz * Bphi[:, 0, 0] + Jphi * Bz[:, 0, 0]

    print("\n  r     Bφ       Jz        f_L,r     |f + Jz Bφ| / |Jz Bφ|")
    for i in range(0, cfg.nr, 6):
        jz_b = float(Jz[i] * Bphi[i, 0, 0])
        fl = float(f_Lr[i])
        rel = abs(fl + jz_b) / (abs(jz_b) + 1e-12)
        print(f"  {float(r[i]):.2f}  {float(Bphi[i,0,0]):+.3e}  {float(Jz[i]):+.3e}  "
              f"{fl:+.3e}  {rel:.2e}")

    # Radial momentum residual (mid-plane)
    # ∂(ρ vr)/∂t ≈ -∇·(ρ vr v) - ∂p/∂r + (ρ vφ²)/r + (J×B)_r + ρ g_r
    # Here g_r = 0 (no gravity in this test)
    rho_m = rho[:, 0, 0]
    vr_m  = vr[:, 0, 0]
    vphi_m = vphi[:, 0, 0]
    p_m = p[:, 0, 0]
    dp_dr = xp.gradient(p_m, r)
    cent = rho_m * vphi_m**2 / (r + 1e-6)
    # inertial term rough: ρ vr² / r
    inert = rho_m * vr_m**2 / (r + 1e-6)
    residual = -dp_dr + cent + f_Lr - inert
    print("\n=== RADIAL MOMENTUM RESIDUAL (mid-plane, g=0) ===")
    print("  r     -dp/dr    ρvφ²/r    f_L,r    -ρvr²/r    residual")
    for i in range(0, cfg.nr, 6):
        print(f"  {float(r[i]):.2f}  {float(-dp_dr[i]):+.2e}  {float(cent[i]):+.2e}  "
              f"{float(f_Lr[i]):+.2e}  {float(-inert[i]):+.2e}  {float(residual[i]):+.2e}")

def run_zpinch_full(nsteps=20):
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_zpinch(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    print("=== Z-PINCH TEST (HLLD x/y/z + CFL + diagnostics) ===")
    print(f"grid: {cfg.nr}x{cfg.nphi}x{cfg.nz}  B0=0.5  cfl={cfg.cfl}")

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    for step in range(nsteps):
        sanitize()
        dt = cfl_dt(state, geom, cfg)
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])
        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()
        if step % 5 == 0 or step == nsteps-1:
            print(f"  step {step:3d}  dt={dt:.3e}")

    print("\n=== DIAGNOSTICS ===")
    diagnostics(state, geom, cfg)
    print("Done.")

def run_floor_sensitivity(floors=(1e-8, 1e-6, 1e-4), nsteps=10):
    """Rerun with different density floors and report core response."""
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== DENSITY-FLOOR SENSITIVITY ===")
    print(f"{'floor':>10}  {'core f_L,r':>12}  {'core vr':>12}  {'ρ_min':>10}")
    for floor in floors:
        cfg = Config()
        geom = Geometry(cfg)
        state = State(cfg, geom)
        set_zpinch(state, geom, cfg)

        keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
        fluxes = {
            "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
            "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
            "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
        }

        def sanitize(fl=floor):
            xp = cfg.xp
            for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
                if name in state.fields:
                    arr = state.get(name)
                    arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
            state.get("rho")[:] = xp.maximum(state.get("rho"), fl)

        for step in range(nsteps):
            sanitize()
            dt = cfl_dt(state, geom, cfg)
            launch_hlld_x(state, geom, cfg, fluxes["r"])
            launch_hlld_y(state, cfg, fluxes["phi"])
            launch_hlld_z(state, cfg, fluxes["z"])
            residual_cylindrical(state, geom, cfg, fluxes, dt)
            sanitize()

        # core diagnostics (r ~ 0.26)
        sl = state.grid.interior_slice()
        r = geom.r_centers
        ir = int(np.argmin(np.abs(r - 0.26)))
        rho = state.get("rho")[sl]
        Bphi = state.get("Bphi")[sl]
        vr = state.get("rho_vr")[sl] / cfg.xp.maximum(rho, 1e-12)
        rB = r * Bphi[:, 0, 0]
        Jz = cfg.xp.gradient(rB, r) / (r + 1e-6)
        f_Lr = -Jz * Bphi[:, 0, 0]
        print(f"{floor:10.1e}  {float(f_Lr[ir]):+12.3e}  {float(vr[ir,0,0]):+12.3e}  "
              f"{float(cfg.xp.min(rho)):10.3e}")


def run_reverse_current(nsteps=5):
    """
    Sign-and-coupling test.
    1. Flip Bφ (and therefore Jz) → force should stay inward.
    2. Flip only Bφ sign in the force formula → force should reverse.
    """
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== REVERSE-CURRENT TEST ===")

    def run_case(flip_B=False, label=""):
        cfg = Config()
        geom = Geometry(cfg)
        state = State(cfg, geom)
        set_zpinch(state, geom, cfg)
        if flip_B:
            state.get("Bphi")[:] *= -1.0

        keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
        fluxes = {
            "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
            "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
            "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
        }

        def sanitize():
            xp = cfg.xp
            for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
                if name in state.fields:
                    arr = state.get(name)
                    arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
            state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

        for step in range(nsteps):
            sanitize()
            dt = cfl_dt(state, geom, cfg)
            launch_hlld_x(state, geom, cfg, fluxes["r"])
            launch_hlld_y(state, cfg, fluxes["phi"])
            launch_hlld_z(state, cfg, fluxes["z"])
            residual_cylindrical(state, geom, cfg, fluxes, dt)
            sanitize()

        sl = state.grid.interior_slice()
        r = geom.r_centers
        ir = int(np.argmin(np.abs(r - 0.26)))
        Bphi = state.get("Bphi")[sl]
        rB = r * Bphi[:, 0, 0]
        Jz = cfg.xp.gradient(rB, r) / (r + 1e-6)
        f_Lr = -Jz * Bphi[:, 0, 0]
        return float(f_Lr[ir]), float(Bphi[ir, 0, 0]), float(Jz[ir])

    # Case A: normal
    fA, bA, jA = run_case(flip_B=False)
    # Case B: flipped Bφ (Jz flips with it)
    fB, bB, jB = run_case(flip_B=True)

    print(f"  normal:   Bφ={bA:+.3e}  Jz={jA:+.3e}  f_L,r={fA:+.3e}")
    print(f"  flipped:  Bφ={bB:+.3e}  Jz={jB:+.3e}  f_L,r={fB:+.3e}")

    # Both should be inward (negative) if the pinch is consistent
    inward_ok = (fA < 0) and (fB < 0)
    print(f"  both inward: {inward_ok}")

    # Manual one-sided flip: take normal Jz and flipped Bφ in the formula
    f_one_sided = -jA * bB
    print(f"  one-sided (Jz_normal * Bφ_flipped): f={f_one_sided:+.3e}")
    print(f"  one-sided reversed relative to normal: {f_one_sided * fA < 0}")


def run_independent_jz(nsteps=5):
    """
    Compare two Jz reconstructions:
      - staggered-style: (1/r) d(r Bφ)/dr on the existing mid-plane array
      - cell-centered: same derivative but from a fresh centered difference
    They should agree in the core if the discrete operator is consistent.
    """
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== INDEPENDENT Jz RECONSTRUCTION ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_zpinch(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    for step in range(nsteps):
        sanitize()
        dt = cfl_dt(state, geom, cfg)
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])
        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()

    sl = state.grid.interior_slice()
    r = geom.r_centers
    Bphi = state.get("Bphi")[sl][:, 0, 0]
    xp = cfg.xp

    # Method A: existing diagnostic style
    rB = r * Bphi
    Jz_A = xp.gradient(rB, r) / (r + 1e-6)

    # Method B: independent centered difference
    Jz_B = xp.zeros_like(Bphi)
    dr = geom.dr
    for i in range(1, cfg.nr - 1):
        rB_p = r[i+1] * Bphi[i+1]
        rB_m = r[i-1] * Bphi[i-1]
        Jz_B[i] = (rB_p - rB_m) / ((r[i+1] - r[i-1]) * (r[i] + 1e-6))

    print("  r     Jz_grad    Jz_centered   rel_err")
    for i in range(0, cfg.nr, 6):
        a = float(Jz_A[i])
        b = float(Jz_B[i])
        rel = abs(a - b) / (abs(a) + 1e-12)
        print(f"  {float(r[i]):.2f}  {a:+.3e}  {b:+.3e}  {rel:.2e}")

    # core agreement
    ir = int(np.argmin(np.abs(r - 0.26)))
    core_rel = abs(float(Jz_A[ir]) - float(Jz_B[ir])) / (abs(float(Jz_A[ir])) + 1e-12)
    print(f"  core relative error: {core_rel:.2e}")


def run_axis_regularity():
    """
    Reconstruct Jz at and near the axis using the analytical limit.
    For Bφ ~ r near r=0, Jz → 2 dBφ/dr |_{r=0}.
    """
    print("\n=== AXIS REGULARITY ===")
    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_zpinch(state, geom, cfg)

    sl = state.grid.interior_slice()
    r = geom.r_centers
    Bphi = state.get("Bphi")[sl][:, 0, 0]
    xp = cfg.xp

    # analytical limit: Jz(0) = 2 * dBφ/dr at r=0
    # use first two cells
    dB_dr_0 = (Bphi[1] - Bphi[0]) / (r[1] - r[0])
    Jz_analytic = 2.0 * dB_dr_0

    # discrete near-axis
    rB = r * Bphi
    Jz_disc = xp.gradient(rB, r) / (r + 1e-6)

    print(f"  Jz analytic (r→0) = {float(Jz_analytic):+.3e}")
    print(f"  Jz discrete (r=0.01) = {float(Jz_disc[0]):+.3e}")
    print(f"  Jz discrete (r=0.03) = {float(Jz_disc[1]):+.3e}")
    rel = abs(float(Jz_disc[1]) - float(Jz_analytic)) / (abs(float(Jz_analytic)) + 1e-12)
    print(f"  near-axis relative error: {rel:.2e}")


def run_independent_lorentz(nsteps=5):
    """
    Compute J×B from the independently reconstructed Jz,
    without using the production force path.
    """
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== INDEPENDENT LORENTZ FORCE ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_zpinch(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    for step in range(nsteps):
        sanitize()
        dt = cfl_dt(state, geom, cfg)
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])
        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()

    sl = state.grid.interior_slice()
    r = geom.r_centers
    Bphi = state.get("Bphi")[sl][:, 0, 0]
    xp = cfg.xp

    # independent Jz (centered)
    Jz = xp.zeros_like(Bphi)
    for i in range(1, cfg.nr - 1):
        rB_p = r[i+1] * Bphi[i+1]
        rB_m = r[i-1] * Bphi[i-1]
        Jz[i] = (rB_p - rB_m) / ((r[i+1] - r[i-1]) * (r[i] + 1e-6))

    # independent Lorentz: f_r = -Jz * Bφ
    f_indep = -Jz * Bphi

    # production-style (gradient)
    rB = r * Bphi
    Jz_prod = xp.gradient(rB, r) / (r + 1e-6)
    f_prod = -Jz_prod * Bphi

    print("  r     f_indep     f_prod      rel_err")
    for i in range(6, cfg.nr, 6):
        a = float(f_indep[i])
        b = float(f_prod[i])
        rel = abs(a - b) / (abs(b) + 1e-12)
        print(f"  {float(r[i]):.2f}  {a:+.3e}  {b:+.3e}  {rel:.2e}")

    ir = int(np.argmin(np.abs(r - 0.26)))
    core_rel = abs(float(f_indep[ir]) - float(f_prod[ir])) / (abs(float(f_prod[ir])) + 1e-12)
    print(f"  core relative error: {core_rel:.2e}")


def run_momentum_closure(nsteps=5):
    """
    Compare the actual conservative momentum update
    against the complete radial force budget.
    """
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== MOMENTUM CLOSURE ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_zpinch(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    sl = state.grid.interior_slice()
    r = geom.r_centers
    xp = cfg.xp

    # snapshot before
    sanitize()
    rho_vr_before = state.get("rho_vr")[sl].copy()

    dt = cfl_dt(state, geom, cfg)
    launch_hlld_x(state, geom, cfg, fluxes["r"])
    launch_hlld_y(state, cfg, fluxes["phi"])
    launch_hlld_z(state, cfg, fluxes["z"])
    residual_cylindrical(state, geom, cfg, fluxes, dt)
    sanitize()

    # actual update
    rho_vr_after = state.get("rho_vr")[sl]
    d_rho_vr = (rho_vr_after - rho_vr_before) / dt

    # force budget (mid-plane)
    rho = xp.maximum(state.get("rho")[sl][:, 0, 0], 1e-6)
    Bphi = state.get("Bphi")[sl][:, 0, 0]
    p = xp.maximum((cfg.gamma - 1.0) * state.get("E")[sl][:, 0, 0], 0.0)
    dp_dr = xp.gradient(p, r)
    rB = r * Bphi
    Jz = xp.gradient(rB, r) / (r + 1e-6)
    f_Lr = -Jz * Bphi
    # budget: d(ρ vr)/dt ≈ -dp/dr + f_L,r   (no rotation, no gravity)
    budget = -dp_dr + f_Lr

    print("  r     Δ(ρ vr)/dt   force budget   rel_err")
    for i in range(6, cfg.nr, 6):
        a = float(d_rho_vr[i, 0, 0])
        b = float(budget[i])
        rel = abs(a - b) / (abs(b) + 1e-12)
        print(f"  {float(r[i]):.2f}  {a:+.3e}  {b:+.3e}  {rel:.2e}")

    ir = int(np.argmin(np.abs(r - 0.26)))
    core_rel = abs(float(d_rho_vr[ir, 0, 0]) - float(budget[ir])) / (abs(float(budget[ir])) + 1e-12)
    print(f"  core relative error: {core_rel:.2e}")


def set_disk(state, geometry, cfg, B0=0.3, rho0=1.0, p0=0.05, vphi0=0.4):
    """
    Rotating disk + toroidal field.
    Density falls with radius, vφ provides centrifugal support,
    Bφ provides Lorentz force.
    """
    xp = cfg.xp
    sl = state.grid.interior_slice()
    r = geometry.r_centers[:, None, None]
    # disk-like density
    rho = rho0 * xp.exp(-(r / 0.4)**2)
    state.get("rho")[sl] = rho
    # rotation (flat-ish)
    vphi = vphi0 * xp.ones_like(r)
    state.get("rho_vphi")[sl] = rho * vphi
    # toroidal field
    Bphi = B0 * (r / 0.3) * xp.exp(-(r / 0.5)**2)
    state.get("Bphi")[sl] = Bphi
    # energy
    state.get("E")[sl] = p0 / (cfg.gamma - 1.0) + 0.5 * rho * vphi**2 + 0.5 * Bphi**2


def run_disk_test(nsteps=15):
    """Z-pinch stack on a rotating disk."""
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== DISK + Z-PINCH TEST ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_disk(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    for step in range(nsteps):
        sanitize()
        apply_outer_ghost(state, cfg)
        dt = cfl_dt(state, geom, cfg)
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])
        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()
        if step % 5 == 0 or step == nsteps - 1:
            print(f"  step {step:3d}  dt={dt:.3e}")

    # force balance on the disk
    sl = state.grid.interior_slice()
    r = geom.r_centers
    xp = cfg.xp
    rho = xp.maximum(state.get("rho")[sl][:, 0, 0], 1e-6)
    vr = state.get("rho_vr")[sl][:, 0, 0] / rho
    vphi = state.get("rho_vphi")[sl][:, 0, 0] / rho
    Bphi = state.get("Bphi")[sl][:, 0, 0]
    p = xp.maximum((cfg.gamma - 1.0) * state.get("E")[sl][:, 0, 0], 0.0)
    dp_dr = xp.gradient(p, r)
    rB = r * Bphi
    Jz = xp.gradient(rB, r) / (r + 1e-6)
    f_Lr = -Jz * Bphi
    cent = rho * vphi**2 / (r + 1e-6)

    print("\n  r     ρ      vr       vφ       cent      f_L,r     -dp/dr")
    for i in range(0, cfg.nr, 6):
        print(f"  {float(r[i]):.2f}  {float(rho[i]):.3f}  {float(vr[i]):+.2e}  "
              f"{float(vphi[i]):.3f}  {float(cent[i]):+.2e}  {float(f_Lr[i]):+.2e}  "
              f"{float(-dp_dr[i]):+.2e}")
    print("Done.")


def run_cfl_decomposition(nsteps=10):
    """Print the cell and speeds that set the CFL timestep."""
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== CFL DECOMPOSITION ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_disk(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    xp = cfg.xp
    sl = state.grid.interior_slice()
    r = geom.r_centers

    for step in range(nsteps):
        sanitize()
        rho = xp.maximum(state.get("rho")[sl], 1e-6)
        vr = state.get("rho_vr")[sl] / rho
        Bphi = state.get("Bphi")[sl]
        Bz = state.get("Bz")[sl]
        p = xp.maximum((cfg.gamma - 1.0) * state.get("E")[sl], 1e-8)
        cs2 = cfg.gamma * p / rho
        ca2 = (Bphi**2 + Bz**2) / rho
        cf = xp.sqrt(xp.maximum(cs2 + ca2, 0.0))
        speed = xp.abs(vr) + cf
        dr = geom.dr[:, None, None]
        dt_local = cfg.cfl * dr / xp.maximum(speed, 1e-6)
        # find limiting cell
        flat = dt_local.ravel()
        idx = int(xp.argmin(flat))
        ir = idx // (cfg.nphi * cfg.nz)
        print(f"  step {step:2d}  dt={float(flat[idx]):.3e}  "
              f"r={float(r[ir]):.3f}  ρ={float(rho.ravel()[idx]):.3e}  "
              f"|vr|={float(xp.abs(vr).ravel()[idx]):.3e}  cf={float(cf.ravel()[idx]):.3e}")

        dt = float(flat[idx])
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])
        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()


def run_outer_disk_inspection(nsteps=10):
    """Full radial profiles near the outer edge."""
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== OUTER-DISK INSPECTION ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_disk(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    for step in range(nsteps):
        sanitize()
        dt = cfl_dt(state, geom, cfg)
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])
        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()

    sl = state.grid.interior_slice()
    r = geom.r_centers
    xp = cfg.xp
    rho = xp.maximum(state.get("rho")[sl][:, 0, 0], 1e-6)
    vr = state.get("rho_vr")[sl][:, 0, 0] / rho
    vphi = state.get("rho_vphi")[sl][:, 0, 0] / rho
    Bphi = state.get("Bphi")[sl][:, 0, 0]
    rB = r * Bphi
    Jz = xp.gradient(rB, r) / (r + 1e-6)

    print("  r     ρ        vr        vφ       Bφ        Jz")
    for i in range(cfg.nr - 12, cfg.nr):
        print(f"  {float(r[i]):.3f}  {float(rho[i]):.3e}  {float(vr[i]):+.2e}  "
              f"{float(vphi[i]):+.3f}  {float(Bphi[i]):+.3e}  {float(Jz[i]):+.3e}")


def run_full_momentum_closure(nsteps=3):
    """
    Compare actual Δ(ρ vr) against flux divergence + geometric sources.
    """
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== FULL MOMENTUM CLOSURE ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_disk(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    sl = state.grid.interior_slice()
    r = geom.r_centers
    xp = cfg.xp
    g = cfg.ghost_width

    sanitize()
    rho_vr_before = state.get("rho_vr")[sl].copy()

    dt = cfl_dt(state, geom, cfg)
    launch_hlld_x(state, geom, cfg, fluxes["r"])
    launch_hlld_y(state, cfg, fluxes["phi"])
    launch_hlld_z(state, cfg, fluxes["z"])

    # flux divergence contribution (radial only, mid-plane)
    f = fluxes["r"]["vr"][g:-g, g:-g, g:-g]
    A = geom.area_r
    vol = geom.cell_volumes
    flux_div = (f[1:] * A[1:] - f[:-1] * A[:-1]) / vol
    flux_div_mid = flux_div[:, 0, 0]

    residual_cylindrical(state, geom, cfg, fluxes, dt)
    sanitize()

    rho_vr_after = state.get("rho_vr")[sl]
    d_rho_vr = (rho_vr_after - rho_vr_before)[:, 0, 0] / dt

    # Correct budget: the residual only differences the flux.
    # Pressure and Lorentz are already inside the HLLD flux.
    # Geometric source is not applied in this test.
    budget = -flux_div_mid

    print("  r     Δ(ρ vr)/dt   -flux_div     rel_err")
    for i in range(6, cfg.nr, 6):
        a = float(d_rho_vr[i])
        b = float(budget[i])
        rel = abs(a - b) / (abs(b) + 1e-12)
        print(f"  {float(r[i]):.2f}  {a:+.3e}  {b:+.3e}  {rel:.2e}")

    ir = int(np.argmin(np.abs(r - 0.26)))
    core_rel = abs(float(d_rho_vr[ir]) - float(budget[ir])) / (abs(float(budget[ir])) + 1e-12)
    print(f"  core relative error: {core_rel:.2e}")


def apply_outer_ghost(state, cfg):
    """Zero-gradient outer radial ghost: copy last real cell into ghosts."""
    g = cfg.ghost_width
    nr = cfg.nr
    # last real radial index in ghosted array
    i_last = g + nr - 1
    for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
        if name in state.fields:
            arr = state.get(name)
            for offset in range(1, g + 1):
                arr[i_last + offset, :, :] = arr[i_last, :, :]


def run_extreme_cell_instrumentation(nsteps=6):
    """
    Find the cell with extreme vr and print the left/right states
    and HLLD flux at the radial face that feeds it.
    """
    from hlld_x_kernel import launch_hlld_x
    from hlld_y_kernel import launch_hlld_y
    from hlld_z_kernel import launch_hlld_z
    from residual_cylindrical import residual_cylindrical

    print("\n=== EXTREME CELL INSTRUMENTATION ===")

    cfg = Config()
    geom = Geometry(cfg)
    state = State(cfg, geom)
    set_disk(state, geom, cfg)

    keys = ["rho", "vr", "vphi", "vz", "E", "Bphi", "Bz", "Br"]
    fluxes = {
        "r":   {k: cfg.xp.zeros(state._shapes["r"],   dtype=cfg.dtype) for k in keys},
        "phi": {k: cfg.xp.zeros(state._shapes["phi"], dtype=cfg.dtype) for k in keys},
        "z":   {k: cfg.xp.zeros(state._shapes["z"],   dtype=cfg.dtype) for k in keys},
    }

    def sanitize():
        xp = cfg.xp
        for name in ("rho", "rho_vr", "rho_vphi", "rho_vz", "E", "Bphi", "Bz"):
            if name in state.fields:
                arr = state.get(name)
                arr[:] = xp.where(xp.isfinite(arr), arr, 0.0)
        state.get("rho")[:] = xp.maximum(state.get("rho"), 1e-6)

    xp = cfg.xp
    sl = state.grid.interior_slice()
    r = geom.r_centers
    g = cfg.ghost_width

    for step in range(nsteps):
        sanitize()
        apply_outer_ghost(state, cfg)
        dt = cfl_dt(state, geom, cfg)
        launch_hlld_x(state, geom, cfg, fluxes["r"])
        launch_hlld_y(state, cfg, fluxes["phi"])
        launch_hlld_z(state, cfg, fluxes["z"])

        # find extreme vr cell
        rho = xp.maximum(state.get("rho")[sl], 1e-6)
        vr = state.get("rho_vr")[sl] / rho
        flat = vr.ravel()
        idx = int(xp.argmax(xp.abs(flat)))
        ir = idx // (cfg.nphi * cfg.nz)
        ip = (idx // cfg.nz) % cfg.nphi
        iz = idx % cfg.nz

        # radial face that feeds this cell (outer face)
        # ghosted face index
        face_ir = ir + g + 1
        face_ip = ip + g
        face_iz = iz + g

        # left and right cell states (ghosted indices)
        iL = ir + g
        iR = ir + g + 1
        j = ip + g
        k = iz + g

        def grab(name, ii):
            arr = state.get(name)
            return float(arr[ii, j, k])

        print(f"\n--- step {step}  extreme cell ir={ir} r={float(r[ir]):.3f} ---")
        print(f"  vr = {float(flat[idx]):+.3e}  ρ = {float(rho.ravel()[idx]):.3e}")
        print(f"  LEFT  (ir={ir}):   ρ={grab('rho', iL):.3e}  "
              f"ρvr={grab('rho_vr', iL):+.3e}  ρvφ={grab('rho_vphi', iL):+.3e}  "
              f"E={grab('E', iL):.3e}  Bφ={grab('Bphi', iL):+.3e}")
        print(f"  RIGHT (ir={ir+1}): ρ={grab('rho', iR):.3e}  "
              f"ρvr={grab('rho_vr', iR):+.3e}  ρvφ={grab('rho_vphi', iR):+.3e}  "
              f"E={grab('E', iR):.3e}  Bφ={grab('Bphi', iR):+.3e}")

        # flux at the outer face
        f_rho = float(fluxes["r"]["rho"][face_ir, face_ip, face_iz])
        f_vr  = float(fluxes["r"]["vr"][face_ir, face_ip, face_iz])
        f_vphi = float(fluxes["r"]["vphi"][face_ir, face_ip, face_iz])
        f_E   = float(fluxes["r"]["E"][face_ir, face_ip, face_iz])
        print(f"  FLUX at outer face: Fρ={f_rho:+.3e}  Fvr={f_vr:+.3e}  "
              f"Fvφ={f_vphi:+.3e}  FE={f_E:+.3e}")

        residual_cylindrical(state, geom, cfg, fluxes, dt)
        sanitize()


if __name__ == "__main__":
    run_extreme_cell_instrumentation()
