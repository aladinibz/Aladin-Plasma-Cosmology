"""
ALADIN Z-Pinch — Full Verification Suite

Runs every check developed for the cylindrical HLLD stack:
  1. Core Z-pinch evolution + diagnostics
  2. Density-floor sensitivity
  3. Reverse-current sign coupling
  4. Independent Jz reconstruction
  5. Axis regularity
  6. Independent Lorentz force
  7. Momentum closure (simplified)
  8. Disk + rotation
  9. CFL decomposition
 10. Outer-disk inspection
 11. Full momentum closure
 12. Extreme-cell instrumentation

Requires:
  hlld_x_kernel.py
  hlld_y_kernel.py
  hlld_z_kernel.py
  residual_cylindrical.py
"""

from test_zpinch_full import (
    run_zpinch_full,
    run_floor_sensitivity,
    run_reverse_current,
    run_independent_jz,
    run_axis_regularity,
    run_independent_lorentz,
    run_momentum_closure,
    run_disk_test,
    run_cfl_decomposition,
    run_outer_disk_inspection,
    run_full_momentum_closure,
    run_extreme_cell_instrumentation,
)


def run_all():
    """Execute the complete verification suite."""
    print("=" * 60)
    print("ALADIN Z-PINCH FULL VERIFICATION SUITE")
    print("=" * 60)

    sections = [
        ("1. Core Z-pinch",            run_zpinch_full),
        ("2. Floor sensitivity",       run_floor_sensitivity),
        ("3. Reverse-current",         run_reverse_current),
        ("4. Independent Jz",          run_independent_jz),
        ("5. Axis regularity",         run_axis_regularity),
        ("6. Independent Lorentz",     run_independent_lorentz),
        ("7. Momentum closure",        run_momentum_closure),
        ("8. Disk + rotation",         run_disk_test),
        ("9. CFL decomposition",       run_cfl_decomposition),
        ("10. Outer-disk inspection",  run_outer_disk_inspection),
        ("11. Full momentum closure",  run_full_momentum_closure),
        ("12. Extreme-cell instrument", run_extreme_cell_instrumentation),
    ]

    for title, fn in sections:
        print("\n" + "=" * 60)
        print(title)
        print("=" * 60)
        try:
            fn()
        except Exception as e:
            print(f"  FAILED: {type(e).__name__}: {e}")

    print("\n" + "=" * 60)
    print("SUITE COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    run_all()
