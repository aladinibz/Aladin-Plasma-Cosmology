"""
uct_zp58_transition_map.py
VERSION: 2026-11-15-ZP58
Map current errors in the last 12 cells and measure order after exclusion
"""

import cupy as cp

def analytic_F(r):
    return 1e-3 * cp.sin(cp.pi * r) * 0.5 * r

def analytic_dJzdt(r):
    pi = cp.pi
    return -5e-4 * (cp.sin(pi*r)/r + 3*pi*cp.cos(pi*r) - pi**2 * r * cp.sin(pi*r))

def zp58():
    print("ZP-58 — BOUNDARY-TRANSITION ERROR MAP\n")
    print("Using 5-point induction on last 3 cells (Variant C)\n")

    for Nr in [64, 128, 256, 512]:
        dr = 1.0 / Nr
        r = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
        F = analytic_F(r)

        dB = cp.zeros(Nr)
        for i in range(2, Nr-2):
            dB[i] = -(F[i+1] - F[i-1]) / (2*dr)
        dB[0] = - (F[0] / (r[0]**2) * dr**2) / dr
        dB[1] = -(F[2] - F[0]) / (2*dr)
        # 5-point on last 3
        for k in [1, 2, 3]:
            i = Nr - k
            dB[i] = - (25*F[i] - 48*F[i-1] + 36*F[i-2] - 16*F[i-3] + 3*F[i-4]) / (12*dr)

        rdB = r * dB
        dJz = cp.zeros(Nr)
        for i in range(1, Nr-1):
            dJz[i] = (rdB[i+1] - rdB[i-1]) / (2*dr * r[i])
        dJz[-1] = (3*rdB[-1] - 4*rdB[-2] + rdB[-3]) / (2*dr * r[-1])
        dJz[0] = dJz[1]

        dJz_ref = analytic_dJzdt(r)
        dJz_ref[0] = -2 * cp.pi * 1e-3
        err = (dJz - dJz_ref).get()

        print(f"=== Nr = {Nr} ===")
        print(" last 12 current errors:")
        for k in range(1, 13):
            print(f"  e[-{k:2d}] = {err[-k]:+.3e}")
        print(" first 4 current errors:")
        for k in range(4):
            print(f"  e[{k}]  = {err[k]:+.3e}")

        # exclusion test
        V = ((cp.arange(Nr)+1)**2 - cp.arange(Nr)**2) * dr**2
        print(" L2 after excluding last N cells:")
        for n_excl in [0, 1, 2, 3, 4, 6, 8, 12]:
            if n_excl == 0:
                mask = cp.ones(Nr, dtype=bool)
            else:
                mask = cp.ones(Nr, dtype=bool)
                mask[-n_excl:] = False
            l2 = float(cp.sqrt(cp.sum((dJz-dJz_ref)**2 * V * mask) / cp.sum(V * mask)))
            print(f"  exclude {n_excl:2d}: L2 = {l2:.3e}")
        print()

if __name__ == "__main__":
    zp58()
