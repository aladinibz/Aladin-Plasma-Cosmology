"""
uct_zp60_jxb_closure.py
VERSION: 2026-11-15-ZP60
Full Lorentz-force closure with uniform 5-point induction
"""

import cupy as cp

def analytic_F(r):
    return 1e-3 * cp.sin(cp.pi * r) * 0.5 * r

def analytic_dBdt(r):
    return -5e-4 * (cp.sin(cp.pi * r) + cp.pi * r * cp.cos(cp.pi * r))

def analytic_dJzdt(r):
    pi = cp.pi
    return -5e-4 * (cp.sin(pi*r)/r + 3*pi*cp.cos(pi*r) - pi**2 * r * cp.sin(pi*r))

def analytic_dFrdt(r):
    B = 0.5 * r
    J = cp.ones_like(r)
    dB = analytic_dBdt(r)
    dJ = analytic_dJzdt(r)
    return -dJ * B - J * dB

def zp60():
    print("ZP-60 — COUPLED J×B CLOSURE VERIFICATION\n")
    print("Uniform 5-point induction (Variant D)\n")
    prev_B = prev_J = prev_F = None
    for Nr in [64, 128, 256, 512]:
        dr = 1.0 / Nr
        r = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
        F = analytic_F(r)

        dB = cp.zeros(Nr)
        # uniform 5-point
        for i in range(4, Nr-4):
            dB[i] = - (F[i-2] - 8*F[i-1] + 8*F[i+1] - F[i+2]) / (12*dr)
        for k in range(1, 5):
            i = Nr - k
            dB[i] = - (25*F[i] - 48*F[i-1] + 36*F[i-2] - 16*F[i-3] + 3*F[i-4]) / (12*dr)
        dB[0] = - (F[0] / (r[0]**2) * dr**2) / dr
        dB[1] = -(F[2] - F[0]) / (2*dr)
        dB[2] = -(F[3] - F[1]) / (2*dr)
        dB[3] = -(F[4] - F[2]) / (2*dr)

        # current
        rdB = r * dB
        dJz = cp.zeros(Nr)
        for i in range(1, Nr-1):
            dJz[i] = (rdB[i+1] - rdB[i-1]) / (2*dr * r[i])
        dJz[-1] = (3*rdB[-1] - 4*rdB[-2] + rdB[-3]) / (2*dr * r[-1])
        dJz[0] = dJz[1]

        # force
        B = 0.5 * r
        J = cp.ones(Nr)
        dFr = -dJz * B - J * dB

        # references
        dB_ref = analytic_dBdt(r)
        dJz_ref = analytic_dJzdt(r)
        dJz_ref[0] = -2 * cp.pi * 1e-3
        dFr_ref = analytic_dFrdt(r)
        dFr_ref[0] = -dJz_ref[0]*B[0] - J[0]*dB_ref[0]

        V = ((cp.arange(Nr)+1)**2 - cp.arange(Nr)**2) * dr**2
        l2B = float(cp.sqrt(cp.sum((dB-dB_ref)**2 * V) / cp.sum(V)))
        l2J = float(cp.sqrt(cp.sum((dJz-dJz_ref)**2 * V) / cp.sum(V)))
        l2F = float(cp.sqrt(cp.sum((dFr-dFr_ref)**2 * V) / cp.sum(V)))
        oB = float(cp.log2(prev_B/l2B)) if prev_B else 0.0
        oJ = float(cp.log2(prev_J/l2J)) if prev_J else 0.0
        oF = float(cp.log2(prev_F/l2F)) if prev_F else 0.0
        print(f"Nr={Nr:4d}  L2B={l2B:.3e}({oB:.2f})  L2J={l2J:.3e}({oJ:.2f})  L2F={l2F:.3e}({oF:.2f})")
        print(f"        e_J[0]={float(dJz[0]-dJz_ref[0]):+.3e}  e_F[-1]={float(dFr[-1]-dFr_ref[-1]):+.3e}")
        prev_B, prev_J, prev_F = l2B, l2J, l2F

if __name__ == "__main__":
    zp60()
