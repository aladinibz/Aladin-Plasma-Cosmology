"""
uct_zp59_transition_width.py
VERSION: 2026-11-15-ZP59
Expand the high-order induction region and track the transition error
"""

import cupy as cp

def analytic_F(r):
    return 1e-3 * cp.sin(cp.pi * r) * 0.5 * r

def analytic_dJzdt(r):
    pi = cp.pi
    return -5e-4 * (cp.sin(pi*r)/r + 3*pi*cp.cos(pi*r) - pi**2 * r * cp.sin(pi*r))

def zp59():
    print("ZP-59 — TRANSITION-STENCIL COMPATIBILITY\n")
    for n_high, name in [(3, "A: last 3"), (5, "B: last 5"), (8, "C: last 8"), (0, "D: uniform 5pt")]:
        print(f"=== {name} ===")
        prev = None
        for Nr in [64, 128, 256, 512]:
            dr = 1.0 / Nr
            r = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
            F = analytic_F(r)

            dB = cp.zeros(Nr)
            # default centered
            for i in range(2, Nr-2):
                dB[i] = -(F[i+1] - F[i-1]) / (2*dr)
            dB[0] = - (F[0] / (r[0]**2) * dr**2) / dr
            dB[1] = -(F[2] - F[0]) / (2*dr)

            # high-order region
            if n_high == 0:
                # uniform 5-point everywhere possible
                for i in range(4, Nr-4):
                    dB[i] = - (F[i-2] - 8*F[i-1] + 8*F[i+1] - F[i+2]) / (12*dr)
                for k in range(1, 5):
                    i = Nr - k
                    dB[i] = - (25*F[i] - 48*F[i-1] + 36*F[i-2] - 16*F[i-3] + 3*F[i-4]) / (12*dr)
            else:
                for k in range(1, n_high+1):
                    i = Nr - k
                    dB[i] = - (25*F[i] - 48*F[i-1] + 36*F[i-2] - 16*F[i-3] + 3*F[i-4]) / (12*dr)

            # current
            rdB = r * dB
            dJz = cp.zeros(Nr)
            for i in range(1, Nr-1):
                dJz[i] = (rdB[i+1] - rdB[i-1]) / (2*dr * r[i])
            dJz[-1] = (3*rdB[-1] - 4*rdB[-2] + rdB[-3]) / (2*dr * r[-1])
            dJz[0] = dJz[1]

            dJz_ref = analytic_dJzdt(r)
            dJz_ref[0] = -2 * cp.pi * 1e-3
            err = (dJz - dJz_ref).get()
            V = ((cp.arange(Nr)+1)**2 - cp.arange(Nr)**2) * dr**2
            l2 = float(cp.sqrt(cp.sum((dJz-dJz_ref)**2 * V) / cp.sum(V)))
            order = float(cp.log2(prev/l2)) if prev else 0.0
            print(f"  Nr={Nr:4d}  L2={l2:.3e}  ord={order:.2f}  e[-3]={err[-3]:+.3e}  e[-4]={err[-4]:+.3e}")
            prev = l2
        print()

if __name__ == "__main__":
    zp59()
