"""
uct_jxb.py
VERSION: 2026-11-14-v8-FINAL
"""

import cupy as cp

_KERNEL_SRC = r"""
extern "C" __global__
void uct_jxb_kernel(
    const double* __restrict__ Jr,
    const double* __restrict__ Jth,
    const double* __restrict__ Jz,
    const double* __restrict__ Br,
    const double* __restrict__ Bth,
    const double* __restrict__ Bz,
    double* __restrict__ fr,
    double* __restrict__ fth,
    double* __restrict__ fz,
    int Nr, int Nth, int Nz
) {
    const int k = blockIdx.x * blockDim.x + threadIdx.x;
    const int j = blockIdx.y;
    const int i = blockIdx.z;
    if (i >= Nr || j >= Nth || k >= Nz) return;

    const int idx = i * (Nth * Nz) + j * Nz + k;

    // Dead simple: use the values exactly as stored (caller supplies cell-center fields)
    double Jr_c  = Jr[idx];
    double Jth_c = Jth[idx];
    double Jz_c  = Jz[idx];
    double Br_c  = Br[idx];
    double Bth_c = Bth[idx];
    double Bz_c  = Bz[idx];

    // Axis fix only
    if (i == 0) {
        Jr_c = 0.0;
        Br_c = 0.0;
    }

    fr[idx]  = Jth_c * Bz_c - Jz_c * Bth_c;
    fth[idx] = Jz_c * Br_c - Jr_c * Bz_c;
    fz[idx]  = Jr_c * Bth_c - Jth_c * Br_c;
}
"""

_jxb_kernel = cp.RawKernel(_KERNEL_SRC, "uct_jxb_kernel")
print("LOADED VERSION: 2026-11-14-v8-FINAL")


def launch_jxb(Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz):
    Nr, Nth, Nz = Jr.shape
    block = (256, 1)
    grid = ((Nz + 255) // 256, Nth, Nr)
    _jxb_kernel(grid, block,
                (Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz,
                 cp.int32(Nr), cp.int32(Nth), cp.int32(Nz)))
    return fr, fth, fz


def test_zpinch_full_chain(Nr=64, Nth=8, Nz=4, r_max=1.0):
    print("TEST VERSION: 2026-11-14-v8-FINAL")
    dr = r_max / Nr
    r_faces = cp.arange(Nr + 1, dtype=cp.float64) * dr
    r_centers = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
    shape = (Nr, Nth, Nz)

    # Cell-center B_theta the kernel will use directly
    Bth = cp.zeros(shape, dtype=cp.float64)
    for i in range(Nr):
        Bth[i] = 0.5 * float(r_centers[i])

    Jr = cp.zeros(shape, dtype=cp.float64)
    Jth = cp.zeros(shape, dtype=cp.float64)
    Br = cp.zeros(shape, dtype=cp.float64)
    Bz = cp.zeros(shape, dtype=cp.float64)
    Jz = cp.zeros(shape, dtype=cp.float64)

    # Numerical curl from faces -> Jz = 1
    for i in range(Nr):
        r_left = float(r_faces[i])
        r_right = float(r_faces[i + 1])
        rB_left = r_left * 0.5 * r_left
        rB_right = r_right * 0.5 * r_right
        d_rB_dr = (rB_right - rB_left) / dr
        r_c = float(r_centers[i])
        Jz[i] = d_rB_dr / r_c if r_c > 0 else 1.0

    fr = cp.zeros(shape, dtype=cp.float64)
    fth = cp.zeros(shape, dtype=cp.float64)
    fz = cp.zeros(shape, dtype=cp.float64)

    launch_jxb(Jr, Jth, Jz, Br, Bth, Bz, fr, fth, fz)

    f_r_expected = -0.5 * r_centers
    fr_radial = fr.mean(axis=(1, 2))
    err = cp.abs(fr_radial - f_r_expected)

    print(f"Jz[:4]       = {Jz[:,0,0][:4].get()}")
    print(f"fr_comp[:4]  = {fr_radial[:4].get()}")
    print(f"fr_exp[:4]   = {f_r_expected[:4].get()}")
    print(f"max |error|  = {float(err.max()):.3e}")
    print(f"err[0]       = {float(err[0]):.3e}")
    return fr, Jz, r_centers, fr_radial
