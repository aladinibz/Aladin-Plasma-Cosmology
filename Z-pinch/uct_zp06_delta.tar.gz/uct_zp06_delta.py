"""
uct_zp06_delta.py
VERSION: 2026-11-14-ZP06
Convergence on perturbation fields only (background subtracted)
Mini-pipeline — not production HLLD/UCT
"""

import cupy as cp
from uct_zp04_mini import run_zp04_v2

def extract_delta(Nr, nsteps, dt):
    vr, rho, Bth, r_centers, hist_vr, hist_E = run_zp04_v2(
        Nr=Nr, Nth=8, Nz=4, r_max=1.0, nsteps=nsteps, dt=dt
    )
    r = r_centers.get()
    # Initial analytic profiles
    B0 = 0.5 * r
    rho0 = 1.0
    vr0 = 1e-3 * cp.sin(cp.pi * r_centers).get()

    dB   = Bth[:,0,0].get() - B0
    drho = rho[:,0,0].get() - rho0
    dvr  = vr[:,0,0].get() - vr0

    return {
        "Nr": Nr,
        "r": r,
        "dB": dB,
        "drho": drho,
        "dvr": dvr,
        "E0": hist_E[0],
        "Ef": hist_E[-1],
        "max_dB": float(cp.abs(Bth[:,0,0] - 0.5*r_centers).max()),
        "max_drho": float(cp.abs(rho[:,0,0] - 1.0).max()),
    }

def zp06():
    print("ZP-06 — PERTURBATION-ONLY CONVERGENCE")
    print("Background subtracted | mini-pipeline\n")

    configs = [
        (32,  150, 1e-4),
        (64,  300, 5e-5),
        (128, 600, 2.5e-5),
        (256, 1200, 1.25e-5),
    ]

    results = [extract_delta(*c) for c in configs]

    print("\n========== DELTA MAGNITUDES ==========")
    print(f"{'Nr':>6} {'max|dB|':>12} {'max|drho|':>12} {'E_drift':>12}")
    for res in results:
        drift = res["Ef"] - res["E0"]
        print(f"{res['Nr']:6d} {res['max_dB']:12.3e} {res['max_drho']:12.3e} {drift:12.3e}")

    print("\n========== L2 ON DELTAS (consecutive) ==========")
    for i in range(len(results)-1):
        c = results[i]
        f = results[i+1]
        ratio = f["Nr"] // c["Nr"]
        dB_f   = f["dB"][::ratio][:c["Nr"]]
        drho_f = f["drho"][::ratio][:c["Nr"]]
        dvr_f  = f["dvr"][::ratio][:c["Nr"]]
        l2_dB   = float(cp.sqrt(cp.mean((cp.asarray(c["dB"])   - cp.asarray(dB_f))**2)))
        l2_drho = float(cp.sqrt(cp.mean((cp.asarray(c["drho"]) - cp.asarray(drho_f))**2)))
        l2_dvr  = float(cp.sqrt(cp.mean((cp.asarray(c["dvr"])  - cp.asarray(dvr_f))**2)))
        print(f"Nr {c['Nr']:>3} vs {f['Nr']:>3}:  "
              f"L2(dB)={l2_dB:.3e}  L2(drho)={l2_drho:.3e}  L2(dvr)={l2_dvr:.3e}")

    print("\nEnergy definition used:")
    print("  E = mean( 0.5*rho*vr**2 + 0.5*Bth**2 + P*rho/0.4 )")
    print("  P = 1 - 0.25*r**2   (held as base, scaled by rho)")
    print("  No boundary flux term in this reduced scheme")
    return results

if __name__ == "__main__":
    zp06()
