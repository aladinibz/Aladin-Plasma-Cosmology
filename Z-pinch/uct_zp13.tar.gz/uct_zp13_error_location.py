"""
uct_zp13_error_location.py
VERSION: 2026-11-14-ZP13
Where does the max induction error live?
"""

import cupy as cp

def analytical_dBdt(r):
    return -5e-4 * (cp.sin(cp.pi * r) + cp.pi * r * cp.cos(cp.pi * r))

def numerical_and_error(Nr):
    dr = 1.0 / Nr
    r = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
    B = 0.5 * r
    vr = 1e-3 * cp.sin(cp.pi * r)
    flux = vr * B
    dflux = cp.zeros(Nr)
    for i in range(1, Nr-1):
        dflux[i] = (flux[i+1] - flux[i-1]) / (2 * dr)
    r_g = r[-1] + dr
    vr_g = 1e-3 * cp.sin(cp.pi * r_g)
    B_g = 0.5 * r_g
    flux_g = vr_g * B_g
    dflux[-1] = (flux_g - flux[-2]) / (2 * dr)
    dflux[0] = (flux[1] - 0.0) / (2 * dr)
    dBdt_num = -dflux
    dBdt_ana = analytical_dBdt(r)
    err = cp.abs(dBdt_num - dBdt_ana)
    return r.get(), err.get()

def zp13():
    print("ZP-13 — LOCATION OF MAX INDUCTION ERROR\n")
    print(f"{'Nr':>6} {'max|err|':>12} {'r_at_max':>12} {'first':>12} {'last':>12} {'interior max':>12}")
    for Nr in [32, 64, 128, 256, 512]:
        r, err = numerical_and_error(Nr)
        idx = int(cp.argmax(cp.asarray(err)))
        print(f"{Nr:6d} {err.max():12.3e} {r[idx]:12.6f} "
              f"{err[0]:12.3e} {err[-1]:12.3e} {err[1:-1].max():12.3e}")
    print("\nIf max error is always at first or last cell, the interior operator is cleaner.")
    print("Derivative is computed directly from the spatial flux difference (no time step).")

if __name__ == "__main__":
    zp13()
