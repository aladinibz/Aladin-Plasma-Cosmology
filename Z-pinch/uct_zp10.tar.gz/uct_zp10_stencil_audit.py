"""
uct_zp10_stencil_audit.py
VERSION: 2026-11-14-ZP10
Exact static audit of the outer centered curl
No evolution — pure geometric consistency check
"""

import cupy as cp

def audit(Nr):
    dr = 1.0 / Nr
    r = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
    # analytic B on cells + ghost
    B = 0.5 * r
    r_ghost = r[-1] + dr
    B_ghost = 0.5 * r_ghost

    i = Nr - 1
    r_im1 = float(r[i-1])
    r_i   = float(r[i])
    r_ip1 = float(r_ghost)
    B_im1 = float(B[i-1])
    B_i   = float(B[i])
    B_ip1 = float(B_ghost)

    # centered cylindrical curl
    num = r_ip1 * B_ip1 - r_im1 * B_im1
    Jz = num / (2 * dr * r_i)

    print(f"\n=== Nr={Nr}  dr={dr:.6e} ===")
    print(f"r_im1={r_im1:.8f}  r_i={r_i:.8f}  r_ip1={r_ip1:.8f}")
    print(f"B_im1={B_im1:.8f}  B_i={B_i:.8f}  B_ip1={B_ip1:.8f}")
    print(f"numerator = {num:.8e}")
    print(f"Jz        = {Jz:.10f}")
    print(f"Jz - 1    = {Jz - 1.0:.3e}")

    # independent scalar
    Jz_scalar = (r_ip1*B_ip1 - r_im1*B_im1) / (2*dr*r_i)
    print(f"scalar Jz = {Jz_scalar:.10f}   diff={Jz-Jz_scalar:.3e}")

def zp10():
    print("ZP-10 — STATIC OUTER STENCIL AUDIT")
    print("Analytic B_phi=0.5*r + analytic ghost, no time step\n")
    for Nr in [32, 64, 128, 256, 512]:
        audit(Nr)
    print("\nIf Jz-1 stays ~1e-15 on every Nr, the stencil is geometrically consistent.")
    print("If it grows, the indexing or the 2*dr factor is wrong.")

if __name__ == "__main__":
    zp10()
