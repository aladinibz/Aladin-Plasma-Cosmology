"""
ghost_cell_analysis.py
VERSION: 2026-11-14-ghost
Explicit outer radial ghost-cell treatment for the mini-pipeline
"""

import cupy as cp

def apply_outer_ghost(rho, vr, Bth, r_centers, mode="equilibrium"):
    """
    Fill a ghost value for the outer radial boundary.
    mode='equilibrium' -> preserve the analytic Z-pinch profiles
    mode='zero_grad'   -> simple zero-gradient
    """
    if mode == "equilibrium":
        # analytic targets at the outer face / ghost
        r_ghost = r_centers[-1] + (r_centers[-1] - r_centers[-2])
        rho_ghost = 1.0
        vr_ghost  = 1e-3 * cp.sin(cp.pi * r_ghost)   # or 0.0 for wall
        Bth_ghost = 0.5 * r_ghost
    else:  # zero_grad
        rho_ghost = rho[-1,0,0]
        vr_ghost  = vr[-1,0,0]
        Bth_ghost = Bth[-1,0,0]

    return float(rho_ghost), float(vr_ghost), float(Bth_ghost)


def demo():
    print("Ghost-cell demo (analytic equilibrium mode)")
    Nr = 64
    dr = 1.0 / Nr
    r_centers = (cp.arange(Nr) + 0.5) * dr
    rho = cp.ones((Nr, 1, 1))
    vr  = 1e-3 * cp.sin(cp.pi * r_centers)[:, None, None]
    Bth = (0.5 * r_centers)[:, None, None]

    rg, vg, bg = apply_outer_ghost(rho, vr, Bth, r_centers, "equilibrium")
    print(f"last cell r = {float(r_centers[-1]):.6f}")
    print(f"ghost rho   = {rg:.6f}")
    print(f"ghost vr    = {vg:.6e}")
    print(f"ghost Bth   = {bg:.6f}")
    print(f"analytic B  = {0.5 * (float(r_centers[-1]) + dr):.6f}")
    print("\nWith this ghost the centered difference at i=Nr-1 becomes consistent")
    print("with the interior scheme and the equilibrium.")

if __name__ == "__main__":
    demo()
