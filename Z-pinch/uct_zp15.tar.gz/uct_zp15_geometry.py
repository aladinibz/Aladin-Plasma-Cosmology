"""
uct_zp15_geometry.py
VERSION: 2026-11-14-ZP15
Geometric factor isolation for the first radial cell
Compare integrated flux change BEFORE dividing by area
"""

import cupy as cp

def analytic_flux_integral(r_left, r_right, nquad=512):
    """Integral of -d/dt (something) wait: the RHS integrated.
    For induction, the change in integral(B r dr) = - [r vr B ]_face
    """
    # Exact face flux at r_right for analytic fields
    r_f = r_right
    vr_f = 1e-3 * cp.sin(cp.pi * r_f)
    B_f  = 0.5 * r_f
    return float(r_f * vr_f * B_f)

def zp15():
    print("ZP-15 — GEOMETRIC FACTOR ISOLATION (first cell)\n")
    for Nr in [32, 64, 128, 256]:
        dr = 1.0 / Nr
        r_centers = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
        r0 = float(r_centers[0])
        r_face = dr                     # outer face of first cell
        area = 0.5 * dr**2              # cylindrical "volume" of first cell

        # Numerical integrated flux (what the code uses)
        B0 = 0.5 * r0
        vr0 = 1e-3 * cp.sin(cp.pi * r0)
        # current regularity version
        B_face = 2.0 * B0
        vr_face = 0.5 * (vr0 + 1e-3 * cp.sin(cp.pi * (r0+dr)))
        num_integrated_flux = r_face * vr_face * B_face

        # Analytical integrated flux change
        ana_integrated_flux = analytic_flux_integral(0.0, r_face)

        print(f"=== Nr={Nr} ===")
        print(f"1. Coordinate of B DOF (cell center) : {r0:.8f}")
        print(f"2. B is treated as                   : point value at cell center")
        print(f"3. Physical area (V0)                : {area:.8e}")
        print(f"4. Faraday update                    : d(int B r dr)/dt = -flux_face")
        print(f"5. Numerical integrated flux         : {num_integrated_flux:.8e}")
        print(f"6. Analytical integrated flux        : {ana_integrated_flux:.8e}")
        print(f"   Difference (before /area)         : {num_integrated_flux - ana_integrated_flux:.3e}")
        print(f"   After /area (dB/dt num)           : {-num_integrated_flux/area:.6e}")
        print(f"   After /area (dB/dt ana face)      : {-ana_integrated_flux/area:.6e}")
        print()

    print("If integrated fluxes agree but dB/dt differs → normalization/reference issue.")
    print("If integrated fluxes differ → reconstruction or face value is wrong.")

if __name__ == "__main__":
    zp15()
