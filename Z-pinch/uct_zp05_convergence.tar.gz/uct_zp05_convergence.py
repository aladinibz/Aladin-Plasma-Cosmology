"""
uct_zp05_convergence.py
VERSION: 2026-11-14-ZP05-mini
Convergence + energy study of the ZP-04 mini-pipeline
Clearly labeled: reduced operators, not production HLLD-UCT
"""

import cupy as cp
from uct_zp04_mini import run_zp04_v2

def run_resolution(Nr, nsteps, dt):
    print(f"\n=== Nr={Nr} | steps={nsteps} | dt={dt:.2e} ===")
    vr, rho, Bth, r_centers, hist_vr, hist_E = run_zp04_v2(
        Nr=Nr, Nth=8, Nz=4, r_max=1.0, nsteps=nsteps, dt=dt
    )
    return {
        "Nr": Nr,
        "r": r_centers.get(),
        "vr": vr[:,0,0].get(),
        "rho": rho[:,0,0].get(),
        "Bth": Bth[:,0,0].get(),
        "E0": hist_E[0],
        "Ef": hist_E[-1],
        "max_vr": hist_vr[-1],
    }

def zp05():
    print("ZP-05 MINI-PIPELINE CONVERGENCE STUDY")
    print("Reduced operators — not production HLLD/UCT")
    print("Fixed final time t=0.015\n")

    configs = [
        (32,  150, 1e-4),
        (64,  300, 5e-5),
        (128, 600, 2.5e-5),
        (256, 1200, 1.25e-5),
    ]

    results = []
    for Nr, nsteps, dt in configs:
        results.append(run_resolution(Nr, nsteps, dt))

    print("\n========== SUMMARY ==========")
    print(f"{'Nr':>6} {'max|vr|':>12} {'E_drift':>12} {'E_rel':>12}")
    for res in results:
        drift = res["Ef"] - res["E0"]
        rel = drift / abs(res["E0"])
        print(f"{res['Nr']:6d} {res['max_vr']:12.3e} {drift:12.3e} {rel:12.3e}")

    # Simple profile difference between consecutive resolutions (coarsened)
    print("\nProfile L2 differences (consecutive resolutions, coarsened):")
    for i in range(len(results)-1):
        coarse = results[i]
        fine = results[i+1]
        # sample fine onto coarse points (nearest)
        ratio = fine["Nr"] // coarse["Nr"]
        vr_f = fine["vr"][::ratio][:coarse["Nr"]]
        rho_f = fine["rho"][::ratio][:coarse["Nr"]]
        B_f = fine["Bth"][::ratio][:coarse["Nr"]]
        dvr = cp.sqrt(cp.mean((cp.asarray(coarse["vr"]) - cp.asarray(vr_f))**2))
        drho = cp.sqrt(cp.mean((cp.asarray(coarse["rho"]) - cp.asarray(rho_f))**2))
        dB = cp.sqrt(cp.mean((cp.asarray(coarse["Bth"]) - cp.asarray(B_f))**2))
        print(f"Nr {coarse['Nr']} vs {fine['Nr']}:  "
              f"L2(vr)={float(dvr):.3e}  L2(rho)={float(drho):.3e}  L2(B)={float(dB):.3e}")

    return results

if __name__ == "__main__":
    zp05()
