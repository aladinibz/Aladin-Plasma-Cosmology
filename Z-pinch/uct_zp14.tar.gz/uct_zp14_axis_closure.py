"""
uct_zp14_axis_closure.py
VERSION: 2026-11-14-ZP14
Axis cell: numerical flux difference vs exact cell-average of analytic dB/dt
"""

import cupy as cp

def analytic_dBdt(r):
    return -5e-4 * (cp.sin(cp.pi * r) + cp.pi * r * cp.cos(cp.pi * r))

def exact_cell_average(r_left, r_right, nquad=64):
    """High-order quadrature of analytic dB/dt over [r_left, r_right], volume-weighted."""
    # V ~ r dr in cylindrical (axisym)
    rs = cp.linspace(r_left, r_right, nquad)
    drs = rs[1] - rs[0]
    vals = analytic_dBdt(rs)
    # trapezoid with r weight
    w = rs
    integ = cp.sum(vals * w) * drs
    vol = 0.5 * (r_right**2 - r_left**2)
    return float(integ / vol) if vol > 0 else float(vals[0])

def numerical_first_cell(Nr):
    dr = 1.0 / Nr
    r = (cp.arange(Nr, dtype=cp.float64) + 0.5) * dr
    B = 0.5 * r
    vr = 1e-3 * cp.sin(cp.pi * r)
    flux = vr * B
    # one-sided / axis treatment currently used
    dflux0 = (flux[1] - 0.0) / (2 * dr)
    return float(-dflux0), float(r[0]), dr

def zp14():
    print("ZP-14 — AXIS CLOSURE AUDIT")
    print("Numerical first-cell dB/dt vs exact cell-average of analytic derivative\n")
    print(f"{'Nr':>6} {'num':>12} {'exact_avg':>12} {'abs_err':>12} {'rel_err':>12}")
    for Nr in [32, 64, 128, 256, 512]:
        num, r0, dr = numerical_first_cell(Nr)
        r_left = 0.0
        r_right = dr
        exact = exact_cell_average(r_left, r_right)
        err = abs(num - exact)
        rel = err / (abs(exact) + 1e-30)
        print(f"{Nr:6d} {num:12.6e} {exact:12.6e} {err:12.3e} {rel:12.3e}")
    print("\nIf abs_err ~ O(dr) the axis stencil is first-order.")
    print("If abs_err ~ O(dr^2) or smaller, the cell-average reference matches.")

if __name__ == "__main__":
    zp14()
