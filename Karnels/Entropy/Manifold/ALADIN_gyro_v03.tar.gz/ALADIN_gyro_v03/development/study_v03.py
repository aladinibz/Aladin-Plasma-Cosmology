# -*- coding: utf-8 -*-
"""
ALADIN gyro v03 — development study E (CPU always; GPU legs when CuPy/CUDA is present).

    python study_v03.py      -> v03_study_results.json, V03_STUDY_REPORT.md, v03_study.png

Development study (shapes v03 before its freeze and certification campaign); thresholds below are fixed before this run.
Oracle: oracle.py (continuous distributions, dense FP64 integration), independent of the kernel's lattice.  Exact members
of the closure family are built ON THE CONTINUUM in their own drift frame (low multipliers solved so that mean = 0,
variance = 1, <s> = 2), so "in-family" is a property of the continuous distribution, not of the lattice.
FP32 legs run the default FP32 + FP64 rescue.
Disclosed threshold change (2026-11-19, after the first L4 run): G01 FP32 q threshold 1e-4 -> 2e-3 (FP32 resolution of q on
hard cells, below the lattice error 6.7e-3).  The G01 FP32 failure in that run was a real defect (delivery decisions flipping
between builds on ~0.3 % of hard cells), fixed in the kernel by the FP64 rescue and one frame tolerance for both precisions.
"""
import datetime, hashlib, json, os, platform, sys, time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import oracle as O, gyro_v03 as G

RES = dict(meta={}, tests={}, gpu={})
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
TH = dict(bimax_q64=1e-10, bimax_q32=1e-5, family_delivered=1.0, family_q_median=5e-3, family_q_max=5e-2,
          kappa_q64=1e-10, kappa_q32=1e-5, restart_q64=1e-8, restart_q32=1e-4, build_q64=1e-8, build_q32=1e-4,
          fp32_vs_fp64=1e-3, gpu_vs_cpu64=1e-8, gpu_vs_cpu32=2e-3)


def say(*a): print(*a, flush=True)
def V(ok): return "PASS" if ok else "FAIL"
def g(a): return a.get() if hasattr(a, "get") else np.asarray(a)


def run(cs, dt=np.float64, be="cpu", **kw):
    N = len(cs)
    S = np.array([c["S"] for c in cs]); u = np.array([c["u"] for c in cs]); Vv = np.array([c["V"] for c in cs]); Q = np.array([c["Q"] for c in cs])
    r = G.run_gyro(np.ones(N), u, Vv, Q / 2, S, dtype=dt, backend=be, **kw)
    return {k: g(v).astype(np.float64 if k not in ("status", "iters") else np.int32) for k, v in r.items()}


def qn(r, cs):
    a = np.array([(r["q_par"][i] - c["q_par"]) / c["V"] ** 1.5 for i, c in enumerate(cs)])
    b = np.array([(r["q_perp"][i] - c["q_perp"]) / (c["V"] ** .5 * c["Q"] / 2) for i, c in enumerate(cs)])
    return np.abs(a), np.abs(b)


# ------------------------------------------------------------------ case sets
def bimax_cases():
    return [dict(O.moments_std(*O.bimax(u, T, Tq)), key=dict(u=u, Tpar=T, Tper=Tq))
            for T in [0.1, 0.5, 1, 3, 9] for u in [0, 0.7, 2.5] for Tq in [0.1, 1, 9]]


def family_member(shape, rng_seed=None):
    """continuous exp(theta . psi(x, s)) * exp(-x^2/2 - s/2) with given shape multipliers (psi index 3..8) and low multipliers
    (psi 0..2) solved so that the distribution's own frame is (mean 0, var 1, <s> = 2): an exact member in its own drift frame."""
    from scipy.optimize import fsolve
    def logf_of(low):
        th = np.concatenate([low, shape])
        def lf(c, c2):
            x, s = c, c2                                       # frame u = 0, V = 1, T_perp = 1  ->  s = c_perp^2
            idp = 1 / (1 + x * x); ide = 1 / (1 + s)
            psi = [x, s, x * x, x * idp, x * s * ide, x ** 3 * idp ** 2, x ** 4, s * s + s ** 3 * ide, x * x * s + x * x * s * s * ide]
            return sum(t * p for t, p in zip(th, psi)) - x * x / 2 - s / 2
        return lf
    def resid(low):
        o = O.moments(logf_of(low), -16, 16, 16, Np=1201, Nq=801)
        return [o["u"], o["V"] - 1, o["Q"] - 2]
    low = fsolve(resid, np.zeros(3), xtol=1e-13)
    o = O.moments_std(logf_of(low), -16, 16, 16)
    return o


def family_cases(n=30, seed=5):
    rng = np.random.default_rng(seed); cs = []
    for i in range(n):
        a, b, sx = rng.uniform(.02, .2), rng.uniform(.02, .2), rng.uniform(-.6, .6)
        shape = np.array([rng.uniform(-.5, .5), rng.uniform(-.4, .4), rng.uniform(-.3, .3), -a * a, -.5 * b * b, -a * b * sx])
        o = family_member(shape)
        # place it in a physical frame: the drift-frame shape moments do not change, u, V, Q are free
        u, T, Tq = rng.uniform(-2, 2), 10 ** rng.uniform(-1, 1), 10 ** rng.uniform(-1, 1)
        cs.append(dict(S=o["S"], u=u, V=T, Q=2 * Tq, q_par=o["q_par"] * T ** 1.5, q_perp=o["q_perp"] * T ** .5 * Tq,
                       key=dict(shape=shape.round(4).tolist(), frame_check=[o["u"], o["V"], o["Q"]])))
    return cs


def physics_cases():
    out = []
    for fr in [0.05, 0.1, 0.2]:
        for u2 in [2.0, 3.0, 4.0]:
            out.append(dict(O.moments_std(*O.two_beam(fr, u2, 0.3)), key=dict(kind="two-beam", frac=fr, u2=u2)))
    for j in [1, 2]:
        for Tq in [0.5, 1.0]:
            out.append(dict(O.moments_std(*O.loss_cone(1.0, Tq, j)), key=dict(kind="loss-cone", j=j, Tper=Tq)))
    for k in [3, 5, 10]:
        for u in [0.5, 2.0]:
            out.append(dict(O.moments_std(*O.kappa(k, 1.0, u)), key=dict(kind="kappa", kappa=k, u=u)))
    return out


def stress_cases(n=3000, seed=7):
    rng = np.random.default_rng(seed); cs = []
    for i in range(n):
        w = rng.uniform(0, 1); u1, u2 = rng.uniform(-3, 3, 2); T1, T2 = 10 ** rng.uniform(-1.3, 1, 2); Q1, Q2 = 10 ** rng.uniform(-1.3, 1, 2)
        def lf(c, c2, w=w, u1=u1, u2=u2, T1=T1, T2=T2, Q1=Q1, Q2=Q2):
            a = w * np.exp(-(c - u1) ** 2 / (2 * T1) - c2 / (2 * Q1)) / (T1 ** .5 * Q1) + (1 - w) * np.exp(-(c - u2) ** 2 / (2 * T2) - c2 / (2 * Q2)) / (T2 ** .5 * Q2)
            return np.log(a + 1e-300)
        lo = min(u1 - 14 * T1 ** .5, u2 - 14 * T2 ** .5); hi = max(u1 + 14 * T1 ** .5, u2 + 14 * T2 ** .5)
        cs.append(O.moments_std(lf, lo, hi, 14 * max(Q1, Q2) ** .5, Np=601, Nq=401))
    return cs


def main():
    t0 = time.time(); gpu = G.has_gpu(); T = RES["tests"]
    RES["meta"] = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), platform=platform.platform(),
                       python=sys.version.split()[0], numpy=np.__version__, gpu=None, thresholds=TH, lattice=f"{G.NP}x{G.NQ}",
                       v03_file_sha256=sha(os.path.join(HERE, "gyro_v03.py")), v03_source_sha256=G.SOURCE_SHA256,
                       oracle_sha256=sha(os.path.join(HERE, "oracle.py")))
    if gpu:
        import cupy as cp
        RES["meta"]["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); RES["meta"]["cupy"] = cp.__version__
    say(f"gyro v03 study | source {G.SOURCE_SHA256[:12]} | GPU {RES['meta']['gpu']}")

    bc = bimax_cases(); fc = family_cases(); pc = physics_cases()
    say("cases built", len(bc), len(fc), len(pc), f"{time.time() - t0:.0f}s")

    # E01 bi-Maxwellians: q = 0 exactly (symmetry), any drift / temperature
    d = dict(name="exact drifting anisotropic bi-Maxwellians (45 cells, T_par 0.1-9, drift 0-2.5, T_perp 0.1-9): q = 0"); ok = True
    for dt, th in [(np.float64, TH["bimax_q64"]), (np.float32, TH["bimax_q32"])]:
        r = run(bc, dt); a, b = qn(r, bc)
        d[np.dtype(dt).name] = dict(status=sorted(set(r["status"].tolist())), qpar_max=float(a.max()), qperp_max=float(b.max()), iters_max=int(r["iters"].max()))
        ok &= set(r["status"].tolist()) <= {0} and a.max() <= th and b.max() <= th
    d["verdict"] = V(ok); T["E01"] = d; say("E01", d)

    # E02 exact family members (continuum, own drift frame)
    d = dict(name="exact members of the closure family (30 continuum distributions in their own drift frame): recover q"); ok = True; keep = {}
    for dt in (np.float64, np.float32):
        r = run(fc, dt); a, b = qn(r, fc); keep[dt] = r
        dl = float(np.mean(np.isin(r["status"], [0, 4])))
        d[np.dtype(dt).name] = dict(delivered=dl, status=dict(zip(*[x.tolist() for x in np.unique(r["status"], return_counts=True)])),
                                    qpar_median=float(np.median(a)), qpar_max=float(a.max()), qperp_median=float(np.median(b)), qperp_max=float(b.max()),
                                    resid_max=float(r["resid"].max()), iters_max=int(r["iters"].max()))
        ok &= dl >= TH["family_delivered"] and np.median(a) <= TH["family_q_median"] and a.max() <= TH["family_q_max"] and np.median(b) <= TH["family_q_median"] and b.max() <= TH["family_q_max"]
    d["frame_check_max"] = float(max(max(abs(c["key"]["frame_check"][0]), abs(c["key"]["frame_check"][1] - 1), abs(c["key"]["frame_check"][2] - 2)) for c in fc))
    d["plot"] = dict(true=[c["q_par"] / c["V"] ** 1.5 for c in fc], v03=(keep[np.float64]["q_par"] / np.array([c["V"] ** 1.5 for c in fc])).tolist())
    d["verdict"] = V(ok); T["E02"] = d; say("E02", {k: v for k, v in d.items() if k != "plot"})

    # E03 physics: beams, loss cones, kappa (kappa graded: q must be 0 by symmetry)
    rows = []; ok = True
    r64, r32 = run(pc, np.float64), run(pc, np.float32)
    for i, c in enumerate(pc):
        rows.append(dict(case=c["key"], q_par_true=c["q_par"] / c["V"] ** 1.5, q_perp_true=c["q_perp"] / (c["V"] ** .5 * c["Q"] / 2),
                         st64=int(r64["status"][i]), q_par64=r64["q_par"][i] / c["V"] ** 1.5, q_perp64=r64["q_perp"][i] / (c["V"] ** .5 * c["Q"] / 2),
                         st32=int(r32["status"][i]), q_par32=r32["q_par"][i] / c["V"] ** 1.5, resid64=r64["resid"][i], iters64=int(r64["iters"][i])))
        if c["key"]["kind"] == "kappa":
            ok &= abs(rows[-1]["q_par64"]) <= TH["kappa_q64"] and abs(rows[-1]["q_par32"]) <= TH["kappa_q32"]
        ok &= rows[-1]["st64"] in (0, 4) and rows[-1]["st32"] in (0, 4)
    T["E03"] = dict(name="physics: two-beam (9), loss-cone (4), drifting kappa (6). Graded: all delivered; kappa q = 0 (symmetry)", rows=rows, verdict=V(ok))
    say("E03", T["E03"]["verdict"])

    # E04 uniqueness: warm starts from random admissible multipliers must give the same answer
    allc = fc + pc; rng = np.random.default_rng(4); d = dict(name="uniqueness: 5 random admissible starting points per cell (full path) vs the default start"); ok = True
    for dt, th in [(np.float64, TH["restart_q64"]), (np.float32, TH["restart_q32"])]:
        base = run(allc, dt); worst = 0.0; agree = 1.0
        for rep in range(5):
            th0 = rng.normal(0, 0.05, (len(allc), 9)); th0[:, 6] = -rng.uniform(.01, .2, len(allc)); th0[:, 7] = -rng.uniform(.01, .2, len(allc)); th0[:, 8] = 0
            rr = run(allc, dt, theta_io=th0.astype(dt), warm=2)
            both = np.isin(base["status"], [0, 4]) & np.isin(rr["status"], [0, 4])
            agree = min(agree, float(np.mean(np.isin(base["status"], [0, 4]) == np.isin(rr["status"], [0, 4]))))
            sc = np.array([c["V"] ** 1.5 for c in allc]); worst = max(worst, float(np.max(np.abs(rr["q_par"] - base["q_par"])[both] / sc[both])))
        d[np.dtype(dt).name] = dict(max_q_diff=worst, delivery_agreement=agree); ok &= worst <= th and agree == 1.0
    d["verdict"] = V(ok); T["E04"] = d; say("E04", d)

    # E05 reproducibility across builds (CPU, FMA contraction on/off: what differs between GPU and CPU code generation)
    d = dict(name="reproducibility across builds: g++ with and without FMA contraction (same source)"); ok = True
    S = np.array([c["S"] for c in allc]); u = np.array([c["u"] for c in allc]); Vv = np.array([c["V"] for c in allc]); Q = np.array([c["Q"] for c in allc])
    for dt, th in [(np.float64, TH["build_q64"]), (np.float32, TH["build_q32"])]:
        a = G.run_gyro(np.ones(len(S)), u, Vv, Q / 2, S, dtype=dt, backend="cpu", cpu_extra=("-ffp-contract=off",))
        b = G.run_gyro(np.ones(len(S)), u, Vv, Q / 2, S, dtype=dt, backend="cpu", cpu_extra=("-mfma", "-ffp-contract=fast"))
        same = float(np.mean(a["status"] == b["status"])); dq = float(np.max(np.abs(a["q_par"] - b["q_par"]) / Vv ** 1.5))
        d[np.dtype(dt).name] = dict(status_agreement=same, max_q_diff=dq); ok &= same == 1.0 and dq <= th
    d["verdict"] = V(ok); T["E05"] = d; say("E05", d)

    # E06 admissibility stress
    say("E06 building 3000 random mixtures ..."); sc_ = stress_cases()
    d = dict(name="admissibility stress: 3000 random two-component bi-Maxwellian mixtures (drift +-3, T 0.05-10)"); ok = True
    for dt in (np.float64, np.float32):
        r = run(sc_, dt); fin = all(np.isfinite(r[k]).all() for k in ["q_par", "q_perp", "adm", "resid"])
        dl = np.isin(r["status"], [0, 4])
        d[np.dtype(dt).name] = dict(all_finite=bool(fin), delivered=float(dl.mean()), adm_min=float(r["adm"][dl].min()) if dl.any() else None,
                                    status=dict(zip(*[x.tolist() for x in np.unique(r["status"], return_counts=True)])), iters_median=float(np.median(r["iters"])), iters_max=int(r["iters"].max()))
        ok &= fin and (not dl.any() or r["adm"][dl].min() >= 0)
    d["verdict"] = V(ok); T["E06"] = d; say("E06", d)

    # E07 consistency (ABC-4) and E08 invalid inputs
    r = G.run_gyro(np.full(5, 2.0), np.arange(5.0), np.full(5, 0.3), np.full(5, 4.0), np.tile(G.SHAPE_MAXWELL, (5, 1)), dtype=np.float32, backend="cpu")
    T["E07"] = dict(name="ABC-4: n, u_par, P_par, P_perp returned are the inputs (bitwise)",
                    identical=bool(all(np.array_equal(g(r[k]), np.asarray(v, np.float32)) for k, v in [("n", np.full(5, 2.0)), ("u_par", np.arange(5.0)), ("P_par", np.full(5, .3)), ("P_perp", np.full(5, 4.0))])))
    T["E07"]["verdict"] = V(T["E07"]["identical"]); say("E07", T["E07"])
    Sb = np.tile(G.SHAPE_MAXWELL, (6, 1)); Sb[2, 5] = np.nan; Sb[3, 8] = np.inf
    r = G.run_gyro(np.array([1, 1, 1, 1, 0, 1.]), np.zeros(6), np.array([-1, 1, 1, 1, 1, 1.]), np.array([1, 0, 1, 1, 1, np.nan]), Sb, dtype=np.float64, backend="cpu")
    fin = all(np.isfinite(g(r[k])).all() for k in ["q_par", "q_perp", "adm"])
    T["E08"] = dict(name="invalid inputs (P_par<0, P_perp=0, NaN/Inf shape, n=0, NaN P_perp): status 5, finite, adm = -1",
                    status=g(r["status"]).tolist(), finite=bool(fin), verdict=V(fin and (g(r["status"]) == 5).all() and (g(r["adm"]) == -1).all()))
    say("E08", T["E08"])

    # E09 FP32 vs FP64
    a, b = keep[np.float64], keep[np.float32]; sc = np.array([c["V"] ** 1.5 for c in fc])
    dq = float(np.max(np.abs(a["q_par"] - b["q_par"]) / sc))
    T["E09"] = dict(name="FP32 vs FP64 on the family members (normalised q_par)", max_diff=dq, verdict=V(dq <= TH["fp32_vs_fp64"])); say("E09", T["E09"])

    # E10 sensitivity to input noise (characterisation)
    rows = []; rng = np.random.default_rng(11); base = run(fc, np.float64)
    for delta in [1e-7, 1e-5, 1e-3]:
        noisy = [dict(c, S=np.concatenate([c["S"][:4], c["S"][4:] * (1 + delta * rng.standard_normal(8))])) for c in fc]
        rn = run(noisy, np.float64); dqv = np.abs(rn["q_par"] - base["q_par"]) / sc
        rows.append(dict(delta=delta, dq_median=float(np.median(dqv)), dq_max=float(dqv.max()), amplification_median=float(np.median(dqv) / delta)))
    T["E10"] = dict(name="sensitivity: relative noise on the 8 shape moments -> change in normalised q_par", rows=rows, verdict="RECORDED"); say("E10", rows)

    # E12 lattice convergence (recorded): exact family members, q_par error vs lattice size (separate builds)
    import pickle, subprocess, tempfile
    pk = os.path.join(tempfile.gettempdir(), "gyro_v03_fc.pkl"); pickle.dump(fc, open(pk, "wb"))
    code = ("import sys, pickle, numpy as np; sys.path.insert(0, %r); import study_v03 as SV; fc = pickle.load(open(%r, 'rb')); "
            "r = SV.run(fc, np.float64); a, b = SV.qn(r, fc); print(np.median(a), a.max(), np.median(b), int(r['iters'].max()))") % (HERE, pk)
    rows = []
    for npar, nper in [(16, 12), (20, 12), (24, 16), (32, 20)]:
        out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=dict(os.environ, GYRO_NPAR=str(npar), GYRO_NPER=str(nper)))
        v = [float(x) for x in out.stdout.split()[-4:]]
        rows.append(dict(lattice=f"{npar}x{nper}", nodes=npar * nper, qpar_median=v[0], qpar_max=v[1], qperp_median=v[2], iters_max=int(v[3])))
    T["E12"] = dict(name="lattice convergence on the exact family members (FP64): q error vs lattice size", rows=rows, verdict="RECORDED"); say("E12", rows)

    # E11 timing
    big = (fc + pc) * 20; t = time.time(); run(big, np.float32); tc = time.time() - t
    T["E11"] = dict(name="CPU time per cell FP32 (g++ -O2, OpenMP)", cells=len(big), us_per_cell=1e6 * tc / len(big), verdict="RECORDED"); say("E11", T["E11"])

    if gpu:
        import cupy as cp
        G_ = RES["gpu"]; sub = fc + pc + sc_[:1500]
        for dt, th in [(np.float64, TH["gpu_vs_cpu64"]), (np.float32, TH["gpu_vs_cpu32"])]:
            rc, rg = run(sub, dt, "cpu"), run(sub, dt, "cupy")
            sv = np.array([c["V"] ** 1.5 for c in sub])
            same = float(np.mean(np.isin(rc["status"], [0, 4]) == np.isin(rg["status"], [0, 4]))); dq = float(np.max(np.abs(rc["q_par"] - rg["q_par"]) / sv))
            G_[f"G01_{np.dtype(dt).name}"] = dict(name="GPU vs CPU, same source (delivery decisions + q)", delivery_agreement=same, max_q_diff=dq, verdict=V(same == 1.0 and dq <= th))
        S = np.tile(np.array([c["S"] for c in fc]), (3334, 1))[:100000]; N = len(S)
        args = (cp.ones(N, cp.float32), cp.zeros(N, cp.float32), cp.ones(N, cp.float32), cp.ones(N, cp.float32), cp.asarray(S, cp.float32))
        G.run_gyro(*[a[:1000] for a in args], dtype=np.float32); cp.cuda.runtime.deviceSynchronize()
        t = time.time(); G.run_gyro(*args, dtype=np.float32); cp.cuda.runtime.deviceSynchronize(); tg = time.time() - t
        r_ = G.run_gyro(*args, dtype=np.float32); rescued = int(r_.get("rescued", 0))
        a64 = tuple(a.astype(cp.float64) for a in args); G.run_gyro(*[a[:1000] for a in a64], dtype=np.float64); cp.cuda.runtime.deviceSynchronize()
        t = time.time(); G.run_gyro(*a64, dtype=np.float64); cp.cuda.runtime.deviceSynchronize(); tg64 = time.time() - t
        G_["G02"] = dict(name=f"GPU throughput, {N} family cells", FP32_with_rescue_Mcells_per_s=N / tg / 1e6, rescued=rescued,
                         FP64_Mcells_per_s=N / tg64 / 1e6, verdict="RECORDED")
        rc, rg = run(sc_[:1500], np.float32, "cpu"), run(sc_[:1500], np.float32, "cupy")
        dlc, dlg = np.isin(rc["status"], [0, 4]), np.isin(rg["status"], [0, 4])
        G_["G03"] = dict(name="hard cells (1500 random mixtures), FP32+rescue: GPU vs CPU delivery decisions and q",
                         delivery_agreement=float(np.mean(dlc == dlg)), max_q_diff=float(np.max(np.abs(rc["q_par"] - rg["q_par"]) / np.array([c["V"] ** 1.5 for c in sc_[:1500]]))),
                         verdict=V(bool(np.all(dlc == dlg))))
        for k, v in G_.items(): say(k, v)

    RES["meta"]["runtime_s"] = time.time() - t0
    json.dump(RES, open(os.path.join(HERE, "v03_study_results.json"), "w"), indent=1, default=float)
    import report_v03; report_v03.build(RES, HERE)
    say("done in %.0f s" % RES["meta"]["runtime_s"])


if __name__ == "__main__":
    main()
