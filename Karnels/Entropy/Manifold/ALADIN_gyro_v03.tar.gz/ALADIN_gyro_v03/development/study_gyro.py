# -*- coding: utf-8 -*-
"""
ALADIN gyro closure — development study D (v2.1 frozen vs v02), CPU always + GPU when CuPy/CUDA is present.

    python study_gyro.py            # writes gyro_study_results.json, GYRO_STUDY_REPORT.md, gyro_study.png

This is a DEVELOPMENT study (it motivated and checks v02), not yet a certification campaign: thresholds for v02 were
fixed after the exploratory runs described in the report.  v2.1 is measured, never patched.
Disclosed definition changes after the first full run (2026-11-19): D03 counts status 0 or 4 as delivered (status 4 =
stationary least-squares fit was introduced by the stationarity fix); D05 FP32 measured in units of eps32 * kappa,
kappa = (M3 + M1^2) / (M3 - M1^2), because the FP32 input itself cannot carry V to better than that.
Oracle: oracle.py — continuous distributions integrated on a dense 3001 x 2001 grid in FP64, independent of both lattices.
"""
import hashlib, json, os, platform, sys, time, datetime
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import oracle as O, gyro_v02 as G, v21_cpu as V

RES = dict(meta={}, tests={}, gpu={})
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
TH = dict(  # v02 acceptance thresholds
    bimax_q_fp64=1e-5, bimax_q_fp32=1e-4, bimax_status0=1.0,
    family_delivered=0.95, family_q_median=5e-3, family_q_max=5e-2,
    consist_fp64=1e-12, consist_fp32_eps_kappa=4.0, fp32_vs_fp64_q=2e-3, warm_q=2e-3)


def say(*a): print(*a, flush=True)


def verdict(ok): return "PASS" if ok else "FAIL"


# ------------------------------------------------------------------ case sets
def bimax_cases():
    cs = []
    for T in [0.1, 0.25, 0.5, 1, 1.5, 2, 3, 4, 6, 9]:
        for u in [0, 0.7, 1.3, 2.5]:
            for Tq in [0.1, 1, 4, 9]:
                o = O.moments(*O.bimax(u, T, Tq)); o["key"] = dict(u=u, Tpar=T, Tper=Tq); cs.append(o)
    return cs


def family_cases(n=40, seed=1):
    rng = np.random.default_rng(seed); cs = []
    for i in range(n):
        lam = np.zeros(12); lam[[4, 5, 9]] = rng.uniform(-.4, .4, 3); lam[1] = rng.uniform(-.2, .2)
        a, b, s = rng.uniform(.05, .3), rng.uniform(.05, .3), rng.uniform(-.5, .5)
        lam[8] = -a * a; lam[6] = lam[10] = -.5 * b * b; lam[7] = lam[11] = -a * b * s
        u, Tp, Tq = rng.uniform(-1, 1), rng.uniform(.3, 2), rng.uniform(.3, 2)
        o = O.moments(*O.family(lam, u, Tp, Tq)); o["key"] = dict(u=u, Tpar=Tp, Tper=Tq); cs.append(o)
    return cs


def physics_cases():
    cs = []
    for fr in [0.05, 0.1, 0.2]:
        for u2 in [2.0, 3.0, 4.0]:
            o = O.moments(*O.two_beam(fr, u2, 0.3)); o["key"] = dict(kind="two-beam", frac=fr, u2=u2); cs.append(o)
    for j in [1, 2]:
        for Tq in [0.5, 1.0]:
            o = O.moments(*O.loss_cone(1.0, Tq, j)); o["key"] = dict(kind="loss-cone", j=j, Tper=Tq); cs.append(o)
    for k in [3, 5, 10]:
        o = O.moments(*O.kappa(k, 1.0, 0.5)); o["key"] = dict(kind="kappa", kappa=k, u=0.5); cs.append(o)
    return cs


def stress_cases(n=4000, seed=7):
    """random two-component bi-Maxwellian mixtures, moments in closed form for polynomial features + oracle-free:
    computed by the oracle on a coarser grid for speed."""
    rng = np.random.default_rng(seed); Ms = []
    for i in range(n):
        w = rng.uniform(0, 1); u1, u2 = rng.uniform(-3, 3, 2); T1, T2 = 10 ** rng.uniform(-1.3, 1, 2); Q1, Q2 = 10 ** rng.uniform(-1.3, 1, 2)
        def lf(c, c2, w=w, u1=u1, u2=u2, T1=T1, T2=T2, Q1=Q1, Q2=Q2):
            a = w * np.exp(-(c - u1) ** 2 / (2 * T1) - c2 / (2 * Q1)) / (T1 ** .5 * Q1) + (1 - w) * np.exp(-(c - u2) ** 2 / (2 * T2) - c2 / (2 * Q2)) / (T2 ** .5 * Q2)
            return np.log(a + 1e-300)
        lo = min(u1 - 14 * T1 ** .5, u2 - 14 * T2 ** .5); hi = max(u1 + 14 * T1 ** .5, u2 + 14 * T2 ** .5)
        Ms.append(O.moments(lf, lo, hi, 14 * max(Q1, Q2) ** .5, Np=601, Nq=401)["M"])
    return np.array(Ms)


# ------------------------------------------------------------------ runners
def run02(M, be="cpu", dt=np.float64, **kw):
    r = G.run_gyro(np.asarray(M), np.ones(len(M)), backend=be, dtype=dt, **kw)
    return {k: (v.get() if hasattr(v, "get") else v).astype(np.float64 if k != "status" else np.int32) for k, v in r.items()}


def run21(M, be="cpu"):
    r = V.run_v21(np.asarray(M, np.float32), np.ones(len(M), np.float32), backend=be)
    return {k: np.asarray(v).astype(np.float64 if k != "status" else np.int32) for k, v in r.items()}


def qerr(r, cs):
    ep = np.array([abs(r["qpar"][i] - c["q_par"]) / c["V"] ** 1.5 for i, c in enumerate(cs)])
    eq = np.array([abs(r["qperp"][i] - c["q_perp"]) / (c["V"] ** .5 * c["Q"]) for i, c in enumerate(cs)])
    return ep, eq


def consist(r, M):
    M = np.asarray(M, np.float64); u = M[:, 1]; Vv = M[:, 3] - M[:, 1] ** 2; Q = M[:, 2]
    du = np.abs(r["upar"] - u) / np.sqrt(Vv); dp = np.abs(r["Ppar"] / Vv - 1); dq = np.abs(r["Pperp"] / (0.5 * Q) - 1)
    return float(max(du.max(), dp.max(), dq.max())), dict(u=float(du.max()), Ppar=float(dp.max()), Pperp=float(dq.max()))


def main():
    t0 = time.time()
    gpu = G.has_gpu()
    RES["meta"] = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), platform=platform.platform(),
                       python=sys.version.split()[0], numpy=np.__version__, gpu=None, thresholds=TH,
                       v21_file_sha256=sha(os.path.join(HERE, "gyro_v21.py")), v02_file_sha256=sha(os.path.join(HERE, "gyro_v02.py")),
                       v02_source_sha256=G.SOURCE_SHA256, v02_lattice=f"{G.NP}x{G.NQ}", oracle_sha256=sha(os.path.join(HERE, "oracle.py")))
    if gpu:
        import cupy as cp
        RES["meta"]["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); RES["meta"]["cupy"] = cp.__version__
    say(f"gyro study | v02 {G.SOURCE_SHA256[:12]} lattice {G.NP}x{G.NQ} | GPU: {RES['meta']['gpu']}")
    T = RES["tests"]

    # D01 v2.1 own self-test
    spec = __import__("importlib.util").util.spec_from_file_location("g21", os.path.join(HERE, "gyro_v21.py"))
    m21 = __import__("importlib.util").util.module_from_spec(spec); spec.loader.exec_module(m21)
    Mb = m21.compute_base_moments(); r = run21(np.tile(Mb, (128, 1)))
    Vb = Mb[3] - Mb[1] ** 2
    T["D01"] = dict(name="v2.1 reproduces its own self-test (lattice-generated target)", cls="REFERENCE",
                    v21_status=sorted(set(r["status"].tolist())), v21_Ppar_vs_target=float(r["Ppar"][0] / Vb - 1),
                    v21_Pperp_vs_target=float(r["Pperp"][0] / (0.5 * Mb[2]) - 1), verdict="PASS" if set(r["status"].tolist()) == {0} else "FAIL")
    say("D01", T["D01"])

    # D02 bi-Maxwellians
    bc = bimax_cases(); Mbc = np.array([c["M"] for c in bc])
    d = dict(name="exact drifting anisotropic bi-Maxwellians, T_par 0.1-9, drift 0-2.5, T_perp 0.1-9 (160 cells): expect q = 0", n=len(bc))
    ok = True
    for dt, th in [(np.float64, TH["bimax_q_fp64"]), (np.float32, TH["bimax_q_fp32"])]:
        r = run02(Mbc, dt=dt); ep, eq = qerr(r, bc); s0 = float(np.mean(r["status"] == 0))
        d[f"v02_{np.dtype(dt).name}"] = dict(status0=s0, qpar_max=float(ep.max()), qperp_max=float(eq.max()))
        ok &= s0 >= TH["bimax_status0"] and ep.max() <= th and eq.max() <= th
    r = run21(Mbc); ep, eq = qerr(r, bc)
    byT = {}
    for i, c in enumerate(bc):
        t = c["key"]["Tpar"]; byT.setdefault(t, []).append(i)
    d["v21"] = dict(status0=float(np.mean(r["status"] == 0)), qpar_max=float(ep.max()), status_counts={str(k): int(v) for k, v in zip(*np.unique(r["status"], return_counts=True))},
                    by_Tpar={str(t): dict(status0=int(np.sum(r["status"][ix] == 0)), n=len(ix), qpar_max=float(ep[ix].max()),
                                          Ppar_err_max=float(max(abs(r["Ppar"][i] / bc[i]["V"] - 1) for i in ix))) for t, ix in byT.items()})
    r2 = run02(Mbc); e2, _ = qerr(r2, bc)
    d["plot"] = dict(T=[c["key"]["Tpar"] for c in bc], v21=ep.tolist(), v02=e2.tolist(), v21_status=r["status"].tolist())
    d["verdict"] = verdict(ok); T["D02"] = d; say("D02", {k: v for k, v in d.items() if k not in ("plot",)}["verdict"], d["v02_float64"], d["v02_float32"], "v21 status0", d["v21"]["status0"])

    # D03 in-family recovery
    fc = family_cases(); Mf = np.array([c["M"] for c in fc])
    d = dict(name="members of the closure family exp(lambda.phi) (40 random cells, odd + quartic): recover q_par, q_perp", n=len(fc))
    ok = True; keep = {}
    for dt in (np.float64, np.float32):
        r = run02(Mf, dt=dt); ep, eq = qerr(r, fc); keep[dt] = r
        s0 = float(np.mean(np.isin(r["status"], [0, 4])))
        d[f"v02_{np.dtype(dt).name}"] = dict(delivered=s0, status_counts={str(k): int(v) for k, v in zip(*np.unique(r["status"], return_counts=True))}, qpar_median=float(np.median(ep)), qpar_max=float(ep.max()), qperp_median=float(np.median(eq)), qperp_max=float(eq.max()))
        ok &= s0 >= TH["family_delivered"] and np.median(ep) <= TH["family_q_median"] and ep.max() <= TH["family_q_max"] and np.median(eq) <= TH["family_q_median"] and eq.max() <= TH["family_q_max"]
    r = run21(Mf); ep, eq = qerr(r, fc); conv = r["status"] == 0
    d["v21"] = dict(status0=float(np.mean(conv)), qpar_median_converged=float(np.median(ep[conv])) if conv.any() else None,
                    qpar_max_converged=float(ep[conv].max()) if conv.any() else None, qperp_median_converged=float(np.median(eq[conv])) if conv.any() else None)
    d["plot"] = dict(true=[c["q_par"] for c in fc], v02=keep[np.float64]["qpar"].tolist(), v21=r["qpar"].tolist(), v21_status=r["status"].tolist())
    d["verdict"] = verdict(ok); T["D03"] = d; say("D03", d["verdict"], d["v02_float64"], d["v02_float32"], d["v21"])

    # D04 out-of-family physics (characterisation)
    pc = physics_cases(); Mp = np.array([c["M"] for c in pc]); r2 = run02(Mp); r1 = run21(Mp)
    rows = []
    for i, c in enumerate(pc):
        rows.append(dict(case=c["key"], q_par_true=c["q_par"] / c["V"] ** 1.5, q_perp_true=c["q_perp"] / (c["V"] ** .5 * c["Q"]),
                         v02=dict(status=int(r2["status"][i]), q_par=r2["qpar"][i] / c["V"] ** 1.5, q_perp=r2["qperp"][i] / (c["V"] ** .5 * c["Q"]), resid=r2["resid"][i]),
                         v21=dict(status=int(r1["status"][i]), q_par=r1["qpar"][i] / c["V"] ** 1.5, q_perp=r1["qperp"][i] / (c["V"] ** .5 * c["Q"]))))
    T["D04"] = dict(name="out-of-family physics: two-beam, loss-cone, kappa (normalised q; characterisation)", cls="CHARACTERISATION", rows=rows, verdict="RECORDED")
    say("D04 recorded", len(rows))

    # D06 stress (admissibility)
    say("D06 building 4000 random mixtures ...")
    Ms = stress_cases()
    d = dict(name="admissibility stress: 4000 random two-component bi-Maxwellian mixtures (drift +-3, T 0.05-10)", n=len(Ms))
    ok = True
    for dt in (np.float64, np.float32):
        r = run02(Ms, dt=dt); fin = np.all([np.isfinite(r[k]).all() for k in G.OUT_NAMES])
        good = np.isin(r["status"], [0, 4])
        d[f"v02_{np.dtype(dt).name}"] = dict(all_finite=bool(fin), P_positive=bool((r["Ppar"] > 0).all() and (r["Pperp"] > 0).all()),
                                             adm_min_delivered=float(r["adm"][good].min()) if good.any() else None,
                                             status_counts={str(k): int(v) for k, v in zip(*np.unique(r["status"], return_counts=True))}, consistency=consist(r, Ms)[1])
        ok &= fin and (r["Ppar"] > 0).all() and (r["Pperp"] > 0).all() and (not good.any() or r["adm"][good].min() >= -1e-6)
    r = run21(Ms)
    d["v21"] = dict(all_finite=bool(np.all([np.isfinite(r[k]).all() for k in ["upar", "Ppar", "Pperp", "qpar", "qperp"]])),
                    P_positive=bool((r["Ppar"] > 0).all() and (r["Pperp"] > 0).all()),
                    status_counts={str(k): int(v) for k, v in zip(*np.unique(r["status"], return_counts=True))}, consistency=consist(r, Ms)[1])
    d["verdict"] = verdict(ok); T["D06"] = d; say("D06", d["verdict"], d["v02_float64"], d["v21"])

    # D05 consistency ABC-4 over all sets
    allM = np.concatenate([Mbc, Mf, Mp, Ms]); d = dict(name="ABC-4 consistency: returned u, P_par, P_perp equal the fluid input (all %d cells)" % len(allM))
    ok = True
    mx, parts = consist(run02(allM, dt=np.float64), allM); d["v02_float64"] = dict(max_rel=mx, **parts); ok &= mx <= TH["consist_fp64"]
    # FP32: the input itself limits the result (V = M3 - M1^2 cancels in FP32): deviation measured in units of eps32 * kappa
    M32 = allM.astype(np.float32).astype(np.float64); kap = (M32[:, 3] + M32[:, 1] ** 2) / (M32[:, 3] - M32[:, 1] ** 2)
    r32 = run02(allM, dt=np.float32); Vv = M32[:, 3] - M32[:, 1] ** 2
    dev = np.maximum.reduce([np.abs(r32["upar"] - M32[:, 1]) / np.sqrt(Vv), np.abs(r32["Ppar"] / Vv - 1), np.abs(r32["Pperp"] / (0.5 * M32[:, 2]) - 1)])
    e32 = float(np.finfo(np.float32).eps); worst = float(np.max(dev / (e32 * kap)))
    d["v02_float32"] = dict(max_rel=float(dev.max()), max_in_eps_kappa=worst, kappa_max=float(kap.max())); ok &= worst <= TH["consist_fp32_eps_kappa"]
    mx, parts = consist(run21(allM), allM); d["v21"] = dict(max_rel=mx, **parts)
    d["verdict"] = verdict(ok); T["D05"] = d; say("D05", d["verdict"], d["v02_float64"], d["v02_float32"], d["v21"])

    # D07 invalid inputs
    bad = np.tile(bc[0]["M"], (6, 1)); bad[0, 3] = bad[0, 1] ** 2 - 0.1; bad[1, 2] = -1; bad[2, 5] = np.nan; bad[3, 1] = np.inf; bad[4, 3] = bad[4, 1] ** 2
    nin = np.ones(6); nin[5] = 0
    r = G.run_gyro(bad, nin, dtype=np.float64, backend="cpu"); r1 = V.run_v21(bad.astype(np.float32), nin.astype(np.float32))
    fin = all(np.isfinite(r[k]).all() for k in G.OUT_NAMES)
    T["D07"] = dict(name="invalid inputs (V<0, Q<0, NaN, Inf, V=0, n=0): status 5, finite outputs, adm=-1",
                    v02_status=r["status"].tolist(), v02_finite=bool(fin), v02_adm=r["adm"].tolist(),
                    v21_status=r1["status"].tolist(), v21_finite=bool(all(np.isfinite(r1[k]).all() for k in ["upar", "Ppar", "Pperp", "qpar", "qperp"])),
                    verdict=verdict(fin and (r["status"] == 5).all() and (r["adm"] == -1).all()))
    say("D07", T["D07"])

    # D08 FP32 vs FP64
    a, b = keep[np.float64], keep[np.float32]; both = (a["status"] == 0) & (b["status"] == 0)
    dq = float(max(np.max(np.abs(a["qpar"] - b["qpar"])[both] / np.array([c["V"] ** 1.5 for c in fc])[both]),
                   np.max(np.abs(a["qperp"] - b["qperp"])[both] / np.array([c["V"] ** .5 * c["Q"] for c in fc])[both])))
    T["D08"] = dict(name="FP32 vs FP64 on the family cells (normalised q)", max_diff=dq, cells=int(both.sum()), verdict=verdict(dq <= TH["fp32_vs_fp64_q"]))
    say("D08", T["D08"])

    # D09 warm start (same cells, and 1 % perturbed targets)
    lam = np.zeros((len(Mf), 12)); r0 = G.run_gyro(Mf, np.ones(len(Mf)), lambda_io=lam, dtype=np.float64, backend="cpu")
    rw = G.run_gyro(Mf, np.ones(len(Mf)), lambda_io=lam.copy(), dtype=np.float64, backend="cpu", warm=True)
    Mpert = Mf.copy(); Mpert[:, 1:] *= 1.01
    rwp = G.run_gyro(Mpert, np.ones(len(Mf)), lambda_io=lam.copy(), dtype=np.float64, backend="cpu", warm=True)
    rcp = G.run_gyro(Mpert, np.ones(len(Mf)), dtype=np.float64, backend="cpu")
    sc = np.array([c["V"] ** 1.5 for c in fc])
    w1 = float(np.max(np.abs(rw["qpar"] - r0["qpar"]) / sc)); w2 = float(np.max(np.abs(rwp["qpar"] - rcp["qpar"]) / sc))
    T["D09"] = dict(name="warm start: same targets, and 1 % perturbed targets, warm vs cold", same=w1, perturbed=w2,
                    status_warm=sorted(set(rw["status"].tolist())), status_pert_warm=sorted(set(rwp["status"].tolist())),
                    verdict=verdict(max(w1, w2) <= TH["warm_q"]))
    say("D09", T["D09"])

    # D11 sensitivity of q to noise in the input moments (characterisation: q_par is not a feature, it is extrapolated)
    rng = np.random.default_rng(11); rows = []
    base = run02(Mf, dt=np.float64)
    for delta in [1e-7, 1e-5, 1e-3]:
        Mn = Mf.copy(); Mn[:, 1:] *= 1 + delta * rng.standard_normal(Mn[:, 1:].shape)
        rn = run02(Mn, dt=np.float64); dq = np.abs(rn["qpar"] - base["qpar"]) / np.array([c["V"] ** 1.5 for c in fc])
        rows.append(dict(delta=delta, dq_median=float(np.median(dq)), dq_max=float(dq.max()), amplification_median=float(np.median(dq) / delta),
                         delivered=float(np.mean(np.isin(rn["status"], [0, 4])))))
    T["D11"] = dict(name="sensitivity: relative noise delta on the 11 input feature moments -> change in normalised q_par (family cells)", rows=rows, verdict="RECORDED")
    say("D11", rows)

    # D10 timing (CPU)
    Mt = np.tile(Mf, (25, 1)); t = time.time(); run02(Mt, dt=np.float32); t2 = time.time() - t
    t = time.time(); run21(Mt); t1 = time.time() - t
    T["D10"] = dict(name="CPU time per cell (g++ -O2, %s)" % platform.processor(), cells=len(Mt), v02_us=1e6 * t2 / len(Mt), v21_us=1e6 * t1 / len(Mt), verdict="RECORDED")
    say("D10", T["D10"])

    # ------------------------------------------------------------- GPU legs
    if gpu:
        import cupy as cp
        g = RES["gpu"]
        sub = np.concatenate([Mf, Ms[:2000]])
        for dt in (np.float32, np.float64):
            rc, rg = run02(sub, "cpu", dt), run02(sub, "cupy", dt)
            same = rc["status"] == rg["status"]; ok_ = same & np.isin(rc["status"], [0, 4])
            g[f"G01_{np.dtype(dt).name}"] = dict(name="v02 GPU vs CPU, same source", status_agree=float(same.mean()),
                                                 qpar_maxdiff=float(np.abs(rc["qpar"] - rg["qpar"])[ok_].max()), Ppar_maxdiff=float(np.abs(rc["Ppar"] - rg["Ppar"]).max()))
        rc, rg = run21(sub, "cpu"), run21(sub, "cupy")
        g["G02"] = dict(name="v2.1 GPU vs CPU emulation", status_agree=float((rc["status"] == rg["status"]).mean()),
                        qpar_maxdiff=float(np.nanmax(np.abs(rc["qpar"] - rg["qpar"]))))
        # G03 partial last block after poisoning shared memory with NaN
        poison = cp.RawKernel(r'''extern "C" __global__ void poison(float* o){ __shared__ float s[12288];
            for (int i = threadIdx.x; i < 12288; i += blockDim.x) s[i] = __int_as_float(0x7fc00000); __syncthreads();
            if (threadIdx.x == 0) o[blockIdx.x] = s[blockIdx.x % 12288]; }''', "poison")
        rows = []
        base = np.tile(Mf[:1], (64, 1))
        for rem in [1, 5, 11, 15, 16, 63]:
            M = np.concatenate([base, np.tile(Mf[:1], (rem, 1))])
            junk = cp.zeros(4096, cp.float32); poison((4096,), (256,), (junk,)); cp.cuda.runtime.deviceSynchronize()
            a1 = run21(M, "cupy")
            poison((4096,), (256,), (junk,)); cp.cuda.runtime.deviceSynchronize()
            a2 = run02(M, "cupy", np.float32)
            dev21 = float(np.nanmax(np.abs(a1["qpar"][64:] - a1["qpar"][0]))) if np.isfinite(a1["qpar"][64:]).all() else float("nan")
            rows.append(dict(Ncells=64 + rem, v21_last_block_status=sorted(set(a1["status"][64:].tolist())), v21_first_block_status=int(a1["status"][0]),
                             v21_last_block_finite=bool(np.isfinite(a1["qpar"][64:]).all() and np.isfinite(a1["Ppar"][64:]).all()),
                             v21_last_block_dev=dev21, v02_last_block_dev=float(np.abs(a2["qpar"][64:] - a2["qpar"][0]).max())))
        g["G03"] = dict(name="partial last block (identical cells) after poisoning shared memory with NaN", rows=rows)
        # G04 throughput
        Mbig = np.tile(Mf, (2500, 1)); Mg = cp.asarray(Mbig, cp.float32); ng = cp.ones(len(Mbig), cp.float32)
        G.run_gyro(Mg[:1000], ng[:1000]); cp.cuda.runtime.deviceSynchronize()
        t = time.time(); G.run_gyro(Mg, ng); cp.cuda.runtime.deviceSynchronize(); tg2 = time.time() - t
        lam21 = cp.zeros((len(Mbig), 12), cp.float32); lam21[:, 6] = lam21[:, 8] = lam21[:, 10] = -0.05
        m21.launch_gyro(Mg[:1000], ng[:1000], lam21[:1000].copy()); cp.cuda.runtime.deviceSynchronize()
        t = time.time(); m21.launch_gyro(Mg, ng, lam21); cp.cuda.runtime.deviceSynchronize(); tg1 = time.time() - t
        g["G04"] = dict(name="GPU throughput, %d cells FP32" % len(Mbig), v02_Mcells_per_s=len(Mbig) / tg2 / 1e6, v21_Mcells_per_s=len(Mbig) / tg1 / 1e6)
        for k, v in g.items(): say(k, v)

    RES["meta"]["runtime_s"] = time.time() - t0
    json.dump(RES, open(os.path.join(HERE, "gyro_study_results.json"), "w"), indent=1, default=float)
    report(); say("done in %.0f s" % RES["meta"]["runtime_s"])


def report():
    import report_gyro
    report_gyro.build(RES, HERE)


if __name__ == "__main__":
    main()
