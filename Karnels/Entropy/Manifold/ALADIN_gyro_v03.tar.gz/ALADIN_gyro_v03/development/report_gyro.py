# -*- coding: utf-8 -*-
"""Report builder for the gyro development study: every number comes from gyro_study_results.json."""
import json, os, sys


def f(x, p=2):
    if x is None: return "n/a"
    if isinstance(x, float):
        return f"{x:.{p}e}" if (x != 0 and (abs(x) < 1e-2 or abs(x) >= 1e4)) else f"{x:.{p+1}g}"
    return str(x)


def tbl(head, rows):
    return "\n".join(["| " + " | ".join(head) + " |", "|" + "|".join("---" for _ in head) + "|"] + ["| " + " | ".join(f(c) for c in r) + " |" for r in rows])


def plots(R, here):
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, numpy as np
    except Exception:
        return None
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    p = R["tests"]["D02"]["plot"]; T = np.array(p["T"]); s = np.array(p["v21_status"])
    e21 = np.maximum(np.array(p["v21"]), 1e-12); e02 = np.maximum(np.array(p["v02"]), 1e-12)
    j = np.random.default_rng(0).uniform(-.06, .06, len(T))
    ax[0].scatter(T * (1 + j), e21, s=14, c=np.where(s == 0, "C3", "0.6"), label="v2.1 (grey: status != 0, q forced to 0)")
    ax[0].scatter(T * (1 - j), e02, s=14, c="C0", label="v02")
    ax[0].set_xscale("log"); ax[0].set_yscale("log"); ax[0].set_xlabel("T_par (thermal_scale units)"); ax[0].set_ylabel("|q_par| / T_par^1.5  (exact: 0)")
    ax[0].set_title("Exact bi-Maxwellians, 160 cells"); ax[0].legend(fontsize=8)
    p = R["tests"]["D03"]["plot"]; t = np.array(p["true"]); s = np.array(p["v21_status"])
    lim = 1.1 * np.max(np.abs(t))
    ax[1].plot([-lim, lim], [-lim, lim], "k:", lw=1)
    ax[1].scatter(t, p["v21"], s=16, c=np.where(s == 0, "C3", "0.6"), label="v2.1")
    ax[1].scatter(t, p["v02"], s=16, c="C0", label="v02")
    ax[1].set_xlabel("q_par true (continuum oracle)"); ax[1].set_ylabel("q_par closure"); ax[1].set_title("Closure-family members, 40 cells"); ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(here, "gyro_study.png"), dpi=130); return "gyro_study.png"


def build(R, here):
    m, T, g = R["meta"], R["tests"], R.get("gpu", {})
    L = []; A = L.append
    A("# ALADIN gyro closure — development study: v2.1 (frozen) vs v02")
    A(f"*Generated from `gyro_study_results.json` · {m['utc']} · {m['platform']} · GPU: {m['gpu']}*\n")
    A("Development study, not yet a certification campaign: the v02 thresholds were fixed after the exploratory runs that shaped v02. "
      "v2.1 is measured exactly as written (frozen source, never patched). Oracle: continuous distributions integrated on a dense "
      "3001 x 2001 grid in FP64, independent of both kernels' lattices.\n")
    A("**History (disclosed).** First full run: D05 FAIL (FP32 threshold 1e-6 ignored that V = M3 - M1^2 cancels in the FP32 input; "
      "redefined in units of eps32*kappa) and D09 FAIL (warm vs cold q differed by 1.8e-2: res_tol = 1e-3 stopped the solver early "
      "in a flat valley, so q depended on the start; fixed in the kernel by a stationarity stop, res_tol 1e-5, new status 4 = "
      "least-squares stationary fit; D03 then counts status 0 or 4 as delivered). Second run: D02 FAIL traced to the oracle, "
      "not the kernel: trapezoid in c_perp is O(h^2) at c_perp = 0 (4e-6 moment error); oracle switched to composite Gauss-Legendre "
      "(self-agreement 4e-16). The episode exposed that q amplifies input-moment noise; D11 now measures it.\n")
    A(tbl(["Item", "Value"], [["v2.1 file SHA-256", f"`{m['v21_file_sha256']}`"], ["v02 file SHA-256", f"`{m['v02_file_sha256']}`"],
                              ["v02 kernel source SHA-256", f"`{m['v02_source_sha256']}`"], ["v02 lattice", m["v02_lattice"]], ["oracle SHA-256", f"`{m['oracle_sha256']}`"]]))
    A("\n## Verdicts\n")
    A(tbl(["Test", "What", "Verdict"], [[k, v["name"], v["verdict"]] for k, v in sorted(T.items())]))
    d = T["D01"]
    A(f"\n## D01 — v2.1 own self-test\nstatus {d['v21_status']}; returned P_par differs from its own target by {d['v21_Ppar_vs_target']:+.2%}, P_perp by {d['v21_Pperp_vs_target']:+.2%}.")
    d = T["D02"]
    A(f"\n## D02 — {d['name']}\n")
    A(tbl(["", "status 0", "max abs(q_par)/T^1.5", "max q_perp (norm.)"],
          [["v02 FP64", d["v02_float64"]["status0"], d["v02_float64"]["qpar_max"], d["v02_float64"]["qperp_max"]],
           ["v02 FP32", d["v02_float32"]["status0"], d["v02_float32"]["qpar_max"], d["v02_float32"]["qperp_max"]],
           ["v2.1 FP32", d["v21"]["status0"], d["v21"]["qpar_max"], ""]]))
    A("\nv2.1 by T_par (status-0 cells / 16, worst q, worst P_par error):\n")
    A(tbl(["T_par", "status 0", "max q/T^1.5", "max P_par err"], [[t, f"{v['status0']}/{v['n']}", v["qpar_max"], v["Ppar_err_max"]] for t, v in d["v21"]["by_Tpar"].items()]))
    d = T["D03"]
    A(f"\n## D03 — {d['name']}\n")
    A(tbl(["", "delivered (status 0/4) / status 0 (v2.1)", "median q_par err", "max q_par err", "median q_perp err", "max q_perp err"],
          [["v02 FP64"] + [d["v02_float64"][k] for k in ["delivered", "qpar_median", "qpar_max", "qperp_median", "qperp_max"]],
           ["v02 FP32"] + [d["v02_float32"][k] for k in ["delivered", "qpar_median", "qpar_max", "qperp_median", "qperp_max"]],
           ["v2.1 (converged cells)", d["v21"]["status0"], d["v21"]["qpar_median_converged"], d["v21"]["qpar_max_converged"], d["v21"]["qperp_median_converged"], ""]]))
    A("\nErrors normalised by T_par^1.5 (q_par) and sqrt(T_par)<c_perp^2> (q_perp).")
    d = T["D04"]
    A(f"\n## D04 — {d['name']}\n")
    A(tbl(["case", "q_par true", "v02 st", "v02 q_par", "v2.1 st", "v2.1 q_par", "q_perp true", "v02 q_perp", "v2.1 q_perp"],
          [[" ".join(f"{k}={v}" for k, v in r["case"].items()), r["q_par_true"], r["v02"]["status"], r["v02"]["q_par"], r["v21"]["status"], r["v21"]["q_par"],
            r["q_perp_true"], r["v02"]["q_perp"], r["v21"]["q_perp"]] for r in d["rows"]]))
    A("\nThese distributions are outside the closure family: a 12-moment closure cannot reproduce their q exactly. Recorded, not graded.")
    for key in ["D05", "D06"]:
        d = T[key]; A(f"\n## {key} — {d['name']}\n"); A("```"); A(json.dumps({k: v for k, v in d.items() if k not in ("name",)}, indent=1, default=str)); A("```")
    for key in ["D07", "D08", "D09", "D10", "D11"]:
        d = T[key]; A(f"\n## {key} — {d['name']}\n"); A("```"); A(json.dumps({k: v for k, v in d.items() if k not in ("name",)}, indent=1, default=str)); A("```")
    if g:
        A("\n## GPU legs\n")
        for k, v in g.items():
            A(f"**{k} — {v['name']}**\n"); A("```"); A(json.dumps({kk: vv for kk, vv in v.items() if kk != "name"}, indent=1, default=str)); A("```")
    else:
        A("\n## GPU legs\nNot run here (no CUDA device). Run `python study_gyro.py` on a CUDA machine (Colab) for G01-G04.")
    p = plots(R, here)
    if p: A(f"\n![study]({p})")
    A(f"\n---\nRuntime {m.get('runtime_s', 0):.0f} s · thresholds: `{json.dumps(m['thresholds'])}`")
    open(os.path.join(here, "GYRO_STUDY_REPORT.md"), "w").write("\n".join(L) + "\n")


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "gyro_study_results.json"))
    build(json.load(open(os.path.join(here, "gyro_study_results.json"))), here)
