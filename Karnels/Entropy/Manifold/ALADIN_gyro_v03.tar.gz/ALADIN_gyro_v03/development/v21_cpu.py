# -*- coding: utf-8 -*-
"""Run the frozen v2.1 gyro kernel source on CPU (g++) or GPU (CuPy) for side-by-side comparison.

CPU path: the CUDA source text is taken verbatim from gyro_v21.py and compiled by g++ with shims for the CUDA keywords.
The one semantic emulation: the shared-memory quadrature load (done by threads 0..15 / 0..11 of a block) is replaced by
a full copy, i.e. the CPU path reproduces a FULL block.  The partial-last-block defect therefore cannot appear on CPU;
it is exercised only on the GPU (test G03).
"""
import ctypes, hashlib, os, re, subprocess, tempfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_FILE = os.path.join(HERE, "gyro_v21.py")


def kernel_source():
    t = open(SRC_FILE).read()
    return re.search(r'cp\.RawKernel\(r"""(.*?)""", "gyrotropic_12_kernel"\)', t, re.S).group(1)


SHIM = r"""
#include <cmath>
#include <algorithm>
using namespace std;
struct float4 { float x, y, z, w; };
struct dim3_ { int x; };
static dim3_ blockIdx, threadIdx, blockDim;
#define __device__ static inline
#define __forceinline__
#define __constant__ static const
#define __shared__ static
#define __global__
#define __launch_bounds__(a,b)
#define __syncthreads()
#define __expf expf
"""


def build():
    src = kernel_source()
    load = ("    if (threadIdx.x < 16) { s_np[threadIdx.x] = np[threadIdx.x]; s_wp[threadIdx.x] = wp[threadIdx.x]; }\n"
            "    if (threadIdx.x < 12) { s_nq[threadIdx.x] = nq[threadIdx.x]; s_wq[threadIdx.x] = wq[threadIdx.x]; }")
    assert src.count(load) == 1
    src = src.replace(load, "    for (int t = 0; t < 16; ++t) { s_np[t] = np[t]; s_wp[t] = wp[t]; }\n"
                            "    for (int t = 0; t < 12; ++t) { s_nq[t] = nq[t]; s_wq[t] = wq[t]; }")
    src = src.replace("__device__ __forceinline__", "__device__")
    src = SHIM + src + r"""
extern "C" void run_cpu(const float* M, const float* n, float* lam, float* n_out, float* up, float* pp, float* pe,
                        float* qp, float* qe, float* mg, float* Mr, int* st, int N, float mass, float vt, float ap, float ae) {
    blockDim.x = 64;
    for (int i = 0; i < N; ++i) { blockIdx.x = i / 64; threadIdx.x = i % 64;
        gyrotropic_12_kernel(M, n, lam, n_out, up, pp, pe, qp, qe, mg, Mr, st, N, mass, vt, ap, ae); }
}
"""
    h = hashlib.sha256(src.encode()).hexdigest()[:12]
    d = os.path.join(tempfile.gettempdir(), "gyro_v21_" + h); os.makedirs(d, exist_ok=True)
    so = os.path.join(d, "v21.so")
    if not os.path.exists(so):
        open(os.path.join(d, "v21.cpp"), "w").write(src)
        r = subprocess.run(["g++", "-O2", "-shared", "-fPIC", "-o", so, os.path.join(d, "v21.cpp")], capture_output=True, text=True)
        if r.returncode: raise RuntimeError(r.stderr)
    return ctypes.CDLL(so)


_lib = None


def run_v21(M_target, n_in, lambda_init=None, mass=1.0, thermal_scale=1.0, alpha_par=0.5, alpha_perp=0.5, backend="cpu"):
    N = M_target.shape[0]
    lam = np.zeros((N, 12), np.float32) if lambda_init is None else np.array(lambda_init, np.float32)
    if lambda_init is None: lam[:, 6] = lam[:, 8] = lam[:, 10] = -0.05      # the v2.1 self-test initialisation
    if backend == "cupy":
        import cupy as cp, importlib.util
        spec = importlib.util.spec_from_file_location("gyro_v21", SRC_FILE); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        lam_d = cp.asarray(lam)
        o = m.launch_gyro(cp.asarray(M_target, dtype=cp.float32), cp.asarray(n_in, dtype=cp.float32), lam_d,
                          mass=mass, thermal_scale=thermal_scale, alpha_par=alpha_par, alpha_perp=alpha_perp)
        o = [x.get() for x in o]
    else:
        global _lib
        if _lib is None: _lib = build()
        M = np.ascontiguousarray(M_target, np.float32); n = np.ascontiguousarray(n_in, np.float32)
        o = [np.zeros(N, np.float32) for _ in range(7)] + [np.zeros((N, 12), np.float32), np.zeros(N, np.int32)]
        p = lambda a: a.ctypes.data_as(ctypes.c_void_p)
        _lib.run_cpu(p(M), p(n), p(lam), *[p(a) for a in o], ctypes.c_int(N), ctypes.c_float(mass), ctypes.c_float(thermal_scale),
                     ctypes.c_float(alpha_par), ctypes.c_float(alpha_perp))
    keys = ["n", "upar", "Ppar", "Pperp", "qpar", "qperp", "margin", "M_recon", "status"]
    return dict(zip(keys, o))


if __name__ == "__main__":
    import importlib.util
    spec = importlib.util.spec_from_file_location("g", SRC_FILE); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    Mb = m.compute_base_moments()
    o = run_v21(np.tile(Mb, (128, 1)), np.ones(128))
    print("v2.1 own self-test on CPU: status", np.unique(o["status"]), "max|Mrec-M|", np.abs(o["M_recon"] - Mb).max(),
          "Ppar", o["Ppar"][0], "Pperp", o["Pperp"][0])
