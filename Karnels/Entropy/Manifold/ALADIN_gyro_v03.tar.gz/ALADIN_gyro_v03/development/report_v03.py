# -*- coding: utf-8 -*-
"""Report builder for the gyro v03 study: every number comes from v03_study_results.json."""
import json, os, sys


def f(x, p=3):
    if x is None: return "n/a"
    if isinstance(x, float): return f"{x:.{p - 1}e}" if (x != 0 and (abs(x) < 1e-2 or abs(x) >= 1e4)) else f"{x:.{p}g}"
    return str(x)


def tbl(head, rows):
    return "\n".join(["| " + " | ".join(head) + " |", "|" + "|".join("---" for _ in head) + "|"] + ["| " + " | ".join(f(c) for c in r) + " |" for r in rows])


def plots(R, here):
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, numpy as np
    except Exception:
        return None
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    p = R["tests"]["E02"]["plot"]; t = np.array(p["true"]); lim = 1.1 * np.abs(t).max()
    ax[0].plot([-lim, lim], [-lim, lim], "k:", lw=1); ax[0].scatter(t, p["v03"], s=18, c="C0")
    ax[0].set_xlabel("q_par / T^1.5, continuum oracle"); ax[0].set_ylabel("q_par / T^1.5, gyro v03"); ax[0].set_title("Exact family members (own drift frame)")
    rows = R["tests"]["E03"]["rows"]; beams = [r for r in rows if r["case"]["kind"] == "two-beam"]
    lab = [f"{r['case']['frac']}/{r['case']['u2']:g}" for r in beams]; xx = np.arange(len(beams))
    ax[1].bar(xx - 0.2, [r["q_par_true"] for r in beams], 0.4, label="true", color="0.6")
    ax[1].bar(xx + 0.2, [r["q_par64"] for r in beams], 0.4, label="v03", color="C0")
    ax[1].set_xticks(xx); ax[1].set_xticklabels(lab, rotation=45); ax[1].set_xlabel("beam fraction / beam speed"); ax[1].set_ylabel("q_par / T^1.5")
    ax[1].set_title("Two-beam heat flux (outside the family)"); ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(here, "v03_study.png"), dpi=130); return "v03_study.png"


def build(R, here):
    m, T, g = R["meta"], R["tests"], R.get("gpu", {})
    L = []; A = L.append
    A("# ALADIN gyro v03 — development study")
    A(f"*Generated from `v03_study_results.json` · {m['utc']} · {m['platform']} · GPU: {m['gpu']}*\n")
    A("Development study before the freeze of v03. Oracle: continuous distributions integrated in FP64, independent of the kernel lattice; "
      "exact family members are built on the continuum in their own drift frame.\n")
    A(tbl(["Item", "Value"], [["gyro_v03.py SHA-256", f"`{m['v03_file_sha256']}`"], ["kernel source SHA-256", f"`{m['v03_source_sha256']}`"],
                              ["lattice", m["lattice"]], ["oracle SHA-256", f"`{m['oracle_sha256']}`"]]))
    A("\n## Verdicts\n")
    A(tbl(["Test", "What", "Verdict"], [[k, v["name"], v["verdict"]] for k, v in sorted(T.items())] + [[k, v["name"], v.get("verdict", "RECORDED")] for k, v in g.items()]))
    rows = T["E03"]["rows"]
    A("\n## E03 — physics cases\n")
    A(tbl(["case", "q_par true", "v03 FP64", "v03 FP32", "status 64/32", "resid", "Newton its"],
          [[" ".join(f"{k}={v}" for k, v in r["case"].items()), r["q_par_true"], r["q_par64"], r["q_par32"], f"{r['st64']}/{r['st32']}", r["resid64"], r["iters64"]] for r in rows]))
    for k in sorted(T):
        if k == "E03": continue
        d = T[k]; A(f"\n## {k} — {d['name']}\n"); A("```"); A(json.dumps({kk: vv for kk, vv in d.items() if kk not in ("name", "plot")}, indent=1, default=str)); A("```")
    if g:
        A("\n## GPU legs\n")
        for k, v in g.items(): A(f"**{k} — {v['name']}**\n"); A("```"); A(json.dumps({kk: vv for kk, vv in v.items() if kk != "name"}, indent=1, default=str)); A("```")
    else:
        A("\n## GPU legs\nNot run here (no CUDA device): run `python study_v03.py` on a CUDA machine.")
    p = plots(R, here)
    if p: A(f"\n![study]({p})")
    A(f"\n---\nRuntime {m.get('runtime_s', 0):.0f} s · thresholds `{json.dumps(m['thresholds'])}`")
    open(os.path.join(here, "V03_STUDY_REPORT.md"), "w").write("\n".join(L) + "\n")


if __name__ == "__main__":
    build(json.load(open(sys.argv[1] if len(sys.argv) > 1 else "v03_study_results.json")), os.getcwd())
