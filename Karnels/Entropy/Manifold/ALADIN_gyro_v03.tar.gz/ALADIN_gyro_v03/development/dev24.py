# development measurements at the 24x16 lattice, used to set the certification thresholds (kept as evidence)
import numpy as np, pickle, time, json, gyro_v03 as G, study_v03 as SV, oracle as O
out = {}
fc = pickle.load(open('/tmp/claude-0/fc.pkl', 'rb'))
for dt in (np.float64, np.float32):
    r = SV.run(fc, dt); a, b = SV.qn(r, fc)
    out[f'family_{np.dtype(dt).name}'] = dict(status=np.unique(r['status']).tolist(), qpar_med=float(np.median(a)), qpar_max=float(a.max()), qperp_med=float(np.median(b)), qperp_max=float(b.max()), resid_max=float(r['resid'].max()))
pc = SV.physics_cases(); r = SV.run(pc, np.float64)
out['beams'] = [(c['key']['frac'], c['key']['u2'], round(float(r['q_par'][i] / c['V'] ** 1.5), 4), round(float(c['q_par'] / c['V'] ** 1.5), 4), int(r['status'][i])) for i, c in enumerate(pc) if c['key']['kind'] == 'two-beam']
out['kappa_max_q'] = float(max(abs(r['q_par'][i]) / c['V'] ** 1.5 for i, c in enumerate(pc) if c['key']['kind'] == 'kappa'))
D = np.load('/tmp/claude-0/stressS.npy'); u, V, Q, S = D[:, 0], D[:, 1], D[:, 2], D[:, 3:]
a = G.run_gyro(np.ones(len(S)), u, V, Q / 2, S, dtype=np.float32, backend='cpu')
c = G.run_gyro(np.ones(len(S)), u, V, Q / 2, S, dtype=np.float64, backend='cpu')
dl = lambda r: np.isin(r['status'], [0, 4])
out['stress'] = dict(rescued=a['rescued'], delivered32=float(dl(a).mean()), delivered64=float(dl(c).mean()), agree=float(np.mean(dl(a) == dl(c))), dq=float(np.max(np.abs(a['q_par'] - c['q_par']) / V ** 1.5)), adm_min=float(c['adm'][dl(c)].min()))
# mirror antisymmetry c -> -c : odd shape moments flip sign
Sf = S.copy(); Sf[:, [1, 4, 5, 9]] *= -1
m = G.run_gyro(np.ones(len(S)), -u, V, Q / 2, Sf, dtype=np.float64, backend='cpu')
both = dl(c) & dl(m)
out['mirror'] = dict(delivery_agree=float(np.mean(dl(c) == dl(m))), max_q_sum=float(np.max(np.abs(c['q_par'] + m['q_par'])[both] / V[both] ** 1.5)), max_qperp_sum=float(np.max(np.abs(c['q_perp'] + m['q_perp'])[both])))
rng = np.random.default_rng(11); base = SV.run(fc, np.float64); sc = np.array([x['V'] ** 1.5 for x in fc])
noisy = [dict(x, S=np.concatenate([x['S'][:4], x['S'][4:] * (1 + 1e-3 * rng.standard_normal(8))])) for x in fc]
rn = SV.run(noisy, np.float64); out['noise_amp_median'] = float(np.median(np.abs(rn['q_par'] - base['q_par']) / sc) / 1e-3)
t = time.time(); SV.run(fc * 30, np.float32); out['cpu_us_per_cell'] = 1e6 * (time.time() - t) / (30 * len(fc))
print(json.dumps(out, indent=1)); json.dump(out, open('dev24_measurements.json', 'w'), indent=1)
