# -*- coding: utf-8 -*-
"""
ALADIN gyro kernel v02 — gyrotropic 12-feature maximum-entropy closure, Admissible By Construction (ABC)

Successor of "ALADIN Plasma Drive v2.1" (2026-11-10-16x12-baseline). Same feature basis, same tied quartic
parametrisation (eta, zeta, s) and the same 9-parameter Gauss-Newton / Levenberg-Marquardt solver.  What changed:

  ABC-1  positivity      f = w_ref * exp(lambda . phi) > 0 on a lattice of strictly positive weights      (as v2.1)
  ABC-2  integrability   tied quartic block is negative definite for every parameter value: the continuous
                         closure is integrable with all moments finite                                     (as v2.1)
  ABC-3  realizability   every output moment is a moment of one positive measure, so P_par, P_perp > 0 and
                         the Hankel condition  kurt - 1 - skew^2 >= 0  holds; reported per cell as `adm`  (new: certified)
  ABC-4  consistency     n, u_par, P_par, P_perp returned are EXACTLY the fluid input moments, for every cell
                         and every status: the closure distribution is pushed forward by an affine map that
                         fixes them, so it only supplies q_par, q_perp                                     (new)
  ABC-6  well-balanced   the lattice's quadrature error on the cell's reference bi-Maxwellian (exact moments: 1-D
                         trapezoid in c_par, closed form with E1 in c_perp) is removed from the target: a drifting
                         anisotropic bi-Maxwellian of any temperature returns lambda = 0, q = 0                      (new)
  ABC-5  resolution      the velocity lattice is a Gauss-Hermite (c_par) x Gauss-Laguerre (c_perp^2) rule
                         centred on u_par and scaled by the cell's own T_par, T_perp: a bi-Maxwellian is
                         reproduced exactly (q = 0) at any drift and any anisotropy                         (new)
  fix    the v2.1 bounds check before __syncthreads() left shared-memory quadrature nodes uninitialised in a
         partial last block (Ncells % 64 in 1..15).  v02 uses no shared memory and no barrier.
  also   covariance accumulated centred (two-pass) — no E[pp]-E[p]E[p] cancellation; accurate exp (no __expf);
         FP32 and FP64 builds; one source compiled by NVRTC (GPU) and g++ (CPU), so both legs run the same code.

Input convention (unchanged from v2.1): M_target[:, k] = < phi_k(c) > with c = v / thermal_scale,
  phi = [1, c, c2, c^2, c/(1+c^2), c c2/(1+c2), c2^2, c^2 c2, c^4, c^3/(1+c^2)^2, c2^3/(1+c2), c^2 c2^2/(1+c2)]
  where c = c_par, c2 = c_perp^2.  Low moments used: u = M1, var_par = M3 - M1^2, <c_perp^2> = M2.

status: 0 exact moment match (max residual < res_tol, in units of each feature's standard deviation) | 4 least-squares
        stationary point (step < STEP_TOL; residual below accept_tol, reported in resid), q delivered | 1 max iterations | 2 Cholesky | 3 line search | 5 invalid input
        6 moment failure | 7 tail certificate.  For status != 0 (valid input) the output is the exact
        bi-Maxwellian with the input moments and q = 0.  For status 5 nothing admissible exists: adm = -1.
"""
import os, hashlib, ctypes, subprocess, tempfile
import numpy as np

VERSION = "gyro_v02 2026-11-19"
N_FEAT, N_FREE = 12, 9
NP, NQ = int(os.environ.get('GYRO_NPAR', 16)), int(os.environ.get('GYRO_NPER', 12))
ETA_INIT = float(os.environ.get('GYRO_ETA_INIT', -4))
SCALE = np.array([1, 1, 1, 1, 1, 1, 3, 2, 3, 1, 4, 3], dtype=np.float64)

SRC = r"""
#ifdef GYRO_GPU
  #define DEV __device__ __forceinline__
#else
  #include <cmath>
  using namespace std;
  #define DEV static inline
#endif
typedef REAL R;
#define N_FEAT 12
#define N_FREE 9
#ifndef NPAR
#define NPAR 16
#endif
#ifndef NPER
#define NPER 12
#endif
#define ETA_MIN R(-10)
#define ETA_MAX R(3)
#ifndef STEP_TOL
#define STEP_TOL (sizeof(R) == 8 ? R(1e-7) : R(1e-5))
#endif
#define S_MAX R(0.95)
#ifndef ETA_SNAP
#define ETA_SNAP R(-8)
#endif
#ifndef ETA_INIT
#define ETA_INIT R(-4)
#endif

DEV void eval_phi(R c, R c2, R* p) {
    R cc = c*c, cc2 = cc*c, cc4 = cc*cc, q4 = c2*c2, q6 = q4*c2;
    R idp = R(1)/(R(1)+cc), ide = R(1)/(R(1)+c2);
    p[0]=R(1); p[1]=c; p[2]=c2; p[3]=cc; p[4]=c*idp; p[5]=c*c2*ide;
    p[6]=q4; p[7]=cc*c2; p[8]=cc4; p[9]=cc2*idp*idp; p[10]=q6*ide; p[11]=cc*q4*ide;
}


// free parameters (eta, zeta, xi, low[6]) -> lambda[12]; quartic block tied: negative definite for all values
// quartic block in units of the cell's own V = var_par and Q = <c_perp^2> (scale-free; physical lambda returned)
DEV void set_from_free(R eta, R zeta, R xi, const R* low, R V, R Q, R* L) {
    R a = exp(eta)/V, b = exp(zeta)/Q, s = xi;   // xi is the cross-term coefficient s itself, boxed in [-S_MAX, S_MAX]
    L[0]=R(0); L[1]=low[0]; L[2]=low[1]; L[3]=low[2]; L[4]=low[3]; L[5]=low[4]; L[9]=low[5];
    L[6]=L[10]=R(-0.5)*b*b; L[7]=L[11]=-a*b*s; L[8]=-a*a;
}

DEV void extract_free(const R* L, R V, R Q, R* eta, R* zeta, R* xi, R* low) {
    R A = fmax(-L[8]*V*V, R(1e-20)), B = fmax(R(-2)*L[6]*Q*Q, R(1e-20));
    *eta  = fmax(fmin(R(0.5)*log(A), ETA_MAX), ETA_MIN);
    *zeta = fmax(fmin(R(0.5)*log(B), ETA_MAX), ETA_MIN);
    R ab = fmax(exp(*eta)*exp(*zeta), R(1e-30));
    R l7s = L[7]*V*Q;
    *xi = fmax(fmin(-l7s/ab, S_MAX), -S_MAX);
    low[0]=L[1]; low[1]=L[2]; low[2]=L[3]; low[3]=L[4]; low[4]=L[5]; low[5]=L[9];
}

// certificate: smallest/largest eigenvalue of the asymptotic quartic form [[a^2, ab s],[ab s, b^2]] (> 0 by construction)
DEV R tail_margin(R eta, R zeta, R xi) {
    R a2 = exp(R(2)*eta), b2 = exp(R(2)*zeta), s = xi;
    R tr = a2 + b2, det = a2*b2*(R(1)-s*s);
    R disc = sqrt(fmax((a2-b2)*(a2-b2) + R(4)*a2*b2*s*s, R(0)));
    R lmax = R(0.5)*(tr + disc);
    return (lmax > R(0)) ? det/(lmax*lmax) : R(0);
}

DEV void jacobian(R eta, R zeta, R xi, R V, R Q, R* J) {
    for (int i = 0; i < N_FEAT*N_FREE; ++i) J[i] = R(0);
    R a = exp(eta)/V, b = exp(zeta)/Q, s = xi, ds = R(1);
    J[8*N_FREE+0] = R(-2)*a*a;
    J[6*N_FREE+1] = J[10*N_FREE+1] = -b*b;
    J[7*N_FREE+0] = J[11*N_FREE+0] = -a*b*s;
    J[7*N_FREE+1] = J[11*N_FREE+1] = -a*b*s;
    J[7*N_FREE+2] = J[11*N_FREE+2] = -a*b*ds;
    J[1*N_FREE+3]=R(1); J[2*N_FREE+4]=R(1); J[3*N_FREE+5]=R(1); J[4*N_FREE+6]=R(1); J[5*N_FREE+7]=R(1); J[9*N_FREE+8]=R(1);
}

DEV R objective(const R* M, const R* Mt, const R* sc) {
    R o = R(0);
    for (int k = 1; k < N_FEAT; ++k) { R r = (M[k]-Mt[k])/sc[k]; o += R(0.5)*r*r; }
    return o;
}
DEV R max_resid(const R* M, const R* Mt, const R* sc) {
    R m = R(0);
    for (int k = 1; k < N_FEAT; ++k) m = fmax(m, fabs((M[k]-Mt[k])/sc[k]));
    return m;
}

// moments of the discrete measure w_ij exp(lambda.phi(c_i, q_j)); G (if non-null) = centred covariance (two-pass)
DEV bool moments(const R* L, const R* cpar, const R* wpar, const R* cper, const R* wper, R* M, R* G) {
    R p[N_FEAT], maxe = R(-1e30);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_phi(cpar[i], cper[j], p); R e = R(0);
        for (int k = 0; k < N_FEAT; ++k) e += L[k]*p[k];
        maxe = fmax(maxe, e);
    }
    R Z = R(0);
    for (int k = 0; k < N_FEAT; ++k) M[k] = R(0);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_phi(cpar[i], cper[j], p); R e = R(0);
        for (int k = 0; k < N_FEAT; ++k) e += L[k]*p[k];
        R w = wpar[i]*wper[j]*exp(e - maxe); Z += w;
        for (int k = 0; k < N_FEAT; ++k) M[k] += w*p[k];
    }
    if (!(Z > R(0)) || !isfinite(Z)) return false;
    for (int k = 0; k < N_FEAT; ++k) M[k] /= Z;
    if (G) {
        for (int k = 0; k < N_FEAT*N_FEAT; ++k) G[k] = R(0);
        for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
            eval_phi(cpar[i], cper[j], p); R e = R(0);
            for (int k = 0; k < N_FEAT; ++k) e += L[k]*p[k];
            R w = wpar[i]*wper[j]*exp(e - maxe)/Z;
            for (int k = 0; k < N_FEAT; ++k) p[k] -= M[k];
            for (int a = 1; a < N_FEAT; ++a) for (int b = 1; b <= a; ++b) G[a*N_FEAT+b] += w*p[a]*p[b];
        }
        for (int a = 1; a < N_FEAT; ++a) for (int b = 1; b < a; ++b) G[b*N_FEAT+a] = G[a*N_FEAT+b];
    }
    return true;
}

// central moments of the solved distribution: mean, var_par, <c_perp^2>, mu3, mu4, <(c-u) c_perp^2>
DEV bool central(const R* L, const R* cpar, const R* wpar, const R* cper, const R* wper, R* out6) {
    R p[N_FEAT], maxe = R(-1e30);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_phi(cpar[i], cper[j], p); R e = R(0);
        for (int k = 0; k < N_FEAT; ++k) e += L[k]*p[k];
        maxe = fmax(maxe, e);
    }
    R Z = R(0), m1 = R(0), q2 = R(0);
    for (int pass = 0; pass < 2; ++pass) {
        R v = R(0), m3 = R(0), m4 = R(0), mix = R(0);
        for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
            eval_phi(cpar[i], cper[j], p); R e = R(0);
            for (int k = 0; k < N_FEAT; ++k) e += L[k]*p[k];
            R w = wpar[i]*wper[j]*exp(e - maxe);
            if (pass == 0) { Z += w; m1 += w*cpar[i]; q2 += w*cper[j]; }
            else { R d = cpar[i] - m1, d2 = d*d; v += w*d2; m3 += w*d2*d; m4 += w*d2*d2; mix += w*d*cper[j]; }
        }
        if (pass == 0) { if (!(Z > R(0)) || !isfinite(Z)) return false; m1 /= Z; q2 /= Z; }
        else { out6[0]=m1; out6[1]=v/Z; out6[2]=q2; out6[3]=m3/Z; out6[4]=m4/Z; out6[5]=mix/Z; }
    }
    return isfinite(out6[1]) && out6[1] > R(0) && out6[2] > R(0);
}

DEV bool chol9(R* H, const R* rhs, R* dx) {
    R Lc[N_FREE*N_FREE], y[N_FREE];
    for (int i = 0; i < N_FREE*N_FREE; ++i) Lc[i] = R(0);
    for (int i = 0; i < N_FREE; ++i) for (int j = 0; j <= i; ++j) {
        R s = H[i*N_FREE+j];
        for (int k = 0; k < j; ++k) s -= Lc[i*N_FREE+k]*Lc[j*N_FREE+k];
        if (i == j) { if (!(s > R(0))) return false; Lc[i*N_FREE+i] = sqrt(s); }
        else Lc[i*N_FREE+j] = s/Lc[j*N_FREE+j];
    }
    for (int i = 0; i < N_FREE; ++i) { R s = rhs[i]; for (int k = 0; k < i; ++k) s -= Lc[i*N_FREE+k]*y[k]; y[i] = s/Lc[i*N_FREE+i]; }
    for (int i = N_FREE-1; i >= 0; --i) { R s = y[i]; for (int k = i+1; k < N_FREE; ++k) s -= Lc[k*N_FREE+i]*dx[k]; dx[i] = s/Lc[i*N_FREE+i]; }
    return true;
}

// ---- well-balanced reference: exact feature moments of the bi-Maxwellian N(u,V) x Exp(<c_perp^2> = Q) ----
// e^x E1(x): series for x <= 1, Lentz continued fraction for x > 1
DEV R expE1(R x) {
    if (x <= R(1)) {
        R s = R(0), t = R(1);
        for (int k = 1; k < 40; ++k) { t *= -x/R(k); s += t/R(k); }
        return exp(x)*(R(-0.57721566490153286) - log(x) - s);
    }
    R b = x + R(1), c = R(1e30), d = R(1)/b, h = d;
    for (int i = 1; i < 200; ++i) {
        R an = -R(i)*R(i); b += R(2);
        d = R(1)/(an*d + b); c = b + an/c; R del = c*d; h *= del;
        if (fabs(del - R(1)) < R(1e-15)) break;
    }
    return h;
}
#define NREF 512
DEV void reference_moments(R u, R V, R Q, R* Mr) {
    // parallel: 1-D trapezoid in x = (c-u)/sqrt(V) on [-12, 12]; geometric convergence for the poles at c = +-i
    R sv = sqrt(V), h = R(24)/R(NREF-1), Z = R(0), e1 = R(0), e2 = R(0), e4 = R(0), r1 = R(0), r3 = R(0);
    for (int i = 0; i < NREF; ++i) {
        R x = R(-12) + h*R(i), w = exp(R(-0.5)*x*x), c = u + sv*x, cc = c*c, idp = R(1)/(R(1)+cc);
        Z += w; e1 += w*c; e2 += w*cc; e4 += w*cc*cc; r1 += w*c*idp; r3 += w*cc*c*idp*idp;
    }
    e1 /= Z; e2 /= Z; e4 /= Z; r1 /= Z; r3 /= Z;
    // perpendicular: closed form with J = E[1/(1+c_perp^2)] = e^{1/Q} E1(1/Q) / Q
    R J = expE1(R(1)/Q)/Q;
    Mr[0] = R(1); Mr[1] = e1; Mr[2] = Q; Mr[3] = e2; Mr[4] = r1; Mr[5] = e1*(R(1)-J);
    Mr[6] = R(2)*Q*Q; Mr[7] = e2*Q; Mr[8] = e4; Mr[9] = r3; Mr[10] = R(2)*Q*Q - Q + R(1) - J; Mr[11] = e2*(Q - R(1) + J);
}

DEV void gyro_cell(int idx, const R* Mt_all, const R* n_in, R* lam_io,
                   R* n_out, R* u_out, R* ppar_out, R* pper_out, R* qpar_out, R* qper_out,
                   R* margin_out, R* adm_out, R* res_out, R* M_recon, int* status,
                   const R* xn, const R* xw, const R* en, const R* ew,
                   R mass, R vth, R res_tol, R accept_tol, int max_newton, int warm)
{
    R Mt[N_FEAT];
    for (int k = 0; k < N_FEAT; ++k) Mt[k] = Mt_all[idx*N_FEAT + k];
    R* lo = lam_io + idx*N_FEAT;
    R n = n_in[idx];
    R u = Mt[1], V = Mt[3] - Mt[1]*Mt[1], Q = Mt[2];
    int flag = 0;
    bool finite_in = isfinite(n);
    for (int k = 0; k < N_FEAT; ++k) finite_in = finite_in && isfinite(Mt[k]);
    if (!finite_in || !(n > R(0)) || !(mass > R(0)) || !(vth > R(0)) || !(V > R(1e-12)) || !(Q > R(1e-12))) flag = 5;

    // ABC-5: lattice adapted to this cell (Gauss-Hermite in c_par about u, Gauss-Laguerre in c_perp^2)
    R cpar[NPAR], cper[NPER];
    if (flag == 5) { u = R(0); V = R(1); Q = R(1); }
    R sp = sqrt(V);
    for (int i = 0; i < NPAR; ++i) cpar[i] = u + sp*xn[i];
    for (int j = 0; j < NPER; ++j) cper[j] = Q*en[j];

    // dimensionless residual scale: each feature's standard deviation under the cell's reference bi-Maxwellian
    R L[N_FEAT], M[N_FEAT], G[N_FEAT*N_FEAT], sc[N_FEAT];
    for (int k = 0; k < N_FEAT; ++k) L[k] = R(0);
    moments(L, cpar, xw, cper, ew, M, G);
    for (int k = 0; k < N_FEAT; ++k) sc[k] = fmax(sqrt(fmax(G[k*N_FEAT+k], R(0))), R(1e-30));
    sc[0] = R(1);
    // ABC-6 well-balanced: remove the lattice's own quadrature error of the reference bi-Maxwellian from the target,
    // so a bi-Maxwellian input is reproduced with lambda = 0 and q = 0 exactly (symmetric nodes about u)
    if (flag == 0) {
        R Mref[N_FEAT];
        reference_moments(u, V, Q, Mref);
        for (int k = 1; k < N_FEAT; ++k) Mt[k] -= (Mref[k] - M[k]);
    }

    R eta = ETA_INIT, zeta = ETA_INIT, xi = R(0), low[6] = {0,0,0,0,0,0};
    if (flag == 0) {
        R L0[N_FEAT], M0[N_FEAT];
        set_from_free(ETA_MIN, ETA_MIN, R(0), low, V, Q, L0);
        if (moments(L0, cpar, xw, cper, ew, M0, (R*)0) && max_resid(M0, Mt, sc) < res_tol) { eta = ETA_MIN; zeta = ETA_MIN; }
    }
    if (warm && flag == 0) {
        bool ok = true; for (int k = 0; k < N_FEAT; ++k) ok = ok && isfinite(lo[k]);
        if (ok) extract_free(lo, V, Q, &eta, &zeta, &xi, low);
    }

    R lm = R(1e-3), res = R(-1);
    int chol_fails = 0, ls_fails = 0;
    bool conv = false, stationary = false;
    if (flag == 0) {
        for (int it = 0; it < max_newton; ++it) {
            set_from_free(eta, zeta, xi, low, V, Q, L);
            if (!moments(L, cpar, xw, cper, ew, M, G)) { flag = 6; break; }
            R obj = objective(M, Mt, sc);
            if (max_resid(M, Mt, sc) < res_tol) { conv = true; break; }
            R J[N_FEAT*N_FREE], H[N_FREE*N_FREE], rhs[N_FREE], dx[N_FREE];
            jacobian(eta, zeta, xi, V, Q, J);
            for (int a = 0; a < N_FREE*N_FREE; ++a) H[a] = R(0);
            for (int a = 0; a < N_FREE; ++a) rhs[a] = R(0);
            for (int i = 1; i < N_FEAT; ++i) {
                R ri = (M[i]-Mt[i])/sc[i], Di[N_FREE];
                for (int a = 0; a < N_FREE; ++a) {
                    R s = R(0);
                    for (int j = 1; j < N_FEAT; ++j) s += G[i*N_FEAT+j]*J[j*N_FREE+a];
                    Di[a] = s/sc[i]; rhs[a] += Di[a]*ri;
                }
                for (int a = 0; a < N_FREE; ++a) for (int b = 0; b < N_FREE; ++b) H[a*N_FREE+b] += Di[a]*Di[b];
            }
            R md = R(1e-30);
            for (int a = 0; a < N_FREE; ++a) md = fmax(md, H[a*N_FREE+a]);
            for (int a = 0; a < N_FREE; ++a) H[a*N_FREE+a] += lm*md + R(1e-30);
            if (!chol9(H, rhs, dx)) { lm *= R(4); if (++chol_fails > 4) { flag = 2; break; } continue; }
            {   // projected Gauss-Newton: freeze variables on an active bound (step pointing outward) and re-solve
                bool act[3];
                act[0] = (eta <= ETA_MIN && dx[0] > R(0)) || (eta >= ETA_MAX && dx[0] < R(0));
                act[1] = (zeta <= ETA_MIN && dx[1] > R(0)) || (zeta >= ETA_MAX && dx[1] < R(0));
                act[2] = (xi >= S_MAX && dx[2] < R(0)) || (xi <= -S_MAX && dx[2] > R(0)) || eta <= ETA_MIN || zeta <= ETA_MIN;
                if (act[0] || act[1] || act[2]) {
                    for (int i = 0; i < 3; ++i) if (act[i]) {
                        for (int j = 0; j < N_FREE; ++j) { H[i*N_FREE+j] = R(0); H[j*N_FREE+i] = R(0); }
                        H[i*N_FREE+i] = R(1); rhs[i] = R(0);
                    }
                    if (!chol9(H, rhs, dx)) { lm *= R(4); if (++chol_fails > 4) { flag = 2; break; } continue; }
                }
            }
            chol_fails = 0;
            R al = R(1); bool acc = false;
            for (int ls = 0; ls < 8; ++ls) {
                // projected step: quartic parameters clipped to their box (never rejected for leaving it)
                R e2 = fmin(fmax(eta - al*dx[0], ETA_MIN), ETA_MAX), z2 = fmin(fmax(zeta - al*dx[1], ETA_MIN), ETA_MAX), x2 = xi - al*dx[2];
                // a quartic that wants to vanish sits at eta -> -inf in this parametrisation: snap it onto the floor exactly
                if (e2 < ETA_SNAP) e2 = ETA_MIN;
                if (z2 < ETA_SNAP) z2 = ETA_MIN;
                x2 = fmin(fmax(x2, -S_MAX), S_MAX);
                if (e2 == ETA_MIN || z2 == ETA_MIN) x2 = xi;   // cross-term is a null direction once a factor vanishes
                R l2[6], L2[N_FEAT], M2[N_FEAT];
                for (int k = 0; k < 6; ++k) l2[k] = low[k] - al*dx[3+k];
                set_from_free(e2, z2, x2, l2, V, Q, L2);
                if (!moments(L2, cpar, xw, cper, ew, M2, (R*)0)) { al *= R(0.5); continue; }
                if (objective(M2, Mt, sc) < obj) {
                    // stationarity measured on the PHYSICAL multipliers (change of the exponent, feature by feature):
                    // parameter directions with no physical effect (e.g. xi when the quartic vanishes) cannot block it
                    R st = R(0);
                    for (int k = 1; k < N_FEAT; ++k) st = fmax(st, fabs(L2[k]-L[k])*sc[k]);
                    eta = e2; zeta = z2; xi = x2; for (int k = 0; k < 6; ++k) low[k] = l2[k]; acc = true;
                    if (st < STEP_TOL) stationary = true;
                    break;
                }
                al *= R(0.5);
            }
            if (!acc) { if (++ls_fails > 3) { flag = 3; break; } lm = fmin(lm*R(4), R(1e3)); }
            else { ls_fails = 0; lm = fmax(lm*R(0.3), R(1e-9)); if (stationary) break; }
            if (it == max_newton-1) flag = 1;
        }
    }

    R c6[6] = {0,0,0,0,0,0};
    R margin = tail_margin(eta, zeta, xi);
    if (flag != 5) {
        set_from_free(eta, zeta, xi, low, V, Q, L);
        bool okm = moments(L, cpar, xw, cper, ew, M, (R*)0);
        bool okc = okm && central(L, cpar, xw, cper, ew, c6);
        if (okm) res = max_resid(M, Mt, sc);
        if (!okm || !okc) flag = 6;
        else if (conv || res < res_tol) flag = 0;
        else if (stationary && res < accept_tol) flag = 4;   // genuine least-squares stationary point (step < STEP_TOL): q delivered
        else if (flag == 0) flag = 1;                         // stalled fits are NOT delivered: not reproducible across hardware
        if (!(margin > R(0)) && (flag == 0 || flag == 4)) flag = 7;
    }
    status[idx] = flag; margin_out[idx] = margin; res_out[idx] = res;
    for (int k = 0; k < N_FEAT; ++k) M_recon[idx*N_FEAT+k] = (flag != 5) ? M[k] : R(0);
    if (flag == 0 || flag == 4) for (int k = 0; k < N_FEAT; ++k) lo[k] = L[k];

    R v2 = vth*vth, v3 = v2*vth;
    n_out[idx] = n;
    if (flag == 5) {   // nothing admissible exists for these inputs: floor and flag it (adm = -1)
        R V0 = Mt[3] - Mt[1]*Mt[1], Q0 = Mt[2];
        R vp = (isfinite(V0) && V0 > R(1e-4)) ? V0 : R(1e-4), qq = (isfinite(Q0) && Q0 > R(1e-4)) ? Q0 : R(1e-4);
        R nn = (isfinite(n) && n > R(0)) ? n : R(0);
        u_out[idx] = isfinite(Mt[1]) ? Mt[1]*vth : R(0);
        ppar_out[idx] = mass*nn*v2*vp; pper_out[idx] = R(0.5)*mass*nn*v2*qq;
        qpar_out[idx] = R(0); qper_out[idx] = R(0); adm_out[idx] = R(-1);
        return;
    }
    // ABC-4: low moments are the fluid's, exactly, for every status
    u_out[idx] = u*vth; ppar_out[idx] = mass*n*v2*V; pper_out[idx] = R(0.5)*mass*n*v2*Q;
    if (flag == 0 || flag == 4) {   // pushforward c -> u + (c - u_r) k_par,  c_perp^2 -> c_perp^2 k_perp2
        R kp = sqrt(V/c6[1]), kq = Q/c6[2];
        qpar_out[idx] = mass*n*v3*c6[3]*kp*kp*kp;
        qper_out[idx] = R(0.5)*mass*n*v3*c6[5]*kp*kq;
        adm_out[idx] = c6[4]/(c6[1]*c6[1]) - R(1) - c6[3]*c6[3]/(c6[1]*c6[1]*c6[1]);   // ABC-3 Hankel margin (scale-free)
    } else {           // exact bi-Maxwellian with the input moments
        qpar_out[idx] = R(0); qper_out[idx] = R(0); adm_out[idx] = R(2);
    }
}

#ifdef GYRO_GPU
extern "C" __global__ void gyro_v02_kernel(const R* Mt, const R* n_in, R* lam, R* n_out, R* u_out, R* ppar, R* pper,
    R* qpar, R* qper, R* margin, R* adm, R* res, R* Mrec, int* status, const R* xn, const R* xw, const R* en, const R* ew,
    int Ncells, R mass, R vth, R res_tol, R accept_tol, int max_newton, int warm)
{
    int idx = blockIdx.x*blockDim.x + threadIdx.x;
    if (idx < Ncells)
        gyro_cell(idx, Mt, n_in, lam, n_out, u_out, ppar, pper, qpar, qper, margin, adm, res, Mrec, status,
                  xn, xw, en, ew, mass, vth, res_tol, accept_tol, max_newton, warm);
}
#else
extern "C" void gyro_v02_cpu(const R* Mt, const R* n_in, R* lam, R* n_out, R* u_out, R* ppar, R* pper,
    R* qpar, R* qper, R* margin, R* adm, R* res, R* Mrec, int* status, const R* xn, const R* xw, const R* en, const R* ew,
    int Ncells, R mass, R vth, R res_tol, R accept_tol, int max_newton, int warm)
{
    #pragma omp parallel for schedule(dynamic, 16)
    for (int idx = 0; idx < Ncells; ++idx)
        gyro_cell(idx, Mt, n_in, lam, n_out, u_out, ppar, pper, qpar, qper, margin, adm, res, Mrec, status,
                  xn, xw, en, ew, mass, vth, res_tol, accept_tol, max_newton, warm);
}
#endif
"""

SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()
OUT_NAMES = ["n", "upar", "Ppar", "Pperp", "qpar", "qperp", "margin", "adm", "resid"]


def lattice(dtype=np.float64):
    """Gauss-Hermite (weight exp(-x^2/2)) x Gauss-Laguerre (weight exp(-eta)), weights normalised to 1."""
    x, wx = np.polynomial.hermite_e.hermegauss(NP)
    e, we = np.polynomial.laguerre.laggauss(NQ)
    return [np.ascontiguousarray(a / (a.sum() if k % 2 else 1), dtype=dtype) for k, a in enumerate((x, wx, e, we))]


_cache = {}


def _cpu_lib(dtype):
    key = ("cpu", np.dtype(dtype).name)
    if key in _cache: return _cache[key]
    real = "double" if dtype == np.float64 else "float"
    d = os.path.join(tempfile.gettempdir(), f"gyro_v02_{SOURCE_SHA256[:12]}_{real}_{NP}x{NQ}_e{ETA_INIT}")
    os.makedirs(d, exist_ok=True)
    so = os.path.join(d, "gyro.so")
    if not os.path.exists(so):
        open(os.path.join(d, "gyro.cpp"), "w").write(SRC)
        cmd = ["g++", "-O2", "-shared", "-fPIC", "-fopenmp", f"-DREAL={real}", f"-DNPAR={NP}", f"-DNPER={NQ}", f"-DETA_INIT=R({ETA_INIT})", "-o", so, os.path.join(d, "gyro.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError("g++ build failed:\n" + r.stderr)
    lib = ctypes.CDLL(so); _cache[key] = lib; return lib


def _gpu_kernel(dtype):
    import cupy as cp
    key = ("gpu", np.dtype(dtype).name)
    if key in _cache: return _cache[key]
    real = "double" if dtype == np.float64 else "float"
    mod = cp.RawModule(code=SRC, options=("-DGYRO_GPU", f"-DREAL={real}", f"-DNPAR={NP}", f"-DNPER={NQ}", f"-DETA_INIT=R({ETA_INIT})", "-std=c++14"))
    k = mod.get_function("gyro_v02_kernel"); _cache[key] = k; return k


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


def run_gyro(M_target, n_in, lambda_io=None, mass=1.0, thermal_scale=1.0, res_tol=1e-5, accept_tol=0.25, max_newton=80,
             warm=False, backend="auto", dtype=np.float32, threads=64):
    """Run the closure on Ncells cells. M_target (Ncells,12), n_in (Ncells,). Arrays may be NumPy or CuPy.
    lambda_io (Ncells,12) is updated in place for converged cells (warm start with warm=True).
    Returns dict of outputs (same array module as the backend) + 'M_recon' and 'status'."""
    if backend == "auto": backend = "cupy" if has_gpu() else "cpu"
    N = int(M_target.shape[0])
    if backend == "cupy":
        import cupy as cp
        xp = cp
    else:
        xp = np
    Mt = xp.ascontiguousarray(xp.asarray(M_target, dtype=dtype)); n = xp.ascontiguousarray(xp.asarray(n_in, dtype=dtype))
    if lambda_io is None: lambda_io = xp.zeros((N, N_FEAT), dtype=dtype)
    assert lambda_io.dtype == np.dtype(dtype) and lambda_io.flags.c_contiguous
    outs = {k: xp.zeros(N, dtype=dtype) for k in OUT_NAMES}
    Mrec = xp.zeros((N, N_FEAT), dtype=dtype); status = xp.zeros(N, dtype=np.int32)
    lat = [xp.asarray(a) for a in lattice(dtype)]
    sc = np.float64 if dtype == np.float64 else np.float32
    args_arr = [Mt, n, lambda_io] + [outs[k] for k in ["n", "upar", "Ppar", "Pperp", "qpar", "qperp", "margin", "adm", "resid"]] + [Mrec, status] + lat
    if backend == "cupy":
        k = _gpu_kernel(dtype)
        k(((N + threads - 1) // threads,), (threads,),
          tuple(args_arr) + (np.int32(N), sc(mass), sc(thermal_scale), sc(res_tol), sc(accept_tol), np.int32(max_newton), np.int32(int(warm))))
        cp.cuda.runtime.deviceSynchronize()
    else:
        lib = _cpu_lib(dtype); ct = ctypes.c_double if dtype == np.float64 else ctypes.c_float
        ptr = lambda a: a.ctypes.data_as(ctypes.c_void_p)
        lib.gyro_v02_cpu(*[ptr(a) for a in args_arr], ctypes.c_int(N), ct(mass), ct(thermal_scale), ct(res_tol), ct(accept_tol),
                         ctypes.c_int(max_newton), ctypes.c_int(int(warm)))
    outs["M_recon"] = Mrec; outs["status"] = status
    return outs


def phi_numpy(c, c2):
    """Feature vector, NumPy (for oracles and targets)."""
    c = np.asarray(c, dtype=np.float64); c2 = np.asarray(c2, dtype=np.float64)
    idp = 1 / (1 + c * c); ide = 1 / (1 + c2)
    return np.stack([np.ones_like(c * c2), c + 0 * c2, c2 + 0 * c, c * c + 0 * c2, c * idp + 0 * c2, c * c2 * ide, c2 ** 2 + 0 * c,
                     c * c * c2, c ** 4 + 0 * c2, c ** 3 * idp * idp + 0 * c2, c2 ** 3 * ide + 0 * c, c * c * c2 ** 2 * ide], axis=0)


if __name__ == "__main__":
    # quick smoke test: drifting anisotropic bi-Maxwellians must give q = 0, status 0, low moments exact
    u, Tpar, Tper = 1.3, 0.4, 2.5
    c = np.linspace(u - 14 * Tpar ** .5, u + 14 * Tpar ** .5, 2001)[:, None]; cq = np.linspace(0, 14 * Tper ** .5, 2001)[None, :]
    W = np.exp(-(c - u) ** 2 / (2 * Tpar) - cq ** 2 / (2 * Tper)) * cq          # continuum target (dense trapezoid)
    M = (phi_numpy(c, cq ** 2) * W).sum(axis=(1, 2)) / W.sum()
    for be in (["cupy"] if has_gpu() else []) + ["cpu"]:
        for dt in (np.float32, np.float64):
            o = run_gyro(np.tile(M, (77, 1)), np.ones(77), backend=be, dtype=dt)
            g = lambda a: a.get() if hasattr(a, "get") else a
            print(f"{be:5s} {np.dtype(dt).name}: status {np.unique(g(o['status']))}  max|q_par| {np.abs(g(o['qpar'])).max():.2e}  "
                  f"Ppar {g(o['Ppar'])[0]:.6f} (exact {Tpar})  Pperp {g(o['Pperp'])[0]:.6f} (exact {Tper})  adm {g(o['adm'])[0]:.4f}")
    print("source sha256", SOURCE_SHA256)
