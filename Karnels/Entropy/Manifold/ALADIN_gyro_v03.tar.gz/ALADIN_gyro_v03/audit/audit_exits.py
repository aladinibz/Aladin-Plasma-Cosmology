# Audit B (reproducible): which exit ends the final barrier stage of every delivered cell, and is the returned point the optimum?
# Builds an exit-instrumented copy of the frozen kernel (serial; the kernel file is untouched), runs the GYRO-02 case set
# (40 family members, symmetric, kappa, beams, 1500 random mixtures), then polishes each answer with an independently written
# Newton solver in extended precision (np.longdouble) on the same lattice and targets, and compares q.
# Run: python audit_exits.py   (~10 min; needs g++ and scipy)
import sys, os, ctypes, subprocess, numpy as np, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..", "code"))
import gyro_v03 as G, campaign_gyro02 as C
C.G = G
src = G.SRC
rep = [("        if (dec < tol) { *ok_out = true; return it; }", "        if (dec < tol) { *ok_out = true; g_exit = 1; return it; }"),
       ("        if (!moved) { *ok_out = true; return it; }   // no representable decrease: converged to the build's precision", "        if (!moved) { *ok_out = true; g_exit = 2; return it; }"),
       ("        if (F0 - F1 <= R(8)*EPS_R*(R(1) + fabs(F0))) { *ok_out = true; return it; }", "        if (F0 - F1 <= R(8)*EPS_R*(R(1) + fabs(F0))) { *ok_out = true; g_exit = 3; return it; }"),
       ("    status[idx] = flag; iters[idx] = used; resid_out[idx] = res;", "    status[idx] = flag; iters[idx] = used; resid_out[idx] = res; g_exits[idx] = g_exit;")]
for a, b in rep:
    assert src.count(a) == 1, a[:50]; src = src.replace(a, b)
src = src.replace("typedef REAL R;", "typedef REAL R;\nstatic int g_exit = 0; static int* g_exits = 0;\nextern \"C\" void set_exits(int* p) { g_exits = p; }")
open(os.path.join(HERE, "exits.cpp"), "w").write(src)
for real in ("double", "float"):
    subprocess.run(["g++", "-O2", "-shared", "-fPIC", f"-DREAL={real}", "-DNPAR=24", "-DNPER=16", "-o", os.path.join(HERE, f"exits_{real}.so"), os.path.join(HERE, "exits.cpp")], check=True)
cases = C.family_cases() + C.symmetric_cases() + C.kappa_cases() + C.beam_cases() + C.stress_cases(1500); N = len(cases)
L = np.longdouble
xn, wx, sn, ws = G.lattice(); mu_c, isd_c = G._psi_constants(); delta = G.delta()
X = np.repeat(xn, len(sn)).astype(L); Sg = np.tile(sn, len(xn)).astype(L); W = np.outer(wx, ws).ravel().astype(L)
def psi_std(x, s):
    idp = 1 / (1 + x * x); ide = 1 / (1 + s)
    P = np.stack([x, s, x * x, x * idp, x * s * ide, x ** 3 * idp ** 2, x ** 4, s * s + s ** 3 * ide, x * x * s + x * x * s * s * ide])
    return (P - mu_c.astype(L)[:, None]) * isd_c.astype(L)[:, None]
PS = psi_std(X, Sg)
S2 = L(0.9025)
def barrier(t):
    a = -t[6] * L(isd_c[6]); b = -2 * t[7] * L(isd_c[7]); x = t[8] * L(isd_c[8]); g = S2 * a * b - x * x
    if a <= 0 or b <= 0 or g <= 0: return None
    da = np.zeros(9, L); da[6] = -L(isd_c[6]); db = np.zeros(9, L); db[7] = -2 * L(isd_c[7]); dx = np.zeros(9, L); dx[8] = L(isd_c[8])
    dg = S2 * (b * da + a * db) - 2 * x * dx
    val = -np.log(a) - np.log(b) - np.log(g); grad = -da / a - db / b - dg / g
    d2g = S2 * (np.outer(da, db) + np.outer(db, da)) - 2 * np.outer(dx, dx)
    H = np.outer(da, da) / a ** 2 + np.outer(db, db) / b ** 2 + np.outer(dg, dg) / g ** 2 - d2g / g
    return val, grad, H
def F_all(t, m, mu):
    e = t @ PS; mx = e.max(); w = W * np.exp(e - mx); Z = w.sum(); p = w / Z
    Ep = PS @ p; Cv = (PS * p) @ PS.T - np.outer(Ep, Ep); bv = barrier(t)
    return mx + np.log(Z) - t @ m + mu * bv[0], Ep - m + mu * bv[1], Cv + mu * bv[2], p
def qnorm(p):
    m1 = p @ X; d = X - m1; v = p @ d ** 2; return float((p @ d ** 3) / v ** 1.5)
def polish(t, m, mu, iters=60):
    dec = None
    for it in range(iters):
        F, g, H, p = F_all(t, m, mu); dx = np.linalg.solve(H.astype(np.float64), g.astype(np.float64)).astype(L)
        dec = float(g @ dx)
        if dec < 1e-26: break
        al = L(1)
        while True:
            t2 = t - al * dx
            if barrier(t2) is not None and F_all(t2, m, mu)[0] <= F - L(0.3) * al * L(dec): break
            al /= 2
            if al < 1e-30: return t, dec, it
        t = t2
    return t, dec, it
def dec_at(t, m, mu):
    F, g, H, p = F_all(t, m, mu); return float(g @ np.linalg.solve(H.astype(np.float64), g.astype(np.float64)).astype(L)), p
out = {}
for real, dt, mu_fin in (("double", np.float64, 1e-10), ("float", np.float32, 1e-6)):
    lib = ctypes.CDLL(os.path.join(HERE, f'exits_{real}.so')); ex = np.zeros(N, np.int32); lib.set_exits(ex.ctypes.data_as(ctypes.c_void_p))
    S = np.ascontiguousarray([c["S"] for c in cases], dt); u = np.array([c["u"] for c in cases], dt); V = np.array([c["V"] for c in cases], dt); Q = np.array([c["Q"] for c in cases], dt)
    th = np.zeros((N, 9), dt); o = {k: np.zeros(N, dt) for k in G.OUTS}; Mr = np.zeros((N, 12), dt); Mf = np.zeros((N, 12), dt)
    st = np.zeros(N, np.int32); its = np.zeros(N, np.int32); lat = [np.ascontiguousarray(a, dt) for a in G.lattice()] + [np.ascontiguousarray(delta, dt)]
    arrs = [np.ones(N, dt), u, V, Q / 2, S, th, o["q_par"], o["q_perp"], o["resid"], o["adm"], o["cone"], Mr, Mf, st, its] + lat
    pp = lambda a: a.ctypes.data_as(ctypes.c_void_p); ct = ctypes.c_double if dt == np.float64 else ctypes.c_float
    lib.gyro_v03_cpu(*[pp(a) for a in arrs], ctypes.c_int(N), ct(1), ct(1e-4 if dt == np.float64 else 2e-3), ctypes.c_int(40), ctypes.c_int(0))
    dl = np.isin(st, [0, 4])
    if dt == np.float32: dl &= (o["cone"] >= 1e-5) & (its <= 32)          # cells the default FP32 + rescue keeps in FP32
    rows = {}
    for i in np.where(dl)[0]:
        Sx = cases[i]["S"].astype(np.float64).copy(); Sx[:4] = [1, 0, 2, 1]; Mt = Sx - delta
        m_raw = np.array([Mt[1], Mt[2], Mt[3], Mt[4], Mt[5], Mt[9], Mt[8], Mt[6] + Mt[10], Mt[7] + Mt[11]])
        m = ((m_raw - mu_c) * isd_c).astype(L); t0 = (th[i].astype(np.float64) / isd_c).astype(L)
        d0, p0 = dec_at(t0, m, L(mu_fin)); t1, d1, k = polish(t0, m, L(mu_fin))
        q_ld = qnorm(F_all(t1, m, L(mu_fin))[3])
        r = rows.setdefault(int(ex[i]), dict(n=0, max_dq=0.0, max_dec_at_kernel_point=0.0, max_polish_steps=0))
        r["n"] += 1; r["max_dq"] = max(r["max_dq"], abs(float(o["q_par"][i]) / float(V[i]) ** 1.5 - q_ld))
        r["max_dec_at_kernel_point"] = max(r["max_dec_at_kernel_point"], d0); r["max_polish_steps"] = max(r["max_polish_steps"], k)
    names = {1: "Newton decrement < tolerance", 2: "no representable decrease (line search)", 3: "progress below the precision of F"}
    out[real] = {names.get(k, str(k)): v for k, v in sorted(rows.items())}
    print(f"\n{real}: delivered cells audited {int(dl.sum())}")
    for k, v in sorted(rows.items()): print(f"   exit {k} ({names.get(k)}): {v['n']} cells | max |q_kernel - q_extended| = {v['max_dq']:.1e} | max Newton decrement at the kernel's point {v['max_dec_at_kernel_point']:.1e} | polish steps <= {v['max_polish_steps']}")
out['kernel_sha256'] = __import__('hashlib').sha256(open(os.path.join(HERE, '..', 'code', 'gyro_v03.py'), 'rb').read()).hexdigest(); out['cells'] = N
json.dump(out, open(os.path.join(HERE, 'audit_exits.json'), 'w'), indent=1)
for f in ('exits.cpp', 'exits_double.so', 'exits_float.so'): os.remove(os.path.join(HERE, f))
