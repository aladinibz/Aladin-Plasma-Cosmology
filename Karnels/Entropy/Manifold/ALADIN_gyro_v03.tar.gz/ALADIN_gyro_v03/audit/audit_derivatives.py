import sys, os, ctypes, subprocess, numpy as np, hashlib, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..", "code")); import gyro_v03 as G
src = G.SRC
a = src.index("        R a, b, g; cone(th, &a, &b, &g);\n        R gr[NS], H[NS*NS], dg[NS], dx[NS];"); b = src.index("        // Jacobi scaling")
probe = src.split("#ifdef GYRO_GPU\nextern")[0] + r'''
extern "C" int probe_grad(const R* th, const R* m, R mu, const R* xn, const R* xw, const R* sn, const R* sw, R* gr_out, R* H_out, R* F_out) {
    R E[NS], C[NS*NS];
    if (!stats(th, xn, xw, sn, sw, E, C)) return -1;
''' + src[a:b] + r'''
    for (int k = 0; k < NS; ++k) gr_out[k] = gr[k];
    for (int k = 0; k < NS*NS; ++k) H_out[k] = H[k];
    *F_out = objective(th, m, mu, xn, xw, sn, sw);
    return 0;
}
extern "C" double probe_F(const R* th, const R* m, R mu, const R* xn, const R* xw, const R* sn, const R* sw) { return objective(th, m, mu, xn, xw, sn, sw); }
'''
open(os.path.join(HERE, "probe.cpp"), "w").write(probe)
subprocess.run(["g++", "-O2", "-shared", "-fPIC", "-DREAL=double", "-DNPAR=24", "-DNPER=16", "-o", os.path.join(HERE, "probe.so"), os.path.join(HERE, "probe.cpp")], check=True)
lib = ctypes.CDLL(os.path.join(HERE, "probe.so")); lib.probe_F.restype = ctypes.c_double
x, wx, s, ws = [np.ascontiguousarray(v, np.float64) for v in G.lattice()]; isd = G._psi_constants()[1]
p = lambda v: v.ctypes.data_as(ctypes.c_void_p)
def grad(th, m, mu):
    gr = np.zeros(9); H = np.zeros(81); F = ctypes.c_double()
    lib.probe_grad(p(np.ascontiguousarray(th)), p(m), ctypes.c_double(mu), p(x), p(wx), p(s), p(ws), p(gr), p(H), ctypes.byref(F)); return gr, H.reshape(9, 9)
Fv = lambda t, m, mu: lib.probe_F(p(np.ascontiguousarray(t)), p(m), ctypes.c_double(mu), p(x), p(wx), p(s), p(ws))
rng = np.random.default_rng(1); wg = wH = wB = 0.0
for trial in range(300):
    th = rng.normal(0, 0.3, 9); th[6] = -abs(rng.normal(0.5, 0.3)) - 0.05; th[7] = -abs(rng.normal(0.5, 0.3)) - 0.05
    A_ = -th[6]*isd[6]; B_ = -2*th[7]*isd[7]; th[8] = rng.uniform(-0.999, 0.999) * np.sqrt(0.9025*A_*B_)/isd[8]
    m = rng.normal(0, 0.5, 9); mu = 10.0 ** rng.uniform(-10, -3); g0, H = grad(th, m, mu)
    fdg = np.array([(Fv(th + e, m, mu) - Fv(th - e, m, mu)) / (2 * e[k]) for k in range(9) for e in [np.eye(9)[k] * 1e-6 * max(1.0, abs(th[k]))]])
    fdH = np.zeros((9, 9)); fdB = np.zeros((9, 9)); _, H1 = grad(th, m, 1.0); _, H2 = grad(th, m, 2.0)
    for k in range(9):
        e = np.eye(9)[k] * 1e-6 * max(1.0, abs(th[k]))
        fdH[:, k] = (grad(th + e, m, mu)[0] - grad(th - e, m, mu)[0]) / (2 * e[k])
        fdB[:, k] = ((grad(th + e, m, 2.0)[0] - grad(th + e, m, 1.0)[0]) - (grad(th - e, m, 2.0)[0] - grad(th - e, m, 1.0)[0])) / (2 * e[k])
    wg = max(wg, np.max(np.abs(fdg - g0)) / max(1e-8, np.max(np.abs(g0)))); wH = max(wH, np.max(np.abs(fdH - H)) / np.max(np.abs(H)))
    wB = max(wB, np.max(np.abs(fdB - (H2 - H1))) / np.max(np.abs(H2 - H1)))
res = dict(kernel_sha256=hashlib.sha256(open(os.path.join(HERE, "..", "code", "gyro_v03.py"), "rb").read()).hexdigest(), points=300,
           gradient_max_rel_err=wg, hessian_max_rel_err=wH, barrier_hessian_max_rel_err=wB)
print(json.dumps(res, indent=1)); json.dump(res, open(os.path.join(HERE, "audit_derivatives.json"), "w"), indent=1)
