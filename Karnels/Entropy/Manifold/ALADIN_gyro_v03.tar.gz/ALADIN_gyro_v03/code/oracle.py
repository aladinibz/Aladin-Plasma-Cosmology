# -*- coding: utf-8 -*-
"""Independent continuum oracle: moments of a continuous gyrotropic f(c_par, c_perp) by dense trapezoid integration
(FP64: 3001-point trapezoid in c_par (spectral for smooth decaying f), composite 20-point Gauss-Legendre
with ~2000 nodes in c_perp, +-16 thermal widths).  Shares nothing with either kernel's lattice.
Returns the 12 feature moments (kernel input), and the true u, V, Q=<c_perp^2>, q_par=<(c-u)^3>, q_perp=0.5<(c-u)c_perp^2>
for mass = n = thermal_scale = 1."""
import numpy as np


def phi(c, c2):
    idp = 1 / (1 + c * c); ide = 1 / (1 + c2)
    return [np.ones_like(c * c2), c + 0 * c2, c2 + 0 * c, c * c + 0 * c2, c * idp + 0 * c2, c * c2 * ide, c2 ** 2 + 0 * c,
            c * c * c2, c ** 4 + 0 * c2, c ** 3 * idp * idp + 0 * c2, c2 ** 3 * ide + 0 * c, c * c * c2 ** 2 * ide]


def moments(logf, cmin, cmax, cperp_max, Np=3001, Nq=2001):
    c = np.linspace(cmin, cmax, Np)[:, None]
    # c_perp: composite 20-point Gauss-Legendre (the c_perp dc_perp measure has a kink at 0 that limits trapezoid to O(h^2))
    xg, wg = np.polynomial.legendre.leggauss(20); npan = max(1, Nq // 20)
    edges = np.linspace(0, cperp_max, npan + 1); hh = np.diff(edges)
    cq = (edges[:-1, None] + 0.5 * hh[:, None] * (xg[None, :] + 1)).ravel()[None, :]
    wq = (0.5 * hh[:, None] * wg[None, :]).ravel()
    c2 = cq * cq
    lf = logf(c, c2)
    w = np.exp(lf - lf.max()) * cq                      # c_perp dc_perp measure
    wc = np.full(Np, 1.0); wc[[0, -1]] = 0.5
    w = w * wc[:, None] * wq[None, :]
    Z = w.sum()
    M = np.array([(w * f).sum() / Z for f in phi(c, c2)])
    u = (w * c).sum() / Z; d = c - u
    V = (w * d * d).sum() / Z; Q = (w * c2).sum() / Z
    q_par = (w * d ** 3).sum() / Z; q_perp = 0.5 * (w * d * c2).sum() / Z
    mu4 = (w * d ** 4).sum() / Z
    tail = max(w[[0, -1], :].max(), w[:, -1].max()) / w.max()
    return dict(M=M, u=u, V=V, Q=Q, q_par=q_par, q_perp=q_perp, kurt=mu4 / V ** 2, skew=q_par / V ** 1.5, edge=tail)


def bimax(u, Tpar, Tper):
    return (lambda c, c2: -(c - u) ** 2 / (2 * Tpar) - c2 / (2 * Tper)), u - 16 * Tpar ** .5, u + 16 * Tpar ** .5, 16 * (Tper ** .5)


def family(lam, u, Tpar, Tper):
    """exp(lambda . phi) member of the closure family (bi-Maxwellian base absorbed in lambda_1,2,3)."""
    lam = np.array(lam, float).copy()
    lam[3] += -1 / (2 * Tpar); lam[1] += u / Tpar; lam[2] += -1 / (2 * Tper)
    f = lambda c, c2: sum(l * p for l, p in zip(lam, phi(c, c2)) if l != 0)
    return f, u - 16 * Tpar ** .5, u + 16 * Tpar ** .5, 16 * Tper ** .5


def two_beam(frac, u2, T2, Tpar=1.0, Tper=1.0):
    def f(c, c2):
        a = (1 - frac) * np.exp(-c ** 2 / (2 * Tpar)) / Tpar ** .5 + frac * np.exp(-(c - u2) ** 2 / (2 * T2)) / T2 ** .5
        return np.log(a + 1e-300) - c2 / (2 * Tper)
    lo = min(-16 * Tpar ** .5, u2 - 16 * T2 ** .5); hi = max(16 * Tpar ** .5, u2 + 16 * T2 ** .5)
    return f, lo, hi, 16 * Tper ** .5


def loss_cone(Tpar, Tper, j=1):
    """c_perp^(2j) exp(-c_perp^2/2Tper): DGH loss-cone-type perpendicular distribution."""
    return (lambda c, c2: -c ** 2 / (2 * Tpar) + j * np.log(c2 + 1e-300) - c2 / (2 * Tper)), -16 * Tpar ** .5, 16 * Tpar ** .5, 20 * Tper ** .5


def kappa(k, theta, u=0.0):
    """isotropic-in-shape kappa-like f = (1 + ((c-u)^2 + c_perp^2)/(k theta^2))^-(k+1); heavy power-law tail."""
    return (lambda c, c2: -(k + 1) * np.log1p(((c - u) ** 2 + c2) / (k * theta ** 2))), u - 60 * theta, u + 60 * theta, 60 * theta


def moments_std(logf, cmin, cmax, cperp_max, Np=3001, Nq=2001):
    """Drift-frame (v03) feature moments: features evaluated at xi = (c - u)/sqrt(V), s2 = c_perp^2 / T_perp with T_perp = Q/2.
    Returns the 12 standardised feature moments S (S1 = 0, S2 = 2, S3 = 1 by construction) plus u, V, Q, q_par, q_perp
    in thermal_scale units (mass = n = 1)."""
    o = moments(logf, cmin, cmax, cperp_max, Np, Nq)
    c = np.linspace(cmin, cmax, Np)[:, None]
    xg, wg = np.polynomial.legendre.leggauss(20); npan = max(1, Nq // 20)
    edges = np.linspace(0, cperp_max, npan + 1); hh = np.diff(edges)
    cq = (edges[:-1, None] + 0.5 * hh[:, None] * (xg[None, :] + 1)).ravel()[None, :]
    wq = (0.5 * hh[:, None] * wg[None, :]).ravel()
    lf = logf(c, cq * cq); w = np.exp(lf - lf.max()) * cq
    wc = np.full(Np, 1.0); wc[[0, -1]] = 0.5; w = w * wc[:, None] * wq[None, :]; Z = w.sum()
    xi = (c - o["u"]) / np.sqrt(o["V"]); s2 = cq * cq / (o["Q"] / 2)
    o["S"] = np.array([(w * f).sum() / Z for f in phi(xi, s2)])
    return o
