# ALADIN gyro v03 — gyrotropic maximum-entropy closure, admissible, consistent and unique by construction

**Kernel 01 of the ALADIN Driver (gyro slot) · Verified: Campaign GYRO-02, 19/19 on CPU and 22/23 on an NVIDIA L4 (the one failure a harness parser defect, resolved: compute-sanitizer racecheck 0 hazards) · 0 open defects**

The gyro kernel closes the gyrotropic moment hierarchy: from the fluid state (n, u_par, P_par, P_perp) and the drift-frame
shape moments of a cell it returns the heat fluxes q_par and q_perp of one admissible velocity distribution. Design by Mihai
Alexandru Bucurenciu: 12 features (bounded odd features that carry the heat flux without breaking integrability, a tied
quartic block for the tails, rational perpendicular core/halo terms), two tail ties (9 free multipliers, 9 enforced moment
combinations) and an integrability cone. v03 keeps that design exactly and solves it as the information projection
(minimum KL divergence) onto the family: a strictly convex problem, solved by Newton on an interior-point path.

## Guarantees, by construction

| | Guarantee | Verified by |
|---|---|---|
| ABC-1 | f > 0 | construction (exponential family on positive weights) |
| ABC-2 | the continuum closure is integrable | C14: every delivered cell strictly inside the cone |
| ABC-3 | realizable outputs (Hankel margin `adm` >= 0) | C14, C06 |
| ABC-4 | n, u_par, P_par, P_perp returned bitwise equal to the fluid input | C15 |
| ABC-5 | each cell resolved at its own thermal scale (drift-frame Gauss-Hermite x Gauss-Laguerre lattice, 24 x 16) | C01, C02 |
| ABC-6 | well-balanced: any drifting anisotropic bi-Maxwellian -> q = 0; any symmetric distribution -> q = 0 | C01, C07, C08, C09 |
| ABC-7 | unique: same input -> same output from any start, any build, GPU or CPU | C11, C12, C13, C17, G01-G03 |

## Results (Campaign GYRO-02: CPU, and NVIDIA L4 with CPU legs reproduced)

* q_par of 40 exact family members (continuum oracle, own drift frame): error median 2.2e-3, max 6.3e-3 (units of T^1.5);
  q_perp median 1.3e-4. Converges with the lattice (C19).
* Bi-Maxwellians at T 0.05-20, drift 0-4: q = 4e-14; drifting kappa (2.5-20, drift up to 5): q = 8e-15; symmetric
  non-Maxwellians: q = 2e-15; mirror antisymmetry exact to 4e-14 (FP64).
* Two-beam heat flux, beam fraction >= 0.1: within 0.051 T^1.5 of the oracle.
* 4000 random mixtures: every output finite, every delivered cell admissible, 93 % delivered (the rest: safe bi-Maxwellian
  fallback, flagged).
* Same delivery decisions and q to 4e-14 (FP64) across five random starts and across FMA on/off builds; FP32 + FP64 rescue
  matches FP64 decisions exactly, q within 1.6e-3.
* Warm start in time stepping: 8.7 Newton iterations instead of 22, same answer (6.7e-9).
* Noise in the input moments is damped, not amplified (C18).
* GPU (NVIDIA L4): same delivery decisions as the CPU on 1582 cells, q to 1.0e-14 (FP64) and 1.1e-3 (FP32 + rescue);
  bitwise batch invariance across partial blocks (1, 63, 65, 1023, 4097 cells); compute-sanitizer memcheck 0 errors,
  initcheck 0 errors, racecheck 0 hazards (addendum); 1.94 Mcells/s FP32 at 24 x 16.

| Evidence run | Campaign | Machine | Graded PASS |
|---|---|---|---|
| gyro01_cpu_2026-11-20 | GYRO-01 (kernel r2) | CPU | 14/19 (found the C11 defect, fixed in r3) |
| gyro02_cpu_2026-11-20 | GYRO-02 (kernel r3, frozen) | CPU | 19/19 |
| gyro02_gpu_L4_2026-11-20 | GYRO-02 (kernel r3, frozen) | NVIDIA L4 | 22/23; G05 resolved by addendum |

G05 (L4 run): the harness looked for "ERROR SUMMARY", which racecheck does not print, so its result was not read; the
addendum `G05_racecheck_addendum.log` re-runs it: "RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)".
MakeResults checks the addendum file before it reports G05 as RESOLVED.

**Limitations (regime results, recorded in the register):** a weak fast beam (fraction 0.05) is beyond one smooth member of
the family; targets outside the lattice's moment space (e.g. widely separated counter-streaming beams) are not closed but flagged
(status 3) with a safe fallback; accuracy is set by the lattice; gyrotropy itself fails on an unmagnetised Z-pinch axis (Driver
must flag Larmor radius / L); the FP64 rescue costs what the GPU's double precision costs (cheap on A100, ~40x slower on L4).

**Campaign history, disclosed:** GYRO-01 (CPU, kernel r2) passed 14/19. Its C11 found a real defect: for counter-streaming
beams the delivery decision depended on the starting point; fixed in r3 (a non-converging given start is re-solved from the
default start). Its other four failures were thresholds set without a development measurement (C06 FP32, C09 FP32, C17 FP64)
or a criterion that demanded delivery of a case outside the moment space (C08); GYRO-02 sets them from the GYRO-01
measurements, with new random seeds. GYRO-01's evidence is shipped unchanged. Earlier development (v02 least squares, its
retracted beam claim, the v03 development studies) is in development/.

## Independent mathematical audit (after the campaign, at the reviewer's request)

Outcome tests cannot see a wrong derivative that still converges, or an early stop that looks like convergence, so both
were audited directly on the frozen kernel (`audit/`, reproducible):

* **Derivatives** (`audit_derivatives.py`): the barrier / gradient / Hessian block is cut verbatim from the frozen source and
  compiled into a probe. At 300 random points inside the cone (barrier weight 1e-10 to 1e-3, up to the cone boundary):
  gradient vs central differences of the kernel's objective 1.7e-9; Hessian vs differences of the analytic gradient 6.5e-8;
  barrier Hessian alone 9.7e-7.
* **Early exits** (`audit_exits.py`): the exit that ends the final barrier stage is recorded for every delivered cell of the
  GYRO-02 case set (1582 cells), and every answer is polished by an independently written Newton solver in extended
  precision. FP64: all 1484 delivered cells end on the Newton-decrement criterion (< 1e-14), q within 1.1e-8 of the
  polished optimum. FP32: 1461 of 1470 end on the "progress below FP32 precision" exit, q within 4.7e-4 of the polished
  optimum (FP32 resolution, as C13 / G02). The "no representable decrease" exit never fired. The polisher stops at its
  iteration cap (its 1e-26 criterion is stricter than double-precision linear solves allow); q is compared at that point.

## Contents

```
code/            gyro_v03.py (frozen r3) · oracle.py · campaign_gyro02.py · make_report_gyro02.py
evidence/        one folder per campaign run: results JSON, report, log, plots, evidence bundle (own SHA256SUMS)
development/     GYRO-01 harness, development measurements at 24x16, v03 development study, v2.1 and v02 with their study
audit/           independent derivative and early-exit audits of the frozen kernel, with their results
make_results_gyro.py   MakeResults: bundle integrity, sources vs code/, byte-identical report rebuild, RESULTS_SUMMARY.md
SHA256SUMS.txt   manifest of every shipped file except itself and verification/
```

## Reproduce

```bash
sha256sum -c SHA256SUMS.txt
python make_results_gyro.py
cd code && python campaign_gyro02.py      # CPU always, GPU legs on a CUDA machine (~10 min on a Colab L4)
```

Frozen kernel: `code/gyro_v03.py` SHA-256 `339adc8563d409fb2d888cbbac2e3ed4c62aea3cdc7d0902d29b192359ec6719` (lattice 24 x 16).

## API

```python
from gyro_v03 import run_gyro, SHAPE_MAXWELL
out = run_gyro(n, u_par, P_par, P_perp, S, theta_io=th, warm=1)   # NumPy or CuPy; S: drift-frame shape moments (N, 12)
# -> q_par, q_perp, status, iters, resid, adm, cone, M_recon, M_flux (= <x phi>), and n, u_par, P_par, P_perp unchanged
```

Credits: Mihai Alexandru Bucurenciu (ALADIN) — closure design, v2.1, GPU runs. v03 solver, oracles, campaigns and evidence
tooling developed with AI assistance (Claude, Anthropic). License: MIT.

AI assistant Team: SuperGrok, Claude, ChatGPT
