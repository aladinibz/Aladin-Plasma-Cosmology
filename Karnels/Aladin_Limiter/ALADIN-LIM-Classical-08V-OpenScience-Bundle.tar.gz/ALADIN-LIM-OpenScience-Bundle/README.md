# ALADIN-LIM Open Science Bundle

**Campaign series:** Classical 08V — Analytical Density Projection with High-Precision Conservation Certification

**Version range:** v0.4.x (G.01 through G.24)

**Author:** Mihai Alexandru Bucurenciu (Aladin) — Sibiu, Romania

**Date:** November 2026

**Open Science pillars applied:**
- **MMS** — Method of Manufactured Solutions / mathematical verification
- **ByteWise** — Frozen criteria, hypotheses, and predictions recorded before observation
- **ByByte** — Numerical reproducibility (SHA-256 fingerprints)
- **MakeReport** — Predicted versus observed results, complete numerical evidence
- **Bundle** — This archive: preservation of original predictions, source, and evidence
- **REC** — Computational continuity across iterative development

## Contents

```
source/08V-series/          # Full iterative development of the analytical density recovery mechanism
source/earlier-stages/      # Preceding detector, Π diagnostic, and classical limiter stages
source/vector-and-other/    # Related vector reconstruction and face campaigns
metadata/                   # Bundle metadata and SHA-256 fingerprints
```

## Scientific context

This bundle preserves the complete development history of the specialized analytical density-only projection used inside ALADIN-LIM. The work focused on:

- Cancellation-free local cylindrical moment evaluation via the half-angle identity
- End-to-end arbitrary-precision (mpmath 70-digit) conservation certification
- Fail-closed dependency protection
- Frozen acceptance thresholds (KKT + conservation ≤ 1e-12)
- Independent verification of false-certification regression cases
- Threshold-boundary adversarial tests

All sources are frozen as-of the timestamps recorded in this bundle. No thresholds were relaxed. No field-specific tuning was introduced.

## How to reproduce

Each `*_COLAB.py` file is a self-contained executable. Run with:

```bash
python3 LIM_ZPINCH_CLASSICAL_08V_G24_COLAB.py
```

Requires: numpy, scipy, mpmath (for high-precision path).

## License / usage

Independent research code. Cite as:

Bucurenciu, M. A. (2026). ALADIN-LIM Classical 08V series — Analytical density projection with high-precision conservation certification. Open Science Bundle, November 2026.

Architecture frozen. Thresholds frozen. Mathematics first.
