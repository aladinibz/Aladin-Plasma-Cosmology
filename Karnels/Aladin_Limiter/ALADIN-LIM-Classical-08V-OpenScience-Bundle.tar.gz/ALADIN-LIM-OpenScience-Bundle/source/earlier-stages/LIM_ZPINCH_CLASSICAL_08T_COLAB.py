#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-CLASSICAL-08T
Fixes from 08S:
1. Magnetic Gram uses differentiated B basis (not vector potential)
2. Full metric is positive-definite (density/energy blocks included)
3. Genuine oriented face-flux matrix (not coefficient freezing)
4. Correct cylindrical moment
Self-contained. Π=0.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.optimize import minimize
from numpy.polynomial.legendre import leggauss

print("LIM-ZPINCH-CLASSICAL-08T (self-contained, four fixes)")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    """Differentiated magnetic basis for Gram metric."""
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    # Derivatives of reconstruct_B w.r.t. coefficients
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

def magnetic_gram(Xc, Yc, h, r0, r1, p0, p1, n=12):
    """M_B = integral(D_B.T @ D_B dV) — differentiated magnetic basis."""
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
            D = np.vstack([dBx, dBy])  # 2 x 9
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def face_flux_matrix(Xc, Yc, h, r0, r1, p0, p1):
    """Genuine oriented face-flux matrix for annular sector."""
    # Four faces: outer radial, inner radial, +phi, -phi
    # Approximate with quadrature on edges
    C = np.zeros((4, 9))
    # Outer radial face (r1, p0 to p1)
    nodes, w = leggauss(8)
    p = 0.5*(p1-p0)*nodes + 0.5*(p0+p1)
    wp = 0.5*(p1-p0)*w
    for j, pj in enumerate(p):
        X = r1*np.cos(pj)
        Y = r1*np.sin(pj)
        dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
        nx, ny = np.cos(pj), np.sin(pj)
        C[0] += (dBx*nx + dBy*ny) * r1 * wp[j]
    # Inner radial face (r0, p0 to p1) — opposite orientation
    for j, pj in enumerate(p):
        X = r0*np.cos(pj)
        Y = r0*np.sin(pj)
        dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
        nx, ny = -np.cos(pj), -np.sin(pj)
        C[1] += (dBx*nx + dBy*ny) * r0 * wp[j]
    # +phi face
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    nx, ny = -np.sin(p1), np.cos(p1)
    for i, ri in enumerate(r):
        X = ri*np.cos(p1)
        Y = ri*np.sin(p1)
        dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
        C[2] += (dBx*nx + dBy*ny) * wr[i]
    # -phi face
    nx, ny = np.sin(p0), -np.cos(p0)
    for i, ri in enumerate(r):
        X = ri*np.cos(p0)
        Y = ri*np.sin(p0)
        dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
        C[3] += (dBx*nx + dBy*ny) * wr[i]
    return C

def cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1):
    """Correct Volume I cylindrical average of xi^2 + eta^2."""
    # Exact integral of (X^2 + Y^2) over annular sector
    # = integral_r0^r1 integral_p0^p1 r^3 dr dphi
    area = 0.5 * (r1**2 - r0**2) * (p1 - p0)
    r4_int = 0.25 * (r1**4 - r0**4) * (p1 - p0)
    mean_r2 = r4_int / area
    # Transform to centered coordinates
    # <xi^2 + eta^2> = (<(X-Xc)^2 + (Y-Yc)^2>) / h^2
    # = (<X^2+Y^2> - 2 Xc <X> - 2 Yc <Y> + Xc^2 + Yc^2) / h^2
    # For annular sector, <X> = (2/3)(r1^3-r0^3)/(r1^2-r0^2) * (sin p1 - sin p0)/(p1-p0)
    # <Y> similar with cos
    dr2 = r1**2 - r0**2
    dr3 = r1**3 - r0**3
    dp = p1 - p0
    mean_X = (2/3) * dr3 / dr2 * (np.sin(p1) - np.sin(p0)) / dp
    mean_Y = (2/3) * dr3 / dr2 * (np.cos(p0) - np.cos(p1)) / dp
    mean_xi2_eta2 = (mean_r2 - 2*Xc*mean_X - 2*Yc*mean_Y + Xc**2 + Yc**2) / h**2
    return mean_xi2_eta2

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def e_int(rho, mx, my, E, Bx, By):
    if rho < EPS_RHO:
        return -np.inf
    return E - (mx**2 + my**2)/(2*rho) - (Bx**2 + By**2)/(2*MU0)

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

def project_simultaneous(c_mag, N, H, Xc, Yc, h, rho0, E0, points, avg, scale_rho=1.0, scale_E=1.0):
    ns_mag = N.shape[1]
    ns = ns_mag + 2
    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H
    # Positive-definite blocks for density and energy
    H_full[ns_mag, ns_mag] = scale_rho
    H_full[ns_mag+1, ns_mag+1] = scale_E

    def objective(z):
        return 0.5 * z @ H_full @ z

    def constraints(z):
        z_mag = z[:ns_mag]
        a_rho, a_E = z[ns_mag:]
        c = c_mag + N @ z_mag
        g = []
        for X, Y in points:
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            rho = rho0 + a_rho * mean_free_mode(xi, eta, avg)
            E = E0 + a_E * mean_free_mode(xi, eta, avg)
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            g.append(rho - EPS_RHO)
            g.append(e_int(rho, 0, 0, E, Bx, By) - (EPS_EINT + DELTA_NUM))
        return np.array(g)

    cons = {"type": "ineq", "fun": constraints}
    res = minimize(objective, np.zeros(ns), constraints=cons,
                   method="SLSQP", tol=1e-12)
    return res, H_full

def run():
    t0 = perf_counter()
    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48

    # Fix 1: magnetic Gram with differentiated basis
    M_B = magnetic_gram(Xc, Yc, h, r0, r1, p0, p1)

    # Fix 3: genuine face-flux matrix
    C = face_flux_matrix(Xc, Yc, h, r0, r1, p0, p1)
    N, flux_rank = null_space(C)
    H = N.T @ M_B @ N

    # Fix 4: correct cylindrical moment
    avg = cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1)

    points = [(Xc, Yc), (Xc + 0.5*h, Yc), (Xc - 0.5*h, Yc)]

    c_bad = np.zeros(9)
    c_bad[1] = 0.5 * h
    res, H_full = project_simultaneous(c_bad, N, H, Xc, Yc, h, 1.0, 0.1, points, avg)
    z = res.x
    ns_mag = N.shape[1]
    c_final = c_bad + N @ z[:ns_mag]
    a_rho, a_E = z[ns_mag:]

    evals = []
    for X, Y in points:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        rho = 1.0 + a_rho * mean_free_mode(xi, eta, avg)
        E = 0.1 + a_E * mean_free_mode(xi, eta, avg)
        Bx, By = reconstruct_B(c_final, X, Y, Xc, Yc, h)
        ei = e_int(rho, 0, 0, E, Bx, By)
        evals.append({
            "r": float(np.hypot(X, Y)),
            "rho": float(rho),
            "eint": float(ei),
            "admissible": int(ei >= EPS_EINT and rho >= EPS_RHO)
        })

    # Eigenvalues of full metric
    eigvals = np.linalg.eigvalsh(H_full)

    results = {
        "success": int(res.success),
        "z_norm": float(np.linalg.norm(z)),
        "avg_used": float(avg),
        "points": evals,
        "all_admissible": int(all(p["admissible"] for p in evals)),
        "min_eint": float(min(p["eint"] for p in evals)),
        "gram_trace": float(np.trace(M_B)),
        "H_condition": float(np.linalg.cond(H)),
        "H_full_min_eigenvalue": float(eigvals[0]),
        "H_full_condition": float(eigvals[-1] / max(eigvals[0], 1e-30)),
        "flux_rank": int(flux_rank),
        "CN_norm": float(np.linalg.norm(C @ N)),
        "analytical_avg_reference": 0.17481795369724296
    }

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08T",
        "version": "0.4.108-classical-08t",
        "base": "CLASSICAL-08S",
        "fixes": [
            "magnetic Gram uses differentiated B basis",
            "full metric positive-definite",
            "genuine oriented face-flux matrix",
            "correct cylindrical moment"
        ],
        "floors": {"eps_rho": EPS_RHO, "eps_eint": EPS_EINT},
        "delta_num": DELTA_NUM,
        "Pi_influence": 0.0,
        "results": results,
        "wall_time_s": perf_counter() - t0,
        "note": "Four fixes applied. Self-contained. Classical baseline."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
