#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-CLASSICAL-08S
Builds on LIM_ZPINCH_CLASSICAL_ASSEMBLY.
Uses Volume II v0.4.46 + WB-07D physical Gram.
Simultaneous multi-point admissible projection.
Π=0. Classical baseline.
"""
import numpy as np
import json, hashlib, sys
from time import perf_counter
from scipy.optimize import minimize

print("LIM-ZPINCH-CLASSICAL-08S Simultaneous multi-point on real operators")

sys.path.insert(0, "/workspace/artifacts")
from LIM_VEC_06_hard_constrained_v046 import A_basis, reconstruct_B
from LIM_ZPINCH_WB_07D import physical_gram

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def e_int(rho, mx, my, E, Bx, By):
    if rho < EPS_RHO:
        return -np.inf
    return E - (mx**2 + my**2)/(2*rho) - (Bx**2 + By**2)/(2*MU0)

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T

def project_simultaneous(c_mag, N, H, Xc, Yc, h, rho0, E0, points, avg):
    ns_mag = N.shape[1]
    ns = ns_mag + 2
    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H

    def objective(z):
        return 0.5 * z @ H_full @ z

    def constraints(z):
        z_mag = z[:ns_mag]
        a_rho, a_E = z[ns_mag:]
        c = c_mag + N @ z_mag
        g = []
        for X, Y in points:
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            rho = rho0 + a_rho * mean_free_mode(xi, eta, avg)
            E = E0 + a_E * mean_free_mode(xi, eta, avg)
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            g.append(rho - EPS_RHO)
            g.append(e_int(rho, 0, 0, E, Bx, By) - (EPS_EINT + DELTA_NUM))
        return np.array(g)

    cons = {"type": "ineq", "fun": constraints}
    res = minimize(objective, np.zeros(ns), constraints=cons,
                   method="SLSQP", tol=1e-12)
    return res

def run():
    t0 = perf_counter()
    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48

    M_B = physical_gram(Xc, Yc, h, r0, r1, p0, p1)
    C = np.zeros((2, 9))
    C[0, 0] = 1.0
    C[1, 1] = 1.0
    N = null_space(C)
    H = N.T @ M_B @ N

    # Cylindrical average from Volume I geometry (annular sector)
    area = 0.5 * (r1**2 - r0**2) * (p1 - p0)
    r2_int = (r1**4 - r0**4) / 4.0 * (p1 - p0)
    avg = (r2_int / area + Xc**2 + Yc**2 - 2*Xc*0.5*(r0+r1)) / h**2

    points = [(Xc, Yc), (Xc + 0.5*h, Yc), (Xc - 0.5*h, Yc)]

    # Manufactured inadmissible
    c_bad = np.zeros(9)
    c_bad[1] = 0.5 * h
    res = project_simultaneous(c_bad, N, H, Xc, Yc, h, 1.0, 0.1, points, avg)
    z = res.x
    ns_mag = N.shape[1]
    c_final = c_bad + N @ z[:ns_mag]
    a_rho, a_E = z[ns_mag:]

    evals = []
    for X, Y in points:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        rho = 1.0 + a_rho * mean_free_mode(xi, eta, avg)
        E = 0.1 + a_E * mean_free_mode(xi, eta, avg)
        Bx, By = reconstruct_B(c_final, X, Y, Xc, Yc, h)
        ei = e_int(rho, 0, 0, E, Bx, By)
        evals.append({
            "r": float(np.hypot(X, Y)),
            "rho": float(rho),
            "eint": float(ei),
            "admissible": int(ei >= EPS_EINT and rho >= EPS_RHO)
        })

    results = {
        "success": int(res.success),
        "z_norm": float(np.linalg.norm(z)),
        "avg_used": float(avg),
        "points": evals,
        "all_admissible": int(all(p["admissible"] for p in evals)),
        "min_eint": float(min(p["eint"] for p in evals)),
        "gram_trace": float(np.trace(M_B)),
        "H_condition": float(np.linalg.cond(H)),
        "CN_norm": float(np.linalg.norm(C @ N))
    }

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08S",
        "version": "0.4.107-classical-08s",
        "base": "LIM_ZPINCH_CLASSICAL_ASSEMBLY 0.4.106",
        "operators": ["Volume II v0.4.46", "WB-07D physical Gram"],
        "floors": {"eps_rho": EPS_RHO, "eps_eint": EPS_EINT},
        "delta_num": DELTA_NUM,
        "Pi_influence": 0.0,
        "results": results,
        "wall_time_s": perf_counter() - t0,
        "note": "Simultaneous multi-point on real Volume II + WB-07D operators. Classical baseline."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
