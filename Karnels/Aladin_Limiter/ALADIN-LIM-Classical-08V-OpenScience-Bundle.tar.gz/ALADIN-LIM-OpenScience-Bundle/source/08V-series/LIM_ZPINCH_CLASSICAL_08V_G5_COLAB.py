#!/usr/bin/env python3
"""
ALADIN-LIM  Classical 08V-G.5 — Analytical Ground Truth
Baseline: v0.4.121-classical-08v-g4
Architecture: Frozen
Π influence: 0.0
Exact analytical G01 projection. Three-way comparison.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.optimize import minimize, nnls
from numpy.polynomial.legendre import leggauss
import cvxpy as cp

print("LIM-ZPINCH Classical 08V-G.5 — Analytical Ground Truth")

SEED = 20261127

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

def magnetic_gram(Xc, Yc, h, r0, r1, p0, p1, n=8):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
            D = np.vstack([dBx, dBy])
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1):
    area = 0.5 * (r1**2 - r0**2) * (p1 - p0)
    r4_int = 0.25 * (r1**4 - r0**4) * (p1 - p0)
    mean_r2 = r4_int / area
    dr2 = r1**2 - r0**2
    dr3 = r1**3 - r0**3
    dp = p1 - p0
    mean_X = (2/3) * dr3 / dr2 * (np.sin(p1) - np.sin(p0)) / dp
    mean_Y = (2/3) * dr3 / dr2 * (np.cos(p0) - np.cos(p1)) / dp
    mean_xi2_eta2 = (mean_r2 - 2*Xc*mean_X - 2*Yc*mean_Y + Xc**2 + Yc**2) / h**2
    return mean_xi2_eta2

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def build_cell(Xc, Yc, h, r0, r1, p0, p1):
    M_B = magnetic_gram(Xc, Yc, h, r0, r1, p0, p1)
    C = np.zeros((4, 9))
    for k in range(9):
        c_k = np.zeros(9)
        c_k[k] = 1.0
        def Bx(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[0]
        def By(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[1]
        C[0, k] = numerical_radial_flux(r1, p0, p1, Bx, By)
        C[1, k] = -numerical_radial_flux(r0, p0, p1, Bx, By)
        C[2, k] = numerical_azi_flux(p1, r0, r1, Bx, By)
        C[3, k] = -numerical_azi_flux(p0, r0, r1, Bx, By)
    N, rank = null_space(C)
    H = N.T @ M_B @ N
    avg = cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1)
    return {"M_B": M_B, "C": C, "N": N, "rank": rank, "H": H, "avg": avg,
            "Xc": Xc, "Yc": Yc, "h": h, "r0": r0, "r1": r1, "p0": p0, "p1": p1}

def analytical_g01_projection(a_rho_offset, points, cell, rho0=1.0):
    """
    Exact analytical projection for density-only G01 states.
    Returns the minimum-correction density coefficient.
    """
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]

    mf_vals = []
    for X, Y in points:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        mf_vals.append(mean_free_mode(xi, eta, avg))

    mf_min = min(mf_vals)
    mf_max = max(mf_vals)

    # Bounds for final density coefficient
    # rho = rho0 + a_rho_final * mf >= rho_floor
    # For mf > 0: a_rho_final >= (rho_floor - rho0) / mf
    # For mf < 0: a_rho_final <= (rho_floor - rho0) / mf

    rho_floor = EPS_RHO + DELTA_NUM
    L = -np.inf
    U = np.inf

    for mf in mf_vals:
        if mf > 1e-12:
            L = max(L, (rho_floor - rho0) / mf)
        elif mf < -1e-12:
            U = min(U, (rho_floor - rho0) / mf)

    # Clip to allowable interval
    a_rho_final = np.clip(a_rho_offset, L, U)
    delta_a_rho = a_rho_final - a_rho_offset

    return {
        "delta_a_rho": delta_a_rho,
        "a_rho_final": a_rho_final,
        "L": L,
        "U": U,
        "obj": 0.5 * delta_a_rho**2
    }

def run_slsqp(cell, c_bad, points, rho0, E0, mx, my, a_rho_offset, a_E_offset):
    N = cell["N"]
    H = cell["H"]
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    ns_mag = N.shape[1]
    ns = ns_mag + 2
    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H
    H_full[ns_mag, ns_mag] = 1.0
    H_full[ns_mag+1, ns_mag+1] = 1.0

    def objective(z):
        return 0.5 * z @ H_full @ z

    def objective_jac(z):
        return H_full @ z

    def constraints(z):
        z_mag = z[:ns_mag]
        a_rho_corr, a_E_corr = z[ns_mag:]
        c = c_bad + N @ z_mag
        g = []
        for X, Y in points:
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            mf = mean_free_mode(xi, eta, avg)
            rho = rho0 + (a_rho_offset + a_rho_corr) * mf
            E = E0 + (a_E_offset + a_E_corr) * mf
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            g.append(rho - (EPS_RHO + DELTA_NUM))
            if rho >= EPS_RHO:
                eint = E - (mx**2 + my**2)/(2*rho) - (Bx**2 + By**2)/(2*MU0)
                g.append(eint - (EPS_EINT + DELTA_NUM))
            else:
                g.append(-1e30)
        return np.array(g)

    def constraints_jac(z):
        z_mag = z[:ns_mag]
        a_rho_corr, a_E_corr = z[ns_mag:]
        c = c_bad + N @ z_mag
        n_cons = 2 * len(points)
        J = np.zeros((n_cons, ns))
        for i, (X, Y) in enumerate(points):
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            mf = mean_free_mode(xi, eta, avg)
            rho = rho0 + (a_rho_offset + a_rho_corr) * mf
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            J[2*i, ns_mag] = mf
            if rho >= EPS_RHO:
                mom2 = mx**2 + my**2
                J[2*i+1, ns_mag] = mom2 * mf / (2 * rho**2)
                J[2*i+1, ns_mag+1] = mf
                dBx_dc = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
                dBy_dc = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
                dBx_dz = dBx_dc @ N
                dBy_dz = dBy_dc @ N
                J[2*i+1, :ns_mag] = -(Bx * dBx_dz + By * dBy_dz) / MU0
        return J

    cons = {"type": "ineq", "fun": constraints, "jac": constraints_jac}
    z0 = np.zeros(ns)
    z0[ns_mag] = -a_rho_offset
    res = minimize(objective, z0, jac=objective_jac, constraints=cons, method="SLSQP", tol=1e-14)
    return res

def run_comparison():
    t0 = perf_counter()

    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48
    cell = build_cell(Xc, Yc, h, r0, r1, p0, p1)

    points = [(Xc, Yc), (Xc + 0.5*h, Yc), (Xc - 0.5*h, Yc),
              (Xc, Yc + 0.5*h), (Xc + 0.3*h, Yc + 0.3*h)]

    # G01 test cases including previously failed offsets
    test_offsets = [10.0, 37.5462, 41.7178, 53.4746, 56.7091, 73.6086, 90.9870, 93.8309, 100.0]

    results = []
    print("  G01 analytical comparison ...", flush=True)

    for offset in test_offsets:
        # Analytical solution
        analytical = analytical_g01_projection(offset, points, cell)

        # SLSQP solution
        c_bad = np.zeros(9)
        c_bad[1] = 0.1 * h
        slsqp_res = run_slsqp(cell, c_bad, points, 1.0, 0.1, 0.0, 0.0, offset, 0.0)

        slsqp_delta = None
        slsqp_obj = None
        if slsqp_res.success:
            ns_mag = cell["N"].shape[1]
            slsqp_delta = slsqp_res.x[ns_mag]
            H_full = np.zeros((len(slsqp_res.x), len(slsqp_res.x)))
            H_full[:ns_mag, :ns_mag] = cell["H"]
            H_full[ns_mag, ns_mag] = 1.0
            H_full[ns_mag+1, ns_mag+1] = 1.0
            slsqp_obj = 0.5 * slsqp_res.x @ H_full @ slsqp_res.x

        results.append({
            "offset": offset,
            "analytical_delta": analytical["delta_a_rho"],
            "analytical_obj": analytical["obj"],
            "analytical_L": analytical["L"],
            "analytical_U": analytical["U"],
            "slsqp_success": bool(slsqp_res.success),
            "slsqp_delta": float(slsqp_delta) if slsqp_delta is not None else None,
            "slsqp_obj": float(slsqp_obj) if slsqp_obj is not None else None,
            "delta_diff": float(abs(slsqp_delta - analytical["delta_a_rho"])) if slsqp_delta is not None else None,
            "obj_diff": float(abs(slsqp_obj - analytical["obj"])) if slsqp_obj is not None else None
        })
        print(f"    offset={offset:.2f} analytical_delta={analytical['delta_a_rho']:.6f} slsqp={'OK' if slsqp_res.success else 'FAIL'}", flush=True)

    n_total = len(results)
    n_slsqp_success = sum(1 for r in results if r["slsqp_success"])
    delta_diffs = [r["delta_diff"] for r in results if r["delta_diff"] is not None]
    obj_diffs = [r["obj_diff"] for r in results if r["obj_diff"] is not None]

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08V-G5",
        "version": "0.4.122-classical-08v-g5",
        "baseline": "v0.4.121-classical-08v-g4",
        "total_states": n_total,
        "Pi_influence": 0.0,
        "formulation": "analytical_g01_projection",
        "comparison": {
            "n_slsqp_success": n_slsqp_success,
            "n_total": n_total,
            "delta_diff_max": float(max(delta_diffs)) if delta_diffs else None,
            "delta_diff_median": float(np.median(delta_diffs)) if delta_diffs else None,
            "obj_diff_max": float(max(obj_diffs)) if obj_diffs else None,
            "obj_diff_median": float(np.median(obj_diffs)) if obj_diffs else None
        },
        "results": results,
        "wall_time_s": perf_counter() - t0,
        "note": "Analytical G01 ground truth. Three-way comparison."
    }
    def convert_bools(obj):
        if isinstance(obj, dict):
            return {k: convert_bools(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_bools(v) for v in obj]
        elif isinstance(obj, (np.bool_, bool)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.integer)):
            return float(obj) if isinstance(obj, np.floating) else int(obj)
        return obj
    report_clean = convert_bools(report)
    raw = json.dumps(report_clean, sort_keys=True).encode()
    report_clean["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report_clean, indent=2))
    return report_clean

if __name__ == "__main__":
    run_comparison()
