#!/usr/bin/env python3
"""
ALADIN-LIM  Classical 08V-G.4 — Certified Convex Reference
Baseline: v0.4.120-classical-08v-g3
Architecture: Frozen
Π influence: 0.0
Normalized objective comparison. Small-momentum fix. Independent verification.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.optimize import minimize, nnls
from numpy.polynomial.legendre import leggauss
import cvxpy as cp

print("LIM-ZPINCH Classical 08V-G.4 — Certified Convex Reference")

SEED = 20261127
N_PER_CATEGORY = 20

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

def magnetic_gram(Xc, Yc, h, r0, r1, p0, p1, n=8):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
            D = np.vstack([dBx, dBy])
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1):
    area = 0.5 * (r1**2 - r0**2) * (p1 - p0)
    r4_int = 0.25 * (r1**4 - r0**4) * (p1 - p0)
    mean_r2 = r4_int / area
    dr2 = r1**2 - r0**2
    dr3 = r1**3 - r0**3
    dp = p1 - p0
    mean_X = (2/3) * dr3 / dr2 * (np.sin(p1) - np.sin(p0)) / dp
    mean_Y = (2/3) * dr3 / dr2 * (np.cos(p0) - np.cos(p1)) / dp
    mean_xi2_eta2 = (mean_r2 - 2*Xc*mean_X - 2*Yc*mean_Y + Xc**2 + Yc**2) / h**2
    return mean_xi2_eta2

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def build_cell(Xc, Yc, h, r0, r1, p0, p1):
    M_B = magnetic_gram(Xc, Yc, h, r0, r1, p0, p1)
    C = np.zeros((4, 9))
    for k in range(9):
        c_k = np.zeros(9)
        c_k[k] = 1.0
        def Bx(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[0]
        def By(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[1]
        C[0, k] = numerical_radial_flux(r1, p0, p1, Bx, By)
        C[1, k] = -numerical_radial_flux(r0, p0, p1, Bx, By)
        C[2, k] = numerical_azi_flux(p1, r0, r1, Bx, By)
        C[3, k] = -numerical_azi_flux(p0, r0, r1, Bx, By)
    N, rank = null_space(C)
    H = N.T @ M_B @ N
    avg = cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1)
    return {"M_B": M_B, "C": C, "N": N, "rank": rank, "H": H, "avg": avg,
            "Xc": Xc, "Yc": Yc, "h": h, "r0": r0, "r1": r1, "p0": p0, "p1": p1}

def run_slsqp(cell, c_bad, points, rho0, E0, mx, my, a_rho_offset, a_E_offset):
    N = cell["N"]
    H = cell["H"]
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    ns_mag = N.shape[1]
    ns = ns_mag + 2
    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H
    H_full[ns_mag, ns_mag] = 1.0
    H_full[ns_mag+1, ns_mag+1] = 1.0

    def objective(z):
        return 0.5 * z @ H_full @ z

    def objective_jac(z):
        return H_full @ z

    def constraints(z):
        z_mag = z[:ns_mag]
        a_rho_corr, a_E_corr = z[ns_mag:]
        c = c_bad + N @ z_mag
        g = []
        for X, Y in points:
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            mf = mean_free_mode(xi, eta, avg)
            rho = rho0 + (a_rho_offset + a_rho_corr) * mf
            E = E0 + (a_E_offset + a_E_corr) * mf
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            g.append(rho - (EPS_RHO + DELTA_NUM))
            if rho >= EPS_RHO:
                eint = E - (mx**2 + my**2)/(2*rho) - (Bx**2 + By**2)/(2*MU0)
                g.append(eint - (EPS_EINT + DELTA_NUM))
            else:
                g.append(-1e30)
        return np.array(g)

    def constraints_jac(z):
        z_mag = z[:ns_mag]
        a_rho_corr, a_E_corr = z[ns_mag:]
        c = c_bad + N @ z_mag
        n_cons = 2 * len(points)
        J = np.zeros((n_cons, ns))
        for i, (X, Y) in enumerate(points):
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            mf = mean_free_mode(xi, eta, avg)
            rho = rho0 + (a_rho_offset + a_rho_corr) * mf
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            J[2*i, ns_mag] = mf
            if rho >= EPS_RHO:
                mom2 = mx**2 + my**2
                J[2*i+1, ns_mag] = mom2 * mf / (2 * rho**2)
                J[2*i+1, ns_mag+1] = mf
                dBx_dc = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
                dBy_dc = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
                dBx_dz = dBx_dc @ N
                dBy_dz = dBy_dc @ N
                J[2*i+1, :ns_mag] = -(Bx * dBx_dz + By * dBy_dz) / MU0
        return J

    cons = {"type": "ineq", "fun": constraints, "jac": constraints_jac}
    z0 = np.zeros(ns)
    z0[ns_mag] = -a_rho_offset
    res = minimize(objective, z0, jac=objective_jac, constraints=cons, method="SLSQP", tol=1e-14)
    return res

def run_cvxpy_full(cell, c_bad, points, rho0, E0, mx, my, a_rho_offset, a_E_offset):
    """Full convex formulation. No small-momentum approximation."""
    N = cell["N"]
    H = cell["H"]
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    ns_mag = N.shape[1]
    ns = ns_mag + 2

    z = cp.Variable(ns)
    z_mag = z[:ns_mag]
    a_rho_corr = z[ns_mag]
    a_E_corr = z[ns_mag + 1]

    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H
    H_full[ns_mag, ns_mag] = 1.0
    H_full[ns_mag+1, ns_mag+1] = 1.0

    objective = cp.Minimize(0.5 * cp.quad_form(z, H_full))

    constraints = []
    mom2 = mx**2 + my**2

    for X, Y in points:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        mf = mean_free_mode(xi, eta, avg)
        rho = rho0 + (a_rho_offset + a_rho_corr) * mf
        E = E0 + (a_E_offset + a_E_corr) * mf

        constraints.append(rho >= EPS_RHO + DELTA_NUM)

        c = c_bad + N @ z_mag
        dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
        Bx = dBx @ c
        By = dBy @ c

        # Kinetic energy (no threshold - use inv_pos for all nonzero)
        if mom2 > 0:
            kinetic = 0.5 * mom2 * cp.inv_pos(rho)
        else:
            kinetic = 0.0

        magnetic = cp.sum_squares(cp.hstack([Bx, By])) / (2 * MU0)
        constraints.append(kinetic + magnetic + EPS_EINT + DELTA_NUM <= E)

    prob = cp.Problem(objective, constraints)
    try:
        prob.solve(solver=cp.CLARABEL, verbose=False)
        if prob.status == cp.OPTIMAL:
            return {"success": True, "x": z.value, "obj": prob.value}
        else:
            return {"success": False, "x": None, "obj": None, "status": prob.status}
    except Exception as e:
        return {"success": False, "x": None, "obj": None, "error": str(e)}

def generate_test_state(rng, category):
    if category == "G01":
        return {"a_rho_offset": rng.uniform(1, 100), "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.1, "rho0": 1.0, "E0": 0.1}
    elif category == "G03":
        return {"a_rho_offset": rng.uniform(0.5, 5), "a_E_offset": 0.0,
                "mx": rng.uniform(0.1, 0.5), "my": rng.uniform(0.1, 0.5),
                "c_mag": 0.1, "rho0": 1.0, "E0": 0.5}
    elif category == "G06":
        return {"a_rho_offset": rng.uniform(0.5, 2.0), "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.05, "rho0": 1.0, "E0": 0.1}
    elif category == "G08":
        return {"a_rho_offset": 0.0, "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.01, "rho0": 1.0, "E0": 0.1}
    else:
        return {"a_rho_offset": rng.uniform(0.1, 10), "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.1, "rho0": 1.0, "E0": 0.1}

def run_comparison():
    t0 = perf_counter()
    rng = np.random.default_rng(SEED)

    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48
    cell = build_cell(Xc, Yc, h, r0, r1, p0, p1)

    points = [(Xc, Yc), (Xc + 0.5*h, Yc), (Xc - 0.5*h, Yc),
              (Xc, Yc + 0.5*h), (Xc + 0.3*h, Yc + 0.3*h)]

    categories = ["G01", "G03", "G06", "G08"]
    results = []
    disagreements = []

    for cat in categories:
        print(f"  {cat} ...", end="", flush=True)
        for i in range(N_PER_CATEGORY):
            state = generate_test_state(rng, cat)
            c_bad = np.zeros(9)
            c_bad[1] = state["c_mag"] * h

            slsqp_res = run_slsqp(cell, c_bad, points,
                                   state["rho0"], state["E0"], state["mx"], state["my"],
                                   state["a_rho_offset"], state["a_E_offset"])
            cvxpy_res = run_cvxpy_full(cell, c_bad, points,
                                        state["rho0"], state["E0"], state["mx"], state["my"],
                                        state["a_rho_offset"], state["a_E_offset"])

            obj_diff_abs = None
            obj_diff_norm = None
            if slsqp_res.success and cvxpy_res["success"] and cvxpy_res["obj"] is not None:
                H_full = np.zeros((len(slsqp_res.x), len(slsqp_res.x)))
                ns_mag = cell["N"].shape[1]
                H_full[:ns_mag, :ns_mag] = cell["H"]
                H_full[ns_mag, ns_mag] = 1.0
                H_full[ns_mag+1, ns_mag+1] = 1.0
                slsqp_obj = 0.5 * slsqp_res.x @ H_full @ slsqp_res.x
                obj_diff_abs = abs(slsqp_obj - cvxpy_res["obj"])
                scale = max(1.0, abs(slsqp_obj), abs(cvxpy_res["obj"]))
                obj_diff_norm = obj_diff_abs / scale

            result = {
                "category": cat,
                "index": i,
                "slsqp_success": bool(slsqp_res.success),
                "cvxpy_success": cvxpy_res["success"],
                "agreement": bool(slsqp_res.success == cvxpy_res["success"]),
                "obj_diff_abs": float(obj_diff_abs) if obj_diff_abs is not None else None,
                "obj_diff_norm": float(obj_diff_norm) if obj_diff_norm is not None else None
            }
            results.append(result)

            if not result["agreement"]:
                disagreements.append({
                    "category": cat,
                    "index": i,
                    "slsqp": result["slsqp_success"],
                    "cvxpy": result["cvxpy_success"],
                    "state": {k: float(v) if isinstance(v, (float, np.floating)) else v
                              for k, v in state.items()}
                })
        print(" done", flush=True)

    n_total = len(results)
    n_slsqp = sum(1 for r in results if r["slsqp_success"])
    n_cvxpy = sum(1 for r in results if r["cvxpy_success"])
    n_agree = sum(1 for r in results if r["agreement"])
    obj_diffs_abs = [r["obj_diff_abs"] for r in results if r["obj_diff_abs"] is not None]
    obj_diffs_norm = [r["obj_diff_norm"] for r in results if r["obj_diff_norm"] is not None]

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08V-G4",
        "version": "0.4.121-classical-08v-g4",
        "baseline": "v0.4.120-classical-08v-g3",
        "seed": SEED,
        "n_per_category": N_PER_CATEGORY,
        "total_states": n_total,
        "Pi_influence": 0.0,
        "formulation": "full_convex (no momentum threshold)",
        "comparison": {
            "n_slsqp_success": n_slsqp,
            "n_cvxpy_success": n_cvxpy,
            "n_agreement": n_agree,
            "agreement_rate": n_agree / n_total,
            "obj_diff_abs_max": float(max(obj_diffs_abs)) if obj_diffs_abs else None,
            "obj_diff_abs_median": float(np.median(obj_diffs_abs)) if obj_diffs_abs else None,
            "obj_diff_norm_max": float(max(obj_diffs_norm)) if obj_diffs_norm else None,
            "obj_diff_norm_median": float(np.median(obj_diffs_norm)) if obj_diffs_norm else None
        },
        "n_disagreements": len(disagreements),
        "disagreements": disagreements,
        "wall_time_s": perf_counter() - t0,
        "note": "Normalized objective comparison. No momentum threshold. Disagreements recorded."
    }
    def convert_bools(obj):
        if isinstance(obj, dict):
            return {k: convert_bools(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_bools(v) for v in obj]
        elif isinstance(obj, (np.bool_, bool)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.integer)):
            return float(obj) if isinstance(obj, np.floating) else int(obj)
        return obj
    report_clean = convert_bools(report)
    raw = json.dumps(report_clean, sort_keys=True).encode()
    report_clean["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report_clean, indent=2))
    return report_clean

if __name__ == "__main__":
    run_comparison()
