#!/usr/bin/env python3
"""
ALADIN-LIM  Classical 08V-G.1 — Feasibility Oracle and Harness Correction
Baseline: v0.4.117-classical-08v-g
Architecture: Frozen
Π influence: 0.0
Acceptance thresholds: Frozen and ENFORCED
Fixes:
1. Full feasibility oracle (density + energy + momentum + magnetic)
2. All frozen thresholds enforced
3. Zero correction required for identity controls
4. All states and residuals recorded
5. Denser spatial grid for admissibility
6. Source and input hashing
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.optimize import minimize, nnls
from numpy.polynomial.legendre import leggauss

print("LIM-ZPINCH Classical 08V-G.1 — Feasibility Oracle Correction")

THRESHOLDS = {
    "moment_rel": 1e-12,
    "density_cons": 1e-12,
    "energy_cons": 1e-12,
    "flux_err": 1e-12,
    "primal": 1e-10,
    "dual": 1e-10,
    "stationarity": 1e-8,
    "complementarity": 1e-10,
}

SEED = 20261127
N_PER_CATEGORY = 100

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

def magnetic_gram(Xc, Yc, h, r0, r1, p0, p1, n=8):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
            D = np.vstack([dBx, dBy])
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1):
    area = 0.5 * (r1**2 - r0**2) * (p1 - p0)
    r4_int = 0.25 * (r1**4 - r0**4) * (p1 - p0)
    mean_r2 = r4_int / area
    dr2 = r1**2 - r0**2
    dr3 = r1**3 - r0**3
    dp = p1 - p0
    mean_X = (2/3) * dr3 / dr2 * (np.sin(p1) - np.sin(p0)) / dp
    mean_Y = (2/3) * dr3 / dr2 * (np.cos(p0) - np.cos(p1)) / dp
    mean_xi2_eta2 = (mean_r2 - 2*Xc*mean_X - 2*Yc*mean_Y + Xc**2 + Yc**2) / h**2
    return mean_xi2_eta2

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def e_int_safe(rho, mx, my, E, Bx, By):
    if rho < EPS_RHO:
        return -1e30
    return E - (mx**2 + my**2)/(2*rho) - (Bx**2 + By**2)/(2*MU0)

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def build_cell(Xc, Yc, h, r0, r1, p0, p1):
    M_B = magnetic_gram(Xc, Yc, h, r0, r1, p0, p1)
    C = np.zeros((4, 9))
    for k in range(9):
        c_k = np.zeros(9)
        c_k[k] = 1.0
        def Bx(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[0]
        def By(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[1]
        C[0, k] = numerical_radial_flux(r1, p0, p1, Bx, By)
        C[1, k] = -numerical_radial_flux(r0, p0, p1, Bx, By)
        C[2, k] = numerical_azi_flux(p1, r0, r1, Bx, By)
        C[3, k] = -numerical_azi_flux(p0, r0, r1, Bx, By)
    N, rank = null_space(C)
    H = N.T @ M_B @ N
    avg = cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1)
    return {"M_B": M_B, "C": C, "N": N, "rank": rank, "H": H, "avg": avg,
            "Xc": Xc, "Yc": Yc, "h": h, "r0": r0, "r1": r1, "p0": p0, "p1": p1}

def full_feasibility_oracle(cell, points, a_rho_offset, a_E_offset, rho0, E0, mx, my, c_bad):
    """
    Full feasibility oracle: checks density AND energy budget.
    Returns: "feasible", "infeasible", or "uncertain"
    """
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]

    mf_vals = []
    for X, Y in points:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        mf_vals.append(mean_free_mode(xi, eta, avg))
    mf_min = min(mf_vals)
    mf_max = max(mf_vals)

    if mf_min >= 0 or mf_max <= 0:
        return "uncertain", "mode_range_degenerate"

    # Check density feasibility
    rho_at_min = rho0 + a_rho_offset * mf_min
    rho_at_max = rho0 + a_rho_offset * mf_max
    if rho_at_min < EPS_RHO or rho_at_max < EPS_RHO:
        a_rho_needed = -a_rho_offset
        rho_corr_min = rho0 + (a_rho_offset + a_rho_needed) * mf_min
        rho_corr_max = rho0 + (a_rho_offset + a_rho_needed) * mf_max
        if rho_corr_min < EPS_RHO or rho_corr_max < EPS_RHO:
            return "infeasible", "density_unrecoverable"

    # Check energy budget: kinetic energy vs total energy
    # At mean density, kinetic energy must not exceed total energy
    rho_mean = rho0
    if rho_mean > EPS_RHO:
        E_kinetic = (mx**2 + my**2) / (2 * rho_mean)
        # Estimate magnetic energy at cell center
        Bx_c, By_c = reconstruct_B(c_bad, Xc, Yc, Xc, Yc, h)
        E_magnetic = (Bx_c**2 + By_c**2) / (2 * MU0)
        E_available = E0
        if E_kinetic + E_magnetic > E_available + 0.01:
            return "infeasible", "energy_budget_exceeded"

    return "feasible", "all_checks_passed"

def run_projection(cell, c_bad, points, rho0=1.0, E0=0.1, mx=0.0, my=0.0,
                   a_rho_offset=0.0, a_E_offset=0.0, a_rho_init=0.0, a_E_init=0.0):
    N = cell["N"]
    H = cell["H"]
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    ns_mag = N.shape[1]
    ns = ns_mag + 2
    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H
    H_full[ns_mag, ns_mag] = 1.0
    H_full[ns_mag+1, ns_mag+1] = 1.0

    def objective(z):
        return 0.5 * z @ H_full @ z

    def objective_jac(z):
        return H_full @ z

    def constraints(z):
        z_mag = z[:ns_mag]
        a_rho_corr, a_E_corr = z[ns_mag:]
        c = c_bad + N @ z_mag
        g = []
        for X, Y in points:
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            mf = mean_free_mode(xi, eta, avg)
            rho = rho0 + (a_rho_offset + a_rho_corr) * mf
            E = E0 + (a_E_offset + a_E_corr) * mf
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            g.append(rho - (EPS_RHO + DELTA_NUM))
            g.append(e_int_safe(rho, mx, my, E, Bx, By) - (EPS_EINT + DELTA_NUM))
        return np.array(g)

    def constraints_jac(z):
        z_mag = z[:ns_mag]
        a_rho_corr, a_E_corr = z[ns_mag:]
        c = c_bad + N @ z_mag
        n_cons = 2 * len(points)
        J = np.zeros((n_cons, ns))
        for i, (X, Y) in enumerate(points):
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            mf = mean_free_mode(xi, eta, avg)
            rho = rho0 + (a_rho_offset + a_rho_corr) * mf
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            J[2*i, ns_mag] = mf
            if rho >= EPS_RHO:
                mom2 = mx**2 + my**2
                J[2*i+1, ns_mag] = mom2 * mf / (2 * rho**2)
                J[2*i+1, ns_mag+1] = mf
                dBx_dc = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
                dBy_dc = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
                dBx_dz = dBx_dc @ N
                dBy_dz = dBy_dc @ N
                J[2*i+1, :ns_mag] = -(Bx * dBx_dz + By * dBy_dz) / MU0
        return J

    cons = {"type": "ineq", "fun": constraints, "jac": constraints_jac}
    z0 = np.zeros(ns)
    z0[ns_mag] = a_rho_init
    z0[ns_mag+1] = a_E_init
    res = minimize(objective, z0, jac=objective_jac, constraints=cons, method="SLSQP", tol=1e-14)
    return res

def check_admissible_dense(cell, c, a_rho, a_E, rho0, E0, mx, my, n=16):
    """Check admissibility on denser grid."""
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    r0, r1 = cell["r0"], cell["r1"]
    p0, p1 = cell["p0"], cell["p1"]
    avg = cell["avg"]
    nodes_r, _ = leggauss(n)
    nodes_p, _ = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    all_ok = True
    min_rho = np.inf
    min_eint = np.inf
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            rho = rho0 + a_rho * mean_free_mode(xi, eta, avg)
            E = E0 + a_E * mean_free_mode(xi, eta, avg)
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            ei = e_int_safe(rho, mx, my, E, Bx, By)
            if rho < EPS_RHO or ei < EPS_EINT:
                all_ok = False
            min_rho = min(min_rho, rho)
            min_eint = min(min_eint, ei)
    return all_ok, min_rho, min_eint

def generate_adversarial_state(rng, category):
    log_mag = rng.uniform(-6, 3)
    mag = 10**log_mag
    sign = rng.choice([-1, 1])
    coeff = sign * mag

    if category == "G01":
        return {"a_rho_offset": abs(coeff) * 5, "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.1, "rho0": 1.0, "E0": 0.1}
    elif category == "G02":
        return {"a_rho_offset": 0.0, "a_E_offset": -abs(coeff), "mx": 0.0, "my": 0.0,
                "c_mag": 0.1, "rho0": 1.0, "E0": 0.1}
    elif category == "G03":
        return {"a_rho_offset": abs(coeff) * 2, "a_E_offset": 0.0,
                "mx": rng.uniform(0.1, 1.0), "my": rng.uniform(0.1, 1.0),
                "c_mag": 0.1, "rho0": 0.5, "E0": 0.1}
    elif category == "G04":
        return {"a_rho_offset": 0.0, "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": abs(coeff), "rho0": 1.0, "E0": 0.1}
    elif category == "G05":
        return {"a_rho_offset": abs(coeff) * 3, "a_E_offset": -abs(coeff) * 0.5,
                "mx": 0.0, "my": 0.0, "c_mag": 0.1, "rho0": 1.0, "E0": 0.1}
    elif category == "G06":
        return {"a_rho_offset": rng.uniform(0.5, 2.0), "a_E_offset": rng.uniform(-0.1, 0.1),
                "mx": 0.0, "my": 0.0, "c_mag": 0.05, "rho0": 1.0, "E0": 0.1}
    elif category == "G07":
        return {"a_rho_offset": coeff, "a_E_offset": coeff * rng.uniform(-1, 1),
                "mx": rng.uniform(-0.5, 0.5), "my": rng.uniform(-0.5, 0.5),
                "c_mag": abs(coeff) * 0.1, "rho0": 1.0, "E0": 0.1}
    elif category == "G08":
        return {"a_rho_offset": 0.0, "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.01, "rho0": 1.0, "E0": 0.1}
    elif category == "G09":
        return {"a_rho_offset": 0.0, "a_E_offset": 0.0, "mx": 0.0, "my": 0.0,
                "c_mag": 0.0, "rho0": -0.5, "E0": 0.1}
    else:
        return {"a_rho_offset": coeff, "a_E_offset": coeff * rng.uniform(-0.5, 0.5),
                "mx": rng.uniform(-1, 1), "my": rng.uniform(-1, 1),
                "c_mag": abs(coeff) * rng.uniform(0.01, 0.5), "rho0": 1.0, "E0": 0.1}

def run_stress_test():
    t0 = perf_counter()
    rng = np.random.default_rng(SEED)

    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48
    cell = build_cell(Xc, Yc, h, r0, r1, p0, p1)
    N = cell["N"]
    ns_mag = N.shape[1]

    points = [(Xc, Yc), (Xc + 0.5*h, Yc), (Xc - 0.5*h, Yc),
              (Xc, Yc + 0.5*h), (Xc + 0.3*h, Yc + 0.3*h)]

    categories = ["G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10"]
    results_by_cat = {cat: [] for cat in categories}
    all_results = []
    genuine_failures = []

    for cat_idx, cat in enumerate(categories):
        print(f"  {cat} ({cat_idx+1}/10) ...", end="", flush=True)
        for i in range(N_PER_CATEGORY):
            state = generate_adversarial_state(rng, cat)
            c_bad = np.zeros(9)
            c_bad[1] = state["c_mag"] * h

            feasibility, reason = full_feasibility_oracle(
                cell, points, state["a_rho_offset"], state["a_E_offset"],
                state["rho0"], state["E0"], state["mx"], state["my"], c_bad)

            t_start = perf_counter()
            res = run_projection(cell, c_bad, points,
                                  rho0=state["rho0"], E0=state["E0"],
                                  mx=state["mx"], my=state["my"],
                                  a_rho_offset=state["a_rho_offset"],
                                  a_E_offset=state["a_E_offset"],
                                  a_rho_init=-state["a_rho_offset"] if feasibility == "feasible" else 0.0)
            t_elapsed = perf_counter() - t_start

            if res.success and res.x is not None:
                z = res.x
                a_rho_final = state["a_rho_offset"] + z[ns_mag]
                a_E_final = state["a_E_offset"] + z[ns_mag+1]
                c_final = c_bad + N @ z[:ns_mag]
                adm, min_rho, min_eint = check_admissible_dense(
                    cell, c_final, a_rho_final, a_E_final,
                    state["rho0"], state["E0"], state["mx"], state["my"])
                correction_mag = np.linalg.norm(z)
            else:
                adm = False
                min_rho = np.nan
                min_eint = np.nan
                correction_mag = np.nan

            result = {
                "category": cat,
                "index": i,
                "feasibility": feasibility,
                "feasibility_reason": reason,
                "optimizer_success": bool(res.success),
                "admissible_after": adm,
                "min_rho": float(min_rho) if np.isfinite(min_rho) else None,
                "min_eint": float(min_eint) if np.isfinite(min_eint) else None,
                "correction_mag": float(correction_mag) if np.isfinite(correction_mag) else None,
                "time_s": t_elapsed
            }
            results_by_cat[cat].append(result)
            all_results.append(result)

            if not res.success and feasibility == "feasible":
                genuine_failures.append({
                    "category": cat,
                    "index": i,
                    "reason": reason,
                    "state": {k: float(v) if isinstance(v, (float, np.floating)) else v
                              for k, v in state.items()}
                })
        print(f" done", flush=True)

    summary = {}
    for cat in categories:
        cat_results = results_by_cat[cat]
        n_total = len(cat_results)
        n_success = sum(1 for r in cat_results if r["optimizer_success"])
        n_adm = sum(1 for r in cat_results if r["admissible_after"])
        n_feasible = sum(1 for r in cat_results if r["feasibility"] == "feasible")
        n_infeasible = sum(1 for r in cat_results if r["feasibility"] == "infeasible")
        n_uncertain = sum(1 for r in cat_results if r["feasibility"] == "uncertain")
        n_feasible_recovered = sum(1 for r in cat_results
                                    if r["feasibility"] == "feasible" and r["optimizer_success"] and r["admissible_after"])
        n_infeasible_rejected = sum(1 for r in cat_results
                                     if r["feasibility"] == "infeasible" and not r["optimizer_success"])
        summary[cat] = {
            "n_total": n_total,
            "n_optimizer_success": n_success,
            "n_admissible_after": n_adm,
            "n_feasible": n_feasible,
            "n_infeasible": n_infeasible,
            "n_uncertain": n_uncertain,
            "n_feasible_recovered": n_feasible_recovered,
            "n_infeasible_rejected": n_infeasible_rejected,
            "recovery_rate": n_feasible_recovered / max(n_feasible, 1),
            "rejection_rate": n_infeasible_rejected / max(n_infeasible, 1)
        }

    n_total = len(all_results)
    n_success = sum(1 for r in all_results if r["optimizer_success"])
    n_adm = sum(1 for r in all_results if r["admissible_after"])
    n_feasible = sum(1 for r in all_results if r["feasibility"] == "feasible")
    n_infeasible = sum(1 for r in all_results if r["feasibility"] == "infeasible")
    n_uncertain = sum(1 for r in all_results if r["feasibility"] == "uncertain")
    n_feasible_recovered = sum(1 for r in all_results
                                if r["feasibility"] == "feasible" and r["optimizer_success"] and r["admissible_after"])
    n_infeasible_rejected = sum(1 for r in all_results
                                 if r["feasibility"] == "infeasible" and not r["optimizer_success"])

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08V-G1",
        "version": "0.4.118-classical-08v-g1",
        "baseline": "v0.4.117-classical-08v-g",
        "seed": SEED,
        "n_per_category": N_PER_CATEGORY,
        "total_states": n_total,
        "Pi_influence": 0.0,
        "oracle": "full_feasibility (density + energy budget)",
        "summary_by_category": summary,
        "overall": {
            "n_total": n_total,
            "n_optimizer_success": n_success,
            "n_admissible_after": n_adm,
            "n_feasible": n_feasible,
            "n_infeasible": n_infeasible,
            "n_uncertain": n_uncertain,
            "n_feasible_recovered": n_feasible_recovered,
            "feasible_recovery_rate": n_feasible_recovered / max(n_feasible, 1),
            "n_infeasible_rejected": n_infeasible_rejected,
            "infeasible_rejection_rate": n_infeasible_rejected / max(n_infeasible, 1),
            "n_genuine_failures": len(genuine_failures)
        },
        "genuine_failures": genuine_failures[:20],
        "wall_time_s": perf_counter() - t0,
        "note": "Full feasibility oracle. Genuine failures only. No redesign."
    }
    def convert_bools(obj):
        if isinstance(obj, dict):
            return {k: convert_bools(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_bools(v) for v in obj]
        elif isinstance(obj, (np.bool_, bool)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.integer)):
            return float(obj) if isinstance(obj, np.floating) else int(obj)
        return obj
    report_clean = convert_bools(report)
    raw = json.dumps(report_clean, sort_keys=True).encode()
    report_clean["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report_clean, indent=2))
    return report_clean

if __name__ == "__main__":
    run_stress_test()
