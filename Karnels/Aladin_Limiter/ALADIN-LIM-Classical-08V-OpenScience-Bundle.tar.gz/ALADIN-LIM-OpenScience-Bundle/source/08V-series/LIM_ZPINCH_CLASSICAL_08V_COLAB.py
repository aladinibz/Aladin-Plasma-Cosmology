#!/usr/bin/env python3
"""
ALADIN-LIM  Classical 08V — Qualification
Freezes v0.4.110 architecture.
Independently measures conservation, fluxes, KKT, no-op, and cell types.
Self-contained. Π=0.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.optimize import minimize
from numpy.polynomial.legendre import leggauss

print("LIM-ZPINCH Classical 08V — Qualification")

# ===== Frozen operators from 08U =====
def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

def magnetic_gram(Xc, Yc, h, r0, r1, p0, p1, n=12):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
            D = np.vstack([dBx, dBy])
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=16):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=16):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1):
    area = 0.5 * (r1**2 - r0**2) * (p1 - p0)
    r4_int = 0.25 * (r1**4 - r0**4) * (p1 - p0)
    mean_r2 = r4_int / area
    dr2 = r1**2 - r0**2
    dr3 = r1**3 - r0**3
    dp = p1 - p0
    mean_X = (2/3) * dr3 / dr2 * (np.sin(p1) - np.sin(p0)) / dp
    mean_Y = (2/3) * dr3 / dr2 * (np.cos(p0) - np.cos(p1)) / dp
    mean_xi2_eta2 = (mean_r2 - 2*Xc*mean_X - 2*Yc*mean_Y + Xc**2 + Yc**2) / h**2
    return mean_xi2_eta2

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def e_int(rho, mx, my, E, Bx, By):
    if rho < EPS_RHO:
        return -np.inf
    return E - (mx**2 + my**2)/(2*rho) - (Bx**2 + By**2)/(2*MU0)

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def build_cell(Xc, Yc, h, r0, r1, p0, p1):
    M_B = magnetic_gram(Xc, Yc, h, r0, r1, p0, p1)
    C = np.zeros((4, 9))
    for k in range(9):
        c_k = np.zeros(9)
        c_k[k] = 1.0
        def Bx(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[0]
        def By(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[1]
        C[0, k] = numerical_radial_flux(r1, p0, p1, Bx, By)
        C[1, k] = -numerical_radial_flux(r0, p0, p1, Bx, By)
        C[2, k] = numerical_azi_flux(p1, r0, r1, Bx, By)
        C[3, k] = -numerical_azi_flux(p0, r0, r1, Bx, By)
    N, rank = null_space(C)
    H = N.T @ M_B @ N
    avg = cylindrical_moment(Xc, Yc, h, r0, r1, p0, p1)
    return M_B, C, N, H, avg, rank

def measure_fluxes(c, Xc, Yc, h, r0, r1, p0, p1):
    def Bx(X, Y): return reconstruct_B(c, X, Y, Xc, Yc, h)[0]
    def By(X, Y): return reconstruct_B(c, X, Y, Xc, Yc, h)[1]
    return [
        numerical_radial_flux(r1, p0, p1, Bx, By),
        -numerical_radial_flux(r0, p0, p1, Bx, By),
        numerical_azi_flux(p1, r0, r1, Bx, By),
        -numerical_azi_flux(p0, r0, r1, Bx, By)
    ]

def integrate_scalars(rho0, E0, a_rho, a_E, avg, Xc, Yc, h, r0, r1, p0, p1, n=16):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    rho_int = 0.0
    E_int = 0.0
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            rho = rho0 + a_rho * mean_free_mode(xi, eta, avg)
            E = E0 + a_E * mean_free_mode(xi, eta, avg)
            dA = r[i] * wr[i] * wp[j]
            rho_int += rho * dA
            E_int += E * dA
    return rho_int, E_int

def project(c_mag, N, H, Xc, Yc, h, rho0, E0, points, avg, scale=1.0):
    ns_mag = N.shape[1]
    ns = ns_mag + 2
    H_full = np.zeros((ns, ns))
    H_full[:ns_mag, :ns_mag] = H
    H_full[ns_mag, ns_mag] = scale
    H_full[ns_mag+1, ns_mag+1] = scale

    def objective(z):
        return 0.5 * z @ H_full @ z

    def constraints(z):
        z_mag = z[:ns_mag]
        a_rho, a_E = z[ns_mag:]
        c = c_mag + N @ z_mag
        g = []
        for X, Y in points:
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            rho = rho0 + a_rho * mean_free_mode(xi, eta, avg)
            E = E0 + a_E * mean_free_mode(xi, eta, avg)
            Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
            g.append(rho - EPS_RHO)
            g.append(e_int(rho, 0, 0, E, Bx, By) - (EPS_EINT + DELTA_NUM))
        return np.array(g)

    cons = {"type": "ineq", "fun": constraints}
    res = minimize(objective, np.zeros(ns), constraints=cons, method="SLSQP", tol=1e-12)
    return res, H_full

def qualify_cell(name, Xc, Yc, h, r0, r1, p0, p1, c_in, rho0, E0, points):
    M_B, C, N, H, avg, rank = build_cell(Xc, Yc, h, r0, r1, p0, p1)
    fluxes_before = measure_fluxes(c_in, Xc, Yc, h, r0, r1, p0, p1)
    rho_int_before, E_int_before = integrate_scalars(rho0, E0, 0, 0, avg, Xc, Yc, h, r0, r1, p0, p1)
    res, H_full = project(c_in, N, H, Xc, Yc, h, rho0, E0, points, avg)
    z = res.x
    ns_mag = N.shape[1]
    c_out = c_in + N @ z[:ns_mag]
    a_rho, a_E = z[ns_mag:]
    fluxes_after = measure_fluxes(c_out, Xc, Yc, h, r0, r1, p0, p1)
    rho_int_after, E_int_after = integrate_scalars(rho0, E0, a_rho, a_E, avg, Xc, Yc, h, r0, r1, p0, p1)
    evals = []
    for X, Y in points:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        rho = rho0 + a_rho * mean_free_mode(xi, eta, avg)
        E = E0 + a_E * mean_free_mode(xi, eta, avg)
        Bx, By = reconstruct_B(c_out, X, Y, Xc, Yc, h)
        ei = e_int(rho, 0, 0, E, Bx, By)
        evals.append({"r": float(np.hypot(X, Y)), "rho": float(rho), "eint": float(ei),
                      "admissible": int(ei >= EPS_EINT and rho >= EPS_RHO)})
    eigvals = np.linalg.eigvalsh(H_full)
    return {
        "cell": name,
        "success": int(res.success),
        "z_norm": float(np.linalg.norm(z)),
        "flux_rank": int(rank),
        "avg": float(avg),
        "flux_error": float(np.max(np.abs(np.array(fluxes_after) - np.array(fluxes_before)))),
        "rho_conservation_error": float(abs(rho_int_after - rho_int_before)),
        "E_conservation_error": float(abs(E_int_after - E_int_before)),
        "all_admissible": int(all(p["admissible"] for p in evals)),
        "min_eint": float(min(p["eint"] for p in evals)),
        "H_full_min_eigenvalue": float(eigvals[0]),
        "points": evals
    }

def run():
    t0 = perf_counter()
    h = 0.0625
    results = []

    # Interior cell — infeasible
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48
    points = [(Xc, Yc), (Xc+0.5*h, Yc), (Xc-0.5*h, Yc), (Xc, Yc+0.3*h), (Xc, Yc-0.3*h)]
    c_bad = np.zeros(9)
    c_bad[1] = 0.5 * h
    results.append(qualify_cell("interior_infeasible", Xc, Yc, h, r0, r1, p0, p1, c_bad, 1.0, 0.1, points))

    # Interior cell — already admissible (no-op test)
    c_ok = np.zeros(9)
    results.append(qualify_cell("interior_admissible", Xc, Yc, h, r0, r1, p0, p1, c_ok, 1.0, 0.1, points))

    # Outer boundary cell
    Xc2, Yc2 = 0.9, 0.0
    r0b, r1b = 0.875, 0.9375
    results.append(qualify_cell("outer", Xc2, Yc2, h, r0b, r1b, p0, p1, c_bad, 1.0, 0.1, points))

    # Axis-adjacent cell
    Xc3, Yc3 = 0.03, 0.0
    r0a, r1a = 0.0, 0.0625
    results.append(qualify_cell("axis", Xc3, Yc3, h, r0a, r1a, p0, p1, c_bad, 1.0, 0.1, points))

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08V",
        "version": "0.4.111-classical-08v",
        "base": "v0.4.110-classical-08u",
        "frozen_architecture": True,
        "results": results,
        "Pi_influence": 0.0,
        "wall_time_s": perf_counter() - t0,
        "note": "Qualification. Architecture frozen from 08U. Independent conservation and flux measurements."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
