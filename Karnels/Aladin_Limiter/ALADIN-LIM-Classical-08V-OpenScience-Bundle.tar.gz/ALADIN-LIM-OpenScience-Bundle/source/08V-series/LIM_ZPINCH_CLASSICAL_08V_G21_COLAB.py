#!/usr/bin/env python3
"""
ALADIN-LIM  Classical 08V-G.21 — High-Precision Certification and Cumulative Closure
Baseline: v0.4.137-classical-08v-g20
Architecture: Frozen
Π influence: 0.0
Frozen half-angle formulation. High-precision verification. Cumulative closure. Bundle evidence.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.optimize import minimize, nnls
from numpy.polynomial.legendre import leggauss

print("LIM-ZPINCH Classical 08V-G.21 — High-Precision Certification")

SEED = 20261127

# Frozen thresholds
PRIMAL_TOL = 1e-10
STATIONARITY_TOL = 1e-8
COMPLEMENTARITY_TOL = 1e-10
CONSERVATION_TOL = 1e-12
DUAL_TOL = 1e-10

# Operating envelope
MAX_COEFFICIENT_MAGNITUDE = 1e6

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

def magnetic_gram(Xc, Yc, h, r0, r1, p0, p1, n=8):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(r1-r0)*nodes_r + 0.5*(r0+r1)
    p = 0.5*(p1-p0)*nodes_p + 0.5*(p0+p1)
    wr = 0.5*(r1-r0)*w_r
    wp = 0.5*(p1-p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, Xc, Yc, h)
            D = np.vstack([dBx, dBy])
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def cylindrical_moment_local(Xc, Yc, h, r0, r1, p0, p1, n=32):
    """Cancellation-free local cylindrical moment using half-angle identity."""
    nodes, weights = leggauss(n)

    Rc = np.hypot(Xc, Yc)
    phic = np.arctan2(Yc, Xc)

    r = 0.5 * (r1 - r0) * nodes + 0.5 * (r1 + r0)
    p = 0.5 * (p1 - p0) * nodes + 0.5 * (p1 + p0)

    R, P = np.meshgrid(r, p, indexing="ij")

    # Half-angle identity: d^2 = (r - Rc)^2 + 4*r*Rc*sin^2((phi - phic)/2)
    distance_sq = (R - Rc)**2 + 4 * R * Rc * np.sin(0.5 * (P - phic))**2

    dr = 0.5 * (r1 - r0)
    dp = 0.5 * (p1 - p0)
    W = R * weights[:, None] * weights[None, :] * dr * dp

    mean_distance_sq = np.sum(W * distance_sq) / np.sum(W)
    mean_xi2_eta2 = mean_distance_sq / h**2

    return mean_xi2_eta2

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def build_cell(Xc, Yc, h, r0, r1, p0, p1):
    M_B = magnetic_gram(Xc, Yc, h, r0, r1, p0, p1)
    C = np.zeros((4, 9))
    for k in range(9):
        c_k = np.zeros(9)
        c_k[k] = 1.0
        def Bx(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[0]
        def By(X, Y, c=c_k): return reconstruct_B(c, X, Y, Xc, Yc, h)[1]
        C[0, k] = numerical_radial_flux(r1, p0, p1, Bx, By)
        C[1, k] = -numerical_radial_flux(r0, p0, p1, Bx, By)
        C[2, k] = numerical_azi_flux(p1, r0, r1, Bx, By)
        C[3, k] = -numerical_azi_flux(p0, r0, r1, Bx, By)
    N, rank = null_space(C)
    H = N.T @ M_B @ N
    avg = cylindrical_moment_local(Xc, Yc, h, r0, r1, p0, p1)
    return {"M_B": M_B, "C": C, "N": N, "rank": rank, "H": H, "avg": avg,
            "Xc": Xc, "Yc": Yc, "h": h, "r0": r0, "r1": r1, "p0": p0, "p1": p1}

def full_cell_bounds(cell, rho0=1.0):
    avg = cell["avg"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    r0, r1 = cell["r0"], cell["r1"]
    p0, p1 = cell["p0"], cell["p1"]

    q_min = -avg

    corners = [
        (r1 * np.cos(p0), r1 * np.sin(p0)),
        (r1 * np.cos(p1), r1 * np.sin(p1)),
        (r0 * np.cos(p0), r0 * np.sin(p0)),
        (r0 * np.cos(p1), r0 * np.sin(p1))
    ]

    q_max = -np.inf
    for X, Y in corners:
        xi = (X - Xc) / h
        eta = (Y - Yc) / h
        q = xi**2 + eta**2 - avg
        q_max = max(q_max, q)

    rho_floor = EPS_RHO + DELTA_NUM

    L = -np.inf
    U = np.inf

    if q_min < -1e-12:
        U = min(U, (rho_floor - rho0) / q_min)
    if q_max > 1e-12:
        L = max(L, (rho_floor - rho0) / q_max)

    return {"L": L, "U": U, "q_min": q_min, "q_max": q_max, "rho_floor": rho_floor}

def compute_mass_conservation_measured(delta_a_rho, cell, n=32):
    """Compute mass conservation residual using actual cylindrical quadrature."""
    nodes, weights = leggauss(n)

    r0, r1 = cell["r0"], cell["r1"]
    p0, p1 = cell["p0"], cell["p1"]
    Xc, Yc, h = cell["Xc"], cell["Yc"], cell["h"]
    avg = cell["avg"]

    r = 0.5 * (r1 - r0) * nodes + 0.5 * (r1 + r0)
    p = 0.5 * (p1 - p0) * nodes + 0.5 * (p1 + p0)

    R, P = np.meshgrid(r, p, indexing="ij")

    xi = (R * np.cos(P) - Xc) / h
    eta = (R * np.sin(P) - Yc) / h

    q = xi**2 + eta**2 - avg

    dr = 0.5 * (r1 - r0)
    dp = 0.5 * (p1 - p0)
    W = R * weights[:, None] * weights[None, :] * dr * dp

    mean_q = np.sum(W * q) / np.sum(W)

    mass_residual = abs(delta_a_rho * mean_q)

    return mass_residual, mean_q

def analytical_full_cell_projection(a_rho_offset, cell, rho0=1.0):
    """Analytical density-only projection with high-precision certification."""
    if np.isfinite(a_rho_offset) and abs(a_rho_offset) > MAX_COEFFICIENT_MAGNITUDE:
        return {"status": "REJECTED", "reason": "outside_operating_envelope", "committed": False}

    if not np.isfinite(a_rho_offset):
        return {"status": "REJECTED", "reason": "nonfinite_input", "committed": False}

    bounds = full_cell_bounds(cell, rho0)
    L, U = bounds["L"], bounds["U"]
    q_min, q_max = bounds["q_min"], bounds["q_max"]
    rho_floor = bounds["rho_floor"]

    if not np.isfinite(L) or not np.isfinite(U):
        return {"status": "REJECTED", "reason": "nonfinite_bounds", "committed": False}

    if L > U:
        return {"status": "REJECTED", "reason": "empty_interval", "committed": False}

    a_rho_final = np.clip(a_rho_offset, L, U)
    delta = a_rho_final - a_rho_offset

    with np.errstate(over="ignore", invalid="ignore"):
        obj = (0.5 * delta) * delta

    if not np.isfinite(obj):
        return {"status": "REJECTED", "reason": "objective_overflow", "committed": False}

    if not np.isfinite(a_rho_final):
        return {"status": "REJECTED", "reason": "nonfinite_output", "committed": False}

    # Scalar KKT diagnostics
    q = np.array([q_min, q_max])
    g = rho0 + a_rho_final * q - rho_floor

    lam = np.zeros(2)
    if a_rho_offset > U:
        lam[0] = delta / q[0]
    elif a_rho_offset < L:
        lam[1] = delta / q[1]

    primal = max(0.0, -np.min(g))
    dual = max(0.0, -np.min(lam))
    stationarity = abs(delta - np.dot(lam, q))
    comp_abs = np.max(np.abs(lam * g))
    comp_norm = np.max(np.abs(lam * g) / np.maximum(1.0, np.abs(lam)))

    # Measured mass conservation
    mass_residual, mean_q = compute_mass_conservation_measured(delta, cell)

    # KKT certification
    kkt_certified = (primal <= PRIMAL_TOL and dual <= DUAL_TOL and
                     stationarity <= STATIONARITY_TOL and comp_abs <= COMPLEMENTARITY_TOL)

    # Conservation certification
    conservation_certified = mass_residual <= CONSERVATION_TOL

    # Full certification
    certified = kkt_certified and conservation_certified
    status = "CERTIFIED" if certified else "FEASIBLE_UNCERTIFIED"
    committed = certified

    return {
        "status": status,
        "committed": committed,
        "a_rho_final": a_rho_final if committed else None,
        "delta": delta,
        "obj": obj,
        "primal": primal,
        "dual": dual,
        "stationarity": stationarity,
        "comp_abs": comp_abs,
        "comp_norm": comp_norm,
        "mass_residual": mass_residual,
        "mean_q": mean_q,
        "kkt_certified": kkt_certified,
        "conservation_certified": conservation_certified
    }

def run_high_precision_certification():
    t0 = perf_counter()

    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48

    cell = build_cell(Xc, Yc, h, r0, r1, p0, p1)

    print(f"  Half-angle moment: {cell['avg']:.16e}", flush=True)

    # Test with cumulative regression cases
    test_offsets = [10.0, 37.546185, 53.474612, 90.987012,
                    -1.0, -2.72949, -3.0, -5.0, -10.0, -100.0,
                    1000.0, -1000.0, 1e4, -1e4, 1e6, -1e6,
                    float("nan"), float("inf"), float("-inf")]

    results = []
    print("  High-precision certification ...", flush=True)

    bounds = full_cell_bounds(cell)
    print(f"    Full-cell bounds: L={bounds['L']:.6f} U={bounds['U']:.6f}", flush=True)

    for offset in test_offsets:
        analytical = analytical_full_cell_projection(offset, cell)

        results.append({
            "offset": offset if np.isfinite(offset) else str(offset),
            "status": analytical["status"],
            "committed": analytical.get("committed", False),
            "mass_residual": analytical.get("mass_residual"),
            "mean_q": analytical.get("mean_q"),
            "kkt_certified": analytical.get("kkt_certified", False),
            "conservation_certified": analytical.get("conservation_certified", False),
            "reason": analytical.get("reason")
        })
        print(f"    offset={offset if np.isfinite(offset) else 'NaN/Inf'} {analytical['status']}", flush=True)

    n_total = len(results)
    n_certified = sum(1 for r in results if r["status"] == "CERTIFIED")
    n_uncertified = sum(1 for r in results if r["status"] == "FEASIBLE_UNCERTIFIED")
    n_rejected = sum(1 for r in results if r["status"] == "REJECTED")
    n_committed = sum(1 for r in results if r.get("committed"))

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08V-G21",
        "version": "0.4.138-classical-08v-g21",
        "baseline": "v0.4.137-classical-08v-g20",
        "total_states": n_total,
        "Pi_influence": 0.0,
        "formulation": "high_precision_certification",
        "operating_envelope": MAX_COEFFICIENT_MAGNITUDE,
        "moment": cell["avg"],
        "full_cell_bounds": {
            "L": bounds["L"],
            "U": bounds["U"],
            "q_min": bounds["q_min"],
            "q_max": bounds["q_max"]
        },
        "summary": {
            "n_certified": n_certified,
            "n_uncertified": n_uncertified,
            "n_rejected": n_rejected,
            "n_committed": n_committed,
            "n_total": n_total
        },
        "results": results,
        "wall_time_s": perf_counter() - t0,
        "note": "High-precision certification. Cumulative closure. Half-angle formulation frozen."
    }
    def convert_bools(obj):
        if isinstance(obj, dict):
            return {k: convert_bools(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_bools(v) for v in obj]
        elif isinstance(obj, (np.bool_, bool)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.integer)):
            return float(obj) if isinstance(obj, np.floating) else int(obj)
        return obj
    report_clean = convert_bools(report)
    raw = json.dumps(report_clean, sort_keys=True).encode()
    report_clean["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report_clean, indent=2))
    return report_clean

if __name__ == "__main__":
    run_high_precision_certification()
