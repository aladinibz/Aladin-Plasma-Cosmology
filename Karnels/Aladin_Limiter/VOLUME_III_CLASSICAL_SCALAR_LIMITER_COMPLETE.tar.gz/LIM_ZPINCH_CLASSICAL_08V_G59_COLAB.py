#!/usr/bin/env python3
"""
ALADIN-LIM  Classical 08V-G.59 — Final Evidence Integrity
Baseline: v0.4.173-classical-08v-g56
Published reference: Volume II — DOI 10.5281/zenodo.24603335
Analytical mathematics: FROZEN
Certification architecture: FROZEN
Acceptance thresholds: FROZEN
Final evidence integrity. Complete certificate export. Actual snapshot cross-process verification.
"""
import numpy as np
import json, hashlib, subprocess, os, sys, tempfile
from time import perf_counter
from scipy.optimize import minimize, nnls
from numpy.polynomial.legendre import leggauss

try:
    import mpmath as mp
    HAS_MPMATH = True
except ImportError:
    HAS_MPMATH = False
    print("Warning: mpmath not available, certification will fail closed")

print("LIM-ZPINCH Classical 08V-G.59 — Final Evidence Integrity")

SEED = 20261127

PRIMAL_TOL = 1e-10
STATIONARITY_TOL = 1e-8
COMPLEMENTARITY_TOL = 1e-10
CONSERVATION_TOL = 1e-12
DUAL_TOL = 1e-10
ENERGY_TOL = 1e-12
FLUX_TOL = 1e-12
EINT_TOL = 1e-10
MOMENTUM_TOL = 1e-12

MAX_COEFFICIENT_MAGNITUDE = 1e6
MU0 = 1.0
EPS_RHO = 1e-8
EPS_EINT = 1e-8
DELTA_NUM = 1e-9

FORMULATION_VERSION = "0.4.176-classical-08v-g59"
MOMENT_VALIDATION_TOL = 1e-12

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def D_B_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
    dBy = np.array([-1, 0, -2*xi, -eta, 0, -3*xi**2, -2*xi*eta, -eta**2, 0]) / h
    return dBx, dBy

# ---- Immutable Canonical Geometry ----

class CanonicalGeometry:
    def __init__(self, Xc, Yc, h, r0, r1, p0, p1):
        if not all(np.isfinite([Xc, Yc, h, r0, r1, p0, p1])):
            raise ValueError("Nonfinite geometry inputs")
        if h <= 0:
            raise ValueError("Non-positive cell scale")
        if r0 < 0 or r1 <= r0:
            raise ValueError("Invalid radial bounds")
        object.__setattr__(self, "Xc", float(Xc))
        object.__setattr__(self, "Yc", float(Yc))
        object.__setattr__(self, "h", float(h))
        object.__setattr__(self, "r0", float(r0))
        object.__setattr__(self, "r1", float(r1))
        if p1 < p0:
            raise ValueError("Reversed angular interval not supported")
        span = p1 - p0
        if span <= 0:
            raise ValueError("Zero-width angular interval")
        if span > 2 * np.pi:
            raise ValueError("Oversized angular span exceeds one full revolution")
        object.__setattr__(self, "p0", float(p0))
        object.__setattr__(self, "p1", float(p1))
        object.__setattr__(self, "span", float(span))
        object.__setattr__(self, "is_full", span == 2 * np.pi)

    def __setattr__(self, name, value):
        raise AttributeError("CanonicalGeometry is immutable")

    def fingerprint(self):
        return (self.Xc, self.Yc, self.h, self.r0, self.r1, self.p0, self.p1)

    def angular_membership(self, phi):
        if self.is_full:
            return True
        return self.p0 <= phi <= self.p1

    def stationary_points(self):
        if self.is_full:
            return [k * np.pi / 2 for k in range(4)]
        k_min = int(np.floor(self.p0 / (np.pi / 2))) - 1
        k_max = int(np.ceil(self.p1 / (np.pi / 2))) + 1
        candidates = []
        for k in range(k_min, k_max + 1):
            phi = k * np.pi / 2
            if self.angular_membership(phi):
                candidates.append(phi)
        return candidates

    def extrema_points(self):
        points = [
            (self.r0 * np.cos(self.p0), self.r0 * np.sin(self.p0)),
            (self.r0 * np.cos(self.p1), self.r0 * np.sin(self.p1)),
            (self.r1 * np.cos(self.p0), self.r1 * np.sin(self.p0)),
            (self.r1 * np.cos(self.p1), self.r1 * np.sin(self.p1)),
        ]
        for phi in self.stationary_points():
            points.append((self.r0 * np.cos(phi), self.r0 * np.sin(phi)))
            points.append((self.r1 * np.cos(phi), self.r1 * np.sin(phi)))
        return points

    def density_extrema_points(self):
        points = self.extrema_points()
        phic = np.arctan2(self.Yc, self.Xc)
        k_min = int(np.floor((self.p0 - phic) / np.pi)) - 1
        k_max = int(np.ceil((self.p1 - phic) / np.pi)) + 1
        for k in range(k_min, k_max + 1):
            phi = phic + k * np.pi
            if self.angular_membership(phi):
                points.append((self.r0 * np.cos(phi), self.r0 * np.sin(phi)))
                points.append((self.r1 * np.cos(phi), self.r1 * np.sin(phi)))
        return points

def outward_upper(x):
    if not np.isfinite(x):
        return x
    return np.nextafter(x, np.inf)

def outward_lower(x):
    if not np.isfinite(x):
        return x
    return np.nextafter(x, -np.inf)

def magnetic_gram(geom, n=8):
    nodes_r, w_r = leggauss(n)
    nodes_p, w_p = leggauss(n)
    r = 0.5*(geom.r1-geom.r0)*nodes_r + 0.5*(geom.r0+geom.r1)
    p = 0.5*(geom.p1-geom.p0)*nodes_p + 0.5*(geom.p0+geom.p1)
    wr = 0.5*(geom.r1-geom.r0)*w_r
    wp = 0.5*(geom.p1-geom.p0)*w_p
    M = np.zeros((9, 9))
    for i in range(n):
        for j in range(n):
            X = r[i]*np.cos(p[j])
            Y = r[i]*np.sin(p[j])
            dBx, dBy = D_B_basis(X, Y, geom.Xc, geom.Yc, geom.h)
            D = np.vstack([dBx, dBy])
            dA = r[i] * wr[i] * wp[j]
            M += D.T @ D * dA
    return M

def numerical_radial_flux(r, geom, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    p = 0.5*(geom.p1-geom.p0)*nodes + 0.5*(geom.p0+geom.p1)
    wp = 0.5*(geom.p1-geom.p0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, geom, Bx_func, By_func, n=12):
    nodes, w = leggauss(n)
    r = 0.5*(geom.r1-geom.r0)*nodes + 0.5*(geom.r0+geom.r1)
    wr = 0.5*(geom.r1-geom.r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def cylindrical_moment_reference(geom, dps=70):
    if not HAS_MPMATH:
        raise RuntimeError("Independent certification unavailable: mpmath not installed")
    with mp.workdps(dps):
        r0 = mp.mpf(float(geom.r0))
        r1 = mp.mpf(float(geom.r1))
        p0 = mp.mpf(float(geom.p0))
        p1 = mp.mpf(float(geom.p1))
        Xc = mp.mpf(float(geom.Xc))
        Yc = mp.mpf(float(geom.Yc))
        h = mp.mpf(float(geom.h))
        radial_area = (r1**2 - r0**2) / 2
        mean_r = (r1**3 - r0**3) / (3 * radial_area)
        mean_r2 = (r1**2 + r0**2) / 2
        mean_X = mean_r * (mp.sin(p1) - mp.sin(p0)) / (p1 - p0)
        mean_Y = mean_r * (mp.cos(p0) - mp.cos(p1)) / (p1 - p0)
        return (mean_r2 - 2*Xc*mean_X - 2*Yc*mean_Y + Xc**2 + Yc**2) / h**2

def null_space(C, tol=1e-12):
    U, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank = (s > tol).sum()
    return Vt[rank:].T, rank

def mean_free_mode(xi, eta, avg):
    return xi**2 + eta**2 - avg

def build_cell(Xc, Yc, h, r0, r1, p0, p1):
    geom = CanonicalGeometry(Xc, Yc, h, r0, r1, p0, p1)
    M_B = magnetic_gram(geom)
    C = np.zeros((4, 9))
    for k in range(9):
        c_k = np.zeros(9)
        c_k[k] = 1.0
        def Bx(X, Y, c=c_k): return reconstruct_B(c, X, Y, geom.Xc, geom.Yc, geom.h)[0]
        def By(X, Y, c=c_k): return reconstruct_B(c, X, Y, geom.Xc, geom.Yc, geom.h)[1]
        C[0, k] = numerical_radial_flux(geom.r1, geom, Bx, By)
        C[1, k] = -numerical_radial_flux(geom.r0, geom, Bx, By)
        C[2, k] = numerical_azi_flux(geom.p1, geom, Bx, By)
        C[3, k] = -numerical_azi_flux(geom.p0, geom, Bx, By)
    N, rank = null_space(C)
    H = N.T @ M_B @ N
    if HAS_MPMATH:
        avg_hp = cylindrical_moment_reference(geom, 70)
        avg = float(avg_hp)
    else:
        raise RuntimeError("High-precision moment required")
    return {"M_B": M_B, "C": C, "N": N, "rank": rank, "H": H, "avg": avg,
            "Xc": geom.Xc, "Yc": geom.Yc, "h": geom.h,
            "r0": geom.r0, "r1": geom.r1, "p0": geom.p0, "p1": geom.p1,
            "geom": geom}

def full_cell_bounds_from_params(Xc, Yc, h, r0, r1, p0, p1, stored_moment, rho0=1.0):
    geom = CanonicalGeometry(Xc, Yc, h, r0, r1, p0, p1)
    avg = stored_moment
    q_min = -avg
    points = geom.density_extrema_points()
    q_max = -np.inf
    for X, Y in points:
        xi = (X - geom.Xc) / geom.h
        eta = (Y - geom.Yc) / geom.h
        q = xi**2 + eta**2 - avg
        q_max = max(q_max, q)
    rho_floor = EPS_RHO + DELTA_NUM
    L = -np.inf
    U = np.inf
    if q_min < -1e-12:
        U = min(U, (rho_floor - rho0) / q_min)
    if q_max > 1e-12:
        L = max(L, (rho_floor - rho0) / q_max)
    if np.isfinite(L):
        L = outward_upper(L)
    if np.isfinite(U):
        U = outward_lower(U)
    return {"L": L, "U": U, "q_min": q_min, "q_max": q_max, "rho_floor": rho_floor}

def compute_mass_conservation_high_precision(delta_a_rho, geom, stored_moment, dps=70):
    if not HAS_MPMATH:
        raise RuntimeError("Independent certification unavailable: mpmath not installed")
    with mp.workdps(dps):
        reference = cylindrical_moment_reference(geom, dps)
        stored = mp.mpf(float(stored_moment))
        delta = mp.mpf(float(delta_a_rho))
        mean_q = reference - stored
        residual = abs(delta * mean_q)
        passed = mp.isfinite(residual) and residual <= mp.mpf("1e-12")
        return float(residual), float(mean_q), bool(passed)

def validate_stored_moment(Xc, Yc, h, r0, r1, p0, p1, stored_moment, dps=70):
    if not HAS_MPMATH:
        return False, np.nan
    geom = CanonicalGeometry(Xc, Yc, h, r0, r1, p0, p1)
    with mp.workdps(dps):
        reference = cylindrical_moment_reference(geom, dps)
        stored = mp.mpf(float(stored_moment))
        residual = abs(reference - stored)
        passed = residual <= mp.mpf(str(MOMENT_VALIDATION_TOL))
        return bool(passed), float(residual)

def analytical_full_cell_projection_from_params(a_rho_offset, Xc, Yc, h, r0, r1, p0, p1, stored_moment, rho0=1.0):
    if np.isfinite(a_rho_offset) and abs(a_rho_offset) > MAX_COEFFICIENT_MAGNITUDE:
        return {"status": "REJECTED", "reason": "outside_operating_envelope", "committed": False}
    if not np.isfinite(a_rho_offset):
        return {"status": "REJECTED", "reason": "nonfinite_input", "committed": False}
    
    geom = CanonicalGeometry(Xc, Yc, h, r0, r1, p0, p1)
    bounds = full_cell_bounds_from_params(Xc, Yc, h, r0, r1, p0, p1, stored_moment, rho0)
    L, U = bounds["L"], bounds["U"]
    q_min, q_max = bounds["q_min"], bounds["q_max"]
    rho_floor = bounds["rho_floor"]
    if not np.isfinite(L) or not np.isfinite(U):
        return {"status": "REJECTED", "reason": "nonfinite_bounds", "committed": False}
    if L > U:
        return {"status": "REJECTED", "reason": "empty_interval", "committed": False}
    a_rho_final = np.clip(a_rho_offset, L, U)
    delta = a_rho_final - a_rho_offset
    with np.errstate(over="ignore", invalid="ignore"):
        obj = (0.5 * delta) * delta
    if not np.isfinite(obj):
        return {"status": "REJECTED", "reason": "objective_overflow", "committed": False}
    if not np.isfinite(a_rho_final):
        return {"status": "REJECTED", "reason": "nonfinite_output", "committed": False}
    q = np.array([q_min, q_max])
    g = rho0 + a_rho_final * q - rho_floor
    lam = np.zeros(2)
    if a_rho_offset > U:
        lam[0] = delta / q[0]
    elif a_rho_offset < L:
        lam[1] = delta / q[1]
    primal = max(0.0, -np.min(g))
    dual = max(0.0, -np.min(lam))
    stationarity = abs(delta - np.dot(lam, q))
    comp_abs = np.max(np.abs(lam * g))
    comp_norm = np.max(np.abs(lam * g) / np.maximum(1.0, np.abs(lam)))
    try:
        mass_residual_hp, mean_q_hp, conservation_hp = compute_mass_conservation_high_precision(delta, geom, stored_moment)
        hp_available = True
    except RuntimeError as e:
        return {"status": "REJECTED", "reason": "certification_unavailable", "committed": False, "error": str(e)}
    kkt_certified = (primal <= PRIMAL_TOL and dual <= DUAL_TOL and
                     stationarity <= STATIONARITY_TOL and comp_abs <= COMPLEMENTARITY_TOL)
    conservation_certified = conservation_hp
    density_certified = kkt_certified and conservation_certified
    return {
        "status": "DENSITY_CERTIFIED" if density_certified else "DENSITY_UNCERTIFIED",
        "committed": False,
        "a_rho_final": a_rho_final if density_certified else None,
        "delta": delta, "obj": obj,
        "primal": primal, "dual": dual, "stationarity": stationarity,
        "comp_abs": comp_abs, "comp_norm": comp_norm,
        "mass_residual_hp": mass_residual_hp,
        "mean_q_hp": mean_q_hp,
        "kkt_certified": kkt_certified,
        "conservation_hp": conservation_hp,
        "density_certified": density_certified,
        "hp_available": hp_available,
        "bounds": bounds,
        "a_rho_input": a_rho_offset,
        "lam": lam,
        "q": q
    }

def evaluate_candidate_kkt_corrected(a_before, a_after, rho0, L, U, q_min, q_max, rho_floor):
    delta = a_after - a_before
    q = np.array([q_min, q_max])
    g = rho0 + a_after * q - rho_floor
    
    lam = np.zeros(2)
    if a_before > U:
        lam[0] = delta / q_min if abs(q_min) > 1e-12 else 0.0
    elif a_before < L:
        lam[1] = delta / q_max if abs(q_max) > 1e-12 else 0.0
    
    primal = max(0.0, -np.min(g))
    dual = max(0.0, -np.min(lam))
    stationarity = abs(delta - np.dot(lam, q))
    comp_abs = np.max(np.abs(lam * g))
    
    kkt_certified = (primal <= PRIMAL_TOL and dual <= DUAL_TOL and
                     stationarity <= STATIONARITY_TOL and comp_abs <= COMPLEMENTARITY_TOL)
    
    return {
        "primal": primal,
        "dual": dual,
        "stationarity": stationarity,
        "comp_abs": comp_abs,
        "kkt_certified": kkt_certified,
        "lam": lam,
        "g": g
    }

# ---- Fully Immutable State Snapshot ----

class FullyImmutableSnapshot:
    def __init__(self, rho0, m0, E0, c_B, a_rho, Xc, Yc, h, r0, r1, p0, p1, stored_moment):
        object.__setattr__(self, "rho0", float(rho0))
        object.__setattr__(self, "m0", float(m0))
        object.__setattr__(self, "E0", float(E0))
        object.__setattr__(self, "a_rho", float(a_rho))
        
        if len(c_B) != 9:
            raise ValueError(f"Magnetic coefficient vector must have length 9, got {len(c_B)}")
        
        c_B_tuple = tuple(float(x) for x in c_B)
        object.__setattr__(self, "c_B_tuple", c_B_tuple)
        
        object.__setattr__(self, "Xc", float(Xc))
        object.__setattr__(self, "Yc", float(Yc))
        object.__setattr__(self, "h", float(h))
        object.__setattr__(self, "r0", float(r0))
        object.__setattr__(self, "r1", float(r1))
        object.__setattr__(self, "p0", float(p0))
        object.__setattr__(self, "p1", float(p1))
        object.__setattr__(self, "stored_moment", float(stored_moment))
        object.__setattr__(self, "formulation_version", FORMULATION_VERSION)
        
        fingerprint = self._compute_sha256()
        object.__setattr__(self, "sha256_fingerprint", fingerprint)

    def __setattr__(self, name, value):
        raise AttributeError("FullyImmutableSnapshot is immutable")

    def _compute_sha256(self):
        data = {
            "rho0": self.rho0,
            "m0": self.m0,
            "E0": self.E0,
            "a_rho": self.a_rho,
            "c_B": list(self.c_B_tuple),
            "Xc": self.Xc,
            "Yc": self.Yc,
            "h": self.h,
            "r0": self.r0,
            "r1": self.r1,
            "p0": self.p0,
            "p1": self.p1,
            "stored_moment": self.stored_moment,
            "formulation_version": self.formulation_version
        }
        raw = json.dumps(data, sort_keys=True).encode()
        return hashlib.sha256(raw).hexdigest()

    @property
    def c_B(self):
        arr = np.array(self.c_B_tuple, dtype=float)
        arr.flags.writeable = False
        return arr

    def verify_integrity(self):
        current = self._compute_sha256()
        return current == self.sha256_fingerprint

    def basis_matches(self, other):
        return (self.stored_moment == other.stored_moment and
                self.Xc == other.Xc and self.Yc == other.Yc and
                self.h == other.h and
                self.r0 == other.r0 and self.r1 == other.r1 and
                self.p0 == other.p0 and self.p1 == other.p1 and
                self.formulation_version == other.formulation_version)

    def get_geometry(self):
        return CanonicalGeometry(self.Xc, self.Yc, self.h, self.r0, self.r1, self.p0, self.p1)

    def to_dict(self):
        return {
            "rho0": self.rho0,
            "m0": self.m0,
            "E0": self.E0,
            "a_rho": self.a_rho,
            "c_B": list(self.c_B_tuple),
            "Xc": self.Xc,
            "Yc": self.Yc,
            "h": self.h,
            "r0": self.r0,
            "r1": self.r1,
            "p0": self.p0,
            "p1": self.p1,
            "stored_moment": self.stored_moment,
            "formulation_version": self.formulation_version,
            "sha256_fingerprint": self.sha256_fingerprint
        }

def verify_complete_mass_conservation_hp(snapshot_before, snapshot_after, dps=70):
    if not HAS_MPMATH:
        return False, np.nan
    
    if not snapshot_before.basis_matches(snapshot_after):
        return False, np.nan
    
    with mp.workdps(dps):
        rho0_before = mp.mpf(float(snapshot_before.rho0))
        rho0_after = mp.mpf(float(snapshot_after.rho0))
        a_before = mp.mpf(float(snapshot_before.a_rho))
        a_after = mp.mpf(float(snapshot_after.a_rho))
        
        stored = mp.mpf(float(snapshot_before.stored_moment))
        geom = snapshot_before.get_geometry()
        reference = cylindrical_moment_reference(geom, dps)
        mean_q = reference - stored
        
        mass_before = rho0_before + a_before * mean_q
        mass_after = rho0_after + a_after * mean_q
        residual = abs(mass_after - mass_before)
        
        passed = mp.isfinite(residual) and residual <= mp.mpf("1e-12")
        return bool(passed), float(residual)

def verify_momentum_conservation(snapshot_before, snapshot_after):
    if not np.isfinite(snapshot_before.m0) or not np.isfinite(snapshot_after.m0):
        return False, np.nan
    residual = abs(snapshot_after.m0 - snapshot_before.m0)
    return residual <= MOMENTUM_TOL, residual

def verify_total_energy(snapshot_before, snapshot_after):
    if not np.isfinite(snapshot_before.E0) or not np.isfinite(snapshot_after.E0):
        return False, np.nan
    residual = abs(snapshot_after.E0 - snapshot_before.E0)
    return residual <= ENERGY_TOL, residual

def verify_magnetic_flux_all_faces(snapshot_before, snapshot_after):
    if not np.all(np.isfinite(snapshot_before.c_B)) or not np.all(np.isfinite(snapshot_after.c_B)):
        return False, np.nan
    geom = snapshot_before.get_geometry()
    c_before = snapshot_before.c_B
    c_after = snapshot_after.c_B
    def Bx_b(X, Y): return reconstruct_B(c_before, X, Y, geom.Xc, geom.Yc, geom.h)[0]
    def By_b(X, Y): return reconstruct_B(c_before, X, Y, geom.Xc, geom.Yc, geom.h)[1]
    def Bx_a(X, Y): return reconstruct_B(c_after, X, Y, geom.Xc, geom.Yc, geom.h)[0]
    def By_a(X, Y): return reconstruct_B(c_after, X, Y, geom.Xc, geom.Yc, geom.h)[1]
    faces = [
        ("radial_outer", geom.r1, True),
        ("radial_inner", geom.r0, True),
        ("azi_right", geom.p1, False),
        ("azi_left", geom.p0, False),
    ]
    max_residual = 0.0
    for name, val, is_radial in faces:
        if is_radial:
            fb = numerical_radial_flux(val, geom, Bx_b, By_b)
            fa = numerical_radial_flux(val, geom, Bx_a, By_a)
        else:
            fb = numerical_azi_flux(val, geom, Bx_b, By_b)
            fa = numerical_azi_flux(val, geom, Bx_a, By_a)
        if not np.isfinite(fb) or not np.isfinite(fa):
            return False, np.nan
        max_residual = max(max_residual, abs(fa - fb))
    return max_residual <= FLUX_TOL, max_residual

def verify_strict_scalar_contract(snapshot_before, snapshot_after):
    """
    Strict scalar modification contract.
    Exact equality for all protected fields. Only a_rho may change.
    """
    rho0_unchanged = snapshot_before.rho0 == snapshot_after.rho0
    m0_unchanged = snapshot_before.m0 == snapshot_after.m0
    E0_unchanged = snapshot_before.E0 == snapshot_after.E0
    c_B_unchanged = snapshot_before.c_B_tuple == snapshot_after.c_B_tuple
    basis_unchanged = snapshot_before.basis_matches(snapshot_after)
    
    return rho0_unchanged and m0_unchanged and E0_unchanged and c_B_unchanged and basis_unchanged

def rigorous_magnetic_energy_upper_bound(snapshot):
    geom = snapshot.get_geometry()
    h = geom.h
    if h <= 0:
        return np.nan
    points = geom.extrema_points()
    A = max(abs((X - geom.Xc) / h) for X, Y in points)
    D = max(abs((Y - geom.Yc) / h) for X, Y in points)
    A = outward_upper(A)
    D = outward_upper(D)
    c = snapshot.c_B
    Mx = (1.0 / h) * (
        abs(c[1]) + abs(c[3])*A + 2*abs(c[4])*D
        + abs(c[6])*A**2 + 2*abs(c[7])*A*D + 3*abs(c[8])*D**2
    )
    My = (1.0 / h) * (
        abs(c[0]) + 2*abs(c[2])*A + abs(c[3])*D
        + 3*abs(c[5])*A**2 + 2*abs(c[6])*A*D + abs(c[7])*D**2
    )
    B2_max = Mx**2 + My**2
    if not np.isfinite(B2_max):
        return np.nan
    return outward_upper(B2_max)

def verify_internal_energy_admissibility(snapshot):
    if not np.isfinite(snapshot.a_rho) or not np.isfinite(snapshot.E0) or not np.isfinite(snapshot.m0):
        return False, np.nan
    if not np.all(np.isfinite(snapshot.c_B)):
        return False, np.nan
    bounds = full_cell_bounds_from_params(
        snapshot.Xc, snapshot.Yc, snapshot.h, snapshot.r0, snapshot.r1,
        snapshot.p0, snapshot.p1, snapshot.stored_moment, snapshot.rho0
    )
    q_min = bounds["q_min"]
    q_max = bounds["q_max"]
    rho_at_qmin = snapshot.rho0 + snapshot.a_rho * q_min
    rho_at_qmax = snapshot.rho0 + snapshot.a_rho * q_max
    rho_min = min(rho_at_qmin, rho_at_qmax)
    if not np.isfinite(rho_min) or rho_min <= EPS_RHO:
        return False, np.nan
    B2_max = rigorous_magnetic_energy_upper_bound(snapshot)
    if not np.isfinite(B2_max):
        return False, np.nan
    try:
        with np.errstate(over="raise", invalid="raise"):
            kinetic = 0.5 * snapshot.m0**2 / rho_min
            magnetic = 0.5 * B2_max / MU0
            eint_min = snapshot.E0 - kinetic - magnetic
    except (OverflowError, FloatingPointError):
        return False, np.nan
    if not np.isfinite(eint_min):
        return False, np.nan
    return eint_min >= EPS_EINT, eint_min

# ---- Independent Certificate Authority with Overflow Protection (G.59) ----

def independent_certificate_authority(snapshot_before, snapshot_after):
    """
    Independent certificate authority with overflow protection.
    Final evidence integrity. Complete evidence preservation.
    """
    gates = {}
    
    try:
        # Verify snapshot integrity
        integrity_before = snapshot_before.verify_integrity()
        integrity_after = snapshot_after.verify_integrity()
        gates["integrity_before"] = integrity_before
        gates["integrity_after"] = integrity_after
        if not integrity_before or not integrity_after:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "integrity_violation"
            return gates
        
        # Strict scalar modification contract
        strict_contract = verify_strict_scalar_contract(snapshot_before, snapshot_after)
        gates["strict_scalar_contract"] = strict_contract
        if not strict_contract:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "unauthorized_modification"
            return gates
        
        # Verify reconstruction basis matches
        basis_ok = snapshot_before.basis_matches(snapshot_after)
        gates["basis_matches"] = basis_ok
        if not basis_ok:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "basis_mismatch"
            return gates
        
        # Validate stored moment against high-precision reference
        moment_valid, moment_residual = validate_stored_moment(
            snapshot_before.Xc, snapshot_before.Yc, snapshot_before.h,
            snapshot_before.r0, snapshot_before.r1,
            snapshot_before.p0, snapshot_before.p1,
            snapshot_before.stored_moment
        )
        gates["moment_valid"] = moment_valid
        gates["moment_residual"] = moment_residual
        if not moment_valid:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "invalid_stored_moment"
            return gates
        
        # Coefficients must be finite
        if not np.isfinite(snapshot_before.a_rho) or not np.isfinite(snapshot_after.a_rho):
            gates["release_authorized"] = False
            gates["rejection_reason"] = "nonfinite_coefficients"
            return gates
        
        # Independently recompute density projection from immutable parameters
        analytical = analytical_full_cell_projection_from_params(
            snapshot_before.a_rho,
            snapshot_before.Xc, snapshot_before.Yc, snapshot_before.h,
            snapshot_before.r0, snapshot_before.r1,
            snapshot_before.p0, snapshot_before.p1,
            snapshot_before.stored_moment,
            snapshot_before.rho0
        )
        
        # Verify final coefficient matches independent projection
        a_final_expected = analytical.get("a_rho_final")
        if a_final_expected is None:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "projection_failed"
            return gates
        
        # Exact equality for identity classification
        is_identity = snapshot_before.a_rho == a_final_expected
        if is_identity:
            coefficient_matches = snapshot_after.a_rho == snapshot_before.a_rho
        else:
            coefficient_matches = snapshot_after.a_rho == a_final_expected
        gates["coefficient_matches"] = coefficient_matches
        gates["is_identity"] = is_identity
        if not coefficient_matches:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "coefficient_mismatch"
            return gates
        
        # Evaluate KKT conditions using feasible bounds L, U
        bounds = analytical.get("bounds", {})
        L = bounds.get("L", -np.inf)
        U = bounds.get("U", np.inf)
        q_min = bounds.get("q_min", 0)
        q_max = bounds.get("q_max", 0)
        rho_floor = bounds.get("rho_floor", EPS_RHO + DELTA_NUM)
        
        candidate_kkt = evaluate_candidate_kkt_corrected(
            snapshot_before.a_rho, snapshot_after.a_rho,
            snapshot_before.rho0, L, U, q_min, q_max, rho_floor
        )
        
        gates["candidate_kkt_certified"] = candidate_kkt["kkt_certified"]
        gates["candidate_primal"] = candidate_kkt["primal"]
        gates["candidate_dual"] = candidate_kkt["dual"]
        gates["candidate_stationarity"] = candidate_kkt["stationarity"]
        gates["candidate_comp_abs"] = candidate_kkt["comp_abs"]
        gates["candidate_lam"] = candidate_kkt["lam"].tolist()
        gates["bounds_L"] = L
        gates["bounds_U"] = U
        
        if not candidate_kkt["kkt_certified"]:
            gates["release_authorized"] = False
            gates["rejection_reason"] = "candidate_kkt_violation"
            return gates
        
        gates["conservation_hp"] = analytical.get("conservation_hp", False)
        gates["density_certified"] = analytical.get("density_certified", False)
        
        # Complete mass conservation in high precision
        mass_ok, mass_res = verify_complete_mass_conservation_hp(snapshot_before, snapshot_after)
        gates["mass_conservation"] = mass_ok
        gates["mass_residual"] = mass_res
        
        # Momentum conservation
        mom_ok, mom_res = verify_momentum_conservation(snapshot_before, snapshot_after)
        gates["momentum_conservation"] = mom_ok
        gates["momentum_residual"] = mom_res
        
        # Energy conservation
        energy_ok, energy_res = verify_total_energy(snapshot_before, snapshot_after)
        gates["energy_conservation"] = energy_ok
        gates["energy_residual"] = energy_res
        
        # Magnetic flux conservation
        flux_ok, flux_res = verify_magnetic_flux_all_faces(snapshot_before, snapshot_after)
        gates["flux_conservation"] = flux_ok
        gates["flux_residual"] = flux_res
        
        # Internal energy admissibility
        eint_ok, eint_min = verify_internal_energy_admissibility(snapshot_after)
        gates["eint_admissible"] = eint_ok
        gates["eint_min"] = eint_min
        
        # Fail-closed: ALL gates must pass
        all_pass = all([
            gates.get("integrity_before", False),
            gates.get("integrity_after", False),
            gates.get("strict_scalar_contract", False),
            gates.get("basis_matches", False),
            gates.get("moment_valid", False),
            gates.get("coefficient_matches", False),
            gates.get("candidate_kkt_certified", False),
            gates.get("density_certified", False),
            gates.get("conservation_hp", False),
            gates.get("mass_conservation", False),
            gates.get("momentum_conservation", False),
            gates.get("energy_conservation", False),
            gates.get("flux_conservation", False),
            gates.get("eint_admissible", False)
        ])
        gates["release_authorized"] = all_pass
        if not all_pass:
            gates["rejection_reason"] = "gate_failed"
        
        return gates
    
    except (ValueError, RuntimeError, OverflowError, FloatingPointError) as e:
        gates["release_authorized"] = False
        gates["rejection_reason"] = f"controlled_rejection: {type(e).__name__}"
        return gates

def convert_bools(obj):
    if isinstance(obj, dict):
        return {k: convert_bools(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_bools(v) for v in obj]
    elif isinstance(obj, (np.bool_, bool)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.integer)):
        return float(obj) if isinstance(obj, np.floating) else int(obj)
    return obj


def run_publication_release_gate():
    t0 = perf_counter()
    print("LIM-ZPINCH Classical 08V-G.59 — Final Evidence Integrity", flush=True)
    print(f"  mpmath available: {HAS_MPMATH}", flush=True)

    h = 0.0625
    Xc, Yc = 0.5, 0.0
    r0, r1 = 0.46875, 0.53125
    p0, p1 = -np.pi/48, np.pi/48
    cell = build_cell(Xc, Yc, h, r0, r1, p0, p1)
    stored_moment = cell["avg"]

    # Moment representation error
    if HAS_MPMATH:
        with mp.workdps(80):
            ref = cylindrical_moment_reference(cell["geom"], 80)
            stored = mp.mpf(float(stored_moment))
            repr_error = float(abs(ref - stored))
        print(f"  Moment representation error (80-digit): {repr_error:.6e}", flush=True)
    else:
        repr_error = None

    # Campaign A: G.39 scalar replay through complete release authority with complete certificate export
    print("\n=== CAMPAIGN A: G.39 Scalar Replay (Complete Authority + Complete Certificate Export) ===", flush=True)
    rng = np.random.default_rng(SEED)
    n_states = 1000
    n_certified = 0
    n_authority_pass = 0
    max_mass_residual = 0.0
    c_B = np.zeros(9); c_B[1] = 0.05 * h
    individual_certificates = []
    for i in range(n_states):
        offset = rng.uniform(-1e4, 1e4)
        analytical = analytical_full_cell_projection_from_params(
            offset, Xc, Yc, h, r0, r1, p0, p1, stored_moment
        )
        if analytical.get("density_certified") and analytical.get("a_rho_final") is not None:
            n_certified += 1
            max_mass_residual = max(max_mass_residual, analytical.get("mass_residual_hp", 0))
            a_final = analytical["a_rho_final"]
            snap_before = FullyImmutableSnapshot(
                rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=offset,
                Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
            )
            snap_after = FullyImmutableSnapshot(
                rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=a_final,
                Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
            )
            gates = independent_certificate_authority(snap_before, snap_after)
            if gates["release_authorized"]:
                n_authority_pass += 1
            # Export complete certificate with full snapshots
            individual_certificates.append({
                "index": i,
                "snapshot_before": snap_before.to_dict(),
                "snapshot_after": snap_after.to_dict(),
                "release_authorized": gates["release_authorized"],
                "rejection_reason": gates.get("rejection_reason"),
                "mass_residual": gates.get("mass_residual"),
                "momentum_residual": gates.get("momentum_residual"),
                "energy_residual": gates.get("energy_residual"),
                "flux_residual": gates.get("flux_residual"),
                "kkt_primal": gates.get("candidate_primal"),
                "kkt_dual": gates.get("candidate_dual"),
                "kkt_stationarity": gates.get("candidate_stationarity"),
                "kkt_comp_abs": gates.get("candidate_comp_abs"),
                "kkt_lam": gates.get("candidate_lam"),
                "bounds_L": gates.get("bounds_L"),
                "bounds_U": gates.get("bounds_U"),
                "eint_min": gates.get("eint_min"),
                "integrity_before": gates.get("integrity_before"),
                "integrity_after": gates.get("integrity_after"),
                "strict_scalar_contract": gates.get("strict_scalar_contract"),
                "basis_matches": gates.get("basis_matches"),
                "moment_valid": gates.get("moment_valid"),
                "coefficient_matches": gates.get("coefficient_matches"),
                "density_certified": gates.get("density_certified"),
                "conservation_hp": gates.get("conservation_hp"),
                "mass_conservation": gates.get("mass_conservation"),
                "momentum_conservation": gates.get("momentum_conservation"),
                "energy_conservation": gates.get("energy_conservation"),
                "flux_conservation": gates.get("flux_conservation"),
                "eint_admissible": gates.get("eint_admissible")
            })
    print(f"  Certified: {n_certified}/{n_states}  Authority: {n_authority_pass}/{n_states}  max_mass_res={max_mass_residual:.2e}", flush=True)
    print(f"  Individual certificates generated: {len(individual_certificates)}", flush=True)
    


    # E01: Actual certificate export to persistent file with checksum
    cert_file = "/tmp/aladin_lim_certificates_g59.jsonl"
    with open(cert_file, "w") as f:
        for cert in individual_certificates:
            f.write(json.dumps(convert_bools(cert), allow_nan=False) + "\n")
    
    # Compute certificate file checksum
    with open(cert_file, "rb") as f:
        cert_sha256 = hashlib.sha256(f.read()).hexdigest()
    print(f"  Certificates exported to: {cert_file}", flush=True)
    print(f"  Certificate file SHA-256: {cert_sha256}", flush=True)
    
    # Verify export completeness
    with open(cert_file, "r") as f:
        exported_count = sum(1 for _ in f)
    print(f"  Exported certificates verified: {exported_count}", flush=True)
    cert_export_pass = (exported_count == 1000)
    
    campaign_a_pass = (n_certified == n_states and n_authority_pass == n_states and max_mass_residual <= CONSERVATION_TOL and cert_export_pass)

    # Campaign B: Final evidence integrity
    print("\n=== CAMPAIGN B: Final Evidence Integrity ===", flush=True)
    certification_results = []

    # Test 1: Positive correction
    print("  Test 1: Positive correction ...", flush=True)
    analytical = analytical_full_cell_projection_from_params(10.0, Xc, Yc, h, r0, r1, p0, p1, stored_moment)
    a_final = analytical.get("a_rho_final")
    if a_final is not None:
        snap_before = FullyImmutableSnapshot(
            rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=10.0,
            Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
        )
        snap_after = FullyImmutableSnapshot(
            rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=a_final,
            Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
        )
        gates = independent_certificate_authority(snap_before, snap_after)
        test1_pass = gates["release_authorized"]
        print(f"    delta={analytical['delta']:.4f} release={test1_pass}", flush=True)
    else:
        test1_pass = False
        print("    Projection failed", flush=True)
    certification_results.append({"test": "positive_correction", "pass": test1_pass})

    # Test 2: Negative correction
    print("  Test 2: Negative correction ...", flush=True)
    analytical = analytical_full_cell_projection_from_params(-10.0, Xc, Yc, h, r0, r1, p0, p1, stored_moment)
    a_final = analytical.get("a_rho_final")
    if a_final is not None:
        snap_before = FullyImmutableSnapshot(
            rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=-10.0,
            Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
        )
        snap_after = FullyImmutableSnapshot(
            rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=a_final,
            Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
        )
        gates = independent_certificate_authority(snap_before, snap_after)
        test2_pass = gates["release_authorized"]
        print(f"    delta={analytical['delta']:.4f} release={test2_pass}", flush=True)
    else:
        test2_pass = False
        print("    Projection failed", flush=True)
    certification_results.append({"test": "negative_correction", "pass": test2_pass})

    # Extended boundary qualification: 12 cases
    print("  Extended boundary qualification (12 cases) ...", flush=True)
    bounds = full_cell_bounds_from_params(Xc, Yc, h, r0, r1, p0, p1, stored_moment, 1.0)
    L, U = bounds["L"], bounds["U"]
    boundary_cases = [
        ("L-1ULP", np.nextafter(L, -np.inf)),
        ("L-exact", L),
        ("L+1ULP", np.nextafter(L, np.inf)),
        ("U-1ULP", np.nextafter(U, -np.inf)),
        ("U-exact", U),
        ("U+1ULP", np.nextafter(U, np.inf)),
    ]
    boundary_pass_count = 0
    for name, a_input in boundary_cases:
        analytical = analytical_full_cell_projection_from_params(a_input, Xc, Yc, h, r0, r1, p0, p1, stored_moment)
        a_final_b = analytical.get("a_rho_final")
        if a_final_b is not None:
            snap_before = FullyImmutableSnapshot(
                rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=a_input,
                Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
            )
            snap_after = FullyImmutableSnapshot(
                rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=a_final_b,
                Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
            )
            gates = independent_certificate_authority(snap_before, snap_after)
            if gates["release_authorized"]:
                boundary_pass_count += 1
            a_incorrect = np.nextafter(a_final_b, np.inf)
            snap_after_bad = FullyImmutableSnapshot(
                rho0=1.0, m0=1e-5, E0=1.0, c_B=c_B, a_rho=a_incorrect,
                Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
            )
            gates_bad = independent_certificate_authority(snap_before, snap_after_bad)
            if not gates_bad["release_authorized"]:
                boundary_pass_count += 1
    boundary_pass = (boundary_pass_count == 12)
    print(f"    boundary: {boundary_pass_count}/12 (must be 12/12) -> {boundary_pass}", flush=True)
    certification_results.append({"test": "extended_boundary_12", "pass": boundary_pass})

    # ADV-23: Extreme finite momentum
    print("  ADV-23: Extreme finite momentum ...", flush=True)
    snap_before = FullyImmutableSnapshot(
        rho0=1.0, m0=1e200, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    snap_after = FullyImmutableSnapshot(
        rho0=1.0, m0=1e200, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    gates = independent_certificate_authority(snap_before, snap_after)
    adv23_pass = not gates["release_authorized"]
    print(f"    release={gates['release_authorized']} reason={gates.get('rejection_reason')} (must be False) -> {adv23_pass}", flush=True)
    certification_results.append({"test": "ADV-23_extreme_momentum", "pass": adv23_pass})

    # Mean-density sweep: 12 states
    print("  Mean-density sweep (12 states) ...", flush=True)
    mean_densities = [1e-6, 0.01, 1.0, 100.0]
    initial_coeffs = [-10.0, 0.0, 10.0]
    sweep_pass_count = 0
    for rho0 in mean_densities:
        for a_init in initial_coeffs:
            analytical = analytical_full_cell_projection_from_params(
                a_init, Xc, Yc, h, r0, r1, p0, p1, stored_moment, rho0
            )
            a_final_sweep = analytical.get("a_rho_final")
            if a_final_sweep is not None:
                snap_before = FullyImmutableSnapshot(
                    rho0=rho0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=a_init,
                    Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
                )
                snap_after = FullyImmutableSnapshot(
                    rho0=rho0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=a_final_sweep,
                    Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
                )
                gates = independent_certificate_authority(snap_before, snap_after)
                if gates["release_authorized"]:
                    sweep_pass_count += 1
    sweep_pass = (sweep_pass_count == 12)
    print(f"    sweep: {sweep_pass_count}/12 (must be 12/12) -> {sweep_pass}", flush=True)
    certification_results.append({"test": "mean_density_sweep_12", "pass": sweep_pass})

    # ADV-01: Mean density corruption
    print("  ADV-01: Mean density corruption ...", flush=True)
    snap_before = FullyImmutableSnapshot(
        rho0=1.0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    snap_after = FullyImmutableSnapshot(
        rho0=2.0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    gates = independent_certificate_authority(snap_before, snap_after)
    adv01_pass = not gates["release_authorized"]
    print(f"    release={gates['release_authorized']} reason={gates.get('rejection_reason')} (must be False) -> {adv01_pass}", flush=True)
    certification_results.append({"test": "ADV-01_mean_density", "pass": adv01_pass})

    # ADV-13: Incorrect reconstruction moment
    print("  ADV-13: Incorrect reconstruction moment ...", flush=True)
    incorrect_moment = stored_moment + 0.1
    snap_before = FullyImmutableSnapshot(
        rho0=1.0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=incorrect_moment
    )
    snap_after = FullyImmutableSnapshot(
        rho0=1.0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=incorrect_moment
    )
    gates = independent_certificate_authority(snap_before, snap_after)
    adv13_pass = not gates["release_authorized"]
    print(f"    release={gates['release_authorized']} reason={gates.get('rejection_reason')} (must be False) -> {adv13_pass}", flush=True)
    certification_results.append({"test": "ADV-13_incorrect_moment", "pass": adv13_pass})

    # ADV-19: Small unauthorized magnetic modification
    print("  ADV-19: Small unauthorized magnetic modification ...", flush=True)
    c_B_small = np.zeros(9); c_B_small[1] = 1e-13
    snap_before = FullyImmutableSnapshot(
        rho0=1.0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    snap_after = FullyImmutableSnapshot(
        rho0=1.0, m0=0.0, E0=1.0, c_B=c_B_small, a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    gates = independent_certificate_authority(snap_before, snap_after)
    adv19_pass = not gates["release_authorized"]
    print(f"    release={gates['release_authorized']} reason={gates.get('rejection_reason')} (must be False) -> {adv19_pass}", flush=True)
    certification_results.append({"test": "ADV-19_small_magnetic", "pass": adv19_pass})

    # ADV-20: Unauthorized momentum and energy modification
    print("  ADV-20: Unauthorized momentum and energy modification ...", flush=True)
    snap_before = FullyImmutableSnapshot(
        rho0=1.0, m0=0.0, E0=1.0, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    snap_after = FullyImmutableSnapshot(
        rho0=1.0, m0=1e-13, E0=1.0 + 1e-13, c_B=np.zeros(9), a_rho=0.0,
        Xc=Xc, Yc=Yc, h=h, r0=r0, r1=r1, p0=p0, p1=p1, stored_moment=stored_moment
    )
    gates = independent_certificate_authority(snap_before, snap_after)
    adv20_pass = not gates["release_authorized"]
    print(f"    release={gates['release_authorized']} reason={gates.get('rejection_reason')} (must be False) -> {adv20_pass}", flush=True)
    certification_results.append({"test": "ADV-20_momentum_energy", "pass": adv20_pass})

    # E02: Actual FullyImmutableSnapshot cross-process verification
    print("  E02: Actual FullyImmutableSnapshot cross-process verification ...", flush=True)
    cross_process_script = f'''
import json, hashlib
class FullyImmutableSnapshot:
    def __init__(self, rho0, m0, E0, c_B, a_rho, Xc, Yc, h, r0, r1, p0, p1, stored_moment):
        object.__setattr__(self, "rho0", float(rho0))
        object.__setattr__(self, "m0", float(m0))
        object.__setattr__(self, "E0", float(E0))
        object.__setattr__(self, "a_rho", float(a_rho))
        c_B_tuple = tuple(float(x) for x in c_B)
        object.__setattr__(self, "c_B_tuple", c_B_tuple)
        object.__setattr__(self, "Xc", float(Xc))
        object.__setattr__(self, "Yc", float(Yc))
        object.__setattr__(self, "h", float(h))
        object.__setattr__(self, "r0", float(r0))
        object.__setattr__(self, "r1", float(r1))
        object.__setattr__(self, "p0", float(p0))
        object.__setattr__(self, "p1", float(p1))
        object.__setattr__(self, "stored_moment", float(stored_moment))
        object.__setattr__(self, "formulation_version", "0.4.176-classical-08v-g59")
        fingerprint = self._compute_sha256()
        object.__setattr__(self, "sha256_fingerprint", fingerprint)
    def __setattr__(self, name, value):
        raise AttributeError("FullyImmutableSnapshot is immutable")
    def _compute_sha256(self):
        data = {{
            "rho0": self.rho0,
            "m0": self.m0,
            "E0": self.E0,
            "a_rho": self.a_rho,
            "c_B": list(self.c_B_tuple),
            "Xc": self.Xc,
            "Yc": self.Yc,
            "h": self.h,
            "r0": self.r0,
            "r1": self.r1,
            "p0": self.p0,
            "p1": self.p1,
            "stored_moment": self.stored_moment,
            "formulation_version": self.formulation_version
        }}
        raw = json.dumps(data, sort_keys=True).encode()
        return hashlib.sha256(raw).hexdigest()
snap = FullyImmutableSnapshot(
    rho0=1.0, m0=1e-5, E0=1.0, c_B=[0.0, 0.003125, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], a_rho=0.0,
    Xc=0.5, Yc=0.0, h=0.0625, r0=0.46875, r1=0.53125, p0={p0}, p1={p1}, stored_moment={stored_moment}
)
print(snap.sha256_fingerprint)
'''
    try:
        result1 = subprocess.run([sys.executable, "-c", cross_process_script], 
                                 capture_output=True, text=True, env={**os.environ, "PYTHONHASHSEED": "0"})
        result2 = subprocess.run([sys.executable, "-c", cross_process_script], 
                                 capture_output=True, text=True, env={**os.environ, "PYTHONHASHSEED": "42"})
        fp1 = result1.stdout.strip()
        fp2 = result2.stdout.strip()
        cross_process_pass = (fp1 == fp2 and len(fp1) == 64)
        print(f"    fingerprints match across processes: {cross_process_pass}", flush=True)
    except Exception as e:
        cross_process_pass = False
        print(f"    cross-process verification failed: {e}", flush=True)
    certification_results.append({"test": "E02_actual_snapshot_cross_process", "pass": cross_process_pass})

    campaign_b_pass = all(r["pass"] for r in certification_results)
    print(f"  CAMPAIGN B VERDICT: {'PASS' if campaign_b_pass else 'FAIL'}", flush=True)

    all_pass = campaign_a_pass and campaign_b_pass

    report = {
        "campaign": "LIM-ZPINCH-CLASSICAL-08V-G59",
        "version": "0.4.176-classical-08v-g59",
        "baseline": "v0.4.175-classical-08v-g58",
        "published_reference": "Volume II — DOI 10.5281/zenodo.24603335",
        "Pi_influence": 0.0,
        "formulation": "publication_release_gate",
        "moment_representation_error": repr_error,
        "campaign_a": {
            "verdict": "PASS" if campaign_a_pass else "FAIL",
            "n_certified": n_certified,
            "n_authority_pass": n_authority_pass,
            "n_states": n_states,
            "max_mass_residual": max_mass_residual,
            "individual_certificates_count": len(individual_certificates),
            "certificates_exported": cert_export_pass,
            "certificate_file": cert_file,
            "certificate_sha256": cert_sha256
        },
        "campaign_b": {
            "verdict": "PASS" if campaign_b_pass else "FAIL",
            "results": certification_results
        },
        "overall_verdict": "PASS" if all_pass else "FAIL",
        "wall_time_s": perf_counter() - t0,
        "note": "Publication release gate. Correct metadata. Complete certificate export with all authority gates. Actual FullyImmutableSnapshot cross-process verification. Certificate file SHA-256 included. Complete evidence bundle for Volume III publication."
    }
    report_clean = convert_bools(report)
    raw = json.dumps(report_clean, sort_keys=True, allow_nan=False).encode()
    report_clean["sha256"] = hashlib.sha256(raw).hexdigest()
    print("\n========== FINAL REPORT ==========", flush=True)
    print(json.dumps(report_clean, indent=2, allow_nan=False))
    return report_clean

if __name__ == "__main__":
    run_publication_release_gate()
