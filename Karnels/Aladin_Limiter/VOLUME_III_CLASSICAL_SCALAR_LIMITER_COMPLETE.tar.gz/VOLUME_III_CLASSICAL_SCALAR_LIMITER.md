# ALADIN-LIM Volume III — Classical Scalar Limiter

**Version:** v0.4.176-classical-08v-g59  
**DOI Reference:** Volume II — 10.5281/zenodo.24603335  
**Publication Date:** November 28, 2026  
**Author:** Mihai Alexandru Bucurenciu (Aladin) — Sibiu, Romania

---

## Scope

This volume publishes a verified specialized scalar limiter for native-cylindrical magnetohydrodynamics. The limiter is designed for density coefficient correction under physical admissibility constraints.

**What this volume establishes:**
- Analytical constrained optimization for scalar density coefficients
- Native cylindrical reconstruction with analytically derived, high-precision geometric moments
- High-precision mass conservation verification
- KKT optimality certification
- Physical admissibility checks (density, internal energy)
- Immutable state snapshots with SHA-256 fingerprints
- Strict modification contracts
- Fail-closed release authority
- Individually traceable certificates
- Byte-for-byte certificate reproducibility across repeated executions of the same version

**What this volume does not establish:**
- Full coupled MHD recovery
- Near-axis and extreme-geometry qualification
- Full ALADIN Driver integration
- Comparative limiter benchmarks
- Experimental plasma stability law limiting

---

## Frozen Formulation

| Component | Status |
|-----------|--------|
| Analytical scalar core | FROZEN |
| Certification architecture | FROZEN |
| Acceptance thresholds | FROZEN |
| Formulation version | 0.4.176-classical-08v-g59 |

---

## Verification Results

### Campaign A — G.39 Scalar Replay
| Metric | Result |
|--------|--------|
| Analytical certification | 1000/1000 |
| Release authority | 1000/1000 |
| Maximum mass residual | 4.1869679 × 10⁻¹⁴ |
| Conservation margin | 23.88× below tolerance |
| Moment representation error | 4.1915 × 10⁻¹⁸ |

### Campaign B — Publication Release Gate
| Test | Result |
|------|--------|
| Positive correction | PASS |
| Negative correction | PASS |
| Extended boundary qualification | 12/12 PASS |
| ADV-23 extreme momentum | Correctly rejected |
| Mean-density sweep | 12/12 PASS |
| ADV-01 mean density corruption | Correctly rejected |
| ADV-13 incorrect moment | Correctly rejected |
| ADV-19 small magnetic modification | Correctly rejected |
| ADV-20 momentum/energy modification | Correctly rejected |
| Cross-process fingerprint verification | PASS |

### Independently Verified Residuals
| Residual | Maximum | Tolerance | Status |
|----------|---------|-----------|--------|
| Mass conservation | 4.187e-14 | 1e-12 | PASS |
| Momentum conservation | 0.0 | 1e-12 | PASS |
| Total energy conservation | 0.0 | 1e-12 | PASS |
| Magnetic flux conservation | 0.0 | 1e-12 | PASS |
| Primal feasibility | 0.0 | 1e-10 | PASS |
| Dual feasibility | 0.0 | 1e-10 | PASS |
| KKT stationarity | 9.095e-13 | 1e-8 | PASS |
| KKT complementarity | 7.582e-12 | 1e-10 | PASS |

### Internal Energy Bound
| Metric | Value |
|--------|-------|
| Minimum certified internal energy | 0.9942045455 |
| Required physical floor | 1e-8 |
| Safety margin | 99.42 million × |

---

## Certificate Artifact

| Property | Value |
|----------|-------|
| Certificate count | 1000 |
| Certificate file | CERTIFICATES_G59.jsonl |
| Certificate file SHA-256 | `95e81223d0968d2c36250f5480a8a4ef84b60b7c2373b8b6ce8e3dacba411aad` |
| Reproducibility | Byte-for-byte across repeated executions of the same version |
| State fingerprints verified | 2000/2000 |

**Note on bitwise reproduction:** The certificate artifact is reproduced byte-for-byte across repeated executions of the same version. Different versions may produce different certificate hashes due to formulation or metadata changes.

---

## Documented Limitations

1. **Specialized scalar scope:** This limiter corrects only the density coefficient. Full coupled MHD limiting remains a separate qualification.

2. **Built-in certificate verification:** The internal verification counts certificate lines. External audit independently parses certificates and recomputes all 2,000 state fingerprints.

3. **Cross-process verification:** The built-in cross-process test duplicates the snapshot class implementation rather than importing the original class directly. External audit independently verified the original class determinism.

4. **Rigorous floating-point enclosures:** The magnetic energy bound uses ordinary floating-point arithmetic followed by `nextafter`. Rigorous accumulated-error enclosures are pending.

5. **Historical ADV regression suite:** The complete ADV-01–23 regression suite is not included in this publication. Individual adversarial tests are included.

6. **Executable Pi isolation:** Classical Pi isolation is not demonstrated in this publication.

7. **Geometric moments:** The reconstruction uses analytically derived geometric moments computed with high-precision arithmetic (mpmath, 70–80 decimal places). These are not closed-form exact moments but high-precision numerical approximations.

---

## Source Fingerprint

| File | SHA-256 |
|------|---------|
| LIM_ZPINCH_CLASSICAL_08V_G59_COLAB.py | `38836eacee682eb4a29fffb316245ec05151142b3a84592d900738ad1ce8b3d3` |

---

## Execution Environment

| Property | Value |
|----------|-------|
| Python | 3.10.21 |
| Platform | Linux-6.12.8+-x86_64-with-glibc2.36 |
| MakeReport | MAKE_REPORT_G59.txt |
| MakeReport SHA-256 | `bcc0766d4b8a9f3c1a7d36f4589c3ab6dd38698c9a6da5f08135aecb058c9169` |

---

## Next Scientific Challenges

1. Coupled MHD recovery
2. Near-axis and extreme-geometry qualification
3. Full ALADIN Driver integration
4. Comparative limiter benchmarks
5. Experimental limiter based on plasma stability law

---

## Open Science Standards

This publication follows the ALADIN Open Science standards:

- **MMS** — Mathematical verification
- **ByteWise** — Frozen criteria, hypotheses and predictions
- **ByByte** — Numerical reproducibility
- **MakeReport** — Predicted versus observed results
- **Bundle** — Preservation of original predictions and evidence
- **REC** — Computational continuity

---

## Citation

Bucurenciu, M. A. (2026). ALADIN-LIM Volume III: Classical Scalar Limiter. Zenodo. [DOI to be assigned]

---

**MMS · ByteWise · ByByte · MakeReport · Bundle · REC**
