# ALADIN-LIM Version Log
Generated: 2026-11-27

Format: Campaign | Version | File | SHA-256

- LIM-BASIS-01 | 01 | LIM_BASIS_01_enlarge.py | db3d2d1d32dc0bbf2e30bbb3ba9824bfd82005edc018a4623abf18dff3674ba1
- LIM-BESSEL-01 | el01 | LIM_BESSEL_01_spectral.py | 625f6c32306f4bee64fb39af1fad2237ecd2b023d4e4f1cd0ec7d27cf2b8d778
- LIM-BESSEL-02 | el02 | LIM_BESSEL_02_higher.py | e860d93e33ff84437b610e11ce431ba91d8016a7d828d5bbcf129881d8eee51c
- LIM-CONV-03 | 0.4.56-conv03 | LIM_CONV_03_basis.py | 731d0918596a6213534e11b6fa0f937b4bab65b88fb2ab4be7513992aa7f233f
- LIM-CONV-04 | 0.4.57-conv04 | LIM_CONV_04_nonadm.py | 676235ca488165c8bbddebeb85565b03b433cf34bfedd283576c91fbc912235b
- LIM-CONV-05 | 0.4.58-conv05 | LIM_CONV_05_normalized.py | 0c55166e4ccd40972fe145af124e342d1a559d16548139b38bc0887c80caa084
- LIM-KKT-02 | 0.4.49-kkt02 | LIM_KKT_02_oracle.py | 2d1dc4da66ef9d1aa11114541cfa50375e6c3b0a2fe685338d1203804159772b
- LIM-MODE-01 | 0.4.50-mode01 | LIM_MODE_01_decomposition.py | c625834bf111c35a45d0d10831d6db9eab06c1b29abcd82818f65ad52cb49c82
- LIM-MODE-02 | 0.4.51-mode02 | LIM_MODE_02_helical.py | cd45b5340e8da57ad92f8fbf818401dba577747546bfe46cd97a91726057b08f
- LIM-NULL-02 | 0.4.49-null02 | LIM_NULL_02_projection.py | 7857c9aae2403186fd46c42cabbd3f3bd33f3cf027b4e5b9f720d372772ebd7b
- LIM-NULL-03 | 0.4.49-null03 | LIM_NULL_03_regularization.py | 3b1ebd0fa9120e3940e59e83b6255883a4b7250a2df86a61c431bc0ad3850f09
- LIM-NULL-04 | 0.4.49-null04 | LIM_NULL_04_lcurve.py | f96b25413dded7d06faba16f64c9c006fadf339eafc0a2713ad4eb9afd4dbd9a
- LIM-NULL-05 | 0.4.49-null05 | LIM_NULL_05_curvature.py | 17aa7fc025bf074423e36587fde4d42e22d4fa9401d4be9a2fca191dfa502c37
- LIM-NULL-06 | 0.4.49-null06 | LIM_NULL_06_selection.py | cb769f8c99334204f47638c9b86636b45ee579e620e599de1533ea9e0a903f68
- LIM-NULL-07 | 0.4.49-null07 | LIM_NULL_07_compare.py | 715cf68c42b790a3812a8932d5083293265e332ff0e7c986a7243c78415da1f8
- LIM-NULL-08 | 0.4.49-null08 | LIM_NULL_08_sensitivity.py | c0febc3960fa8175684926418495a9e005e360d62794cb5d98da42147e4f36e0
- LIM-NULL-09 | 0.4.49-null09 | LIM_NULL_09_variants.py | b000a9ddc85f35df5303bf9e8a4badd69d239837b6f5aae7cba82065ca9a8ad6
- LIM-NULL-10 | 0.4.49-null10 | LIM_NULL_10_higher.py | 68e5ba71400d882aae16275c796a599930a66da599139d55c4ce662424d9a4bd
- LIM-NULL-11 | 0.4.49-null11 | LIM_NULL_11_sglasso.py | 12addc9591fc7102a0c7bb7c13d00e2b6a1d5451ea621bb92e30c6597ae5530c
- LIM-NULL-12 | 0.4.49-null12 | LIM_NULL_12_prox.py | a8b892d1cd814d856fd9dd2da6766108fdcc78f8e0a35d37a79ea35be76ffc31
- LIM-VEC-06-D-complete | el-complete | LIM_VEC_06_D_complete.py | 0e0edde04ecbced567fc52d1fb4afa199eb41b7fec360724a6b4649f5e96c9e9
- LIM-VEC-06-D-face-cache | el-face-cache | LIM_VEC_06_D_face_cache.py | b7bcdb931d85f8fe1cb0ce5232550ef5c9f93b2cdb6b62280bf849c08298592d
- campaign — face cache + atomic checkpoint | el-full-campaign | LIM_VEC_06_D_full_campaign.py | 038b350fc23ba07d28dcc8091182a8f631617235c21275200a7d15890c3dd68f
- LIM-VEC-06-D-optimized | el-optimized | LIM_VEC_06_D_optimized.py | 3efd080ea54525d140d6c7591b1efaead9f06120bcdcbf632eef9c9ce7e10f9e
- LIM-VEC-06 | trained | LIM_VEC_06_hard_constrained.py | e28a859a72c341beb558a0d35c7013c2ddaae288e4683728af1e1596118dd8c8
- LIM-VEC-06 | trained-rank-corrected | LIM_VEC_06_hard_constrained_v044.py | 2a11f07e0d64823e733706fd8c49f9a1b6e5856647b5044d590aeafce56d024c
- LIM-VEC-06 |  | LIM_VEC_06_hard_constrained_v045.py | 602cd81282e2b26a92ef054ddc43bfb237e7dff1a72e659d3296bac83e58c0ea
- LIM-VEC-06 | 0.4.46-target-centered | LIM_VEC_06_hard_constrained_v046.py | b47583c9c575644c1def406331cdbc1e7956d979e578efcb088f1ca4e7b58366
- LIM-VEC-06 | 0.4.48-complete-qualification | LIM_VEC_06_v048_complete_qualification.py | eb1ac3d5bffae22ea3b26a57ad75c8d028d6a356d26e7ed46a9ecdf6613daf21
- LIM-VEC-06 |  | LIM_VEC_06_v049_safety.py | 0523a9d0673e815002723c952e1b93e35dfd4bd89dc77c1e571b0359ab6bc1af
- LIM-ZPINCH-03E | 0.4.70-zpinch03e | LIM_ZPINCH_03E_real.py | a3ac76dffb3a2fdf69bfeff0ae44b72785fe33e16b6d5ffa07031324f3cb79f6
- LIM-ZPINCH-03 | truction) | LIM_ZPINCH_03_nonlinear_limiter.py | cdc1e3deacdec7d81b768a419ff1168bc148f4c78c8db28947ef10ef5d201ea3
- LIM-ZPINCH-04 | 0.4.71-zpinch04 | LIM_ZPINCH_04_cylindrical.py | bf7425ce1a5ee1329a530312491263518cad0d8f296ba9754ba6066f7bd21b2d
- LIM-ZPINCH-WB-01 |  if needed — currently zero intervention) | LIM_ZPINCH_WB_01.py | 0b38381e964aa99e47d45b145bf11cc7849125d8d5b03379b40b7323314cc536
- LIM-ZPINCH-WB-02 | 0.4.73-wb02 | LIM_ZPINCH_WB_02.py | 77eb99d93fc10429aa1e6f207ed01b942d737cb6447b248d031bb0841a88801a
- LIM-ZPINCH-WB-03 | 0.4.74-wb03 | LIM_ZPINCH_WB_03.py | 603d8f454dfe259f7ef0a74aa8b98a9b88508f2efcbb00890fa1651fc6cd6c53
- LIM-ZPINCH-WB-04 | 0.4.75-wb04 | LIM_ZPINCH_WB_04.py | f58ecf5d79e3a5559599100874cbcb98948facc3474960132848eac67bf343b6
- LIM-ZPINCH-WB-05 | 0.4.76-wb05 | LIM_ZPINCH_WB_05.py | 779ef62a6963049f74a8dddafa8f984f89680f8189d5ec22357a3ae295f75a14
- LIM-ZP-01B | 0.4.49-zp01b | LIM_ZP_01B_force_balance.py | ebcd8bc0df876410c5bc6cf1f7fbe3e9bb7eb9cae5e6e4c5431aea6d9383f131
- LIM-ZP-01C | 0.4.49-zp01c | LIM_ZP_01C_limiting.py | 0d0cb8af5dcd5117cc9786d993e10c67c70366d0fb6f5dbb881356c8435a4862
- LIM-ZP-01D | 0.4.49-zp01d | LIM_ZP_01D_separated.py | 90a3d4ccf3dd2a30326cc00edcf50890f67128d054259788586e8def9be5af75
- LIM-ZP-01E | 0.4.49-zp01e | LIM_ZP_01E_detector.py | bdcadb7dadeb440faf66bbc5e908c6dba441400c1b02dc80e386503dcc247ba2
- LIM-ZP-01 | 0.4.49-zp01 | LIM_ZP_01_equilibrium.py | 574dec6b176af8641d3e75508b083a44cbf34f28e58bf979ddb9eaf381e29878
-  |  | operator_v1.py | cdbc9443241457f99b5401e5e221700e27e09444f1752716a8d00cfbd379e6dd
All hashes are SHA-256 of the source files.
