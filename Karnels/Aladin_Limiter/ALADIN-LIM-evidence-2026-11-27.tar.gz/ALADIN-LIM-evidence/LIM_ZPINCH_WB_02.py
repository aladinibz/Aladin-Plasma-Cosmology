#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-WB-02
Perturbed stability limits — small physical perturbation on discrete Z-pinch.
Classical baseline (Π = 0).
Measures residual and perturbation amplitude before/after reconstruction+limiting.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-WB-02 Perturbed stability")

def make_equilibrium(nr=64, R=1.0, p0=1.0):
    r = np.linspace(0, R, nr+1)
    r_c = 0.5 * (r[:-1] + r[1:])
    # Parabolic-like pressure and consistent B_phi (simplified)
    p = p0 * (1.0 - (r_c / R)**2)**2
    p = np.maximum(p, 1e-8)
    # Consistent B_phi from approximate force balance (uniform current style)
    Bphi = 0.5 * r_c * np.sqrt(np.maximum(p0 - p, 0.0)) * 1e-3   # scaled for residual
    return r_c, p, Bphi

def force_balance_residual(r, p, Bphi):
    mu0 = 4e-7 * np.pi
    res = []
    for i in range(1, len(r)-1):
        dpdr = (p[i+1] - p[i-1]) / (r[i+1] - r[i-1])
        rB = r * Bphi
        drBdr = (rB[i+1] - rB[i-1]) / (r[i+1] - r[i-1])
        term = (Bphi[i] / (mu0 * max(r[i], 1e-12))) * drBdr
        res.append(abs(dpdr + term))
    return float(np.max(res)) if res else 0.0, float(np.mean(res)) if res else 0.0

def add_perturbation(p, r, amp=0.02, m=1):
    """Small radial perturbation (sausage-like for m=0, kink-like for m=1)"""
    pert = amp * np.sin(2 * np.pi * m * r / r[-1]) * (r / r[-1])
    return p + pert, pert

def mean_preserving_recon(q, neighbors_proxy=None):
    """Identity mean-preserving (current stand-in)"""
    return q.copy()

def apply_limiter(q, floor=1e-8):
    """Simple positivity floor only (no slope reduction yet)"""
    return np.maximum(q, floor)

def run():
    t0 = perf_counter()
    r, p0, Bphi = make_equilibrium(nr=64)
    p_pert, pert = add_perturbation(p0, r, amp=0.015, m=1)

    # Residuals
    max_eq, mean_eq = force_balance_residual(r, p0, Bphi)
    max_pert, mean_pert = force_balance_residual(r, p_pert, Bphi)

    # Reconstruction (mean-preserving)
    p_recon = mean_preserving_recon(p_pert)
    max_recon, mean_recon = force_balance_residual(r, p_recon, Bphi)

    # Limiting
    p_lim = apply_limiter(p_recon)
    max_lim, mean_lim = force_balance_residual(r, p_lim, Bphi)

    # Perturbation amplitude preservation
    amp_before = float(np.max(np.abs(p_pert - p0)))
    amp_after = float(np.max(np.abs(p_lim - p0)))
    mean_err = float(np.max(np.abs(p_recon - p_pert)))

    report = {
        "campaign": "LIM-ZPINCH-WB-02",
        "version": "0.4.73-wb02",
        "Pi_influence": 0.0,
        "perturbation": {"amp": 0.015, "mode": 1},
        "residuals": {
            "equilibrium_max": max_eq,
            "perturbed_max": max_pert,
            "after_recon_max": max_recon,
            "after_limit_max": max_lim
        },
        "perturbation_amplitude": {
            "before": amp_before,
            "after_limit": amp_after,
            "reduction_factor": amp_before / max(amp_after, 1e-16)
        },
        "mean_preservation_error": mean_err,
        "positivity_min": float(np.min(p_lim)),
        "wall_time_s": perf_counter() - t0,
        "note": "Small m=1 perturbation. Classical mean-preserving + positivity floor. Residual and amplitude tracked."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
