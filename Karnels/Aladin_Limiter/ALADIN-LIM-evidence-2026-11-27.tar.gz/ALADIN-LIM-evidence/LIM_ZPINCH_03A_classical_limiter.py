#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-03A
Classical operational nonlinear limiter (filled placeholders).
Π influence = 0.0 exactly. Independent baseline.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-03A Classical Nonlinear Limiter")

# ---------------------------------------------------------------------------
# Simple but real mean-preserving quadratic reconstruction (scalar demo)
# ---------------------------------------------------------------------------
def reconstruct(q_bar, neighbors):
    """Return limited-ready coefficients. Mean is q_bar."""
    # Placeholder polynomial: constant + small slope estimate
    slope = np.mean(neighbors) - q_bar
    c = np.array([0.0, slope * 0.1, 0.0, 0.0, 0.0])  # mean-free
    return c

def evaluate(c, q_bar, xi):
    """Point evaluation (1D radial demo)."""
    return q_bar + c[1] * xi

# ---------------------------------------------------------------------------
# Actual nonlinear limiter
# ---------------------------------------------------------------------------
def limit(q_bar, neighbors, bounds):
    c = reconstruct(q_bar, neighbors)
    # Evaluation points
    pts = [-0.5, 0.0, 0.5]
    vals = [evaluate(c, q_bar, xi) for xi in pts]

    # Admissibility checks
    min_val = min(vals)
    max_val = max(vals)
    neigh_min = np.min(neighbors)
    neigh_max = np.max(neighbors)

    positivity_ok = min_val >= bounds.get("min", 0.0)
    extremum_ok = (q_bar >= neigh_max - 1e-8) or (q_bar <= neigh_min + 1e-8) or \
                  (min_val >= neigh_min - 1e-8 and max_val <= neigh_max + 1e-8)
    oscillation = (not extremum_ok) and (max(abs(v - q_bar) for v in vals) > 1e-6)

    if positivity_ok and not oscillation:
        return c, "unlimited", vals

    # Minimum correction: scale slope
    alpha = 1.0
    if not positivity_ok:
        # Pull back until positive
        for _ in range(8):
            alpha *= 0.5
            c_try = c * alpha
            vals_try = [evaluate(c_try, q_bar, xi) for xi in pts]
            if min(vals_try) >= bounds.get("min", 0.0):
                c = c_try
                vals = vals_try
                break
    elif oscillation:
        alpha = 0.5
        c = c * alpha
        vals = [evaluate(c, q_bar, xi) for xi in pts]

    return c, "limited", vals

# ---------------------------------------------------------------------------
# Test suite
# ---------------------------------------------------------------------------
def run_tests():
    t0 = perf_counter()
    bounds = {"min": 1e-12}
    results = {}

    # 1. Admissible
    q, neigh = 1.0, np.array([0.95, 1.05, 0.98, 1.02])
    c, flag, vals = limit(q, neigh, bounds)
    results["admissible"] = {"flag": flag, "before_after_vals": vals, "c_norm": float(np.linalg.norm(c))}

    # 2. Negative pressure
    q, neigh = 0.01, np.array([-0.1, 0.05, -0.05, 0.02])
    c, flag, vals = limit(q, neigh, bounds)
    results["negative"] = {"flag": flag, "min_val_after": float(min(vals)), "c_norm": float(np.linalg.norm(c))}

    # 3. Smooth extremum
    q, neigh = 2.0, np.array([1.5, 1.6, 1.4, 1.7])
    c, flag, vals = limit(q, neigh, bounds)
    results["extremum"] = {"flag": flag, "preserved": flag == "unlimited"}

    # 4. Oscillation
    q, neigh = 1.0, np.array([0.5, 1.5, 0.4, 1.6])
    c, flag, vals = limit(q, neigh, bounds)
    results["oscillation"] = {"flag": flag, "c_norm": float(np.linalg.norm(c))}

    report = {
        "campaign": "LIM-ZPINCH-03A",
        "version": "0.4.64-zpinch03a",
        "description": "classical operational limiter — placeholders filled",
        "Pi_influence": 0.0,
        "results": results,
        "wall_time_s": perf_counter() - t0,
        "note": "Classical baseline. Π strictly read-only."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run_tests()
