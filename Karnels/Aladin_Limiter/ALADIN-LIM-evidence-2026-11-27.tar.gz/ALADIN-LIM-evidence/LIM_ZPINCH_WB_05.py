#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-WB-05
Uses cleaned Volume I style operator (operator_v1.py).
Analytical Z-pinch + genuine evaluation + analytical theta.
Classical baseline (Π=0).
"""
import numpy as np
import json, hashlib
from time import perf_counter
from operator_v1 import reconstruct_cell, conservative_theta, basis

print("LIM-ZPINCH-WB-05 Actual-style operator")

def make_analytical(nr=32, R=1.0, p0=0.5):
    r = np.linspace(0, R, nr+1)
    r_c = 0.5 * (r[:-1] + r[1:])
    Bphi = 0.5 * r_c
    p = np.maximum(p0 - 0.25 * r_c**2, 1e-8)
    return r_c, p, Bphi

def residual(r, p, Bphi):
    res = []
    for i in range(1, len(r)-1):
        dpdr = (p[i+1] - p[i-1]) / (r[i+1] - r[i-1])
        res.append(abs(dpdr + Bphi[i]))
    return float(np.max(res)) if res else 0.0

def run():
    t0 = perf_counter()
    r, p, Bphi = make_analytical()
    h = r[1] - r[0]
    res_eq = residual(r, p, Bphi)

    # Reconstruct a few cells with real coefficients
    thetas = []
    mean_errs = []
    active = 0
    for i in range(2, len(p)-2):
        # local neighbors (1D proxy)
        neighbors = [
            (p[i-1], r[i-1], 0.0),
            (p[i+1], r[i+1], 0.0),
            (p[i-2], r[i-2], 0.0),
            (p[i+2], r[i+2], 0.0),
            (p[i], r[i], 0.0),
        ]
        c, eval_poly = reconstruct_cell(p[i], neighbors, r[i], 0.0, h)
        # evaluate at offset point (not center)
        q_face = eval_poly(0.5, 0.0)
        q_min = min(p[i], q_face)
        theta = conservative_theta(p[i], q_min)
        thetas.append(theta)
        if theta < 0.999:
            active += 1
        # independent mean check (center)
        mean_errs.append(abs(eval_poly(0.0, 0.0) - p[i]))

    # Force active case
    p_bad = p.copy()
    p_bad[10] = 0.001
    c2, eval2 = reconstruct_cell(p_bad[10], [(p[9], r[9], 0.0), (p[11], r[11], 0.0)], r[10], 0.0, h)
    q_min2 = min(p_bad[10], eval2(0.5, 0.0))
    theta2 = conservative_theta(p_bad[10], q_min2)

    report = {
        "campaign": "LIM-ZPINCH-WB-05",
        "version": "0.4.76-wb05",
        "Pi_influence": 0.0,
        "equilibrium_residual": res_eq,
        "mean_preservation_max_error": float(np.max(mean_errs)),
        "theta_min_inactive": float(np.min(thetas)),
        "active_count_normal": active,
        "forced_active_theta": float(theta2),
        "wall_time_s": perf_counter() - t0,
        "note": "Cleaned five-coefficient mean-preserving operator. Analytical theta. Face evaluation. Π=0."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
