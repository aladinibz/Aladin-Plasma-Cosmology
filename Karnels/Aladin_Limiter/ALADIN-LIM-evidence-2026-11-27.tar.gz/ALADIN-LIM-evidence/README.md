# ALADIN-LIM Evidence Bundle
Generated: 2026-11-27

## Contents
- VERSION_LOG.md — Campaign | Version | File | SHA-256 of every source file
- All LIM_*.py scripts (70+)
- operator_v1.py — cleaned five-coefficient mean-preserving reconstruction
- Any JSON reports present

## How to verify
sha256sum -c <(awk -F' | ' '{print $NF "  " $3}' VERSION_LOG.md | sed 's/|//g')

## Status
Classical baseline (Π = 0).  
Reconstruction is mean-preserving centered isotropic style.  
All versions preserved for Open Science audit.
