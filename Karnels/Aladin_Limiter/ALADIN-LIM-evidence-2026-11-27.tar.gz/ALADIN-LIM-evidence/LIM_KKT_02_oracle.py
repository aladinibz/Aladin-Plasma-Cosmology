#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-KKT-02
Corrected nontrivial convex QP oracle.
min 0.5 z^T H z
subject to a^T z >= beta > 0
Exact analytical solution + full KKT residuals.
Correct multiplier sign.
Cylindrical Gram matrix.
Hard flux residual reported.
Frozen Volume II core.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.special import jv, jvp

print("LIM-KKT-02 corrected oracle")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf), None
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf), None
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf), None
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat, None
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat, null
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat, null
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf), null
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, float(np.inf), final_res, null
    return c, rank_C, float(np.inf), final_res, null

def bessel_field(m, k, X, Y, mu0=1.0):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        if m == 0:
            return 0.0, 0.0, k**2 * jv(0, 0) / mu0
        elif m == 1:
            return 0.0, -k/2, 0.0
        else:
            return 0.0, 0.0, 0.0
    phi = np.arctan2(Y, X)
    jm = jv(m, k*r)
    jmp = jvp(m, k*r)
    Br = -m * jm * np.sin(m*phi) / r
    Bphi = -k * jmp * np.cos(m*phi)
    Jz = k**2 * jm * np.cos(m*phi) / mu0
    Bx = Br*np.cos(phi) - Bphi*np.sin(phi)
    By = Br*np.sin(phi) + Bphi*np.cos(phi)
    return Bx, By, Jz

def cylindrical_gram(r0, r1, phi0, phi1, Xc, Yc, h, nq=8):
    nodes, w = np.polynomial.legendre.leggauss(nq)
    M = np.zeros((9, 9))
    for ir, wr in enumerate(w):
        r = 0.5*(r1-r0)*nodes[ir] + 0.5*(r0+r1)
        wr *= 0.5*(r1-r0)
        for ip, wp in enumerate(w):
            phi = 0.5*(phi1-phi0)*nodes[ip] + 0.5*(phi0+phi1)
            wp *= 0.5*(phi1-phi0)
            X = r * np.cos(phi)
            Y = r * np.sin(phi)
            xi = (X - Xc) / h
            eta = (Y - Yc) / h
            dBx = np.array([0, 1, 0, xi, 2*eta, 0, xi**2, 2*xi*eta, 3*eta**2]) / h
            dBy = -np.array([1, 0, 2*xi, eta, 0, 3*xi**2, 2*xi*eta, eta**2, 0]) / h
            M += (np.outer(dBx, dBx) + np.outer(dBy, dBy)) * r * wr * wp
    return M

def analytical_z_star(H, a, beta):
    try:
        Ha = np.linalg.solve(H, a)
        denom = float(a @ Ha)
        if abs(denom) < 1e-14:
            return None
        return beta * Ha / denom
    except np.linalg.LinAlgError:
        return None

def full_kkt(z, H, a, beta):
    # Constraint: a^T z >= beta  <=>  -a^T z + beta <= 0
    G = -a.reshape(1, -1)
    b_ineq = np.array([-beta])
    grad = H @ z
    # Correct multiplier: for g = -a·z + beta <= 0, mu >= 0
    # Stationarity: Hz - mu * a = 0  =>  mu = (a @ grad) / (a @ a)
    # residual_grad removed
    mu = np.array([(a @ grad) / (a @ a)])
    stationarity = float(np.linalg.norm(grad + G.T @ mu))
    primal = float((G @ z - b_ineq).item())
    dual = float(mu[0])
    comp = float(np.abs(mu[0] * (G @ z - b_ineq).item()))
    return stationarity, primal, dual, comp

def test_one(nr, nphi, i, j, m, k):
    h = 1.0 / nr
    def Bx_func(X, Y):
        return bessel_field(m, k, X, Y)[0]
    def By_func(X, Y):
        return bessel_field(m, k, X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    A, b, C, d, Xc, Yc = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
    result = constrained_solve(A, b, C, d)
    if result[0] is None:
        return None
    c_H, _, _, _, null = result
    if null is None or null.shape[1] == 0:
        return None
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r0 = i * dr
    r1 = (i + 1) * dr
    phi0 = j * dphi
    phi1 = (j + 1) * dphi
    M_B = cylindrical_gram(r0, r1, phi0, phi1, Xc, Yc, h)
    H = null.T @ M_B @ null
    H = 0.5 * (H + H.T)
    a = np.ones(H.shape[0])
    a /= np.linalg.norm(a)
    beta = 0.04
    z = analytical_z_star(H, a, beta)
    if z is None:
        return None
    stationarity, primal, dual, comp = full_kkt(z, H, a, beta)
    c_LIM = c_H + null @ z
    flux_res = float(np.linalg.norm(C @ c_LIM - d))
    return {
        "z_norm": float(np.linalg.norm(z)),
        "stationarity": stationarity,
        "primal": primal,
        "dual": dual,
        "complementary": comp,
        "flux_residual": flux_res,
        "constraint_value": float(a @ z - beta)
    }

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    results = {"m0": [], "m1": []}
    for m in [0, 1]:
        for i in [2, 6, 10]:
            for j in [0, 8, 16]:
                info = test_one(nr, nphi, i, j, m, 4.0)
                if info is not None:
                    results[f"m{m}"].append(info)
    report = {
        "campaign": "LIM-KKT-02",
        "version": "0.4.49-kkt02",
        "results": results,
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
