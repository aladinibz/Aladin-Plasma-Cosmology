#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-01
Operational Z-pinch admissibility detector.
Uses area-normalized residual D_h against a frozen physical threshold.
Reports acceptance/refusal for representative Z-pinch equilibria and perturbations.
Hard flux constraints retained.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-01 Z-pinch admissibility detector")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
    return np.array(C_rows), np.array(d)

def cell_area(nr, nphi, i, j):
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    r_minus = i * dr
    r_plus = (i + 1) * dr
    return 0.5 * (r_plus**2 - r_minus**2) * dphi

def detector(nr, nphi, Bx_func, By_func, physical_points, D_threshold=1e-8):
    h = 1.0 / nr
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    decisions = []
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    for r_phys, phi_phys in physical_points:
        i_c = min(int(r_phys / dr), nr - 1)
        j_c = int(phi_phys / dphi) % nphi
        C, d = build_system_cached(nr, nphi, i_c, j_c, 3, 3, radial, azi, h)
        if C.shape[0] < 3:
            decisions.append({"r": r_phys, "phi": phi_phys, "status": "degenerate", "D_h": None})
            continue
        try:
            c_part = np.linalg.lstsq(C, d, rcond=1e-12)[0]
            eps = float(np.linalg.norm(C @ c_part - d))
        except np.linalg.LinAlgError:
            decisions.append({"r": r_phys, "phi": phi_phys, "status": "singular", "D_h": None})
            continue
        area = cell_area(nr, nphi, i_c, j_c)
        D_h = 2.0 * eps / area if area > 0 else float('inf')
        status = "admissible" if D_h <= D_threshold else "refused"
        decisions.append({
            "r": r_phys,
            "phi": phi_phys,
            "D_h": D_h,
            "status": status
        })
    return decisions

def equilibrium_field(X, Y):
    # Simple Bennett-like Z-pinch: Bphi ~ r / (1 + r^2)
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return 0.0, 0.0
    phi = np.arctan2(Y, X)
    Bphi = r / (1.0 + r**2)
    return -Bphi * np.sin(phi), Bphi * np.cos(phi)

def perturbed_field(X, Y, amp=0.05, m=1):
    Bx_eq, By_eq = equilibrium_field(X, Y)
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return Bx_eq, By_eq
    phi = np.arctan2(Y, X)
    Bphi_pert = amp * r * np.cos(m * phi)
    return Bx_eq - Bphi_pert * np.sin(phi), By_eq + Bphi_pert * np.cos(phi)

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    physical_points = [(0.3, 0.5), (0.5, 1.5), (0.7, 2.5)]
    D_threshold = 1e-8
    cases = {
        "equilibrium": lambda X, Y: equilibrium_field(X, Y),
        "pert_m1_small": lambda X, Y: perturbed_field(X, Y, 0.01, 1),
        "pert_m1_large": lambda X, Y: perturbed_field(X, Y, 0.2, 1),
        "pert_m2_small": lambda X, Y: perturbed_field(X, Y, 0.01, 2)
    }
    results = {}
    for name, field in cases.items():
        def Bx_func(X, Y):
            return field(X, Y)[0]
        def By_func(X, Y):
            return field(X, Y)[1]
        decisions = detector(nr, nphi, Bx_func, By_func, physical_points, D_threshold)
        results[name] = decisions
    report = {
        "campaign": "LIM-ZPINCH-01",
        "version": "0.4.59-zpinch01",
        "results": {
            "grid": f"{nr}x{nphi}",
            "D_threshold": D_threshold,
            "cases": results
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
