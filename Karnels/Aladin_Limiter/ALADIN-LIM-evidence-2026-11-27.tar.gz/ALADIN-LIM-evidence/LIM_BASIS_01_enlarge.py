#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-BASIS-01
Basis enlargement strategies.
Compares quadratic (degree 2) vs cubic (degree 3) local bases
on pure Bessel m=1 and m=2 profiles.
Records rank, residual, and pointwise error when solvable.
Frozen flux-constraint architecture.
"""
import numpy as np
from scipy.special import jv
import json, hashlib
from time import perf_counter

print("LIM-BASIS-01 basis enlargement")

def basis_quadratic(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def basis_cubic(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3,
                     xi**4, xi**3*eta, xi**2*eta**2, xi*eta**3, eta**4])

def reconstruct_B_quad(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def reconstruct_B_cubic(c, X, Y, Xc, Yc, h):
    # Derivative of cubic terms contribute to B
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    # Simplified: use same reconstruction pattern extended
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2
          + c[10]*xi**3 + 2*c[11]*xi**2*eta + 3*c[12]*xi*eta**2 + 4*c[13]*eta**3) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2
           + 4*c[9]*xi**3 + 3*c[10]*xi**2*eta + 2*c[11]*xi*eta**2 + c[12]*eta**3) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system(nr, nphi, i_c, j_c, ni, nj, radial, azi, h, basis_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((basis_func(X2, Y2, Xc, Yc, h) - basis_func(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((basis_func(X2, Y2, Xc, Yc, h) - basis_func(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((basis_func(X2, Y2, Xc, Yc, h) - basis_func(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((basis_func(X2, Y2, Xc, Yc, h) - basis_func(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, n_coeff, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf)
    if C.shape[0] < 3:
        return None, 0, float(np.inf)
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf)
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, compat
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, compat
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = n_coeff - rank_C
    if rank_red < expected_red:
        return None, rank_C, compat
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf)
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, final_res
    return c, rank_C, final_res

def bessel_field(m, k, X, Y):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return 0.0, 0.0
    phi = np.arctan2(Y, X)
    Jr = jv(m, k * r)
    Bphi = Jr * np.cos(m * phi)
    Bx = -Bphi * np.sin(phi)
    By =  Bphi * np.cos(phi)
    return Bx, By

def probe(nr, nphi, m, k, basis_func, recon_func, n_coeff, n_trials=6):
    h = 1.0 / nr
    def Bx_func(X, Y):
        return bessel_field(m, k, X, Y)[0]
    def By_func(X, Y):
        return bessel_field(m, k, X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    successes = 0
    max_err = 0.0
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    rng = np.random.default_rng(m * 100 + n_coeff)
    for _ in range(n_trials):
        r = rng.uniform(0.2, 0.8)
        phi = rng.uniform(0, 2*np.pi)
        X = r * np.cos(phi)
        Y = r * np.sin(phi)
        i_c = min(int(r / dr), nr - 1)
        j_c = int(phi / dphi) % nphi
        A, b, C, d, Xc, Yc = build_system(nr, nphi, i_c, j_c, 3, 3, radial, azi, h, basis_func)
        res = constrained_solve(A, b, C, d, n_coeff)
        if res[0] is None:
            continue
        successes += 1
        c = res[0]
        Bx_rec, By_rec = recon_func(c, X, Y, Xc, Yc, h)
        Bx_ex, By_ex = bessel_field(m, k, X, Y)
        err = np.hypot(Bx_rec - Bx_ex, By_rec - By_ex)
        if err > max_err:
            max_err = err
    return {
        "success_rate": successes / n_trials,
        "max_err": float(max_err) if successes else None,
        "n_coeff": n_coeff
    }

def run():
    t0 = perf_counter()
    k = 4.0
    nr, nphi = 16, 24
    results = {}
    for m in [1, 2]:
        results[f"m{m}_quad"] = probe(nr, nphi, m, k, basis_quadratic, reconstruct_B_quad, 9)
        results[f"m{m}_cubic"] = probe(nr, nphi, m, k, basis_cubic, reconstruct_B_cubic, 14)
    report = {
        "campaign": "LIM-BASIS-01",
        "version": "0.4.54-basis01",
        "results": {
            "k": k,
            "grid": f"{nr}x{nphi}",
            "comparisons": results
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
