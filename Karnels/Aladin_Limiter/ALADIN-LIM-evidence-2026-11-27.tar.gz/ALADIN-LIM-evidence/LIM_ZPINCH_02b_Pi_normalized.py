#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-02b
Normalized ALADIN-Π diagnostic.
Uses consistent physical scaling so Π_ref and Π_local are comparable.
Also reports Π_B from reconstructed Bphi.
Still read-only.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-02b normalized Π diagnostic")

mu0 = 4 * np.pi * 1e-7
c = 2.99792458e8

def synthetic_physical(nr=32, a_phys=0.01, n0=1e22, I_total=1e6):
    """
    Physical Bennett-like profiles.
    a_phys in meters, n0 in m^-3, I_total in amperes.
    """
    r = (np.arange(nr) + 0.5) * a_phys / nr
    # Bennett density
    rho = 1.67e-27 * n0 / (1.0 + (r/a_phys)**2)**2   # kg/m³
    # Total current distributed as Bennett
    # Jz(r) = (I_total / (π a²)) * a^4 / (r² + a²)²
    Jz = (I_total / (np.pi * a_phys**2)) * (a_phys**4 / (r**2 + a_phys**2)**2)
    # Bphi from Ampere
    # cumulative current
    dr = r[1] - r[0]
    I_enc = np.cumsum(Jz * 2 * np.pi * r * dr)
    Bphi = mu0 * I_enc / (2 * np.pi * np.maximum(r, 1e-12))
    # pressure from rough force balance
    p = np.zeros_like(r)
    for i in range(nr-1, -1, -1):
        if i == nr-1:
            p[i] = 0.0
        else:
            p[i] = p[i+1] + (Bphi[i]**2 / (2*mu0)) * 0.05
    p = np.maximum(p, 1e-6)
    return r, rho, p, Bphi, Jz

def compute_diagnostics(r, rho, Bphi, Jz, a):
    # Reference Π using global J0 = I_total / (π a²)
    I_total = np.trapezoid(Jz * 2 * np.pi * r, r)
    J0 = I_total / (np.pi * a**2)
    Pi_ref = mu0 * J0**2 * a**2 / (rho * c**2)
    # Local Π from local Jz
    Pi_local = mu0 * Jz**2 * a**2 / (rho * c**2)
    # Π_B from local Bphi (the identity form)
    Pi_B = 4 * Bphi**2 / (mu0 * rho * c**2)
    return Pi_ref, Pi_local, Pi_B, J0, I_total

def run():
    t0 = perf_counter()
    a_phys = 0.01          # 1 cm
    n0 = 1e22              # 10^22 m^-3
    I_total = 1e6          # 1 MA
    r, rho, p, Bphi, Jz = synthetic_physical(a_phys=a_phys, n0=n0, I_total=I_total)
    Pi_ref, Pi_local, Pi_B, J0, I_tot = compute_diagnostics(r, rho, Bphi, Jz, a_phys)
    report = {
        "campaign": "LIM-ZPINCH-02b",
        "version": "0.4.61-zpinch02b",
        "description": "normalized read-only Π diagnostic",
        "results": {
            "a_phys_m": a_phys,
            "n0_m3": n0,
            "I_total_A": float(I_tot),
            "J0_A_m2": float(J0),
            "max_Pi_ref": float(np.max(Pi_ref)),
            "max_Pi_local": float(np.max(Pi_local)),
            "max_Pi_B": float(np.max(Pi_B)),
            "Pi_ref_sample": Pi_ref[::4].tolist(),
            "Pi_local_sample": Pi_local[::4].tolist(),
            "Pi_B_sample": Pi_B[::4].tolist(),
            "note": "diagnostic only — no limiting feedback"
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
