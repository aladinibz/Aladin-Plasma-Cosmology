#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-04
Classical cylindrical reconstruction integration.
Uses mean-preserving centered isotropic style (frozen v0.3.x foundation).
Π influence = 0 exactly.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-04 Cylindrical Integration")

# --- Frozen-style reconstruction (mean-preserving, centered) ---
def cylindrical_reconstruct(q_bar, neighbors):
    """Mean-preserving linear stand-in for centered isotropic moment reconstruction.
    Constant term is exactly the cell average. Slope is pure deviation.
    """
    if not np.isfinite(q_bar) or not np.isfinite(neighbors).all():
        return None
    # Volume-weighted style: mean of neighbors is the reference
    slope = np.mean(neighbors) - q_bar
    # Coefficients: [const_dev, slope, ...] — const is zero by construction
    return np.array([0.0, slope, 0.0, 0.0, 0.0])

def evaluate(c, q_bar, xi):
    if c is None:
        return np.nan
    return q_bar + c[1] * xi

def limit(q_bar, neighbors, bounds):
    # Full nonfinite + infeasible refusal
    if not np.isfinite(q_bar) or not np.isfinite(neighbors).all():
        return None, "REFUSED_nonfinite_input", [], 0.0
    if "min" in bounds and not np.isfinite(bounds["min"]):
        return None, "REFUSED_nonfinite_bound", [], 0.0
    if q_bar < bounds.get("min", 0.0):
        return None, "REFUSED_infeasible_average", [], 0.0

    c_H = cylindrical_reconstruct(q_bar, neighbors)
    if c_H is None or not np.isfinite(c_H).all():
        return None, "REFUSED_nonfinite_reconstruction", [], 0.0

    pts = [-0.5, 0.0, 0.5]
    vals_H = [evaluate(c_H, q_bar, xi) for xi in pts]
    if not np.isfinite(vals_H).all():
        return None, "REFUSED_nonfinite_evaluation", [], 0.0

    # Geometry-aware smoothness (curvature proxy)
    if len(neighbors) >= 3:
        second = abs(neighbors[0] - 2*neighbors[1] + neighbors[2])
    else:
        second = 0.0
    local_scale = max(np.std(neighbors), abs(q_bar)*0.015, 1e-8)
    osc_thresh = 0.65 * local_scale + 0.25 * second

    min_H = min(vals_H)
    positivity_ok = min_H >= bounds.get("min", 0.0)
    extremum = (q_bar > np.max(neighbors) + 1e-6) or (q_bar < np.min(neighbors) - 1e-6)
    oscillation = (not extremum) and (max(abs(v - q_bar) for v in vals_H) > osc_thresh)

    if positivity_ok and not oscillation:
        return c_H, "unlimited", vals_H, 0.0

    # Minimum intervention: binary search for largest admissible alpha
    alpha_lo, alpha_hi = 0.0, 1.0
    best_c = np.zeros(5)
    best_vals = [q_bar] * 3
    for _ in range(32):
        alpha = 0.5 * (alpha_lo + alpha_hi)
        c_try = c_H * alpha
        vals_try = [evaluate(c_try, q_bar, xi) for xi in pts]
        min_ok = min(vals_try) >= bounds.get("min", 0.0)
        osc_ok = max(abs(v - q_bar) for v in vals_try) <= osc_thresh
        if min_ok and osc_ok:
            alpha_lo = alpha
            best_c, best_vals = c_try, vals_try
        else:
            alpha_hi = alpha

    if not np.isfinite(best_vals).all() or min(best_vals) < bounds.get("min", 0.0):
        return None, "REFUSED_correction_failed", best_vals, 0.0

    corr = float(np.linalg.norm(best_c - c_H))
    return best_c, "limited", best_vals, corr

def run():
    t0 = perf_counter()
    bounds = {"min": 1e-8}
    cases = {}

    # Admissible (constant-like)
    q, n = 1.0, np.array([0.995, 1.005, 0.99, 1.01])
    c, flag, _, mag = limit(q, n, bounds)
    cases["admissible"] = {"flag": flag, "corr_mag": mag}

    # Positivity
    q, n = 0.08, np.array([-0.7, 0.25, -0.85, 0.15])
    c, flag, vals, mag = limit(q, n, bounds)
    cases["positivity"] = {
        "flag": flag,
        "corr_mag": mag,
        "min_after": float(min(vals)) if vals else None
    }

    # Oscillation
    q, n = 1.0, np.array([0.02, 1.98, 0.01, 1.99])
    c, flag, _, mag = limit(q, n, bounds)
    cases["oscillation"] = {"flag": flag, "corr_mag": mag}

    # Infeasible
    c, flag, _, _ = limit(-0.05, np.array([0.1, 0.2, 0.3]), bounds)
    cases["infeasible"] = {"flag": flag}

    # NaN bound
    c, flag, _, _ = limit(1.0, np.array([1.0, 1.0]), {"min": np.nan})
    cases["nan_bound"] = {"flag": flag}

    report = {
        "campaign": "LIM-ZPINCH-04",
        "version": "0.4.71-zpinch04",
        "Pi_influence": 0.0,
        "reconstruction": "mean-preserving centered (frozen-style)",
        "cases": cases,
        "activation_count": sum(1 for c in cases.values() if c["flag"] == "limited"),
        "refusal_count": sum(1 for c in cases.values() if "REFUSED" in str(c["flag"])),
        "wall_time_s": perf_counter() - t0,
        "note": "Classical cylindrical-style. Mean-preserving. Π=0 exactly."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
