#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-NULL-08
L-curve curvature sensitivity analysis.
Examines how corner location depends on:
1. Number of lambda samples
2. Injected noise level
3. Discrete vs spline curvature estimator
Frozen Volume II reconstruction core.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.interpolate import CubicSpline

print("LIM-NULL-08 L-curve curvature sensitivity")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf), None
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf), None
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf), None
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat, None
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat, null
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat, null
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf), null
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, float(np.inf), final_res, null
    return c, rank_C, float(np.inf), final_res, null

def profile_A(X, Y):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return 0.0, 0.0
    phi = np.arctan2(Y, X)
    Bphi = 0.5 * r
    Bx = -Bphi * np.sin(phi)
    By =  Bphi * np.cos(phi)
    return Bx, By

def l_curve_point(target, N, lam):
    NTN = N.T @ N
    NTt = N.T @ target
    z = np.linalg.solve(NTN + lam * np.eye(NTN.shape[0]), NTt)
    proj = N @ z
    residual = float(np.linalg.norm(target - proj))
    solution = float(np.linalg.norm(proj))
    return residual, solution

def discrete_curvature(log_res, log_sol):
    n = len(log_res)
    kappa = np.zeros(n)
    if n < 3:
        return kappa
    dr = np.diff(log_res)
    ds = np.diff(log_sol)
    d2r = np.diff(log_res, 2)
    d2s = np.diff(log_sol, 2)
    for i in range(1, n-1):
        xr = dr[i-1]
        xs = ds[i-1]
        xrr = d2r[i-1]
        xss = d2s[i-1]
        denom = (xr**2 + xs**2)**1.5
        if denom > 1e-30:
            kappa[i] = abs(xr * xss - xs * xrr) / denom
    return kappa

def spline_corner(log_res, log_sol, n_eval=300):
    t = np.linspace(0, 1, len(log_res))
    cs_r = CubicSpline(t, log_res)
    cs_s = CubicSpline(t, log_sol)
    t_fine = np.linspace(0, 1, n_eval)
    dr = cs_r(t_fine, 1)
    ds = cs_s(t_fine, 1)
    d2r = cs_r(t_fine, 2)
    d2s = cs_s(t_fine, 2)
    denom = (dr**2 + ds**2)**1.5
    kappa = np.where(denom > 1e-30, np.abs(dr * d2s - ds * d2r) / denom, 0.0)
    idx = np.argmax(kappa)
    t_star = t_fine[idx]
    orig_idx = int(np.argmin(np.abs(t - t_star)))
    return orig_idx

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    h = 1.0 / nr
    i, j = 8, 12
    def Bx_func(X, Y):
        return profile_A(X, Y)[0]
    def By_func(X, Y):
        return profile_A(X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    A, b, C, d, Xc, Yc = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
    result = constrained_solve(A, b, C, d)
    if result[0] is None:
        print("rank failure")
        return
    c_H, _, _, flux_res, null = result
    rng = np.random.default_rng(37)
    base_target = rng.standard_normal(9) * 0.05
    # Sensitivity to number of samples
    sample_counts = [15, 31, 61]
    sample_results = []
    for n_samp in sample_counts:
        lambdas = np.logspace(-6, 0, n_samp)
        residuals = []
        solutions = []
        for lam in lambdas:
            res, sol = l_curve_point(base_target, null, lam)
            residuals.append(res)
            solutions.append(sol)
        residuals = np.array(residuals)
        solutions = np.array(solutions)
        log_r = np.log(residuals + 1e-30)
        log_s = np.log(solutions + 1e-30)
        kappa = discrete_curvature(log_r, log_s)
        idx = int(np.argmax(kappa[1:-1])) + 1
        sample_results.append({
            "n_samples": n_samp,
            "lambda": float(lambdas[idx]),
            "residual": float(residuals[idx]),
            "solution": float(solutions[idx])
        })
    # Sensitivity to noise level
    noise_levels = [0.0, 0.002, 0.01, 0.05]
    noise_results = []
    lambdas_ref = np.logspace(-6, 0, 41)
    for noise in noise_levels:
        target = base_target + rng.standard_normal(9) * noise
        residuals = []
        solutions = []
        for lam in lambdas_ref:
            res, sol = l_curve_point(target, null, lam)
            residuals.append(res)
            solutions.append(sol)
        residuals = np.array(residuals)
        solutions = np.array(solutions)
        log_r = np.log(residuals + 1e-30)
        log_s = np.log(solutions + 1e-30)
        kappa = discrete_curvature(log_r, log_s)
        idx = int(np.argmax(kappa[1:-1])) + 1
        noise_results.append({
            "noise": noise,
            "lambda": float(lambdas_ref[idx]),
            "residual": float(residuals[idx]),
            "solution": float(solutions[idx])
        })
    report = {
        "campaign": "LIM-NULL-08",
        "version": "0.4.49-null08",
        "results": {
            "sample_sensitivity": sample_results,
            "noise_sensitivity": noise_results,
            "flux_residual_H": flux_res
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
