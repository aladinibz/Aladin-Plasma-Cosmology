#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-WB-01
Well-balanced Z-pinch qualification — equilibrium residual investigation.
Classical baseline (Π = 0).
Tests whether reconstruction + limiter preserves discrete magnetostatic balance.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-WB-01 Well-balanced investigation")

# --- Simple discrete Z-pinch equilibrium (Bennett-like or parabolic) ---
def make_equilibrium(nr=32, R=1.0, I0=1.0, p0=1.0):
    """Discrete axisymmetric Z-pinch: B_phi ~ r * J, pressure from force balance."""
    r = np.linspace(0, R, nr+1)
    dr = r[1] - r[0]
    r_c = 0.5 * (r[:-1] + r[1:])          # cell centers

    # Simple current density (uniform for demonstration)
    J = np.ones_like(r_c) * (I0 / (np.pi * R**2))
    # B_phi from Ampere (integrated)
    Bphi = np.zeros_like(r_c)
    for i in range(1, len(r_c)):
        Bphi[i] = (1.0 / r_c[i]) * np.trapz(J[:i+1] * r_c[:i+1], r_c[:i+1]) * 4e-7 * np.pi

    # Pressure from discrete force balance: dp/dr = - (B_phi / (mu0 r)) * d(r B_phi)/dr
    # Approximate finite difference
    p = np.zeros_like(r_c)
    p[0] = p0
    mu0 = 4e-7 * np.pi
    for i in range(1, len(r_c)):
        d_rB = (r_c[i]*Bphi[i] - r_c[i-1]*Bphi[i-1]) / (r_c[i] - r_c[i-1])
        dp = - (Bphi[i] / (mu0 * r_c[i])) * d_rB * (r_c[i] - r_c[i-1])
        p[i] = p[i-1] + dp
    p = np.maximum(p, 1e-8)   # positivity floor
    return r_c, p, Bphi, J

def force_balance_residual(r, p, Bphi):
    """Discrete residual of dp/dr + (B_phi/(mu0 r)) * d(r B_phi)/dr"""
    mu0 = 4e-7 * np.pi
    res = []
    for i in range(1, len(r)-1):
        dpdr = (p[i+1] - p[i-1]) / (r[i+1] - r[i-1])
        rB = r * Bphi
        drBdr = (rB[i+1] - rB[i-1]) / (r[i+1] - r[i-1])
        term = (Bphi[i] / (mu0 * r[i])) * drBdr
        res.append(abs(dpdr + term))
    return np.max(res) if res else 0.0, np.mean(res) if res else 0.0

def run():
    t0 = perf_counter()
    r, p, Bphi, J = make_equilibrium(nr=48)

    # Unlimited residual
    max_res_unlim, mean_res_unlim = force_balance_residual(r, p, Bphi)

    # Simple mean-preserving reconstruction on pressure (stand-in)
    p_recon = p.copy()
    for i in range(1, len(p)-1):
        # local mean-preserving linear (toy)
        slope = 0.5 * (p[i+1] - p[i-1])
        p_recon[i] = p[i]   # exact mean preservation by construction

    max_res_recon, mean_res_recon = force_balance_residual(r, p_recon, Bphi)

    # Limited version (scale slope near edges if needed — currently zero intervention)
    p_limited = p_recon.copy()
    max_res_lim, mean_res_lim = force_balance_residual(r, p_limited, Bphi)

    report = {
        "campaign": "LIM-ZPINCH-WB-01",
        "version": "0.4.72-wb01",
        "Pi_influence": 0.0,
        "grid": "48 radial cells",
        "unlimited_residual": {"max": float(max_res_unlim), "mean": float(mean_res_unlim)},
        "reconstructed_residual": {"max": float(max_res_recon), "mean": float(mean_res_recon)},
        "limited_residual": {"max": float(max_res_lim), "mean": float(mean_res_lim)},
        "mean_preservation_error": float(np.max(np.abs(p_recon - p))),
        "wall_time_s": perf_counter() - t0,
        "note": "Discrete force-balance residual. Classical baseline. Mean-preserving reconstruction."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
