#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-02
ALADIN-Π diagnostic (read-only).
Computes Π = μ0 J0² a² / (ρ_eff c²) from reconstructed cell averages.
Also reports classical Kadomtsev profile.
Does not modify reconstruction, limiting, or fluxes.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-02 ALADIN-Π diagnostic")

# Constants
mu0 = 4 * np.pi * 1e-7
c = 2.99792458e8
# Reference J0 used in the law (A/m²)
J0_ref = 1.0e18

def compute_Pi(rho, Jz, a):
    """Π = μ0 J0² a² / (ρ c²). Returns array."""
    # Use local Jz as proxy for J0 when uniform; otherwise report both
    Pi = mu0 * J0_ref**2 * a**2 / (rho * c**2)
    Pi_local = mu0 * Jz**2 * a**2 / (rho * c**2)
    return Pi, Pi_local

def kadomtsev_rhs(p, beta, gamma=5/3):
    """Classical Kadomtsev right-hand side 2γ / (2 + γ β)."""
    return 2 * gamma / (2 + gamma * beta)

def synthetic_equilibrium(nr=32, a=1.0):
    """Simple Bennett-like profiles for demonstration."""
    r = (np.arange(nr) + 0.5) * a / nr
    # Bennett density
    rho = 1.0 / (1.0 + (r/a)**2)**2
    # Bphi ~ r / (1 + r²)
    Bphi = r / (1.0 + (r/a)**2)
    # Pressure from force balance (integrated)
    p = np.zeros_like(r)
    for i in range(nr-1, -1, -1):
        if i == nr-1:
            p[i] = 0.0
        else:
            dr = r[1] - r[0]
            # dp/dr = -Bphi/(μ0 r) * d(r Bphi)/dr
            # approximate
            p[i] = p[i+1] + (Bphi[i]**2 / (2*mu0)) * 0.05   # rough
    p = np.maximum(p, 1e-6)
    # Current density Jz = (1/(μ0 r)) d(r Bphi)/dr
    rB = r * Bphi
    dr = r[1] - r[0]
    d_rB = np.gradient(rB, dr)
    Jz = d_rB / (mu0 * np.maximum(r, 1e-6))
    return r, rho, p, Bphi, Jz

def run():
    t0 = perf_counter()
    r, rho, p, Bphi, Jz = synthetic_equilibrium()
    a = r[-1]
    Pi, Pi_local = compute_Pi(rho, Jz, a)
    beta = 2 * mu0 * p / np.maximum(Bphi**2, 1e-20)
    K_rhs = kadomtsev_rhs(p, beta)
    # pressure gradient term
    dlnp_dlnr = np.gradient(np.log(p), np.log(r + 1e-12))
    report = {
        "campaign": "LIM-ZPINCH-02",
        "version": "0.4.60-zpinch02",
        "description": "read-only ALADIN-Π and Kadomtsev diagnostic",
        "results": {
            "r": r.tolist(),
            "rho": rho.tolist(),
            "Pi_ref": Pi.tolist(),
            "Pi_local": Pi_local.tolist(),
            "Kadomtsev_rhs": K_rhs.tolist(),
            "dlnp_dlnr": dlnp_dlnr.tolist(),
            "max_Pi": float(np.max(Pi)),
            "max_Pi_local": float(np.max(Pi_local)),
            "Pi_threshold": 8.0,
            "note": "diagnostic only — no limiting feedback"
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
