#!/usr/bin/env python3
"""
ALADIN-LIM Volume I style operator (scalar, mean-preserving, five-coefficient).
Centered isotropic basis. Extracted and cleaned from LIM-FACE / WB campaigns.
Classical baseline.
"""
import numpy as np

def basis(xi, eta):
    """Five non-constant centered isotropic basis functions."""
    return np.array([
        xi,
        eta,
        xi**2 + eta**2,
        xi**2 - eta**2,
        2 * xi * eta
    ])

def reconstruct_cell(q_bar, neighbors, r_c, phi_c, h):
    """
    Mean-preserving five-coefficient reconstruction for one cell.
    Returns coefficients c (5,) and a callable that evaluates the polynomial.
    """
    # Build local system from neighbors (simplified for radial 1D proxy)
    A = []
    b = []
    for nq, nr, nphi in neighbors:
        xi = (nr * np.cos(nphi) - r_c * np.cos(phi_c)) / h
        eta = (nr * np.sin(nphi) - r_c * np.sin(phi_c)) / h
        A.append(basis(xi, eta))
        b.append(nq - q_bar)
    if len(A) < 5:
        c = np.zeros(5)
    else:
        A = np.array(A)
        b = np.array(b)
        c = np.linalg.lstsq(A, b, rcond=None)[0]
    def eval_poly(xi, eta):
        return q_bar + np.dot(c, basis(xi, eta))
    return c, eval_poly

def conservative_theta(q_bar, q_min, eps=1e-8):
    """Analytical maximum admissible theta for positivity."""
    if q_min >= eps:
        return 1.0
    if q_bar <= eps:
        return 0.0
    return max(0.0, min(1.0, (q_bar - eps) / (q_bar - q_min)))
