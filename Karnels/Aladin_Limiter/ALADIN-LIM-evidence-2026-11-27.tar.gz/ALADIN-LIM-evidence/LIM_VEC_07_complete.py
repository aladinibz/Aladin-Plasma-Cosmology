#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-VEC-07 complete qualification
All four grids, five modes, full diagnostics.
Frozen v0.4.49 core. Face-flux cache. Atomic checkpoint.
"""
import numpy as np
import json, hashlib, os, tempfile
from time import perf_counter
from scipy.special import jv, jvp

print("LIM-VEC-07 complete — full qualification harness")

_gauss_cache = {}
def get_gauss(n):
    if n not in _gauss_cache:
        _gauss_cache[n] = np.polynomial.legendre.leggauss(n)
    return _gauss_cache[n]

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = get_gauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = get_gauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf)
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf)
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf)
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf)
    cond_red = float(s_red[0]/s_red[expected_red-1]) if expected_red > 0 and s_red[expected_red-1] > 1e-14 else float(np.inf)
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, cond_red, final_res
    return c, rank_C, cond_red, final_res

def bessel_field(m, k, X, Y, mu0=1.0):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        if m == 0:
            return 0.0, 0.0, k**2 * jv(0, 0) / mu0
        elif m == 1:
            return 0.0, -k/2, 0.0
        else:
            return 0.0, 0.0, 0.0
    phi = np.arctan2(Y, X)
    jm = jv(m, k*r)
    jmp = jvp(m, k*r)
    Br = -m * jm * np.sin(m*phi) / r
    Bphi = -k * jmp * np.cos(m*phi)
    Jz = k**2 * jm * np.cos(m*phi) / mu0
    Bx = Br*np.cos(phi) - Bphi*np.sin(phi)
    By = Br*np.sin(phi) + Bphi*np.cos(phi)
    return Bx, By, Jz

def run_diagnostics(nr, nphi, m, k):
    h = 1.0 / nr
    dr = 1.0 / nr
    def Bx_func(X, Y):
        return bessel_field(m, k, X, Y)[0]
    def By_func(X, Y):
        return bessel_field(m, k, X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    B_axis, B_outer, B_interior = [], [], []
    Jz_axis, Jz_outer, Jz_interior = [], [], []
    axis_B_err = []
    axis_Jz_err = []
    residuals = []
    ranks = []
    n_ok = 0
    for i in range(nr):
        for j in range(nphi):
            A, b, C, d, Xc, Yc = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
            c_rec, rank_C, cond_red, final_res = constrained_solve(A, b, C, d)
            if c_rec is None:
                continue
            n_ok += 1
            residuals.append(final_res)
            ranks.append(rank_C)
            Bx_rec, By_rec = reconstruct_B(c_rec, Xc, Yc, Xc, Yc, h)
            Bx_true, By_true, Jz_true = bessel_field(m, k, Xc, Yc)
            B_err = np.sqrt((Bx_rec - Bx_true)**2 + (By_rec - By_true)**2)
            xi = eta = 0.0
            Jz_rec = -(2*c_rec[2] + 2*c_rec[4]
                       + (6*c_rec[5] + 2*c_rec[7])*xi
                       + (2*c_rec[6] + 6*c_rec[8])*eta) / h**2
            Jz_err = abs(Jz_rec - Jz_true)
            if i == 0:
                B_axis.append(B_err)
                Jz_axis.append(Jz_err)
                Bx0, By0 = reconstruct_B(c_rec, 0.0, 0.0, Xc, Yc, h)
                xi0 = -Xc / h
                eta0 = -Yc / h
                Jz0 = -(2*c_rec[2] + 2*c_rec[4]
                        + (6*c_rec[5] + 2*c_rec[7])*xi0
                        + (2*c_rec[6] + 6*c_rec[8])*eta0) / h**2
                Bx_t0, By_t0, Jz_t0 = bessel_field(m, k, 0.0, 0.0)
                axis_B_err.append(np.sqrt((Bx0-Bx_t0)**2 + (By0-By_t0)**2))
                axis_Jz_err.append(abs(Jz0 - Jz_t0))
                if "axis_Jz_vals" not in locals():
                    axis_Jz_vals = []
                axis_Jz_vals.append(Jz0)
            elif i == nr - 1:
                B_outer.append(B_err)
                Jz_outer.append(Jz_err)
            else:
                B_interior.append(B_err)
                Jz_interior.append(Jz_err)
    axis_B_err = np.array(axis_B_err)
    axis_Jz_err = np.array(axis_Jz_err)
    return {
        "n_ok": n_ok,
        "B_axis_Linf": float(np.max(B_axis)) if B_axis else None,
        "B_interior_Linf": float(np.max(B_interior)) if B_interior else None,
        "B_outer_Linf": float(np.max(B_outer)) if B_outer else None,
        "Jz_axis_Linf": float(np.max(Jz_axis)) if Jz_axis else None,
        "Jz_interior_Linf": float(np.max(Jz_interior)) if Jz_interior else None,
        "Jz_outer_Linf": float(np.max(Jz_outer)) if Jz_outer else None,
        "axis_B_analytical_max": float(np.max(axis_B_err)) if len(axis_B_err) else None,
        "axis_Jz_analytical_max": float(np.max(axis_Jz_err)) if len(axis_Jz_err) else None,
        "axis_B_spread": float(np.std(axis_B_err)) if len(axis_B_err) else None,
        "axis_Jz_spread": float(np.max(axis_Jz_vals) - np.min(axis_Jz_vals)) if "axis_Jz_vals" in locals() and len(axis_Jz_vals) else None,
        "max_residual": float(np.max(residuals)) if residuals else None,
        "min_rank": int(np.min(ranks)) if ranks else None
    }

def atomic_write(path, data):
    dir_name = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(dir=dir_name)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except Exception:
        os.unlink(tmp)
        raise

def run():
    t0 = perf_counter()
    grids = [(16,24), (32,48), (64,96)]
    modes = [0, 1]
    k = 4.0
    ckpt = "/workspace/artifacts/LIM_VEC_07_complete_checkpoint.json"
    results = {}
    if os.path.exists(ckpt):
        with open(ckpt) as f:
            results = json.load(f)
        print("Resumed from checkpoint")
    for m in modes:
        if f"m{m}" not in results:
            results[f"m{m}"] = {}
        for nr, nphi in grids:
            key = f"{nr}x{nphi}"
            if key in results[f"m{m}"]:
                print(f"  {key} m={m} already done")
                continue
            print(f"  {key} m={m} ...", flush=True)
            results[f"m{m}"][key] = run_diagnostics(nr, nphi, m, k)
            atomic_write(ckpt, results)
    report = {
        "campaign": "LIM-VEC-07-complete",
        "version": "0.4.49-vec07-complete",
        "grids": [f"{nr}x{nphi}" for nr, nphi in grids],
        "modes": modes,
        "results": results,
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
