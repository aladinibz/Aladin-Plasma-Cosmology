#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-VEC-06-D
Bessel Vector Reconstruction Convergence
Frozen v0.4.49 core. Analytical stream function Az = Jm(kr) cos(mφ).
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.special import jv, jvp

print("LIM-VEC-06-D — Bessel convergence (frozen core)")

# ---------- Frozen core (v0.4.49) ----------
def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([
        xi, eta,
        xi**2, xi*eta, eta**2,
        xi**3, xi**2*eta, xi*eta**2, eta**3
    ])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (
        c[1] + c[3]*xi + 2*c[4]*eta
        + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2
    ) / h
    By = -(
        c[0] + 2*c[2]*xi + c[3]*eta
        + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2
    ) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=16):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=16):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def build_system(nr, nphi, i_c, j_c, ni, nj, Bx_func, By_func, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            r0, r1 = ii*dr, (ii+1)*dr
            p0, p1 = jj*dphi, (jj+1)*dphi
            faces = []
            X1, Y1 = r1*np.cos(p0), r1*np.sin(p0)
            X2, Y2 = r1*np.cos(p1), r1*np.sin(p1)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          numerical_radial_flux(r1, p0, p1, Bx_func, By_func)))
            X1, Y1 = r0*np.cos(p1), r0*np.sin(p1)
            X2, Y2 = r0*np.cos(p0), r0*np.sin(p0)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -numerical_radial_flux(r0, p0, p1, Bx_func, By_func)))
            X1, Y1 = r1*np.cos(p1), r1*np.sin(p1)
            X2, Y2 = r0*np.cos(p1), r0*np.sin(p1)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          numerical_azi_flux(p1, r0, r1, Bx_func, By_func)))
            X1, Y1 = r0*np.cos(p0), r0*np.sin(p0)
            X2, Y2 = r1*np.cos(p0), r1*np.sin(p0)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -numerical_azi_flux(p0, r0, r1, Bx_func, By_func)))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf)
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf)
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf)
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf)
    cond_red = float(s_red[0]/s_red[expected_red-1]) if expected_red > 0 and s_red[expected_red-1] > 1e-14 else float(np.inf)
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, cond_red, final_res
    return c, rank_C, cond_red, final_res

# ---------- Analytical Bessel references ----------
def bessel_field(m, k, X, Y, mu0=1.0):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        if m == 0:
            return 0.0, 0.0, k**2 * jv(0, 0)
        elif m == 1:
            return 0.0, -k/2, 0.0
        else:
            return 0.0, 0.0, 0.0
    phi = np.arctan2(Y, X)
    jm = jv(m, k*r)
    jmp = jvp(m, k*r)
    Br = -m * jm * np.sin(m*phi) / r
    Bphi = -k * jmp * np.cos(m*phi)
    Jz = k**2 * jm * np.cos(m*phi) / mu0
    Bx = Br*np.cos(phi) - Bphi*np.sin(phi)
    By = Br*np.sin(phi) + Bphi*np.cos(phi)
    return Bx, By, Jz

def run_bessel_cell(nr, nphi, m, k, i_c, j_c):
    h = 1.0 / nr
    def Bx_func(X, Y):
        return bessel_field(m, k, X, Y)[0]
    def By_func(X, Y):
        return bessel_field(m, k, X, Y)[1]
    A, b, C, d, Xc, Yc = build_system(nr, nphi, i_c, j_c, 3, 3, Bx_func, By_func, h)
    c_rec, rank_C, cond_red, final_res = constrained_solve(A, b, C, d)
    if c_rec is None:
        return {"status": "refused"}
    # Evaluate at cell center
    Bx_rec, By_rec = reconstruct_B(c_rec, Xc, Yc, Xc, Yc, h)
    Bx_true, By_true, Jz_true = bessel_field(m, k, Xc, Yc)
    B_err = np.sqrt((Bx_rec - Bx_true)**2 + (By_rec - By_true)**2)
    # Jz from reconstructed coefficients (independent of field function)
    xi = eta = 0.0
    Jz_rec = -(
        2*c_rec[2] + 2*c_rec[4]
        + (6*c_rec[5] + 2*c_rec[7])*xi
        + (2*c_rec[6] + 6*c_rec[8])*eta
    ) / h**2
    jz_err = abs(Jz_rec - Jz_true)
    return {
        "B_err": float(B_err),
        "Jz_err": float(jz_err),
        "rank_C": int(rank_C),
        "cond_red": float(cond_red),
        "final_residual": float(final_res)
    }

def campaign_D():
    grids = [(8,12), (16,24), (32,48), (64,96)]
    modes = [0, 1, 2, 3, 4]
    k = 4.0
    results = {}
    for m in modes:
        results[f"m{m}"] = {}
        for nr, nphi in grids:
            key = f"{nr}x{nphi}"
            # Sample interior cell
            res = run_bessel_cell(nr, nphi, m, k, nr//2, 0)
            results[f"m{m}"][key] = res
    return results

def run():
    t0 = perf_counter()
    report = {
        "campaign": "LIM-VEC-06-D",
        "version": "0.4.49-bessel",
        "status": "Bessel vector reconstruction convergence",
        "k": 4.0,
        "results": campaign_D(),
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
