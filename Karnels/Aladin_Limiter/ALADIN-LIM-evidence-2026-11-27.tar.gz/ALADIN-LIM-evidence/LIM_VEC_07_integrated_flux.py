#!/usr/bin/env python3
"""
ALADIN-LIM  Integrated shared-face flux verification
Independent Gaussian quadrature of reconstructed B on both sides of every shared face.
Frozen core. Separates integrated flux from pointwise normal-field jump.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.special import jv, jvp

print("LIM-VEC-07 integrated shared-face flux")

_gauss_cache = {}
def get_gauss(n):
    if n not in _gauss_cache:
        _gauss_cache[n] = np.polynomial.legendre.leggauss(n)
    return _gauss_cache[n]

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = get_gauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = get_gauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf)
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf)
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf)
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf)
    cond_red = float(s_red[0]/s_red[expected_red-1]) if expected_red > 0 and s_red[expected_red-1] > 1e-14 else float(np.inf)
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, cond_red, final_res
    return c, rank_C, cond_red, final_res

def bessel_field(m, k, X, Y, mu0=1.0):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        if m == 0:
            return 0.0, 0.0, k**2 * jv(0, 0) / mu0
        elif m == 1:
            return 0.0, -k/2, 0.0
        else:
            return 0.0, 0.0, 0.0
    phi = np.arctan2(Y, X)
    jm = jv(m, k*r)
    jmp = jvp(m, k*r)
    Br = -m * jm * np.sin(m*phi) / r
    Bphi = -k * jmp * np.cos(m*phi)
    Jz = k**2 * jm * np.cos(m*phi) / mu0
    Bx = Br*np.cos(phi) - Bphi*np.sin(phi)
    By = Br*np.sin(phi) + Bphi*np.cos(phi)
    return Bx, By, Jz

def integrate_radial_face(c, Xc, Yc, h, r, phi0, phi1, n=20):
    nodes, w = get_gauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
        flux += (Bx*nx + By*ny) * r * wp[j]
    return flux

def integrated_check(nr, nphi, m, k):
    h = 1.0 / nr
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    def Bx_func(X, Y):
        return bessel_field(m, k, X, Y)[0]
    def By_func(X, Y):
        return bessel_field(m, k, X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    max_radial_diff = 0.0
    max_azi_diff = 0.0
    n_radial = 0
    n_azi = 0
    # Radial shared faces
    for i in range(nr-1):
        for j in range(nphi):
            A_L, b_L, C_L, d_L, XcL, YcL = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
            c_L, _, _, _ = constrained_solve(A_L, b_L, C_L, d_L)
            A_R, b_R, C_R, d_R, XcR, YcR = build_system_cached(nr, nphi, i+1, j, 3, 3, radial, azi, h)
            c_R, _, _, _ = constrained_solve(A_R, b_R, C_R, d_R)
            if c_L is None or c_R is None:
                continue
            r_face = (i+1) * dr
            phi0 = j * dphi
            phi1 = (j+1) * dphi
            flux_L = integrate_radial_face(c_L, XcL, YcL, h, r_face, phi0, phi1)
            flux_R = integrate_radial_face(c_R, XcR, YcR, h, r_face, phi0, phi1)
            diff = abs(flux_L - flux_R)
            if diff > max_radial_diff:
                max_radial_diff = diff
            n_radial += 1
    # Azimuthal shared faces (simplified sample)
    for j in range(nphi):
        for i in range(1, nr-1):
            A_L, b_L, C_L, d_L, XcL, YcL = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
            c_L, _, _, _ = constrained_solve(A_L, b_L, C_L, d_L)
            A_R, b_R, C_R, d_R, XcR, YcR = build_system_cached(nr, nphi, i, (j+1)%nphi, 3, 3, radial, azi, h)
            c_R, _, _, _ = constrained_solve(A_R, b_R, C_R, d_R)
            if c_L is None or c_R is None:
                continue
            phi = (j+1) * dphi
            r0 = i * dr
            r1 = (i+1) * dr
            # Integrate azimuthal face from both reconstructions
            nodes, w = get_gauss(20)
            rr = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
            wr = 0.5*(r1-r0)*w
            flux_L = 0.0
            flux_R = 0.0
            nx, ny = -np.sin(phi), np.cos(phi)
            for kq in range(20):
                X = rr[kq]*np.cos(phi)
                Y = rr[kq]*np.sin(phi)
                BxL, ByL = reconstruct_B(c_L, X, Y, XcL, YcL, h)
                BxR, ByR = reconstruct_B(c_R, X, Y, XcR, YcR, h)
                flux_L += (BxL*nx + ByL*ny) * wr[kq]
                flux_R += (BxR*nx + ByR*ny) * wr[kq]
            diff = abs(flux_L - flux_R)
            if diff > max_azi_diff:
                max_azi_diff = diff
            n_azi += 1
    return {
        "n_radial": n_radial,
        "max_radial_flux_diff": float(max_radial_diff),
        "n_azi": n_azi,
        "max_azi_flux_diff": float(max_azi_diff)
    }

def run():
    t0 = perf_counter()
    grids = [(16,24)]
    modes = [0, 1]
    k = 4.0
    results = {}
    for m in modes:
        results[f"m{m}"] = {}
        for nr, nphi in grids:
            key = f"{nr}x{nphi}"
            print(f"  {key} m={m} ...", flush=True)
            results[f"m{m}"][key] = integrated_check(nr, nphi, m, k)
    report = {
        "campaign": "LIM-VEC-07-integrated-flux",
        "version": "0.4.49-integrated",
        "results": results,
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
