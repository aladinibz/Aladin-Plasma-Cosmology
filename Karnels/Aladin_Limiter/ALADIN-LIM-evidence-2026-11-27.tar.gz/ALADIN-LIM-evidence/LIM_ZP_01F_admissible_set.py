#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZP-01F
Operational admissible-set check.
Hard constraints: flux, positivity (rho, p).
Numerical indicator separate and non-overriding.
Actual cylindrical control-volume averages.
Frozen thresholds.
Frozen Volume II reconstruction core.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from scipy.special import jv, jvp

print("LIM-ZP-01F admissible-set check")

EPS_RHO = 1e-8
EPS_P   = 1e-8
OSC_THRESHOLD = 0.25   # frozen before campaign

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf), None
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf), None
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf), None
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat, None
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat, null
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat, null
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf), null
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, float(np.inf), final_res, null
    return c, rank_C, float(np.inf), final_res, null

def profile_A(X, Y, p0=1.0):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return 0.0, 0.0, p0, 1.0
    phi = np.arctan2(Y, X)
    Bphi = 0.5 * r
    Bx = -Bphi * np.sin(phi)
    By =  Bphi * np.cos(phi)
    p = p0 - 0.25 * r**2
    return Bx, By, p, 1.0

def cell_average(func, r0, r1, phi0, phi1, n=6):
    nodes, w = np.polynomial.legendre.leggauss(n)
    avg = 0.0
    area = 0.0
    for ir, wr in enumerate(w):
        r = 0.5*(r1-r0)*nodes[ir] + 0.5*(r0+r1)
        wr *= 0.5*(r1-r0)
        for ip, wp in enumerate(w):
            phi = 0.5*(phi1-phi0)*nodes[ip] + 0.5*(phi0+phi1)
            wp *= 0.5*(phi1-phi0)
            X = r * np.cos(phi)
            Y = r * np.sin(phi)
            avg += func(X, Y) * r * wr * wp
            area += r * wr * wp
    return avg / area if area > 0 else 0.0

def hard_admissible(flux_res, p_center, rho_center):
    if not np.isfinite(flux_res) or flux_res > 1e-10:
        return False, "flux"
    if p_center < EPS_P:
        return False, "pressure"
    if rho_center < EPS_RHO:
        return False, "density"
    return True, "ok"

def numerical_indicator(p_center, p_neighbors):
    if len(p_neighbors) == 0:
        return True, "ok"
    rel = np.max(np.abs(np.array(p_neighbors) - p_center)) / max(abs(p_center), 1e-12)
    if rel > OSC_THRESHOLD:
        return False, "oscillation"
    return True, "ok"

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    cells = [(1,0), (8,12), (14,18)]
    results = {}
    # Exact linear equilibrium
    def p_A(X, Y):
        return profile_A(X, Y)[2]
    def rho_A(X, Y):
        return 1.0
    h = 1.0 / nr
    def Bx_func(X, Y):
        return profile_A(X, Y)[0]
    def By_func(X, Y):
        return profile_A(X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    exact = []
    for i, j in cells:
        A, b, C, d, Xc, Yc = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
        result = constrained_solve(A, b, C, d)
        if result[0] is None:
            exact.append({"status": "rank_fail"})
            continue
        _, _, _, flux_res, _ = result
        r0, r1 = i*dr, (i+1)*dr
        phi0, phi1 = j*dphi, (j+1)*dphi
        p_c = cell_average(p_A, r0, r1, phi0, phi1)
        rho_c = cell_average(rho_A, r0, r1, phi0, phi1)
        hard_ok, hard_reason = hard_admissible(flux_res, p_c, rho_c)
        # neighbors
        p_neigh = []
        for di, dj in [(-1,0),(1,0),(0,-1),(0,1)]:
            ii = max(0, min(nr-1, i+di))
            jj = (j+dj) % nphi
            p_neigh.append(cell_average(p_A, ii*dr, (ii+1)*dr, jj*dphi, (jj+1)*dphi))
        num_ok, num_reason = numerical_indicator(p_c, p_neigh)
        exact.append({
            "flux_residual": flux_res,
            "hard_ok": hard_ok,
            "hard_reason": hard_reason,
            "numerical_ok": num_ok,
            "numerical_reason": num_reason,
            "status": "ok"
        })
    results["exact_A"] = exact
    # Negativity control
    def p_neg(X, Y):
        return -0.05
    neg = []
    for i, j in cells:
        r0, r1 = i*dr, (i+1)*dr
        phi0, phi1 = j*dphi, (j+1)*dphi
        p_c = cell_average(p_neg, r0, r1, phi0, phi1)
        hard_ok, hard_reason = hard_admissible(1e-16, p_c, 1.0)
        neg.append({"hard_ok": hard_ok, "hard_reason": hard_reason, "p_center": p_c})
    results["negativity"] = neg
    report = {
        "campaign": "LIM-ZP-01F",
        "version": "0.4.49-zp01f",
        "description": "hard admissible set + separate numerical indicator",
        "thresholds": {"EPS_P": EPS_P, "EPS_RHO": EPS_RHO, "OSC_THRESHOLD": OSC_THRESHOLD},
        "results": results,
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
