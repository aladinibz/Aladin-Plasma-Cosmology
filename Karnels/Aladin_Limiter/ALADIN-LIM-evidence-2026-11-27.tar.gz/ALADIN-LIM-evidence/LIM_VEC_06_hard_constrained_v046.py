#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-VEC-06  v0.4.46
Target-centered dimensionless coordinates for improved conditioning.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from numpy.polynomial.legendre import leggauss

print("LIM-VEC-06 v0.4.46 — target-centered dimensionless basis")

def A_basis(X, Y, Xc, Yc, h):
    """Target-centered dimensionless coordinates."""
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([
        xi, eta,
        xi**2, xi*eta, eta**2,
        xi**3, xi**2*eta, xi*eta**2, eta**3
    ])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (
        c[1] + c[3]*xi + 2*c[4]*eta
        + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2
    ) / h
    By = -(
        c[0] + 2*c[2]*xi + c[3]*eta
        + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2
    ) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=16):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=16):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def build_system(nr, nphi, i_c, j_c, ni, nj, Bx_func, By_func, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    # Target cell center
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            r0, r1 = ii*dr, (ii+1)*dr
            p0, p1 = jj*dphi, (jj+1)*dphi
            faces = []
            X1, Y1 = r1*np.cos(p0), r1*np.sin(p0)
            X2, Y2 = r1*np.cos(p1), r1*np.sin(p1)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          numerical_radial_flux(r1, p0, p1, Bx_func, By_func)))
            X1, Y1 = r0*np.cos(p1), r0*np.sin(p1)
            X2, Y2 = r0*np.cos(p0), r0*np.sin(p0)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -numerical_radial_flux(r0, p0, p1, Bx_func, By_func)))
            X1, Y1 = r1*np.cos(p1), r1*np.sin(p1)
            X2, Y2 = r0*np.cos(p1), r0*np.sin(p1)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          numerical_azi_flux(p1, r0, r1, Bx_func, By_func)))
            X1, Y1 = r0*np.cos(p0), r0*np.sin(p0)
            X2, Y2 = r1*np.cos(p0), r1*np.sin(p0)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -numerical_azi_flux(p0, r0, r1, Bx_func, By_func)))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10):
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf)
    try:
        c_part = np.linalg.lstsq(C, d, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf)
    compat = float(np.linalg.norm(C @ c_part - d))
    if compat > tol:
        return None, 0, float(np.inf), compat
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > 1e-10 * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > 1e-10 * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat
    z = np.linalg.lstsq(A_red, b_red, rcond=None)[0]
    c = c_part + null @ z
    cond_red = float(s_red[0]/s_red[expected_red-1]) if expected_red > 0 and s_red[expected_red-1] > 1e-14 else float(np.inf)
    final_res = float(np.linalg.norm(C @ c - d))
    if final_res > tol:
        return None, rank_C, cond_red, final_res
    return c, rank_C, cond_red, final_res

def poly_field(c_true, X, Y, Xc, Yc, h):
    return reconstruct_B(c_true, X, Y, Xc, Yc, h)

def run_test(nr, nphi, c_true, i_c, j_c):
    h = 1.0 / nr
    def Bx_func(X, Y):
        # Temporary center for field definition (will be overwritten by actual)
        return poly_field(c_true, X, Y, 0.0, 0.0, h)[0]
    def By_func(X, Y):
        return poly_field(c_true, X, Y, 0.0, 0.0, h)[1]
    A, b, C, d, Xc, Yc = build_system(nr, nphi, i_c, j_c, 3, 3, Bx_func, By_func, h)
    # Rebuild with correct centered field functions
    def Bx_func_c(X, Y):
        return poly_field(c_true, X, Y, Xc, Yc, h)[0]
    def By_func_c(X, Y):
        return poly_field(c_true, X, Y, Xc, Yc, h)[1]
    A, b, C, d, Xc, Yc = build_system(nr, nphi, i_c, j_c, 3, 3, Bx_func_c, By_func_c, h)
    c_rec, rank_C, cond_red, final_res = constrained_solve(A, b, C, d)
    if c_rec is None:
        return {"status": "refused", "rank_C": rank_C, "residual": final_res}
    err = float(np.linalg.norm(c_rec - c_true))
    return {
        "coeff_error": err,
        "rank_C": int(rank_C),
        "cond_red": float(cond_red),
        "final_constraint_residual": float(final_res)
    }

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    results = {"interior": {}, "axis": {}, "outer": {}}

    for k in range(9):
        c_true = np.zeros(9)
        c_true[k] = 1.0
        results["interior"][f"basis_{k}"] = run_test(nr, nphi, c_true, nr//2, 0)

    c_true = np.zeros(9)
    c_true[0] = 1.0
    results["axis"]["basis_0"] = run_test(nr, nphi, c_true, 0, 0)
    results["outer"]["basis_0"] = run_test(nr, nphi, c_true, nr-1, 0)

    report = {
        "campaign": "LIM-VEC-06",
        "version": "0.4.46-target-centered",
        "status": "target-centered dimensionless coordinates",
        "grid": f"{nr}x{nphi}",
        "results": results,
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
