#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-NULL-06
Regularization parameter selection methods.
Compares:
1. L-curve (discrete curvature)
2. Generalized cross-validation (GCV)
3. Discrepancy principle
4. Quasi-optimality
Frozen Volume II reconstruction core.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-NULL-06 regularization parameter selection")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf), None
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf), None
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf), None
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat, None
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat, null
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat, null
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf), null
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, float(np.inf), final_res, null
    return c, rank_C, float(np.inf), final_res, null

def profile_A(X, Y):
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return 0.0, 0.0
    phi = np.arctan2(Y, X)
    Bphi = 0.5 * r
    Bx = -Bphi * np.sin(phi)
    By =  Bphi * np.cos(phi)
    return Bx, By

def evaluate_lambda(target, N, lam):
    NTN = N.T @ N
    NTt = N.T @ target
    z = np.linalg.solve(NTN + lam * np.eye(NTN.shape[0]), NTt)
    proj = N @ z
    residual = float(np.linalg.norm(target - proj))
    solution = float(np.linalg.norm(proj))
    # Effective degrees of freedom (trace of influence)
    # For Tikhonov: df = trace(N (NTN+λI)^{-1} NT)
    M = np.linalg.solve(NTN + lam * np.eye(NTN.shape[0]), N.T)
    df = float(np.trace(N @ M))
    return residual, solution, df, proj

def discrete_curvature(log_res, log_sol):
    n = len(log_res)
    kappa = np.zeros(n)
    if n < 3:
        return kappa
    dr = np.diff(log_res)
    ds = np.diff(log_sol)
    d2r = np.diff(log_res, 2)
    d2s = np.diff(log_sol, 2)
    for i in range(1, n-1):
        xr = dr[i-1]
        xs = ds[i-1]
        xrr = d2r[i-1]
        xss = d2s[i-1]
        denom = (xr**2 + xs**2)**1.5
        if denom > 1e-30:
            kappa[i] = abs(xr * xss - xs * xrr) / denom
    return kappa

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    h = 1.0 / nr
    i, j = 8, 12
    def Bx_func(X, Y):
        return profile_A(X, Y)[0]
    def By_func(X, Y):
        return profile_A(X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    A, b, C, d, Xc, Yc = build_system_cached(nr, nphi, i, j, 3, 3, radial, azi, h)
    result = constrained_solve(A, b, C, d)
    if result[0] is None:
        print("rank failure")
        return
    c_H, _, _, flux_res, null = result
    rng = np.random.default_rng(29)
    target = rng.standard_normal(9) * 0.05
    n = len(target)
    lambdas = np.logspace(-6, 0, 41)
    residuals = []
    solutions = []
    dfs = []
    for lam in lambdas:
        res, sol, df, _ = evaluate_lambda(target, null, lam)
        residuals.append(res)
        solutions.append(sol)
        dfs.append(df)
    residuals = np.array(residuals)
    solutions = np.array(solutions)
    dfs = np.array(dfs)
    log_r = np.log(residuals + 1e-30)
    log_s = np.log(solutions + 1e-30)
    # 1. L-curve
    kappa = discrete_curvature(log_r, log_s)
    idx_lcurve = int(np.argmax(kappa[1:-1])) + 1
    # 2. GCV: minimize residual^2 / (n - df)^2
    gcv = residuals**2 / (n - dfs)**2
    idx_gcv = int(np.argmin(gcv))
    # 3. Discrepancy principle: residual ≈ noise level (here synthetic 0.01)
    noise = 0.01
    idx_disc = int(np.argmin(np.abs(residuals - noise)))
    # 4. Quasi-optimality: minimize ||z_λ - z_{2λ}||
    qo = np.zeros(len(lambdas))
    for k in range(len(lambdas)-1):
        _, _, _, p1 = evaluate_lambda(target, null, lambdas[k])
        _, _, _, p2 = evaluate_lambda(target, null, lambdas[k+1])
        qo[k] = np.linalg.norm(p1 - p2)
    idx_qo = int(np.argmin(qo[:-1]))
    report = {
        "campaign": "LIM-NULL-06",
        "version": "0.4.49-null06",
        "results": {
            "n_lambda": len(lambdas),
            "lcurve": {
                "lambda": float(lambdas[idx_lcurve]),
                "residual": float(residuals[idx_lcurve]),
                "solution": float(solutions[idx_lcurve])
            },
            "gcv": {
                "lambda": float(lambdas[idx_gcv]),
                "residual": float(residuals[idx_gcv]),
                "solution": float(solutions[idx_gcv]),
                "gcv_value": float(gcv[idx_gcv])
            },
            "discrepancy": {
                "lambda": float(lambdas[idx_disc]),
                "residual": float(residuals[idx_disc]),
                "solution": float(solutions[idx_disc]),
                "target_noise": noise
            },
            "quasi_optimality": {
                "lambda": float(lambdas[idx_qo]),
                "residual": float(residuals[idx_qo]),
                "solution": float(solutions[idx_qo])
            },
            "flux_residual_H": flux_res
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
