#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-03B
Activation and correction verification (forced activation cases).
Classical baseline — Π influence = 0.0 exactly.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-03B Activation & Correction")

def reconstruct(q_bar, neighbors):
    # Stronger slope so limiting can activate
    slope = np.mean(neighbors) - q_bar
    return np.array([0.0, slope * 2.0, 0.0, 0.0, 0.0])

def evaluate(c, q_bar, xi):
    return q_bar + c[1] * xi

def limit(q_bar, neighbors, bounds):
    c_H = reconstruct(q_bar, neighbors)
    pts = [-0.5, 0.0, 0.5]
    vals_H = [evaluate(c_H, q_bar, xi) for xi in pts]

    min_H = min(vals_H)
    positivity_ok = min_H >= bounds.get("min", 0.0)
    neigh_min, neigh_max = np.min(neighbors), np.max(neighbors)
    extremum = (q_bar >= neigh_max - 1e-8) or (q_bar <= neigh_min + 1e-8)
    oscillation = (not extremum) and (max(abs(v - q_bar) for v in vals_H) > 0.3)

    if positivity_ok and not oscillation:
        return c_H, "unlimited", vals_H, 0.0

    alpha = 1.0
    c = c_H.copy()
    vals = vals_H
    for _ in range(16):
        alpha *= 0.55
        c_try = c_H * alpha
        vals_try = [evaluate(c_try, q_bar, xi) for xi in pts]
        min_ok = min(vals_try) >= bounds.get("min", 0.0)
        osc_ok = max(abs(v - q_bar) for v in vals_try) <= 0.3
        if min_ok and osc_ok:
            c = c_try
            vals = vals_try
            break
    corr_mag = float(np.linalg.norm(c - c_H))
    return c, "limited", vals, corr_mag

def run():
    t0 = perf_counter()
    bounds = {"min": 1e-8}
    cases = {}

    # Admissible
    q, n = 1.0, np.array([0.99, 1.01, 0.98, 1.02])
    c, flag, vals, mag = limit(q, n, bounds)
    cases["admissible"] = {"flag": flag, "corr_mag": mag}

    # Positivity violation (force negative)
    q, n = 0.1, np.array([-0.8, 0.3, -0.9, 0.2])
    c, flag, vals, mag = limit(q, n, bounds)
    cases["positivity"] = {
        "flag": flag,
        "corr_mag": mag,
        "min_before": float(min([evaluate(reconstruct(q,n), q, xi) for xi in [-0.5,0,0.5]])),
        "min_after": float(min(vals))
    }

    # Strong oscillation
    q, n = 1.0, np.array([0.05, 1.95, 0.02, 1.98])
    c, flag, vals, mag = limit(q, n, bounds)
    cases["oscillation"] = {"flag": flag, "corr_mag": mag}

    # Smooth extremum
    q, n = 4.0, np.array([2.5, 2.6, 2.4, 2.7])
    c, flag, vals, mag = limit(q, n, bounds)
    cases["extremum"] = {"flag": flag, "corr_mag": mag, "preserved": flag == "unlimited"}

    report = {
        "campaign": "LIM-ZPINCH-03B",
        "version": "0.4.66-zpinch03b",
        "Pi_influence": 0.0,
        "cases": cases,
        "activation_count": sum(1 for c in cases.values() if c["flag"] == "limited"),
        "wall_time_s": perf_counter() - t0,
        "note": "Classical baseline. Π = 0 exactly."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
