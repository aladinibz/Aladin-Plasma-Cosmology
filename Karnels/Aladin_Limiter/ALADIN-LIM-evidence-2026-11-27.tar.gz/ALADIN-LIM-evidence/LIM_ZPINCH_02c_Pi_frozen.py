#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-02c
Frozen normalized ALADIN-Π diagnostic.
Exact Bennett enclosed-current oracle.
Still completely read-only.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-02c frozen Π diagnostic")

mu0 = 4 * np.pi * 1e-7
c = 2.99792458e8

def bennett_exact(nr=32, a=0.01, n0=1e22, I0=1e6):
    """Exact Bennett profiles (analytic enclosed current)."""
    r = (np.arange(nr) + 0.5) * a / nr
    rho = 1.67e-27 * n0 / (1.0 + (r/a)**2)**2
    # exact enclosed current
    I_enc = I0 * r**2 / (a**2 + r**2)
    Bphi = mu0 * I_enc / (2 * np.pi * np.maximum(r, 1e-12))
    # exact pressure from radial force balance (integrated)
    # dp/dr = -Bphi * d(r Bphi)/dr / (mu0 r)
    # for this profile the result is known analytically
    p = (mu0 * I0**2 / (8 * np.pi**2 * a**2)) / (1.0 + (r/a)**2)**2
    p = np.maximum(p, 0.0)
    return r, rho, p, Bphi, I_enc

def compute_Pi(r, rho, Bphi, a, I0):
    J0 = I0 / (np.pi * a**2)
    Pi_ref = mu0 * J0**2 * a**2 / (rho * c**2)
    # local Jz from derivative of I_enc
    # Jz = (1/(2πr)) dI/dr
    dI_dr = np.gradient(I0 * r**2 / (a**2 + r**2), r)
    Jz = dI_dr / (2 * np.pi * np.maximum(r, 1e-12))
    Pi_local = mu0 * Jz**2 * a**2 / (rho * c**2)
    Pi_B = 4 * Bphi**2 / (mu0 * rho * c**2)
    return Pi_ref, Pi_local, Pi_B

def run():
    t0 = perf_counter()
    a, n0, I0 = 0.01, 1e22, 1e6
    r, rho, p, Bphi, I_enc = bennett_exact(a=a, n0=n0, I0=I0)
    Pi_ref, Pi_local, Pi_B = compute_Pi(r, rho, Bphi, a, I0)
    report = {
        "campaign": "LIM-ZPINCH-02c",
        "version": "0.4.62-zpinch02c",
        "description": "frozen exact-Bennett normalized Π diagnostic",
        "results": {
            "a_m": a,
            "I0_A": I0,
            "max_I_enc": float(I_enc[-1]),
            "max_Pi_ref": float(np.max(Pi_ref)),
            "max_Pi_local": float(np.max(Pi_local)),
            "max_Pi_B": float(np.max(Pi_B)),
            "note": "read-only diagnostic, exact analytic oracle, frozen"
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
