#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-VEC-06  v0.4.44
Hard-constrained qualification — corrected rank logic.
Interior constraint rank expected = 3 (not 4).
Compatibility, reduced-system rank, final residual checked.
"""
import numpy as np
import json, hashlib
from time import perf_counter
from numpy.polynomial.legendre import leggauss

print("LIM-VEC-06 v0.4.44 — corrected constraint rank")

def A_basis(X, Y):
    return np.array([
        X, Y,
        X**2, X*Y, Y**2,
        X**3, X**2*Y, X*Y**2, Y**3
    ])

def reconstruct_B(c, X, Y):
    Bx = (
        c[1] + c[3]*X + 2*c[4]*Y
        + c[6]*X**2 + 2*c[7]*X*Y + 3*c[8]*Y**2
    )
    By = -(
        c[0] + 2*c[2]*X + c[3]*Y
        + 3*c[5]*X**2 + 2*c[6]*X*Y + c[7]*Y**2
    )
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=16):
    nodes, w = leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=16):
    nodes, w = leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def build_system(nr, nphi, i_c, j_c, ni, nj, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    C_rows, d = [], []
    A_rows, b = [], []
    j0 = j_c - nj//2
    i0 = i_c - ni//2
    for ii in range(i0, i0 + ni):
        if not (0 <= ii < nr):
            continue
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            r0, r1 = ii*dr, (ii+1)*dr
            p0, p1 = jj*dphi, (jj+1)*dphi
            faces = []
            X1, Y1 = r1*np.cos(p0), r1*np.sin(p0)
            X2, Y2 = r1*np.cos(p1), r1*np.sin(p1)
            faces.append((A_basis(X2, Y2) - A_basis(X1, Y1),
                          numerical_radial_flux(r1, p0, p1, Bx_func, By_func)))
            X1, Y1 = r0*np.cos(p1), r0*np.sin(p1)
            X2, Y2 = r0*np.cos(p0), r0*np.sin(p0)
            faces.append((A_basis(X2, Y2) - A_basis(X1, Y1),
                          -numerical_radial_flux(r0, p0, p1, Bx_func, By_func)))
            X1, Y1 = r1*np.cos(p1), r1*np.sin(p1)
            X2, Y2 = r0*np.cos(p1), r0*np.sin(p1)
            faces.append((A_basis(X2, Y2) - A_basis(X1, Y1),
                          numerical_azi_flux(p1, r0, r1, Bx_func, By_func)))
            X1, Y1 = r0*np.cos(p0), r0*np.sin(p0)
            X2, Y2 = r1*np.cos(p0), r1*np.sin(p0)
            faces.append((A_basis(X2, Y2) - A_basis(X1, Y1),
                          -numerical_azi_flux(p0, r0, r1, Bx_func, By_func)))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d)

def constrained_solve(A, b, C, d):
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf)
    try:
        c_part = np.linalg.lstsq(C, d, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf)
    compat = float(np.linalg.norm(C @ c_part - d))
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > 1e-10 * s[0]))
    # Expected rank_C == 3 for interior closed cell
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat
    A_red = A @ null
    b_red = b - A @ c_part
    # Reduced system rank
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > 1e-10 * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat
    z = np.linalg.lstsq(A_red, b_red, rcond=None)[0]
    c = c_part + null @ z
    cond_red = float(s_red[0]/s_red[expected_red-1]) if expected_red > 0 and s_red[expected_red-1] > 1e-14 else float(np.inf)
    final_res = float(np.linalg.norm(C @ c - d))
    return c, rank_C, cond_red, final_res

def poly_field(c_true, X, Y):
    return reconstruct_B(c_true, X, Y)

def run_poly_test(nr, nphi, c_true):
    def Bx_func(X, Y):
        return poly_field(c_true, X, Y)[0]
    def By_func(X, Y):
        return poly_field(c_true, X, Y)[1]
    i_c = nr // 2
    j_c = 0
    A, b, C, d = build_system(nr, nphi, i_c, j_c, 3, 3, Bx_func, By_func)
    c_rec, rank_C, cond_red, final_res = constrained_solve(A, b, C, d)
    if c_rec is None:
        return {"status": "refused", "rank_C": rank_C}
    err = float(np.linalg.norm(c_rec - c_true))
    return {
        "coeff_error": err,
        "rank_C": int(rank_C),
        "cond_red": float(cond_red),
        "final_constraint_residual": float(final_res)
    }

def run():
    t0 = perf_counter()
    results = {"polynomial": {}, "mixed": {}}
    nr, nphi = 16, 24

    for k in range(9):
        c_true = np.zeros(9)
        c_true[k] = 1.0
        results["polynomial"][f"basis_{k}"] = run_poly_test(nr, nphi, c_true)

    c_mixed = np.array([0.0, 0.0, 0.3, 0.5, -0.2, 0.1, 0.0, 0.0, 0.0])
    results["mixed"]["corrected"] = run_poly_test(nr, nphi, c_mixed)

    report = {
        "campaign": "LIM-VEC-06",
        "version": "0.4.44-hard-constrained-rank-corrected",
        "status": "constraint rank 3 expected — reduced system checked",
        "grid": f"{nr}x{nphi}",
        "results": results,
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
