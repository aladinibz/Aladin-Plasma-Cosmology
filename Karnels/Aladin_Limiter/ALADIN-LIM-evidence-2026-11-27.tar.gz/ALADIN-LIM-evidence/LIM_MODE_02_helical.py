#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-MODE-02
Corrected cylindrical mode decomposition.
- Helical vector regularity (B+, B-)
- Independent cell reconstruction, ring-by-ring assembly
- Manufactured modes m = 0..4
- Complex Fourier coefficients
- Mode leakage and radial scaling
Frozen Volume II reconstruction core.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-MODE-02 helical mode decomposition")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def reconstruct_B(c, X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    Bx = (c[1] + c[3]*xi + 2*c[4]*eta
          + c[6]*xi**2 + 2*c[7]*xi*eta + 3*c[8]*eta**2) / h
    By = -(c[0] + 2*c[2]*xi + c[3]*eta
           + 3*c[5]*xi**2 + 2*c[6]*xi*eta + c[7]*eta**2) / h
    return Bx, By

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    A_rows, b = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
                else:
                    A_rows.append(row)
                    b.append(flux)
    return np.array(A_rows), np.array(b), np.array(C_rows), np.array(d), Xc, Yc

def constrained_solve(A, b, C, d, tol=1e-10, rcond=1e-12):
    for arr in (A, b, C, d):
        if not np.isfinite(arr).all():
            return None, 0, float(np.inf), float(np.inf), None
    if C.shape[0] < 3:
        return None, 0, float(np.inf), float(np.inf), None
    try:
        c_part = np.linalg.lstsq(C, d, rcond=rcond)[0]
    except np.linalg.LinAlgError:
        return None, 0, float(np.inf), float(np.inf), None
    compat = float(np.linalg.norm(C @ c_part - d))
    if not np.isfinite(compat) or compat > tol:
        return None, 0, float(np.inf), compat, None
    _, s, Vt = np.linalg.svd(C, full_matrices=True)
    rank_C = int(np.sum(s > rcond * s[0]))
    null = Vt[rank_C:].T
    if null.shape[1] == 0:
        return c_part, rank_C, float(np.inf), compat, null
    A_red = A @ null
    b_red = b - A @ c_part
    s_red = np.linalg.svd(A_red, compute_uv=False)
    rank_red = int(np.sum(s_red > rcond * s_red[0])) if len(s_red) else 0
    expected_red = 9 - rank_C
    if rank_red < expected_red:
        return None, rank_C, float(np.inf), compat, null
    z = np.linalg.lstsq(A_red, b_red, rcond=rcond)[0]
    c = c_part + null @ z
    if not np.isfinite(c).all():
        return None, rank_C, float(np.inf), float(np.inf), null
    final_res = float(np.linalg.norm(C @ c - d))
    if not np.isfinite(final_res) or final_res > tol:
        return None, rank_C, float(np.inf), final_res, null
    return c, rank_C, float(np.inf), final_res, null

def manufactured_field(m_target, X, Y):
    """Simple manufactured helical mode with correct radial regularity."""
    r = np.sqrt(X**2 + Y**2)
    if r < 1e-14:
        return 0.0, 0.0
    phi = np.arctan2(Y, X)
    # B+ ~ r^{|m+1|} e^{im phi}, B- ~ r^{|m-1|} e^{im phi}
    amp_plus = r ** abs(m_target + 1)
    amp_minus = r ** abs(m_target - 1)
    phase = np.exp(1j * m_target * phi)
    B_plus = amp_plus * phase
    B_minus = amp_minus * phase
    Br = 0.5 * (B_plus + B_minus).real
    Bphi = 0.5 * (B_plus - B_minus).imag
    Bx = Br * np.cos(phi) - Bphi * np.sin(phi)
    By = Br * np.sin(phi) + Bphi * np.cos(phi)
    return Bx, By

def assemble_ring_spectrum(nr, nphi, m_target, r_query):
    """Reconstruct every cell independently and extract spectrum at r_query."""
    h = 1.0 / nr
    def Bx_func(X, Y):
        return manufactured_field(m_target, X, Y)[0]
    def By_func(X, Y):
        return manufactured_field(m_target, X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    # Sample points on the query ring
    n_sample = 64
    phi_s = np.linspace(0, 2*np.pi, n_sample, endpoint=False)
    Br_s = np.zeros(n_sample, dtype=complex)
    Bphi_s = np.zeros(n_sample, dtype=complex)
    # For each sample point, find the cell that contains it and reconstruct there
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    for k, phi in enumerate(phi_s):
        X = r_query * np.cos(phi)
        Y = r_query * np.sin(phi)
        i_c = min(int(r_query / dr), nr - 1)
        j_c = int(phi / dphi) % nphi
        A, b, C, d, Xc, Yc = build_system_cached(nr, nphi, i_c, j_c, 3, 3, radial, azi, h)
        res = constrained_solve(A, b, C, d)
        if res[0] is None:
            continue
        c = res[0]
        Bx, By = reconstruct_B(c, X, Y, Xc, Yc, h)
        Br_s[k] = Bx * np.cos(phi) + By * np.sin(phi)
        Bphi_s[k] = -Bx * np.sin(phi) + By * np.cos(phi)
    # Helical combinations
    B_plus = Br_s + 1j * Bphi_s
    B_minus = Br_s - 1j * Bphi_s
    coeff_plus = np.fft.fft(B_plus) / n_sample
    coeff_minus = np.fft.fft(B_minus) / n_sample
    return {
        "target_m": m_target,
        "amp_plus_target": float(np.abs(coeff_plus[m_target % n_sample])),
        "amp_minus_target": float(np.abs(coeff_minus[m_target % n_sample])),
        "leakage_plus": float(np.sum(np.abs(coeff_plus)) - np.abs(coeff_plus[m_target % n_sample])),
        "leakage_minus": float(np.sum(np.abs(coeff_minus)) - np.abs(coeff_minus[m_target % n_sample]))
    }

def run():
    t0 = perf_counter()
    nr, nphi = 16, 24
    results = []
    for m in range(0, 5):
        r_query = 0.5
        spec = assemble_ring_spectrum(nr, nphi, m, r_query)
        results.append(spec)
    report = {
        "campaign": "LIM-MODE-02",
        "version": "0.4.51-mode02",
        "results": {
            "grid": f"{nr}x{nphi}",
            "r_query": 0.5,
            "mode_sweep": results
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
