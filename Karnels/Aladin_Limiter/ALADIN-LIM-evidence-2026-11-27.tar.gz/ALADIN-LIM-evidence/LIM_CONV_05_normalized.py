#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-CONV-05
Area-normalized incompatibility diagnostic.
Matched physical sampling. Absolute residual, area-normalized residual,
analytical cell-averaged divergence, rank, and explicit refusal.
Hard flux constraints retained.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-CONV-05 area-normalized diagnostic")

def A_basis(X, Y, Xc, Yc, h):
    xi = (X - Xc) / h
    eta = (Y - Yc) / h
    return np.array([xi, eta, xi**2, xi*eta, eta**2,
                     xi**3, xi**2*eta, xi*eta**2, eta**3])

def numerical_radial_flux(r, phi0, phi1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    p = 0.5*(phi1-phi0)*nodes + 0.5*(phi0+phi1)
    wp = 0.5*(phi1-phi0)*w
    flux = 0.0
    for j in range(n):
        X = r*np.cos(p[j])
        Y = r*np.sin(p[j])
        nx, ny = np.cos(p[j]), np.sin(p[j])
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * r * wp[j]
    return flux

def numerical_azi_flux(phi, r0, r1, Bx_func, By_func, n=12):
    nodes, w = np.polynomial.legendre.leggauss(n)
    r = 0.5*(r1-r0)*nodes + 0.5*(r0+r1)
    wr = 0.5*(r1-r0)*w
    flux = 0.0
    nx, ny = -np.sin(phi), np.cos(phi)
    for i in range(n):
        X = r[i]*np.cos(phi)
        Y = r[i]*np.sin(phi)
        flux += (Bx_func(X, Y)*nx + By_func(X, Y)*ny) * wr[i]
    return flux

def precompute_face_fluxes(nr, nphi, Bx_func, By_func):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    radial = {}
    azi = {}
    for i in range(nr + 1):
        r = i * dr
        for j in range(nphi):
            p0 = j * dphi
            p1 = (j + 1) * dphi
            radial[(i, j)] = numerical_radial_flux(r, p0, p1, Bx_func, By_func)
    for j in range(nphi):
        phi = j * dphi
        for i in range(nr):
            r0 = i * dr
            r1 = (i + 1) * dr
            azi[(i, j)] = numerical_azi_flux(phi, r0, r1, Bx_func, By_func)
    return radial, azi

def build_system_cached(nr, nphi, i_c, j_c, ni, nj, radial, azi, h):
    R = 1.0
    dr = R / nr
    dphi = 2 * np.pi / nphi
    r_c = (i_c + 0.5) * dr
    phi_c = (j_c + 0.5) * dphi
    Xc, Yc = r_c * np.cos(phi_c), r_c * np.sin(phi_c)
    C_rows, d = [], []
    i0 = max(0, min(i_c - ni//2, nr - ni))
    j0 = j_c - nj//2
    for ii in range(i0, i0 + ni):
        for jj_off in range(nj):
            jj = (j0 + jj_off) % nphi
            faces = []
            X1 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y1 = ((ii+1)*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y2 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          radial[(ii+1, jj)]))
            X1 = (ii*dr) * np.cos((jj+1)*dphi)
            Y1 = (ii*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos(jj*dphi)
            Y2 = (ii*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -radial[(ii, jj)]))
            X1 = ((ii+1)*dr) * np.cos((jj+1)*dphi)
            Y1 = ((ii+1)*dr) * np.sin((jj+1)*dphi)
            X2 = (ii*dr) * np.cos((jj+1)*dphi)
            Y2 = (ii*dr) * np.sin((jj+1)*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          azi[(ii, (jj+1) % nphi)]))
            X1 = (ii*dr) * np.cos(jj*dphi)
            Y1 = (ii*dr) * np.sin(jj*dphi)
            X2 = ((ii+1)*dr) * np.cos(jj*dphi)
            Y2 = ((ii+1)*dr) * np.sin(jj*dphi)
            faces.append((A_basis(X2, Y2, Xc, Yc, h) - A_basis(X1, Y1, Xc, Yc, h),
                          -azi[(ii, jj)]))
            for row, flux in faces:
                if ii == i_c and jj == j_c:
                    C_rows.append(row)
                    d.append(flux)
    return np.array(C_rows), np.array(d), Xc, Yc

def cell_area(nr, nphi, i, j):
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    r_minus = i * dr
    r_plus = (i + 1) * dr
    return 0.5 * (r_plus**2 - r_minus**2) * dphi

def analytical_div_avg(m, nr, nphi, i, j):
    # ∇·B = -m sin(m φ), cell average
    dphi = 2 * np.pi / nphi
    phi0 = j * dphi
    phi1 = (j + 1) * dphi
    # average of sin(m φ) over [phi0, phi1]
    if m == 0:
        return 0.0
    avg_sin = (np.cos(m * phi0) - np.cos(m * phi1)) / (m * dphi)
    return -m * avg_sin

def probe_matched(nr, nphi, m, physical_points, tol=1e-10):
    h = 1.0 / nr
    def field(X, Y):
        r = np.sqrt(X**2 + Y**2)
        if r < 1e-14:
            return 0.0, 0.0
        phi = np.arctan2(Y, X)
        Bphi = r * np.cos(m * phi)
        return -Bphi * np.sin(phi), Bphi * np.cos(phi)
    def Bx_func(X, Y):
        return field(X, Y)[0]
    def By_func(X, Y):
        return field(X, Y)[1]
    radial, azi = precompute_face_fluxes(nr, nphi, Bx_func, By_func)
    samples = []
    dr = 1.0 / nr
    dphi = 2 * np.pi / nphi
    for r_phys, phi_phys in physical_points:
        i_c = min(int(r_phys / dr), nr - 1)
        j_c = int(phi_phys / dphi) % nphi
        C, d, Xc, Yc = build_system_cached(nr, nphi, i_c, j_c, 3, 3, radial, azi, h)
        if C.shape[0] < 3:
            continue
        try:
            c_part = np.linalg.lstsq(C, d, rcond=1e-12)[0]
            eps = float(np.linalg.norm(C @ c_part - d))
        except np.linalg.LinAlgError:
            continue
        area = cell_area(nr, nphi, i_c, j_c)
        D_h = 2.0 * eps / area if area > 0 else float('inf')
        div_exact = analytical_div_avg(m, nr, nphi, i_c, j_c)
        refused = eps > tol
        samples.append({
            "r": r_phys,
            "phi": phi_phys,
            "i": i_c,
            "j": j_c,
            "eps": eps,
            "area": area,
            "D_h": D_h,
            "div_exact": div_exact,
            "refused": refused,
            "abs_diff": abs(D_h - abs(div_exact))
        })
    return samples

def run():
    t0 = perf_counter()
    # Matched physical locations
    physical_points = [
        (0.25, 0.3),
        (0.45, 1.2),
        (0.65, 2.4),
        (0.80, 0.7)
    ]
    grids = [(8, 12), (16, 24), (32, 48)]
    results = {}
    for m in [1, 2]:
        mode_data = {}
        for nr, nphi in grids:
            samples = probe_matched(nr, nphi, m, physical_points)
            mode_data[f"{nr}x{nphi}"] = samples
        results[f"m{m}"] = mode_data
    report = {
        "campaign": "LIM-CONV-05",
        "version": "0.4.58-conv05",
        "results": {
            "description": "area-normalized residual vs analytical cell-averaged divergence",
            "matched_points": physical_points,
            "modes": results
        },
        "wall_time_s": perf_counter() - t0
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run()
