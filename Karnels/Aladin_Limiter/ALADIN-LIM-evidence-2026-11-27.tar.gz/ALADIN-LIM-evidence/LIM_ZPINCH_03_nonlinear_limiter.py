#!/usr/bin/env python3
"""
ALADIN-LIM  LIM-ZPINCH-03
Operational Nonlinear Limiter (minimum functional version)
Native-cylindrical Z-pinch MHD.
Π diagnostic is strictly read-only — zero influence.
"""
import numpy as np
import json, hashlib
from time import perf_counter

print("LIM-ZPINCH-03 Operational Nonlinear Limiter")

# ---------------------------------------------------------------------------
# Frozen reconstruction interface (placeholder — uses existing foundation)
# ---------------------------------------------------------------------------
def reconstruct_unlimited(q_bar, neighbors, moments):
    """Return high-order coefficients c_H (mean-preserving)."""
    # In production this calls the frozen centered-isotropic operator
    return np.zeros(5)   # placeholder

def nullspace_basis(C):
    """Return null-space matrix N such that C @ N = 0."""
    # Placeholder: identity for demo
    return np.eye(5)

# ---------------------------------------------------------------------------
# Minimum functional nonlinear limiter
# ---------------------------------------------------------------------------
def limit_coefficients(c_H, q_bar, neighbors, positivity_bounds,
                       extremum_tol=1e-8, osc_tol=1e-6):
    """
    Apply minimum correction inside the admissible space.
    c_LIM = c_H + N z,  C N = 0.
    Returns limited coefficients and a flag.
    """
    # 1. Start from unlimited
    c = c_H.copy()

    # 2. Check positivity at evaluation points (cell + faces)
    #    (placeholder logic — real version evaluates reconstruction)
    needs_positivity = False
    if q_bar < positivity_bounds.get("rho", 0) or q_bar < positivity_bounds.get("p", 0):
        needs_positivity = True

    # 3. Detect oscillations (simple neighbor comparison)
    neighbor_max = np.max(neighbors)
    neighbor_min = np.min(neighbors)
    is_extremum = (q_bar >= neighbor_max - extremum_tol) or (q_bar <= neighbor_min + extremum_tol)
    is_oscillation = (not is_extremum) and (np.max(np.abs(neighbors - q_bar)) > osc_tol)

    # 4. If admissible, leave unchanged
    if not needs_positivity and not is_oscillation:
        return c, "unlimited"

    # 5. Minimum correction in null space (placeholder scaling)
    N = nullspace_basis(None)
    # Scale toward zero correction that restores positivity / removes osc
    alpha = 0.0
    if needs_positivity:
        alpha = 0.5          # conservative pull-back
    elif is_oscillation:
        alpha = 0.25

    z = -alpha * np.linalg.lstsq(N, c, rcond=None)[0]
    c_lim = c + N @ z

    return c_lim, "limited"

# ---------------------------------------------------------------------------
# Driver-facing interface
# ---------------------------------------------------------------------------
def apply_limiter(q_bar, neighbors, moments, positivity_bounds):
    c_H = reconstruct_unlimited(q_bar, neighbors, moments)
    c_lim, flag = limit_coefficients(c_H, q_bar, neighbors, positivity_bounds)
    return c_lim, flag

# ---------------------------------------------------------------------------
# Frozen acceptance criteria (recorded before any run)
# ---------------------------------------------------------------------------
ACCEPTANCE = {
    "mean_preservation_max_err": 1e-14,
    "positivity_violations": 0,
    "smooth_extremum_clipping": False,
    "axis_regularity_preserved": True,
    "Pi_influence": 0.0,          # must remain exactly zero
    "regression_AXM_m2_m3_m4": "preserve_original_failures"
}

def run_demo():
    t0 = perf_counter()
    # Synthetic cell
    q_bar = 1.2
    neighbors = np.array([1.1, 1.3, 0.9, 1.4, 1.0])
    bounds = {"rho": 1e-12, "p": 1e-12}
    c_lim, flag = apply_limiter(q_bar, neighbors, None, bounds)

    report = {
        "campaign": "LIM-ZPINCH-03",
        "version": "0.4.63-zpinch03",
        "description": "operational nonlinear limiter — minimum functional",
        "acceptance_criteria": ACCEPTANCE,
        "demo_result": {
            "flag": flag,
            "c_lim_norm": float(np.linalg.norm(c_lim)),
            "Pi_feedback": 0.0
        },
        "wall_time_s": perf_counter() - t0,
        "note": "Π is strictly read-only. No threshold used."
    }
    raw = json.dumps(report, sort_keys=True).encode()
    report["sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    run_demo()
