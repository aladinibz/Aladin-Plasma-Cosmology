# HLLD-05 results: ALADIN HLLD v05.2

Made 2026-11-20 23:43 UTC.  Source hash frozen and identical on all legs: **True**

- cpu leg kernel sha256 `7e32b8643a7356fe77fa1883406954e30401635a91c04c4d489a5c60f9c0cda0`, build sha256 `0530cf05260c494e9336ad72cd11b1c84b9c2d9da69b4ad84cc62b2f5d77a6be` (source of record: leg JSON)
- gpu leg kernel sha256 `7e32b8643a7356fe77fa1883406954e30401635a91c04c4d489a5c60f9c0cda0`, build sha256 `0530cf05260c494e9336ad72cd11b1c84b9c2d9da69b4ad84cc62b2f5d77a6be` (source of record: RECONSTRUCTED from the GPU console transcript (hlld05_run2_gpu_TRANSCRIPT.txt, sha256 366f90d3116e9a0ac158d1092ec33ce690465546b6f681d8373a3d07cc3350f3); the GPU leg JSON was not supplied (Colab output pasted))

| Test | Final | cpu | gpu |
|---|---|---|---|
| H01 | VERIFIED | VERIFIED | VERIFIED |
| H02 | VERIFIED | VERIFIED | VERIFIED |
| H03 | VERIFIED | VERIFIED | VERIFIED |
| H04 | VERIFIED | VERIFIED | VERIFIED |
| H05 | VERIFIED | VERIFIED | VERIFIED |
| H06 | VERIFIED | VERIFIED | VERIFIED |
| H07 | VERIFIED | VERIFIED | VERIFIED |
| H08 | VERIFIED | VERIFIED | VERIFIED |
| H09 | VERIFIED | VERIFIED | VERIFIED |
| H10 | VERIFIED | VERIFIED | VERIFIED |
| H11 | VERIFIED | VERIFIED | VERIFIED |
| H12 | VERIFIED | VERIFIED | VERIFIED |
| H13 | VERIFIED | VERIFIED | VERIFIED |
| H14 | VERIFIED | VERIFIED | VERIFIED |
| H15 | VERIFIED | VERIFIED | VERIFIED |
| H16 | VERIFIED | VERIFIED | VERIFIED |
| H17 | VERIFIED | VERIFIED | VERIFIED |
| H18 | VERIFIED | VERIFIED | VERIFIED |
| K01 | VERIFIED | VERIFIED | VERIFIED |
| K02 | VERIFIED | VERIFIED | VERIFIED |
| K03 | VERIFIED | VERIFIED | VERIFIED |
| K04 | VERIFIED | VERIFIED | VERIFIED |
| K05 | VERIFIED | VERIFIED | VERIFIED |
| R00 | VERIFIED | VERIFIED | VERIFIED |
| R01 | VERIFIED | VERIFIED | VERIFIED |
| R02 | VERIFIED | VERIFIED | VERIFIED |
| R03 | VERIFIED | VERIFIED | VERIFIED |
| R04 | VERIFIED | VERIFIED | VERIFIED |
| N1 | VERIFIED | VERIFIED | VERIFIED |
| S1 | VERIFIED | VERIFIED | VERIFIED |
| L01 | VERIFIED | VERIFIED | VERIFIED |
| L02 | BLOCKER | BLOCKER | BLOCKER |
| L03 | VERIFIED | VERIFIED | VERIFIED |
| G1 | VERIFIED | — | VERIFIED |
| G2 | VERIFIED | — | VERIFIED |
| G3 | VERIFIED | — | VERIFIED |
| G4 | VERIFIED | — | VERIFIED |
| G5 | VERIFIED | — | VERIFIED |
| G6 | VERIFIED | — | VERIFIED |
| G7 | VERIFIED | — | VERIFIED |
| G8 | VERIFIED | — | VERIFIED |
| G9 | VERIFIED | — | VERIFIED |
| M1_memcheck | VERIFIED |  |  |
| M2_racecheck | VERIFIED |  |  |

Counts: {'VERIFIED': 43, 'BLOCKER': 1}

## Checks (measured vs predeclared threshold)

- H01 [cpu] worst rel: 8.9592e-15 <= 1.0e-13 -> pass
- H01 [gpu] worst rel: 8.9590e-15 <= 1.0e-13 -> pass
- H02 [cpu] worst rel: 5.2116e-12 <= 1.0e-10 -> pass
- H02 [cpu] 99.99% quantile: 2.1991e-13 <= 1.0e-12 -> pass
- H02 [gpu] worst rel: 5.2120e-12 <= 1.0e-10 -> pass
- H02 [gpu] 99.99% quantile: 2.1990e-13 <= 1.0e-12 -> pass
- H03 [cpu] worst rel: 4.8390e-15 <= 1.0e-13 -> pass
- H03 [gpu] worst rel: 4.8390e-15 <= 1.0e-13 -> pass
- H04 [cpu] worst rel: 9.3695e-15 <= 1.0e-13 -> pass
- H04 [gpu] worst rel: 9.3700e-15 <= 1.0e-13 -> pass
- H05 [cpu] worst rel (v02): 5.0239e-15 <= 1.0e-13 -> pass
- H05 [gpu] worst rel (v02): 5.0240e-15 <= 1.0e-13 -> pass
- H06 [cpu] worst rel vs oracle: 8.8961e-15 <= 1.0e-10 -> pass
- H06 [gpu] worst rel vs oracle: 8.8960e-15 <= 1.0e-10 -> pass
- H07 [cpu] worst rel between directions: 0.0000e+00 <= 1.0e-14 -> pass
- H07 [gpu] worst rel between directions: 0.0000e+00 <= 1.0e-14 -> pass
- H08 [cpu] finite and oracle-consistent: 1.0000e+00 == 1.0e+00 -> pass
- H08 [cpu] first-order faces exercised: 3.2400e+02 >= 1.0e+00 -> pass
- H08 [gpu] finite and oracle-consistent: 1.0000e+00 == 1.0e+00 -> pass
- H08 [gpu] first-order faces exercised: 3.2400e+02 >= 1.0e+00 -> pass
- H09 [cpu] worst rel vs physical flux of the face state: 2.8162e-16 <= 1.0e-14 -> pass
- H09 [gpu] worst rel vs physical flux of the face state: 2.8160e-16 <= 1.0e-14 -> pass
- H10 [cpu] MC final order: 1.9780e+00 >= 1.9e+00 -> pass
- H10 [cpu] minmod final order: 1.8833e+00 >= 1.8e+00 -> pass
- H10 [cpu] MC rel L1 at nz=256: 7.3261e-04 <= 1.0e-03 -> pass
- H10 [gpu] MC final order: 1.9780e+00 >= 1.9e+00 -> pass
- H10 [gpu] minmod final order: 1.8830e+00 >= 1.8e+00 -> pass
- H10 [gpu] MC rel L1 at nz=256: 7.3260e-04 <= 1.0e-03 -> pass
- H11 [cpu] mean L1 order 100->800: 8.6373e-01 >= 7.0e-01 -> pass
- H11 [cpu] L1(rho) at nz=800: 8.2515e-04 <= 1.2e-03 -> pass
- H11 [gpu] mean L1 order 100->800: 8.6370e-01 >= 7.0e-01 -> pass
- H11 [gpu] L1(rho) at nz=800: 8.2510e-04 <= 1.2e-03 -> pass
- H12 [cpu] finite and positive: 1.0000e+00 == 1.0e+00 -> pass
- H12 [cpu] max |mass or energy change|: 2.8422e-16 <= 1.0e-12 -> pass
- H12 [gpu] finite and positive: 1.0000e+00 == 1.0e+00 -> pass
- H12 [gpu] max |mass or energy change|: 2.8420e-16 <= 1.0e-12 -> pass
- H13 [cpu] worst 99.99% quantile: 6.8038e-12 <= 1.0e-06 -> pass
- H13 [cpu] all finite: 1.0000e+00 == 1.0e+00 -> pass
- H13 [gpu] worst 99.99% quantile: 6.8040e-12 <= 1.0e-06 -> pass
- H13 [gpu] all finite: 1.0000e+00 == 1.0e+00 -> pass
- H14 [cpu] 99.99% quantile: 6.0572e-06 <= 1.0e-04 -> pass
- H14 [cpu] worst: 7.1078e-06 <= 2.0e-03 -> pass
- H14 [gpu] 99.99% quantile: 6.0570e-06 <= 1.0e-04 -> pass
- H14 [gpu] worst: 7.1080e-06 <= 2.0e-03 -> pass
- H15 [cpu] max |F| / physical flux scale on the sweeps: 2.7045e+00 <= 1.0e+01 -> pass
- H15 [cpu] edges located: 2.8000e+01 >= 1.0e+01 -> pass
- H15 [cpu] no HLLD face with violated ordering: 1.0000e+00 == 1.0e+00 -> pass
- H15 [gpu] max |F| / physical flux scale on the sweeps: 2.7040e+00 <= 1.0e+01 -> pass
- H15 [gpu] edges located: 2.8000e+01 >= 1.0e+01 -> pass
- H15 [gpu] no HLLD face with violated ordering: 1.0000e+00 == 1.0e+00 -> pass
- H16 [cpu] FP64 disagreements: 0.0000e+00 <= 0.0e+00 -> pass
- H16 [cpu] FP32 disagreement fraction: 0.0000e+00 <= 1.0e-04 -> pass
- H16 [gpu] FP64 disagreements: 0.0000e+00 <= 0.0e+00 -> pass
- H16 [gpu] FP32 disagreement fraction: 0.0000e+00 <= 1.0e-04 -> pass
- H17 [cpu] FP64 worst: 4.6042e-14 <= 1.0e-12 -> pass
- H17 [cpu] FP32 worst: 4.5778e-05 <= 1.0e-03 -> pass
- H17 [gpu] FP64 worst: 4.6040e-14 <= 1.0e-12 -> pass
- H17 [gpu] FP32 worst: 4.5780e-05 <= 1.0e-03 -> pass
- H18 [cpu] max guard rate (random): 4.2100e-03 <= 1.0e-02 -> pass
- H18 [cpu] guard faces in smooth problems: 0.0000e+00 <= 0.0e+00 -> pass
- H18 [gpu] max guard rate (random): 4.2100e-03 <= 1.0e-02 -> pass
- H18 [gpu] guard faces in smooth problems: 0.0000e+00 <= 0.0e+00 -> pass
- K01 [cpu] max jump at h = 1e-12: 3.9888e-11 <= 1.0e-06 -> pass
- K01 [cpu] boundaries tested: 5.1000e+01 >= 2.0e+01 -> pass
- K01 [gpu] max jump at h = 1e-12: 3.9890e-11 <= 1.0e-06 -> pass
- K01 [gpu] boundaries tested: 5.1000e+01 >= 2.0e+01 -> pass
- K02 [cpu] max |U(heal on) - U(heal off)|: 0.0000e+00 <= 0.0e+00 -> pass
- K02 [gpu] max |U(heal on) - U(heal off)|: 0.0000e+00 <= 0.0e+00 -> pass
- K03 [cpu] failures with all healing on: 0.0000e+00 <= 0.0e+00 -> pass
- K03 [cpu] blend faces exercised (HLL + blended): 6.6300e+02 >= 1.0e+00 -> pass
- K03 [gpu] failures with all healing on: 0.0000e+00 <= 0.0e+00 -> pass
- K03 [gpu] blend faces exercised (HLL + blended): 6.6300e+02 >= 1.0e+00 -> pass
- K04 [cpu] all problems completed with recovery: 1.0000e+00 == 1.0e+00 -> pass
- K04 [cpu] problems that needed recovery: 3.0000e+00 >= 1.0e+00 -> pass
- K04 [gpu] all problems completed with recovery: 1.0000e+00 == 1.0e+00 -> pass
- K04 [gpu] problems that needed recovery: 3.0000e+00 >= 1.0e+00 -> pass
- K05 [cpu] max deviation (unflagged: abs; flagged: rel vs oracle): 6.0022e-16 <= 1.0e-13 -> pass
- K05 [cpu] flagged faces: 1.8000e+01 >= 1.2e+01 -> pass
- K05 [gpu] flagged: rel vs oracle): 6.0020e-16 <= 1.0e-13 -> pass
- K05 [gpu] flagged faces: 1.8000e+01 >= 1.2e+01 -> pass
- R00 [cpu] Riemann problems off the ramp differing + grid flag mismatches: 0.0000e+00 <= 0.0e+00 -> pass
- R00 [cpu] max relative |v05.2 - v04| everywhere: 0.0000e+00 <= 1.0e-12 -> pass
- R00 [gpu] Riemann problems off the ramp differing + grid flag mismatches: 0.0000e+00 <= 0.0e+00 -> pass
- R00 [gpu] max relative |v05.2 - v04| everywhere: 0.0000e+00 <= 1.0e-12 -> pass
- R01 [cpu] fraction of invalid cases refused (code 4, all-NaN flux): 1.0000e+00 == 1.0e+00 -> pass
- R01 [cpu] admissible edge cases never refused: 1.0000e+00 == 1.0e+00 -> pass
- R01 [cpu] kernel refusal == oracle rule on every face: 1.0000e+00 == 1.0e+00 -> pass
- R01 [gpu] fraction of invalid cases refused (code 4, all-NaN flux): 1.0000e+00 == 1.0e+00 -> pass
- R01 [gpu] admissible edge cases never refused: 1.0000e+00 == 1.0e+00 -> pass
- R01 [gpu] kernel refusal == oracle rule on every face: 1.0000e+00 == 1.0e+00 -> pass
- R02 [cpu] max (refused-set mismatch, non-NaN refused flux, change elsewhere): 0.0000e+00 <= 0.0e+00 -> pass
- R02 [gpu] max (refused-set mismatch, non-NaN refused flux, change elsewhere): 0.0000e+00 <= 0.0e+00 -> pass
- R03 [cpu] refusal holds in all settings: 1.0000e+00 == 1.0e+00 -> pass
- R03 [gpu] refusal holds in all settings: 1.0000e+00 == 1.0e+00 -> pass
- R04 [cpu] every run stopped in the first step: 1.0000e+00 == 1.0e+00 -> pass
- R04 [gpu] every run stopped in the first step: 1.0000e+00 == 1.0e+00 -> pass
- N1 [cpu] failures with full healing (flux healing + recovery): 0.0000e+00 <= 0.0e+00 -> pass
- N1 [gpu] failures with full healing (flux healing + recovery): 0.0000e+00 <= 0.0e+00 -> pass
- S1 [cpu] no run completed with an inadmissible state: 1.0000e+00 == 1.0e+00 -> pass
- S1 [gpu] no run completed with an inadmissible state: 1.0000e+00 == 1.0e+00 -> pass
- L01 [cpu] FP64 max |log10p6 - (log10 m + 6)|: 6.6613e-16 <= 1.0e-15 -> pass
- L01 [cpu] FP32 max abs error: 3.1346e-07 <= 1.0e-06 -> pass
- L01 [cpu] monotonicity violations (sorted m): 0.0000e+00 <= 0.0e+00 -> pass
- L01 [gpu] FP64 max |log10p6 - (log10 m + 6)|: 6.6610e-16 <= 1.0e-15 -> pass
- L01 [gpu] FP32 max abs error: 3.1350e-07 <= 1.0e-06 -> pass
- L01 [gpu] monotonicity violations (sorted m): 0.0000e+00 <= 0.0e+00 -> pass
- L02 [cpu] fraction blended (code 3): 9.9980e-01 >= 9.0e-01 -> pass
- L02 [cpu] max rel |v05.2 - v05.1|: 3.8938e-16 <= 1.0e-12 -> pass
- L02 [cpu] worst rel vs 80-bit oracle: 6.7954e-10 <= 1.0e-10 -> FAIL
- L02 [gpu] fraction blended (code 3): 9.9980e-01 >= 9.0e-01 -> pass
- L02 [gpu] max rel |v05.2 - v05.1|: 3.8940e-16 <= 1.0e-12 -> pass
- L02 [gpu] worst rel vs 80-bit oracle: 6.7950e-10 <= 1.0e-10 -> FAIL
- L03 [cpu] blended phi faces (flag 8): 4.7200e+02 >= 1.0e+02 -> pass
- L03 [cpu] phi max rel |v05.2 - v05.1|: 1.7696e-20 <= 1.0e-12 -> pass
- L03 [cpu] r, z values + all flags differing from v05.1: 0.0000e+00 <= 0.0e+00 -> pass
- L03 [gpu] blended phi faces (flag 8): 4.7200e+02 >= 1.0e+02 -> pass
- L03 [gpu] phi max rel |v05.2 - v05.1|: 1.7700e-20 <= 1.0e-12 -> pass
- L03 [gpu] r, z values + all flags differing from v05.1: 0.0000e+00 <= 0.0e+00 -> pass
- G1 [gpu] FP64: 0.0000e+00 <= 1.0e-12 -> pass
- G1 [gpu] FP32: 0.0000e+00 <= 1.0e-04 -> pass
- G2 [gpu] max |run_i - run_0|: 0.0000e+00 <= 0.0e+00 -> pass
- G3 [gpu] worst rel vs extended: 5.2120e-12 <= 1.0e-10 -> pass
- G4 [gpu] FP64 worst: 0.0000e+00 <= 1.0e-11 -> pass
- G4 [gpu] FP32 worst: 0.0000e+00 <= 5.0e-03 -> pass
- G4 [gpu] fallback-code disagreements (FP64): 0.0000e+00 <= 0.0e+00 -> pass
- G5 [gpu] differing values + integer mismatches: 0.0000e+00 <= 0.0e+00 -> pass
- G6 [gpu] differing values: 0.0000e+00 <= 0.0e+00 -> pass
- G7 [gpu] differing values + flag/code mismatches: 0.0000e+00 <= 0.0e+00 -> pass
- G8 [gpu] '.ftz' instructions in the PTX: 0.0000e+00 <= 0.0e+00 -> pass
- G8 [gpu] FP32 subnormal self-test passed: 1.0000e+00 >= 1.0e+00 -> pass
- G9 [gpu] differing values of W: 0.0000e+00 <= 0.0e+00 -> pass
- G9 [gpu] subnormal values present in W (CPU): 1.9500e+04 >= 1.0e+02 -> pass
- M1_memcheck: VERIFIED ========= ERROR SUMMARY: 0 errors
- M2_racecheck: VERIFIED ========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)
