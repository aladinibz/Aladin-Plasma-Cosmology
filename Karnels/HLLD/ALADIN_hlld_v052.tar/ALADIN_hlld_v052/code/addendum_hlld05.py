# -*- coding: utf-8 -*-
"""HLLD-05 ADDENDUM — declared 2026-11-20 AFTER the CPU leg showed L02 check 3 FAIL (worst rel vs 80-bit oracle 6.8e-10 > 1e-10).
L02 stays FAIL in the record.  These two checks characterise it; they do not replace it.
  A1  no regression: on the 20 000 L02 problems, v05.2's error vs the 80-bit oracle equals v05.1's error EXACTLY (per problem)
  A2  moderate field: log10-ramp problems restricted to |B_n| <= 1e3 (>= 1000 problems), L02's original threshold 1e-10
python addendum_hlld05.py   (CPU)"""
import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import hlld_v05 as H, hlld_v051_reference as V1, band_states as BS, numpy_oracle_hlld as N
TH = dict(A1_error_identical_to_v051=0.0, A2_moderate_field_worst=1e-10, A2_min_problems=1000.0)
def ext(L, R, b): return N.hlld_v04(L.astype(np.longdouble), R.astype(np.longdouble), b.astype(np.longdouble), np.longdouble(5) / 3)[0].astype(np.float64)
rr = lambda F, X: np.abs(F - X).max(1) / np.maximum(np.abs(X).max(1), 1e-300)
out = {}
L, R, b = BS.band(np.random.default_rng(450), 20000); X = ext(L, R, b)
e2, e1 = rr(H.riemann(L, R, b, 5 / 3)[0], X), rr(V1.riemann(L, R, b, 5 / 3)[0], X)
a1 = float(np.abs(e2 - e1).max())
out["A1"] = dict(max_abs_error_difference=a1, worst_v052=float(e2.max()), worst_v051=float(e1.max()), passed=a1 <= TH["A1_error_identical_to_v051"])
rng = np.random.default_rng(455); Ls, Rs, bs = [], [], []; n = 0
while n < 2000:
    l, r, bb = BS.band(rng, 20000); k = np.abs(bb) <= 1e3; Ls.append(l[k]); Rs.append(r[k]); bs.append(bb[k]); n += int(k.sum())
L, R, b = np.concatenate(Ls), np.concatenate(Rs), np.concatenate(bs)
F, c = H.riemann(L, R, b, 5 / 3); w = float(rr(F, ext(L, R, b)).max())
out["A2"] = dict(problems=int(len(b)), blended_fraction=float((c == 3).mean()), max_abs_bn=float(np.abs(b).max()), worst_rel=w,
                 passed=(w <= TH["A2_moderate_field_worst"]) and len(b) >= TH["A2_min_problems"])
for k, v in out.items(): print(k, "PASS" if v["passed"] else "FAIL", v)
json.dump(dict(declared="2026-11-20, after the L02 CPU result", thresholds=TH, results=out), open(os.path.join(HERE, "hlld05_addendum_cpu.json"), "w"), indent=1)
