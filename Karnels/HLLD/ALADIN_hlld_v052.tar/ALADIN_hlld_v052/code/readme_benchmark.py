# -*- coding: utf-8 -*-
"""The README reference benchmark (normalised Z-pinch, mu0 = 1) through the certified ALADIN kernels, unmodified:
   B_phi = r/2  ->  J_z = 1,  f_r = -r/2,  div B = 0,  P = P0 - r^2/4  (dP/dr = -r/2)."""
import sys, os, hashlib, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import uct_curl as UC, uct_emf_v02 as E, eglm_v02 as GL, hlld_v05 as H   # certified kernels, unmodified
print("kernel hashes: UCT_CURL file", hashlib.sha256(open("uct_curl.py", "rb").read()).hexdigest()[:12], "| UCT-EMF", E.SOURCE_SHA256[:12], "| EGLM", GL.SOURCE_SHA256[:12], "| HLLD", H.SOURCE_SHA256[:12])
P0 = 1.0
for (nr, nphi, nz) in ((16, 8, 4), (64, 32, 8)):
    G = E.Grid(nr, nphi, nz, 0.0, 1.0); g = G.g; I = slice(g, g + nr); Jc = slice(g, g + nphi); K = slice(g, g + nz)
    rc = G.r_centers; rf = G.r_faces
    Br, Bp, Bz = G.zeros("Br"), G.zeros("Bphi"), G.zeros("Bz"); Bp[...] = 0.5 * rc[:, None, None]          # B_phi = r/2 on the phi-faces
    # 1) axial current J_z = 1 (UCT_CURL v1.3)
    J, _ = UC.run_curl(Br, Bp, Bz, np.ascontiguousarray(rf), np.ascontiguousarray(rc), G.dr, G.dphi, G.dz, nr, nphi, nz, g)
    J = [np.ascontiguousarray(a) for a in J]
    err_J = float(np.abs(J[2][I, Jc, K] - 1.0).max()); err_Jt = float(max(np.abs(J[0][I, Jc, K]).max(), np.abs(J[1][I, Jc, K]).max()))
    # 2) Lorentz force f_r = -r/2 (UCT-EMF v02)
    fr, fp, fz = E.lorentz_force(G, Br, Bp, Bz, J)
    err_f = float(np.abs(fr[I, Jc, K] - (-0.5 * rc[I, None, None])).max()); err_ft = float(max(np.abs(fp[I, Jc, K]).max(), np.abs(fz[I, Jc, K]).max()))
    # 3) div B = 0 (EGLM v02 monitor, the divergence constrained transport preserves)
    Gg = GL.Grid(nr, nphi, nz, 0.0, 1.0); divn = GL.monitor(Gg, Br, Bp, Bz)["max_abs_div"]
    # 4)+5) pressure balance dP/dr = -r/2: HLLD v05 radial faces, well-balanced with the exact equilibrium face values;
    #       the radial momentum flux on a face is the total pressure P + B_phi^2/2 (B_r = 0, v = 0)
    Gh = H.Grid(nr, nphi, nz, 0.0, 1.0); sh = Gh.shape("cell"); rho = np.ones(sh); z0 = np.zeros(sh); p = (P0 - 0.25 * rc ** 2)[:, None, None] * np.ones(sh)
    W8 = H.pack(Gh, rho, z0, z0, z0, p, Br, Bp, Bz); rfi = rf[g:g + nr + 1][:, None, None]
    Wf = np.zeros(Gh.shape("F_r")); Wf[0] = 1; Wf[4] = P0 - 0.25 * rfi ** 2; Wf[6] = 0.5 * rfi
    F, fl = H.fluxes(Gh, rho, z0, z0, z0, p, Br, Bp, Bz, W_eq=W8, W_eq_faces={0: Wf}, directions=(0,))
    Pface = F[0][1] - 0.5 * (0.5 * rfi) ** 2                     # gas pressure on the r-faces from the HLLD momentum flux
    dPdr = (Pface[1:] - Pface[:-1]) / G.dr                         # at cell centres
    err_dP = float(np.abs(dPdr - (-0.5 * rc[I, None, None])).max()); err_P = float(np.abs(Pface - (P0 - 0.25 * rfi ** 2)).max())
    mass_flux = float(np.abs(F[0][0]).max()); energy_flux = float(np.abs(F[0][4]).max())
    print(f"\ngrid {nr}x{nphi}x{nz} (axis grid, r in [0,1]):")
    print(f"  B_phi = 0.5 r          : set on the CT faces")
    print(f"  J_z = 1                : max |J_z - 1| = {err_J:.1e}   (J_r, J_phi max {err_Jt:.1e})")
    print(f"  f_r = -0.5 r           : max |f_r + 0.5 r| = {err_f:.1e}   (f_phi, f_z max {err_ft:.1e})")
    print(f"  div B = 0              : max |div B| = {divn:.1e}")
    print(f"  P = P0 - r^2/4         : max |P_face - exact| = {err_P:.1e}   (HLLD mass flux {mass_flux:.1e}, energy flux {energy_flux:.1e}: static)")
    print(f"  dP/dr = -0.5 r         : max |dP/dr + 0.5 r| = {err_dP:.1e}")
    print(f"  force balance dP/dr - f_r = {float(np.abs(dPdr - fr[I, Jc, K]).max()):.1e}")
