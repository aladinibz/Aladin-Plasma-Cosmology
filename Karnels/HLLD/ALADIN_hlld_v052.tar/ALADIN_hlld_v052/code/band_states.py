# -*- coding: utf-8 -*-
"""HLLD-05 test data: Riemann problems ON the log10 ramp of the v04 blend (1e-6 < m < 1e-5), m computed by the independent
NumPy oracle (numpy_oracle_hlld.blend_weight_v04 definition), found by bisection on B_n for random state pairs."""
import numpy as np
import numpy_oracle_hlld as N

def m_of(L, R, bn, gam=5 / 3):
    dL, uL, vL, wL, pL, byL, bzL = L.T; dR, uR, vR, wR, pR, byR, bzR = R.T
    cfL = N.fast_speed(dL, pL, bn, byL, bzL, gam); cfR = N.fast_speed(dR, pR, bn, byR, bzR, gam)
    SL = np.minimum(uL, uR) - np.maximum(cfL, cfR); SR = np.maximum(uL, uR) + np.maximum(cfL, cfR)
    pTL = pL + 0.5 * (bn ** 2 + byL ** 2 + bzL ** 2); pTR = pR + 0.5 * (bn ** 2 + byR ** 2 + bzR ** 2)
    with np.errstate(all="ignore"):
        SM = ((SR - uR) * dR * uR - (SL - uL) * dL * uL - pTR + pTL) / ((SR - uR) * dR - (SL - uL) * dL)
        dLs = dL * (SL - uL) / (SL - SM); dRs = dR * (SR - uR) / (SR - SM)
        return np.minimum(dLs * (SL - SM) ** 2, dRs * (SR - SM) ** 2) / bn ** 2 - 1

def band(rng, n, gam=5 / 3):
    """n Riemann problems with oracle m log-uniform in (1e-6, 1e-5)"""
    out_L, out_R, out_b = [], [], []; have = 0
    while have < n:
        k = 2 * n
        L = np.column_stack([rng.uniform(0.1, 3, k), rng.normal(0, 1, k), rng.normal(0, 1, k), rng.normal(0, 1, k), rng.uniform(0.05, 3, k), rng.normal(0, 1, k), rng.normal(0, 1, k)])
        R = np.column_stack([rng.uniform(0.1, 3, k), rng.normal(0, 1, k), rng.normal(0, 1, k), rng.normal(0, 1, k), rng.uniform(0.05, 3, k), rng.normal(0, 1, k), rng.normal(0, 1, k)])
        target = 10 ** rng.uniform(-6, -5, k)
        lo, hi = np.full(k, 1e-3), np.full(k, 1e8)                       # m decreases ~ 1/B_n^2 (bracket checked below)
        ok = (m_of(L, R, lo) > target) & (m_of(L, R, hi) < target)
        for _ in range(200):
            mid = np.sqrt(lo * hi); mm = m_of(L, R, mid)
            up = mm > target; lo = np.where(up, mid, lo); hi = np.where(up, hi, mid)
        bn = np.sqrt(lo * hi) * np.where(rng.uniform(size=k) < 0.5, 1.0, -1.0); mm = m_of(L, R, bn)
        keep = ok & (mm > 1e-6) & (mm < 1e-5) & np.isfinite(mm)
        out_L.append(L[keep]); out_R.append(R[keep]); out_b.append(bn[keep]); have += int(keep.sum())
    return np.concatenate(out_L)[:n], np.concatenate(out_R)[:n], np.concatenate(out_b)[:n]
