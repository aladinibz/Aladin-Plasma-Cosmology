# -*- coding: utf-8 -*-
"""
ALADIN HLLD v05.2 -- certification campaign HLLD-05.   python campaign_hlld05.py cpu | gpu
HLLD-05 re-runs EVERY HLLD-04 test on v05.2 with the HLLD-04 thresholds (R00 restated, see R00), and adds:
  L01 deterministic log10 accuracy + monotonicity      L02 log10-ramp Riemann problems: v05.2 vs v05.1 and vs extended precision
  L03 Z-pinch phi sweep (B_n = B_phi != 0): blended faces present, v05.2 vs v05.1
  G6  log10p6 GPU == CPU bitwise (FP64, FP32)          G7  log10-ramp problems + Z-pinch grids: GPU == CPU bitwise (FP64, FP32)
  G8  GPU build: PTX free of .ftz, FP32 subnormal arithmetic IEEE (direct NVRTC loader)
Why: Driver v4.0 KW-00 (2026-11-20) found HLLD-phi fluxes differing GPU vs CPU by a few ulp on blended faces; the cause is the
math-library log10() in the v04 blend weight.  HLLD-04 G5 did not see it: random states reach the log10 ramp ~1 in 10^5.
Frozen kernel (SOURCE_SHA256 checked).  Thresholds PREDECLARED in THRESHOLDS.  Classes VERIFIED / LIMITATION /
INCONCLUSIVE / BLOCKER.  Writes hlld04_<leg>_results.json and hlld04_<leg>.log.
"""
import sys, os, time, json, copy, hashlib, platform, datetime, traceback, subprocess, warnings, ctypes
import numpy as np
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import hlld_v05 as H
import dev_heal as K
import numpy_oracle_hlld as N
import dev_hlld as D

FROZEN_SHA = "7e32b8643a7356fe77fa1883406954e30401635a91c04c4d489a5c60f9c0cda0"      # v05.2 C source
FROZEN_BUILD = "0530cf05260c494e9336ad72cd11b1c84b9c2d9da69b4ad84cc62b2f5d77a6be"   # source + GPU options + CPU flags + GPU loader (v05.2)
RUN = "run 2 (v05.2: kernel-side pack; reference builds as shipped on the GPU)"
# run 2 changes (declared 2026-11-20 before run 2, after run 1):
#  * kernel: W (cell-centred B) built inside the IEEE module on the GPU (run 1 G7: CuPy elementwise flushes FP32 subnormals)
#  * harness: on the GPU the v04 / v05.1 references are built as they shipped (cupy.RawModule, -fmad=false) and compared in
#    FP64 only (their FP32 GPU builds flush subnormals by design); run 1 built them with v05.2's strict loader, which refuses
#    their PTX (log10f -> .ftz instructions): R00, L02, L03 crashed on the GPU in run 1.
#  * new G9 (W on the GPU == W on the CPU, FP32 S6 states, subnormals present)
import band_states as BS
GAM = 5 / 3

THRESHOLDS = dict(
    H01_consistency_rel=1e-13,
    H02_vs_extended_worst=1e-10, H02_vs_extended_q9999=1e-12,
    H03_contact_rel=1e-13, H04_rotational_rel=1e-13, H05_tangential_rel=1e-13,
    H06_grid_vs_oracle_rel=1e-10,
    H07_frame_rel=1e-14,
    H08_fallback_finite=1.0,
    H09_well_balanced_rel=1e-14,
    H10_cpaw_mc_order=1.85, H10_cpaw_minmod_order=1.75, H10_cpaw_mc_err256=1e-3,
    H11_sod_order=0.7, H11_sod_err800=1.2e-3,
    H12_brio_wu_conservation=1e-12,
    H13_extreme_vs_extended=1e-6,
    H14_fp32_rel=1e-4, H14_fp32_worst=2e-3,
    H15_edge_flux_bound=10.0, H15_hlld_faces_ordering_ok=1.0,
    H16_guard_disagree_fp64=0.0, H16_guard_disagree_fp32_frac=1e-4,
    H17_g1_fp64_worst=1e-12, H17_g1_fp32_worst=1e-3,
    H18_guard_rate_random=0.01, H18_guard_faces_smooth=0.0,
    K01_continuity_h1e12=1e-6, K02_heal_off_identical=0.0, K03_heal_on_failures=0.0, K03_blend_faces_min=1.0,
    K04_all_completed=1.0, K05_mask_exact=0.0,
    R00_regression_v04=0.0, R01_refused_all=1.0, R01_admissible_kept=1.0, R02_locality=0.0, R03_not_overridable=1.0, R04_evolution_stops=1.0,
    N1_heal_on_failures=0.0, S1_never_invalid=1.0,
    G1_gpu_cpu_fp64=1e-12, G1_gpu_cpu_fp32=1e-4,
    G4_gpu_cpu_worst_fp64=1e-11, G4_gpu_cpu_worst_fp32=5e-3, G4_gpu_guard_disagree=0.0,
    G2_determinism=0.0, G5_gpu_cpu_bitwise=0.0,
    G3_gpu_vs_extended_worst=1e-10,
    # HLLD-05 (new, predeclared 2026-11-20 before any v05.2 result)
    R00_off_ramp_differing=0.0, R00_on_ramp_rel=1e-12,
    L01_log10_fp64_abs=1e-15, L01_log10_fp32_abs=1e-6, L01_monotone_violations=0.0,
    L02_ramp_blended_frac=0.9, L02_vs_v051_rel=1e-12, L02_vs_extended_worst=1e-10,
    L03_phi_blended_faces_min=100.0, L03_vs_v051_rel=1e-12, L03_rz_identical_to_v051=0.0,
    G6_log10_gpu_cpu_bitwise=0.0, G7_ramp_gpu_cpu_bitwise=0.0, G8_ptx_ftz=0.0, G8_fp32_subnormal_ieee=1.0,
    G9_pack_gpu_cpu_bitwise=0.0, G9_subnormals_min=100.0,
)

LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
BACKEND = "cupy" if LEG == "gpu" else "cpu"
D.BACKEND = BACKEND; K.BACKEND = BACKEND; K.MAX_PASSES = 8
LOG = open(os.path.join(HERE, f"hlld05_{LEG}.log"), "w")
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.write(s + "\n"); LOG.flush()
if BACKEND == "cupy": import cupy as cp
def dev(G):
    if BACKEND != "cupy": return G
    X = copy.copy(G); X.xp = cp; return X
to = (lambda x: cp.asarray(x)) if BACKEND == "cupy" else (lambda x: x)
host = lambda x: x.get() if hasattr(x, "get") else x

def states(rng, n, vs=1.0, bs=1.0):
    return np.column_stack([rng.uniform(0.1, 3, n), rng.normal(0, vs, n), rng.normal(0, 1, n), rng.normal(0, 1, n), rng.uniform(0.05, 3, n),
                            rng.normal(0, bs, n), rng.normal(0, bs, n)])
def riem(L, R, bn, dtype=np.float64): return H.riemann(L, R, bn, GAM, dtype, BACKEND)
def ext(L, R, bn): return N.hlld_v04(L.astype(np.longdouble), R.astype(np.longdouble), bn.astype(np.longdouble), np.longdouble(5) / 3)[0].astype(np.float64)
def rowrel(F, X): return np.abs(F - X).max(1) / np.maximum(np.abs(X).max(1), 1e-300)
def phys(W, bn): return N.phys_flux(W, bn, GAM)[1]

# ------------------------------------------------------------------ tests
def H01():
    rng = np.random.default_rng(401); W = states(rng, 50000); bn = rng.normal(0, 2, 50000)
    F, fb = riem(W, W, bn); w = float(rowrel(F, phys(W, bn)).max())
    return dict(conditions="50000 random states, L = R: the HLLD flux must equal the physical flux", worst=w, hll_fallbacks=int(fb.sum())), \
        [("worst rel", w, "<=", THRESHOLDS["H01_consistency_rel"])]

def H02():
    rows = []
    for seed, bs in ((402, 1.0), (403, 10.0), (404, 100.0), (405, 0.0), (406, 1e-9)):
        rng = np.random.default_rng(seed); n = 100000; L, R = states(rng, n), states(rng, n)
        bn = rng.normal(0, bs, n) if bs else np.zeros(n)
        F, fb = riem(L, R, bn); e = rowrel(F, ext(L, R, bn))
        rows.append(dict(bn_scale=bs, n=n, worst=float(e.max()), q9999=float(np.quantile(e, 0.9999)), median=float(np.median(e)), hll_fallbacks=int(fb.sum())))
    return dict(conditions="100000 random Riemann problems per B_n regime vs the independent oracle evaluated in extended precision (80-bit)", rows=rows), \
        [("worst rel", max(r["worst"] for r in rows), "<=", THRESHOLDS["H02_vs_extended_worst"]),
         ("99.99% quantile", max(r["q9999"] for r in rows), "<=", THRESHOLDS["H02_vs_extended_q9999"])]

def H03():
    rng = np.random.default_rng(407); n = 20000; w = 0.0
    for bn in (rng.normal(0, 1, n), np.zeros(n)):
        L = states(rng, n); R = L.copy(); R[:, 0] = rng.uniform(0.1, 3, n)
        F, _ = riem(L, R, bn); X = np.where((L[:, 1] >= 0)[:, None], phys(L, bn), phys(R, bn)); w = max(w, float(rowrel(F, X).max()))
    return dict(conditions="isolated contact (density jump only), B_n random and B_n = 0: flux = exact upwind physical flux", worst=w), \
        [("worst rel", w, "<=", THRESHOLDS["H03_contact_rel"])]

def H04():
    rng = np.random.default_rng(408); n = 20000; w = 0.0
    for sg in (1, -1):
        L = states(rng, n); bn = rng.uniform(0.3, 2, n) * rng.choice([-1, 1], n); th = rng.uniform(0, 2 * np.pi, n)
        bt = L[:, 5:7]; btR = np.column_stack([np.cos(th) * bt[:, 0] - np.sin(th) * bt[:, 1], np.sin(th) * bt[:, 0] + np.cos(th) * bt[:, 1]])
        R = L.copy(); R[:, 5:7] = btR; R[:, 2:4] = L[:, 2:4] + sg * np.sign(bn)[:, None] * (btR - bt) / np.sqrt(L[:, 0])[:, None]
        F, _ = riem(L, R, bn); sp = L[:, 1] - sg * np.abs(bn) / np.sqrt(L[:, 0])
        X = np.where((sp >= 0)[:, None], phys(L, bn), phys(R, bn)); w = max(w, float(rowrel(F, X).max()))
    return dict(conditions="isolated rotational (Alfven) discontinuity, both families, random rotation angle", worst=w), [("worst rel", w, "<=", THRESHOLDS["H04_rotational_rel"])]

def H05():
    rng = np.random.default_rng(409); n = 20000
    L, R = states(rng, n, vs=0.3), states(rng, n, vs=0.3); R[:, 1] = L[:, 1]
    R[:, 4] = L[:, 4] + 0.5 * (L[:, 5] ** 2 + L[:, 6] ** 2) - 0.5 * (R[:, 5] ** 2 + R[:, 6] ** 2); ok = R[:, 4] > 0.01; L, R = L[ok], R[ok]
    z = np.zeros(len(L)); F, fb = riem(L, R, z); X = np.where((L[:, 1] >= 0)[:, None], phys(L, z), phys(R, z)); w = float(rowrel(F, X).max())
    out = dict(conditions="B_n = 0 tangential discontinuity (Z-pinch radial faces): rho, p, v_t, B_t jump, total pressure continuous", worst=w, n=len(L))
    orig = os.path.join(HERE, "predecessor", "hlld_cylindrical_kernels.py")
    if os.path.exists(orig):            # informational: the predecessor on the same states (compiled for CPU, FP32)
        try:
            src = open(orig).read().split("hlld_source = r'''")[1].split("'''")[0].split('extern "C" __global__')[0]
            src = src.replace("#include <cuda_runtime.h>", "#include <cmath>\nusing namespace std;").replace("__device__", "static") + '''
extern "C" void orig_riemann(const float* L, const float* R, const float* bn, float* F, float gamma, long n) {
  for (long t = 0; t < n; ++t) { const float* a = L + 7*t; const float* b = R + 7*t; float* f = F + 8*t;
    hlld_flux(a[0],a[1],a[2],a[3],a[4],bn[t],a[5],a[6], b[0],b[1],b[2],b[3],b[4],bn[t],b[5],b[6], f,f+1,f+2,f+3,f+4,f+5,f+6,f+7, gamma); } }'''
            d = os.path.join(HERE, "_orig_build"); os.makedirs(d, exist_ok=True); open(os.path.join(d, "o.cpp"), "w").write(src)
            subprocess.run(["g++", "-O2", "-shared", "-fPIC", "-o", os.path.join(d, "o.so"), os.path.join(d, "o.cpp")], check=True, capture_output=True)
            lib = ctypes.CDLL(os.path.join(d, "o.so")); Lf, Rf, bf = (np.ascontiguousarray(x, np.float32) for x in (L, R, z)); Fo = np.zeros((len(L), 8), np.float32)
            P = lambda a: a.ctypes.data_as(ctypes.c_void_p); lib.orig_riemann(P(Lf), P(Rf), P(bf), P(Fo), ctypes.c_float(GAM), ctypes.c_long(len(L)))
            out["predecessor_worst_rel_informational"] = float(rowrel(np.delete(Fo, 5, 1).astype(np.float64), X).max())
        except Exception as e:
            out["predecessor_worst_rel_informational"] = f"not evaluated: {e!r}"
    return out, [("worst rel (v02)", w, "<=", THRESHOLDS["H05_tangential_rel"])]

def oracle_grid(G, W8, Bn_face, d, limiter, Weq=None, Weqf=None):
    """oracle: reconstruction + HLLD for all interior faces of direction d, global output order"""
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz
    sl = [slice(g, g + n), slice(g, g + P), slice(g, g + Z)]; sl[d] = slice(g, g + (n, P, Z)[d] + 1)
    def shift(a, s):
        idx = [slice(None)] * 3; i = sl[d]; idx[d] = slice(i.start + s, i.stop + s); o = [x for x in sl]; o[d] = idx[d]; return a[tuple(o)]
    L, R = [], []
    for v in range(8):
        q = W8[v] - (Weq[v] if Weq is not None else 0)
        a, b, c, e = shift(q, -2), shift(q, -1), shift(q, 0), shift(q, 1)
        ef = 0 if Weq is None else (0.5 * (shift(Weq[v], -1) + shift(Weq[v], 0)) if Weqf is None else Weqf[v])
        L.append(ef + b + 0.5 * N.limiter(b - a, c - b, limiter)); R.append(ef + c - 0.5 * N.limiter(c - b, e - c, limiter))
    L, R = np.array(L), np.array(R)
    bad = (L[0] <= 0) | (R[0] <= 0) | (L[4] <= 0) | (R[4] <= 0)
    if bad.any():
        for v in range(8): L[v] = np.where(bad, shift(W8[v], -1), L[v]); R[v] = np.where(bad, shift(W8[v], 0), R[v])
    nn, t1, t2 = d, (d + 1) % 3, (d + 2) % 3
    loc = lambda X: np.column_stack([X[0].ravel(), X[1 + nn].ravel(), X[1 + t1].ravel(), X[1 + t2].ravel(), X[4].ravel(), X[5 + t1].ravel(), X[5 + t2].ravel()])
    bn = Bn_face[tuple(sl)].ravel()
    Fl = N.hlld_v04(loc(L), loc(R), bn, GAM)[0]
    out = np.zeros((8,) + L.shape[1:]); out[0] = Fl[:, 0].reshape(L.shape[1:]); out[4] = Fl[:, 4].reshape(L.shape[1:])
    out[1 + nn] = Fl[:, 1].reshape(L.shape[1:]); out[1 + t1] = Fl[:, 2].reshape(L.shape[1:]); out[1 + t2] = Fl[:, 3].reshape(L.shape[1:])
    out[5 + t1] = Fl[:, 5].reshape(L.shape[1:]); out[5 + t2] = Fl[:, 6].reshape(L.shape[1:])
    return out

def rand_fields(G, rng, smooth=True):
    sh = G.shape("cell")
    def f(lo=None, hi=None, s=1.0):
        a = rng.normal(0, s, sh)
        if smooth:
            for ax in range(3): a = 0.5 * a + 0.25 * (np.roll(a, 1, ax) + np.roll(a, -1, ax))
        return a if lo is None else lo + (hi - lo) * (np.tanh(a) + 1) / 2
    rho, p = f(0.3, 2.0), f(0.3, 2.0); vr, vp, vz = f(), f(), f()
    Br, Bp, Bz = rng.normal(0, 1, G.shape("Br")), rng.normal(0, 1, G.shape("Bphi")), rng.normal(0, 1, G.shape("Bz"))
    return rho, vr, vp, vz, p, Br, Bp, Bz

def H06():
    rng = np.random.default_rng(410); rows = []
    for rmin, s in ((0.4, (9, 12, 7)), (0.0, (8, 10, 6)), (0.4, (3, 5, 1)), (0.4, (17, 6, 9))):
        G = H.Grid(*s, rmin, 1.3)
        for lim in ("mc", "minmod"):
            for use_eq in (False, True):
                rho, vr, vp, vz, p, Br, Bp, Bz = rand_fields(G, rng)
                W8 = H.pack(G, rho, vr, vp, vz, p, Br, Bp, Bz)
                Weq = None
                if use_eq: Weq = W8 + 0.05 * rng.normal(0, 1, W8.shape); Weq[0] = np.abs(Weq[0]) + 0.1; Weq[4] = np.abs(Weq[4]) + 0.1
                Fk, fl = H.fluxes(dev(G), *[to(x) for x in (rho, vr, vp, vz, p, Br, Bp, Bz)], gamma=GAM, limiter=lim, W_eq=None if Weq is None else to(Weq), backend=BACKEND)
                for d in (0, 1, 2):
                    if s[d] == 1 and d == 2: pass
                    O = oracle_grid(G, W8, (Br, Bp, Bz)[d], d, lim, Weq)
                    K = host(Fk[d]); e = float(np.abs(K - O).max() / np.abs(O).max())
                    rows.append(dict(grid=f"{'axis' if rmin == 0 else 'annulus'} {s}", limiter=lim, eq=use_eq, dir="r phi z".split()[d], rel=e, flags=int((host(fl[d]) > 0).sum())))
    w = max(r["rel"] for r in rows)
    return dict(conditions="full kernel (reconstruction + HLLD, 3 directions, MC/minmod, with and without equilibrium subtraction) vs oracle on random smooth fields", rows=rows, worst=w), \
        [("worst rel vs oracle", w, "<=", THRESHOLDS["H06_grid_vs_oracle_rel"])]

def H07():
    """the same 1-D Riemann data placed across an r-, phi- and z-face must give the same (permuted) global fluxes"""
    rng = np.random.default_rng(411); G = H.Grid(6, 6, 6, 0.5, 1.5); w = 0.0
    for trial in range(20):
        wl = np.array([rng.uniform(0.3, 2), *rng.normal(0, 1, 3), rng.uniform(0.3, 2)]); wr = np.array([rng.uniform(0.3, 2), *rng.normal(0, 1, 3), rng.uniform(0.3, 2)])
        bl, br_, bnorm = rng.normal(0, 1, 3), rng.normal(0, 1, 3), rng.normal(0, 1)
        res = []
        for d in (0, 1, 2):
            sh = G.shape("cell"); idx = np.indices(sh)[d]; left = idx < G.g + 3
            # global vector components: permute so that the local (n, t1, t2) data is identical for every d
            perm = [(d + k) % 3 for k in range(3)]                 # global index of local n, t1, t2
            cells = {}
            for name, (sL, sR) in (("rho", (wl[0], wr[0])), ("p", (wl[4], wr[4]))): cells[name] = np.where(left, sL, sR)
            v = [None] * 3; B = [None] * 3
            for k in range(3): v[perm[k]] = np.where(left, wl[1 + k], wr[1 + k]); B[perm[k]] = (bl[k], br_[k])
            faces = []
            for gi, kind in enumerate(("Br", "Bphi", "Bz")):
                if gi == perm[0]: faces.append(np.full(G.shape(kind), bnorm))
                else:
                    fi = np.indices(G.shape(kind))[d]; faces.append(np.where(fi < G.g + 3, B[gi][0], B[gi][1]).astype(float))
            F, _ = H.fluxes(dev(G), *[to(x) for x in (cells["rho"], v[0], v[1], v[2], cells["p"], *faces)], gamma=GAM, limiter="minmod", backend=BACKEND, directions=(d,))
            Fd = host(F[d]); face = [slice(None)] * 4; face[1 + d] = 3; others = [1, 1, 1]
            sel = Fd[tuple([slice(None)] + [3 if a == d else 1 for a in range(3)])]
            loc = np.array([sel[0], sel[1 + perm[0]], sel[1 + perm[1]], sel[1 + perm[2]], sel[4], sel[5 + perm[1]], sel[5 + perm[2]]]); res.append(loc)
        w = max(w, float(np.abs(res[1] - res[0]).max() / np.abs(res[0]).max()), float(np.abs(res[2] - res[0]).max() / np.abs(res[0]).max()))
    return dict(conditions="20 random 1-D Riemann problems placed across r, phi and z faces (piecewise constant, minmod -> first order at the jump)", worst=w), \
        [("worst rel between directions", w, "<=", THRESHOLDS["H07_frame_rel"])]

def H08():
    rng = np.random.default_rng(412); G = H.Grid(10, 8, 6, 0.4, 1.3)
    rho, vr, vp, vz, p, Br, Bp, Bz = rand_fields(G, rng)
    W8 = H.pack(G, rho, vr, vp, vz, p, Br, Bp, Bz); Weq = W8.copy(); Weq[0] = W8[0] * rng.uniform(0.0, 3.0, W8[0].shape); Weq[4] = W8[4] * rng.uniform(0.0, 3.0, W8[4].shape)
    F, fl = H.fluxes(dev(G), *[to(x) for x in (rho, vr, vp, vz, p, Br, Bp, Bz)], gamma=GAM, W_eq=to(Weq), backend=BACKEND)
    nfo = sum(int((host(fl[d]) & 1).sum()) for d in range(3)); fin = all(np.isfinite(host(F[d])).all() for d in range(3))
    for d in range(3):
        O = oracle_grid(G, W8, (Br, Bp, Bz)[d], d, "mc", Weq)
        if not np.allclose(host(F[d]), O, rtol=1e-10, atol=1e-12 * np.abs(O).max()): fin = False
    return dict(conditions="badly mismatched equilibrium -> reconstructed rho or p <= 0 on many faces: those faces must fall back to first order, flagged, finite, equal to oracle",
                first_order_faces=nfo), [("finite and oracle-consistent", float(fin), "==", THRESHOLDS["H08_fallback_finite"]), ("first-order faces exercised", float(nfo), ">=", 1.0)]

def H09():
    """Z-pinch equilibrium B_phi = r/2, p = p0 - r^2/4 (J_z = 1): with W_eq = W and exact equilibrium face values, L = R
    on every r-face, so the flux is the physical flux of the exact face state (zero upwind dissipation)."""
    G = H.Grid(16, 8, 4, 0.0, 1.0); rc = G.r_centers[:, None, None]; sh = G.shape("cell"); p0 = 1.0
    rho = np.ones(sh); p = (p0 - 0.25 * rc ** 2) * np.ones(sh); z = np.zeros(sh)
    Br, Bz = np.zeros(G.shape("Br")), np.full(G.shape("Bz"), 0.3); Bp = (0.5 * rc) * np.ones(G.shape("Bphi"))
    W8 = H.pack(G, rho, z, z, z, p, Br, Bp, Bz)
    rf = G.r_faces[G.g:G.g + G.nr + 1][:, None, None]; fs = (8, G.nr + 1, G.nphi, G.nz)
    Wf = np.zeros(fs); Wf[0] = 1; Wf[4] = p0 - 0.25 * rf ** 2; Wf[6] = 0.5 * rf; Wf[7] = 0.3
    F, fl = H.fluxes(dev(G), *[to(x) for x in (rho, z, z, z, p, Br, Bp, Bz)], gamma=GAM, W_eq=to(W8), W_eq_faces={0: to(Wf)}, backend=BACKEND, directions=(0,))
    loc = np.column_stack([Wf[0].ravel(), Wf[1].ravel(), Wf[2].ravel(), Wf[3].ravel(), Wf[4].ravel(), Wf[6].ravel(), Wf[7].ravel()])
    X = phys(loc, np.zeros(loc.shape[0])); K = host(F[0]); Kl = np.column_stack([K[0].ravel(), K[1].ravel(), K[2].ravel(), K[3].ravel(), K[4].ravel(), K[6].ravel(), K[7].ravel()])
    w = float(np.abs(Kl - X).max() / np.abs(X).max())
    Fn, _ = H.fluxes(dev(G), *[to(x) for x in (rho, z, z, z, p, Br, Bp, Bz)], gamma=GAM, backend=BACKEND, directions=(0,))
    Kn = host(Fn[0]); diss = float(np.abs(Kn[[0, 1, 4, 6]] - K[[0, 1, 4, 6]]).max())
    return dict(conditions="static Z-pinch on the axis grid, r-faces; well-balanced mode with exact equilibrium face values", worst=w,
                dissipation_without_eq_subtraction_informational=diss), [("worst rel vs physical flux of the face state", w, "<=", THRESHOLDS["H09_well_balanced_rel"])]

def H10():
    res = {}
    for lim in ("mc", "minmod"):
        rows = [D.cp_alfven(n, lim) for n in (32, 64, 128, 256)]; o = [float(np.log2(rows[i]["rel_l1"] / rows[i + 1]["rel_l1"])) for i in range(3)]
        res[lim] = dict(rows=rows, orders=o)
    return dict(conditions="circularly polarised Alfven wave along z (Toth 2000), one period, SSP-RK2 CFL 0.4, test-only 1-D update", results=res), \
        [("MC final order", res["mc"]["orders"][-1], ">=", THRESHOLDS["H10_cpaw_mc_order"]), ("minmod final order", res["minmod"]["orders"][-1], ">=", THRESHOLDS["H10_cpaw_minmod_order"]),
         ("MC rel L1 at nz=256", res["mc"]["rows"][-1]["rel_l1"], "<=", THRESHOLDS["H10_cpaw_mc_err256"])]

def H11():
    rows = [D.sod(n) for n in (100, 200, 400, 800)]; o = float(np.log2(rows[0]["l1_rho"] / rows[-1]["l1_rho"]) / 3)
    return dict(conditions="Sod shock tube with B = 0 along z vs the exact Euler solution (Toro), t = 0.2, MC", rows=rows, mean_order=o), \
        [("mean L1 order 100->800", o, ">=", THRESHOLDS["H11_sod_order"]), ("L1(rho) at nz=800", rows[-1]["l1_rho"], "<=", THRESHOLDS["H11_sod_err800"])]

def H12():
    rows = []
    for n in (400, 800):
        r = D.brio_wu(n); r.pop("rho"); rows.append(r)
    cons = max(max(r["mass_change"], r["energy_change"]) for r in rows); ok = all(r["finite"] and r["min_rho"] > 0 and r["min_p"] > 0 for r in rows)
    return dict(conditions="Brio & Wu (1988) along z, gamma = 2, t = 0.1, MC", rows=rows), \
        [("finite and positive", float(ok), "==", 1.0), ("max |mass or energy change|", cons, "<=", THRESHOLDS["H12_brio_wu_conservation"])]

def H13():
    rng = np.random.default_rng(413); rows = []; n = 20000
    cases = dict(low_beta=dict(p=1e-6), high_beta=dict(p=1e4), density_contrast=dict(dR=1e-6), hypersonic=dict(v=50.0), strong_bn=dict(bn=100.0), weak_field=dict(b=1e-6))
    for name, c in cases.items():
        L, R = states(rng, n), states(rng, n); bn = rng.normal(0, c.get("bn", 1.0), n)
        if "p" in c: L[:, 4] *= c["p"]; R[:, 4] *= c["p"]
        if "dR" in c: R[:, 0] *= c["dR"]
        if "v" in c: L[:, 1:4] *= c["v"]; R[:, 1:4] *= c["v"]
        if "b" in c: L[:, 5:7] *= c["b"]; R[:, 5:7] *= c["b"]; bn *= c["b"]
        F, fb = riem(L, R, bn); e = rowrel(F, ext(L, R, bn)); fin = bool(np.isfinite(F).all())
        rows.append(dict(case=name, worst=float(e.max()), q9999=float(np.quantile(e, 0.9999)), finite=fin, hll_fallbacks=int(fb.sum())))
    w = max(r["q9999"] for r in rows)
    return dict(conditions="random Riemann problems at extreme parameters vs extended-precision oracle", rows=rows), \
        [("worst 99.99% quantile", w, "<=", THRESHOLDS["H13_extreme_vs_extended"]), ("all finite", float(all(r["finite"] for r in rows)), "==", 1.0)]

def H14():
    rng = np.random.default_rng(414); n = 20000; L, R = states(rng, n), states(rng, n); bn = rng.normal(0, 1, n)
    F32, _ = riem(L.astype(np.float32), R.astype(np.float32), bn.astype(np.float32), np.float32)
    X = ext(L.astype(np.float32).astype(np.float64), R.astype(np.float32).astype(np.float64), bn.astype(np.float32).astype(np.float64))
    e = rowrel(F32.astype(np.float64), X); return dict(conditions="FP32 kernel vs extended-precision oracle on the same FP32 inputs", q9999=float(np.quantile(e, 0.9999)), worst=float(e.max())), \
        [("99.99% quantile", float(np.quantile(e, 0.9999)), "<=", THRESHOLDS["H14_fp32_rel"]), ("worst", float(e.max()), "<=", THRESHOLDS["H14_fp32_worst"])]

# ------------------------------------------------------------------ new in HLLD-04 (targets the G1 finding)
def _margin(L, R, b):
    ld = np.longdouble; L, R, b = L.astype(ld), R.astype(ld), ld(b); g = ld(5) / 3
    cL = N.fast_speed(L[None, 0], L[None, 4], np.array([b]), L[None, 5], L[None, 6], g)[0]; cR = N.fast_speed(R[None, 0], R[None, 4], np.array([b]), R[None, 5], R[None, 6], g)[0]
    SL = min(L[1], R[1]) - max(cL, cR); SR = max(L[1], R[1]) + max(cL, cR)
    pTL = L[4] + 0.5 * (b * b + L[5] ** 2 + L[6] ** 2); pTR = R[4] + 0.5 * (b * b + R[5] ** 2 + R[6] ** 2)
    SM = ((SR - R[1]) * R[0] * R[1] - (SL - L[1]) * L[0] * L[1] - pTR + pTL) / ((SR - R[1]) * R[0] - (SL - L[1]) * L[0])
    dLs = L[0] * (SL - L[1]) / (SL - SM); dRs = R[0] * (SR - R[1]) / (SR - SM)
    return float(min(dLs * (SL - SM) ** 2, dRs * (SR - SM) ** 2) / (b * b) - 1)

def H15():
    from scipy.optimize import brentq
    rng = np.random.default_rng(415); n = 400000; L, R = states(rng, n), states(rng, n); b = rng.normal(0, 3, n)
    F, fb = riem(L, R, b); cand = np.where(fb == 2)[0][:40]; edges = 0; worst = 0.0
    for i in cand:
        mk = lambda s: np.r_[L[i][:4], L[i][4] * (1 + s), L[i][5:]]
        try: s0 = brentq(lambda s: _margin(mk(s), R[i], b[i]), -0.9, 3.0, xtol=1e-15)
        except Exception: continue
        edges += 1
        for off in (1e-1, 1e-3, 1e-5, 1e-6, 1e-7, 1e-9, 1e-12, 0, -1e-12, -1e-9, -1e-6, -1e-3, -1e-1):
            Li = mk(s0 + off * max(abs(s0), 1e-3))
            if Li[4] <= 0: continue
            sc = np.abs(N.phys_flux(np.vstack([Li, R[i]]), np.r_[b[i], b[i]], GAM)[1]).max()
            for dt_ in (np.float64, np.float32):
                Fi, _ = riem(Li[None], R[i][None], b[i:i + 1], dt_); worst = max(worst, float(np.abs(Fi).max() / sc))
    # every face the kernel solved with HLLD (code 0, inside the fan) must satisfy the ordering with margin
    rngb = np.random.default_rng(416); L2, R2 = states(rngb, 200000), states(rngb, 200000); b2 = rngb.normal(0, 10, 200000)
    F2, fb2 = riem(L2, R2, b2); wx = N.blend_weight_v04(L2.astype(np.longdouble), R2.astype(np.longdouble), b2.astype(np.longdouble), np.longdouble(5) / 3)[0]
    ok = float(not np.any((fb2 == 0) & (wx < 1)))
    return dict(conditions="located singular edges (rho*(S-S_M)^2 = B_n^2) swept from both sides in FP64 and FP32; HLLD faces checked for valid wave ordering", edges=edges, worst_flux_over_scale=worst), \
        [("max |F| / physical flux scale on the sweeps", worst, "<=", THRESHOLDS["H15_edge_flux_bound"]), ("edges located", float(edges), ">=", 10.0),
         ("no HLLD face with violated ordering", ok, "==", THRESHOLDS["H15_hlld_faces_ordering_ok"])]

def H16():
    rng = np.random.default_rng(417); n = 1000000; L, R = states(rng, n), states(rng, n); b = rng.normal(0, 5, n)
    cx = N.hlld_v04(L.astype(np.longdouble), R.astype(np.longdouble), b.astype(np.longdouble), np.longdouble(5) / 3)[1]
    _, f64 = riem(L, R, b); _, f32 = riem(L, R, b, np.float32)
    d64 = int((f64 != cx).sum()); d32 = float((f32 != cx).mean())
    return dict(conditions="1e6 random states, B_n ~ N(0,5): kernel blend code (HLLD / HLL / blended) vs the oracle's independently written blend weight (80-bit)", disagree_fp64=d64, disagree_fp32_fraction=d32,
                hll_rate=float((f64 == 2).mean()), blended_rate=float((f64 == 3).mean())), \
        [("FP64 disagreements", float(d64), "<=", THRESHOLDS["H16_guard_disagree_fp64"]), ("FP32 disagreement fraction", d32, "<=", THRESHOLDS["H16_guard_disagree_fp32_frac"])]

def H17():
    rng = np.random.default_rng(31); n = 50000; L, R = states(rng, n), states(rng, n); bn = rng.normal(0, 1, n)        # the frozen G1 data
    out = {}
    for dt_ in (np.float64, np.float32):
        F, fb = riem(L, R, bn, dt_); X = ext(L.astype(dt_).astype(float), R.astype(dt_).astype(float), bn.astype(dt_).astype(float)); e = rowrel(F.astype(float), X)
        out[np.dtype(dt_).name] = dict(worst=float(e.max()), q9999=float(np.quantile(e, .9999)), guard_rate=float((fb == 2).mean()), worst_index=int(e.argmax()))
    return dict(conditions="the exact G1 data set of HLLD-01 (seed 31): WORST case vs 80-bit oracle (G1's outlier: v02 1.6e-9 FP64, 0.35 FP32)", **out), \
        [("FP64 worst", out["float64"]["worst"], "<=", THRESHOLDS["H17_g1_fp64_worst"]), ("FP32 worst", out["float32"]["worst"], "<=", THRESHOLDS["H17_g1_fp32_worst"])]

def H18():
    rng = np.random.default_rng(418); rows = []
    for bs in (0.0, 1e-3, 1.0, 10.0, 100.0):
        n = 200000; L, R = states(rng, n), states(rng, n); b = rng.normal(0, bs, n) if bs else np.zeros(n); _, fb = riem(L, R, b)
        rows.append(dict(bn_scale=bs, guard_rate=float((fb >= 2).mean()), hll_rate=float((fb == 2).mean()), blended_rate=float((fb == 3).mean())))
    smooth = 0
    for lim in ("mc", "minmod"):
        for nz in (64, 256): smooth += D.cp_alfven(nz, lim)["fallbacks"]
    smooth += sum(D.sod(n)["fallbacks"] for n in (100, 800)); smooth += sum(D.brio_wu(n)["fallbacks"] for n in (400, 800))
    rngg = np.random.default_rng(419); noisy = 0
    for rmin, sz in ((0.4, (16, 16, 8)), (0.0, (12, 16, 8))):
        G = H.Grid(*sz, rmin, 1.3)
        # genuinely smooth 3-D field: analytic profiles with strong B (B ~ 3, beta ~ 0.2)
        r, ph, z = G.r_centers[:, None, None], G.phi_c[None, :, None], G.z_c[None, None, :]; sh = G.shape("cell")
        rho = (1 + 0.3 * np.sin(2 * np.pi * z) * np.cos(ph)) * np.ones(sh); p = (1 + 0.2 * np.cos(2 * np.pi * z)) * np.ones(sh)
        vr, vp, vz = 0.3 * np.sin(ph) * np.ones(sh), (0.5 * r + 0.1 * np.cos(2 * np.pi * z)) * np.ones(sh), 0.2 * np.cos(ph) * np.ones(sh)
        Br = 0.5 * np.cos(G.phi_c)[None, :, None] * np.ones(G.shape("Br")); Bp = (2.0 + 0.3 * np.sin(2 * np.pi * G.z_c))[None, None, :] * np.ones(G.shape("Bphi"))
        Bz = (3.0 + 0.2 * np.cos(G.phi_c))[None, :, None] * np.ones(G.shape("Bz"))
        Fk, flg = H.fluxes(dev(G), *[to(x) for x in (rho, vr, vp, vz, p, Br, Bp, Bz)], gamma=GAM, backend=BACKEND)
        smooth += sum(int(((host(flg[d]) & 12) > 0).sum()) for d in range(3))
        fl = rand_fields(G, rngg); Fk, flg = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend=BACKEND)    # informational: random (non-smooth) B
        noisy += sum(int(((host(flg[d]) & 12) > 0).sum()) for d in range(3))
    return dict(conditions="guard rate on random Riemann problems per B_n regime; guard faces in smooth / standard problems (CPAW, Sod, Brio-Wu, analytic smooth 3-D fields with strong B). "
                           "Dry-run note: an earlier draft counted grids with random (non-smooth) face B as 'smooth'; they are kept as informational",
                rows=rows, guard_faces_smooth=smooth, guard_faces_random_grids_informational=noisy), \
        [("max guard rate (random)", max(r["guard_rate"] for r in rows), "<=", THRESHOLDS["H18_guard_rate_random"]), ("guard faces in smooth problems", float(smooth), "<=", THRESHOLDS["H18_guard_faces_smooth"])]

def _edge_points(seed, nmax):
    from scipy.optimize import brentq
    rng = np.random.default_rng(seed); n = 400000; L, R = states(rng, n), states(rng, n); b = rng.normal(0, 3, n)
    F, fb = riem(L, R, b); out = []
    for i in np.where(fb >= 2)[0][:nmax]:
        mk = lambda s, i=i: np.r_[L[i][:4], L[i][4] * (1 + s), L[i][5:]]
        try: s0 = brentq(lambda s: _margin(mk(s), R[i], b[i]), -0.9, 3.0, xtol=1e-15)
        except Exception: continue
        out.append((mk, R[i], b[i], s0))
    return out

def K01():
    """continuity of the flux at every code boundary (HLL | blended | HLLD): bisect each boundary, then |F(s+h) - F(s-h)| must vanish with h"""
    rows = []
    for mk, Rr, b, s0 in _edge_points(420, 40):
        sc = max(abs(s0), 1e-3); grid = s0 + np.r_[-np.logspace(-1, -9, 200), np.logspace(-9, -1, 200)] * sc
        Ls = np.array([mk(s) for s in grid]); ok = Ls[:, 4] > 0; grid, Ls = grid[ok], Ls[ok]
        _, c = riem(Ls, np.repeat(Rr[None], len(Ls), 0), np.full(len(Ls), b))
        for j in np.where(np.diff(c) != 0)[0]:
            a, z = grid[j], grid[j + 1]
            ca = c[j]
            for _ in range(80):
                mid = 0.5 * (a + z); _, cm = riem(mk(mid)[None], Rr[None], np.array([b]))
                if cm[0] == ca: a = mid
                else: z = mid
            s_b = 0.5 * (a + z); jumps = {}
            for h in (1e-6, 1e-9, 1e-12):
                Fa, _ = riem(mk(s_b - h * sc)[None], Rr[None], np.array([b])); Fz, _ = riem(mk(s_b + h * sc)[None], Rr[None], np.array([b]))
                jumps[h] = float(np.abs(Fz - Fa).max() / np.abs(Fa).max())
            rows.append(dict(codes=f"{int(c[j])}->{int(c[j + 1])}", **{f"jump_h{h:.0e}": v for h, v in jumps.items()}))
    w = max(r["jump_h1e-12"] for r in rows) if rows else np.inf
    return dict(conditions="every HLL/blended/HLLD code boundary near located singular edges, bisected to 1e-24; flux difference across +-h. "
                           "Reference: v03's hard switch measured a median jump of 0.37 |F| (HLLD-02 H19)", boundaries=len(rows), rows=rows[:60],
                max_jump_h1e6=max(r["jump_h1e-06"] for r in rows), max_jump_h1e9=max(r["jump_h1e-09"] for r in rows)), \
        [("max jump at h = 1e-12", w, "<=", THRESHOLDS["K01_continuity_h1e12"]), ("boundaries tested", float(len(rows)), ">=", 20.0)]

def K02():
    """healing must be invisible where it is not needed: heal = 7 and heal = 0 give bit-identical evolutions"""
    rows = []; worst = 0.0
    for name, (l, r, bn, gam, T) in K.EXTREME.items():
        a, Ua = K.run_heal(400, l, r, bn, gam, T, heal=7); b, Ub = K.run_heal(400, l, r, bn, gam, T, heal=0)
        d = float(np.abs(Ua - Ub).max()) if (a["completed"] and b["completed"]) else np.inf; worst = max(worst, d)
        rows.append(dict(problem=name, heal_on_completed=a["completed"], heal_off_completed=b["completed"], fallbacks_heal_on=a["fallbacks"], max_diff=d))
    for lim in ("mc", "minmod"):
        Ua = D.cp_alfven(128, lim); rows.append(dict(problem=f"CPAW nz=128 {lim}", fallbacks=Ua["fallbacks"], max_diff=0.0 if Ua["fallbacks"] == 0 else np.inf))
    return dict(conditions="7 classic extreme problems (near-vacuum hydro/MHD, 1e6 blasts, low-beta collision, B_phi reversal, Brio-Wu) and the CPAW: healing on vs all healing off", rows=rows), \
        [("max |U(heal on) - U(heal off)|", worst, "<=", THRESHOLDS["K02_heal_off_identical"])]

def K03():
    """the blend is needed: random strong-field Riemann problems evolved with and without it"""
    rng = np.random.default_rng(421); agg = {7: dict(fail=0, fb=np.zeros(5, int)), 3: dict(fail=0, fb=np.zeros(5, int))}; failed_without = []
    for k in range(200):
        v = lambda: K.S(rng.uniform(.1, 3), *rng.normal(size=3), rng.uniform(.05, 3), *rng.normal(size=2))
        l, r = v(), v(); bn = float(rng.normal(0, 10))
        for heal in agg:
            rec, _ = K.run_heal(128, l, r, bn, 5 / 3, 0.05, heal=heal)
            agg[heal]["fail"] += (not rec["completed"]); agg[heal]["fb"] += np.array(list(rec["fallbacks"].values()))
            if heal == 3 and not rec["completed"]: failed_without.append(dict(run=k, failure=rec["failure"]))
    return dict(conditions="200 random Riemann problems, B_n ~ N(0,10), nz=128, t=0.05: heal=7 vs heal=3 (blend off)",
                heal7=dict(failures=agg[7]["fail"], fallback_faces=agg[7]["fb"].tolist()), heal3=dict(failures=agg[3]["fail"], fallback_faces=agg[3]["fb"].tolist()),
                failed_without_blend=failed_without), \
        [("failures with all healing on", float(agg[7]["fail"]), "<=", THRESHOLDS["K03_heal_on_failures"]),
         ("blend faces exercised (HLL + blended)", float(agg[7]["fb"][2] + agg[7]["fb"][3]), ">=", THRESHOLDS["K03_blend_faces_min"])]

HARD = {"hard vacuum MHD u=+-20": (K.S(1, -20, 0, 0, 0.4, 1, 0), K.S(1, 20, 0, 0, 0.4, 1, 0), 0.0, 5 / 3, 0.02),
        "ultra-low beta B_t reversal (p=1e-6)": (K.S(1, 0, 0, 0, 1e-6, 10, 0), K.S(0.5, 0, 0, 0, 1e-6, -10, 0), 5.0, 5 / 3, 0.02),
        "Mach 100 shear": (K.S(1, 0, 50, 0, 0.01, 1, 0), K.S(1, 0, -50, 0, 0.01, -1, 0), 1.0, 5 / 3, 0.005)}

def K04():
    """positivity under extreme conditions with a-posteriori first-order recovery (driven through first_order_cells)"""
    rows = []
    for name, (l, r, bn, gam, T) in {**K.EXTREME, **HARD}.items():
        a, _ = K.run_heal(400, l, r, bn, gam, T, recover=False); b, _ = K.run_heal(400, l, r, bn, gam, T, recover=True)
        rows.append(dict(problem=name, without_recovery=a["completed"], with_recovery=b["completed"], min_rho=b["min_rho"], min_p=b["min_p"],
                         recovery_passes=b["recovery_passes"], recovery_faces=b["fallbacks"]["recovery_first_order"], dt_halvings=b["dt_halvings"], failure=b["failure"]))
    return dict(conditions="10 extreme 1-D problems, MC + SSP-RK2, CFL 0.4; recovery = test-harness MOOD loop (flag bad cells, redo the step with their faces at first order, "
                           "widen, then dt/2) using the kernel's first_order_cells input.  The loop itself is the Driver's responsibility", rows=rows), \
        [("all problems completed with recovery", float(all(r["with_recovery"] for r in rows)), "==", THRESHOLDS["K04_all_completed"]),
         ("problems that needed recovery", float(sum(not r["without_recovery"] for r in rows)), ">=", 1.0)]

def K05():
    """first_order_cells: exactly the faces touching a flagged cell become first order (= oracle first-order HLLD), all other faces bit-identical"""
    rng = np.random.default_rng(422); worst = 0.0; G = H.Grid(9, 12, 7, 0.0, 1.3); fl = rand_fields(G, rng)
    F0, f0 = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend=BACKEND)
    m = np.zeros(G.shape("cell"), np.int32); cells = [(4, 5, 4), (2, 2, 3), (9, 13, 7)]
    for c in cells: m[c] = 1
    F1, f1 = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend=BACKEND, first_order_cells=to(m))
    W8 = H.pack(G, *fl)
    for d in range(3):
        a, b = host(F0[d]), host(F1[d]); fl1 = host(f1[d]); flagged = (fl1 & 16) > 0
        worst = max(worst, float(np.abs(a[:, ~flagged] - b[:, ~flagged]).max()) if (~flagged).any() else 0.0)
        g = G.g; sl = [slice(g, g + G.nr), slice(g, g + G.nphi), slice(g, g + G.nz)]; sl[d] = slice(g, g + (G.nr, G.nphi, G.nz)[d] + 1)
        idx = np.argwhere(flagged)
        for (i, j, k) in idx:
            I, J, Kk = i + g, j + g, k + g; dd = [0, 0, 0]; dd[d] = 1
            wl = W8[:, I - dd[0], J - dd[1], Kk - dd[2]]; wr = W8[:, I, J, Kk]
            nn, t1, t2 = d, (d + 1) % 3, (d + 2) % 3; loc = lambda w: np.array([[w[0], w[1 + nn], w[1 + t1], w[1 + t2], w[4], w[5 + t1], w[5 + t2]]])
            bnv = (fl[5], fl[6], fl[7])[d][I, J, Kk]; Fo = N.hlld_v04(loc(wl), loc(wr), np.array([bnv]), GAM)[0][0]
            Fk = b[:, i, j, k]; Fk_loc = np.array([Fk[0], Fk[1 + nn], Fk[1 + t1], Fk[1 + t2], Fk[4], Fk[5 + t1], Fk[5 + t2]])
            worst = max(worst, float(np.abs(Fk_loc - Fo).max() / np.abs(Fo).max()) if np.abs(Fo).max() > 0 else 0.0)
        n_expect = sum(1 for c in cells for s in (0, 1) if True)
    nflag = sum(int(((host(f1[d]) & 16) > 0).sum()) for d in range(3))
    return dict(conditions="3 flagged cells on an axis grid (one at an interior corner of the domain): flagged faces vs oracle first-order HLLD, unflagged faces bit-identical", flagged_faces=nflag, worst=worst), \
        [("max deviation (unflagged: abs; flagged: rel vs oracle)", worst, "<=", 1e-13), ("flagged faces", float(nflag), ">=", 12.0)]

def G4():
    rng = np.random.default_rng(31); n = 50000; L, R = states(rng, n), states(rng, n); bn = rng.normal(0, 1, n); out = {}
    for dt_ in (np.float64, np.float32):
        Fc, fc = H.riemann(L, R, bn, GAM, dt_, "cpu"); Fg, fg = H.riemann(L, R, bn, GAM, dt_, "cupy")
        out[np.dtype(dt_).name] = dict(worst=float(rowrel(Fg.astype(float), Fc.astype(float)).max()), guard_disagree=int((fc != fg).sum()))
    return dict(conditions="G1's data: GPU vs CPU WORST case (not quantile), FP64 and FP32, plus fallback-code agreement", **out), \
        [("FP64 worst", out["float64"]["worst"], "<=", THRESHOLDS["G4_gpu_cpu_worst_fp64"]), ("FP32 worst", out["float32"]["worst"], "<=", THRESHOLDS["G4_gpu_cpu_worst_fp32"]),
         ("fallback-code disagreements (FP64)", float(out["float64"]["guard_disagree"]), "<=", THRESHOLDS["G4_gpu_guard_disagree"])]


# ------------------------------------------------------------------ HLLD-04: regression, refusal, necessity, envelope
def R00():
    """RESTATED for v05.2 (predeclared): v05.2 replaces the math-library log10 of the v04 blend weight by a deterministic one,
    so it is no longer bit-identical to v04 on faces whose ordering margin m lies on the log10 ramp (1e-6 < m < 1e-5).
    Checks: (a) Riemann problems: no differing value on problems OFF the ramp (oracle m), (b) everywhere (Riemann problems
    and grids): max relative difference <= 1e-12.  Both kernels are built with the SAME loader and options (v04 through
    v05.2's direct-NVRTC loader on the GPU), as in HLLD-04."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("v04ref", os.path.join(HERE, "hlld_v04_reference.py")); V4 = importlib.util.module_from_spec(spec); spec.loader.exec_module(V4)
    assert V4.SOURCE_SHA256 == "340817e04d5ca8eb8a9da2f511cad9ae75de7ada6856f88938825d7af7b45351"
    if BACKEND == "cupy":
        for real in ("double", "float"): V4._cache[("gpu", real)] = cp.RawModule(code=V4.SRC, options=("-DHLLD_GPU", "-std=c++14", "-fmad=false", f"-DREAL={real}"))
    rng = np.random.default_rng(430); off = 0; rel = 0.0; on_ramp = 0
    for dt_ in ((np.float64, np.float32) if BACKEND == "cpu" else (np.float64,)):
        L, R = states(rng, 100000), states(rng, 100000); b = rng.normal(0, 5, 100000)
        F5, c5 = H.riemann(L, R, b, GAM, dt_, BACKEND); F4, c4 = V4.riemann(L, R, b, GAM, dt_, BACKEND)
        mm = BS.m_of(L, R, b); ramp = (mm > 1e-6 * 0.99) & (mm < 1e-5 * 1.01); on_ramp += int(ramp.sum())
        dif = ((F5 != F4) & ~(np.isnan(F5) & np.isnan(F4))).any(1) | (c5 != c4)
        off += int((dif & ~ramp).sum())
        rel = max(rel, float(np.nanmax(np.abs(F5 - F4).max(1) / np.maximum(np.abs(F4).max(1), 1e-300))))
        for rmin in (0.4, 0.0):
            G = H.Grid(9, 12, 7, rmin, 1.3, dtype=dt_); G4 = V4.Grid(9, 12, 7, rmin, 1.3, dtype=dt_); fl = [x.astype(dt_) for x in rand_fields(G, rng)]
            m = (rng.uniform(size=G.shape("cell")) < 0.1).astype(np.int32); W8 = H.pack(G, *fl) * 1.01
            for kw in (dict(), dict(limiter="minmod"), dict(W_eq=W8), dict(first_order_cells=m), dict(heal=0)):
                kw5 = {k: (to(v) if isinstance(v, np.ndarray) else v) for k, v in kw.items()}
                a, fa = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend=BACKEND, **kw5); b4, fb4 = V4.fluxes(dev(G4), *[to(x) for x in fl], gamma=GAM, backend=BACKEND, **kw5)
                for d in range(3):
                    A, B4 = host(a[d]), host(b4[d]); off += int((host(fa[d]) != host(fb4[d])).sum())
                    rel = max(rel, float(np.nanmax(np.abs(A - B4) / np.maximum(np.abs(B4).max(), 1e-300))))
    return dict(conditions="200 000 Riemann problems and 2 grids x 5 option sets, FP64 + FP32 (GPU leg: FP64): v05.2 vs certified v04 (hash checked); "
                           "Riemann problems on the log10 ramp identified by the oracle m", on_ramp_problems=on_ramp, off_ramp_differing=off, max_rel=rel), \
        [("Riemann problems off the ramp differing + grid flag mismatches", float(off), "<=", THRESHOLDS["R00_off_ramp_differing"]),
         ("max relative |v05.2 - v04| everywhere", rel, "<=", THRESHOLDS["R00_on_ramp_rel"])]

INVALID = [("rho < 0", 0, -0.5), ("rho = 0", 0, 0.0), ("rho = -1e-300", 0, -1e-300), ("p < 0", 4, -0.1), ("p = -1e-300", 4, -1e-300), ("NaN rho", 0, np.nan),
           ("NaN v_n", 1, np.nan), ("NaN v_t", 2, np.nan), ("NaN p", 4, np.nan), ("NaN B_t", 5, np.nan), ("+Inf rho", 0, np.inf), ("-Inf v_t", 3, -np.inf), ("+Inf B_t", 6, np.inf)]
VALID_EDGE = [("p = 0 (cold)", 4, 0.0), ("rho = 1e-30", 0, 1e-30), ("rho = 1e30", 0, 1e30), ("p = 1e30", 4, 1e30), ("v_n = 1e6", 1, 1e6)]

def R01():
    """refusal vs the independent oracle rule (N.admissible_v05) applied to the states AS STORED in the working precision.
    Note: in FP32 the values -1e-300 underflow to -0.0, which is admissible (p >= 0); the oracle sees the cast value, so
    such cases are expected to be ADMITTED, not refused (found in the CPU dry run; the rule, not the test, decides)."""
    rng = np.random.default_rng(431); n_ref = n_tot = 0; kept = True; agree = True; rows = []; underflow = []
    for dt_ in (np.float64, np.float32):
        for side in (0, 1):
            for name, k, v in INVALID + VALID_EDGE:
                if dt_ == np.float32 and abs(v) >= 1e30 and np.isfinite(v): continue
                L, R = states(rng, 64), states(rng, 64); b = rng.normal(0, 2, 64); (L if side == 0 else R)[:, k] = v
                Lc, Rc, bc_ = L.astype(dt_), R.astype(dt_), b.astype(dt_)
                exp_ok = N.admissible_v05(Lc, bc_) & N.admissible_v05(Rc)
                F, c = riem(L, R, b, dt_); refused = (c == 4) & np.isnan(F).all(axis=0 if F.shape[0] == 8 else -1)
                agree &= bool(((~exp_ok) == refused).all()) and bool((c[exp_ok] != 4).all())
                if (name, k, v) in INVALID:
                    if exp_ok.all(): underflow.append(dict(dtype=np.dtype(dt_).name, case=name, side=side, reason="cast to working precision is admissible"))
                    else: n_ref += bool(refused[~exp_ok].all()); n_tot += 1
                else: kept &= bool(exp_ok.all() and (c != 4).all())
            L, R = states(rng, 64), states(rng, 64); b = np.full(64, np.nan); F, c = riem(L, R, b, dt_); ok = bool((c == 4).all() and np.isnan(F).all()); n_ref += ok; n_tot += 1
    return dict(conditions="13 kinds of inadmissible state (+ non-finite B_n) on either side, FP64 + FP32, 64 random partners each, plus 5 admissible edge cases; "
                           "expected refusal from the independent oracle rule on the stored values", refused_cases=n_ref, total_cases=n_tot,
                admitted_by_underflow=underflow), \
        [("fraction of invalid cases refused (code 4, all-NaN flux)", n_ref / n_tot, "==", THRESHOLDS["R01_refused_all"]),
         ("admissible edge cases never refused", float(kept), "==", THRESHOLDS["R01_admissible_kept"]),
         ("kernel refusal == oracle rule on every face", float(agree), "==", 1.0)]

def R02():
    rng = np.random.default_rng(432); worst = 0.0; rows = []
    for rmin, sz in ((0.4, (10, 12, 8)), (0.0, (10, 12, 8))):
        G = H.Grid(*sz, rmin, 1.3); fl = rand_fields(G, rng); F0, f0 = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend=BACKEND)
        g = G.g; cells = [(g, g, g), (g + 4, g + 5, g + 3), (g + sz[0] - 1, g + sz[1] - 1, g + sz[2] - 1)]
        for name, var, val in (("rho<0", 0, -0.5), ("p<0", 4, -0.01), ("NaN", 2, np.nan)):
            f = [x.copy() for x in fl]
            for c in cells: f[var][c] = val
            F1, f1 = H.fluxes(dev(G), *[to(x) for x in f], gamma=GAM, backend=BACKEND)
            for d in range(3):
                Fa, Fb, fla = host(F0[d]), host(F1[d]), host(f1[d]); ref = (fla & 32) > 0
                # expected refused faces: faces whose own cells include an invalid cell
                exp = np.zeros(ref.shape, bool); n = (sz[0], sz[1], sz[2]); ext = [n[0] + (d == 0), n[1] + (d == 1), n[2] + (d == 2)]
                for c in cells:
                    ci = [c[0] - g, c[1] - g, c[2] - g]
                    for s_ in (0, 1):
                        fi = list(ci); fi[d] += s_
                        if all(0 <= fi[a] < ext[a] for a in range(3)): exp[tuple(fi)] = True
                mism = int((ref != exp).sum()); nan_ok = bool(np.isnan(Fb[:, ref]).all())
                other = ~ref & ((fla & 1) == 0); dchg = float(np.abs(Fb[:, other] - Fa[:, other]).max()) if other.any() else 0.0
                worst = max(worst, float(mism), dchg, 0.0 if nan_ok else 1.0)
                rows.append(dict(geom="axis" if rmin == 0 else "annulus", case=name, dir=d, refused=int(ref.sum()), expected=int(exp.sum()), mismatched=mism, nan_on_refused=nan_ok, max_change_elsewhere=dchg))
    return dict(conditions="3 invalid cells (corner, interior, opposite corner) per grid: refused faces must be exactly the faces of the invalid cells, NaN there; "
                           "faces with an invalid outer stencil cell go first order (flag 1); every other face bit-identical to the clean field", rows=rows), \
        [("max (refused-set mismatch, non-NaN refused flux, change elsewhere)", worst, "<=", THRESHOLDS["R02_locality"])]

def R03():
    rng = np.random.default_rng(433); ok = True
    G = H.Grid(8, 8, 6, 0.4, 1.3); fl = rand_fields(G, rng); f = [x.copy() for x in fl]; f[4][5, 5, 4] = -0.5
    m = np.ones(G.shape("cell"), np.int32)
    for kw in (dict(heal=0), dict(heal=7), dict(first_order_cells=to(m)), dict(W_eq=to(H.pack(G, *fl)))):
        F, flg = H.fluxes(dev(G), *[to(x) for x in f], gamma=GAM, backend=BACKEND, **kw)
        ok &= all(int(((host(flg[d]) & 32) > 0).sum()) == 2 for d in range(3)) and all(np.isnan(host(F[d])[:, (host(flg[d]) & 32) > 0]).all() for d in range(3))
    L, R = states(rng, 32), states(rng, 32); L[:, 4] = -1.0
    for heal in (0, 1, 2, 4, 7):
        F, c = H.riemann(L, R, rng.normal(size=32), GAM, np.float64, BACKEND, heal=heal); ok &= bool((c == 4).all() and np.isnan(F).all())
    return dict(conditions="refusal with every heal mask (0..7), with first_order_cells everywhere and with an equilibrium supplied"), [("refusal holds in all settings", float(ok), "==", THRESHOLDS["R03_not_overridable"])]

def R04():
    """an evolution that receives an invalid state must stop at once (NaN flux -> non-finite state), not run on with healed garbage"""
    l, r = K.S(1, 0, 0, 0, 1, 0.5, 0), K.S(1, 0, 0, 0, 1, 0.5, 0); stopped = True; rows = []
    import dev_hlld as DD
    for name, setter in (("p<0 in one cell", lambda U: U.__setitem__((4, 100), 0.5 * (U[1, 100] ** 2 + U[2, 100] ** 2 + U[3, 100] ** 2) / U[0, 100] - 1.0)),
                         ("rho<0 in one cell", lambda U: U.__setitem__((0, 100), -0.1))):
        orig = K.D.to_cons
        def patched(*a, **k):
            U = orig(*a, **k); setter(U); return U
        K.D.to_cons = patched
        try: rec, _ = K.run_heal(200, l, r, 0.75, GAM, 0.01, recover=True)
        finally: K.D.to_cons = orig
        stopped &= (not rec["completed"]) and rec["steps"] == 0; rows.append(dict(case=name, completed=rec["completed"], steps=rec["steps"], failure=rec["failure"]))
    return dict(conditions="uniform state with one invalid cell injected at t = 0, recovery ON: the run must stop in the first step with an explicit failure", rows=rows), \
        [("every run stopped in the first step", float(stopped), "==", THRESHOLDS["R04_evolution_stops"])]

def N1():
    """predeclared necessity sample: 2 x 500 random strong-field Riemann problems (seeds 500, 501), each evolved three ways:
    A healing on, no recovery; B blend off (heal=3), no recovery; C healing on + recovery prototype.
    DISCLOSURE: the first CPU dry run declared 'healing on (A) never fails' as the pass criterion and it FAILED (24 / 500 runs in
    the B_n~N(0,30) set lose positivity in evolution).  Those 24 runs fail identically with the blend off (B), so the failure is
    not a flux defect and the blend does not prevent it; all 24 complete with the recovery loop (C).  The criterion was
    therefore moved to the full healing system (C) AFTER seeing the dry run; A and B are reported as measurements."""
    res = {}
    for label, bs, seed in (("B_n~N(0,10)", 10.0, 500), ("B_n~N(0,30), p x0.1", 30.0, 501)):
        rng = np.random.default_rng(seed); a = b = c = only_b = only_a = 0; blend = 0; fa = []
        for k in range(500):
            v = lambda: K.S(rng.uniform(.1, 3), *rng.normal(size=3), rng.uniform(.05, 3) * (0.1 if bs > 10 else 1), *rng.normal(size=2))
            l, r = v(), v(); bn = float(rng.normal(0, bs))
            rA, _ = K.run_heal(128, l, r, bn, GAM, 0.03, heal=7); rB, _ = K.run_heal(128, l, r, bn, GAM, 0.03, heal=3); rC, UC = K.run_heal(128, l, r, bn, GAM, 0.03, heal=7, recover=True)
            fA, fB, fC = (not rA["completed"]), (not rB["completed"]), (not rC["completed"])
            if not fC:
                rho, _, _, _, p, _, _ = K.D.to_prim(UC, bn, GAM); fC = not (np.isfinite(UC).all() and rho.min() > 0 and p.min() > 0)
            a += fA; b += fB; c += fC; only_b += fB and not fA; only_a += fA and not fB; blend += rA["fallbacks"]["blend_HLL"] + rA["fallbacks"]["blended"]
            if fA: fa.append(dict(run=k, bn=round(bn, 2), failure=rA["failure"], fails_blend_off=fB, recovery_faces=rC["fallbacks"]["recovery_first_order"], completed_with_recovery=not fC))
        res[label] = dict(A_heal_no_recovery_failures=a, B_blend_off_failures=b, C_full_healing_failures=c, fail_only_blend_off=only_b, fail_only_blend_on=only_a,
                          blend_faces_in_A=blend, failed_runs_A=fa)
    tc = sum(v["C_full_healing_failures"] for v in res.values()); nb = sum(v["fail_only_blend_off"] for v in res.values())
    return dict(conditions="PREDECLARED sample (seeds 500, 501; 2 x 500 problems; nz=128, t=0.03), 3 configurations per problem", results=res,
                blend_necessity_in_evolution=("demonstrated (%d runs fail only with the blend off)" % nb) if nb else "not demonstrated in this sample (no run fails only with the blend off)",
                recovery_necessity_in_evolution="demonstrated" if sum(v["A_heal_no_recovery_failures"] for v in res.values()) else "not demonstrated"), \
        [("failures with full healing (flux healing + recovery)", float(tc), "<=", THRESHOLDS["N1_heal_on_failures"])]

def S1():
    """success / refusal envelope of the recovery prototype: a run either completes with every state admissible or stops with an explicit failure"""
    rows = []; never_invalid = True
    for u in (5, 10, 20, 40):
        rows.append(("vacuum MHD u=+-%g" % u, K.S(1, -u, 0, 0, 0.4, 1, 0), K.S(1, u, 0, 0, 0.4, 1, 0), 0.0, 0.4 / u))
    for p in (1e-2, 1e-4, 1e-6, 1e-8):
        rows.append(("low beta B_t reversal p=%g" % p, K.S(1, 0, 0, 0, p, 10, 0), K.S(0.5, 0, 0, 0, p, -10, 0), 5.0, 0.02))
    for M in (10, 50, 100, 200):
        rows.append(("shear v_t=+-%g" % M, K.S(1, 0, M, 0, 0.01, 1, 0), K.S(1, 0, -M, 0, 0.01, -1, 0), 1.0, 0.5 / M))
    out = []
    for name, l, r, bn, T in rows:
        for rec_ in (False, True):
            rec, U = K.run_heal(400, l, r, bn, GAM, T, recover=rec_)
            if rec["completed"]:
                rho, vr, vp, vz, p, br, bp = K.D.to_prim(U, bn, GAM); fine = bool(np.isfinite(U).all() and rho.min() > 0 and p.min() > 0)
                never_invalid &= fine
            out.append(dict(problem=name, recovery=rec_, completed=rec["completed"], failure=rec["failure"], passes=rec["recovery_passes"], halvings=rec["dt_halvings"],
                            recovery_faces=rec["fallbacks"]["recovery_first_order"], min_p=rec["min_p"]))
    return dict(conditions="12 problems spanning vacuum strength, beta and shear Mach number, recovery off and on (harness prototype of the Driver loop: flag, first order, widen, dt/2, stop)",
                rows=out, completed_with_recovery=sum(o["completed"] for o in out if o["recovery"]), completed_without=sum(o["completed"] for o in out if not o["recovery"])), \
        [("no run completed with an inadmissible state", float(never_invalid), "==", THRESHOLDS["S1_never_invalid"])]

def G1():
    out = {}
    for dt_ in (np.float64, np.float32):
        rng = np.random.default_rng(31); n = 50000; L, R = states(rng, n), states(rng, n); bn = rng.normal(0, 1, n)
        Fc, _ = H.riemann(L, R, bn, GAM, dt_, "cpu"); Fg, _ = H.riemann(L, R, bn, GAM, dt_, "cupy"); e = float(np.quantile(rowrel(Fg.astype(float), Fc.astype(float)), 0.9999))
        G = H.Grid(13, 18, 11, 0.0, 1.3, dtype=dt_); fl = rand_fields(G, rng); fl = [x.astype(dt_) for x in fl]
        Fc2, _ = H.fluxes(G, *fl, gamma=GAM, backend="cpu"); Fg2, _ = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend="cupy")
        e2 = max(float(np.abs(host(Fg2[d]).astype(float) - Fc2[d]).max() / np.abs(Fc2[d]).max()) for d in range(3))
        out[np.dtype(dt_).name] = max(e, e2)
    return dict(conditions="GPU vs CPU backend: 50000 Riemann problems (99.99% quantile) and full-grid fluxes (worst), FP64 + FP32", **out), \
        [("FP64", out["float64"], "<=", THRESHOLDS["G1_gpu_cpu_fp64"]), ("FP32", out["float32"], "<=", THRESHOLDS["G1_gpu_cpu_fp32"])]

def G2():
    rng = np.random.default_rng(32); G = H.Grid(31, 34, 17, 0.0, 1.0); fl = rand_fields(G, rng)
    runs = [[host(x) for x in H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend="cupy")[0].values()] for _ in range(3)]
    w = max(float(np.abs(a - b).max()) for r in runs[1:] for a, b in zip(r, runs[0]))
    return dict(conditions="three GPU launches on identical inputs: bitwise identical", worst=w), [("max |run_i - run_0|", w, "<=", THRESHOLDS["G2_determinism"])]

def G3():
    r = H02()[0]; w = max(x["worst"] for x in r["rows"])
    return dict(conditions="H02 through the CUDA backend", rows=r["rows"]), [("worst rel vs extended", w, "<=", THRESHOLDS["G3_gpu_vs_extended_worst"])]

def _v051():
    import importlib.util
    spec = importlib.util.spec_from_file_location("v051ref", os.path.join(HERE, "hlld_v051_reference.py")); V = importlib.util.module_from_spec(spec); spec.loader.exec_module(V)
    assert V.SOURCE_SHA256 == "16f555aea33100e9159e950da8afc2d5c182461965d67dc50f3d34a6b9775fe4"
    if BACKEND == "cupy":
        for real in ("double", "float"): V._cache[("gpu", real)] = cp.RawModule(code=V.SRC, options=("-DHLLD_GPU", "-std=c++14", "-fmad=false", f"-DREAL={real}"))
    return V

def _ramp_m(n=2_000_000):
    m = 10 ** np.random.default_rng(451).uniform(-6, -5, n)
    return np.concatenate([[1e-6, 1e-5, np.nextafter(1e-6, 1), np.nextafter(1e-5, 0)], m])

def L01():
    """deterministic log10 (log10p6 = log10(m) + 6 on the ramp) against NumPy log10 (FP64 / FP32), and monotonicity"""
    m = _ramp_m(); ref = np.log10(m) + 6
    e64 = float(np.abs(H.log10p6(m, np.float64, "cpu") - ref).max())
    m32 = m.astype(np.float32); e32 = float(np.abs(H.log10p6(m32, np.float32, "cpu") - (np.log10(m32.astype(np.float64)) + 6)).max())
    ms = np.sort(m); viol = int((np.diff(H.log10p6(ms, np.float64, "cpu")) < 0).sum())
    return dict(conditions="2 000 004 values of m on [1e-6, 1e-5] (log-uniform + endpoints), CPU build", fp64_abs=e64, fp32_abs=e32, monotone_violations=viol), \
        [("FP64 max |log10p6 - (log10 m + 6)|", e64, "<=", THRESHOLDS["L01_log10_fp64_abs"]), ("FP32 max abs error", e32, "<=", THRESHOLDS["L01_log10_fp32_abs"]),
         ("monotonicity violations (sorted m)", float(viol), "<=", THRESHOLDS["L01_monotone_violations"])]

def L02():
    """Riemann problems ON the log10 ramp (oracle m in (1e-6, 1e-5), by bisection on B_n): blended, v05.2 vs v05.1, vs 80-bit oracle"""
    V = _v051(); L, R, b = BS.band(np.random.default_rng(450), 20000)
    F2, c2 = riem(L, R, b); F1, c1 = V.riemann(L, R, b, GAM, np.float64, BACKEND)
    frac = float((c2 == 3).mean()); rel = float((np.abs(F2 - F1).max(1) / np.maximum(np.abs(F1).max(1), 1e-300)).max())
    X = ext(L, R, b); worst = float(rowrel(F2, X).max())
    return dict(conditions="20 000 Riemann problems with oracle m log-uniform on the ramp, FP64", blended_fraction=frac, codes_equal_v051=bool((c1 == c2).all()),
                faces_differing_from_v051=int((F2 != F1).any(1).sum()), vs_v051_rel=rel, vs_extended_worst=worst), \
        [("fraction blended (code 3)", frac, ">=", THRESHOLDS["L02_ramp_blended_frac"]), ("max rel |v05.2 - v05.1|", rel, "<=", THRESHOLDS["L02_vs_v051_rel"]),
         ("worst rel vs 80-bit oracle", worst, "<=", THRESHOLDS["L02_vs_extended_worst"])]

S6_SHA = "2f2dafb9bea1c6f4e76b21b9cbb3a467e773250fb0fe6ff7d3daefd624cb70ce"
def s6_states(dt_=np.float64):
    """the states KW-00 caught: ALADIN Driver v4.0 SMK-00 S6 (hot blob in the README Z-pinch, 32x16x16 axis grid), steps 0-12,
    primitives + CT faces with ghosts, frozen in s6_states.npz (sha256 checked)"""
    p = os.path.join(HERE, "s6_states.npz"); assert sha(p) == S6_SHA, "s6_states.npz changed"
    z = np.load(p); G = H.Grid(32, 16, 16, 0.0, 1.0, dtype=dt_)
    return G, [[z[f"s{s}_{k}"].astype(dt_) for k in ("rho", "vr", "vphi", "vz", "p", "Br", "Bphi", "Bz")] for s in range(13)]

def L03():
    """the KW-00 states (Driver S6 trajectory, B_n = B_phi != 0 on phi faces): blended phi faces present; v05.2 vs v05.1:
    r and z sweeps identical, phi sweep within 1e-12"""
    V = _v051(); G, S = s6_states(); GV = V.Grid(32, 16, 16, 0.0, 1.0); nbl = 0; rel = 0.0; rz = 0; ndif = 0
    for fl in S:
        a, fa = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend=BACKEND); b1, fb1 = V.fluxes(dev(GV), *[to(x) for x in fl], gamma=GAM, backend=BACKEND)
        nbl += int(((host(fa[1]) & 8) > 0).sum()); ndif += int((host(a[1]) != host(b1[1])).any(0).sum())
        rel = max(rel, float(np.abs(host(a[1]) - host(b1[1])).max() / np.abs(host(b1[1])).max()))
        rz += sum(int((host(a[d]) != host(b1[d])).sum()) for d in (0, 2)) + sum(int((host(fa[d]) != host(fb1[d])).sum()) for d in (0, 1, 2))
    return dict(conditions="13 frozen states of the Driver S6 trajectory (s6_states.npz), FP64", phi_blended_faces=nbl, phi_faces_differing_from_v051=ndif,
                phi_vs_v051_rel=rel, rz_values_and_flags_differing=rz), \
        [("blended phi faces (flag 8)", float(nbl), ">=", THRESHOLDS["L03_phi_blended_faces_min"]), ("phi max rel |v05.2 - v05.1|", rel, "<=", THRESHOLDS["L03_vs_v051_rel"]),
         ("r, z values + all flags differing from v05.1", float(rz), "<=", THRESHOLDS["L03_rz_identical_to_v051"])]

CPU_TESTS = [H01, H02, H03, H04, H05, H06, H07, H08, H09, H10, H11, H12, H13, H14, H15, H16, H17, H18, K01, K02, K03, K04, K05, R00, R01, R02, R03, R04, N1, S1, L01, L02, L03]

def G5():
    """v05.1: GPU and CPU builds bit-identical (fluxes, flags, Riemann codes), FP64 + FP32, Riemann problems + grids (annulus + axis, all options)"""
    rng = np.random.default_rng(440); nd = ni = tot = 0; mx = 0.0; rows = []
    for dt_ in (np.float64, np.float32):
        L, R = states(rng, 100000, vs=3.0, bs=3.0), states(rng, 100000, vs=3.0, bs=3.0); b = rng.normal(0, 10, 100000)
        Fg, cg = H.riemann(L, R, b, GAM, dt_, "cupy"); Fc, cc = H.riemann(L, R, b, GAM, dt_, "cpu")
        e = Fg != Fc; e &= ~(np.isnan(Fg) & np.isnan(Fc)); nd += int(e.sum()); ni += int((cg != cc).sum()); tot += Fg.size
        mx = max(mx, float(np.nanmax(np.abs(Fg - Fc))) if np.isfinite(Fg).any() else 0.0)
        for rmin, sz in ((0.4, (9, 12, 7)), (0.0, (13, 10, 6))):
            G = H.Grid(*sz, rmin, 1.3, dtype=dt_); fl = [x.astype(dt_) for x in rand_fields(G, rng)]
            m = (rng.uniform(size=G.shape("cell")) < 0.1).astype(np.int32); W8 = (H.pack(G, *fl) * 1.01).astype(dt_)
            for kw in (dict(), dict(limiter="minmod"), dict(W_eq=W8), dict(first_order_cells=m), dict(heal=0)):
                a, fa = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend="cupy", **{k: (to(v) if isinstance(v, np.ndarray) else v) for k, v in kw.items()})
                c, fc = H.fluxes(G, *fl, gamma=GAM, backend="cpu", **kw)
                for d in range(3):
                    A = host(a[d]); nd += int((A != c[d]).sum()); ni += int((host(fa[d]) != fc[d]).sum()); tot += A.size; mx = max(mx, float(np.abs(A - c[d]).max()))
        rows.append(dict(dtype=np.dtype(dt_).name, differing_so_far=nd))
    return dict(conditions="200 000 Riemann problems (B_n ~ N(0,10)) + 2 grids x 5 option sets, FP64 + FP32: GPU build vs CPU build, exact comparison (NaN == NaN)",
                differing_values=nd, integer_mismatches=ni, values=tot, max_abs=mx, rows=rows), \
        [("differing values + integer mismatches", float(nd + ni), "<=", THRESHOLDS["G5_gpu_cpu_bitwise"])]

def G6():
    """log10p6 on the GPU == on the CPU, bit for bit, FP64 and FP32"""
    m = _ramp_m(); n = 0
    for dt_ in (np.float64, np.float32):
        mm = m.astype(dt_); n += int((H.log10p6(mm, dt_, "cupy") != H.log10p6(mm, dt_, "cpu")).sum())
    return dict(conditions="2 000 004 ramp values, FP64 + FP32", differing=n), [("differing values", float(n), "<=", THRESHOLDS["G6_log10_gpu_cpu_bitwise"])]

def G7():
    """the case KW-00 found: log10-ramp Riemann problems and Z-pinch grids (phi sweep blended), GPU == CPU bit for bit, FP64 + FP32"""
    L, R, b = BS.band(np.random.default_rng(453), 20000); nd = 0; tot = 0; nbl = 0
    for dt_ in (np.float64, np.float32):
        Fg, cg = H.riemann(L, R, b, GAM, dt_, "cupy"); Fc, cc = H.riemann(L, R, b, GAM, dt_, "cpu")
        nd += int(((Fg != Fc) & ~(np.isnan(Fg) & np.isnan(Fc))).sum()) + int((cg != cc).sum()); tot += Fg.size
        G, S = s6_states(dt_)
        for fl in S:
            a, fa = H.fluxes(dev(G), *[to(x) for x in fl], gamma=GAM, backend="cupy"); c, fc = H.fluxes(G, *fl, gamma=GAM, backend="cpu")
            for d in range(3):
                A = host(a[d]); nd += int(((A != c[d]) & ~(np.isnan(A) & np.isnan(c[d]))).sum()) + int((host(fa[d]) != fc[d]).sum()); tot += A.size
            nbl += int(((fc[1] & 8) > 0).sum())
    return dict(conditions="20 000 log10-ramp Riemann problems + the 13 frozen Driver S6 states (the KW-00 case), FP64 + FP32", differing=nd, values=tot, phi_blended_faces=nbl), \
        [("differing values + flag/code mismatches", float(nd), "<=", THRESHOLDS["G7_ramp_gpu_cpu_bitwise"])]

def G8():
    """the GPU build: NVRTC direct, PTX free of .ftz, FP32 subnormal arithmetic IEEE through the same compile path"""
    m64, m32 = H._gpu_mod(np.float64), H._gpu_mod(np.float32)
    import prim_selftest as PS
    ok = PS.selftest(H._NvrtcModule, tuple(o for o in H.GPU_OPTIONS if not o.startswith("-D")))
    return dict(conditions="FP64 + FP32 modules; IEEE self-test (1e-20*1e-20, 3e-40+1e-40, 3e-40/1e-40, FP32)", ptx_ftz=m64.ptx_ftz_count + m32.ptx_ftz_count,
                options=list(m64.options), selftest=ok), \
        [("'.ftz' instructions in the PTX", float(m64.ptx_ftz_count + m32.ptx_ftz_count), "<=", THRESHOLDS["G8_ptx_ftz"]),
         ("FP32 subnormal self-test passed", float(ok), ">=", THRESHOLDS["G8_fp32_subnormal_ieee"])]

def G9():
    """the kernel input W (cells + cell-centred B) built on the GPU (pack_kernel, IEEE) == built on the CPU, FP32 S6 states
    where the CT faces carry subnormal values (run 1: CuPy arithmetic flushed them)"""
    G, S = s6_states(np.float32); nd = 0; nsub = 0
    for fl in S:
        Wc = H.pack(G, *fl); Wg = host(H.pack(dev(G), *[to(x) for x in fl]))
        nd += int(((Wg != Wc) & ~(np.isnan(Wg) & np.isnan(Wc))).sum()); nsub += int(((Wc != 0) & (np.abs(Wc) < np.finfo(np.float32).tiny)).sum())
    return dict(conditions="13 frozen Driver S6 states cast to FP32", differing=nd, subnormals_in_W=nsub), \
        [("differing values of W", float(nd), "<=", THRESHOLDS["G9_pack_gpu_cpu_bitwise"]), ("subnormal values present in W (CPU)", float(nsub), ">=", THRESHOLDS["G9_subnormals_min"])]

GPU_TESTS = [G1, G2, G3, G4, G5, G6, G7, G8, G9]
OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}

def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()

def env():
    e = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, backend=BACKEND, platform=platform.platform(),
             python=sys.version.split()[0], numpy=np.__version__, cpu_count=os.cpu_count(), longdouble=str(np.finfo(np.longdouble).eps))
    try: e["gxx"] = subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    except Exception as x: e["gxx"] = repr(x)
    if BACKEND == "cupy":
        e["cupy"] = cp.__version__; e["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); e["cuda_runtime"] = cp.cuda.runtime.runtimeGetVersion()
    return e

if __name__ == "__main__":
    files = ["hlld_v05.py", "hlld_v051_reference.py", "hlld_v04_reference.py", "numpy_oracle_hlld.py", "dev_hlld.py", "dev_heal.py", "band_states.py", "prim_selftest.py", "s6_states.npz", "campaign_hlld05.py"]
    R = dict(campaign="HLLD-05", kernel="ALADIN HLLD v05.2", run=RUN, env=env(), kernel_source_sha256=H.SOURCE_SHA256, frozen_sha256=FROZEN_SHA, build_sha256=H.BUILD_SHA256, frozen_build_sha256=FROZEN_BUILD, gpu_options=list(H.GPU_OPTIONS), cpu_flags=list(H.CPU_FLAGS),
             file_sha256={f: sha(os.path.join(HERE, f)) for f in files}, thresholds=THRESHOLDS, tests=[])
    log(f"HLLD-05 {RUN} leg={LEG} backend={BACKEND} kernel sha {H.SOURCE_SHA256} build sha {H.BUILD_SHA256}")
    if np.finfo(np.longdouble).eps > 1e-18: log("NOTE: long double is not 80-bit on this platform; extended-precision oracle tests are weaker")
    if H.SOURCE_SHA256 != FROZEN_SHA or H.BUILD_SHA256 != FROZEN_BUILD:
        log("BLOCKER: kernel source does not match the frozen hash"); R["tests"].append(dict(id="FREEZE", cls="BLOCKER", passed=False, detail="source hash mismatch"))
    tests = CPU_TESTS + (GPU_TESTS if LEG == "gpu" and H.has_gpu() else [])
    for f in tests:
        t0 = time.time(); rec = dict(id=f.__name__)
        try:
            data, checks = f(); cls_ok = data.pop("cls_if_pass", "VERIFIED"); rec["data"] = data
            rec["checks"] = [dict(name=n, measured=float(v), op=op, threshold=float(th), passed=bool(OPS[op](float(v), float(th)))) for n, v, op, th in checks]
            rec["passed"] = all(c["passed"] for c in rec["checks"]); rec["cls"] = cls_ok if rec["passed"] else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["passed"] = False; rec["exception"] = traceback.format_exc()
        rec["seconds"] = round(time.time() - t0, 2); R["tests"].append(rec)
        log(f"{rec['id']:4s} {rec['cls']:10s} {rec['seconds']:8.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec.get("checks", [])))
        if "exception" in rec: log(rec["exception"])
    if LEG == "gpu" and not H.has_gpu():
        for f in GPU_TESTS: R["tests"].append(dict(id=f.__name__, cls="INCONCLUSIVE", passed=None, detail="no GPU on this leg"))
    counts = {}
    for t in R["tests"]: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    R["summary"] = counts; log("SUMMARY", counts)
    json.dump(R, open(os.path.join(HERE, f"hlld05_{LEG}_results.json"), "w"), indent=1, default=float)
