# -*- coding: utf-8 -*-
"""HLLD-03 healing harness: 1-D (z) TEST-ONLY conservative update with per-mechanism fallback counting, positivity
monitoring at every stage, and the kernel's healing switches.  Not a Driver kernel."""
import sys, os, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import hlld_v05 as H
import dev_hlld as D
BACKEND = "cpu"
MAX_PASSES = 3

def run_heal(nz, left, right, bn, gam, T, heal=7, cfl=0.4, limiter="mc", dtype=np.float64, backend=None, recover=False):
    """left/right: dict rho, vn, vt1, vt2, p, bt1, bt2 (local z frame: vn = v_z, t1 = r, t2 = phi).  Returns a record.
    recover=True: a-posteriori first-order recovery (MOOD-style) using the kernel's first_order_cells input: after each
    provisional stage, cells with rho <= 0, p <= 0 or non-finite values are flagged and the faces touching them are
    recomputed at first order (up to 3 passes, widening to neighbours)."""
    backend = backend or BACKEND
    G = D.grid1d(nz, dtype=dtype); g = G.g; z = G.z_c[g:g + nz] - 0.5; L = z < 0
    W = {k: np.where(L, left[k], right[k]).astype(float) for k in left}
    U = D.to_cons(W["rho"], W["vt1"], W["vt2"], W["vn"], W["p"], W["bt1"], W["bt2"], bn, gam)
    U0 = U.copy(); counts = {1: 0, 2: 0, 4: 0, 8: 0, 16: 0}; passes = 0; halvings = 0; minrho = np.inf; minp = np.inf; t = 0.0; steps = 0; failure = None
    def fill(a): return np.concatenate([np.repeat(a[..., :1], g, -1), a, np.repeat(a[..., -1:], g, -1)], axis=-1)
    def rhs(U, cellmask=None):
        rho, vr, vp, vz, p, br, bp = (fill(x) for x in D.to_prim(U, bn, gam))
        sh = G.shape("cell"); c3 = lambda x: np.ascontiguousarray(np.broadcast_to(x[None, None, :], sh), dtype=dtype)
        Br = np.ascontiguousarray(np.broadcast_to(br[None, None, :], G.shape("Br")), dtype=dtype)
        Bp = np.ascontiguousarray(np.broadcast_to(bp[None, None, :], G.shape("Bphi")), dtype=dtype); Bz = np.full(G.shape("Bz"), bn, dtype)
        args = [c3(x) for x in (rho, vr, vp, vz, p)] + [Br, Bp, Bz]; Gk = G
        if backend == "cupy":
            import cupy as cp, copy as _c
            args = [cp.asarray(a) for a in args]; Gk = _c.copy(G); Gk.xp = cp
        fom = None
        if cellmask is not None:
            fom = np.zeros(G.shape("cell"), np.int32); fom[:, :, g:g + nz] = cellmask[None, None, :]
            if backend == "cupy":
                import cupy as cp; fom = cp.asarray(fom)
        F, fl = H.fluxes(Gk, *args, gamma=gam, limiter=limiter, backend=backend, directions=(2,), heal=heal, first_order_cells=fom)
        Fz = F[2].get() if hasattr(F[2], "get") else F[2]; f = fl[2].get() if hasattr(fl[2], "get") else fl[2]
        Fz = Fz[:, 0, 0, :]; f = f[0, 0, :]
        for b in counts: counts[b] += int(((f & b) > 0).sum())
        return -(Fz[[0, 1, 2, 3, 4, 5, 6], 1:] - Fz[[0, 1, 2, 3, 4, 5, 6], :-1]) / G.dz
    def check(U, where):
        nonlocal minrho, minp, failure
        rho, vr, vp, vz, p, br, bp = D.to_prim(U, bn, gam)
        if not np.isfinite(U).all(): failure = failure or f"non-finite at {where}"; return False
        minrho = min(minrho, float(rho.min())); minp = min(minp, float(p.min()))
        if rho.min() <= 0 or p.min() <= 0: failure = failure or f"non-positive at {where}"; return False
        return True
    with np.errstate(all="ignore"):
        while t < T - 1e-14:
            rho, vr, vp, vz, p, br, bp = D.to_prim(U, bn, gam)
            cf = np.sqrt((gam * p + br ** 2 + bp ** 2 + bn ** 2) / rho); dt = min(cfl * G.dz / float(np.max(np.abs(vz) + cf)), T - t)
            if not np.isfinite(dt) or dt <= 0: failure = failure or f"bad dt at step {steps}"; break
            def bad_cells(V):
                r_, _, _, _, p_, _, _ = D.to_prim(V, bn, gam); return ~(np.isfinite(V).all(0) & (r_ > 0) & (p_ > 0))
            # step-level a-posteriori recovery (MOOD): redo the WHOLE step from U^n with the flagged cells at first order;
            # if that is not enough, reject the step and retry with dt/2 (time-step control, the Driver's job)
            ok_step = False
            for halving in range(6 if recover else 1):
                m = np.zeros(nz, bool); Un = None
                for it in range(MAX_PASSES if recover else 1):
                    mk_ = m.astype(np.int32) if m.any() else None
                    U1 = U + dt * rhs(U, mk_)
                    bad1 = bad_cells(U1)
                    Un = 0.5 * (U + U1 + dt * rhs(U1, mk_)) if not bad1.any() else U1
                    b = bad1 | bad_cells(Un)
                    if not b.any(): ok_step = True; break
                    if not recover: break
                    passes += 1; m |= b
                    if it > 0: m |= np.r_[m[1:], False] | np.r_[False, m[:-1]]
                if ok_step or not recover: break
                dt *= 0.5; halvings += 1
            if not check(U1, f"step {steps} stage 1"): break
            U = Un; t += dt; steps += 1
            if not check(U, f"step {steps}"): break
    return dict(nz=nz, heal=heal, steps=steps, completed=failure is None, failure=failure, min_rho=minrho, min_p=minp,
                fallbacks={"first_order": counts[1], "numerical_HLL": counts[2], "blend_HLL": counts[4], "blended": counts[8], "recovery_first_order": counts[16]},
                recovery_passes=passes, dt_halvings=halvings,
                mass_change=float(abs(U[0].sum() - U0[0].sum()) * G.dz) if failure is None else None), U

S = lambda rho, vn, vt1, vt2, p, bt1, bt2: dict(rho=rho, vn=vn, vt1=vt1, vt2=vt2, p=p, bt1=bt1, bt2=bt2)
EXTREME = {
    "near_vacuum_hydro (Toro 123)": (S(1, -2, 0, 0, 0.4, 0, 0), S(1, 2, 0, 0, 0.4, 0, 0), 0.0, 1.4, 0.15),
    "near_vacuum_MHD": (S(1, -3, 0, 0, 0.45, 0.5, 0), S(1, 3, 0, 0, 0.45, 0.5, 0), 0.0, 5 / 3, 0.1),
    "blast_hydro (p 1e6:1)": (S(1, 0, 0, 0, 1000, 0, 0), S(1, 0, 0, 0, 0.001, 0, 0), 0.0, 1.4, 0.012),
    "blast_MHD (p 1e6:1)": (S(1, 0, 0, 0, 1000, 1, 0), S(1, 0, 0, 0, 0.001, 1, 0), 0.75, 5 / 3, 0.01),
    "low_beta_colliding": (S(1, 5, 0, 0, 0.01, 10, 0), S(1, -5, 0, 0, 0.01, 10, 0), 1.0, 5 / 3, 0.05),
    "Z-pinch-like B_phi reversal": (S(1, 0, 0, 0, 0.1, 0, 10), S(0.2, 0, 0, 0, 0.1, 0, -10), 0.1, 5 / 3, 0.02),
    "Brio-Wu": (S(1, 0, 0, 0, 1, 1, 0), S(0.125, 0, 0, 0, 0.1, -1, 0), 0.75, 2.0, 0.1),
}
