# -*- coding: utf-8 -*-
"""HLLD-05 sanitizer target (v05.2): the HLLD-04 workload + the log10p6 kernel + the frozen Driver S6 states (blended phi faces). Formerly: HLLD-04 sanitizer target (v05): everything of the HLLD-03 target plus the REFUSAL paths (invalid cells on grids: own-stencil
refusal and outer-stencil first order; invalid Riemann states incl. NaN / Inf / non-finite B_n).
python sanitizer_target_hlld04.py [cpu]   (cpu = dry run of the same workload with the CPU backend)
GPU workload for compute-sanitizer (memcheck / racecheck): HLLD v03 flux kernels (3 directions, MC/minmod, with and
without equilibrium and exact equilibrium faces) and the single-interface kernel; FP64 + FP32; annulus + axis; partial blocks."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hlld_v05 as H
BK = "cpu" if (len(sys.argv) > 1 and sys.argv[1] == "cpu") else "cupy"
if BK == "cupy":
    import cupy as cp
else:
    cp = np
    class _D:
        @staticmethod
        def synchronize(): pass
    np.cuda = type("c", (), {"Device": lambda *a: _D()})
rng = np.random.default_rng(5)
for dt_ in (np.float64, np.float32):
    for rmin, s in ((0.4, (7, 10, 5)), (0.0, (13, 18, 11)), (0.0, (1, 4, 2)), (0.4, (31, 6, 9)), (0.4, (40, 33, 17))):
        G = H.Grid(*s, rmin, 1.3, dtype=dt_, xp=cp) if BK == 'cupy' else H.Grid(*s, rmin, 1.3, dtype=dt_); sh = G.shape("cell")
        rho = cp.asarray(rng.uniform(0.5, 2, sh).astype(dt_)); p = cp.asarray(rng.uniform(0.5, 2, sh).astype(dt_))
        v = [cp.asarray(rng.normal(size=sh).astype(dt_)) for _ in range(3)]
        B = [cp.asarray(rng.normal(size=G.shape(k)).astype(dt_)) for k in ("Br", "Bphi", "Bz")]
        for lim in ("mc", "minmod"):
            F, fl = H.fluxes(G, rho, *v, p, *B, limiter=lim, backend=BK)
        W = H.pack(G, rho, *v, p, *B); Wf = {d: cp.asarray(rng.uniform(0.5, 1.5, G.shape(("F_r", "F_phi", "F_z")[d])).astype(dt_)) for d in range(3)}
        F2, _ = H.fluxes(G, rho, *v, p, *B, W_eq=W * 1.01, W_eq_faces=Wf, backend=BK)
        msk = cp.asarray((rng.uniform(size=sh) < 0.1).astype(np.int32))
        for heal in (0, 3, 7):
            F3, _ = H.fluxes(G, rho, *v, p, *B, backend=BK, heal=heal, first_order_cells=msk)
        n = 1000; L = np.column_stack([rng.uniform(.1, 3, n), *rng.normal(size=(3, n)), rng.uniform(.1, 3, n), *rng.normal(size=(2, n))])
        Fr, fb = H.riemann(L, L[::-1].copy(), rng.normal(size=n), dtype=dt_, backend=BK)
        # guard path (addendum fix): 20000 independent L, R with B_n ~ N(0,10) -> ~0.4 % guard faces (checked on CPU: 93 / 73 hits)
        m = 20000; LL = np.column_stack([rng.uniform(.1, 3, m), *rng.normal(size=(3, m)), rng.uniform(.05, 3, m), *rng.normal(size=(2, m))])
        RR = np.column_stack([rng.uniform(.1, 3, m), *rng.normal(size=(3, m)), rng.uniform(.05, 3, m), *rng.normal(size=(2, m))])
        Fs, fs = H.riemann(LL, RR, rng.normal(0, 10, size=m), dtype=dt_, backend=BK)
        print("   blend faces exercised (HLL, blended):", int((fs == 2).sum()), int((fs == 3).sum()), flush=True)
        cp.cuda.Device().synchronize()
        print(np.dtype(dt_).name, rmin, s, "finite", bool(all(bool(np.isfinite(x.get() if hasattr(x, 'get') else x).all()) for x in list(F.values()) + list(F2.values()))) and bool(np.isfinite(Fr).all()), flush=True)
bs = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), "blend_states.npz"))
for dt_ in (np.float64, np.float32):
    Fb, cb = H.riemann(bs["L"], bs["R"], bs["bn"], dtype=dt_, backend=BK)
    print(np.dtype(dt_).name, "stored blend states: blended faces exercised", int((cb == 3).sum()), "finite", bool(np.isfinite(Fb).all()), flush=True)
# ---- refusal paths (v05)
nref = 0
for dt_ in (np.float64, np.float32):
    for rmin, s in ((0.4, (9, 10, 7)), (0.0, (13, 18, 11))):
        G = H.Grid(*s, rmin, 1.3, dtype=dt_, xp=cp) if BK == 'cupy' else H.Grid(*s, rmin, 1.3, dtype=dt_); sh = G.shape("cell")
        rho = rng.uniform(0.5, 2, sh).astype(dt_); p = rng.uniform(0.5, 2, sh).astype(dt_); v = [rng.normal(size=sh).astype(dt_) for _ in range(3)]
        bad = rng.uniform(size=sh) < 0.03; rho[bad & (rng.uniform(size=sh) < 0.3)] = -0.5; p[bad & (rng.uniform(size=sh) < 0.5)] = -0.1; v[1][bad & (rng.uniform(size=sh) < 0.3)] = np.nan
        B = [cp.asarray(rng.normal(size=G.shape(k)).astype(dt_)) for k in ("Br", "Bphi", "Bz")]
        for heal in (0, 7):
            F, fl = H.fluxes(G, cp.asarray(rho), *[cp.asarray(x) for x in v], cp.asarray(p), *B, backend=BK, heal=heal)
            for d in range(3):
                f = fl[d].get() if hasattr(fl[d], "get") else fl[d]; Fd = F[d].get() if hasattr(F[d], "get") else F[d]; r = (f & 32) > 0
                nref += int(r.sum()); assert r.any() and np.isnan(Fd[:, r]).all() and np.isfinite(Fd[:, ~r]).all()
    n = 4000; L = np.column_stack([rng.uniform(.1, 3, n), *rng.normal(size=(3, n)), rng.uniform(.1, 3, n), *rng.normal(size=(2, n))]); R = L[::-1].copy()
    k = rng.integers(0, 7, n); sel = rng.uniform(size=n) < 0.25; vals = np.array([-1.0, np.nan, np.inf, -np.inf])[rng.integers(0, 4, n)]
    L[sel, k[sel]] = vals[sel]; bn = rng.normal(size=n); bn[rng.uniform(size=n) < 0.02] = np.nan
    Fr, cr = H.riemann(L, R, bn, dtype=dt_, backend=BK); nref += int((cr == 4).sum()); assert (cr == 4).any()
    print(np.dtype(dt_).name, "refusal paths exercised: refused Riemann faces", int((cr == 4).sum()), flush=True)
print("refused faces total", nref)
print("SANITIZER TARGET DONE")
# HLLD-05 additions: the deterministic log10 kernel and the KW-00 states (phi faces blended)
for dt_ in (np.float64, np.float32):
    mm = (10 ** rng.uniform(-6, -5, 1000)).astype(dt_)
    H.log10p6(mm, dt_, BK)
    z = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), "s6_states.npz"))
    G = H.Grid(32, 16, 16, 0.0, 1.0, dtype=dt_, xp=cp) if BK == 'cupy' else H.Grid(32, 16, 16, 0.0, 1.0, dtype=dt_)
    for s in (2, 4, 11):
        fl = [cp.asarray(z[f"s{s}_{k}"].astype(dt_)) for k in ("rho", "vr", "vphi", "vz", "p", "Br", "Bphi", "Bz")]
        F, fl_ = H.fluxes(G, *fl, backend=BK)
np.cuda.Device().synchronize() if BK == "cpu" else cp.cuda.Device().synchronize()
print("HLLD-05 sanitizer workload done")
