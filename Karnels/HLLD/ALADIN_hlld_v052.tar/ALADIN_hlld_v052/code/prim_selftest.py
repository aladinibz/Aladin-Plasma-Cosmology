# -*- coding: utf-8 -*-
"""IEEE FP32 subnormal self-test through a given NVRTC loader (same test as prim_v01.gpu_ieee_selftest)."""
import numpy as np

def selftest(Loader, options):
    import cupy as cp
    src = 'extern "C" __global__ void k(const float* a, const float* b, float* m, float* s, float* d, int n)' \
          '{ int i = blockIdx.x * blockDim.x + threadIdx.x; if (i < n) { m[i] = a[i] * b[i]; s[i] = a[i] + b[i]; d[i] = a[i] / b[i]; } }'
    mod = Loader(src, options)
    a = np.array([1e-20, 3e-40, 1e-44, 1e-30], np.float32); b = np.array([1e-20, 1e-40, 1.0, 1e-10], np.float32)
    A, B = cp.asarray(a), cp.asarray(b); M, S, D = (cp.empty(4, np.float32) for _ in range(3))
    mod.get_function("k")((1,), (32,), (A, B, M, S, D, np.int32(4))); cp.cuda.Device().synchronize()
    return bool(np.array_equal(M.get().view(np.uint32), (a * b).view(np.uint32)) and np.array_equal(S.get().view(np.uint32), (a + b).view(np.uint32))
                and np.array_equal(D.get().view(np.uint32), (a / b).view(np.uint32)))
