# -*- coding: utf-8 -*-
"""Dynamic tests for hlld_v02 through a minimal TEST-ONLY 1-D conservative update along z (the z direction carries no
geometric terms, so a z-only problem is exact planar MHD).  The update is test scaffolding, not a Driver kernel."""
import sys, os, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import hlld_v05 as H

BACKEND = "cpu"


def grid1d(nz, zlen=1.0, dtype=np.float64):
    return H.Grid(1, 4, nz, 1.0, 1.1, zlen=zlen, dtype=dtype)


def to_cons(rho, vr, vp, vz, p, br, bp, bz, gam):
    E = p / (gam - 1) + 0.5 * rho * (vr ** 2 + vp ** 2 + vz ** 2) + 0.5 * (br ** 2 + bp ** 2 + bz ** 2)
    return np.array([rho, rho * vr, rho * vp, rho * vz, E, br, bp])


def to_prim(U, bz, gam):
    rho, mr, mp, mz, E, br, bp = U
    vr, vp, vz = mr / rho, mp / rho, mz / rho
    p = (gam - 1) * (E - 0.5 * rho * (vr ** 2 + vp ** 2 + vz ** 2) - 0.5 * (br ** 2 + bp ** 2 + bz ** 2))
    return rho, vr, vp, vz, p, br, bp


def run1d(G, U, bz, gam, T, cfl=0.4, bc="periodic", limiter="mc", backend=None):
    """U (7, nz) conserved (rho, m_r, m_phi, m_z, E, B_r, B_phi); B_z = bz constant (face).  SSP-RK2."""
    backend = backend or BACKEND; g, nz = G.g, G.nz; dt_ = G.dtype
    def fill(a):
        if bc == "periodic": return np.concatenate([a[..., -g:], a, a[..., :g]], axis=-1)
        return np.concatenate([np.repeat(a[..., :1], g, -1), a, np.repeat(a[..., -1:], g, -1)], axis=-1)
    def rhs(U):
        rho, vr, vp, vz, p, br, bp = (fill(x) for x in to_prim(U, bz, gam))
        sh = G.shape("cell"); bc3 = lambda x: np.ascontiguousarray(np.broadcast_to(x[None, None, :], sh), dtype=dt_)
        Br = np.ascontiguousarray(np.broadcast_to(br[None, None, :], G.shape("Br")), dtype=dt_)
        Bp = np.ascontiguousarray(np.broadcast_to(bp[None, None, :], G.shape("Bphi")), dtype=dt_)
        Bz = np.full(G.shape("Bz"), bz, dt_)
        args = [bc3(x) for x in (rho, vr, vp, vz, p)] + [Br, Bp, Bz]; Gk = G
        if backend == "cupy":                                       # move inputs to the device (harness fix, EMF/HLLD-01 addendum)
            import cupy as cp, copy as _c
            args = [cp.asarray(a) for a in args]; Gk = _c.copy(G); Gk.xp = cp
        F, fl = H.fluxes(Gk, *args, gamma=gam, limiter=limiter, backend=backend, directions=(2,))
        F = {k: (v.get() if hasattr(v, "get") else v) for k, v in F.items()}; fl = {k: (v.get() if hasattr(v, "get") else v) for k, v in fl.items()}
        Fz = F[2][:, 0, 0, :]                                       # (8, nz+1)
        Fz = Fz[[0, 1, 2, 3, 4, 5, 6]]                               # rho, m_r, m_phi, m_z, E, B_r, B_phi
        return -(Fz[:, 1:] - Fz[:, :-1]) / G.dz, int((fl[2] > 0).sum())
    t = 0.0; nfb = 0; steps = 0
    while t < T - 1e-14:
        rho, vr, vp, vz, p, br, bp = to_prim(U, bz, gam)
        cf = np.sqrt((gam * p + br ** 2 + bp ** 2 + bz ** 2) / rho)
        dt = min(cfl * G.dz / float(np.max(np.abs(vz) + cf)), T - t)
        k1, f1 = rhs(U); U1 = U + dt * k1
        k2, f2 = rhs(U1); U = 0.5 * (U + U1 + dt * k2); t += dt; nfb += f1 + f2; steps += 1
    return U, steps, nfb


def cp_alfven(nz, limiter="mc", dtype=np.float64):
    """circularly polarised Alfven wave along z (Toth 2000): rho=1, p=0.1, B_z=1, amplitude 0.1, k=2pi, v_A=1; one period."""
    G = grid1d(nz, dtype=dtype); gam = 5 / 3; z = G.z_c[G.g:G.g + nz]; k = 2 * np.pi; A = 0.1
    br, bp = A * np.cos(k * z), A * np.sin(k * z); vr, vp = -br, -bp                  # right-going wave (v = -B / sqrt(rho))
    U0 = to_cons(np.ones(nz), vr, vp, np.zeros(nz), np.full(nz, 0.1), br, bp, 1.0, gam)
    U, steps, nfb = run1d(G, U0.copy(), 1.0, gam, 1.0, limiter=limiter)
    err = float(np.abs(U[5] - U0[5]).mean() + np.abs(U[6] - U0[6]).mean()) / float(np.abs(U0[5]).mean() + np.abs(U0[6]).mean())
    return dict(nz=nz, steps=steps, rel_l1=err, fallbacks=nfb)


def sod(nz, limiter="mc"):
    """B = 0 shock tube (Sod, gamma 1.4) along z vs the exact Euler solution at t = 0.2."""
    import numpy_oracle_hlld as N
    G = grid1d(nz); gam = 1.4; z = G.z_c[G.g:G.g + nz] - 0.5; left = z < 0
    rho = np.where(left, 1.0, 0.125); p = np.where(left, 1.0, 0.1); zero = np.zeros(nz)
    U0 = to_cons(rho, zero, zero, zero, p, zero, zero, 0.0, gam)
    U, steps, nfb = run1d(G, U0, 0.0, gam, 0.2, bc="outflow", limiter=limiter)
    r_ex, u_ex, p_ex = N.exact_euler(1.0, 0.0, 1.0, 0.125, 0.0, 0.1, gam, z, 0.2)
    return dict(nz=nz, steps=steps, l1_rho=float(np.abs(U[0] - r_ex).mean()), fallbacks=nfb)


def brio_wu(nz, limiter="mc"):
    """Brio & Wu (1988) along z: gamma = 2, B_n = 0.75, B_t flips 1 -> -1; t = 0.1.  Checks finiteness, positivity and
    conservation (outflow boundaries: totals change only by the boundary fluxes, which are zero while the waves stay inside)."""
    G = grid1d(nz); gam = 2.0; z = G.z_c[G.g:G.g + nz] - 0.5; left = z < 0; zero = np.zeros(nz)
    U0 = to_cons(np.where(left, 1.0, 0.125), zero, zero, zero, np.where(left, 1.0, 0.1), np.where(left, 1.0, -1.0), zero, 0.75, gam)
    U, steps, nfb = run1d(G, U0.copy(), 0.75, gam, 0.1, bc="outflow", limiter=limiter)
    rho, vr, vp, vz, p, br, bp = to_prim(U, 0.75, gam)
    return dict(nz=nz, steps=steps, finite=bool(np.isfinite(U).all()), min_rho=float(rho.min()), min_p=float(p.min()),
                mass_change=float(abs(U[0].sum() - U0[0].sum()) * G.dz), energy_change=float(abs(U[4].sum() - U0[4].sum()) * G.dz),
                fallbacks=nfb, rho=rho)


if __name__ == "__main__":
    import time
    for lim in ("mc", "minmod"):
        prev = None
        for nz in (32, 64, 128, 256):
            t = time.time(); r = cp_alfven(nz, lim); o = "" if prev is None else f"order {np.log2(prev / r['rel_l1']):.2f}"; prev = r["rel_l1"]
            print("CPAW", lim, r, o, f"{time.time() - t:.1f}s", flush=True)
    prev = None
    for nz in (100, 200, 400, 800):
        r = sod(nz); o = "" if prev is None else f"order {np.log2(prev / r['l1_rho']):.2f}"; prev = r["l1_rho"]; print("Sod", r, o, flush=True)
    for nz in (400, 800):
        r = brio_wu(nz); r.pop("rho"); print("BrioWu", r, flush=True)
