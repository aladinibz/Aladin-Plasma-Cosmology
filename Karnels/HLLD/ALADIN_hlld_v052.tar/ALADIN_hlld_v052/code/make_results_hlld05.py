# -*- coding: utf-8 -*-
"""
MakeResults for HLLD-05.  Merges the CPU and GPU legs and the compute-sanitizer logs into one bundle WITHOUT dropping
anything: every leg's JSON is embedded verbatim (all measured values, conditions, thresholds, exceptions, timings,
environment and file hashes), plus a cross-leg table and the final per-test class.
  python make_results_hlld04.py            -> HLLD05_RESULTS.json, HLLD05_RESULTS.md
Final class per test: BLOCKER if any leg is BLOCKER; else LIMITATION if any leg says so; else VERIFIED if every leg that
ran it is VERIFIED; INCONCLUSIVE if no leg could evaluate it.
"""
import os, re, json, hashlib, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
P = lambda f: os.path.join(HERE, f)


def load(f):
    return json.load(open(P(f))) if os.path.exists(P(f)) else None


def sanitizer(f, pattern):
    if not os.path.exists(P(f)): return dict(file=f, present=False, cls="INCONCLUSIVE")
    txt = open(P(f), errors="replace").read()
    ok = re.search(pattern, txt) is not None and "HLLD-05 sanitizer workload done" in txt
    summ = [l.strip() for l in txt.splitlines() if "SUMMARY" in l]
    return dict(file=f, present=True, sha256=hashlib.sha256(txt.encode()).hexdigest(), summary_lines=summ, target_completed="HLLD-05 sanitizer workload done" in txt,
                cls="VERIFIED" if ok else "BLOCKER", log=txt)


def main():
    legs = {k: load(f"hlld05_{k}_results.json") for k in ("cpu", "gpu")}
    legs = {k: v for k, v in legs.items() if v is not None}
    san = dict(M1_memcheck=sanitizer("hlld05_memcheck.log", r"ERROR SUMMARY: 0 errors"),
               M2_racecheck=sanitizer("hlld05_racecheck.log", r"RACECHECK SUMMARY: 0 hazards displayed \(0 errors, 0 warnings\)"))
    ids = []
    for L in legs.values():
        for t in L["tests"]:
            if t["id"] not in ids: ids.append(t["id"])
    final, table = {}, []
    for i in ids:
        per = {k: next((t for t in L["tests"] if t["id"] == i), None) for k, L in legs.items()}
        cl = [t["cls"] for t in per.values() if t is not None]
        ran = [c for c in cl if c != "INCONCLUSIVE"]
        f = "BLOCKER" if "BLOCKER" in cl else "LIMITATION" if "LIMITATION" in ran else "VERIFIED" if ran else "INCONCLUSIVE"
        final[i] = f
        row = dict(id=i, final=f)
        for k, t in per.items():
            row[k] = None if t is None else dict(cls=t["cls"], checks=t.get("checks", []), seconds=t.get("seconds"), exception=t.get("exception"))
        table.append(row)
    for k, s in san.items():
        final[k] = s["cls"]; table.append(dict(id=k, final=s["cls"], sanitizer={x: y for x, y in s.items() if x != "log"}))
    hashes = {k: dict(kernel=L["kernel_source_sha256"], frozen=L["frozen_sha256"], build=L.get("build_sha256"), frozen_build=L.get("frozen_build_sha256"), files=L.get("file_sha256"), source=L.get("source", "leg JSON")) for k, L in legs.items()}
    consistent = len({h["kernel"] for h in hashes.values()}) <= 1 and len({h["build"] for h in hashes.values()}) <= 1 and all(h["kernel"] == h["frozen"] and h["build"] == h["frozen_build"] for h in hashes.values())
    counts = {}
    for v in final.values(): counts[v] = counts.get(v, 0) + 1
    out = dict(campaign="HLLD-05", kernel="ALADIN HLLD v05.2", made=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
               source_hash_consistent_and_frozen=consistent, hashes=hashes, final_class=final, final_counts=counts, table=table,
               legs_verbatim=legs, sanitizer_verbatim=san,
               addendum_after_L02=load("hlld05_addendum_cpu.json"),
               L02_statement=("L02 check 3 FAILED its predeclared threshold on both legs (worst rel vs 80-bit oracle 6.795e-10 > 1e-10). "
                              "The threshold was copied from H02 (moderate states); the log10-ramp generator produced |B_n| up to ~6e6 "
                              "(plasma beta ~1e-15), the extreme-field regime where HLLD-04 H13 uses 1e-6. Certified v05.1 has the SAME worst "
                              "error (6.795445434535941e-10), and L02 check 2 (v05.2 vs v05.1 <= 3.9e-16 rel) passed, so the failure is not "
                              "caused by v05.2. Addendum declared after the result: A2 (ramp problems with |B_n| <= 1e3) worst 2.3e-11 <= 1e-10 PASS; "
                              "A1 (per-problem error exactly equal to v05.1) FAIL by test design (fluxes differ by <= 3.9e-16 by construction). "
                              "L02 stays FAIL in the record."),
               history=dict(run1=dict(cpu=load("history_run1/hlld05_run1_cpu_results.json") if os.path.exists(P("history_run1/hlld05_run1_cpu_results.json")) else None,
                                      gpu_transcript=open(P("history_run1/hlld05_run1_gpu_TRANSCRIPT.txt")).read() if os.path.exists(P("history_run1/hlld05_run1_gpu_TRANSCRIPT.txt")) else None),
                            run2_gpu_transcript=open(P("hlld05_run2_gpu_TRANSCRIPT.txt")).read()))
    json.dump(out, open(P("HLLD05_RESULTS.json"), "w"), indent=1, default=float)

    md = [f"# HLLD-05 results: ALADIN HLLD v05.2", "", f"Made {out['made']}.  Source hash frozen and identical on all legs: **{consistent}**", ""]
    for k, h in hashes.items(): md.append(f"- {k} leg kernel sha256 `{h['kernel']}`, build sha256 `{h['build']}` (source of record: {h['source']})")
    md += ["", "| Test | Final | " + " | ".join(legs) + " |", "|---|---|" + "---|" * len(legs)]
    for r in table:
        if "sanitizer" in r:
            md.append(f"| {r['id']} | {r['final']} | " + " | ".join("" for _ in legs) + " |"); continue
        md.append(f"| {r['id']} | {r['final']} | " + " | ".join("—" if r[k] is None else r[k]["cls"] for k in legs) + " |")
    md += ["", f"Counts: {counts}", "", "## Checks (measured vs predeclared threshold)", ""]
    for r in table:
        for k in legs:
            t = r.get(k)
            if not t: continue
            for c in t["checks"]:
                md.append(f"- {r['id']} [{k}] {c['name']}: {c['measured']:.4e} {c['op']} {c['threshold']:.1e} -> {'pass' if c['passed'] else 'FAIL'}")
            if t.get("exception"): md.append(f"- {r['id']} [{k}] EXCEPTION:\n```\n{t['exception']}\n```")
    for k, s in san.items(): md.append(f"- {k}: {s['cls']} " + "; ".join(s.get("summary_lines", [])))
    open(P("HLLD05_RESULTS.md"), "w").write("\n".join(md) + "\n")
    print("\n".join(md[:len(table) + 8])); print("counts", counts)


if __name__ == "__main__":
    main()
