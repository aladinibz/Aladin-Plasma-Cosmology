# -*- coding: utf-8 -*-
"""Independent NumPy oracle for hlld_v02: HLLD written from Miyoshi & Kusano (2005, JCP 208, 315) eqs. (38)-(66) in
conserved-variable form, vectorised; plus the limited reconstruction and the exact gas-dynamics Riemann solver
(Toro 2009, ch. 4) used as the B = 0 reference.  No code shared with the CUDA/C++ source."""
import numpy as np


def fast_speed(rho, p, bn, b1, b2, gam):
    a2 = gam * p / rho; ca2 = (bn ** 2 + b1 ** 2 + b2 ** 2) / rho; cn2 = bn ** 2 / rho
    return np.sqrt(0.5 * (a2 + ca2 + np.sqrt(np.maximum((a2 + ca2) ** 2 - 4 * a2 * cn2, 0))))


def phys_flux(W, bn, gam):
    """W columns: rho, vn, vt1, vt2, p, bt1, bt2 -> (U, F) with U = rho, mn, mt1, mt2, E, bt1, bt2"""
    d, u, v, w, p, by, bz = W.T
    pT = p + 0.5 * (bn ** 2 + by ** 2 + bz ** 2)
    E = p / (gam - 1) + 0.5 * d * (u * u + v * v + w * w) + 0.5 * (bn ** 2 + by ** 2 + bz ** 2)
    U = np.column_stack([d, d * u, d * v, d * w, E, by, bz])
    F = np.column_stack([d * u, d * u * u + pT - bn ** 2, d * v * u - bn * by, d * w * u - bn * bz, (E + pT) * u - bn * (u * bn + v * by + w * bz),
                         by * u - bn * v, bz * u - bn * w])
    return U, F


def hll_flux(WL, WR, bn, gam):
    UL, FL = phys_flux(WL, bn, gam); UR, FR = phys_flux(WR, bn, gam)
    cfL = fast_speed(WL[:, 0], WL[:, 4], bn, WL[:, 5], WL[:, 6], gam); cfR = fast_speed(WR[:, 0], WR[:, 4], bn, WR[:, 5], WR[:, 6], gam)
    SL = (np.minimum(WL[:, 1], WR[:, 1]) - np.maximum(cfL, cfR))[:, None]; SR = (np.maximum(WL[:, 1], WR[:, 1]) + np.maximum(cfL, cfR))[:, None]
    with np.errstate(all="ignore"):
        Fh = (SR * FL - SL * FR + SL * SR * (UR - UL)) / (SR - SL)
    return np.where(SL >= 0, FL, np.where(SR <= 0, FR, Fh))


def guard_v03(WL, WR, bn, gam, K=32.0):
    """v03 ordering / amplification guard, written from its definition: True where HLLD must fall back to HLL"""
    dL, uL, vL, wL, pL, byL, bzL = WL.T; dR, uR, vR, wR, pR, byR, bzR = WR.T
    cfL = fast_speed(dL, pL, bn, byL, bzL, gam); cfR = fast_speed(dR, pR, bn, byR, bzR, gam)
    SL = np.minimum(uL, uR) - np.maximum(cfL, cfR); SR = np.maximum(uL, uR) + np.maximum(cfL, cfR)
    pTL = pL + 0.5 * (bn ** 2 + byL ** 2 + bzL ** 2); pTR = pR + 0.5 * (bn ** 2 + byR ** 2 + bzR ** 2)
    SM = ((SR - uR) * dR * uR - (SL - uL) * dL * uL - pTR + pTL) / ((SR - uR) * dR - (SL - uL) * dL)
    dLs = dL * (SL - uL) / (SL - SM); dRs = dR * (SR - uR) / (SR - SM)
    order_bad = ~(dLs * (SL - SM) ** 2 > bn ** 2 * (1 + 1e-6)) | ~(dRs * (SR - SM) ** 2 > bn ** 2 * (1 + 1e-6))
    bmax = np.sqrt(np.maximum(bn ** 2 + byL ** 2 + bzL ** 2, bn ** 2 + byR ** 2 + bzR ** 2)); cmax = np.maximum(cfL, cfR)
    with np.errstate(all="ignore"):
        denL = dL * (SL - uL) * (SL - SM) - bn ** 2; denR = dR * (SR - uR) * (SR - SM) - bn ** 2
        gbL = np.abs((dL * (SL - uL) ** 2 - bn ** 2) / denL) * np.hypot(byL, bzL); gbR = np.abs((dR * (SR - uR) ** 2 - bn ** 2) / denR) * np.hypot(byR, bzR)
        gvL = np.abs(bn * (SM - uL) / denL) * np.hypot(byL, bzL); gvR = np.abs(bn * (SM - uR) / denR) * np.hypot(byR, bzR)
    amp_bad = ~(gbL <= K * bmax) | ~(gbR <= K * bmax) | ~(gvL <= K * cmax) | ~(gvR <= K * cmax)
    hll_needed = ~((SL < uL) & (SR > uR) & (dLs > 0) & (dRs > 0))     # the kernel's own earlier HLL guards (positivity of rho*)
    inside = (SL < 0) & (SR > 0)
    return inside & ~hll_needed & (order_bad | amp_bad)


def hlld_v03(WL, WR, bn, gam):
    g = guard_v03(WL, WR, bn, gam)
    with np.errstate(all="ignore"):
        F = hlld(WL, WR, bn, gam)
    return np.where(g[:, None], hll_flux(WL, WR, bn, gam), F), g


def hlld(WL, WR, bn, gam):
    """Miyoshi-Kusano HLLD; returns F (n, 7).  Degenerate cases handled as in the paper (sec. 4): when
    rho (S - u)(S - S_M) - B_n^2 -> 0 the star tangential components equal the outer ones; when B_n -> 0 the
    double-star states equal the single-star states."""
    UL, FL = phys_flux(WL, bn, gam); UR, FR = phys_flux(WR, bn, gam)
    dL, uL, vL, wL, pL, byL, bzL = WL.T; dR, uR, vR, wR, pR, byR, bzR = WR.T
    cfL = fast_speed(dL, pL, bn, byL, bzL, gam); cfR = fast_speed(dR, pR, bn, byR, bzR, gam)
    SL = np.minimum(uL, uR) - np.maximum(cfL, cfR); SR = np.maximum(uL, uR) + np.maximum(cfL, cfR)   # eq. (67)
    pTL = pL + 0.5 * (bn ** 2 + byL ** 2 + bzL ** 2); pTR = pR + 0.5 * (bn ** 2 + byR ** 2 + bzR ** 2)
    SM = ((SR - uR) * dR * uR - (SL - uL) * dL * uL - pTR + pTL) / ((SR - uR) * dR - (SL - uL) * dL)   # eq. (38)
    pTs = ((SR - uR) * dR * pTL - (SL - uL) * dL * pTR + dL * dR * (SR - uR) * (SL - uL) * (uR - uL)) / ((SR - uR) * dR - (SL - uL) * dL)  # eq. (41)

    def star(d, u, v, w, by, bz, E, pT, S):
        ds = d * (S - u) / (S - SM)                                                       # eq. (43)
        den = d * (S - u) * (S - SM) - bn ** 2
        degen = np.abs(den) <= 1e-12 * (np.abs(d * (S - u) * (S - SM)) + bn ** 2)
        den_s = np.where(degen, 1.0, den)
        vs = np.where(degen, v, v - bn * by * (SM - u) / den_s)                           # eq. (44)
        ws = np.where(degen, w, w - bn * bz * (SM - u) / den_s)                           # eq. (46)
        bys = np.where(degen, by, by * (d * (S - u) ** 2 - bn ** 2) / den_s)              # eq. (45)
        bzs = np.where(degen, bz, bz * (d * (S - u) ** 2 - bn ** 2) / den_s)              # eq. (47)
        Es = ((S - u) * E - pT * u + pTs * SM + bn * (u * bn + v * by + w * bz - (SM * bn + vs * bys + ws * bzs))) / (S - SM)   # eq. (48)
        return ds, vs, ws, bys, bzs, Es

    dLs, vLs, wLs, byLs, bzLs, ELs = star(dL, uL, vL, wL, byL, bzL, UL[:, 4], pTL, SL)
    dRs, vRs, wRs, byRs, bzRs, ERs = star(dR, uR, vR, wR, byR, bzR, UR[:, 4], pTR, SR)
    SLs = SM - np.abs(bn) / np.sqrt(dLs); SRs = SM + np.abs(bn) / np.sqrt(dRs)           # eq. (51)
    sq = np.sqrt(dLs) + np.sqrt(dRs); sg = np.sign(bn); sg = np.where(sg == 0, 1.0, sg)
    vss = (np.sqrt(dLs) * vLs + np.sqrt(dRs) * vRs + (byRs - byLs) * sg) / sq             # eq. (59)
    wss = (np.sqrt(dLs) * wLs + np.sqrt(dRs) * wRs + (bzRs - bzLs) * sg) / sq             # eq. (60)
    byss = (np.sqrt(dLs) * byRs + np.sqrt(dRs) * byLs + np.sqrt(dLs * dRs) * (vRs - vLs) * sg) / sq   # eq. (61)
    bzss = (np.sqrt(dLs) * bzRs + np.sqrt(dRs) * bzLs + np.sqrt(dLs * dRs) * (wRs - wLs) * sg) / sq   # eq. (62)
    ELss = ELs - np.sqrt(dLs) * (SM * bn + vLs * byLs + wLs * bzLs - (SM * bn + vss * byss + wss * bzss)) * sg   # eq. (63)
    ERss = ERs + np.sqrt(dRs) * (SM * bn + vRs * byRs + wRs * bzRs - (SM * bn + vss * byss + wss * bzss)) * sg
    tiny = 0.5 * bn ** 2 <= 1e-12 * pTs                                                   # B_n -> 0: ** = *
    def pick(a, b): return np.where(tiny, a, b)
    ULs = np.column_stack([dLs, dLs * SM, dLs * vLs, dLs * wLs, ELs, byLs, bzLs])
    URs = np.column_stack([dRs, dRs * SM, dRs * vRs, dRs * wRs, ERs, byRs, bzRs])
    ULss = np.column_stack([dLs, dLs * SM, dLs * pick(vLs, vss), dLs * pick(wLs, wss), pick(ELs, ELss), pick(byLs, byss), pick(bzLs, bzss)])
    URss = np.column_stack([dRs, dRs * SM, dRs * pick(vRs, vss), dRs * pick(wRs, wss), pick(ERs, ERss), pick(byRs, byss), pick(bzRs, bzss)])
    F = np.empty_like(FL)
    c = [SL[:, None] >= 0, SLs[:, None] >= 0, SM[:, None] >= 0, SRs[:, None] > 0, SR[:, None] > 0]
    sup_r = SR[:, None] <= 0                                                              # all waves left-going: F = F_R
    FLs = FL + SL[:, None] * (ULs - UL); FRs = FR + SR[:, None] * (URs - UR)             # eq. (64)
    FLss = FLs + SLs[:, None] * (ULss - ULs); FRss = FRs + SRs[:, None] * (URss - URs)  # eq. (65)
    with np.errstate(all="ignore"):
        F = np.where(c[0], FL, np.where(sup_r, FR, np.where(c[1], FLs, np.where(c[2], FLss, np.where(c[3], FRss, FRs)))))
    return F


def limiter(dl, dr, kind):
    s = np.sign(dl)
    if kind == "minmod": out = s * np.minimum(np.abs(dl), np.abs(dr))
    else: out = s * np.minimum(np.minimum(2 * np.abs(dl), 2 * np.abs(dr)), 0.5 * np.abs(dl + dr))
    return np.where(dl * dr > 0, out, 0.0)


def exact_euler(dL, uL, pL, dR, uR, pR, gam, x, t):
    """Exact Riemann solution of the Euler equations (Toro ch. 4) sampled at x/t; returns rho, u, p."""
    cL, cR = np.sqrt(gam * pL / dL), np.sqrt(gam * pR / dR)
    AL, AR = 2 / ((gam + 1) * dL), 2 / ((gam + 1) * dR); BL, BR = (gam - 1) / (gam + 1) * pL, (gam - 1) / (gam + 1) * pR
    def f(p, d, pk, ck, A, B):
        if p > pk: return (p - pk) * np.sqrt(A / (p + B)), np.sqrt(A / (B + p)) * (1 - (p - pk) / (2 * (B + p)))
        return 2 * ck / (gam - 1) * ((p / pk) ** ((gam - 1) / (2 * gam)) - 1), 1 / (d * ck) * (p / pk) ** (-(gam + 1) / (2 * gam))
    p = max(1e-8, 0.5 * (pL + pR))
    for _ in range(100):
        fL, dfL = f(p, dL, pL, cL, AL, BL); fR, dfR = f(p, dR, pR, cR, AR, BR)
        dp = (fL + fR + uR - uL) / (dfL + dfR); p = max(1e-12, p - dp)
        if abs(dp) < 1e-15 * p: break
    us = 0.5 * (uL + uR) + 0.5 * (f(p, dR, pR, cR, AR, BR)[0] - f(p, dL, pL, cL, AL, BL)[0])
    S = x / t; rho = np.empty_like(S); u = np.empty_like(S); pp = np.empty_like(S)
    for i, s in enumerate(S):
        if s <= us:
            if p > pL:
                dsl = dL * ((p / pL + (gam - 1) / (gam + 1)) / ((gam - 1) / (gam + 1) * p / pL + 1)); SLs = uL - cL * np.sqrt((gam + 1) / (2 * gam) * p / pL + (gam - 1) / (2 * gam))
                rho[i], u[i], pp[i] = (dL, uL, pL) if s <= SLs else (dsl, us, p)
            else:
                csl = cL * (p / pL) ** ((gam - 1) / (2 * gam)); SH, ST = uL - cL, us - csl
                if s <= SH: rho[i], u[i], pp[i] = dL, uL, pL
                elif s >= ST: rho[i], u[i], pp[i] = dL * (p / pL) ** (1 / gam), us, p
                else:
                    c = 2 / (gam + 1) * (cL + (gam - 1) / 2 * (uL - s)); rho[i] = dL * (c / cL) ** (2 / (gam - 1)); u[i] = 2 / (gam + 1) * (cL + (gam - 1) / 2 * uL + s); pp[i] = pL * (c / cL) ** (2 * gam / (gam - 1))
        else:
            if p > pR:
                dsr = dR * ((p / pR + (gam - 1) / (gam + 1)) / ((gam - 1) / (gam + 1) * p / pR + 1)); SRs = uR + cR * np.sqrt((gam + 1) / (2 * gam) * p / pR + (gam - 1) / (2 * gam))
                rho[i], u[i], pp[i] = (dR, uR, pR) if s >= SRs else (dsr, us, p)
            else:
                csr = cR * (p / pR) ** ((gam - 1) / (2 * gam)); SH, ST = uR + cR, us + csr
                if s >= SH: rho[i], u[i], pp[i] = dR, uR, pR
                elif s <= ST: rho[i], u[i], pp[i] = dR * (p / pR) ** (1 / gam), us, p
                else:
                    c = 2 / (gam + 1) * (cR - (gam - 1) / 2 * (uR - s)); rho[i] = dR * (c / cR) ** (2 / (gam - 1)); u[i] = 2 / (gam + 1) * (-cR + (gam - 1) / 2 * uR + s); pp[i] = pR * (c / cR) ** (2 * gam / (gam - 1))
    return rho, u, pp


def blend_weight_v04(WL, WR, bn, gam):
    """v04 blend weight written from its definition (independent of the kernel code): w = w_m * w_A, plus the cases the
    kernel resolves before the blend (supersonic -> pure upwind, non-positive star density -> HLL)."""
    dL, uL, vL, wL, pL, byL, bzL = WL.T; dR, uR, vR, wR, pR, byR, bzR = WR.T
    cfL = fast_speed(dL, pL, bn, byL, bzL, gam); cfR = fast_speed(dR, pR, bn, byR, bzR, gam)
    SL = np.minimum(uL, uR) - np.maximum(cfL, cfR); SR = np.maximum(uL, uR) + np.maximum(cfL, cfR)
    pTL = pL + 0.5 * (bn ** 2 + byL ** 2 + bzL ** 2); pTR = pR + 0.5 * (bn ** 2 + byR ** 2 + bzR ** 2)
    with np.errstate(all="ignore"):
        SM = ((SR - uR) * dR * uR - (SL - uL) * dL * uL - pTR + pTL) / ((SR - uR) * dR - (SL - uL) * dL)
        dLs = dL * (SL - uL) / (SL - SM); dRs = dR * (SR - uR) / (SR - SM)
        m = np.where(bn ** 2 > 0, np.minimum(dLs * (SL - SM) ** 2, dRs * (SR - SM) ** 2) / np.where(bn ** 2 > 0, bn ** 2, 1) - 1, np.inf)
        def sstep(t): t = np.clip(t, 0, 1); return t * t * (3 - 2 * t)
        wm = np.where(m <= 1e-6, 0.0, np.where(m >= 1e-5, 1.0, sstep(np.log10(np.maximum(m, 1e-300)) + 6)))
        denL = dL * (SL - uL) * (SL - SM) - bn ** 2; denR = dR * (SR - uR) * (SR - SM) - bn ** 2
        btL = np.abs((dL * (SL - uL) ** 2 - bn ** 2) / denL) * np.hypot(byL, bzL); btR = np.abs((dR * (SR - uR) ** 2 - bn ** 2) / denR) * np.hypot(byR, bzR)
        dvL = np.abs(bn * (SM - uL) / denL) * np.hypot(byL, bzL); dvR = np.abs(bn * (SM - uR) / denR) * np.hypot(byR, bzR)
        bmax = np.sqrt(np.maximum(bn ** 2 + byL ** 2 + bzL ** 2, bn ** 2 + byR ** 2 + bzR ** 2)); cmax = np.maximum(cfL, cfR)
        A = np.maximum(np.maximum(btL, btR) / bmax, np.maximum(dvL, dvR) / cmax)
        wA = np.where(A <= 16, 1.0, np.where(A >= 32, 0.0, 1 - sstep((A - 16) / 16)))
        w = np.where(wm > 0, wm * np.where(np.isfinite(A), wA, 0.0), 0.0)
    upwind = (SL >= 0) | (SR <= 0); bad = ~((dLs > 0) & (dRs > 0))
    return np.where(upwind, 1.0, np.where(bad, 0.0, w)), upwind, bad


def hlld_v04(WL, WR, bn, gam):
    w, upwind, bad = blend_weight_v04(WL, WR, bn, gam)
    with np.errstate(all="ignore"):
        Fd = hlld(WL, WR, bn, gam)
    Fh = hll_flux(WL, WR, bn, gam)
    Fd = np.where((w > 0)[:, None], Fd, 0.0)
    F = w[:, None] * Fd + (1 - w[:, None]) * Fh
    code = np.where(upwind, 0, np.where(w <= 0, 2, np.where(w < 1, 3, 0)))
    return F, code, w


def admissible_v05(W, bn=None):
    """oracle of the v05 refusal rule (written independently of the kernel): a state (rho, v_n, v_t1, v_t2, p, B_t1, B_t2) is
    admissible iff every component is finite, rho > 0 and p >= 0 (p = 0, the cold limit, is admitted); a non-finite B_n refuses."""
    W = np.asarray(W, dtype=np.float64)
    ok = np.isfinite(W).all(axis=-1) & (W[..., 0] > 0) & (W[..., 4] >= 0)
    if bn is not None: ok &= np.isfinite(np.asarray(bn, dtype=np.float64))
    return ok


def hlld_v05(WL, WR, bn, gam):
    """v05 = v04 on admissible pairs; refused pairs give an all-NaN flux and code 4."""
    ok = admissible_v05(WL, bn) & admissible_v05(WR)
    WLs, WRs = np.where(ok[..., None], WL, 1.0), np.where(ok[..., None], WR, 1.0); bns = np.where(ok, bn, 0.0)
    F, code, w = hlld_v04(WLs, WRs, bns, gam)
    F = np.where(ok[..., None], F, np.nan); code = np.where(ok, code, 4); w = np.where(ok, w, np.nan)
    return F, code, w
