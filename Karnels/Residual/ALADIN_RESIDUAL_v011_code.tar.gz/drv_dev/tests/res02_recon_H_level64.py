import sys, json, numpy as np, hashlib
sys.path.insert(0, "/home/claude/drv_dev"); sys.path.insert(0, "/home/claude/drv_dev/tests")
sys.argv = ["res02.py", "cpu", "H"]
import res02 as M
import aladin_driver_v40 as D
from managers import source_manager as SM
B = "/home/claude/res02night/runs_res02_gpu_H/RES02_H_20261123T211839Z_696f54/"
z = np.load(B + "final_state.npz")
src = SM.MMSSource(SM.mms01_solution())
d = D.Driver(D.Config(nr=64, nphi=128, nz=128, hall=0.02, r_outer_bc="fixed", backend="cpu"), src.ic, source=src)
for i in range(5): d.U[i][...] = z[f"arr_{i}"]
for i in range(3): d.B[i][...] = z[f"arr_{5+i}"]
d.t = float(z["t"]); d.step = int(z["step"])
dmax, rp = 0.0, 0
for line in open(B + "history.jsonl"):
    r = json.loads(line); dmax = max(dmax, r["divB_norm"]); rp += r["recovery_passes"]
rec = dict(level="64x128x128", status="COMPLETED", steps=d.step, t=d.t, seconds=14944.6, divB_max=dmax, recovery_passes=rp, resumed_from_step=None,
           errors=src.errors(d), axis_rings=M.ring_errors(src, d), sha256=M.sha_arrays(d),
           reconstructed_from=dict(bundle="RES02_H_20261123T211839Z_696f54", final_state_sha256=hashlib.sha256(open(B + "final_state.npz", "rb").read()).hexdigest(),
                                   note="GPU run 1 (A100, 2026-11-23/24); level-64 record rebuilt on the CPU from its checksummed final state and per-step history; run 2 printed the identical numbers"))
print(rec["steps"], rec["t"], f"divB {dmax:.3e} recovery {rp}", " ".join(f"{k} {v['L1']:.3e}" for k, v in rec["errors"].items()))
json.dump(dict(levels={"64x128x128": rec}), open("/tmp/claude-0/-home-claude/68a94514-93c3-5864-ab9f-91213bb99729/scratchpad/res02_progress_gpu_H.json", "w"), indent=1, default=float)
