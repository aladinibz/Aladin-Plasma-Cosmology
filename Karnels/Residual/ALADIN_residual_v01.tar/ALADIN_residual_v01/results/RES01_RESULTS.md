# RES-01 results: ALADIN RESIDUAL v01

Made 2026-11-20 17:35 UTC.  Source hash frozen and identical on all legs: **True**

- cpu leg kernel sha256 `51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4`, build sha256 `da42aadd13c49891906d6ebbf91ecb2954b8ca00a5ee7965c0a660fcaaf3682e` (source of record: leg JSON)
- gpu leg kernel sha256 `51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4`, build sha256 `da42aadd13c49891906d6ebbf91ecb2954b8ca00a5ee7965c0a660fcaaf3682e` (source of record: leg JSON)

| Test | Final | cpu | gpu |
|---|---|---|---|
| T01 | VERIFIED | VERIFIED | VERIFIED |
| T02 | VERIFIED | VERIFIED | VERIFIED |
| T03 | VERIFIED | VERIFIED | VERIFIED |
| T04 | VERIFIED | VERIFIED | VERIFIED |
| T05 | VERIFIED | VERIFIED | VERIFIED |
| T06 | VERIFIED | VERIFIED | VERIFIED |
| T07 | VERIFIED | VERIFIED | VERIFIED |
| G6 | VERIFIED | — | VERIFIED |
| G1 | VERIFIED | — | VERIFIED |
| G2 | VERIFIED | — | VERIFIED |
| G3 | VERIFIED | — | VERIFIED |
| M1_memcheck | VERIFIED |  |  |
| M2_racecheck | VERIFIED |  |  |

Counts: {'VERIFIED': 13}

## Checks (measured vs predeclared threshold)

- T01 [cpu] FP64 max error in units of u x term scale: 4.2386e+00 <= 1.6e+01 -> pass
- T01 [cpu] FP32 max error in units of u x term scale: 3.9864e+00 <= 1.6e+01 -> pass
- T01 [gpu] FP64 max error in units of u x term scale: 4.2386e+00 <= 1.6e+01 -> pass
- T01 [gpu] FP32 max error in units of u x term scale: 3.9864e+00 <= 1.6e+01 -> pass
- T02 [cpu] FP64 max relative imbalance: 6.9504e-18 <= 1.0e-13 -> pass
- T02 [cpu] FP32 max relative imbalance: 2.6677e-09 <= 1.0e-05 -> pass
- T02 [gpu] FP64 max relative imbalance: 6.9504e-18 <= 1.0e-13 -> pass
- T02 [gpu] FP32 max relative imbalance: 2.6677e-09 <= 1.0e-05 -> pass
- T03 [cpu] max |dU| in units of u x term scale: 7.1276e-01 <= 1.6e+01 -> pass
- T03 [gpu] max |dU| in units of u x term scale: 7.1276e-01 <= 1.6e+01 -> pass
- T04 [cpu] max deviation of dm_r/dt from dr^2/(32 r_c), units of u x term scale: 6.5581e-01 <= 6.4e+01 -> pass
- T04 [cpu] max |dU| of rho, m_phi, m_z, E: 0.0000e+00 <= 0.0e+00 -> pass
- T04 [cpu] well-balanced mode max |dU|: 0.0000e+00 <= 0.0e+00 -> pass
- T04 [gpu] max deviation of dm_r/dt from dr^2/(32 r_c), units of u x term scale: 6.5581e-01 <= 6.4e+01 -> pass
- T04 [gpu] max |dU| of rho, m_phi, m_z, E: 0.0000e+00 <= 0.0e+00 -> pass
- T04 [gpu] well-balanced mode max |dU|: 0.0000e+00 <= 0.0e+00 -> pass
- T05 [cpu] final order, annulus, L_inf: 1.9935e+00 >= 1.9e+00 -> pass
- T05 [cpu] final order, axis grid, L1: 1.9638e+00 >= 1.8e+00 -> pass
- T05 [gpu] final order, annulus, L_inf: 1.9935e+00 >= 1.9e+00 -> pass
- T05 [gpu] final order, axis grid, L1: 1.9638e+00 >= 1.8e+00 -> pass
- T06 [cpu] mismatches (flag set, NaN outputs, changes elsewhere): 0.0000e+00 <= 0.0e+00 -> pass
- T06 [gpu] mismatches (flag set, NaN outputs, changes elsewhere): 0.0000e+00 <= 0.0e+00 -> pass
- T07 [cpu] relative angular-momentum imbalance: 2.7259e-18 <= 1.0e-13 -> pass
- T07 [gpu] relative angular-momentum imbalance: 2.7259e-18 <= 1.0e-13 -> pass
- G6 [gpu] FP32 subnormal arithmetic bit-identical to IEEE: 1.0000e+00 == 1.0e+00 -> pass
- G6 [gpu] '.ftz' in RESIDUAL PTX: 0.0000e+00 <= 0.0e+00 -> pass
- G1 [gpu] GPU values differing from CPU: 0.0000e+00 <= 0.0e+00 -> pass
- G2 [gpu] differing values: 0.0000e+00 <= 0.0e+00 -> pass
- G3 [gpu] FP64 max error vs oracle in units of u x term scale (GPU): 2.8832e+00 <= 1.6e+01 -> pass
- M1_memcheck: VERIFIED ========= ERROR SUMMARY: 0 errors
- M2_racecheck: VERIFIED ========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)
