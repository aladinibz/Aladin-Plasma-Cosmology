# -*- coding: utf-8 -*-
"""Builds report.html for ALADIN RESIDUAL v01 from RES01_RESULTS.json."""
import json, html
R = json.load(open("/home/claude/res/RES01_RESULTS.json"))
LEG = R["legs_verbatim"]; CPU = {t["id"]: t for t in LEG["cpu"]["tests"]}; GPU = {t["id"]: t for t in LEG["gpu"]["tests"]}
SAN = R["sanitizer_verbatim"]; SHA = R["hashes"]["gpu"]["kernel"]; BSHA = R["hashes"]["gpu"]["build"]; FILES = R["hashes"]["gpu"]["files"]
css = open("/home/claude/gyropdf/report.html").read().split("<style>")[1].split("</style>")[0]
e = html.escape
def f(x, d=2):
    if x == 0: return "0"
    return f"{x:.{d}e}".replace("e-0", "e-").replace("e+0", "e+").replace("e+", "e")
def pill(c): return f'<span class="pill {dict(VERIFIED="", LIMITATION="gold", BLOCKER="red", INCONCLUSIVE="navy")[c]}">{c}</span>'
def checks_txt(t): return "<br>".join(f"{e(c['name'])}: <b>{f(c['measured'])}</b> {e(c['op'])} {f(c['threshold'],0)}" for c in t["checks"])
TITLES = dict(
    T01=("Kernel vs 80-bit oracle", "axis, annulus, 1-cell-wide, r ∈ [2, 3.3]; R_eq on/off; FP64 + FP32; error in units of u × term scale"),
    T02=("Exact discrete conservation", "mass, z-momentum, energy and angular momentum (Σ V r̄ m_φ) vs boundary fluxes"),
    T03=("Free stream", "uniform state, axial field, HLLD fluxes: the P_T/r source balances the divergence"),
    T04=("README Z-pinch: PRIM → HLLD → RESIDUAL", "d(m_r)/dt = dr²/(32 r_c) exactly; other components 0; well-balanced mode 0"),
    T05=("Second order (manufactured solution)", "all 5 components vs exact cell averages, n = 16 … 128"),
    T06=("Refusal: rule, NaN, locality", "NaN / Inf in fluxes, primitives, CT faces, R_eq; FP64 + FP32"),
    T07=("Angular momentum of a rotating disc", "magnetised disc v_φ = r/(1+r²): dL/dt = boundary torque"),
    G6=("GPU compile path is IEEE", "direct NVRTC; subnormal ×, +, ÷ bit-identical; no .ftz in the PTX"),
    G1=("GPU = CPU bit for bit", "4 grids incl. partial blocks and a subnormal-scale case, refusal, R_eq; FP64 + FP32"),
    G2=("GPU determinism", "three launches identical"),
    G3=("GPU vs 80-bit oracle", "T01 FP64 through CUDA"))
rows = []
for i in R["final_class"]:
    if i.startswith("M"): continue
    ti, cond = TITLES[i]; c = CPU.get(i); g = GPU.get(i)
    rows.append(f"<tr><td>{i}</td><td><b>{e(ti)}</b><br><span class='note'>{e(cond)}</span></td><td class='mono'>{checks_txt(c) if c else '— (GPU only)'}</td><td class='mono'>{checks_txt(g)}</td><td>{pill(R['final_class'][i])}</td></tr>")
for k, nm in (("M1_memcheck", "compute-sanitizer memcheck"), ("M2_racecheck", "compute-sanitizer racecheck")):
    s = SAN[k]; line = [l for l in s["summary_lines"] if "SUMMARY" in l][-1].replace("=========", "").strip()
    rows.append(f"<tr><td>{k.split('_')[0]}</td><td><b>{nm}</b><br><span class='note'>6 grids incl. a 1-cell grid and partial blocks, FP64 + FP32, R_eq on/off, refusal paths</span></td><td class='mono'>—</td><td class='mono'>{e(line)}</td><td>{pill(R['final_class'][k])}</td></tr>")
TABLE = "\n".join(rows)
genv, cenv = LEG["gpu"]["env"], LEG["cpu"]["env"]
filerows = "".join(f"<tr><td class='mono'>{k}</td><td class='hash'>{v}</td></tr>" for k, v in FILES.items())
T05 = CPU["T05"]["data"]["rows"]; T07 = CPU["T07"]["data"]["rows"]; G1 = GPU["G1"]["data"]
bench = open("/home/claude/res/benchmark/readme_benchmark_output.txt").read()
body = f"""
<section class="cover">
  <div class="kicker">ALADIN Plasma Cosmology · Kernel 07 · RESIDUAL</div>
  <h1>ALADIN RESIDUAL v01</h1>
  <div class="subtitle">The finite-volume right-hand side of the native-cylindrical ALADIN Driver: conservative divergence of the HLLD fluxes with exact cell volumes, the full magnetohydrodynamic geometric source, exact discrete conservation of mass, axial momentum, energy and angular momentum, and a well-balanced mode in which the README Z-pinch is exactly static. GPU and CPU bit-identical</div>
  <div class="rule"></div>
  <div class="meta">
    <b>Author:</b> Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X<br>
    <b>System:</b> ALADIN native-cylindrical GPU MHD Driver: Z-pinch and J × B research<br>
    <b>Release:</b> RESIDUAL v01 · campaign RES-01 · 20 November 2026<br>
    <b>Kernel source SHA-256:</b> <span class="hash">{SHA}</span><br>
    <b>Build SHA-256</b> (source + GPU options + CPU flags + loader): <span class="hash">{BSHA}</span><br>
    <b>Legs:</b> CPU (g++ / OpenMP) and GPU ({e(genv['gpu'])}, CUDA runtime {genv['cuda_runtime']}, CuPy {genv['cupy']}, NVRTC called directly); FP64 + FP32
  </div>
  <div class="hero">
    <div class="lbl">What RESIDUAL computes for every interior cell</div>
    <div class="eq">dU/dt = −[(r₊F₊ − r₋F₋)/(r_c Δr) + ΔF_φ/(r_c Δφ) + ΔF_z/Δz] + S, &nbsp; S_mr = (ρv_φ² + P_T − B_φ²)/r_c</div>
    <div class="cap">U = (ρ, m_r, m_φ, m_z, E). m_φ uses the angular-momentum form (r₊²F₊ − r₋²F₋)/(r̄ r_c Δr), with r̄ the volume-mean radius. Optional R_eq is subtracted (well-balanced mode). Flag 1 = refused (NaN outputs)</div>
  </div>
  <div class="cards">
    <div class="card"><div class="big">11 / 11</div><div class="t">RES-01 on GPU, all VERIFIED (7 / 7 on CPU) on the first frozen run; sanitizer 0 errors, 0 hazards</div></div>
    <div class="card"><div class="big">0</div><div class="t">README Z-pinch in well-balanced mode: max |dU/dt| exactly 0</div></div>
    <div class="card"><div class="big">3e-18</div><div class="t">relative angular-momentum imbalance of a rotating magnetised disc: dL/dt = boundary torque</div></div>
    <div class="card gold"><div class="big">1.96</div><div class="t">convergence order on the axis grid, L1; 1.99 on the annulus, L∞</div></div>
  </div>
  <div class="cover-foot">Every number is generated from RES01_RESULTS.json (both legs verbatim).</div>
</section>

<h2 class="pb">1. What RESIDUAL v01 is, and what it corrects</h2>
<p>In Driver v3.1 the RESIDUAL slot was a stub, and the separate <code>GeometricSources</code> class carried only the hydrodynamic hoop terms ρv_φ²/r and −ρv_rv_φ/r. The HLLD fluxes carry the full momentum flux tensor (gas pressure, magnetic pressure and tension). In conservative cylindrical form that requires the full source: Π_φφ/r = (ρv_φ² + P_T − B_φ²)/r for m_r, and the matching magnetic term for m_φ. Without it, the README pinch is not an equilibrium of the Driver's discrete equations. RESIDUAL v01 is the kernel built on the certified contract:</p>
<ul>
<li><b>Exact cell volumes.</b> V = ½(r₊² − r₋²)ΔφΔz, so r_c Δr = ½(r₊² − r₋²) exactly. On the axis the inner face carries no flux (r₋ = 0).</li>
<li><b>Angular momentum.</b> The m_φ radial term is written as (r₊²F₊ − r₋²F₋)/(r̄ r_c Δr), with r̄ = ⅔(r₊³ − r₋³)/(r₊² − r₋²). The discrete angular momentum L = Σ V r̄ m_φ then changes only by the boundary torque, to round-off; the φ and z terms telescope for any per-radius weight. r̄ (not r_c) makes the radial term exact for the regular axis behaviour Π_rφ ∝ r. The φ term keeps r_c, because mid-face fluxes are second order there.</li>
<li><b>Well-balanced mode.</b> R(U) − R(U_eq), the same idea as HLLD's W_eq. A state equal to the supplied equilibrium gives dU = 0 exactly.</li>
<li><b>Geometry factors</b> (1/A, 1/r_c, 1/(r̄A), 1/Δφ, 1/Δz) are computed on the host in double and rounded once, so FP32 does not lose digits to r/Δr cancellation.</li>
<li><b>Refusal.</b> A non-finite input among the cell's 30 used flux values, its primitives, its 6 CT faces or R_eq, or ρ ≤ 0, or p &lt; 0, gives flag 1 with NaN outputs. HLLD flag 32 and PRIM flags 1, 2 and 8 therefore propagate as refusals.</li>
<li><b>Build.</b> NVRTC is called directly with <code>-fmad=false -ftz=false</code> (PRIM-01 finding: <code>cupy.RawModule</code> appends <code>-ftz=true</code>), the PTX is checked free of <code>.ftz</code>, and the CPU build uses g++ <code>-ffp-contract=off</code>. GPU and CPU are bit-identical (G1: 0 of {G1['values']:,} values differ).</li>
<li><b>Induction.</b> The B components of the HLLD flux are not used: B is advanced by constrained transport (UCT-EMF, UCT-ASSEMBLY).</li>
</ul>

<h2>2. The README benchmark: normalised Z-pinch, μ<sub>0</sub> = 1</h2>
<p>The full chain now runs on the README pinch: the conserved state goes through PRIM, then HLLD (three directions, well-balanced), then RESIDUAL.</p>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:7.0pt;text-align:left;white-space:pre-wrap">{e(bench)}</div>
<p>Without equilibrium subtraction, the radial-momentum residual equals its exact truncation error. With r± = r_c ± Δr/2, P_T = P₀ − r²/8 and the cell values of P and B_φ:</p>
<p style="text-align:center">dm_r/dt = [r₊² + r₊r₋ + r₋² − 3r_c²]/(8 r_c) = Δr²/(32 r_c),</p>
<p>reproduced to 0.66 ulp of the term scale at every resolution. In well-balanced mode the residual is exactly 0.</p>

<h2 class="pb">3. Accuracy and conservation</h2>
<figure><img src="res_fig.png"><figcaption>Figure 1. Left: manufactured solution, errors against exact cell averages. Annulus L∞ and axis-grid L1 are second order; the axis cell alone (L∞ on the axis grid) is first order. Right: README pinch, the computed radial-momentum residual and the derived truncation error Δr²/(32 r_c).</figcaption></figure>
<ul>
<li><b>Order.</b> Annulus r ∈ [0.5, 1.5], L∞: {' → '.join(f(x,1) for x in T05[0]['errors'])}, order {T05[0]['orders'][-1]:.2f}. Axis grid, L1: {' → '.join(f(x,1) for x in T05[1]['errors'])}, order {T05[1]['orders'][-1]:.2f}.</li>
<li><b>The axis cell.</b> It carries an O(Δr) truncation error ({' → '.join(f(x,1) for x in T05[1]['linf_errors'])}). The radial term is exact for Π ∝ r but not for higher powers, and the one cell at r = 0 cannot be second order without axis-specific reconstruction. This is typical of finite volume at the axis and is reported here, not hidden. It affects only the cells at r = 0; the grid-averaged accuracy is second order.</li>
<li><b>Conservation (T02, T07).</b> Mass, axial momentum, energy and angular momentum balance their boundary fluxes to round-off (FP64 ≤ 7e-18 relative). On a rotating magnetised disc, dL/dt = {f(T07[0]['dL_dt'],10)} against a boundary torque of {f(T07[0]['boundary_torque'],10)}. The discretisation itself cannot create or destroy angular momentum, which matters for rotation-curve studies.</li>
</ul>

<h2 class="pb">4. Results: RES-01, all tests, both legs</h2>
<table class="camp"><tr><th>ID</th><th>Test and conditions</th><th>CPU leg</th><th>GPU leg</th><th>Final</th></tr>
{TABLE}
</table>
<p class="note"><b>Corrected in dry runs before the freeze, and recorded here:</b></p>
<ol class="note">
<li>FP32 lost 47 ulp to r/Δr cancellation when (r₊² − r₋²) was formed from rounded radii. The geometry is now precomputed on the host in double.</li>
<li>The first manufactured solution was singular at the axis. It was replaced by a regular one, and the comparison is now against exact cell averages instead of point values.</li>
<li>Using r̄ in the m_φ φ-term gave the axis cell an O(1) error. The φ-term now uses r_c, and angular-momentum conservation is unaffected.</li>
<li>Tolerances are expressed in units of u × the summed term magnitudes (the floating-point summation bound) instead of fixed relative numbers. A cell with zero term scale must have exactly zero error; this closes a NaN that could have hidden a failure.</li>
</ol>

<h2>5. Limitations and open regimes</h2>
<ul>
<li><b>The axis cell is first order</b> (section 3).</li>
<li><b>Without well-balancing</b>, a static equilibrium has an O(Δr²) residual (exactly Δr²/(32 r_c) for the README pinch, largest in the axis cell). Static or near-static configurations should be run in well-balanced mode.</li>
<li><b>No source terms beyond geometry.</b> Gravity, resistive heating and gyrotropic terms belong to their own Driver operators.</li>
<li><b>Scope.</b> These are kernel-level tests. Time integration (SSP-RK3), stage ordering and coupling with constrained transport belong to the Driver campaign.</li>
</ul>

<h2>6. Integrity and reproduction</h2>
<table><tr><th>File</th><th>SHA-256 (identical on both legs)</th></tr>{filerows}</table>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:9pt;text-align:left">sha256sum -c SHA256SUMS.txt<br>cd code &amp;&amp; python campaign_res01.py cpu &amp;&amp; python campaign_res01.py gpu<br>compute-sanitizer --tool memcheck  python sanitizer_target_res01.py<br>compute-sanitizer --tool racecheck python sanitizer_target_res01.py<br>python make_results_res01.py &nbsp;·&nbsp; python test_adapter_res.py &nbsp;·&nbsp; cd benchmark &amp;&amp; python readme_benchmark.py</div>
<p class="note">CPU leg {e(cenv['utc'])}, NumPy {cenv['numpy']}; GPU leg {e(genv['utc'])}, {e(genv['gpu'])}.</p>

<h2>7. Plugging into the Driver</h2>
<p>Slot 07 is <code>residual_slot(G, fluxes, prims, fields, R_eq=None)</code> in residual_driver_adapter.py. It takes the HLLD slot outputs, the PRIM output and the CT fields, asserts the certified source and build hashes, and is identical to the certified call (difference 0). The output order is ρ, ρv_r, ρv_φ, ρv_z, E.</p>
<p>For well-balanced runs, compute R_eq once from the equilibrium and pass it. Driver v3.1's <code>GeometricSources</code> must be removed when this slot is used: its hoop terms are contained here, in complete form, and applying both would count them twice.</p>
<p class="note">Credits: Mihai Alexandru Bucurenciu (ALADIN): the ALADIN Driver and its kernel architecture, the README Z-pinch benchmark, the well-balancing principle, the rotation-curve science goals that motivate exact angular-momentum conservation, and all GPU campaign runs. Kernel, oracle, campaign and evidence tooling developed with AI assistance (Claude, Anthropic). Independent review by a human third party is pending.</p>
<p class="note"><b>AI assistant Team:</b> SuperGrok, Claude, ChatGPT</p>
"""
css += "\n.hero .eq{font-size:11.5pt} .pill.red{background:#a33b3b} .camp td{font-size:8pt} .camp td.mono{font-size:7.4pt;line-height:1.35}"
open("/home/claude/respdf/report.html", "w").write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>ALADIN RESIDUAL v01</title><style>{css}</style></head><body>{body}</body></html>')
print("ok")
