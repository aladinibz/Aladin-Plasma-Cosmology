# ALADIN RESIDUAL v01 — kernel 07 (flux divergence + cylindrical sources)

RESIDUAL is the finite-volume right-hand side dU/dt for (ρ, m_r, m_φ, m_z, E) of the ALADIN native-cylindrical GPU MHD Driver.

- **Divergence and sources.** It takes the conservative divergence of the HLLD fluxes with exact cell volumes, and adds the full MHD geometric source for m_r: (ρv_φ² + P_T − B_φ²)/r. Driver v3.1's `GeometricSources` carried only the hydrodynamic part. Remove it when this slot is used.
- **Angular momentum.** m_φ is in angular-momentum form. The discrete angular momentum Σ V r̄ m_φ changes only by the boundary torque, to round-off.
- **Well-balanced mode.** R(U) − R(U_eq): the README Z-pinch is exactly static.
- **Refusal.** A non-finite input, ρ ≤ 0 or p < 0 gives flag 1 with NaN outputs. HLLD flag 32 and PRIM flags 1, 2 and 8 propagate.
- **Bit-identical.** GPU = CPU bit for bit. NVRTC is called directly (no CuPy `-ftz=true`) and the PTX is checked free of `.ftz`.

## Campaign RES-01

- **CPU leg:** 7 / 7 VERIFIED.
- **GPU leg (NVIDIA L4):** 11 / 11 VERIFIED, on the first frozen run.
- **compute-sanitizer:** memcheck 0 errors, racecheck 0 hazards.
- **README Z-pinch:** d(m_r)/dt equals the derived truncation error Δr²/(32 r_c) to round-off; in well-balanced mode it is exactly 0.
- **Convergence:** second order (1.99 on the annulus in L∞, 1.96 on the axis grid in L1). The axis cell itself is first order (stated in the report).

## Reproduce

```
sha256sum -c SHA256SUMS.txt
cd code && python campaign_res01.py cpu && python campaign_res01.py gpu
compute-sanitizer --tool memcheck  python sanitizer_target_res01.py
compute-sanitizer --tool racecheck python sanitizer_target_res01.py
python make_results_res01.py ; python test_adapter_res.py ; cd ../benchmark && python readme_benchmark.py
```

## Hashes

- Kernel source SHA-256: `51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4`
- Build SHA-256: `da42aadd13c49891906d6ebbf91ecb2954b8ca00a5ee7965c0a660fcaaf3682e`

Author: Mihai Alexandru Bucurenciu (ALADIN), ORCID 0009-0006-4457-557X.

AI assistant Team: SuperGrok, Claude, ChatGPT
