# -*- coding: utf-8 -*-
"""Independent oracle for RESIDUAL v01, written from the conservation laws in cylindrical coordinates (not from the kernel):
   dU/dt = -(1/V) * sum over faces of (area * flux)  + S,   with V = (r+^2 - r-^2)/2 dphi dz, radial face areas r+- dphi dz,
   phi faces dr dz, z faces (r+^2 - r-^2)/2 dphi;  m_phi via the angular momentum of the cell, L = rbar m_phi with rbar the
   volume-mean radius:  radial part d(rbar m_phi)/dt = -(1/V) sum(r_face * area * F); phi and z parts as for the other
   components (volume averages of (1/r) dPi/dphi and dPi/dz with mid-face fluxes).
Evaluated in 80-bit long double."""
import numpy as np
LD = np.longdouble


def residual(G, F_r, F_phi, F_z, rho, vr, vphi, vz, p, Br, Bphi, Bz, R_eq=None):
    g, nr, nph, nz = G.g, G.nr, G.nphi, G.nz
    rf = np.asarray(G.r_faces, LD)[g:g + nr + 1]; rm, rp = rf[:-1][:, None, None], rf[1:][:, None, None]
    dphi, dz = LD(G.dphi), LD(G.dz); dr = rp - rm
    V = (rp ** 2 - rm ** 2) / 2 * dphi * dz; rc = (rp + rm) / 2
    Fr, Fp, Fz = (np.asarray(x, LD) for x in (F_r, F_phi, F_z))
    I = (slice(g, g + nr), slice(g, g + nph), slice(g, g + nz))
    d, ur, up, uz, pp = (np.asarray(x, LD)[I] for x in (rho, vr, vphi, vz, p))
    bcr = (np.asarray(Br, LD)[g:g + nr + 1][:-1] + np.asarray(Br, LD)[g:g + nr + 1][1:])[:, g:g + nph, g:g + nz] / 2
    Bpi = np.asarray(Bphi, LD)[g:g + nr, g:g + nph + 1, g:g + nz]; bcp = (Bpi[:, :-1] + Bpi[:, 1:]) / 2
    Bzi = np.asarray(Bz, LD)[g:g + nr, g:g + nph, g:g + nz + 1]; bcz = (Bzi[:, :, :-1] + Bzi[:, :, 1:]) / 2
    out = np.zeros((5, nr, nph, nz), LD)
    for m in range(5):
        rbar = (rp ** 3 - rm ** 3) * 2 / (3 * (rp ** 2 - rm ** 2))
        if m == 2:
            radial = (rp * rp * Fr[m][1:] - rm * rm * Fr[m][:-1]) * dphi * dz / (V * rbar)
            az = (Fp[m][:, 1:] - Fp[m][:, :-1]) * dr * dz / V                       # volume average of (1/r) dPi/dphi, mid-face flux
        else:
            radial = (rp * Fr[m][1:] - rm * Fr[m][:-1]) * dphi * dz / V
            az = (Fp[m][:, 1:] - Fp[m][:, :-1]) * dr * dz / V
        ax = (Fz[m][:, :, 1:] - Fz[m][:, :, :-1]) * (rp ** 2 - rm ** 2) / 2 * dphi / V
        out[m] = -(radial + az + ax)
    PT = pp + (bcr ** 2 + bcp ** 2 + bcz ** 2) / 2
    out[1] += (d * up * up + PT - bcp * bcp) / rc
    if R_eq is not None: out -= np.asarray(R_eq, LD)
    return out


def refused(F_r, F_phi, F_z, rho, p, prims_finite, G):
    """flag-1 rule restated: any used flux component of the cell's 6 faces non-finite, or a cell input non-finite, rho <= 0, p < 0"""
    g, nr, nph, nz = G.g, G.nr, G.nphi, G.nz
    fr = np.isfinite(F_r[:5]).all(0); fp = np.isfinite(F_phi[:5]).all(0); fz = np.isfinite(F_z[:5]).all(0)
    ok = fr[:-1] & fr[1:] & fp[:, :-1] & fp[:, 1:] & fz[:, :, :-1] & fz[:, :, 1:]
    I = (slice(g, g + nr), slice(g, g + nph), slice(g, g + nz))
    ok &= prims_finite[I] & (rho[I] > 0) & (p[I] >= 0)
    return ~ok
