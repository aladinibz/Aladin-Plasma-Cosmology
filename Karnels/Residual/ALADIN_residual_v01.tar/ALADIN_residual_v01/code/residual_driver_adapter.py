# -*- coding: utf-8 -*-
"""Driver slot 07 RESIDUAL: maps the Driver's names onto the certified RESIDUAL v01 kernel (residual_v01.py, unchanged).
residual_slot(G, fluxes, prims, fields, R_eq=None): fluxes = {0: F_r, 1: F_phi, 2: F_z} as returned by the HLLD slots (hlld_r / hlld_phi /
hlld_z), prims = PRIM v01 output dict (rho, vr, vphi, vz, p), fields with 'Br', 'Bphi', 'Bz'.  Returns dict(dU (5, nr, nphi, nz), flags).
dU order: rho, rho_vr, rho_vphi, rho_vz, E.  Flag 1 = REFUSED (NaN): stop / roll back / recovery loop, as for HLLD flag 32 and PRIM 1/2/8.
Well-balanced runs (README Z-pinch): compute R_eq = residual_slot(G, fluxes_eq, prims_eq, fields_eq)['dU'] once and pass it.
Angular momentum: the conserved discrete total is sum V rbar m_phi with rbar the volume-mean radius (report section 1)."""
import residual_v01 as RS
CERTIFIED_SHA256 = "51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4"
CERTIFIED_BUILD_SHA256 = "da42aadd13c49891906d6ebbf91ecb2954b8ca00a5ee7965c0a660fcaaf3682e"
assert RS.SOURCE_SHA256 == CERTIFIED_SHA256, "residual_v01.py is not the certified kernel"
assert RS.BUILD_SHA256 == CERTIFIED_BUILD_SHA256, "residual_v01.py build options are not the certified ones"


def residual_slot(G, fluxes, prims, fields, R_eq=None, backend="cpu"):
    return RS.residual(G, fluxes[0], fluxes[1], fluxes[2], prims["rho"], prims["vr"], prims["vphi"], prims["vz"], prims["p"],
                       fields["Br"], fields["Bphi"], fields["Bz"], R_eq=R_eq, backend=backend)
