# -*- coding: utf-8 -*-
"""
ALADIN RESIDUAL v01 -- certification campaign RES-01.   python campaign_res01.py cpu | gpu
Frozen kernel (source + build hashes checked).  Thresholds PREDECLARED in THRESHOLDS.  Classes VERIFIED / LIMITATION /
INCONCLUSIVE / BLOCKER.  Writes res01_<leg>_results.json and res01_<leg>.log.
"""
import sys, os, time, json, copy, hashlib, platform, datetime, traceback, subprocess, warnings
import numpy as np
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "benchmark"))
import residual_v01 as RS
import numpy_oracle_res as O
import hlld_v05 as H
import prim_v01 as PR

FROZEN_SHA = "51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4"
FROZEN_BUILD = "da42aadd13c49891906d6ebbf91ecb2954b8ca00a5ee7965c0a660fcaaf3682e"
LD = np.longdouble

THRESHOLDS = dict(
    T01_oracle_ulps=16.0,
    T02_conservation_fp64=1e-13, T02_conservation_fp32=1e-5,
    T03_freestream_ulps=16.0,
    T04_pinch_formula_ulps=64.0, T04_pinch_other=0.0, T04_pinch_wb=0.0,
    T05_order_annulus_linf=1.9, T05_order_axis_l1=1.8,
    T06_refusal_mismatch=0.0,
    T07_disc_L_conservation=1e-13,
    G1_gpu_cpu_bitwise=0.0, G2_determinism=0.0, G3_gpu_oracle_ulps=16.0, G6_ieee_selftest=1.0,
)

LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
BACKEND = "cupy" if LEG == "gpu" else "cpu"
LOG = None
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True)
    if LOG: LOG.write(s + "\n"); LOG.flush()
if BACKEND == "cupy": import cupy as cp
host = lambda x: x.get() if hasattr(x, "get") else x

def res(G, F, prims, B, R_eq=None, backend=None):
    bk = backend or BACKEND
    if bk == "cupy":
        Gd = copy.copy(G); Gd.xp = cp
        r = RS.residual(Gd, *[cp.asarray(x) for x in list(F) + list(prims) + list(B)], R_eq=None if R_eq is None else cp.asarray(R_eq), backend="cupy")
    else:
        r = RS.residual(G, *F, *prims, *B, R_eq=R_eq, backend="cpu")
    return {k: host(v) for k, v in r.items()}

def rand_case(G, rng, dt=np.float64, periodic=False):
    sh = G.shape("cell")
    F = [rng.normal(size=G.shape(k)).astype(dt) for k in ("F_r", "F_phi", "F_z")]
    if periodic: F[1][:, :, -1] = F[1][:, :, 0]; F[2][:, :, :, -1] = F[2][:, :, :, 0]
    prims = [rng.uniform(.5, 2, sh).astype(dt), *[rng.normal(size=sh).astype(dt) for _ in range(3)], rng.uniform(.1, 1, sh).astype(dt)]
    B = [rng.normal(size=G.shape(k)).astype(dt) for k in ("Br", "Bphi", "Bz")]
    return F, prims, B


def ulps(err, S, u):
    """max |err| / (u S); a cell with S = 0 must have err = 0 exactly (else +Inf).  Never NaN."""
    err = np.abs(np.asarray(err, LD)); S = np.asarray(S, LD); pos = S > 0
    bad0 = bool(np.any(err[~pos] != 0)); r = float(np.max(err[pos] / (LD(u) * S[pos]))) if pos.any() else 0.0
    return float("inf") if bad0 else r


def term_scale(G, F, prims, B, R_eq=None):
    """per cell and component: sum of the magnitudes of every term the kernel adds (radial, phi, z flux terms, source, R_eq),
    in long double.  The standard floating-point summation bound makes |error| <= c u * term_scale for a small c."""
    g, nr, nph, nz = G.g, G.nr, G.nphi, G.nz
    rf = np.asarray(G.r_faces, LD)[g:g + nr + 1]; rm, rp = rf[:-1][:, None, None], rf[1:][:, None, None]; rc = (rp + rm) / 2; A = (rp + rm) * (rp - rm) / 2
    rb = (rp ** 3 - rm ** 3) * 2 / (3 * (rp ** 2 - rm ** 2))
    Fr, Fp, Fz = (np.abs(np.asarray(x, LD)) for x in F); out = np.zeros((5, nr, nph, nz), LD)
    for m in range(5):
        rad = (rp * rp * Fr[m][1:] + rm * rm * Fr[m][:-1]) / (rb * A) if m == 2 else (rp * Fr[m][1:] + rm * Fr[m][:-1]) / A
        out[m] = rad + (Fp[m][:, 1:] + Fp[m][:, :-1]) / (rc * LD(G.dphi)) + (Fz[m][:, :, 1:] + Fz[m][:, :, :-1]) / LD(G.dz)
    I = (slice(g, g + nr), slice(g, g + nph), slice(g, g + nz))
    d, up, pp = (np.asarray(x, LD)[I] for x in (prims[0], prims[2], prims[4]))
    bcr = (np.asarray(B[0], LD)[g:g + nr + 1][:-1] + np.asarray(B[0], LD)[g:g + nr + 1][1:])[:, g:g + nph, g:g + nz] / 2
    Bpi = np.asarray(B[1], LD)[g:g + nr, g:g + nph + 1, g:g + nz]; bcp = (Bpi[:, :-1] + Bpi[:, 1:]) / 2
    Bzi = np.asarray(B[2], LD)[g:g + nr, g:g + nph, g:g + nz + 1]; bcz = (Bzi[:, :, :-1] + Bzi[:, :, 1:]) / 2
    out[1] += (d * up * up + np.abs(pp) + (bcr ** 2 + bcp ** 2 + bcz ** 2) / 2 + bcp ** 2) / rc
    if R_eq is not None: out += np.abs(np.asarray(R_eq, LD))
    return out

# ------------------------------------------------------------------ tests
def T01():
    """kernel vs the 80-bit oracle, error in units of u x the summed magnitudes of the terms (floating-point summation bound)"""
    rng = np.random.default_rng(301); w = {np.float64: 0.0, np.float32: 0.0}
    for dt in (np.float64, np.float32):
        u = float(np.finfo(dt).eps) / 2
        for rmin, s in ((0.0, (12, 10, 8)), (0.4, (9, 14, 6)), (0.0, (1, 3, 2)), (2.0, (20, 8, 10))):
            G = RS.Grid(*s, rmin, rmin + 1.3, dtype=dt); F, pr, B = rand_case(G, rng, dt)
            for use_eq in (False, True):
                Req = rng.normal(size=G.shape("dU")).astype(dt) if use_eq else None
                r = res(G, F, pr, B, Req); o = O.residual(G, *F, *pr, *B, R_eq=Req); S = term_scale(G, F, pr, B, Req)
                w[dt] = max(w[dt], ulps(r["dU"].astype(LD) - o, S, u))
    return dict(conditions="random fluxes, primitives and faces; axis, annulus, 1-cell-wide and r in [2, 3.3] grids; R_eq on/off; vs 80-bit oracle (area/volume form); "
                           "error / (u * sum of term magnitudes)", fp64_ulps=w[np.float64], fp32_ulps=w[np.float32]), \
        [("FP64 max error in units of u x term scale", w[np.float64], "<=", THRESHOLDS["T01_oracle_ulps"]), ("FP32 max error in units of u x term scale", w[np.float32], "<=", THRESHOLDS["T01_oracle_ulps"])]

def T02():
    """exact discrete conservation: sum V dU = -(boundary fluxes) for rho, m_z, E; angular momentum sum V r_c dm_phi = -(r^2 boundary flux)"""
    rng = np.random.default_rng(302); w = {np.float64: 0.0, np.float32: 0.0}; rows = []
    for dt in (np.float64, np.float32):
        for rmin in (0.0, 0.5):
            G = RS.Grid(16, 12, 10, rmin, rmin + 1.0, dtype=dt); F, pr, B = rand_case(G, rng, dt, periodic=True); g = G.g
            r = res(G, F, pr, B); dU = r["dU"].astype(LD)
            rf = np.asarray(G.r_faces, LD)[g:g + G.nr + 1]; rm, rp = rf[:-1], rf[1:]; V = ((rp ** 2 - rm ** 2) / 2)[:, None, None] * LD(G.dphi) * LD(G.dz)
            rc = ((rp ** 3 - rm ** 3) * 2 / (3 * (rp ** 2 - rm ** 2)))[:, None, None]; Fr = F[0].astype(LD); dA = LD(G.dphi) * LD(G.dz)   # rbar: discrete L = sum V rbar m_phi
            for m, name in ((0, "mass"), (3, "z-momentum"), (4, "energy"), (2, "angular momentum (sum V rbar m_phi)")):
                if m == 2:
                    total = np.sum(V * rc * dU[m]); bnd = (rf[-1] ** 2 * Fr[m][-1].sum() - rf[0] ** 2 * Fr[m][0].sum()) * dA
                    scale = np.sum(np.abs(V * rc) * (np.abs(dU[m]) + 1))
                else:
                    total = np.sum(V * dU[m]); bnd = (rf[-1] * Fr[m][-1].sum() - rf[0] * Fr[m][0].sum()) * dA
                    zf = F[2][m].astype(LD); area_z = ((rp ** 2 - rm ** 2) / 2)[:, None] * LD(G.dphi)
                    bnd += np.sum(area_z * (zf[:, :, -1] - zf[:, :, 0]))           # zero by periodicity, kept explicit
                    scale = np.sum(np.abs(V) * (np.abs(dU[m]) + 1))
                rel = float(abs(total + bnd) / scale); w[dt] = max(w[dt], rel); rows.append(dict(dtype=np.dtype(dt).name, rmin=rmin, quantity=name, rel_imbalance=rel))
    return dict(conditions="random fluxes, periodic in phi and z; inner face r = 0 (axis) or 0.5; imbalance relative to the summed magnitudes", rows=rows), \
        [("FP64 max relative imbalance", w[np.float64], "<=", THRESHOLDS["T02_conservation_fp64"]), ("FP32 max relative imbalance", w[np.float32], "<=", THRESHOLDS["T02_conservation_fp32"])]

def hlld_fluxes(G, prims, B, W_eq=None, W_eq_faces=None):
    Gh = H.Grid(G.nr, G.nphi, G.nz, G.rmin, G.rmin + G.nr * G.dr, zlen=G.nz * G.dz)
    F, fl = H.fluxes(Gh, *prims, *B, W_eq=W_eq, W_eq_faces=W_eq_faces); return [F[0], F[1], F[2]], fl, Gh

def T03():
    """free-stream: uniform rho, p, B = (0, 0, Bz), v = 0 -> dU = 0 to round-off (the P_T/r source balances the radial divergence)"""
    worst = 0.0; rows = []
    for rmin in (0.0, 0.3, 5.0):
        G = RS.Grid(24, 8, 6, rmin, rmin + 1.0); sh = G.shape("cell"); one = np.ones(sh); z = np.zeros(sh)
        B = [np.zeros(G.shape("Br")), np.zeros(G.shape("Bphi")), np.full(G.shape("Bz"), 0.7)]; prims = [one * 1.3, z, z, z, one * 0.9]
        F, fl, _ = hlld_fluxes(G, prims, B); r = res(G, F, prims, B); S = term_scale(G, F, prims, B)
        rel = ulps(r["dU"], S, np.finfo(np.float64).eps / 2); worst = max(worst, rel)
        rows.append(dict(rmin=rmin, max_abs_dU=float(np.abs(r["dU"]).max()), rel=rel))
    return dict(conditions="uniform state with axial field, HLLD v05.1 fluxes; axis, annulus and r in [5, 6]; |dU| / (u * term scale)", rows=rows), \
        [("max |dU| in units of u x term scale", worst, "<=", THRESHOLDS["T03_freestream_ulps"])]

def pinch(nr, nphi=8, nz=4):
    G = RS.Grid(nr, nphi, nz, 0.0, 1.0); g = G.g; rc = G.r_centers; rf = G.r_faces; sh = G.shape("cell")
    Bp = np.zeros(G.shape("Bphi")); Bp[:] = (0.5 * rc)[:, None, None]; B = [np.zeros(G.shape("Br")), Bp, np.zeros(G.shape("Bz"))]
    p_ex = (1 - 0.25 * rc ** 2)[:, None, None] * np.ones(sh); one = np.ones(sh); z = np.zeros(sh)
    Gp = PR.Grid(nr, nphi, nz, 0.0, 1.0); U = PR.conserved(Gp, one, z, z, z, p_ex, *B)
    pr = PR.primitives(Gp, U["rho"], U["m_r"], U["m_phi"], U["m_z"], U["E"], *B); prims = [pr[k] for k in ("rho", "vr", "vphi", "vz", "p")]
    Gh = H.Grid(nr, nphi, nz, 0.0, 1.0); W8 = H.pack(Gh, one, z, z, z, p_ex, *B); rfi = rf[g:g + nr + 1][:, None, None]
    Wf = np.zeros(Gh.shape("F_r")); Wf[0] = 1; Wf[4] = 1 - 0.25 * rfi ** 2; Wf[6] = 0.5 * rfi
    F, fl = H.fluxes(Gh, *prims, *B, W_eq=W8, W_eq_faces={0: Wf})
    return G, [F[0], F[1], F[2]], prims, B

def T04():
    """README Z-pinch through PRIM -> HLLD -> RESIDUAL: the m_r residual equals the exact truncation error dr^2 / (32 r_c);
    every other component is exactly 0; the well-balanced mode (R_eq of the equilibrium) gives exactly 0"""
    worst = 0.0; other = 0.0; wb = 0.0; rows = []
    for nr in (16, 32, 64, 128):
        G, F, prims, B = pinch(nr); r = res(G, F, prims, B); g = G.g
        rc = G.r_centers[g:g + nr][:, None, None]; pred = G.dr ** 2 / (32 * rc)
        S = term_scale(G, F, prims, B)[1]; e = ulps(r["dU"][1].astype(LD) - LD(1) * pred, S, np.finfo(np.float64).eps / 2); worst = max(worst, e); other = max(other, float(np.abs(r["dU"][[0, 2, 3, 4]]).max()))
        r2 = res(G, F, prims, B, R_eq=r["dU"]); wb = max(wb, float(np.abs(r2["dU"]).max()))
        rows.append(dict(nr=nr, max_dmr=float(np.abs(r["dU"][1]).max()), L1_dmr=float(np.abs(r["dU"][1]).mean()), dev_from_formula_ulps=e, rel_dev_from_formula=float(np.max(np.abs(r["dU"][1] - pred) / pred))))
    return dict(conditions="normalised Z-pinch B_phi = r/2, P = 1 - r^2/4, mu0 = 1; nr = 16..128 axis grids; HLLD well-balanced with exact face values; "
                           "derivation: residual = [r+^2 + r+ r- + r-^2 - 3 r_c^2] / (8 r_c) = dr^2 / (32 r_c); deviation measured in units of u x term scale (includes the rounding of PRIM and HLLD upstream)", rows=rows), \
        [("max deviation of dm_r/dt from dr^2/(32 r_c), units of u x term scale", worst, "<=", THRESHOLDS["T04_pinch_formula_ulps"]), ("max |dU| of rho, m_phi, m_z, E", other, "<=", THRESHOLDS["T04_pinch_other"]),
         ("well-balanced mode max |dU|", wb, "<=", THRESHOLDS["T04_pinch_wb"])]

def mms(G):
    """smooth manufactured face fluxes and cell states; exact continuous residual at cell centres"""
    # regular at the axis (r F_r -> 0, dF_phi/dphi -> 0):  F_r = r sin(a r + phi) cos(2 pi z) + b r^2,  F_phi = r cos(phi + c r)(1 + z) + r,
    # F_z = r sin(2 pi z + phi) + c   (derivatives by hand; run-0 dry run used F_r(0) != 0, a singular manufactured solution)
    P2 = 2 * np.pi
    def par(m): return 0.3 + 0.1 * m, 0.7 - 0.05 * m, 1.1 + 0.2 * m
    def fr(m, r, ph, z): a, b, c = par(m); return r * np.sin(a * r + ph) * np.cos(P2 * z) + b * r ** 2
    def fp(m, r, ph, z): a, b, c = par(m); return r * np.cos(ph + c * r) * (1 + z) + r
    def fz(m, r, ph, z): a, b, c = par(m); return r * np.sin(P2 * z + ph) + c
    def exact_m(m, r, ph, z):
        a, b, c = par(m); Fr_ = fr(m, r, ph, z); dFr = (np.sin(a * r + ph) + r * a * np.cos(a * r + ph)) * np.cos(P2 * z) + 2 * b * r
        radial = (2 * Fr_ / r + dFr) if m == 2 else (Fr_ / r + dFr)
        return -(radial + (-r * np.sin(ph + c * r) * (1 + z)) / r + P2 * r * np.cos(P2 * z + ph))
    exact = {m: (lambda r, ph, z, m=m: exact_m(m, r, ph, z)) for m in range(5)}
    fl = {m: [(lambda r, ph, z, m=m: fr(m, r, ph, z)), (lambda r, ph, z, m=m: fp(m, r, ph, z)), (lambda r, ph, z, m=m: fz(m, r, ph, z))] for m in range(5)}
    g = G.g; rf = G.r_faces[g:g + G.nr + 1]; rc = G.r_centers[g:g + G.nr]; pf = G.phi_f[g:g + G.nphi + 1]; pc = G.phi_c[g:g + G.nphi]; zf = G.z_f[g:g + G.nz + 1]; zc = G.z_c[g:g + G.nz]
    F = [np.zeros(G.shape(k)) for k in ("F_r", "F_phi", "F_z")]; ex = np.zeros(G.shape("dU"))
    # reference = the exact CELL AVERAGE (volume-weighted, r dr dphi dz) of the continuous residual (m_phi: of its
    # angular-momentum form (1/r^2) d(r^2 F_r)/dr + ...).  4-point Gauss-Legendre per direction.
    xg, wg = np.polynomial.legendre.leggauss(4)
    rm, rp = rf[:-1], rf[1:]; rq = 0.5 * (rp + rm)[:, None] + 0.5 * (rp - rm)[:, None] * xg[None, :]; wr = 0.5 * (rp - rm)[:, None] * wg[None, :] * rq
    pq = pc[:, None] + 0.5 * G.dphi * xg[None, :]; wp = 0.5 * G.dphi * wg; zq = zc[:, None] + 0.5 * G.dz * xg[None, :]; wz = 0.5 * G.dz * wg
    Vr = wr.sum(1); rbar = (2.0 / 3.0) * (rp ** 3 - rm ** 3) / (rp ** 2 - rm ** 2)
    for m in range(5):
        R_, P_, Z_ = np.meshgrid(rf, pc, zc, indexing="ij"); F[0][m] = fl[m][0](R_, P_, Z_)
        R_, P_, Z_ = np.meshgrid(rc, pf, zc, indexing="ij"); F[1][m] = fl[m][1](R_, P_, Z_)
        R_, P_, Z_ = np.meshgrid(rc, pc, zf, indexing="ij"); F[2][m] = fl[m][2](R_, P_, Z_)
        acc = np.zeros(G.shape("dU")[1:])
        for a in range(4):
            for b in range(4):
                for c_ in range(4):
                    val = exact[m](rq[:, a][:, None, None], pq[:, b][None, :, None], zq[:, c_][None, None, :])
                    acc += wr[:, a][:, None, None] * wp[b] * wz[c_] * val
        ex[m] = acc / (Vr[:, None, None] * G.dphi * G.dz)
    sh = G.shape("cell"); prims = [np.ones(sh), np.zeros(sh), np.zeros(sh), np.zeros(sh), np.zeros(sh)]      # source m_r = 0 here
    B = [np.zeros(G.shape(k)) for k in ("Br", "Bphi", "Bz")]
    return F, prims, B, ex

def T05():
    rows = []; orders = {}
    for label, rmin, norm in (("annulus r in [0.5, 1.5]", 0.5, "linf"), ("axis grid r in [0, 1]", 0.0, "l1")):
        errs = []; linf_all = []
        for n in (16, 32, 64, 128):
            G = RS.Grid(n, n, n // 2, rmin, rmin + 1.0); F, prims, B, ex = mms(G); r = res(G, F, prims, B)
            d = np.abs(r["dU"] - ex); errs.append(float(d.max() if norm == "linf" else d.mean())); linf_all.append(float(d.max()))
        o = [float(np.log2(errs[i] / errs[i + 1])) for i in range(3)]; orders[label] = o[-1]; rows.append(dict(grid=label, norm=norm, errors=errs, orders=o, linf_errors=linf_all,
                                                                                  note="axis grid: the axis cell carries an O(dr) truncation error (radial term exact only for Pi ~ r), so L_inf is first order there; L1 is second order"))
    return dict(conditions="manufactured smooth fluxes regular at the axis (all 5 components, m_phi in angular-momentum form) evaluated at face centres; error vs the exact CELL AVERAGE of the continuous residual (Gauss-Legendre); n = 16..128", rows=rows), \
        [("final order, annulus, L_inf", orders["annulus r in [0.5, 1.5]"], ">=", THRESHOLDS["T05_order_annulus_linf"]),
         ("final order, axis grid, L1", orders["axis grid r in [0, 1]"], ">=", THRESHOLDS["T05_order_axis_l1"])]

def T06():
    rng = np.random.default_rng(306); mism = 0; cases = 0
    for dt in (np.float64, np.float32):
        G = RS.Grid(8, 8, 6, 0.0, 1.0, dtype=dt); F0, P0, B0 = rand_case(G, rng, dt); r0 = res(G, F0, P0, B0)
        def run_case(F, P_, B, Req=None, exp_extra=None):
            r = res(G, F, P_, B, Req); pf = np.ones(G.shape("cell"), bool)
            for x in P_: pf &= np.isfinite(x)
            Bok = np.ones(G.shape("cell"), bool)
            Bok &= np.isfinite(B[0][:-1]) & np.isfinite(B[0][1:]) & np.isfinite(B[1][:, :-1]) & np.isfinite(B[1][:, 1:]) & np.isfinite(B[2][:, :, :-1]) & np.isfinite(B[2][:, :, 1:])
            exp = O.refused(F[0], F[1], F[2], P_[0], P_[4], pf & Bok, G)
            if Req is not None: exp |= ~np.isfinite(Req).all(0)
            bad = int(((r["flags"] == 1) != exp).sum()) + int((~np.isnan(r["dU"][:, exp])).sum())
            bad += int(((r["dU"] != r0["dU"]) & ~np.isnan(r["dU"]))[:, ~exp].sum()) if Req is None else 0
            return bad
        for which, idx in ((0, (1, 3, 2, 2)), (1, (4, 2, 0, 3)), (2, (0, 5, 5, 6)), (0, (2, 8, 7, 5))):        # flux faces (incl. outer r face)
            F = [x.copy() for x in F0]; F[which][idx] = np.nan; mism += run_case(F, P0, B0); cases += 1
        for v, val in ((0, -1.0), (0, 0.0), (4, -1e-3), (2, np.inf), (3, np.nan)):
            P_ = [x.copy() for x in P0]; P_[v][4, 5, 3] = val; mism += run_case(F0, P_, B0); cases += 1
        B = [x.copy() for x in B0]; B[1][4, 5, 4] = np.nan; mism += run_case(F0, P0, B); cases += 1
        Req = np.zeros(G.shape("dU"), dt); Req[3, 2, 2, 2] = np.inf; r0e = res(G, F0, P0, B0, Req); ex = np.zeros(G.shape("interior"), bool); ex[2, 2, 2] = True
        mism += int(((r0e["flags"] == 1) != ex).sum()); cases += 1
    return dict(conditions="NaN / Inf in single flux faces (r, phi, z incl. the outer boundary face), primitives (rho = -1, 0; p < 0; Inf; NaN), one CT face, R_eq; FP64 + FP32; "
                           "expected set from the restated rule; all other cells bit-identical", cases=cases), \
        [("mismatches (flag set, NaN outputs, changes elsewhere)", float(mism), "<=", THRESHOLDS["T06_refusal_mismatch"])]

def T07():
    """a rotating, magnetised disc (galactic-rotation-like): v_phi = r / (1 + r^2), B_phi = 0.3 r, B_z = 1, random perturbation;
    HLLD v05.1 fluxes; total angular momentum changes only by the outer-boundary torque, to round-off"""
    rng = np.random.default_rng(307); worst = 0.0; rows = []
    for rmin in (0.0, 0.2):
        G = RS.Grid(32, 24, 8, rmin, rmin + 2.0); g = G.g; sh = G.shape("cell"); rc = G.r_centers[:, None, None] * np.ones(sh)
        prims = [1 + 0.1 * rng.normal(size=sh) ** 2, 0.05 * rng.normal(size=sh), rc / (1 + rc ** 2) + 0.02 * rng.normal(size=sh), 0.05 * rng.normal(size=sh), 0.5 + 0.1 * rng.uniform(size=sh)]
        Bp = np.zeros(G.shape("Bphi")); Bp[:] = (0.3 * G.r_centers)[:, None, None]; B = [0.05 * rng.normal(size=G.shape("Br")), Bp + 0.02 * rng.normal(size=G.shape("Bphi")), 1 + 0.02 * rng.normal(size=G.shape("Bz"))]
        # the phi / z closure: the last phi and z face fluxes are set equal to the first (periodic flux), so they telescope
        F, fl, _ = hlld_fluxes(G, prims, B); F[1][:, :, -1] = F[1][:, :, 0]; F[2][:, :, :, -1] = F[2][:, :, :, 0]
        r = res(G, F, prims, B); dU = r["dU"].astype(LD)
        rf = np.asarray(G.r_faces, LD)[g:g + G.nr + 1]; rm, rp = rf[:-1], rf[1:]; V = ((rp ** 2 - rm ** 2) / 2)[:, None, None] * LD(G.dphi) * LD(G.dz); rcl = ((rp ** 3 - rm ** 3) * 2 / (3 * (rp ** 2 - rm ** 2)))[:, None, None]
        dL = np.sum(V * rcl * dU[2]); torque = -(rf[-1] ** 2 * F[0][2][-1].astype(LD).sum() - rf[0] ** 2 * F[0][2][0].astype(LD).sum()) * LD(G.dphi) * LD(G.dz)
        rel = float(abs(dL - torque) / np.sum(np.abs(V * rcl * dU[2]))); worst = max(worst, rel); rows.append(dict(rmin=rmin, dL_dt=float(dL), boundary_torque=float(torque), rel=rel))
    return dict(conditions="rotating magnetised disc, 32 x 24 x 8, axis and inner hole r = 0.2; periodic phi / z flux closure; dL/dt vs boundary torque", rows=rows), \
        [("relative angular-momentum imbalance", worst, "<=", THRESHOLDS["T07_disc_L_conservation"])]

def G6():
    ok = float(RS.gpu_ieee_selftest()); m32 = RS._gpu_mod(np.float32); m64 = RS._gpu_mod(np.float64)
    return dict(conditions="FP32 subnormal *, +, / bit-identical to IEEE through the kernel's own NVRTC path; PTX free of .ftz", options=list(m32.options)), \
        [("FP32 subnormal arithmetic bit-identical to IEEE", ok, "==", THRESHOLDS["G6_ieee_selftest"]), ("'.ftz' in RESIDUAL PTX", float(m32.ptx_ftz_count + m64.ptx_ftz_count), "<=", 0.0)]

def G1():
    rng = np.random.default_rng(401); diff = 0; tot = 0
    for dt in (np.float64, np.float32):
        for rmin, s, scale in ((0.0, (13, 9, 7), 1.0), (0.4, (40, 33, 17), 1.0), (0.0, (1, 3, 2), 1.0), (0.0, (12, 10, 8), 1e-30 if dt == np.float32 else 1e-300)):
            G = RS.Grid(*s, rmin, rmin + 1.1, dtype=dt); F, pr, B = rand_case(G, rng, dt); F = [(x * scale).astype(dt) for x in F]
            F[0][1, 0, 0, 0] = np.nan; pr[0][3, 3, 3] = -1
            for Req in (None, rng.normal(size=G.shape("dU")).astype(dt)):
                a = res(G, F, pr, B, Req, backend="cupy"); c = res(G, F, pr, B, Req, backend="cpu")
                for k in a:
                    x, y = a[k], c[k]; d = ((x != y) & ~(np.isnan(x) & np.isnan(y))) if x.dtype.kind == "f" else (x != y); diff += int(d.sum()); tot += x.size
    return dict(conditions="4 grids incl. partial blocks and a subnormal-scale case, refusal paths, R_eq on/off, FP64 + FP32", values=tot, differing=diff), \
        [("GPU values differing from CPU", float(diff), "<=", THRESHOLDS["G1_gpu_cpu_bitwise"])]

def G2():
    rng = np.random.default_rng(402); G = RS.Grid(40, 32, 24, 0.0, 1.0); F, pr, B = rand_case(G, rng); r0 = res(G, F, pr, B, backend="cupy"); d = 0
    for _ in range(3):
        r = res(G, F, pr, B, backend="cupy"); d += int((r["dU"] != r0["dU"]).sum()) + int((r["flags"] != r0["flags"]).sum())
    return dict(conditions="3 repeated launches"), [("differing values", float(d), "<=", THRESHOLDS["G2_determinism"])]

def G3():
    rng = np.random.default_rng(403); w = 0.0
    for rmin, s in ((0.0, (12, 10, 8)), (0.4, (9, 14, 6))):
        G = RS.Grid(*s, rmin, rmin + 1.3); F, pr, B = rand_case(G, rng); r = res(G, F, pr, B, backend="cupy"); o = O.residual(G, *F, *pr, *B)
        w = max(w, ulps(r["dU"].astype(LD) - o, term_scale(G, F, pr, B), np.finfo(np.float64).eps / 2))
    return dict(conditions="T01 FP64 through CUDA"), [("FP64 max error vs oracle in units of u x term scale (GPU)", w, "<=", THRESHOLDS["G3_gpu_oracle_ulps"])]

CPU_TESTS = [T01, T02, T03, T04, T05, T06, T07]
GPU_TESTS = [G6, G1, G2, G3]
OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def env():
    e = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, backend=BACKEND, platform=platform.platform(),
             python=sys.version.split()[0], numpy=np.__version__, cpu_count=os.cpu_count(), longdouble=str(np.finfo(np.longdouble).eps))
    try: e["gxx"] = subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    except Exception as x: e["gxx"] = repr(x)
    if BACKEND == "cupy":
        e["cupy"] = cp.__version__; e["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); e["cuda_runtime"] = cp.cuda.runtime.runtimeGetVersion()
    return e

if __name__ == "__main__":
    LOG = open(os.path.join(HERE, f"res01_{LEG}.log"), "w")
    files = ["residual_v01.py", "numpy_oracle_res.py", "campaign_res01.py", "benchmark/hlld_v05.py", "benchmark/prim_v01.py"]
    R = dict(campaign="RES-01", kernel="ALADIN RESIDUAL v01", env=env(), kernel_source_sha256=RS.SOURCE_SHA256, frozen_sha256=FROZEN_SHA, build_sha256=RS.BUILD_SHA256,
             frozen_build_sha256=FROZEN_BUILD, gpu_options=list(RS.GPU_OPTIONS), cpu_flags=list(RS.CPU_FLAGS), gpu_loader=RS.GPU_LOADER,
             file_sha256={f: sha(os.path.join(HERE, f)) for f in files}, thresholds=THRESHOLDS, tests=[])
    log(f"RES-01 leg={LEG} backend={BACKEND} kernel sha {RS.SOURCE_SHA256} build sha {RS.BUILD_SHA256}")
    if RS.SOURCE_SHA256 != FROZEN_SHA or RS.BUILD_SHA256 != FROZEN_BUILD:
        log("BLOCKER: kernel source or build does not match the frozen hashes"); R["tests"].append(dict(id="FREEZE", cls="BLOCKER", passed=False, detail="hash mismatch"))
    tests = CPU_TESTS + (GPU_TESTS if LEG == "gpu" and RS.has_gpu() else [])
    for f in tests:
        t0 = time.time(); rec = dict(id=f.__name__)
        try:
            data, checks = f(); rec["data"] = data
            rec["checks"] = [dict(name=n, measured=float(v), op=op, threshold=float(th), passed=bool(OPS[op](float(v), float(th)))) for n, v, op, th in checks]
            rec["passed"] = all(c["passed"] for c in rec["checks"]); rec["cls"] = "VERIFIED" if rec["passed"] else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["passed"] = False; rec["exception"] = traceback.format_exc()
        rec["seconds"] = round(time.time() - t0, 2); R["tests"].append(rec)
        log(f"{rec['id']:4s} {rec['cls']:10s} {rec['seconds']:8.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec.get("checks", [])))
        if "exception" in rec: log(rec["exception"])
    if LEG == "gpu" and not RS.has_gpu():
        for f in GPU_TESTS: R["tests"].append(dict(id=f.__name__, cls="INCONCLUSIVE", passed=None, detail="no GPU on this leg"))
    counts = {}
    for t in R["tests"]: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    R["summary"] = counts; log("SUMMARY", counts)
    json.dump(R, open(os.path.join(HERE, f"res01_{LEG}_results.json"), "w"), indent=1, default=float)
