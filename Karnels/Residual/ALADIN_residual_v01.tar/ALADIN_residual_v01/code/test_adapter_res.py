import numpy as np, residual_v01 as RS, residual_driver_adapter as A
rng = np.random.default_rng(5); G = RS.Grid(9, 8, 6, 0.0, 1.0); sh = G.shape("cell")
F = {d: rng.normal(size=G.shape(k)) for d, k in enumerate(("F_r", "F_phi", "F_z"))}
pr = dict(rho=rng.uniform(.5, 2, sh), vr=rng.normal(size=sh), vphi=rng.normal(size=sh), vz=rng.normal(size=sh), p=rng.uniform(.1, 1, sh))
fl = dict(Br=rng.normal(size=G.shape("Br")), Bphi=rng.normal(size=G.shape("Bphi")), Bz=rng.normal(size=G.shape("Bz")))
a = A.residual_slot(G, F, pr, fl); b = RS.residual(G, F[0], F[1], F[2], pr["rho"], pr["vr"], pr["vphi"], pr["vz"], pr["p"], fl["Br"], fl["Bphi"], fl["Bz"])
d = max(float(np.abs(a[k] - b[k]).max()) for k in a)
print("ADAPTER EQUIVALENCE max |slot - certified| =", d, "-> PASS" if d == 0 else "-> FAIL")
