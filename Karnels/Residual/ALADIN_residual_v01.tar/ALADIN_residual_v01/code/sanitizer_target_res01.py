# -*- coding: utf-8 -*-
"""RES-01 sanitizer target: residual() on 6 grids (axis, annulus, 1-cell-wide, partial blocks), FP64 + FP32, R_eq on / off,
refusal paths (NaN fluxes incl. boundary faces, rho <= 0, p < 0, NaN CT face, Inf R_eq).   python sanitizer_target_res01.py [cpu]"""
import sys, os, copy, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import residual_v01 as RS
BK = "cpu" if (len(sys.argv) > 1 and sys.argv[1] == "cpu") else "cupy"
if BK == "cupy": import cupy as cp
T = (lambda x: cp.asarray(x)) if BK == "cupy" else (lambda x: x)
H = lambda x: x.get() if hasattr(x, "get") else x
rng = np.random.default_rng(9); seen = {}
for dt in (np.float64, np.float32):
    for rmin, s in ((0.0, (7, 10, 5)), (0.4, (13, 18, 11)), (0.0, (1, 4, 2)), (0.4, (31, 6, 9)), (0.0, (40, 33, 17)), (0.5, (1, 1, 1))):
        G = RS.Grid(*s, rmin, rmin + 1.3, dtype=dt); Gk = G
        if BK == "cupy": Gk = copy.copy(G); Gk.xp = cp
        sh = G.shape("cell"); F = [rng.normal(size=G.shape(k)).astype(dt) for k in ("F_r", "F_phi", "F_z")]
        pr = [rng.uniform(.5, 2, sh).astype(dt), *[rng.normal(size=sh).astype(dt) for _ in range(3)], rng.uniform(.1, 1, sh).astype(dt)]
        B = [rng.normal(size=G.shape(k)).astype(dt) for k in ("Br", "Bphi", "Bz")]
        F[0][1][rng.uniform(size=F[0][1].shape) < 0.02] = np.nan; F[2][4][rng.uniform(size=F[2][4].shape) < 0.02] = np.inf
        bad = rng.uniform(size=sh); pr[0][bad < 0.01] = -1; pr[4][(bad > 0.01) & (bad < 0.02)] = -0.5; B[1][rng.uniform(size=G.shape("Bphi")) < 0.01] = np.nan
        for use_eq in (False, True):
            Req = rng.normal(size=G.shape("dU")).astype(dt) if use_eq else None
            if use_eq: Req[rng.uniform(size=Req.shape) < 0.01] = np.inf
            r = RS.residual(Gk, *[T(x) for x in F + pr + B], R_eq=None if Req is None else T(Req), backend=BK); f = H(r["flags"])
            for v in np.unique(f): seen[int(v)] = seen.get(int(v), 0) + int((f == v).sum())
        if BK == "cupy": cp.cuda.Device().synchronize()
print("flag counts seen:", seen); assert 0 in seen and 1 in seen
print("SANITIZER TARGET DONE")
