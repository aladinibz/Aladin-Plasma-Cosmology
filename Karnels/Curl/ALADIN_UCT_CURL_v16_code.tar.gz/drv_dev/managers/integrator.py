# -*- coding: utf-8 -*-
"""INTEGRATOR — SSP-RK3 (Shu-Osher), TRANSACTIONAL, with MOOD-style recovery.
  stage:   fill ghosts -> pipeline rhs -> U += dt dU (interior) ;  CT Faraday + axis closure (UCT-EMF ct_update, slot 11)
  step:    U1 = S(U);  U2 = 3/4 U + 1/4 S(U1);  U^{n+1} = 1/3 U + 2/3 S(U2)   (B the same, face-centred, CT keeps div B)
  admit:   the step is accepted only if no stage refused (PRIM 1/2/8, HLLD 32, RESIDUAL 1) and the result is admissible and
           finite (a non-finite face marks its two adjacent cells).  Until then the state U^n, B^n is untouched.
  recover: pass k: dilate the bad cells k times -> first-order faces there (HLLD first_order_cells) -> retry; from pass 3 also
           halve dt; after max_passes: explicit STOP (AdmissibilityError) — never a silent continue."""
import numpy as np
from .common import AdmissibilityError


def _dilate(m):
    """one-cell dilation along r, phi, z (no wrap; the mask is ghost-extended)"""
    o = m.copy()
    o[1:] |= m[:-1]; o[:-1] |= m[1:]
    o[:, 1:] |= m[:, :-1]; o[:, :-1] |= m[:, 1:]
    o[:, :, 1:] |= m[:, :, :-1]; o[:, :, :-1] |= m[:, :, 1:]
    return o


def _acc(info, R):
    for k in ("prim", "residual", "hlld"): info["refused"][k] += R["refused"][k]
    for s_, n_ in R["refused"]["hlld_by_slot"].items(): info["refused"][s_] = info["refused"].get(s_, 0) + n_
    info["prim_unresolved"] = max(info["prim_unresolved"], R["refused"]["prim_unresolved"])


class Integrator:
    def __init__(self, cfg, K, grids, boundary, pipeline, timestep, xp):
        self.cfg = cfg; self.K = K; self.gm = grids; self.bm = boundary; self.pl = pipeline; self.ts = timestep; self.xp = xp
        self.bk = cfg.backend; self.first_order = None; self.src = None        # src: SourceManager (MMS), None = off

    def stage(self, U, B, dt, held, t=None):
        if self.src is None:
            self.bm.fill(U, B, held); R = self.pl.rhs(U, B, self.first_order)
        else:                                                                    # MMS: exact ghosts and the source at the stage time t
            S_ = self.src.at(t); self.bm.fill(U, B, S_["held"]); R = self.pl.rhs(U, B, self.first_order, src=S_)
        I = self.gm.I
        Un = [x.copy() for x in U]
        for m in range(5): Un[m][I] = U[m][I] + dt * R["dU"][m]
        Bn = [self.xp.ascontiguousarray(x.copy()) for x in B]
        self.K["E"].ct_update(self.gm.GE, *Bn, *R["EMF"], dt, backend=self.bk)
        return Un, Bn, R

    def try_step(self, U, B, dt, held, t=0.0):
        xp = self.xp; info = dict(refused=dict(prim=0, residual=0, hlld=0), prim_unresolved=0)
        U1, B1, R = self.stage([x.copy() for x in U], [x.copy() for x in B], dt, held, t); bad = R["bad"]; _acc(info, R)
        U2a, B2a, R = self.stage(U1, B1, dt, held, t + dt); bad = bad | R["bad"]; _acc(info, R)
        U2 = [0.75 * a + 0.25 * b for a, b in zip(U, U2a)]; B2 = [xp.ascontiguousarray(0.75 * a + 0.25 * b) for a, b in zip(B, B2a)]
        U3a, B3a, R = self.stage(U2, B2, dt, held, t + 0.5 * dt); bad = bad | R["bad"]; _acc(info, R)
        Un = [a / 3 + 2 * b / 3 for a, b in zip(U, U3a)]; Bn = [xp.ascontiguousarray(a / 3 + 2 * b / 3) for a, b in zip(B, B3a)]
        self.bm.fill(Un, Bn, held if self.src is None else self.src.held(t + dt))
        pr = self.K["PR"].primitives(self.gm.GP, *Un, *Bn, gamma=self.cfg.gamma, backend=self.bk)     # admissibility of the result
        I = self.gm.I
        endbad = ((pr["flags"] & 11) > 0)
        for u_ in Un: endbad |= ~xp.isfinite(u_)
        nf = [~xp.isfinite(b_) for b_ in Bn]                                     # a bad face marks its two adjacent cells (local)
        endbad = endbad | nf[0][:-1] | nf[0][1:] | nf[1][:, :-1] | nf[1][:, 1:] | nf[2][:, :, :-1] | nf[2][:, :, 1:]
        mask = xp.zeros_like(endbad); mask[I] = endbad[I]
        return Un, Bn, bad | mask, info

    def advance(self, s, t_end=None, dt=None):
        """one transactional step of the state holder s (U, B, U0, B0, t, step, events, status); returns the step record"""
        cfg, xp = self.cfg, self.xp; held = (s.U0, s.B0)
        dt0 = self.ts.dt_cfl(s.U, s.B) if dt is None else dt
        if t_end is not None: dt0 = min(dt0, t_end - s.t)
        dt = dt0; widen = 0; self.first_order = None; passes = 0
        while True:
            Un, Bn, bad, info = self.try_step(s.U, s.B, dt, held, s.t)
            nbad = int(bad.sum())
            if nbad == 0: break
            passes += 1
            if passes > cfg.max_passes:
                s.status = "FAILED"
                ev = dict(step=s.step, t=s.t, event="STOP", reason=f"inadmissible cells remain after {cfg.max_passes} recovery passes", bad_cells=nbad,
                          refused=info["refused"]); s.events.append(ev)
                raise AdmissibilityError(ev["reason"])
            widen += 1
            mask = bad.copy()
            for _ in range(widen): mask = _dilate(mask)
            self.first_order = mask.astype(np.int32) if self.first_order is None else xp.maximum(self.first_order, mask.astype(np.int32))
            if passes >= 3: dt *= 0.5
            s.events.append(dict(step=s.step, t=s.t, event="recovery_pass", pass_no=passes, bad_cells=nbad, first_order_cells=int(self.first_order.sum()),
                                 dt=dt, refused=info["refused"]))
        s.U, s.B = Un, Bn; s.t += dt; s.step += 1
        rec = dict(step=s.step, t=s.t, dt=dt, dt_cfl=dt0, recovery_passes=passes, first_order_cells=int(self.first_order.sum()) if self.first_order is not None else 0,
                   prim_unresolved=info["prim_unresolved"])
        self.first_order = None
        return rec
