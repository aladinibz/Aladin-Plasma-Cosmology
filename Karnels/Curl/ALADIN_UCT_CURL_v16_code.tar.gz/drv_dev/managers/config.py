# -*- coding: utf-8 -*-
"""CONFIG — every setting of a run in one place.  The bundle records it (dataclasses.asdict), so any run can be repeated exactly."""
from dataclasses import dataclass
import numpy as np


@dataclass
class Config:
    # grid (code units; axis grid iff r_min == 0)
    nr: int = 32; nphi: int = 16; nz: int = 16
    r_min: float = 0.0; r_max: float = 1.0; z_len: float = 1.0; g: int = 2
    # precision / backend
    precision: str = "float64"; backend: str = "cpu"           # "float64" | "float32" ;  "cpu" | "cupy"
    allow_fp32_ftz: bool = False                                # FP32 on the GPU through kernels that flush subnormals (recorded)
    # physics
    gamma: float = 5 / 3; limiter: str = "mc"
    eta: float = 0.0; hall: float = 0.0                          # resistivity, Hall coefficient (UCT-EMF Ohm's law)
    # time step
    cfl: float = 0.4; dt_max: float = 1e30
    # boundaries
    z_bc: str = "periodic"                                       # "periodic" | "outflow"
    r_outer_bc: str = "fixed"                                    # "fixed" (held at the initial state) | "outflow" | "wall" (rigid conducting wall)
    # schemes / modules
    well_balanced: bool = False                                  # needs an equilibrium from the initial condition
    eglm: str = "project_monitor"                                # "project_monitor" | "monitor" | "off"
    g2_interval: int = 0                                         # 0 = off
    gyro: bool = False                                           # not coupled in v4.0: refused
    ablate: tuple = ()                                           # TEST ONLY (DRV-01 D10): slots switched off, e.g. ("06 HLLD-Z",); recorded
    # recovery
    max_passes: int = 6                                          # recovery passes per step before an explicit STOP
    # identity
    units: str = "code units, mu0 = 1"
    label: str = "experiment"

    @property
    def dtype(self): return np.float64 if self.precision == "float64" else np.float32
