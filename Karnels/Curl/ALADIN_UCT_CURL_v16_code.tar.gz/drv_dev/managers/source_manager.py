# -*- coding: utf-8 -*-
"""SOURCE MANAGER — the method of manufactured solutions (MMS) for the Driver.  OFF by default: a Driver built without a
source runs the certified arithmetic unchanged (proved bit-identical, tests/mms01.py part 0).

A manufactured solution q*(x, y, z, t) is chosen (smooth in CARTESIAN coordinates, so it crosses the axis without any
special treatment; periodic in z).  The Driver then solves  dU/dt + div F(U) = S  with the source  S = dU*/dt + div F(U*)
computed EXACTLY from q* (no finite differences): every field is a sum of separable terms  c f(x) g(y) h(z) T(t), each
factor a sinusoid sin(a u + b) or a monomial u^k, so every partial derivative is again a closed form.  The exact
solution is then q* itself, and the discretisation error ||U - U*|| must shrink at the design order of the scheme.

  ρ, p, v = (vx, vy, vz)        separable fields
  B = B0 + curl A               A separable (B0 enters A as monomials), so div B = 0 exactly; the initial faces are the
                                DISCRETE curl of A on the edges (the kernel's own CT operator), so div B = 0 to round-off
  Ohm's law (UCT-EMF)           E = -v x B + eta J + hall (J x B) / ρ ,  J = curl B
  energy                        E_tot = p/(γ-1) + ρ v²/2 + B²/2 ,  flux (E_tot + P_T) v - (v.B) B + E_ni x B

Where the source enters (pipeline / integrator, only when a source is attached):
  * conserved variables:  dU += S_U at the cell centres, at the stage time (SSP-RK3 stages t, t+dt, t+dt/2); the momentum
    source is the Cartesian vector rotated to (r, phi, z);
  * induction:            the source of B goes in as an EMF on the edges, E_S = -(dA*/dt + E*), so constrained transport
    keeps div B = 0 to round-off with the source on;
  * 'fixed' outer boundary: the ghosts hold the exact solution at the stage time.

Determinism: all transcendental values are computed on the host with Python's math module (scalar libm), once per grid
(the spatial factors) or per stage (scalars of t); per stage only array products and sums are done, one IEEE operation at
a time, in a fixed order, so the CPU and the GPU see the same source bits."""
import math
import numpy as np

PI = math.pi


# ---------------------------------------------------------------------------------------------------- separable fields
def S(a, b=0.0): return ("s", float(a), float(b))           # sin(a u + b)
def C(a, b=0.0): return ("s", float(a), float(b) + PI / 2)  # cos(a u + b)
def M(k): return ("m", int(k))                              # u^k
ONE = M(0)


def factor(f, n, u):
    """n-th derivative of the 1-D factor f at the scalar u (Python float, deterministic)"""
    if f[0] == "s":
        _, a, b = f
        return (a ** n) * math.sin(a * u + b + n * (PI / 2))
    k = f[1]
    if n > k: return 0.0
    return float(math.factorial(k) // math.factorial(k - n)) * (u ** (k - n))


def zero_factor(f, n): return f[0] == "m" and n > f[1]


class Field:
    """sum of terms coef * fx(x) fy(y) fz(z) ft(t)"""
    def __init__(self, *terms): self.terms = [(float(c), fx, fy, fz, ft) for c, fx, fy, fz, ft in terms]
    def __add__(self, o): f = Field(); f.terms = self.terms + o.terms; return f


class Loc:
    """a set of points (r_k, phi_j, z_l) of the Driver grid, with the Cartesian factors cached (host math, once)"""
    def __init__(self, r, phi, z, xp):
        self.r = [float(v) for v in r]; self.phi = [float(v) for v in phi]; self.z = [float(v) for v in z]; self.xp = xp
        self.cs = np.array([math.cos(p) for p in self.phi]); self.sn = np.array([math.sin(p) for p in self.phi])
        self.X = [[ri * math.cos(pj) for pj in self.phi] for ri in self.r]; self.Y = [[ri * math.sin(pj) for pj in self.phi] for ri in self.r]
        self.shape = (len(self.r), len(self.phi), len(self.z)); self._f = {}; self._p = {}
        self.cs_x = xp.asarray(self.cs[None, :, None]); self.sn_x = xp.asarray(self.sn[None, :, None])

    def _fac(self, axis, f, n):
        key = (axis, f, n)
        if key not in self._f:
            if axis == "x": a = np.array([[factor(f, n, u) for u in row] for row in self.X])[:, :, None]
            elif axis == "y": a = np.array([[factor(f, n, u) for u in row] for row in self.Y])[:, :, None]
            else: a = np.array([factor(f, n, u) for u in self.z])[None, None, :]
            self._f[key] = a
        return self._f[key]

    def spatial(self, term, nx, ny, nz):
        """the spatial product of one term's derivative (cached on the backend; None if identically zero)"""
        _, fx, fy, fz, _ = term
        key = (fx, fy, fz, nx, ny, nz)
        if key not in self._p:
            if zero_factor(fx, nx) or zero_factor(fy, ny) or zero_factor(fz, nz): self._p[key] = None
            else:
                xy = self._fac("x", fx, nx) * self._fac("y", fy, ny)                    # host, IEEE, fixed order
                self._p[key] = self.xp.asarray(np.ascontiguousarray(xy * self._fac("z", fz, nz)))
        return self._p[key]

    def eval(self, F, mi, t):
        """d^mi F at time t on these points; mi = (nx, ny, nz, nt)"""
        nx, ny, nz, nt = mi; out = None
        for term in F.terms:
            if zero_factor(term[4], nt): continue
            P = self.spatial(term, nx, ny, nz)
            if P is None: continue
            s = term[0] * factor(term[4], nt, t)
            out = s * P if out is None else out + s * P
        if out is None: out = self.xp.zeros(self.shape)
        return out


# ---------------------------------------------------------------------------------------------------- first-order jets
class Jet:
    """value and the four first partials (x, y, z, t): exact product / quotient rules"""
    __slots__ = ("v", "d")
    def __init__(self, v, d): self.v = v; self.d = d
    def __add__(self, o):
        if isinstance(o, Jet): return Jet(self.v + o.v, [a + b for a, b in zip(self.d, o.d)])
        return Jet(self.v + o, list(self.d))
    __radd__ = __add__
    def __neg__(self): return Jet(-self.v, [-a for a in self.d])
    def __sub__(self, o): return self + (-o)
    def __rsub__(self, o): return (-self) + o
    def __mul__(self, o):
        if isinstance(o, Jet): return Jet(self.v * o.v, [a * o.v + self.v * b for a, b in zip(self.d, o.d)])
        return Jet(self.v * o, [a * o for a in self.d])
    __rmul__ = __mul__
    def inv(self):
        q = 1.0 / self.v; q2 = q * q
        return Jet(q, [-(a * q2) for a in self.d])
    def __truediv__(self, o):
        if isinstance(o, Jet): return self * o.inv()
        return self * (1.0 / o)


def cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
EPS = [(0, 1, 2, 1), (0, 2, 1, -1), (1, 2, 0, 1), (1, 0, 2, -1), (2, 0, 1, 1), (2, 1, 0, -1)]   # (i, j, k, sign) of eps_ijk


def _add(mi, *axes):
    m = list(mi)
    for a in axes: m[a] += 1
    return tuple(m)


# ---------------------------------------------------------------------------------------------------- the solution
class Solution:
    """a manufactured solution: Fields rho, p, v[3], A[3] (B = curl A)"""
    def __init__(self, name, rho, p, v, A, note=""):
        self.name, self.rho, self.p, self.v, self.A, self.note = name, rho, p, list(v), list(A), note

    # point values (plain arrays) ------------------------------------------------------------
    def B(self, L, t, mi=(0, 0, 0, 0)):
        out = [None, None, None]
        for i, j, k, s in EPS:
            a = L.eval(self.A[k], _add(mi, j), t); a = a if s > 0 else -a
            out[i] = a if out[i] is None else out[i] + a
        return out

    def J(self, L, t, mi=(0, 0, 0, 0)):
        """J_i = eps_ijk d_j B_k"""
        out = [None, None, None]
        for i, j, k, s in EPS:
            a = self.B(L, t, _add(mi, j))[k]; a = a if s > 0 else -a
            out[i] = a if out[i] is None else out[i] + a
        return out

    # jets ------------------------------------------------------------------------------------
    def jet(self, L, F, t): return Jet(L.eval(F, (0, 0, 0, 0), t), [L.eval(F, m, t) for m in ((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1))])
    def jets_B(self, L, t):
        v = self.B(L, t); d = [self.B(L, t, m) for m in ((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1))]
        return [Jet(v[i], [d[q][i] for q in range(4)]) for i in range(3)]
    def jets_J(self, L, t):
        v = self.J(L, t); d = [self.J(L, t, m) for m in ((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0))]
        z = L.xp.zeros(L.shape)
        return [Jet(v[i], [d[0][i], d[1][i], d[2][i], z]) for i in range(3)]


def source_U(sol, L, t, gamma, eta, hall):
    """S = dU/dt + div F(U) for (rho, m_x, m_y, m_z, E) at the points L (Cartesian momentum)"""
    rho = sol.jet(L, sol.rho, t); p = sol.jet(L, sol.p, t); v = [sol.jet(L, f, t) for f in sol.v]
    B = sol.jets_B(L, t)
    div = lambda F: F[0].d[0] + F[1].d[1] + F[2].d[2]
    m = [rho * vi for vi in v]
    B2 = dot(B, B); PT = p + 0.5 * B2
    S_rho = rho.d[3] + div(m)
    S_m = []
    for i in range(3):
        F = [m[i] * v[j] - B[i] * B[j] for j in range(3)]; F[i] = F[i] + PT
        S_m.append(m[i].d[3] + div(F))
    E = p * (1.0 / (gamma - 1.0)) + 0.5 * (rho * dot(v, v)) + 0.5 * B2
    vB = dot(v, B)
    F = [(E + PT) * v[j] - vB * B[j] for j in range(3)]
    if eta or hall:
        J = sol.jets_J(L, t)
        Eni = [eta * Ji for Ji in J] if eta else None
        if hall:
            H = [hall * c for c in cross(J, B)]; H = [h / rho for h in H]
            Eni = H if Eni is None else [a + b for a, b in zip(Eni, H)]
        S_ = cross(Eni, B); F = [a + b for a, b in zip(F, S_)]
    S_E = E.d[3] + div(F)
    return S_rho, S_m, S_E


def ohm_E(sol, L, t, eta, hall):
    """E* = -v x B + eta J + hall (J x B)/rho (Cartesian, point values)"""
    v = [L.eval(f, (0, 0, 0, 0), t) for f in sol.v]; B = sol.B(L, t)
    E = [-c for c in cross(v, B)]
    if eta or hall:
        J = sol.J(L, t)
        if eta: E = [a + eta * b for a, b in zip(E, J)]
        if hall:
            rho = L.eval(sol.rho, (0, 0, 0, 0), t); H = cross(J, B)
            E = [a + (hall * h) / rho for a, h in zip(E, H)]
    return E


# ---------------------------------------------------------------------------------------------------- the Driver hook
class MMSSource:
    """attach to a Driver: Driver(cfg, src.ic, source=src).  omit: terms left OUT of the source while the Driver keeps them
    (negative controls: the error must then stop converging), e.g. omit=("eta",)."""
    def __init__(self, sol, omit=()):
        self.sol = sol; self.omit = tuple(omit); self.d = None

    def describe(self): return dict(kind="MMS", solution=self.sol.name, note=self.sol.note, omit=list(self.omit))

    # -- built when the Driver attaches ---------------------------------------------------------
    def attach(self, d):
        self.d = d; cfg = d.cfg; G = d.GE; g = G.g; xp = d.xp; nr, P, Z = cfg.nr, cfg.nphi, cfg.nz
        if not G.axis: raise ValueError("MMS-01 is defined on axis grids (r_min = 0)")
        if cfg.r_outer_bc != "fixed" or cfg.z_bc != "periodic": raise ValueError("MMS needs r_outer_bc='fixed' and z_bc='periodic'")
        if cfg.well_balanced: raise ValueError("MMS runs without well-balancing")
        self.gamma = cfg.gamma; self.eta = 0.0 if "eta" in self.omit else cfg.eta; self.hall = 0.0 if "hall" in self.omit else cfg.hall
        rc, rf, pc, pf, zc, zf = G.r_centers, G.r_faces, G.phi_c, G.phi_f, G.z_c, G.z_f
        self.Lc = Loc(rc[g:g + nr], pc[g:g + P], zc[g:g + Z], xp)                   # interior cell centres
        self.LEr = Loc(rc, pf, zf, xp); self.LEp = Loc(rf, pc, zf, xp); self.LEz = Loc(rf, pf, zc, xp)  # edges (full arrays)
        # outer ghost slabs held by the 'fixed' boundary
        self.Lgc = Loc(rc[g + nr:], pc, zc, xp); self.LgBr = Loc(rf[g + nr + 1:], pc, zc, xp)
        self.LgBp = Loc(rc[g + nr:], pf, zc, xp); self.LgBz = Loc(rc[g + nr:], pc, zf, xp)
        self.held_U = [xp.zeros(G.shape("cell")) for _ in range(5)]
        self.held_B = [xp.zeros(G.shape(k)) for k in ("Br", "Bphi", "Bz")]
        self.zero_U = None

    # -- exact solution -------------------------------------------------------------------------
    def prims(self, L, t):
        """exact rho, v_r, v_phi, v_z, p and B_r, B_phi, B_z (cylindrical components at the points' phi)"""
        s = self.sol; e = (0, 0, 0, 0)
        rho = L.eval(s.rho, e, t); p = L.eval(s.p, e, t); vx, vy, vz = (L.eval(f, e, t) for f in s.v); Bx, By, Bz = s.B(L, t)
        c, n = L.cs_x, L.sn_x
        return dict(rho=rho, vr=c * vx + n * vy, vphi=c * vy - n * vx, vz=vz, p=p, Br=c * Bx + n * By, Bphi=c * By - n * Bx, Bz=Bz)

    def held(self, t):
        d = self.d; g = d.g; nr = d.cfg.nr
        q = self.prims(self.Lgc, t)
        v2 = q["vr"] * q["vr"] + q["vphi"] * q["vphi"] + q["vz"] * q["vz"]; b2 = q["Br"] * q["Br"] + q["Bphi"] * q["Bphi"] + q["Bz"] * q["Bz"]
        U = [q["rho"], q["rho"] * q["vr"], q["rho"] * q["vphi"], q["rho"] * q["vz"], q["p"] * (1.0 / (self.gamma - 1.0)) + 0.5 * (q["rho"] * v2) + 0.5 * b2]
        for a, u in zip(self.held_U, U): a[g + nr:] = u
        self.held_B[0][g + nr + 1:] = self.prims(self.LgBr, t)["Br"]; self.held_B[1][g + nr:] = self.prims(self.LgBp, t)["Bphi"]
        self.held_B[2][g + nr:] = self.prims(self.LgBz, t)["Bz"]
        return self.held_U, self.held_B

    # -- the source at one stage time -----------------------------------------------------------
    def at(self, t):
        sol = self.sol; L = self.Lc
        Sr, Sm, SE = source_U(sol, L, t, self.gamma, self.eta, self.hall)
        c, n = L.cs_x, L.sn_x
        dU = [Sr, c * Sm[0] + n * Sm[1], c * Sm[1] - n * Sm[0], Sm[2], SE]
        EM = []
        for L_, comp in ((self.LEr, "r"), (self.LEp, "phi"), (self.LEz, "z")):
            E = ohm_E(sol, L_, t, self.eta, self.hall)
            dA = [L_.eval(A, (0, 0, 0, 1), t) for A in sol.A]
            ES = [-(a + b) for a, b in zip(dA, E)]
            if comp == "r": EM.append(self.d.xp.ascontiguousarray(L_.cs_x * ES[0] + L_.sn_x * ES[1]))
            elif comp == "phi": EM.append(self.d.xp.ascontiguousarray(L_.cs_x * ES[1] - L_.sn_x * ES[0]))
            else: EM.append(self.d.xp.ascontiguousarray(ES[2]))
        return dict(dU=dU, EMF=tuple(EM), held=self.held(t))

    # -- initial condition (host NumPy, like every IC) -------------------------------------------
    def ic(self, d):
        """exact cells (ghosts included); B faces = DISCRETE curl of the edge values of A (the kernel's CT operator, host C++),
        outer ghost faces = exact point values"""
        cfg = d.cfg; G = d.GE; g = G.g; nr = cfg.nr; s = self.sol
        Lcell = Loc(G.r_centers, G.phi_c, G.z_c, np)
        Gh = d.E.Grid(cfg.nr, cfg.nphi, cfg.nz, cfg.r_min, cfg.r_max, zlen=cfg.z_len, g=g, dtype=np.float64, xp=np)
        Ae = []
        for L_, comp in ((Loc(G.r_centers, G.phi_f, G.z_f, np), "r"), (Loc(G.r_faces, G.phi_c, G.z_f, np), "phi"), (Loc(G.r_faces, G.phi_f, G.z_c, np), "z")):
            A = [L_.eval(a, (0, 0, 0, 0), 0.0) for a in s.A]; c, n = L_.cs_x, L_.sn_x
            Ae.append(np.ascontiguousarray(-(c * A[0] + n * A[1]) if comp == "r" else -(c * A[1] - n * A[0]) if comp == "phi" else -A[2]))
        B = [np.zeros(G.shape(k)) for k in ("Br", "Bphi", "Bz")]
        d.E.ct_update(Gh, *B, *Ae, 1.0, backend="cpu")                              # B = curl A (discrete Stokes), div B = 0
        e = (0, 0, 0, 0)
        B[0][g + nr + 1:] = self.prims(Loc(G.r_faces[g + nr + 1:], G.phi_c, G.z_c, np), 0.0)["Br"]
        B[1][g + nr:] = self.prims(Loc(G.r_centers[g + nr:], G.phi_f, G.z_c, np), 0.0)["Bphi"]
        B[2][g + nr:] = self.prims(Loc(G.r_centers[g + nr:], G.phi_c, G.z_f, np), 0.0)["Bz"]
        q = self.prims(Lcell, 0.0)
        Gp = d.PR.Grid(cfg.nr, cfg.nphi, cfg.nz, cfg.r_min, cfg.r_max, zlen=cfg.z_len, g=g)
        Uc = d.PR.conserved(Gp, *(np.ascontiguousarray(q[k]) for k in ("rho", "vr", "vphi", "vz", "p")), *B, gamma=cfg.gamma)
        return dict(U=[Uc[k] for k in ("rho", "m_r", "m_phi", "m_z", "E")], B=B)

    # -- the error ------------------------------------------------------------------------------
    def errors(self, d):
        """volume-weighted L1 and max errors of the primitives and of the cell-centred B against the exact point values"""
        from .common import host
        I = d.grids.I; V, _ = d.grids.volumes(); V = host(V); Vs = float(V.sum()) * d.cfg.nphi * d.cfg.nz
        pr = d.PR.primitives(d.GP, *d.U, *d.B, gamma=d.cfg.gamma, backend=d.bk); bc = d.PR.cell_B(d.GP, *d.B)
        num = {k: host(pr[k][I]) for k in ("rho", "vr", "vphi", "vz", "p")}
        num.update(Br=host(bc[0][I]), Bphi=host(bc[1][I]), Bz=host(bc[2][I]))
        Lc = Loc(d.GE.r_centers[d.g:d.g + d.cfg.nr], d.GE.phi_c[d.g:d.g + d.cfg.nphi], d.GE.z_c[d.g:d.g + d.cfg.nz], np)
        ex = self.prims(Lc, d.t)
        out = {}
        for k in num:
            e_ = np.abs(num[k] - ex[k]); out[k] = dict(L1=float((V * e_).sum() / Vs), Linf=float(e_.max()))
        return out


# ---------------------------------------------------------------------------------------------------- MMS-01 solution
def mms01_solution():
    """smooth in x, y, z, t; crosses the axis; periodic in z (period 1); every field moves; B0 = (0.4, 0.3, 1.0) oblique
    through the axis; |v| ~ 0.2, |B - B0| ~ 0.2, rho, p in [0.8, 1.2]"""
    k = 2 * PI; pi = PI
    rho = Field((1.0, ONE, ONE, ONE, ONE), (0.2, S(pi, 0.3), C(pi, -0.2), S(k, 0.1), S(1.0, 0.0)))
    rho.terms[1] = (0.2, S(pi, 0.3), C(pi, -0.2), S(k, 0.1), C(1.0, 0.4))
    p = Field((1.0, ONE, ONE, ONE, ONE), (0.15, C(pi, -0.4), S(pi, 0.5), C(k, 0.0), C(2.0, 0.1)))
    vx = Field((0.2, ONE, C(pi, 0.2), S(k, 0.3), C(1.0, 0.0)), (0.05, S(pi, 0.1), ONE, ONE, S(1.5, 0.2)))
    vy = Field((0.2, S(pi, -0.1), ONE, C(k, 0.0), C(2.0, 0.3)))
    vz = Field((0.15, C(pi, 0.3), C(pi, -0.1), C(k, 0.2), C(1.0, -0.5)))
    B0 = (0.4, 0.3, 1.0)
    Ax = Field((0.03, ONE, C(pi, -0.3), S(k, 0.0), C(1.0, 0.0)), (-0.5 * B0[2], ONE, M(1), ONE, ONE))
    Ay = Field((0.03, S(pi, 0.2), ONE, C(k, 0.4), C(1.0, -0.6)), (0.5 * B0[2], M(1), ONE, ONE, ONE))
    Az = Field((0.04, S(pi, -0.1), S(pi, 0.6), ONE, C(1.0, 0.2)), (B0[0], ONE, M(1), ONE, ONE), (-B0[1], M(1), ONE, ONE, ONE))
    return Solution("MMS-01", rho, p, (vx, vy, vz), (Ax, Ay, Az),
                    note="rho, p, v, A sums of separable sinusoids in x, y, z(2 pi), t; B0 = (0.4, 0.3, 1.0) as A monomials")
