# -*- coding: utf-8 -*-
"""GRID MANAGER — builds the per-kernel Grid objects from ONE config, so every kernel sees the same grid (z fastest, g ghost
layers, ghost-extended r faces / centres, axis iff r_faces[g] == 0).  Enforces the axis rule (even nphi) and provides the
interior slice, cell volumes and the angular-momentum radius rbar used by the diagnostics."""
import numpy as np
from .common import AdmissibilityError


class GridManager:
    def __init__(self, cfg, K, xp):
        self.cfg = cfg; self.xp = xp
        mk = lambda M: M.Grid(cfg.nr, cfg.nphi, cfg.nz, cfg.r_min, cfg.r_max, zlen=cfg.z_len, g=cfg.g, dtype=cfg.dtype)
        self.GP, self.GH, self.GR, self.GE, self.GG = mk(K["PR"]), mk(K["H"]), mk(K["RS"]), mk(K["E"]), mk(K["GL"])
        for G_ in (self.GP, self.GH, self.GR, self.GE, self.GG): G_.xp = xp
        self.g = self.GE.g; self.axis = self.GE.axis
        if self.axis and cfg.nphi % 2: raise AdmissibilityError("axis grids need an even nphi (axis reflection)")
        g = self.g
        self.I = (slice(g, g + cfg.nr), slice(g, g + cfg.nphi), slice(g, g + cfg.nz))     # interior cells

    def volumes(self):
        """cell volumes V and rbar = (2/3)(r+^3 - r-^3)/(r+^2 - r-^2) (interior, broadcastable, on the backend)"""
        G, g, cfg, xp = self.GE, self.g, self.cfg, self.xp
        rf = np.asarray(G.r_faces[g:g + cfg.nr + 1], np.float64); rm, rp = rf[:-1], rf[1:]
        V = xp.asarray((0.5 * (rp ** 2 - rm ** 2) * G.dphi * G.dz)[:, None, None])
        rb = xp.asarray(((2 / 3) * (rp ** 3 - rm ** 3) / (rp ** 2 - rm ** 2))[:, None, None])
        return V, rb
