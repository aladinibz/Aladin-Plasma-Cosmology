# -*- coding: utf-8 -*-
"""MEMORY MANAGER — memory pools for the kernels and the state.
GPU (cupy): all device arrays come from CuPy's memory pool (allocations are reused, no cudaMalloc per stage); this manager
  * configures the device pool (optional hard limit) and the pinned host pool (fast host<->device copies),
  * checks BEFORE the run that the grid fits: an estimate from the array count of one SSP-RK3 step, compared with free memory;
    a run that cannot fit is REFUSED (admissible by design) instead of crashing mid-run,
  * measures the real peak after every step and records it, so the estimate is checked against reality,
  * releases cached blocks on demand (checkpoints, end of run).
CPU: reports the process resident memory (peak RSS) the same way.
No physics: the manager never touches array values."""
import os, resource
import numpy as np
from .common import AdmissibilityError

# working set of one SSP-RK3 step in units of one ghost-extended cell array.  History: 75 (first count) -> 120 (L4, MG-00,
# 32x16x16, 2026-11-20) -> 180 (L4, DRV-01 GPU run 1, 2026-11-22: well-balanced 32^3 / 64^3 / 128^3 measured 1.33 / 1.35 / 1.38
# x 120, i.e. up to 166 arrays: the well-balancing equilibrium W_eq, R_eq, E_eq and the held boundary state stay resident).
# 180 = 166 + 8 % margin.  DRV-01 D12 checks it again, including a grid size (96^3) never used for calibration.
ARRAYS_PER_STEP = 180


class MemoryManager:
    def __init__(self, cfg, limit_bytes=None, safety=0.9):
        self.cfg = cfg; self.gpu = cfg.backend == "cupy"; self.safety = safety; self.peak = 0
        if self.gpu:
            import cupy as cp
            self.cp = cp; self.pool = cp.get_default_memory_pool(); self.pinned = cp.get_default_pinned_memory_pool()
            if limit_bytes: self.pool.set_limit(size=int(limit_bytes))
            cp.cuda.set_pinned_memory_allocator(self.pinned.malloc)

    def cell_bytes(self):
        c = self.cfg; return (c.nr + 2 * c.g + 1) * (c.nphi + 2 * c.g + 1) * (c.nz + 2 * c.g + 1) * np.dtype(c.dtype).itemsize

    def estimate(self):
        return ARRAYS_PER_STEP * self.cell_bytes()

    def free_bytes(self):
        if self.gpu:
            free, total = self.cp.cuda.runtime.memGetInfo(); return free + self.pool.free_bytes(), total
        try:
            pages = os.sysconf("SC_AVPHYS_PAGES"); size = os.sysconf("SC_PAGE_SIZE"); tot = os.sysconf("SC_PHYS_PAGES")
            return pages * size, tot * size
        except (ValueError, OSError): return None, None

    def check_fits(self):
        need = self.estimate(); free, total = self.free_bytes()
        rep = dict(estimate_bytes=need, free_bytes=free, total_bytes=total, arrays_per_step=ARRAYS_PER_STEP, safety=self.safety)
        if free is not None and need > self.safety * free:
            raise AdmissibilityError(f"grid does not fit: ~{need / 2**30:.2f} GiB needed for one step, {free / 2**30:.2f} GiB free "
                                     f"({'GPU' if self.gpu else 'host'}).  Reduce the grid or use a larger device.")
        return rep

    def usage(self):
        """measured now: GPU pool bytes in use / held, or host peak RSS"""
        if self.gpu:
            used, held = self.pool.used_bytes(), self.pool.total_bytes(); self.peak = max(self.peak, held)
            return dict(gpu_used_bytes=used, gpu_pool_bytes=held, gpu_pool_peak_bytes=self.peak)
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024; self.peak = max(self.peak, rss)
        return dict(host_peak_rss_bytes=rss)

    def release(self):
        """give cached, unused blocks back to the device (does not touch live arrays)"""
        if self.gpu: self.pool.free_all_blocks(); self.pinned.free_all_blocks()
