# -*- coding: utf-8 -*-
"""PIPELINE — one right-hand side of the equations, in the certified order (the kernel order is the physics):
  PRIM (01)  ->  HLLD-R (04), HLLD-phi (05), HLLD-Z (06)  ->  RESIDUAL (07, all geometric sources)
  ->  UCT-CURL (09, J, only if eta or hall)  ->  UCT-EMF (08, edge EMF; slot 11 CT + axis closure is applied by the integrator)
and the refusal flags of every slot: PRIM 1/2/8, HLLD 32 (per direction), RESIDUAL 1.  Well-balancing (W_eq, W_eq_faces,
R_eq) and the first-order recovery mask are passed through to HLLD / RESIDUAL here."""
import numpy as np
from .build_manager import HLLD_DIR
from .common import host


class Pipeline:
    def __init__(self, cfg, K, grids, boundary, xp):
        self.cfg = cfg; self.K = K; self.gm = grids; self.bm = boundary; self.xp = xp; self.bk = cfg.backend
        self.W_eq = self.W_eq_faces = self.R_eq = self.E_eq = None
        known = set(HLLD_DIR) | {"07 RESIDUAL", "08+11 UCT-EMF", "09 UCT-CURL"}
        bad = [a for a in cfg.ablate if a not in known]
        if bad: raise ValueError(f"unknown slots in ablate: {bad}; known: {sorted(known)}")
        if cfg.ablate: print(f"WARNING: ABLATION TEST, slots switched off: {list(cfg.ablate)} (results are not physics)")

    def poynting_divergence(self, Eni, B):
        """div(E_ni x B) on the interior cells, conservative cylindrical form (same geometry as RESIDUAL v01):
        (r+ S_r+ - r- S_r-)/(r_c dr) + (S_phi+ - S_phi-)/(r_c dphi) + (S_z+ - S_z-)/dz.  Face values: E_ni averaged from the
        face's two edges per component, B tangential averaged from the two adjacent cell centres (cell B = mean of its faces).
        Telescoping: the volume sum equals the boundary flux, so total energy changes only through the boundary."""
        xp, gm, cfg = self.xp, self.gm, self.cfg; G = gm.GE; g = gm.g; nr, P, Z = cfg.nr, cfg.nphi, cfg.nz
        Er, Ep, Ez = Eni; Br, Bp, Bz = B
        Brc = 0.5 * (Br[:-1] + Br[1:]); Bpc = 0.5 * (Bp[:, :-1] + Bp[:, 1:]); Bzc = 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])
        si, sj, sk = slice(g, g + nr), slice(g, g + P), slice(g, g + Z)
        rc = xp.asarray(np.asarray(G.r_centers[g:g + nr], np.float64)[:, None, None]).astype(Br.dtype)
        rf = xp.asarray(np.asarray(G.r_faces[g:g + nr + 1], np.float64)[:, None, None]).astype(Br.dtype)
        sI = slice(g, g + nr + 1); sJ = slice(g, g + P + 1); sK = slice(g, g + Z + 1)
        # r-faces: S_r = E_phi B_z - E_z B_phi
        Ep_f = 0.5 * (Ep[sI, sj, g:g + Z] + Ep[sI, sj, g + 1:g + Z + 1]); Ez_f = 0.5 * (Ez[sI, g:g + P, sk] + Ez[sI, g + 1:g + P + 1, sk])
        Sr = Ep_f * (0.5 * (Bzc[g - 1:g + nr, sj, sk] + Bzc[g:g + nr + 1, sj, sk])) - Ez_f * (0.5 * (Bpc[g - 1:g + nr, sj, sk] + Bpc[g:g + nr + 1, sj, sk]))
        # phi-faces: S_phi = E_z B_r - E_r B_z
        Ez_f = 0.5 * (Ez[g:g + nr, sJ, sk] + Ez[g + 1:g + nr + 1, sJ, sk]); Er_f = 0.5 * (Er[si, sJ, g:g + Z] + Er[si, sJ, g + 1:g + Z + 1])
        Sp = Ez_f * (0.5 * (Brc[si, g - 1:g + P, sk] + Brc[si, g:g + P + 1, sk])) - Er_f * (0.5 * (Bzc[si, g - 1:g + P, sk] + Bzc[si, g:g + P + 1, sk]))
        # z-faces: S_z = E_r B_phi - E_phi B_r
        Er_f = 0.5 * (Er[si, g:g + P, sK] + Er[si, g + 1:g + P + 1, sK]); Ep_f = 0.5 * (Ep[g:g + nr, sj, sK] + Ep[g + 1:g + nr + 1, sj, sK])
        Sz = Er_f * (0.5 * (Bpc[si, sj, g - 1:g + Z] + Bpc[si, sj, g:g + Z + 1])) - Ep_f * (0.5 * (Brc[si, sj, g - 1:g + Z] + Brc[si, sj, g:g + Z + 1]))
        return (rf[1:] * Sr[1:] - rf[:-1] * Sr[:-1]) / (rc * G.dr) + (Sp[:, 1:] - Sp[:, :-1]) / (rc * G.dphi) + (Sz[:, :, 1:] - Sz[:, :, :-1]) / G.dz

    def rhs(self, U, B, first_order=None, src=None):
        """src: the source at the stage time (SourceManager, MMS); None = the certified equations, unchanged"""
        cfg, K, gm = self.cfg, self.K, self.gm
        pr = K["PR"].primitives(gm.GP, *U, *B, gamma=cfg.gamma, backend=self.bk)
        prims = [pr[k] for k in ("rho", "vr", "vphi", "vz", "p")]
        kw = {}
        if self.W_eq is not None: kw["W_eq"] = self.W_eq
        if self.W_eq_faces is not None: kw["W_eq_faces"] = self.W_eq_faces
        if first_order is not None: kw["first_order_cells"] = first_order
        F, fl = {}, {}
        for slot, k in HLLD_DIR.items():                                         # slots 04, 05, 06: one call per direction
            Fk, flk = K["H"].fluxes(gm.GH, *prims, *B, gamma=cfg.gamma, limiter=cfg.limiter, backend=self.bk, directions=(k,), **kw)
            F[k], fl[k] = Fk[k], flk[k]
            if slot in cfg.ablate: F[k] = self.xp.zeros_like(F[k])            # D10 ablation: no flux in this direction
        r = K["RS"].residual(gm.GR, F[0], F[1], F[2], *prims, *B, R_eq=self.R_eq, backend=self.bk)
        J = None
        if cfg.eta or cfg.hall:
            G = gm.GE                                                            # UCT-CURL v1.4: runs on the Driver's backend
            Jl, _ = K["UC"].run_curl(*B, G.r_faces, G.r_centers, G.dr, G.dphi, G.dz, cfg.nr, cfg.nphi, cfg.nz, gm.g,
                                     backend=self.bk, device_out=(self.bk == "cupy"))
            J = [self.xp.ascontiguousarray(x) for x in Jl]; self.bm.fill_cells(J, vector=True)
            if "09 UCT-CURL" in cfg.ablate: J = [self.xp.zeros_like(x) for x in J]           # D10 ablation: no current
        Em = K["E"].compute_emf(gm.GE, *B, prims[1], prims[2], prims[3], prims[0], prims[4], J=J, gamma=cfg.gamma, eta=cfg.eta,
                                hall=cfg.hall, limiter=cfg.limiter, backend=self.bk)
        if (cfg.eta or cfg.hall) and "08+11 UCT-EMF" not in cfg.ablate:
            # non-ideal energy flux: the Poynting flux of E_ni = eta J + hall (J x B)/rho is not in HLLD's ideal fluxes.
            # E_ni on the edges = (full EMF) - (ideal EMF), both from UCT-EMF on the same inputs.
            Ei = K["E"].compute_emf(gm.GE, *B, prims[1], prims[2], prims[3], prims[0], prims[4], J=None, gamma=cfg.gamma, eta=0.0, hall=0.0,
                                    limiter=cfg.limiter, backend=self.bk)
            dU_E = self.poynting_divergence([a - b for a, b in zip(Em, Ei)], B)
        else:
            dU_E = None
        if self.E_eq is not None: Em = tuple(a - b for a, b in zip(Em, self.E_eq))      # well-balanced induction (ideal EMF of the equilibrium)
        if "08+11 UCT-EMF" in cfg.ablate: Em = tuple(self.xp.zeros_like(x) for x in Em)   # D10 ablation: frozen field
        dU = r["dU"] if "07 RESIDUAL" not in cfg.ablate else self.xp.zeros_like(r["dU"])  # D10 ablation: frozen plasma
        if dU_E is not None:
            dU = dU.copy(); dU[4] = dU[4] - dU_E
        if src is not None:                                                      # MMS: S_U at the cell centres, E_S on the edges (CT keeps div B)
            dU = dU.copy()
            for m in range(5): dU[m] = dU[m] + src["dU"][m]
            Em = tuple(self.xp.ascontiguousarray(a + b) for a, b in zip(Em, src["EMF"]))
        bad = self.xp.zeros(gm.GP.shape("cell"), dtype=bool)
        bad |= (pr["flags"] & 11) > 0                                            # PRIM refusals 1, 2, 8 (ghosts included)
        bad[gm.I] |= r["flags"] == 1                                             # RESIDUAL refusal (incl. HLLD flag 32 via NaN fluxes)
        nref = dict(prim=int((pr["flags"] & 11).astype(bool).sum()), residual=int((r["flags"] == 1).sum()),
                    hlld=sum(int(((f & 32) > 0).sum()) for f in fl.values()),
                    hlld_by_slot={slot: int(((fl[k] & 32) > 0).sum()) for slot, k in HLLD_DIR.items()}, prim_unresolved=int(((pr["flags"] & 4) > 0).sum()))
        return dict(dU=dU, EMF=Em, prims=prims, bad=bad, refused=nref)
