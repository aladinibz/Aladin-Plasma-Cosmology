# -*- coding: utf-8 -*-
"""DIAGNOSTICS MANAGER — read-only by design (it never writes to the state):
  totals : mass, energy, p_z, angular momentum L = sum V rbar m_phi (the discrete conserved form of RESIDUAL v01),
           max normalised div B (E-GLM monitor, slot 10)
  g2     : G2 kernel (slot 03) diagnostics on the primitives, averaged (host backend)"""
import numpy as np
from .common import host


class DiagnosticsManager:
    def __init__(self, cfg, K, grids, xp):
        self.cfg = cfg; self.K = K; self.gm = grids; self.xp = xp; self.bk = cfg.backend

    def totals(self, U, B):
        I = self.gm.I; V, rb = self.gm.volumes()
        mon = self.K["GL"].monitor(self.gm.GG, *B, backend=self.bk) if self.cfg.eglm != "off" else {}
        return dict(mass=float((V * U[0][I]).sum()), energy=float((V * U[4][I]).sum()), pz=float((V * U[3][I]).sum()),
                    L=float((V * rb * U[2][I]).sum()), divB_norm=float(mon.get("max_norm", np.nan)))

    def g2(self, U, B):
        cfg, gm = self.cfg, self.gm; G = gm.GE
        pr = self.K["PR"].primitives(gm.GP, *U, *B, gamma=cfg.gamma, backend=self.bk)
        Fd = {k: host(pr[k]) for k in ("rho", "vr", "vphi", "vz")}; Fd.update(Br=host(B[0]), Bphi=host(B[1]), Bz=host(B[2]))
        out = self.K["G2"].run_g2(Fd, G.r_faces, G.r_centers, G.dr, G.dphi, G.dz, cfg.nr, cfg.nphi, cfg.nz, gm.g, backend="host")
        return {k: float(np.nanmean(v)) for k, v in out.items()}
