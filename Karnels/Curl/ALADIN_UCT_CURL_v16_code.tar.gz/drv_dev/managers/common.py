# -*- coding: utf-8 -*-
"""Shared helpers for the ALADIN Driver v4.0 managers (no physics)."""
import datetime
import numpy as np


class AdmissibilityError(RuntimeError):
    """the Driver refuses to start or to continue"""


def host(a):
    """device array -> NumPy"""
    return a.get() if hasattr(a, "get") else np.asarray(a)


def now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def jsonable(x):
    if isinstance(x, dict): return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [jsonable(v) for v in x]
    if isinstance(x, (np.floating, np.integer)): return x.item()
    if isinstance(x, np.ndarray): return x.tolist() if x.size < 64 else f"array{x.shape}"
    return x
