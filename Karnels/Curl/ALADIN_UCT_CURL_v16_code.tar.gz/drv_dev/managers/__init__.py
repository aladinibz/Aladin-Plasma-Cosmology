# ALADIN Driver v4.0 managers.  Each file does one job; aladin_driver_v40.py wires them together.
