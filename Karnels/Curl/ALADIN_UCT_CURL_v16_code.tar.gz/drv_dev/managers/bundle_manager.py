# -*- coding: utf-8 -*-
"""
ALADIN MakeReport bundle manager (for Driver v4.0).  Author: Mihai Alexandru Bucurenciu (ALADIN).

Every run becomes ONE self-contained, checksummed bundle, whatever happens to it:
  COMPLETED    the run finished; checks evaluated against thresholds declared BEFORE the run
  FAILED       the Driver stopped itself (admissibility: recovery exhausted, inadmissible state)
  REFUSED      the Driver refused to start (hash mismatch, precision policy, GYRO, odd nphi on the axis ...)
  INTERRUPTED  stopped by the user (KeyboardInterrupt) — or found later with no live process (hard kill, Colab disconnect)
  CRASHED      a Python exception (bug): traceback saved
Nothing is written only at the end: status.json (heartbeat), history.jsonl and events.jsonl are appended every step, so a
bundle killed with SIGKILL still holds everything up to its last step; finalize_stale() closes it as INTERRUPTED.

Bundle layout  runs/<label>_<UTC time>_<id>/
  status.json         status, verdict, heartbeat (pid, step, t, wall time)
  thresholds.json     the predeclared checks (written and hashed at open, before any step)
  manifest.json       Driver manifest: config, kernel hashes + records, environment, IEEE self-test, pipeline
  history.jsonl       one line per step (t, dt, recovery passes, totals, G2 ...)
  events.jsonl        recovery passes, E-GLM projection, STOP / FAILED ...
  results.json        checks: value, threshold, PASS / FAIL / NOT EVALUATED, overall verdict
  log.txt             everything printed during the run
  final_state.npz     U (5) + B (3) with ghosts, t, step (absent if the Driver never built)
  checkpoint.npz      last checkpoint (optional, for resuming an interrupted run)
  traceback.txt       CRASHED / REFUSED only
  report.html (+ report.pdf if a PDF engine is available)
  SHA256SUMS          every file above
and <bundle>.zip next to it.
compare_bundles(a, b, threshold=0.0) — GPU leg vs CPU leg (or run vs rerun): per-array max |diff| of the final states.
"""
import os, sys, io, json, time, uuid, base64, hashlib, zipfile, traceback, datetime
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT_DIR = os.path.dirname(HERE)
if ROOT_DIR not in sys.path: sys.path.insert(0, ROOT_DIR)
import aladin_driver_v40 as D

BM_VERSION = "ALADIN MakeReport bundle manager v1.0 2026-11-20"
CREDITS = "Mihai Alexandru Bucurenciu (ALADIN) · AI assistant Team: SuperGrok, Claude, ChatGPT"
OPS = {"<=": lambda v, t: v <= t, "<": lambda v, t: v < t, "==": lambda v, t: v == t, ">=": lambda v, t: v >= t, ">": lambda v, t: v > t}


def _now(): return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
def _sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def _dump(path, obj): open(path, "w").write(json.dumps(D._jsonable(obj), indent=1, default=str))
def _append(path, obj):
    with open(path, "a") as f: f.write(json.dumps(D._jsonable(obj), default=str) + "\n"); f.flush(); os.fsync(f.fileno())
def _readlines(path):
    if not os.path.exists(path): return []
    out = []
    for line in open(path):
        try: out.append(json.loads(line))
        except json.JSONDecodeError: pass                                   # a half-written last line after a hard kill
    return out


class _Tee(io.TextIOBase):
    def __init__(self, a, path): self.a = a; self.f = open(path, "a")
    def write(self, s): self.a.write(s); self.f.write(s); self.f.flush(); return len(s)
    def flush(self): self.a.flush(); self.f.flush()


class RunBundle:
    """with RunBundle("runs", "static pinch", thresholds={"max_dU": ("==", 0.0, "static state unchanged")}) as rb:
           d = rb.driver(cfg, ic); rb.run(nsteps=50); rb.check("max_dU", value)"""

    def __init__(self, root, label, thresholds=None, checkpoint_every=0, meta=None):
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in label)[:48]
        self.dir = os.path.join(root, f"{safe}_{stamp}_{uuid.uuid4().hex[:6]}"); os.makedirs(self.dir)
        self.label = label; self.d = None; self.checkpoint_every = checkpoint_every; self.values = {}
        self.thresholds = {k: dict(op=v[0], threshold=v[1], meaning=v[2] if len(v) > 2 else "") for k, v in (thresholds or {}).items()}
        for k, v in self.thresholds.items():
            if v["op"] not in OPS: raise ValueError(f"threshold {k}: unknown operator {v['op']}")
        _dump(self.p("thresholds.json"), dict(declared=_now(), label=label, checks=self.thresholds, meta=meta or {}))
        self.thresholds_sha = _sha(self.p("thresholds.json"))
        self.status = dict(label=label, status="RUNNING", opened=_now(), pid=os.getpid(), bundle_manager=BM_VERSION,
                           thresholds_sha256=self.thresholds_sha, heartbeat=None)
        self._write_status(); self._ev = 0

    def p(self, name): return os.path.join(self.dir, name)
    def _write_status(self): _dump(self.p("status.json"), self.status)

    # ------------------------------------------------------------------ context
    def __enter__(self):
        self._stdout = sys.stdout; sys.stdout = _Tee(self._stdout, self.p("log.txt")); return self

    def __exit__(self, et, ev, tb):
        sys.stdout = self._stdout
        if et is None: st = self.d.status if self.d is not None else "COMPLETED"
        elif issubclass(et, KeyboardInterrupt): st = "INTERRUPTED"
        elif issubclass(et, D.AdmissibilityError): st = "REFUSED" if self.d is None else "FAILED"
        else: st = "CRASHED"
        if et is not None: open(self.p("traceback.txt"), "w").write("".join(traceback.format_exception(et, ev, tb)))
        self.close(st)
        return et is not None and issubclass(et, D.AdmissibilityError)       # refusal is a result, not an exception

    # ------------------------------------------------------------------ driver
    def driver(self, cfg, ic, **kw):
        self.d = D.Driver(cfg, ic, **kw)                                      # AdmissibilityError here -> REFUSED bundle
        _dump(self.p("manifest.json"), dict(self.d.manifest, totals0=self.d.tot0)); self._flush_events(); return self.d

    def _flush_events(self):
        for e in self.d.events[self._ev:]: _append(self.p("events.jsonl"), e)
        self._ev = len(self.d.events)

    def _on_step(self, d, rec):
        _append(self.p("history.jsonl"), rec); self._flush_events()
        self.status["heartbeat"] = dict(step=d.step, t=d.t, wall=_now()); self._write_status()
        if self.checkpoint_every and d.step % self.checkpoint_every == 0: d.save(self.p("checkpoint"))
        if self._user_cb: self._user_cb(d, rec)

    def run(self, on_step=None, **kw):
        self._user_cb = on_step
        st = self.d.run(on_step=self._on_step, **kw); self._flush_events(); return st

    # ------------------------------------------------------------------ checks
    def check(self, name, value):
        if name not in self.thresholds:
            raise KeyError(f"check '{name}' was not declared before the run; undeclared checks are not accepted")
        self.values[name] = value

    def evaluate(self):
        rows = {}
        for k, th in self.thresholds.items():
            if k not in self.values: rows[k] = dict(th, value=None, result="NOT EVALUATED"); continue
            v = self.values[k]
            ok = OPS[th["op"]](v, th["threshold"]) if v is not None and not (isinstance(v, float) and np.isnan(v)) else False
            rows[k] = dict(th, value=v, result="PASS" if ok else "FAIL")
        return rows

    # ------------------------------------------------------------------ close
    def close(self, st):
        if self.d is not None:
            self._flush_events()
            np.savez(self.p("final_state.npz"), *[D._host(x) for x in self.d.U + self.d.B], t=np.float64(self.d.t), step=np.int64(self.d.step))
            if self.d.status == "RUNNING": self.d.status = st
            _dump(self.p("manifest.json"), dict(self.d.manifest, status=st, t=self.d.t, step=self.d.step, totals0=self.d.tot0, totals=self.d.totals()))
        if "expected_status" in self.thresholds: self.values["expected_status"] = st      # the observed status, always
        rows = self.evaluate()
        verdict = _verdict(st, rows)
        _dump(self.p("results.json"), dict(status=st, verdict=verdict, checks=rows, thresholds_sha256=self.thresholds_sha))
        self.status.update(status=st, verdict=verdict, closed=_now()); self._write_status()
        finish(self.dir)


def _verdict(st, rows):
    if st != "COMPLETED": return st if st in ("REFUSED", "FAILED") and _expected(rows, st) else f"NOT QUALIFIED ({st})"
    res = [r["result"] for r in rows.values()]
    if not res: return "COMPLETED (no checks declared)"
    if "FAIL" in res: return "FAIL"
    if "NOT EVALUATED" in res: return "INCOMPLETE"
    return "PASS"


def _expected(rows, st):
    """a test that EXPECTS a refusal/failure declares a check 'expected_status' == st"""
    r = rows.get("expected_status"); return r is not None and r["result"] == "PASS"


def finish(bdir):
    """report + checksums + zip (also used for stale bundles)"""
    try: make_report(bdir)
    except Exception: open(os.path.join(bdir, "report_error.txt"), "w").write(traceback.format_exc())
    files = sorted(f for f in os.listdir(bdir) if f != "SHA256SUMS" and os.path.isfile(os.path.join(bdir, f)))
    open(os.path.join(bdir, "SHA256SUMS"), "w").write("".join(f"{_sha(os.path.join(bdir, f))}  {f}\n" for f in files))
    with zipfile.ZipFile(bdir.rstrip("/") + ".zip", "w", zipfile.ZIP_DEFLATED) as z:
        for f in files + ["SHA256SUMS"]: z.write(os.path.join(bdir, f), os.path.join(os.path.basename(bdir), f))
    return bdir + ".zip"


def _alive(pid):
    try: os.kill(pid, 0); return True
    except (OSError, TypeError): return False


def finalize_stale(root, force=False):
    """close every bundle still marked RUNNING whose process is gone (hard kill / disconnect) as INTERRUPTED"""
    done = []
    for name in sorted(os.listdir(root)):
        b = os.path.join(root, name); sp = os.path.join(b, "status.json")
        if not os.path.isdir(b) or not os.path.exists(sp): continue
        s = json.load(open(sp))
        if s.get("status") != "RUNNING" or (_alive(s.get("pid")) and not force): continue
        th = json.load(open(os.path.join(b, "thresholds.json")))["checks"]
        rows = {k: dict(v, value=None, result="NOT EVALUATED") for k, v in th.items()}
        s.update(status="INTERRUPTED", verdict="NOT QUALIFIED (INTERRUPTED)", closed=_now(),
                 note="closed by finalize_stale: no live process; data up to the last heartbeat")
        _dump(sp, s); _dump(os.path.join(b, "results.json"), dict(status="INTERRUPTED", verdict=s["verdict"], checks=rows, thresholds_sha256=s.get("thresholds_sha256")))
        finish(b); done.append(b)
    return done


def compare_bundles(a, b, threshold=0.0, out=None):
    """final-state comparison of two bundles (e.g. GPU leg vs CPU leg); writes comparison.json in `out` (default: bundle b)"""
    A, Bz = np.load(os.path.join(a, "final_state.npz")), np.load(os.path.join(b, "final_state.npz"))
    names = ["rho", "m_r", "m_phi", "m_z", "E", "Br", "Bphi", "Bz"]
    rows = {}
    for i, n in enumerate(names):
        x, y = A[f"arr_{i}"], Bz[f"arr_{i}"]
        diff = np.abs(x - y); nz = diff > 0
        rows[n] = dict(max_abs=float(diff.max()), n_differ=int(nz.sum()), n=int(diff.size),
                       at=[int(v) for v in np.unravel_index(int(diff.argmax()), diff.shape)] if nz.any() else None,
                       max_rel=float((diff[nz] / np.maximum(np.abs(x[nz]), 1e-300)).max()) if nz.any() else 0.0)
    worst = max(r["max_abs"] for r in rows.values())
    res = dict(a=os.path.basename(a), b=os.path.basename(b), t_a=float(A["t"]), t_b=float(Bz["t"]), step_a=int(A["step"]), step_b=int(Bz["step"]),
               threshold=threshold, max_abs=worst, verdict="PASS" if worst <= threshold and int(A["step"]) == int(Bz["step"]) else "FAIL", arrays=rows, compared=_now())
    _dump(os.path.join(out or b, "comparison.json"), res); return res


# ====================================================================================================== report
CSS = """body{font-family:Georgia,serif;max-width:980px;margin:24px auto;padding:0 16px;color:#1d2433;background:#fff;line-height:1.45}
h1{font-size:24px;margin:0 0 4px}h2{font-size:17px;border-bottom:1px solid #c9cfdb;padding-bottom:3px;margin-top:26px}
.sub{color:#5a6478;font-size:13px}table{border-collapse:collapse;width:100%;font-size:12.5px;margin:6px 0}
td,th{border:1px solid #d5dae4;padding:4px 7px;text-align:left;vertical-align:top}th{background:#f1f3f8}
code,.mono{font-family:Menlo,Consolas,monospace;font-size:11.5px}.PASS{color:#11703a;font-weight:bold}.FAIL{color:#b3261e;font-weight:bold}
.NOT{color:#8a6100;font-weight:bold}.badge{display:inline-block;padding:4px 12px;border-radius:4px;font-weight:bold;font-family:sans-serif;font-size:14px}
.bPASS{background:#dff3e6;color:#11703a}.bFAIL{background:#fbe1df;color:#b3261e}.bOTHER{background:#fff1cc;color:#7a5600}
img{max-width:100%}pre{background:#f6f7fa;padding:8px;font-size:11px;overflow-x:auto;white-space:pre-wrap}
footer{margin-top:30px;color:#5a6478;font-size:12px;border-top:1px solid #c9cfdb;padding-top:6px}"""


def _fig(hist, ref=None):
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except Exception: return ""
    if not hist: return ""
    st = [h["step"] for h in hist]; fig, ax = plt.subplots(1, 3, figsize=(12, 3.1))
    ax[0].semilogy(st, [h["dt"] for h in hist], lw=1.2); ax[0].set_title("dt"); ax[0].set_xlabel("step")
    rp = [h.get("recovery_passes", 0) for h in hist]
    if any(rp):
        a2 = ax[0].twinx(); a2.bar(st, rp, color="#d9822b", alpha=0.45, width=1.0); a2.set_ylabel("recovery passes", fontsize=8)
    ref = ref or hist[0]; m0, e0 = ref.get("mass"), ref.get("energy")
    if m0 is not None:
        f = lambda k, r: [max(abs(h[k] - r) / max(abs(r), 1.0), 1e-17) for h in hist]
        ax[1].semilogy(st, f("mass", m0), label="mass"); ax[1].semilogy(st, f("energy", e0), label="energy"); ax[1].legend(fontsize=8)
        ax[1].set_title("relative drift vs t = 0" if ref is not hist[0] else "relative drift vs first step"); ax[1].set_xlabel("step")
        ax[2].semilogy(st, [max(h.get("divB_norm", np.nan), 1e-18) for h in hist]); ax[2].set_title("max normalised div B"); ax[2].set_xlabel("step")
    fig.text(0.5, 0.005, "exact zeros are drawn at the floor (1e-17 drift, 1e-18 div B)", ha="center", fontsize=7, color="#5a6478")
    fig.tight_layout(rect=(0, 0.04, 1, 1)); b = io.BytesIO(); fig.savefig(b, format="png", dpi=110); plt.close(fig)
    return f'<img alt="run history" src="data:image/png;base64,{base64.b64encode(b.getvalue()).decode()}">'


def make_report(bdir):
    J = lambda n, d=None: json.load(open(os.path.join(bdir, n))) if os.path.exists(os.path.join(bdir, n)) else d
    s = J("status.json", {}); r = J("results.json", {}); m = J("manifest.json", {}); th = J("thresholds.json", {})
    hist = _readlines(os.path.join(bdir, "history.jsonl")); evs = _readlines(os.path.join(bdir, "events.jsonl"))
    v = r.get("verdict", s.get("status", "?")); bc = "bPASS" if v in ("PASS",) else "bFAIL" if v == "FAIL" else "bOTHER"
    esc = lambda x: str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    H = [f"<!doctype html><html><head><meta charset='utf-8'><title>ALADIN run report</title><style>{CSS}</style></head><body>",
         f"<h1>ALADIN Driver run — {esc(s.get('label', ''))}</h1>",
         f"<div class='sub'>{esc(m.get('driver', ''))} · {esc(BM_VERSION)} · bundle <span class='mono'>{esc(os.path.basename(bdir))}</span></div>",
         f"<p><span class='badge {bc}'>{esc(v)}</span> &nbsp; status <b>{esc(s.get('status'))}</b> · opened {esc(s.get('opened'))} · closed {esc(s.get('closed'))}"
         f" · steps {esc(m.get('step', (s.get('heartbeat') or {}).get('step')))} · t = {esc(m.get('t', (s.get('heartbeat') or {}).get('t')))}</p>"]
    if s.get("note"): H.append(f"<p><b>Note:</b> {esc(s['note'])}</p>")
    H.append(f"<h2>Checks (declared {esc(th.get('declared'))}, before the run; thresholds sha256 <span class='mono'>{esc(str(s.get('thresholds_sha256'))[:16])}…</span>)</h2>")
    rows = (r.get("checks") or {})
    if rows:
        H.append("<table><tr><th>check</th><th>meaning</th><th>rule</th><th>value</th><th>result</th></tr>")
        for k, c in rows.items():
            cls = c["result"].split()[0]
            H.append(f"<tr><td class='mono'>{esc(k)}</td><td>{esc(c.get('meaning', ''))}</td><td class='mono'>{esc(c['op'])} {esc(c['threshold'])}</td>"
                     f"<td class='mono'>{esc(c['value'])}</td><td class='{cls}'>{esc(c['result'])}</td></tr>")
        H.append("</table>")
    else: H.append("<p>No checks were declared for this run.</p>")
    if os.path.exists(os.path.join(bdir, "comparison.json")):
        c = J("comparison.json"); H.append(f"<h2>Comparison with <span class='mono'>{esc(c['a'])}</span> — <span class='{c['verdict']}'>{c['verdict']}</span> (threshold {c['threshold']})</h2><table><tr><th>array</th><th>max |diff|</th><th>max rel</th><th>cells differing</th><th>worst index</th></tr>")
        for k, a in c["arrays"].items(): H.append(f"<tr><td>{k}</td><td class='mono'>{a['max_abs']:.3e}</td><td class='mono'>{a['max_rel']:.3e}</td><td>{a['n_differ']} / {a['n']}</td><td class='mono'>{a['at']}</td></tr>")
        H.append("</table>")
    H.append("<h2>Run history</h2>" + (_fig(hist, m.get("totals0")) or "<p>No steps recorded.</p>"))
    if os.path.exists(os.path.join(bdir, "traceback.txt")): H.append(f"<h2>Traceback</h2><pre>{esc(open(os.path.join(bdir, 'traceback.txt')).read())}</pre>")
    H.append(f"<h2>Events ({len(evs)})</h2>")
    if evs:
        H.append("<table><tr><th>step</th><th>event</th><th>details</th></tr>")
        for e in evs[:60]:
            det = {k: v_ for k, v_ in e.items() if k not in ("step", "event")}
            H.append(f"<tr><td>{esc(e.get('step'))}</td><td>{esc(e.get('event'))}</td><td class='mono'>{esc(json.dumps(det, default=str))[:400]}</td></tr>")
        H.append("</table>" + (f"<p>… {len(evs) - 60} more in events.jsonl</p>" if len(evs) > 60 else ""))
    if m.get("kernels"):
        H.append("<h2>Kernels (hash-verified at start)</h2><table><tr><th>slot</th><th>file</th><th>certified hash</th><th>build sha256</th><th>record</th></tr>")
        for k, kk in m["kernels"].items():
            H.append(f"<tr><td>{esc(k)}</td><td class='mono'>{esc(kk['file'])}</td><td class='mono'>{esc(kk['hash_kind'])} {esc(kk['certified_hash'][:16])}…</td>"
                     f"<td class='mono'>{esc(str(kk.get('build_sha256'))[:16])}…</td><td class='mono'>{esc(kk['record'])}</td></tr>")
        H.append("</table>")
    if m.get("config"):
        H.append("<h2>Configuration</h2><table>" + "".join(f"<tr><td class='mono'>{esc(k)}</td><td class='mono'>{esc(v_)}</td></tr>" for k, v_ in m["config"].items()) + "</table>")
    if m.get("environment"):
        H.append("<h2>Environment</h2><table>" + "".join(f"<tr><td class='mono'>{esc(k)}</td><td class='mono'>{esc(v_)}</td></tr>" for k, v_ in m["environment"].items())
                 + f"<tr><td class='mono'>gpu_ieee_selftest</td><td class='mono'>{esc(m.get('gpu_ieee_selftest'))}</td></tr></table>")
        H.append(f"<p class='sub'>Pipeline: {esc(m.get('stage_pipeline'))}<br>Not coupled: {esc(', '.join(m.get('not_coupled', [])))}</p>")
    H.append(f"<footer>{CREDITS}</footer></body></html>")
    open(os.path.join(bdir, "report.html"), "w").write("\n".join(H))
    if os.environ.get("ALADIN_PDF", "1") == "1":
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                br = pw.chromium.launch(); pg = br.new_page(); pg.goto("file://" + os.path.abspath(os.path.join(bdir, "report.html")))
                pg.pdf(path=os.path.join(bdir, "report.pdf"), format="A4", margin=dict(top="14mm", bottom="14mm", left="12mm", right="12mm"), print_background=True); br.close()
        except Exception as x:
            open(os.path.join(bdir, "report_pdf_skipped.txt"), "w").write(f"PDF not produced: {x!r}\n(report.html is complete; PDF needs playwright + chromium)\n")
