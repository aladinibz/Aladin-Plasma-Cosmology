# -*- coding: utf-8 -*-
"""CHECKPOINT MANAGER — save / load the full state for a bit-identical restart:
  <path>.npz  : U (5) + B (3) + the held boundary state U0 (5) + B0 (3), with ghosts, plus t and step (full precision)
  <path>.json : the run manifest, t, step, time, sha256 of the .npz
  load checks the format: 16 arrays, shapes equal to this grid, dtype equal to this precision, sha256 of the .npz;
  a mismatch is REFUSED (a restart onto a different grid or precision is never silent)."""
import os, json, hashlib
import numpy as np
from .common import AdmissibilityError, host, now


class CheckpointManager:
    def __init__(self, cfg, grids, xp):
        self.cfg = cfg; self.gm = grids; self.xp = xp

    def save(self, s, path):
        np.savez(path, *[host(x) for x in s.U + s.B + s.U0 + s.B0], t=np.float64(s.t), step=np.int64(s.step))
        f = path if path.endswith(".npz") else path + ".npz"
        sha = hashlib.sha256(open(f, "rb").read()).hexdigest()
        with open((path[:-4] if path.endswith(".npz") else path) + ".json", "w") as fh:
            json.dump(dict(manifest=s.manifest, t=s.t, step=s.step, saved=now(), npz_sha256=sha), fh, indent=1, default=str)

    def load(self, s, path):
        f = path if path.endswith(".npz") else path + ".npz"; base = f[:-4]
        if os.path.exists(base + ".json"):
            want = json.load(open(base + ".json")).get("npz_sha256")
            if want and hashlib.sha256(open(f, "rb").read()).hexdigest() != want: raise AdmissibilityError(f"checkpoint {f}: sha256 mismatch (file changed)")
        d = np.load(f)
        if len([k for k in d.files if k.startswith("arr_")]) != 16: raise AdmissibilityError(f"checkpoint {f}: not a v4.0 checkpoint (16 arrays expected)")
        arrs = [d[f"arr_{i}"] for i in range(16)]
        for i, a in enumerate(arrs):
            ref = (s.U + s.B)[i % 8]
            if a.shape != tuple(ref.shape) or a.dtype != ref.dtype:
                raise AdmissibilityError(f"checkpoint {f}: array {i} is {a.shape} {a.dtype}, this run needs {tuple(ref.shape)} {ref.dtype}")
        T = lambda a: self.xp.asarray(np.ascontiguousarray(a))
        s.U = [T(a) for a in arrs[0:5]]; s.B = [T(a) for a in arrs[5:8]]; s.U0 = [T(a) for a in arrs[8:13]]; s.B0 = [T(a) for a in arrs[13:16]]
        s.t = float(d["t"]); s.step = int(d["step"])
