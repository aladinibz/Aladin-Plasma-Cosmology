# -*- coding: utf-8 -*-
"""INITIAL CONDITIONS — each returns ic(driver) -> dict(U=[rho, m_r, m_phi, m_z, E], B=[Br, Bphi, Bz]) on the ghost-extended grid
(NumPy), optionally with the equilibrium for the well-balanced mode: U_eq, B_eq, prim_eq [rho, vr, vphi, vz, p] (exact),
W_eq_faces {0: (8, radial faces)} (exact face values for HLLD)."""
import numpy as np


def ic_zpinch(P0=1.0, perturb=None):
    """README normalised Z-pinch (mu0 = 1): rho = 1, v = 0, B_phi = r/2, J_z = 1, P = P0 - r^2/4, div B = 0.
    perturb(driver, rc, phc, zc) -> dp, an optional pressure perturbation added to E as dp / (gamma - 1)."""
    def ic(d):
        G = d.GE; g = G.g; sh = G.shape("cell"); rc = G.r_centers
        Bp = np.zeros(G.shape("Bphi")); Bp[:] = (0.5 * rc)[:, None, None]; B = [np.zeros(G.shape("Br")), Bp, np.zeros(G.shape("Bz"))]
        p = (P0 - 0.25 * rc ** 2)[:, None, None] * np.ones(sh); one = np.ones(sh); z0 = np.zeros(sh)
        Gp = d.PR.Grid(d.cfg.nr, d.cfg.nphi, d.cfg.nz, d.cfg.r_min, d.cfg.r_max, zlen=d.cfg.z_len, g=g)
        Ue = d.PR.conserved(Gp, one, z0, z0, z0, p, *B, gamma=d.cfg.gamma); U_eq = [Ue[k] for k in ("rho", "m_r", "m_phi", "m_z", "E")]
        U = [x.copy() for x in U_eq]
        if perturb is not None:
            dp = perturb(d, rc[:, None, None], G.phi_c[None, :, None], G.z_c[None, None, :]); U[4] = U[4] + dp / (d.cfg.gamma - 1)
        rfi = G.r_faces[g:g + d.cfg.nr + 1][:, None, None]; Wf = np.zeros(d.GH.shape("F_r"))
        Wf[0] = 1; Wf[4] = P0 - 0.25 * rfi ** 2; Wf[6] = 0.5 * rfi
        return dict(U=U, B=B, U_eq=U_eq, B_eq=[x.copy() for x in B], prim_eq=[one, z0, z0, z0, p], W_eq_faces={0: Wf})
    return ic


# ==================================================================================================== DRV-01 test states
def _conserved(d, rho, vr, vp, vz, p, B):
    g = d.GE.g; sh = d.GE.shape("cell"); bc = lambda a: np.ascontiguousarray(np.broadcast_to(a, sh), dtype=np.float64)
    Gp = d.PR.Grid(d.cfg.nr, d.cfg.nphi, d.cfg.nz, d.cfg.r_min, d.cfg.r_max, zlen=d.cfg.z_len, g=g)
    U = d.PR.conserved(Gp, bc(rho), bc(vr), bc(vp), bc(vz), bc(p), *B, gamma=d.cfg.gamma)
    return [U[k] for k in ("rho", "m_r", "m_phi", "m_z", "E")]


def transverse_B(d, bx, by, Bz0=0.0):
    """CT faces of B = (bx(z), by(z), Bz0) (Cartesian, uniform in x and y).  B_r on r-faces is the FACE AVERAGE over the
    face's phi interval (sin(dphi/2)/(dphi/2) * (bx cos phi_c + by sin phi_c)), B_phi on phi-faces the point value: with
    these, the discrete cylindrical divergence vanishes identically, axis included."""
    G = d.GE; ph_c = G.phi_c[None, :, None]; ph_f = G.phi_f[None, :, None]; s = np.sin(G.dphi / 2) / (G.dphi / 2)
    zc = G.z_c[None, None, :]
    Br = np.zeros(G.shape("Br")); Bp = np.zeros(G.shape("Bphi")); Bz = np.full(G.shape("Bz"), float(Bz0))
    Br[:] = s * (bx(zc) * np.cos(ph_c) + by(zc) * np.sin(ph_c)); Bp[:] = -bx(zc) * np.sin(ph_f) + by(zc) * np.cos(ph_f)
    return [Br, Bp, Bz]


def ic_circular_wave(k, eps, B0=1.0, rho0=1.0, p0=1.0, hall=0.0, branch=+1):
    """exact (nonlinear) circularly polarised Alfven / Hall wave along z: b = eps (cos th, sin th), th = k z - w t,
    v = a b with a = -B0 k / (rho0 w);  w^2 + H w - vA^2 k^2 = 0, H = hall B0 k^2 / rho0 (Hall MHD), H = 0 Alfven.
    branch +1: the root w > 0, branch -1: the root w < 0."""
    H = hall * B0 * k * k / rho0; vA2 = B0 * B0 / rho0
    w = (-H + branch * np.sqrt(H * H + 4 * vA2 * k * k)) / 2; a = -B0 * k / (rho0 * w)
    def ic(d):
        G = d.GE; ph = G.phi_c[None, :, None]; zc = G.z_c[None, None, :]
        bx = lambda z: eps * np.cos(k * z); by = lambda z: eps * np.sin(k * z)
        B = transverse_B(d, bx, by, B0)
        vx, vy = a * bx(zc), a * by(zc)
        vr = vx * np.cos(ph) + vy * np.sin(ph); vp = -vx * np.sin(ph) + vy * np.cos(ph)
        return dict(U=_conserved(d, rho0, vr, vp, 0.0, p0, B), B=B, omega=w)
    ic.omega = w
    return ic


def ic_resistive_decay(k, eps, p0=100.0):
    """B = (eps sin(k z), 0, 0) Cartesian, uniform high-beta plasma at rest: exact resistive decay exp(-eta k^2 t)
    (the eps^2 magnetic pressure force is negligible against p0)"""
    def ic(d):
        B = transverse_B(d, lambda z: eps * np.sin(k * z), lambda z: 0.0 * z, 0.0)
        return dict(U=_conserved(d, 1.0, 0.0, 0.0, 0.0, p0, B), B=B)
    return ic


def ic_sod_z(z0=0.5, left=(1.0, 1.0), right=(0.125, 0.1)):
    """Sod shock tube along z, uniform in r and phi, B = 0: rho, p = left for z < z0, right otherwise"""
    def ic(d):
        G = d.GE; zc = G.z_c[None, None, :]
        rho = np.where(zc < z0, left[0], right[0]); p = np.where(zc < z0, left[1], right[1])
        B = [np.zeros(G.shape("Br")), np.zeros(G.shape("Bphi")), np.zeros(G.shape("Bz"))]
        return dict(U=_conserved(d, rho, 0.0, 0.0, 0.0, p, B), B=B)
    return ic


def ic_pinch_mode(mode, eps, P0=1.0):
    """README Z-pinch + eps x a linear eigenmode (m = 0) given as radial profiles (dict from the D07 oracle: rf, rc, vr on faces,
    rho, vz, p, Bp on centres; complex, field = Re[f(r) exp(i k z)]).  The equilibrium (exact) is kept for well-balancing."""
    k = float(mode["k"])
    def ic(d):
        x = ic_zpinch(P0)(d); G = d.GE; rc = G.r_centers; zc = G.z_c[None, None, :]; ez = np.exp(1j * k * zc)
        at = lambda prof, r: np.interp(np.abs(r), mode["rc"], prof.real) + 1j * np.interp(np.abs(r), mode["rc"], prof.imag)
        R = lambda prof: (prof[:, None, None] * ez).real
        vr_c = (np.interp(np.abs(rc), mode["rf"], mode["vr"].real) * np.sign(rc)).astype(complex)
        rho = 1 + eps * R(at(mode["rho"], rc)); p = (P0 - 0.25 * rc ** 2)[:, None, None] + eps * R(at(mode["p"], rc))
        B = [x["B"][0].copy(), x["B"][1] + np.broadcast_to(eps * R(at(mode["Bp"], rc)), (G.shape("Bphi")[0], 1, G.shape("Bphi")[2])), x["B"][2].copy()]
        x["U"] = _conserved(d, rho, eps * R(vr_c), 0.0, eps * R(at(mode["vz"], rc)), p, B); x["B"] = B
        return x
    return ic


def ic_flux_tube(x0=0.4, w=0.2, amp=0.5, p0=1.0):
    """off-axis B_z flux tube B_z = 1 + amp exp(-((x - x0)^2 + y^2)/w^2), plasma at rest (D13 energy accounting; m != 0)"""
    def ic(d):
        G = d.GE; rc = G.r_centers[:, None, None]; ph = G.phi_c[None, :, None]
        X, Y = rc * np.cos(ph), rc * np.sin(ph)
        B = [np.zeros(G.shape("Br")), np.zeros(G.shape("Bphi")), np.zeros(G.shape("Bz"))]
        B[2][:] = (1 + amp * np.exp(-((X - x0) ** 2 + Y ** 2) / w ** 2))
        return dict(U=_conserved(d, 1.0, 0.0, 0.0, 0.0, p0, B), B=B)
    return ic
