# ALADIN Driver v4.0 — layout
Author: Mihai Alexandru Bucurenciu (ALADIN) · AI assistant Team: SuperGrok, Claude, ChatGPT

Backends: `backend="cpu"` or `backend="cupy"` (GPU); same code, same certified kernels.

```
aladin_driver_v40.py      the conductor: Config -> BuildManager -> wires the managers
managers/
  config.py               every setting of a run (recorded in each bundle)
  build_manager.py        kernel registry, certified-hash check, precision policy, GPU IEEE self-test, environment
  grid_manager.py         one grid for every kernel; axis / annulus; even-nphi rule; volumes, rbar
  memory_manager.py       GPU memory pool + pinned pool; refuses a grid that cannot fit; peak usage per step
  boundary_manager.py     axis reflection, staggered phi seams, z periodic/outflow, outer r fixed/outflow, J ghosts
  pipeline.py             one RHS in the certified order: PRIM -> HLLD-R/phi/Z -> RESIDUAL -> UCT-CURL -> UCT-EMF
  timestep_manager.py     CFL (fast speed, r dphi at the axis, resistive and Hall limits)
  integrator.py           SSP-RK3, transactional, local recovery -> dt halving -> explicit STOP
  diagnostics_manager.py  mass, energy, pz, L, div B, G2 (read-only)
  checkpoint_manager.py   bit-identical restart; refuses wrong grid / precision / modified files
  initial_conditions.py   README Z-pinch (exact equilibrium) + perturbations
  bundle_manager.py       MakeReport: bundles, predeclared thresholds, reports, GPU-vs-CPU comparison
  common.py               shared helpers (no physics)
kernels/                  the certified kernels, unmodified (hash-checked at every start)
tests/
  smoke_drv00.py          SMK-00 (8)    bm_selftest.py  BM-00 (10)    managers_selftest.py  MG-00 (5)
  zp_step.py              CHAIN-01 harness (reference for S1)
  smk00_states_cpu.npz    CPU final states for the GPU = CPU comparison
  drv01.py                DRV-01 certification campaign (13 tests, thresholds frozen 2026-11-21)   python drv01.py cpu|gpu
  drv01_addendum_A1.py    addendum A1 (joint r, phi, z refinement; declared after the CPU leg)
  oracle_linear_pinch.py  independent linear eigen-solver (D07 reference)
  drv01_frozen_modes.npz  oracle eigenmodes frozen on the CPU-leg machine (the GPU leg loads them)
  drv01_states_cpu.npz    CPU-leg final states (D11 GPU = CPU)
  probe_kw00..03.py       kernel-wise and lockstep GPU-vs-CPU probes
  readme_benchmark_driver.py   README Z-pinch through the Driver
  make_results_drv01.py   -> DRV01_RESULTS.json / .md
  runs_drv01_cpu/, gpu_leg_run1/, gpu_leg_run2/   checksummed bundles of every leg
```
  oracle_cheb_pinch.py    ORACLE-2: Chebyshev-collocation linear stability oracle (m = 0 and m = 1, axis parity)
  kink01.py               DRV-02 K01: the m = 1 kink (thresholds approved before any run)   python kink01.py cpu|gpu
  kink01_frozen_ic.npz    K01 initial states frozen on the CPU-leg machine;  probe_k01.py  the K-b probe
  make_results_drv02.py   -> DRV02_RESULTS.json

DRV-02 K01: PASS (kink growth 0.73 % vs ORACLE-2, order 2.97, purity 1e-4, GPU = CPU 0).
DRV-01: 9 PASS / 4 FAIL (D03, D04, D06, D13: accuracy limits, explained in the report); D11 GPU = CPU: 0 values differing.
Not yet: GravityManager, ScienceManager (re-attach from v3.1), GYRO coupling (anisotropic pressure).
