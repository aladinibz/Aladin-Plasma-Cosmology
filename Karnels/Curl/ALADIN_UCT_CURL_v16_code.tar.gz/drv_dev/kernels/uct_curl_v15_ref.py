"""
uct_curl.py  (v1.4)  --  cell-centered  C = curl(B)  on a native cylindrical Yee grid.

v1.5 (2026-11-23, ALADIN Driver DRV-03 diagnosis): AXIS-MODE STENCIL FIX -- the Cartesian reconstruction now converts the
phi-averaged Br to its point value before rotating (see the CART macro).  Found by the resistive-decay diagnosis: a uniform field
crossing the axis (J = 0 exactly) gave a spurious Jz ~ dphi^2/r at the axis ring (v1.4: 0.20 at 64x32), which made resistive
decay first order there.  The README pinch (m = 0, Br = 0) is bitwise unchanged; the annulus path is untouched.
v1.4 (2026-11-21, ALADIN Driver v4.0 KW-00 probe): BUILD AND DISPATCH ONLY -- the stencil source _KERNEL_SRC is
byte-identical to v1.3 (KERNEL_SRC_SHA256 below).  KW-00 found GPU vs CPU differences in J (up to 4.2e-15) and that
run_curl ran on the GPU whenever CuPy was installed, whatever the Driver asked for.  v1.4:
  * CPU path = the SAME CUDA source compiled with g++ (-O2 -ffp-contract=off) through a host prelude that runs every
    thread of the launch grid in order (the v1.3 campaigns' HostBackend).  The NumPy emulation curl_numpy_flat is no
    longer a runtime path (it is kept as a test reference; its operation order differs from the C source).
  * GPU path = NVRTC DIRECTLY with -fmad=false -ftz=false -prec-div=true -prec-sqrt=true (cupy.RawKernel contracted
    a*b+c into FMA and appends -ftz=true); the PTX is checked free of .ftz.
  * run_curl(..., backend="cpu" | "cupy" | "auto"): an explicit backend is obeyed; "auto" keeps the v1.3 behaviour.
    device_out=True returns CuPy arrays (no host round trip).
  Result: GPU == CPU bit for bit, FP64 and FP32 (campaign CURL-06).

ROLE IN ALADIN
    This is the *current-density reconstruction* operator ("current_curl"):  J = curl(B)/mu0
    for Hall / resistive terms and J x B.  It is NOT the constrained-transport Faraday update
    curl(E) -> dB/dt.  It uses cell-centered averages, no face areas, no edge lengths, so it is
    NOT CT-compatible and must never be registered in the driver's CT `uct_curl` slot.

UNITS CONTRACT (mu0)
    The kernel returns curl(B) exactly, i.e. J in units where mu0 = 1.
    Physical current density = output / mu0.  The caller owns that division (exactly once).

GRID CONTRACT (enforced by validate_inputs; violations raise CurlContractError)
    Ghost width g >= 1 (g = 2 supported/tested).  nr, nphi, nz >= 1.
    Uniform dr, dphi, dz > 0 and finite.  dphi in RADIANS; full circle requires nphi*dphi == 2*pi
    (pass full_circle=False for a wedge, then nphi*dphi <= 2*pi).
    Staggering / shapes (C-contiguous, z fastest):
        Br   (nr+1+2g, nphi+2g,   nz+2g  )   radial  faces
        Bphi (nr+2g,   nphi+1+2g, nz+2g  )   azimuth faces
        Bz   (nr+2g,   nphi+2g,   nz+1+2g)   axial   faces
        J*   (nr+2g,   nphi+2g,   nz+2g  )   cell centers (only interior cells are written)
    r_faces (nr+1+2g), r_centers (nr+2g), indexed WITH ghosts; uniform spacing dr;
        r_centers[i] = 0.5*(r_faces[i]+r_faces[i+1]);  r_centers > 0 for every interior cell.
        (Axis at r_faces[g] = 0 gives first center dr/2 > 0; the old 1/r guard is therefore gone.)
    All arrays share one dtype (float32 or float64).
    OUTPUT OWNERSHIP: Jr, Jphi, Jz must be three distinct buffers that overlap neither each
        other nor any input.  Every interior cell is written exactly once; ghosts are untouched.
    Ghost cells of B must be filled by the caller (axis / periodic / outer BCs).

AXIS MODE (new in v1.2)  --  active iff r_faces[g] == 0 exactly (the grid contains the axis r = 0)
    v1.0/v1.1 divided O(h^2) interpolation errors by r, so Jz was only FIRST order near the axis for any field
    with a transverse (m = 1) component.  In axis mode, Jz is computed from the Cartesian components
    (Bx, By) of B at cell centres, using 4-point (cubic) face->centre interpolation (error O(h^4)), a one-sided
    3-point radial derivative on the axis ring and centred derivatives elsewhere.  Jz = rhat x d_r B + phihat x d_t B
    has no 1/r amplification.  Jphi on the axis ring uses a one-sided 3-point d(Bz)/dr.
    Consequences:
      * Jr, Jphi (rings >= 1) are bitwise identical to v1.1; Jz and Jphi(ring 0) change.
      * Inner radial ghost cells (index < g) are NEVER read in axis mode, so the driver does not need to fill them.
      * The axis FACE of Br (index g, r = 0) IS read and must hold the limiting value Br(0, phi, z).
      * Requires g >= 2 and nr >= 3.
    Grids with r_min > 0 (annulus) use exactly the v1.1 arithmetic (bitwise identical).

START-RADIUS CONTRACT (new in v1.3)
    r_faces[g] must be exactly 0 (axis mode) or >= AXIS_AMBIGUITY_FRACTION*dr (annulus).  Values in
    (0, 1e-3*dr) -- typically round-off such as 1e-17 from r0 + k*dr -- and negative values (grid straddling
    the axis) are REJECTED, because v1.2 silently ran the less accurate annulus stencil for them.  The driver
    must pass an exact 0.0 for an axis grid.  The 1e-3 value is a policy constant (see CAMPAIGN02 report,
    Test 019 threshold study): far above round-off noise (~nr*eps*dr ~ 1e-13 dr), far below any deliberate annulus.
    Axis grids additionally require nphi >= MIN_NPHI_AXIS (= 3).  That is a validity guard only: it does NOT
    mean 3 cells resolve an m = 1 mode (see the Test 019 resolution study).
"""
import numpy as np

try:
    import cupy as cp
except ImportError:  # no GPU stack: the NumPy emulation below is used instead
    cp = None

VERSION = "1.5"
AXIS_AMBIGUITY_FRACTION = 1e-3   # 0 < r_faces[g] < this*dr is rejected (neither a real annulus nor an exact axis)
MIN_NPHI_AXIS = 3                # axis closure divides by sin(dphi); fewer cells are not a valid grid (NOT a resolution claim)
MU0_CONTRACT = "output = curl(B) with mu0 = 1; physical J = output / mu0 (caller divides once)"


class CurlContractError(ValueError):
    """Raised when inputs violate the current_curl contract."""


_KERNEL_SRC = r"""
typedef REAL_T real;

#define BR(a,b,c)   Br  [(a)*sBr_r  + (b)*sBr_p  + (c)]
#define BP(a,b,c)   Bphi[(a)*sBp_r  + (b)*sBp_p  + (c)]
#define BZ(a,b,c)   Bz  [(a)*sBz_r  + (b)*sBz_p  + (c)]

/* face -> cell-center averages */
#define BRC(a,b,c)  ((real)0.5*(BR((a),(b),(c)) + BR((a)+1,(b),(c))))
#define BPC(a,b,c)  ((real)0.5*(BP((a),(b),(c)) + BP((a),(b)+1,(c))))
#define BZC(a,b,c)  ((real)0.5*(BZ((a),(b),(c)) + BZ((a),(b),(c)+1)))
/* Bphi interpolated to radial face a (between cell a-1 and a) */
#define BPF(a,b,c)  ((real)0.5*(BPC((a)-1,(b),(c)) + BPC((a),(b),(c))))

/* axis mode: Cartesian components of B at cell centre (A,B_,C_) from 4-point (cubic) interpolation.
   Radially centred (-1,9,9,-1)/16 on faces A-1..A+2; the axis ring (A==g) is one-sided (5,15,-5,1)/16 on faces A..A+3
   so no inner ghost is read.  Azimuthally centred on faces B_-1..B_+2.
   v1.5: Br on a radial face is the AVERAGE over the face's azimuthal extent dphi, while Bphi is a point value in phi.
   Br is therefore converted from its phi-average to its point value at the cell centre before the Cartesian rotation:
   Br_pt = Br_avg - (Br_avg[B_+1] - 2 Br_avg[B_] + Br_avg[B_-1]) / 24   (fourth order).  Without it the rotation mixes an
   average with point values: an O(dphi^2) error that the azimuthal derivative of Jz divides by r (first order at the
   axis for any field with an m = 1 part).  An axisymmetric field (README pinch) has Br = 0: unchanged to the bit. */
#define RADC(A,B_,C_) (((A) == g) \
        ? ((real)(1.0/16.0))*((real)5*BR((A),(B_),(C_)) + (real)15*BR((A)+1,(B_),(C_)) - (real)5*BR((A)+2,(B_),(C_)) + BR((A)+3,(B_),(C_))) \
        : ((real)(1.0/16.0))*(-BR((A)-1,(B_),(C_)) + (real)9*BR((A),(B_),(C_)) + (real)9*BR((A)+1,(B_),(C_)) - BR((A)+2,(B_),(C_))))
#define CART(A,B_,C_,BXV,BYV) { \
    const real brm_ = RADC((A),(B_)-1,(C_)), brz_ = RADC((A),(B_),(C_)), brp_ = RADC((A),(B_)+1,(C_)); \
    const real brc_ = brz_ - ((real)(1.0/24.0))*((brp_ - (real)2*brz_) + brm_); \
    const real bpc_ = ((real)(1.0/16.0))*(-BP((A),(B_)-1,(C_)) + (real)9*BP((A),(B_),(C_)) + (real)9*BP((A),(B_)+1,(C_)) - BP((A),(B_)+2,(C_))); \
    BXV = brc_*cos_pc[(B_)] - bpc_*sin_pc[(B_)]; \
    BYV = brc_*sin_pc[(B_)] + bpc_*cos_pc[(B_)]; }

extern "C" __global__
void current_curl_kernel(
    const real* __restrict__ Br,
    const real* __restrict__ Bphi,
    const real* __restrict__ Bz,
    real* __restrict__ Jr,
    real* __restrict__ Jphi,
    real* __restrict__ Jz,
    const real* __restrict__ r_faces,
    const real* __restrict__ r_centers,
    const real dr, const real dphi, const real dz,
    const int nr, const int nphi, const int nz, const int g,
    const real* __restrict__ cos_pc, const real* __restrict__ sin_pc,   /* cos/sin of phi cell centres, size nphi+2g */
    const real sin_dphi, const int axis)                                  /* axis = (r_faces[g] == 0) */
{
    int i = blockIdx.x*blockDim.x + threadIdx.x;
    int j = blockIdx.y*blockDim.y + threadIdx.y;
    int k = blockIdx.z*blockDim.z + threadIdx.z;
    if (i >= nr || j >= nphi || k >= nz) return;

    const int gi = i + g, gj = j + g, gk = k + g;
    const int nz_g = nz + 2*g, nphi_g = nphi + 2*g;

    /* per-array strides (z fastest) */
    const int sBr_r = nphi_g*nz_g,       sBr_p = nz_g;
    const int sBp_r = (nphi_g+1)*nz_g,   sBp_p = nz_g;
    const int sBz_r = nphi_g*(nz_g+1),   sBz_p = nz_g + 1;
    const int sr = nphi_g*nz_g,          sphi = nz_g;      /* J, cell-centered */

    /* contract: r_centers[gi] > 0 for all interior cells (checked by the host launcher) */
    const real rc_ = r_centers[gi];
    const real inv = (real)1.0/rc_;

    const real i2dphi = (real)0.5/dphi, i2dz = (real)0.5/dz, i2dr = (real)0.5/dr;

    /* Jr = (1/r) dBz/dphi - dBphi/dz */
    const real dBz_dphi = (BZC(gi,gj+1,gk) - BZC(gi,gj-1,gk))*i2dphi;
    const real dBp_dz   = (BPC(gi,gj,gk+1) - BPC(gi,gj,gk-1))*i2dz;

    /* Jphi = dBr/dz - dBz/dr */
    const real dBr_dz   = (BRC(gi,gj,gk+1) - BRC(gi,gj,gk-1))*i2dz;
    const real dBz_dr   = (axis && gi == g)
        ? ((real)-3*BZC(gi,gj,gk) + (real)4*BZC(gi+1,gj,gk) - BZC(gi+2,gj,gk))*i2dr      /* axis ring: one-sided, reads no ghost */
        : (BZC(gi+1,gj,gk) - BZC(gi-1,gj,gk))*i2dr;

    const int c = gi*sr + gj*sphi + gk;
    Jr  [c] = inv*dBz_dphi - dBp_dz;
    Jphi[c] = dBr_dz - dBz_dr;

    if (axis) {
        /* Jz = rhat_x d_r By - rhat_y d_r Bx + phihat_x d_t By - phihat_y d_t Bx   (no 1/r amplification) */
        real fx0, fy0, dxr, dyr, tx1, ty1, tx2, ty2;
        CART(gi, gj, gk, fx0, fy0)
        if (gi == g) {
            real fx1, fy1, fx2, fy2;
            CART(gi+1, gj, gk, fx1, fy1)
            CART(gi+2, gj, gk, fx2, fy2)
            dxr = ((real)-3*fx0 + (real)4*fx1 - fx2)*i2dr;
            dyr = ((real)-3*fy0 + (real)4*fy1 - fy2)*i2dr;
        } else {
            real fxp, fyp, fxm, fym;
            CART(gi+1, gj, gk, fxp, fyp)
            CART(gi-1, gj, gk, fxm, fym)
            dxr = (fxp - fxm)*i2dr;
            dyr = (fyp - fym)*i2dr;
        }
        CART(gi, gj+1, gk, tx1, ty1)
        CART(gi, gj-1, gk, tx2, ty2)
        const real inv_t = (real)1.0/((real)2.0*rc_*sin_dphi);
        const real dxt = (tx1 - tx2)*inv_t, dyt = (ty1 - ty2)*inv_t;
        const real cp0 = cos_pc[gj], sp0 = sin_pc[gj];
        Jz[c] = cp0*dyr - sp0*dxr - sp0*dyt - cp0*dxt;
    } else {
        /* Jz = (1/r) d(r Bphi)/dr - (1/r) dBr/dphi */
        const real rBp_hi   = r_faces[gi+1]*BPF(gi+1,gj,gk);
        const real rBp_lo   = r_faces[gi  ]*BPF(gi  ,gj,gk);
        const real dBr_dphi = (BRC(gi,gj+1,gk) - BRC(gi,gj-1,gk))*i2dphi;
        Jz  [c] = inv*((rBp_hi - rBp_lo)/dr - dBr_dphi);
    }
}
"""

import os, ctypes, hashlib, subprocess, tempfile

KERNEL_SRC_SHA256 = hashlib.sha256(_KERNEL_SRC.encode()).hexdigest()       # the stencil (unchanged since v1.3)
GPU_OPTIONS = ("-fmad=false", "-ftz=false", "-prec-div=true", "-prec-sqrt=true")
CPU_FLAGS = ("-O2", "-ffp-contract=off", "-shared", "-fPIC")
GPU_LOADER = "nvrtc-direct (cupy.cuda.nvrtc, no CuPy option injection), -arch=compute_<cc>, PTX checked free of .ftz"
CPU_PRELUDE = r"""
#include <cmath>
#define __global__
struct D3 { int x, y, z; };
static D3 blockIdx, blockDim, threadIdx;
"""
CPU_DRIVER = r"""
extern "C" void cpu_launch(const real* Br, const real* Bphi, const real* Bz, real* Jr, real* Jphi, real* Jz,
    const real* rf, const real* rc, real dr, real dphi, real dz, int nr, int nphi, int nz, int g,
    const real* cph, const real* sph, real sdphi, int axis)
{
  /* every thread of the GPU launch grid, in order: (8, 8, 4) blocks as in launch_current_curl */
  blockDim.x = 8; blockDim.y = 8; blockDim.z = 4;
  int bx = (nr + 7)/8, by = (nphi + 7)/8, bz = (nz + 3)/4;
  for (int a = 0; a < bx; a++) for (int b = 0; b < by; b++) for (int c = 0; c < bz; c++) {
    blockIdx.x = a; blockIdx.y = b; blockIdx.z = c;
    for (int x = 0; x < 8; x++) for (int y = 0; y < 8; y++) for (int z = 0; z < 4; z++) {
      threadIdx.x = x; threadIdx.y = y; threadIdx.z = z;
      current_curl_kernel(Br, Bphi, Bz, Jr, Jphi, Jz, rf, rc, dr, dphi, dz, nr, nphi, nz, g, cph, sph, sdphi, axis);
    }
  }
}
"""
SOURCE_SHA256 = hashlib.sha256((_KERNEL_SRC + "|" + CPU_PRELUDE + "|" + CPU_DRIVER).encode()).hexdigest()
BUILD_SHA256 = hashlib.sha256((SOURCE_SHA256 + "|" + " ".join(GPU_OPTIONS) + "|" + " ".join(CPU_FLAGS) + "|" + GPU_LOADER).encode()).hexdigest()
_kernels = {}
_cpu = {}
_CACHE = os.path.join(tempfile.gettempdir(), "uct_curl_v14_" + BUILD_SHA256[:16])


class _NvrtcModule:
    """a CUDA module compiled by NVRTC DIRECTLY with exactly our options (cupy.RawModule / RawKernel append '-ftz=true').
    The PTX is checked to contain no '.ftz' instruction before it is loaded.  (Same loader as PRIM v01 / HLLD v05.2.)"""

    def __init__(self, src, options):
        from cupy.cuda import nvrtc
        cc = cp.cuda.Device().compute_capability
        opts = [*options, f"-arch=compute_{cc}"]
        prog = nvrtc.createProgram(src, "kernel.cu", [], [])
        try:
            try:
                nvrtc.compileProgram(prog, opts)
            except Exception as x:
                raise RuntimeError(f"NVRTC compile failed: {x}\n{nvrtc.getProgramLog(prog)}")
            ptx = nvrtc.getPTX(prog)
        finally:
            nvrtc.destroyProgram(prog)
        text = ptx.decode("latin-1") if isinstance(ptx, (bytes, bytearray)) else ptx
        n_ftz = text.count(".ftz")
        if n_ftz: raise RuntimeError(f"generated PTX contains {n_ftz} '.ftz' instructions: IEEE gradual underflow not guaranteed")
        self.options, self.ptx_ftz_count, self.arch = tuple(opts), n_ftz, cc
        self.module = cp.cuda.function.Module()
        self.module.load(ptx if isinstance(ptx, (bytes, bytearray)) else ptx.encode())

    def get_function(self, name):
        return self.module.get_function(name)


def build_kernel(dtype):
    """Compile (once per dtype) the GPU kernel with the IEEE options (NVRTC direct).  Needs cupy + a GPU."""
    name = np.dtype(dtype).name
    if name not in _kernels:
        real = {"float32": "float", "float64": "double"}[name]
        _kernels[name] = _NvrtcModule(_KERNEL_SRC.replace("REAL_T", real), GPU_OPTIONS).get_function("current_curl_kernel")
    return _kernels[name]


def build_cpu(dtype):
    """Compile (once per dtype) the SAME source for the CPU with g++ (contraction off)."""
    name = np.dtype(dtype).name
    if name not in _cpu:
        real = {"float32": "float", "float64": "double"}[name]
        os.makedirs(_CACHE, exist_ok=True)
        so = os.path.join(_CACHE, f"curl_{name}.so")
        if not os.path.exists(so):
            cpp = os.path.join(_CACHE, f"curl_{name}.cpp")
            open(cpp, "w").write(CPU_PRELUDE + _KERNEL_SRC.replace("REAL_T", real) + CPU_DRIVER)
            subprocess.check_call(["g++", *CPU_FLAGS, "-o", so + ".tmp", cpp]); os.replace(so + ".tmp", so)
        lib = ctypes.CDLL(so); f = lib.cpu_launch
        ct = ctypes.c_float if name == "float32" else ctypes.c_double
        f.argtypes = [ctypes.c_void_p] * 8 + [ct] * 3 + [ctypes.c_int] * 4 + [ctypes.c_void_p] * 2 + [ct, ctypes.c_int]
        f.restype = None
        _cpu[name] = (lib, f, ct)
    return _cpu[name]


def gpu_ieee_selftest():
    """FP32 subnormal arithmetic through the same loader and options (True = IEEE)."""
    src = 'extern "C" __global__ void k(const float* a, const float* b, float* m, float* s, float* d, int n)' \
          '{ int i = blockIdx.x * blockDim.x + threadIdx.x; if (i < n) { m[i] = a[i] * b[i]; s[i] = a[i] + b[i]; d[i] = a[i] / b[i]; } }'
    mod = _NvrtcModule(src, GPU_OPTIONS)
    a = np.array([1e-20, 3e-40, 1e-44, 1e-30], np.float32); b = np.array([1e-20, 1e-40, 1.0, 1e-10], np.float32)
    A, B = cp.asarray(a), cp.asarray(b); M, S, D = (cp.empty(4, np.float32) for _ in range(3))
    mod.get_function("k")((1,), (32,), (A, B, M, S, D, np.int32(4))); cp.cuda.Device().synchronize()
    return bool(np.array_equal(M.get().view(np.uint32), (a * b).view(np.uint32)) and np.array_equal(S.get().view(np.uint32), (a + b).view(np.uint32))
                and np.array_equal(D.get().view(np.uint32), (a / b).view(np.uint32)))


def make_grid(nr, dr, g=2, dtype=np.float64):
    """Ghost-extended radial faces/centers (indexed directly by gi). Axis at r_faces[g] = 0."""
    r_faces = ((np.arange(nr + 1 + 2*g) - g) * dr).astype(dtype)
    r_centers = ((np.arange(nr + 2*g) - g + 0.5) * dr).astype(dtype)
    return r_faces, r_centers


# --------------------------------------------------------------------------- validation
def _host(a):
    return a.get() if (cp is not None and isinstance(a, cp.ndarray)) else np.asarray(a)


def _extent(a):
    """(start, end) byte addresses of an array's memory (numpy or cupy)."""
    if cp is not None and isinstance(a, cp.ndarray):
        p = int(a.data.ptr)
    else:
        p = int(a.__array_interface__["data"][0])
    return p, p + int(a.nbytes)


def validate_inputs(Br, Bphi, Bz, Jr, Jphi, Jz, r_faces, r_centers,
                    dr, dphi, dz, nr, nphi, nz, g=2, full_circle=True):
    """Raise CurlContractError on the first contract violation. Pure host check; no kernel launch."""
    E = CurlContractError
    names = ("Br", "Bphi", "Bz", "Jr", "Jphi", "Jz", "r_faces", "r_centers")
    arrs = (Br, Bphi, Bz, Jr, Jphi, Jz, r_faces, r_centers)

    for n, v in (("nr", nr), ("nphi", nphi), ("nz", nz), ("g", g)):
        if isinstance(v, bool) or not isinstance(v, (int, np.integer)):
            raise E(f"{n} must be an integer, got {type(v).__name__}")
    if g < 1:
        raise E(f"ghost width g must be >= 1 (got {g})")
    if nr < 1 or nphi < 1 or nz < 1:
        raise E(f"nr, nphi, nz must be >= 1 (got {nr},{nphi},{nz})")

    for n, v in (("dr", dr), ("dphi", dphi), ("dz", dz)):
        if not np.isfinite(v) or v <= 0:
            raise E(f"{n} must be finite and > 0 (got {v})")

    for n, a in zip(names, arrs):
        if not hasattr(a, "dtype") or not hasattr(a, "shape"):
            raise E(f"{n} is not an array")
    dt = Br.dtype
    if np.dtype(dt) not in (np.dtype(np.float32), np.dtype(np.float64)):
        raise E(f"dtype must be float32 or float64 (got {dt})")
    for n, a in zip(names, arrs):
        if a.dtype != dt:
            raise E(f"{n} dtype {a.dtype} differs from Br dtype {dt}")

    ng, pg, zg = nr + 2*g, nphi + 2*g, nz + 2*g
    want = {"Br": (ng + 1, pg, zg), "Bphi": (ng, pg + 1, zg), "Bz": (ng, pg, zg + 1),
            "Jr": (ng, pg, zg), "Jphi": (ng, pg, zg), "Jz": (ng, pg, zg),
            "r_faces": (ng + 1,), "r_centers": (ng,)}
    for n, a in zip(names, arrs):
        if tuple(a.shape) != want[n]:
            raise E(f"{n} shape {tuple(a.shape)} != required {want[n]}")
        if not a.flags.c_contiguous:
            raise E(f"{n} must be C-contiguous")

    # angular units / extent
    span = nphi*dphi
    two_pi = 2*np.pi
    if full_circle:
        if abs(span - two_pi) > 1e-9*two_pi:
            raise E(f"full_circle=True requires nphi*dphi == 2*pi (got {span!r}; dphi must be in radians)")
    elif span > two_pi*(1 + 1e-9):
        raise E(f"nphi*dphi = {span!r} exceeds 2*pi (dphi must be in radians)")

    # radial coordinates
    rf = _host(r_faces).astype(np.float64)
    rc = _host(r_centers).astype(np.float64)
    if not (np.all(np.isfinite(rf)) and np.all(np.isfinite(rc))):
        raise E("r_faces / r_centers contain non-finite values")
    tol = 64*np.finfo(np.dtype(dt)).eps*max(1.0, float(np.abs(rf).max()), float(np.abs(rc).max()))
    if np.max(np.abs(np.diff(rf) - dr)) > tol:
        raise E("r_faces is not uniformly spaced by dr")
    if np.max(np.abs(rc - 0.5*(rf[:-1] + rf[1:]))) > tol:
        raise E("r_centers is not the midpoint of r_faces")
    if not np.all(rc[g:g + nr] > 0):
        raise E("r_centers must be > 0 for every interior cell (axis cell center must be dr/2, not 0)")

    # axis mode (r_faces[g] == 0): needs g >= 2 (cubic stencils) and nr >= 3 (one-sided radial stencil)
    if rf[g] < 0.0:
        raise E(f"r_faces[g] = {rf[g]!r} < 0: the grid straddles the axis (start radius must be 0 or >= {AXIS_AMBIGUITY_FRACTION:g}*dr)")
    if 0.0 < rf[g] < AXIS_AMBIGUITY_FRACTION*dr:
        raise E(f"0 < r_faces[g] = {rf[g]!r} < {AXIS_AMBIGUITY_FRACTION:g}*dr: ambiguous start radius (pass exactly 0.0 for an axis grid, "
                f"or a genuine annulus with r_faces[g] >= {AXIS_AMBIGUITY_FRACTION:g}*dr)")
    if rf[g] == 0.0:
        if nphi < MIN_NPHI_AXIS:
            raise E(f"axis grids require nphi >= {MIN_NPHI_AXIS} (got {nphi}): the axis closure divides by sin(dphi)")
        if g < 2:
            raise E("axis grids (r_faces[g] == 0) require g >= 2")
        if nr < 3:
            raise E("axis grids (r_faces[g] == 0) require nr >= 3")

    # output ownership / aliasing: J arrays must not overlap each other or any input
    ext = {n: _extent(a) for n, a in zip(names, arrs)}
    outs = ("Jr", "Jphi", "Jz")
    for i, a in enumerate(outs):
        for b in names:
            if b == a or (b in outs and names.index(b) <= names.index(a)):
                continue
            (s1, e1), (s2, e2) = ext[a], ext[b]
            if s1 < e2 and s2 < e1:
                raise E(f"output {a} overlaps {b} in memory (aliasing is prohibited)")


def axis_inputs(r_faces, dphi, nphi, g, dtype):
    """Host-side extras for the kernel: cos/sin of phi cell centres (size nphi+2g), sin(dphi), axis flag."""
    phi_c = (np.arange(nphi + 2*g) - g + 0.5)*dphi
    rf0 = float(_host(r_faces)[g])
    return np.cos(phi_c).astype(dtype), np.sin(phi_c).astype(dtype), np.sin(dphi), int(rf0 == 0.0)


def launch_current_curl(Br, Bphi, Bz, Jr, Jphi, Jz,
                        r_faces, r_centers, dr, dphi, dz,
                        nr, nphi, nz, g=2, validate=True, full_circle=True):
    if validate:
        validate_inputs(Br, Bphi, Bz, Jr, Jphi, Jz, r_faces, r_centers,
                        dr, dphi, dz, nr, nphi, nz, g, full_circle)
    dt = Br.dtype
    k = build_kernel(dt)
    c = dt.type
    cph, sph, sdphi, axis = axis_inputs(r_faces, dphi, nphi, g, dt)
    cph, sph = cp.asarray(cph), cp.asarray(sph)
    threads = (8, 8, 4)
    blocks = ((nr + 7)//8, (nphi + 7)//8, (nz + 3)//4)
    k(blocks, threads,
      (Br, Bphi, Bz, Jr, Jphi, Jz, r_faces, r_centers,
       c(dr), c(dphi), c(dz), np.int32(nr), np.int32(nphi), np.int32(nz),
       np.int32(g), cph, sph, c(sdphi), np.int32(axis)))


# driver-slot alias (the driver registers its curl-of-B operator under this name)
launch_uct_curl = launch_current_curl


def cpu_current_curl(Br, Bphi, Bz, Jr, Jphi, Jz,
                     r_faces, r_centers, dr, dphi, dz,
                     nr, nphi, nz, g=2, validate=True, full_circle=True):
    """v1.4 CPU path: the kernel source compiled with g++, every thread of the GPU launch grid in order (NumPy arrays)."""
    if validate:
        validate_inputs(Br, Bphi, Bz, Jr, Jphi, Jz, r_faces, r_centers,
                        dr, dphi, dz, nr, nphi, nz, g, full_circle)
    dt = Br.dtype
    _, f, ct = build_cpu(dt)
    for a in (Br, Bphi, Bz, Jr, Jphi, Jz):
        if not (isinstance(a, np.ndarray) and a.flags.c_contiguous): raise CurlContractError("CPU path needs C-contiguous NumPy arrays")
    rf = np.ascontiguousarray(np.asarray(r_faces, dt)); rc = np.ascontiguousarray(np.asarray(r_centers, dt))
    cph, sph, sdphi, axis = axis_inputs(r_faces, dphi, nphi, g, dt)
    cph, sph = np.ascontiguousarray(cph), np.ascontiguousarray(sph)
    c = dt.type
    f(Br.ctypes.data, Bphi.ctypes.data, Bz.ctypes.data, Jr.ctypes.data, Jphi.ctypes.data, Jz.ctypes.data, rf.ctypes.data, rc.ctypes.data,
      ct(c(dr)), ct(c(dphi)), ct(c(dz)), nr, nphi, nz, g, cph.ctypes.data, sph.ctypes.data, ct(c(sdphi)), int(axis))


def curl_numpy_flat(Br, Bphi, Bz, Jr, Jphi, Jz,
                    r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g=2,
                    validate=True, full_circle=True):
    """Index-for-index emulation of the kernel on flat arrays (same strides and macros).
    v1.4: a TEST REFERENCE only, no longer a runtime path -- its operation order and precision differ from the C source
    in places (e.g. 1/r computed in FP64 then cast, /16 vs *(1/16)), so it is not bitwise equal to the kernel."""
    if validate:
        validate_inputs(Br, Bphi, Bz, Jr, Jphi, Jz, r_faces, r_centers,
                        dr, dphi, dz, nr, nphi, nz, g, full_circle)
    nz_g, nphi_g = nz + 2*g, nphi + 2*g
    sBr = (nphi_g*nz_g, nz_g)
    sBp = ((nphi_g + 1)*nz_g, nz_g)
    sBz = (nphi_g*(nz_g + 1), nz_g + 1)
    sr, sphi = nphi_g*nz_g, nz_g
    fBr, fBp, fBz = Br.ravel(), Bphi.ravel(), Bz.ravel()

    gi, gj, gk = np.meshgrid(np.arange(nr) + g, np.arange(nphi) + g,
                             np.arange(nz) + g, indexing="ij")

    BR = lambda a, b, c: fBr[a*sBr[0] + b*sBr[1] + c]
    BP = lambda a, b, c: fBp[a*sBp[0] + b*sBp[1] + c]
    BZ = lambda a, b, c: fBz[a*sBz[0] + b*sBz[1] + c]
    BRC = lambda a, b, c: 0.5*(BR(a, b, c) + BR(a + 1, b, c))
    BPC = lambda a, b, c: 0.5*(BP(a, b, c) + BP(a, b + 1, c))
    BZC = lambda a, b, c: 0.5*(BZ(a, b, c) + BZ(a, b, c + 1))
    BPF = lambda a, b, c: 0.5*(BPC(a - 1, b, c) + BPC(a, b, c))

    inv = (1.0/r_centers[gi]).astype(Br.dtype)
    cph, sph, sdphi, axis = axis_inputs(r_faces, dphi, nphi, g, Br.dtype)

    jr = inv*(BZC(gi, gj + 1, gk) - BZC(gi, gj - 1, gk))*(0.5/dphi) \
        - (BPC(gi, gj, gk + 1) - BPC(gi, gj, gk - 1))*(0.5/dz)
    dbz_dr = (BZC(gi + 1, gj, gk) - BZC(gi - 1, gj, gk))*(0.5/dr)
    if axis:
        ring0 = (gi == g)
        os = (-3*BZC(gi, gj, gk) + 4*BZC(gi + 1, gj, gk) - BZC(gi + 2, gj, gk))*(0.5/dr)
        dbz_dr = np.where(ring0, os, dbz_dr)
    jp = (BRC(gi, gj, gk + 1) - BRC(gi, gj, gk - 1))*(0.5/dz) - dbz_dr
    if not axis:
        jz = inv*((r_faces[gi + 1]*BPF(gi + 1, gj, gk) - r_faces[gi]*BPF(gi, gj, gk))/dr
                  - (BRC(gi, gj + 1, gk) - BRC(gi, gj - 1, gk))*(0.5/dphi))
    else:
        def radc(a, b, c_):
            af = np.minimum(a, nr + 2*g - 3)                   # np.where evaluates both branches: keep the unused one in bounds
            first = (5*BR(af, b, c_) + 15*BR(af + 1, b, c_) - 5*BR(af + 2, b, c_) + BR(af + 3, b, c_))/16
            ac = np.minimum(a, nr + 2*g - 2)
            cen = (-BR(ac - 1, b, c_) + 9*BR(ac, b, c_) + 9*BR(ac + 1, b, c_) - BR(ac + 2, b, c_))/16
            return np.where(a == g, first, cen)
        def cart(a, b, c_):
            rz, rm, rp = radc(a, b, c_), radc(a, b - 1, c_), radc(a, b + 1, c_)
            brc = rz - ((rp - 2*rz) + rm)/24                    # v1.5: phi-average -> point value of Br
            bpc = (-BP(a, b - 1, c_) + 9*BP(a, b, c_) + 9*BP(a, b + 1, c_) - BP(a, b + 2, c_))/16
            return brc*cph[b] - bpc*sph[b], brc*sph[b] + bpc*cph[b]
        fx0, fy0 = cart(gi, gj, gk)
        # one-sided / centred radial derivative (np.where keeps the unused branch finite-safe: indices stay in bounds)
        a1 = gi + 1; a2 = gi + 2; am = np.maximum(gi - 1, 0)
        fx1, fy1 = cart(a1, gj, gk); fx2, fy2 = cart(a2, gj, gk); fxm, fym = cart(am, gj, gk)
        dxr = np.where(gi == g, (-3*fx0 + 4*fx1 - fx2)*(0.5/dr), (fx1 - fxm)*(0.5/dr))
        dyr = np.where(gi == g, (-3*fy0 + 4*fy1 - fy2)*(0.5/dr), (fy1 - fym)*(0.5/dr))
        tx1, ty1 = cart(gi, gj + 1, gk); tx2, ty2 = cart(gi, gj - 1, gk)
        inv_t = 1.0/(2.0*r_centers[gi]*sdphi)
        dxt, dyt = (tx1 - tx2)*inv_t, (ty1 - ty2)*inv_t
        c0, s0 = cph[gj], sph[gj]
        jz = c0*dyr - s0*dxr - s0*dyt - c0*dxt

    c = gi*sr + gj*sphi + gk
    Jr.ravel()[c] = jr
    Jphi.ravel()[c] = jp
    Jz.ravel()[c] = jz


def run_curl(Br, Bphi, Bz, r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g=2,
             validate=True, full_circle=True, backend="auto", device_out=False):
    """Returns ((Jr, Jphi, Jz), label): curl(B), mu0 = 1.
    backend: "cpu" (the source compiled with g++), "cupy" (GPU), or "auto" (GPU if CuPy has a device, else CPU: the v1.3
    behaviour).  An explicit backend is always obeyed.  device_out=True (GPU only) returns CuPy arrays."""
    shp = (nr + 2*g, nphi + 2*g, nz + 2*g)
    if backend == "auto":
        backend = "cpu"
        if cp is not None:
            try:
                if cp.cuda.runtime.getDeviceCount() > 0: backend = "cupy"
            except Exception:
                pass
    if backend == "cupy":
        if cp is None: raise CurlContractError("backend='cupy' requested but CuPy is not available")
        a = [cp.ascontiguousarray(cp.asarray(x)) for x in (Br, Bphi, Bz)]
        rf, rc = cp.asarray(np.asarray(_host(r_faces), Br.dtype)), cp.asarray(np.asarray(_host(r_centers), Br.dtype))
        J = [cp.zeros(shp, Br.dtype) for _ in range(3)]
        launch_current_curl(a[0], a[1], a[2], *J, rf, rc, dr, dphi, dz, nr, nphi, nz, g, validate, full_circle)
        return (J if device_out else [cp.asnumpy(x) for x in J]), "GPU: NVRTC direct, IEEE options"
    if backend != "cpu": raise CurlContractError(f"unknown backend {backend!r}")
    a = [np.ascontiguousarray(_host(x)) for x in (Br, Bphi, Bz)]
    J = [np.zeros(shp, a[0].dtype) for _ in range(3)]
    cpu_current_curl(a[0], a[1], a[2], *J, _host(r_faces), _host(r_centers), dr, dphi, dz, nr, nphi, nz, g, validate, full_circle)
    return J, "CPU: kernel source compiled with g++ (-ffp-contract=off)"


def _fields(nr, nphi, nz, g, dr, dphi, dz, dtype):
    ng, pg, zg = nr + 2*g, nphi + 2*g, nz + 2*g
    return (np.zeros((ng + 1, pg, zg), dtype),
            np.zeros((ng, pg + 1, zg), dtype),
            np.zeros((ng, pg, zg + 1), dtype))


def test_zpinch(dtype=np.float64, nr=16, nphi=16, nz=8, g=2):
    dr, dz = 0.1, 0.1
    dphi = 2*np.pi/nphi
    rf, rc = make_grid(nr, dr, g, dtype)
    Br, Bphi, Bz = _fields(nr, nphi, nz, g, dr, dphi, dz, dtype)
    sl = (slice(g, g + nr), slice(g, g + nphi), slice(g, g + nz))
    out = {}

    # 1) Z-pinch: Bphi = 0.5 r  (evaluated where Bphi lives: cell radii)
    Bphi[...] = (0.5*rc)[:, None, None]
    (Jr, Jp, Jz), backend = run_curl(Br, Bphi, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g)
    out["zpinch"] = (np.abs(Jz[sl] - 1).max(), np.abs(Jr[sl]).max(), np.abs(Jp[sl]).max())
    axis = (slice(g, g + 1), slice(g, g + nphi), slice(g, g + nz))
    out["axis cell |Jz-1|"] = np.abs(Jz[axis] - 1).max()

    # 2) Bz = 0.5 r^2 -> Jphi = -r
    Bphi[...] = 0
    Bz[...] = (0.5*rc**2)[:, None, None]
    (Jr, Jp, Jz), _ = run_curl(Br, Bphi, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g)
    out["Bz=r^2/2 |Jphi+r|"] = np.abs(Jp[sl] + rc[g:g + nr][:, None, None]).max()

    # 3) Bphi = z -> Jr = -1
    Bz[...] = 0
    zc = (np.arange(nz + 2*g) - g + 0.5)*dz
    Bphi[...] = zc[None, None, :]
    (Jr, Jp, Jz), _ = run_curl(Br, Bphi, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g)
    out["Bphi=z |Jr+1|"] = np.abs(Jr[sl] + 1).max()
    return out, backend


if __name__ == "__main__":
    print(f"current_curl v{VERSION}: {MU0_CONTRACT}")
    for dt in (np.float64, np.float32):
        res, backend = test_zpinch(dt)
        ez, er, ep = res["zpinch"]
        print(f"[{np.dtype(dt).name}] backend: {backend}")
        print("  max |Jz - 1| =", float(ez))
        print("  max |Jr|     =", float(er))
        print("  max |Jphi|   =", float(ep))
        print("  axis-cell max |Jz - 1| =", float(res["axis cell |Jz-1|"]))
        print("  extra: Bz=r^2/2 max |Jphi + r| =", float(res["Bz=r^2/2 |Jphi+r|"]))
        print("  extra: Bphi=z   max |Jr + 1|   =", float(res["Bphi=z |Jr+1|"]))
