# -*- coding: utf-8 -*-
"""
ALADIN RESIDUAL v01.1 -- kernel 07 of the ALADIN native-cylindrical GPU MHD Driver: flux divergence + cylindrical geometric
sources -> dU/dt for (rho, m_r, m_phi, m_z, E) on every interior cell.

    residual(G, F_r, F_phi, F_z, rho, vr, vphi, vz, p, Br, Bphi, Bz, R_eq=None)  ->  dict(dU (5, nr, nphi, nz), flags)

Inputs
  F_r (8, nr+1, nphi, nz), F_phi (8, nr, nphi+1, nz), F_z (8, nr, nphi, nz+1): face fluxes in global order
      (rho, m_r, m_phi, m_z, E, B_r, B_phi, B_z), exactly as returned by HLLD v05.1 (interior faces).  Components 5-7 (induction)
      are NOT used: B is advanced by constrained transport (UCT-EMF / UCT-ASSEMBLY).
  rho, vr, vphi, vz, p: ghost-extended cell primitives (PRIM v01 output); Br, Bphi, Bz: ghost-extended CT faces.
  R_eq (optional, 5 x interior): the residual of a supplied equilibrium, computed by this same function; it is subtracted
      in-kernel (well-balanced mode: a state equal to the equilibrium gives dU = 0 exactly).

Discretisation (finite volume, exact cell volume V = 1/2 (r+^2 - r-^2) dphi dz, r_c = (r+ + r-)/2, so r_c dr = 1/2 (r+^2 - r-^2)):
  q = rho, m_r, m_z, E :  dU/dt = -[(r+ F+ - r- F-) / (r_c dr) + (Fphi+ - Fphi-) / (r_c dphi) + (Fz+ - Fz-) / dz] + S_q
  q = m_phi (angular-momentum form): with rbar = (2/3)(r+^3 - r-^3)/(r+^2 - r-^2), the volume-mean radius of the cell,
                          dU/dt = -[(r+^2 F+ - r-^2 F-) / (rbar r_c dr) + (Fphi+ - Fphi-) / (rbar dphi) + (Fz+ - Fz-) / dz]
      The discrete angular momentum  L = sum_cells V rbar m_phi  then changes only by the boundary torque, to round-off
      (the radial term telescopes with the weight V rbar; the phi and z terms telescope for any per-radius weight).
      rbar, not r_c, in the radial term: it makes the term exact for the regular axis behaviour Pi_r_phi ~ r (with r_c the
      axis cell would carry an O(1) truncation error).
      v01.1 (2026-11-23): the phi term ALSO uses rbar.  It is what the cell integral of the angular-momentum equation gives
      (the phi-face flux of r m_phi over a face of radial extent dr, per V rbar), and it keeps the radial and the phi term at
      the same radius.  A field that crosses the axis (Cartesian-smooth, m != 0) has Pi_r_phi = O(1) at r -> 0, not ~ r: the
      radial and phi terms then each carry a 1/r part that cancels in the exact equation; v01 evaluated them at rbar and r_c,
      which left a truncation error ~ 1/dr in the cells touching the axis (found by MMS-01, 2026-11-23: m_phi residual 0.54,
      1.1, 2.2, 4.4 at nr = 8 ... 64; with v01.1 0.15, 0.12, 0.11, 0.10).  rbar = r_c + dr^2 / (12 r_c): second order in the
      bulk.  Unchanged: every field with Fphi+ = Fphi- (axisymmetric: the README Z-pinch, m = 0) is bit-identical to v01, and
      the phi term still telescopes, so L = sum V rbar m_phi changes only by the boundary torque, to round-off.
  sources (cell-centred, B_c = average of the two CT faces as in HLLD v05.1 / PRIM v01):
      S_m_r = (rho vphi^2 + P_T - B_phi,c^2) / r_c,     P_T = p + |B_c|^2 / 2
      S_rho = S_m_z = S_E = 0;  the m_phi source -(rho v_r v_phi - B_r B_phi)/r is carried exactly by the angular-momentum form.
  On an axis grid r- = 0 on the first cell: its radial face carries no flux (r- F- = 0).
  Geometry factors (1/A, 1/r_c, 1/rbar, 1/(rbar A), 1/dphi, 1/dz) are computed on the host in double and rounded once, so
  FP32 runs do not lose digits to r/dr cancellation; the kernel multiplies by them.

Per-cell flags: 1 REFUSED -- any input of the cell (its 6 face fluxes of the 5 used components, its primitives, its 6 CT
faces, R_eq if given) is not finite, or rho <= 0 or p < 0  -> all five dU are NaN (never repaired; HLLD flag-32 and PRIM
flag-1/2/8 cells propagate as refusals).
Build: one CUDA/C++ source; NVRTC called directly with -fmad=false -ftz=false -prec-div=true -prec-sqrt=true (cupy.RawModule
appends -ftz=true, PRIM-01 finding); g++ -O2 -ffp-contract=off.  GPU and CPU bit-identical.
"""
import os, ctypes, hashlib, subprocess, tempfile, numpy as np

VERSION = "residual v01.1 2026-11-23"

SRC = r"""
#ifdef RES_GPU
#define DEV __device__ __forceinline__
#define KERNEL extern "C" __global__
#define TID (blockIdx.x * blockDim.x + threadIdx.x)
#else
#define DEV static inline
#define KERNEL extern "C"
#endif
typedef REAL R;
DEV int fin(R x) { R y = x - x; return y == y; }
DEV R qnan() { R z = R(0); return z / z; }

DEV void res_one(long long t, int nr, int np_, int nz, int g,
                 const R* Fr, const R* Fp, const R* Fz,
                 const R* rho, const R* vr, const R* vp, const R* vz, const R* p,
                 const R* Br, const R* Bp, const R* Bz, const R* geo, R idphi, R idz,
                 const R* Req, int use_eq, R* dU, int* flags)
{
    int k = (int)(t % nz); long long q = t / nz; int j = (int)(q % np_); int i = (int)(q / np_);
    long long NI = (long long)nr * np_ * nz;                                   // interior cells
    int NR = nr + 2 * g, NP = np_ + 2 * g, NZ = nz + 2 * g;
    long long c = ((long long)(i + g) * NP + (j + g)) * NZ + (k + g);         // ghost-extended cell index
    long long sFr = (long long)(nr + 1) * np_ * nz, sFp = (long long)nr * (np_ + 1) * nz, sFz = (long long)nr * np_ * (nz + 1);
    long long fr0 = ((long long)i * np_ + j) * nz + k, fr1 = fr0 + (long long)np_ * nz;
    long long fp0 = ((long long)i * (np_ + 1) + j) * nz + k, fp1 = fp0 + nz;
    long long fz0 = ((long long)i * np_ + j) * (nz + 1) + k, fz1 = fz0 + 1;
    long long br0 = ((long long)(i + g) * NP + (j + g)) * NZ + (k + g), br1 = br0 + (long long)NP * NZ;   // Br (NR+1, NP, NZ)
    long long bp0 = ((long long)(i + g) * (NP + 1) + (j + g)) * NZ + (k + g), bp1 = bp0 + NZ;          // Bphi (NR, NP+1, NZ)
    long long bz0 = ((long long)(i + g) * NP + (j + g)) * (NZ + 1) + (k + g), bz1 = bz0 + 1;           // Bz (NR, NP, NZ+1)
    // geometry, precomputed on the host in double and rounded once (no r/dr cancellation in the working precision):
    //   rm, rp, 1/A (A = (r+^2 - r-^2)/2 = r_c dr), 1/r_c, 1/rbar, 1/(rbar A); rbar = volume-mean radius = (2/3)(r+^3 - r-^3)/(r+^2 - r-^2)
    R rm = geo[0 * nr + i], rp = geo[1 * nr + i], iA = geo[2 * nr + i], irc = geo[3 * nr + i], irbA = geo[5 * nr + i], irb = geo[4 * nr + i];
    R d = rho[c], ur = vr[c], up = vp[c], uz = vz[c], pp = p[c];
    R b0 = Br[br0], b1 = Br[br1], b2 = Bp[bp0], b3 = Bp[bp1], b4 = Bz[bz0], b5 = Bz[bz1];
    int ok = fin(d) && fin(ur) && fin(up) && fin(uz) && fin(pp) && fin(b0) && fin(b1) && fin(b2) && fin(b3) && fin(b4) && fin(b5)
             && (d > R(0)) && (pp >= R(0));
    R F[5][6];
    for (int m = 0; m < 5; ++m) {
        F[m][0] = Fr[m * sFr + fr0]; F[m][1] = Fr[m * sFr + fr1];
        F[m][2] = Fp[m * sFp + fp0]; F[m][3] = Fp[m * sFp + fp1];
        F[m][4] = Fz[m * sFz + fz0]; F[m][5] = Fz[m * sFz + fz1];
        for (int s = 0; s < 6; ++s) ok = ok && fin(F[m][s]);
        if (use_eq) ok = ok && fin(Req[m * NI + t]);
    }
    if (!ok) { for (int m = 0; m < 5; ++m) dU[m * NI + t] = qnan(); flags[t] = 1; return; }
    R bcr = R(0.5) * (b0 + b1), bcp = R(0.5) * (b2 + b3), bcz = R(0.5) * (b4 + b5);
    R PT = pp + R(0.5) * (((bcr * bcr) + (bcp * bcp)) + (bcz * bcz));
    R Smr = (((d * up) * up + PT) - bcp * bcp) * irc;
    for (int m = 0; m < 5; ++m) {
        R divr;
        if (m == 2) divr = ((rp * rp) * F[m][1] - (rm * rm) * F[m][0]) * irbA;     // angular-momentum form (radial term)
        else        divr = (rp * F[m][1] - rm * F[m][0]) * iA;
        R divp = ((F[m][3] - F[m][2]) * (m == 2 ? irb : irc)) * idphi;     // v01.1: m_phi phi term at rbar (angular-momentum form)
        R divz = (F[m][5] - F[m][4]) * idz;
        R r = -((divr + divp) + divz);
        if (m == 1) r = r + Smr;
        if (use_eq) r = r - Req[m * NI + t];
        dU[m * NI + t] = r;
    }
    flags[t] = 0;
}

#ifdef RES_GPU
KERNEL void res_kernel(const R* Fr, const R* Fp, const R* Fz, const R* rho, const R* vr, const R* vp, const R* vz, const R* p,
                       const R* Br, const R* Bp, const R* Bz, const R* geo, const R* Req, R* dU, int* flags,
                       int nr, int np_, int nz, int g, R idphi, R idz, int use_eq, long long ntot)
{ long long t = TID; if (t < ntot) res_one(t, nr, np_, nz, g, Fr, Fp, Fz, rho, vr, vp, vz, p, Br, Bp, Bz, geo, idphi, idz, Req, use_eq, dU, flags); }
#else
KERNEL void res_cpu(const R* Fr, const R* Fp, const R* Fz, const R* rho, const R* vr, const R* vp, const R* vz, const R* p,
                    const R* Br, const R* Bp, const R* Bz, const R* geo, const R* Req, R* dU, int* flags,
                    int nr, int np_, int nz, int g, R idphi, R idz, int use_eq, long long ntot)
{
    #pragma omp parallel for schedule(static)
    for (long long t = 0; t < ntot; ++t) res_one(t, nr, np_, nz, g, Fr, Fp, Fz, rho, vr, vp, vz, p, Br, Bp, Bz, geo, idphi, idz, Req, use_eq, dU, flags);
}
#endif
"""

SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()
GPU_OPTIONS = ("-DRES_GPU", "-std=c++14", "-fmad=false", "-ftz=false", "-prec-div=true", "-prec-sqrt=true")
CPU_FLAGS = ("-O2", "-ffp-contract=off", "-shared", "-fPIC")
GPU_LOADER = "nvrtc-direct (cupy.cuda.nvrtc, no CuPy option injection), -arch=compute_<cc>, PTX checked free of .ftz"
BUILD_SHA256 = hashlib.sha256((SRC + "|" + " ".join(GPU_OPTIONS) + "|" + " ".join(CPU_FLAGS) + "|" + GPU_LOADER).encode()).hexdigest()
_cache = {}


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


def _cpu_lib(dtype):
    real = "double" if dtype == np.float64 else "float"
    if ("cpu", real) in _cache: return _cache[("cpu", real)]
    d = os.path.join(tempfile.gettempdir(), "res_v01_" + hashlib.sha256((BUILD_SHA256 + real).encode()).hexdigest()[:16])
    os.makedirs(d, exist_ok=True); so = os.path.join(d, "res1.so")
    if not os.path.exists(so):
        open(os.path.join(d, "res.cpp"), "w").write(SRC)
        cmd = ["g++", *CPU_FLAGS, "-fopenmp", f"-DREAL={real}", "-o", so, os.path.join(d, "res.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError(r.stderr)
    lib = ctypes.CDLL(so); _cache[("cpu", real)] = lib; return lib


class _NvrtcModule:
    """CUDA module compiled by NVRTC DIRECTLY with exactly our options (cupy.RawModule appends -ftz=true; PRIM-01 finding).
    The PTX is checked to contain no '.ftz' instruction before it is loaded."""

    def __init__(self, src, options):
        import cupy as cp
        from cupy.cuda import nvrtc
        cc = cp.cuda.Device().compute_capability
        opts = [*options, f"-arch=compute_{cc}"]
        prog = nvrtc.createProgram(src, "kernel.cu", [], [])
        try:
            try:
                nvrtc.compileProgram(prog, opts)
            except Exception as x:
                raise RuntimeError(f"NVRTC compile failed: {x}\n{nvrtc.getProgramLog(prog)}")
            ptx = nvrtc.getPTX(prog)
        finally:
            nvrtc.destroyProgram(prog)
        text = ptx.decode("latin-1") if isinstance(ptx, (bytes, bytearray)) else ptx
        n_ftz = text.count(".ftz")
        if n_ftz: raise RuntimeError(f"generated PTX contains {n_ftz} '.ftz' instructions: IEEE gradual underflow not guaranteed")
        self.options, self.ptx_ftz_count, self.arch = tuple(opts), n_ftz, cc
        self.module = cp.cuda.function.Module()
        self.module.load(ptx if isinstance(ptx, (bytes, bytearray)) else ptx.encode())

    def get_function(self, name):
        return self.module.get_function(name)


def gpu_ieee_selftest():
    """FP32 subnormal *, +, / through the SAME compile path, bit for bit against IEEE (numpy)"""
    import cupy as cp
    src = 'extern "C" __global__ void k(const float* a, const float* b, float* m, float* s, float* d, int n)' \
          '{ int i = blockIdx.x * blockDim.x + threadIdx.x; if (i < n) { m[i] = a[i] * b[i]; s[i] = a[i] + b[i]; d[i] = a[i] / b[i]; } }'
    mod = _NvrtcModule(src, tuple(o for o in GPU_OPTIONS if not o.startswith("-D")))
    a = np.array([1e-20, 3e-40, 1e-44, 1e-30], np.float32); b = np.array([1e-20, 1e-40, 1.0, 1e-10], np.float32)
    A, B = cp.asarray(a), cp.asarray(b); M, S, D = (cp.empty(4, np.float32) for _ in range(3))
    mod.get_function("k")((1,), (32,), (A, B, M, S, D, np.int32(4))); cp.cuda.Device().synchronize()
    return bool(np.array_equal(M.get().view(np.uint32), (a * b).view(np.uint32)) and np.array_equal(S.get().view(np.uint32), (a + b).view(np.uint32))
                and np.array_equal(D.get().view(np.uint32), (a / b).view(np.uint32)))


def _gpu_mod(dtype):
    real = "double" if dtype == np.float64 else "float"
    if ("gpu", real) not in _cache:
        _cache[("gpu", real)] = _NvrtcModule(SRC, (*GPU_OPTIONS, f"-DREAL={real}"))
    return _cache[("gpu", real)]


class Grid:
    """Identical to uct_emf_v02.Grid / hlld_v05.Grid / prim_v01.Grid (ghost-extended radii; axis grid iff r_faces[g] == 0)."""

    def __init__(self, nr, nphi, nz, rmin, rmax, zlen=1.0, g=2, dtype=np.float64, xp=np):
        self.nr, self.nphi, self.nz, self.g, self.dtype, self.xp = nr, nphi, nz, g, dtype, xp
        self.dr = (rmax - rmin) / nr; self.dphi = 2 * np.pi / nphi; self.dz = zlen / nz; self.rmin = rmin
        rf = rmin + (np.arange(nr + 1 + 2 * g) - g) * self.dr
        if rmin == 0: rf[g] = 0.0
        self.r_faces = rf; self.r_centers = 0.5 * (rf[:-1] + rf[1:])
        self.phi_c = (np.arange(nphi + 2 * g) - g + 0.5) * self.dphi; self.phi_f = (np.arange(nphi + 1 + 2 * g) - g) * self.dphi
        self.z_c = (np.arange(nz + 2 * g) - g + 0.5) * self.dz; self.z_f = (np.arange(nz + 1 + 2 * g) - g) * self.dz
        self.axis = rmin == 0

    def shape(self, kind):
        n, p, z, g = self.nr, self.nphi, self.nz, self.g
        return dict(cell=(n + 2 * g, p + 2 * g, z + 2 * g), Br=(n + 1 + 2 * g, p + 2 * g, z + 2 * g), Bphi=(n + 2 * g, p + 1 + 2 * g, z + 2 * g),
                    Bz=(n + 2 * g, p + 2 * g, z + 1 + 2 * g), F_r=(8, n + 1, p, z), F_phi=(8, n, p + 1, z), F_z=(8, n, p, z + 1),
                    dU=(5, n, p, z), interior=(n, p, z))[kind]


def residual(G, F_r, F_phi, F_z, rho, vr, vphi, vz, p, Br, Bphi, Bz, R_eq=None, backend="cpu"):
    """dU/dt for (rho, m_r, m_phi, m_z, E) on every interior cell.  Returns dict(dU (5, nr, nphi, nz), flags (nr, nphi, nz))."""
    kinds = ("F_r", "F_phi", "F_z") + ("cell",) * 5 + ("Br", "Bphi", "Bz")
    for a, kd in zip((F_r, F_phi, F_z, rho, vr, vphi, vz, p, Br, Bphi, Bz), kinds):
        if tuple(a.shape) != tuple(G.shape(kd)): raise ValueError(f"array of shape {a.shape} does not match {kd} {G.shape(kd)}")
    if R_eq is not None and tuple(R_eq.shape) != tuple(G.shape("dU")): raise ValueError(f"R_eq shape {R_eq.shape} != {G.shape('dU')}")
    xp = G.xp; dt = G.dtype; sc = np.float64 if dt == np.float64 else np.float32
    ins = [xp.ascontiguousarray(a.astype(dt)) for a in (F_r, F_phi, F_z, rho, vr, vphi, vz, p, Br, Bphi, Bz)]
    rf = np.asarray(G.r_faces, np.float64)[G.g:G.g + G.nr + 1]; rm, rp = rf[:-1], rf[1:]
    A = 0.5 * (rp + rm) * (rp - rm); rc = 0.5 * (rp + rm); rb = (2.0 / 3.0) * (rp * rp + rp * rm + rm * rm) / (rp + rm)
    geo = xp.ascontiguousarray(xp.asarray(np.stack([rm, rp, 1 / A, 1 / rc, 1 / rb, 1 / (rb * A)]).astype(dt)))
    use_eq = R_eq is not None
    Req = xp.ascontiguousarray(R_eq.astype(dt)) if use_eq else xp.zeros(1, dtype=dt)
    dU = xp.empty(G.shape("dU"), dtype=dt); fl = xp.empty(G.shape("interior"), dtype=np.int32)
    ntot = G.nr * G.nphi * G.nz
    if backend == "cupy":
        k = _gpu_mod(dt).get_function("res_kernel")
        k(((ntot + 127) // 128,), (128,), (*ins, geo, Req, dU, fl, np.int32(G.nr), np.int32(G.nphi), np.int32(G.nz), np.int32(G.g),
                                          sc(1 / G.dphi), sc(1 / G.dz), np.int32(use_eq), np.int64(ntot)))
    else:
        lib = _cpu_lib(dt); f = lib.res_cpu; cr = ctypes.c_double if dt == np.float64 else ctypes.c_float
        args = [a.ctypes.data_as(ctypes.c_void_p) for a in ins + [geo, Req, dU, fl]]
        f.restype = None
        f(*args, ctypes.c_int(G.nr), ctypes.c_int(G.nphi), ctypes.c_int(G.nz), ctypes.c_int(G.g), cr(float(sc(1 / G.dphi))), cr(float(sc(1 / G.dz))),
          ctypes.c_int(int(use_eq)), ctypes.c_longlong(ntot))
    return dict(dU=dU, flags=fl)
