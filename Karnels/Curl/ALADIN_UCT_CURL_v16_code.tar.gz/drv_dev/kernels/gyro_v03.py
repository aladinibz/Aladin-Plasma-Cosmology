# -*- coding: utf-8 -*-
"""
ALADIN gyro kernel v03 — gyrotropic 12-feature maximum-entropy closure: admissible, consistent and UNIQUE by construction

Successor of v2.1 (frozen) and v02 (development).  The author's design is kept exactly:
  * the 12 features  phi = [1, x, s, x^2, x/(1+x^2), x s/(1+s), s^2, x^2 s, x^4, x^3/(1+x^2)^2, s^3/(1+s), x^2 s^2/(1+s)]
  * the two tail ties lambda_6 = lambda_10, lambda_7 = lambda_11  ->  9 free multipliers, 9 enforced moment combinations
  * the integrability cone: quartic tail form negative definite with cross-term margin |s| <= 0.95
What v03 changes:
  * drift frame: x = (v_par - u_par) / sqrt(T_par/m),  s = v_perp^2 / (T_perp/m)       (Galilean and scale-free)
  * the closure is the information projection (minimum KL divergence) of the true distribution onto the family:
        min_theta  log Z(theta) - theta . m  +  mu * barrier_cone(theta),     m = 9 sufficient statistics of the target
    strictly convex -> one solution; solved by Newton on an interior-point path mu = 1e-3 ... 1e-10 (FP32: ... 1e-6) (each stage warm-starts
    the next), so optima on the cone boundary are reached, not approached forever.

Guarantees by construction:
  ABC-1  f > 0                                 exponential family on positive lattice weights
  ABC-2  integrable continuum closure          theta stays strictly inside the cone (barrier)
  ABC-3  realizable outputs                    moments of one positive measure; Hankel margin `adm` >= 0 reported
  ABC-4  consistent                            n, u_par, P_par, P_perp returned = inputs (the frame is built from them)
  ABC-5  resolved                              Gauss-Hermite x Gauss-Laguerre lattice in the drift frame: every cell
                                               is seen at its own thermal scale
  ABC-6  well-balanced                         bi-Maxwellian shape moments -> theta = 0 (up to the barrier), q = 0 by symmetry
  ABC-7  unique                                strictly convex problem: same input -> same output, any start, any hardware
                                               (to the precision of the build)

Inputs  (per cell):  n, u_par, P_par, P_perp  (physical units)  and  S[12] = < phi(x, s) >  (drift-frame shape moments;
                     S0..S3 are fixed by the frame to 1, 0, 2, 1 and are not read)
Outputs (per cell):  n, u_par, P_par, P_perp (unchanged), q_par, q_perp, status, iterations, resid, adm, cone,
                     theta[9] (warm start), M_recon[12] = <phi>, M_flux[12] = <x phi>  (parallel flux moments, for the Driver)
status: 0 converged, target inside the family (resid < res_tol) | 4 converged, target outside the family (q delivered,
        resid reported) | 3 target outside the lattice's moment space (frame not reproduced or multipliers diverge;
        exact bi-Maxwellian, q = 0) | 1 not converged in max_newton (same) | 2 linear solve failure (same)
        | 5 invalid input (floors, adm = -1) | 6 moment failure (bi-Maxwellian, q = 0)
"""
import os, math, hashlib, ctypes, subprocess, tempfile
import numpy as np

VERSION = "gyro_v03 2026-11-20 (r3: default-start retry after a non-converging given start)"
N_FEAT, N_SUF = 12, 9
NP, NQ = int(os.environ.get("GYRO_NPAR", 24)), int(os.environ.get("GYRO_NPER", 16))   # certified lattice: 24 x 16

SRC = r"""
#ifdef GYRO_GPU
  #define DEV __device__ __forceinline__
#else
  #include <cmath>
  using namespace std;
  #define DEV static inline
#endif
typedef REAL R;
#define N_FEAT 12
#define NS 9
#ifndef NPAR
#define NPAR 24
#endif
#ifndef NPER
#define NPER 16
#endif
#define S2MAX R(0.9025)
#define I_C4 6
#define I_Q 7
#define I_X 8
// precision-aware interior-point path: FP64 runs the barrier down to 1e-10, FP32 to 1e-6 (below that FP32 cannot resolve it)
#ifndef MU_STAGES
#define MU_STAGES (sizeof(R) == 8 ? 10 : 6)
#endif
#ifndef MU_FIRST
#define MU_FIRST 3
#endif
#ifndef TOL_FIN
#define TOL_FIN (sizeof(R) == 8 ? R(1e-14) : R(1e-8))
#endif
#ifndef TOL_MID
#define TOL_MID (sizeof(R) == 8 ? R(1e-10) : R(1e-6))
#endif
#define RIDGE (sizeof(R) == 8 ? R(1e-13) : R(1e-6))
#define THETA_MAX R(1e4)
#ifndef FRAME_TOL
#define FRAME_TOL R(1e-3)   /* one physical rule for both precisions: frame reproduced to 0.1 % of a standard deviation */
#endif
#define EPS_R (sizeof(R) == 8 ? R(2.220446049250313e-16) : R(1.1920929e-07))

// the 9 sufficient statistics psi = A^T phi (ties folded in), STANDARDISED by their reference-Maxwellian mean and spread
// (a linear change of variables: same convex problem, same solution; keeps every accumulation O(1) for FP32)
DEV void eval_psi_raw(R x, R s, R* p) {
    R x2 = x*x, idp = R(1)/(R(1)+x2), ide = R(1)/(R(1)+s);
    p[0] = x; p[1] = s; p[2] = x2; p[3] = x*idp; p[4] = x*s*ide; p[5] = x2*x*idp*idp;
    p[6] = x2*x2; p[7] = s*s + s*s*s*ide; p[8] = x2*s + x2*s*s*ide;
}
DEV R psi_mu(int k)  { const R v[NS] = PSI_MU;  return v[k]; }
DEV R psi_isd(int k) { const R v[NS] = PSI_ISD; return v[k]; }
DEV void eval_psi(R x, R s, R* p) {
    eval_psi_raw(x, s, p);
    for (int k = 0; k < NS; ++k) p[k] = (p[k] - psi_mu(k))*psi_isd(k);
}
DEV void eval_phi(R x, R s, R* p) {
    R x2 = x*x, idp = R(1)/(R(1)+x2), ide = R(1)/(R(1)+s);
    p[0]=R(1); p[1]=x; p[2]=s; p[3]=x2; p[4]=x*idp; p[5]=x*s*ide; p[6]=s*s; p[7]=x2*s; p[8]=x2*x2;
    p[9]=x2*x*idp*idp; p[10]=s*s*s*ide; p[11]=x2*s*s*ide;
}

// cone barrier: a = -th_c4 > 0, b = -2 th_q > 0, g = S2MAX a b - th_x^2 > 0
DEV bool cone(const R* th, R* a, R* b, R* g) {
    R xx = th[I_X]*psi_isd(I_X);
    *a = -th[I_C4]*psi_isd(I_C4); *b = R(-2)*th[I_Q]*psi_isd(I_Q); *g = S2MAX*(*a)*(*b) - xx*xx;
    return *a > R(0) && *b > R(0) && *g > R(0);
}

// F(theta) = log sum w exp(theta.psi) - theta.m + mu * barrier
DEV R objective(const R* th, const R* m, R mu, const R* xn, const R* xw, const R* sn, const R* sw) {
    R a, b, g;
    if (!cone(th, &a, &b, &g)) return R(1e30);
    R p[NS], mx = R(-1e30);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_psi(xn[i], sn[j], p); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*p[k]; mx = fmax(mx, e);
    }
    R Z = R(0);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_psi(xn[i], sn[j], p); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*p[k]; Z += xw[i]*sw[j]*exp(e - mx);
    }
    R F = mx + log(Z);
    for (int k = 0; k < NS; ++k) F -= th[k]*m[k];
    return F - mu*(log(a) + log(b) + log(g));
}

// expectation and centred covariance of psi under the current theta (two passes)
DEV bool stats(const R* th, const R* xn, const R* xw, const R* sn, const R* sw, R* E, R* C) {
    R p[NS], mx = R(-1e30);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_psi(xn[i], sn[j], p); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*p[k]; mx = fmax(mx, e);
    }
    R Z = R(0);
    for (int k = 0; k < NS; ++k) E[k] = R(0);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_psi(xn[i], sn[j], p); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*p[k];
        R w = xw[i]*sw[j]*exp(e - mx); Z += w; for (int k = 0; k < NS; ++k) E[k] += w*p[k];
    }
    if (!(Z > R(0)) || !isfinite(Z)) return false;
    for (int k = 0; k < NS; ++k) E[k] /= Z;
    for (int k = 0; k < NS*NS; ++k) C[k] = R(0);
    for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
        eval_psi(xn[i], sn[j], p); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*p[k];
        R w = xw[i]*sw[j]*exp(e - mx)/Z;
        for (int k = 0; k < NS; ++k) p[k] -= E[k];
        for (int a = 0; a < NS; ++a) for (int b = 0; b <= a; ++b) C[a*NS+b] += w*p[a]*p[b];
    }
    for (int a = 0; a < NS; ++a) for (int b = 0; b < a; ++b) C[b*NS+a] = C[a*NS+b];
    return true;
}

DEV bool chol_solve(R* H, const R* g, R* dx) {
    R L[NS*NS], y[NS];
    for (int i = 0; i < NS*NS; ++i) L[i] = R(0);
    for (int i = 0; i < NS; ++i) for (int j = 0; j <= i; ++j) {
        R s = H[i*NS+j]; for (int k = 0; k < j; ++k) s -= L[i*NS+k]*L[j*NS+k];
        if (i == j) { if (!(s > R(0))) return false; L[i*NS+i] = sqrt(s); } else L[i*NS+j] = s/L[j*NS+j];
    }
    for (int i = 0; i < NS; ++i) { R s = g[i]; for (int k = 0; k < i; ++k) s -= L[i*NS+k]*y[k]; y[i] = s/L[i*NS+i]; }
    for (int i = NS-1; i >= 0; --i) { R s = y[i]; for (int k = i+1; k < NS; ++k) s -= L[k*NS+i]*dx[k]; dx[i] = s/L[i*NS+i]; }
    return true;
}

// one damped-Newton stage at fixed mu; returns iterations used, or -1 on solve failure
DEV int newton_stage(R* th, const R* m, R mu, R tol, int maxit, const R* xn, const R* xw, const R* sn, const R* sw,
                     R* E, R* C, R* dec_out, bool* ok_out) {
    *ok_out = false;
    for (int it = 0; it < maxit; ++it) {
        if (!stats(th, xn, xw, sn, sw, E, C)) return -1;
        R a, b, g; cone(th, &a, &b, &g);
        R gr[NS], H[NS*NS], dg[NS], dx[NS];
        for (int k = 0; k < NS; ++k) { gr[k] = E[k] - m[k]; dg[k] = R(0); }
        for (int k = 0; k < NS*NS; ++k) H[k] = C[k];
        R bg[NS], bH[NS*NS];
        for (int k = 0; k < NS; ++k) bg[k] = R(0);
        for (int k = 0; k < NS*NS; ++k) bH[k] = R(0);
        dg[I_C4] = -S2MAX*b; dg[I_Q] = R(-2)*S2MAX*a; dg[I_X] = R(-2)*th[I_X]*psi_isd(I_X);
        bg[I_C4] += R(1)/a; bg[I_Q] += R(2)/b;
        for (int k = 0; k < NS; ++k) bg[k] -= dg[k]/g;
        bH[I_C4*NS+I_C4] += R(1)/(a*a); bH[I_Q*NS+I_Q] += R(4)/(b*b);
        for (int i = 0; i < NS; ++i) for (int j = 0; j < NS; ++j) bH[i*NS+j] += dg[i]*dg[j]/(g*g);
        bH[I_C4*NS+I_Q] -= R(2)*S2MAX/g; bH[I_Q*NS+I_C4] -= R(2)*S2MAX/g; bH[I_X*NS+I_X] += R(2)/g;
        for (int i = 0; i < NS; ++i) {
            gr[i] += mu*bg[i]*psi_isd(i);
            for (int j = 0; j < NS; ++j) H[i*NS+j] += mu*bH[i*NS+j]*psi_isd(i)*psi_isd(j);
        }
        // Jacobi scaling: the statistics span ~7 orders of magnitude; solve (D H D) y = D g, dx = D y
        R D[NS], gs[NS];
        for (int k = 0; k < NS; ++k) D[k] = R(1)/sqrt(fmax(H[k*NS+k], R(1e-30)));
        for (int i = 0; i < NS; ++i) { gs[i] = D[i]*gr[i]; for (int j = 0; j < NS; ++j) H[i*NS+j] *= D[i]*D[j]; }
        for (int k = 0; k < NS; ++k) H[k*NS+k] += RIDGE;
        if (!chol_solve(H, gs, dx)) return -1;
        for (int k = 0; k < NS; ++k) dx[k] *= D[k];
        R dec = R(0); for (int k = 0; k < NS; ++k) dec += gr[k]*dx[k];
        *dec_out = dec;
        if (dec < tol) { *ok_out = true; return it; }
        R F0 = objective(th, m, mu, xn, xw, sn, sw), al = R(1), t2[NS];
        bool moved = false;
        for (int ls = 0; ls < 40; ++ls) {
            for (int k = 0; k < NS; ++k) t2[k] = th[k] - al*dx[k];
            R F1 = objective(t2, m, mu, xn, xw, sn, sw);
            if (F1 <= F0 - R(0.3)*al*dec) { moved = true; break; }
            al *= R(0.5);
        }
        if (!moved) { *ok_out = true; return it; }   // no representable decrease: converged to the build's precision
        R F1 = objective(t2, m, mu, xn, xw, sn, sw);
        for (int k = 0; k < NS; ++k) th[k] = t2[k];
        { R tm = R(0); for (int k = 0; k < NS; ++k) tm = fmax(tm, fabs(th[k])); if (!(tm < THETA_MAX)) return -2; }   // escaping to infinity
        // progress below the build's resolution of F: converged to the build's precision (FP32 cannot do better)
        if (F0 - F1 <= R(8)*EPS_R*(R(1) + fabs(F0))) { *ok_out = true; return it; }
    }
    return maxit;
}

DEV void gyro_cell(int idx, const R* n_in, const R* u_in, const R* pp_in, const R* pe_in, const R* S_all, R* th_io,
                   R* q_par, R* q_per, R* resid_out, R* adm_out, R* cone_out, R* Mrec, R* Mflux, int* status, int* iters,
                   const R* xn, const R* xw, const R* sn, const R* sw, const R* delta,
                   R mass, R res_tol, int max_newton, int warm)
{
    R n = n_in[idx], u = u_in[idx], Pp = pp_in[idx], Pe = pe_in[idx], S[N_FEAT];
    bool fin = isfinite(n) && isfinite(u) && isfinite(Pp) && isfinite(Pe) && isfinite(mass);
    for (int k = 0; k < N_FEAT; ++k) { S[k] = S_all[idx*N_FEAT+k]; fin = fin && isfinite(S[k]); }
    int flag = (!fin || !(n > R(0)) || !(Pp > R(0)) || !(Pe > R(0)) || !(mass > R(0))) ? 5 : 0;
    // ABC-4: the frame fixes the low shape moments
    S[0] = R(1); S[1] = R(0); S[2] = R(2); S[3] = R(1);
    // ABC-6: remove the lattice's own (constant) error on the reference bi-Maxwellian, then fold the ties
    R Mt[N_FEAT];
    for (int k = 0; k < N_FEAT; ++k) Mt[k] = S[k] - delta[k];
    R m[NS] = { Mt[1], Mt[2], Mt[3], Mt[4], Mt[5], Mt[9], Mt[8], Mt[6] + Mt[10], Mt[7] + Mt[11] };
    for (int k = 0; k < NS; ++k) m[k] = (m[k] - psi_mu(k))*psi_isd(k);

    R th[NS];
    for (int k = 0; k < NS; ++k) th[k] = R(0);
    th[I_C4] = R(-1e-2)/psi_isd(I_C4); th[I_Q] = R(-0.5e-2)/psi_isd(I_Q);
    int first_stage = MU_FIRST;
    if (warm && flag == 0) {
        R t0[NS], a, b, g; bool ok = true;
        for (int k = 0; k < NS; ++k) { t0[k] = th_io[idx*NS+k]/psi_isd(k); ok = ok && isfinite(t0[k]); }
        if (ok && cone(t0, &a, &b, &g)) {
            for (int k = 0; k < NS; ++k) th[k] = t0[k];
            if (warm == 1) first_stage = MU_STAGES - 3 > MU_FIRST ? MU_STAGES - 3 : MU_FIRST;
        }
    }

    R E[NS], C[NS*NS], dec = R(0), res = R(-1);
    int used = 0; bool ok = false;
    if (flag == 0) {
        // a given start (warm) is only an accelerator: if it does not converge, the cell is re-solved from the default
        // start on the full path, so whether a cell is delivered never depends on where the solver started
        bool given = (first_stage != MU_FIRST) || warm;
        for (int attempt = 0; attempt < 2; ++attempt) {
            flag = 0;
            for (int st = first_stage; st <= MU_STAGES; ++st) {
                R mu = pow(R(10), R(-st));
                int k = newton_stage(th, m, mu, st == MU_STAGES ? TOL_FIN : TOL_MID, max_newton, xn, xw, sn, sw, E, C, &dec, &ok);
                if (k == -2) { flag = 3; break; }   // target outside the lattice's moment space: multipliers diverge
                if (k < 0) { flag = 2; break; }
                used += k + 1;
                if (!ok) { flag = 1; break; }
            }
            if (flag == 0 || !given || attempt == 1) break;
            for (int k = 0; k < NS; ++k) th[k] = R(0);
            th[I_C4] = R(-1e-2)/psi_isd(I_C4); th[I_Q] = R(-0.5e-2)/psi_isd(I_Q);
            first_stage = MU_FIRST;
        }
    }

    // final pass: moments of the solved distribution
    R c6[6] = {0,0,0,0,0,0};   // mean x, var x, mean s, mu3, mu4, <(x-mean) s>
    R a_, b_, g_;
    cone_out[idx] = cone(th, &a_, &b_, &g_) ? g_/(S2MAX*a_*b_) : R(-1);
    if (flag == 0 || flag == 1) {
        R p[N_FEAT], ps[NS], mx = R(-1e30), Z = R(0), M[N_FEAT], F[N_FEAT];
        for (int k = 0; k < N_FEAT; ++k) { M[k] = R(0); F[k] = R(0); }
        for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
            eval_psi(xn[i], sn[j], ps); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*ps[k]; mx = fmax(mx, e);
        }
        R m1 = R(0), ms = R(0);
        for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
            eval_psi(xn[i], sn[j], ps); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*ps[k];
            R w = xw[i]*sw[j]*exp(e - mx); Z += w; m1 += w*xn[i]; ms += w*sn[j];
            eval_phi(xn[i], sn[j], p);
            for (int k = 0; k < N_FEAT; ++k) { M[k] += w*p[k]; F[k] += w*xn[i]*p[k]; }
        }
        if (!(Z > R(0)) || !isfinite(Z)) { flag = 6; }
        else {
            m1 /= Z; ms /= Z;
            R v = R(0), m3 = R(0), m4 = R(0), mix = R(0);
            for (int i = 0; i < NPAR; ++i) for (int j = 0; j < NPER; ++j) {
                eval_psi(xn[i], sn[j], ps); R e = R(0); for (int k = 0; k < NS; ++k) e += th[k]*ps[k];
                R w = xw[i]*sw[j]*exp(e - mx)/Z, d = xn[i] - m1, d2 = d*d;
                v += w*d2; m3 += w*d2*d; m4 += w*d2*d2; mix += w*d*sn[j];
            }
            c6[0] = m1; c6[1] = v; c6[2] = ms; c6[3] = m3; c6[4] = m4; c6[5] = mix;
            for (int k = 0; k < N_FEAT; ++k) { Mrec[idx*N_FEAT+k] = M[k]/Z + delta[k]; Mflux[idx*N_FEAT+k] = F[k]/Z; }
            // residual on the 9 enforced combinations, in units of each statistic's standard deviation
            R frame = R(1e30);
            if (stats(th, xn, xw, sn, sw, E, C)) {
                res = R(0);
                for (int k = 0; k < NS; ++k) res = fmax(res, fabs(E[k] - m[k])/sqrt(fmax(C[k*NS+k], R(1e-30))));
                frame = fmax(fmax(fabs(E[0] - m[0]), fabs(E[1] - m[1])), fabs(E[2] - m[2]));   // standardised units
            }
            if (flag == 0 && !(v > R(0) && ms > R(0) && isfinite(v) && isfinite(m3) && isfinite(m4) && isfinite(mix))) flag = 6;
            // a closure must reproduce its own frame (mean 0, var 1, <s> = 2); if not, the target is outside the lattice's moment space
            if (flag == 0 && !(frame < FRAME_TOL)) flag = 3;
        }
    }
    if (flag == 0 && res >= res_tol) flag = 4;

    status[idx] = flag; iters[idx] = used; resid_out[idx] = res;
    for (int k = 0; k < NS; ++k) if (flag == 0 || flag == 4) th_io[idx*NS+k] = th[k]*psi_isd(k);
    if (flag == 5) { q_par[idx] = R(0); q_per[idx] = R(0); adm_out[idx] = R(-1); return; }
    if (flag == 0 || flag == 4) {
        // pushforward to the exact frame (mean 0, var 1, <s> = 2): q in physical units
        R V = Pp/(mass*n), Tp = Pe/(mass*n), sv = sqrt(c6[1]);
        R skew = c6[3]/(c6[1]*sv), mixn = c6[5]/sv*(R(2)/c6[2]);
        q_par[idx] = mass*n*V*sqrt(V)*skew;
        q_per[idx] = R(0.5)*mass*n*sqrt(V)*(Tp/mass)*mixn;
        adm_out[idx] = c6[4]/(c6[1]*c6[1]) - R(1) - skew*skew;
    } else {
        q_par[idx] = R(0); q_per[idx] = R(0); adm_out[idx] = R(2);
    }
}

#ifdef GYRO_GPU
extern "C" __global__ void gyro_v03_kernel(const R* n, const R* u, const R* pp, const R* pe, const R* S, R* th,
    R* qp, R* qe, R* res, R* adm, R* cn, R* Mrec, R* Mflux, int* status, int* iters,
    const R* xn, const R* xw, const R* sn, const R* sw, const R* delta, int Ncells, R mass, R res_tol, int max_newton, int warm)
{
    int idx = blockIdx.x*blockDim.x + threadIdx.x;
    if (idx < Ncells)
        gyro_cell(idx, n, u, pp, pe, S, th, qp, qe, res, adm, cn, Mrec, Mflux, status, iters, xn, xw, sn, sw, delta,
                  mass, res_tol, max_newton, warm);
}
#else
extern "C" void gyro_v03_cpu(const R* n, const R* u, const R* pp, const R* pe, const R* S, R* th,
    R* qp, R* qe, R* res, R* adm, R* cn, R* Mrec, R* Mflux, int* status, int* iters,
    const R* xn, const R* xw, const R* sn, const R* sw, const R* delta, int Ncells, R mass, R res_tol, int max_newton, int warm)
{
    #pragma omp parallel for schedule(dynamic, 8)
    for (int idx = 0; idx < Ncells; ++idx)
        gyro_cell(idx, n, u, pp, pe, S, th, qp, qe, res, adm, cn, Mrec, Mflux, status, iters, xn, xw, sn, sw, delta,
                  mass, res_tol, max_newton, warm);
}
#endif
"""

def _psi_constants():
    x, wx, s_, ws = lattice()
    X, Sg = x[:, None], s_[None, :]; W = (wx[:, None] * ws[None, :]).ravel()
    idp = 1 / (1 + X * X); ide = 1 / (1 + Sg); z = 0 * X * Sg
    P = np.stack([X + z, Sg + z, X * X + z, X * idp + z, X * Sg * ide, X ** 3 * idp ** 2 + z, X ** 4 + z,
                  Sg * Sg + Sg ** 3 * ide + z, X * X * Sg + X * X * Sg * Sg * ide], 0).reshape(9, -1)
    mu = P @ W; sd = np.sqrt(((P - mu[:, None]) ** 2) @ W)
    return mu, 1 / sd


def _build_source():
    mu, isd = _psi_constants()
    f = lambda v: "{" + ", ".join("R(%.17g)" % t for t in v) + "}"
    return f"#define PSI_MU {f(mu)}\n#define PSI_ISD {f(isd)}\n" + SRC_BODY


SRC_BODY = SRC
SRC = None   # built after lattice() is defined (below)


# ------------------------------------------------------------------ host-side constants
def _expE1(x):
    """e^x E1(x) for x <= 1 by its convergent series (exact to double precision for x = 0.5)."""
    s, t = 0.0, 1.0
    for k in range(1, 60):
        t *= -x / k; s += t / k
    return math.exp(x) * (-0.5772156649015329 - math.log(x) - s)


def phi_numpy(x, s):
    x = np.asarray(x, float); s = np.asarray(s, float); idp = 1 / (1 + x * x); ide = 1 / (1 + s)
    z = 0 * x * s
    return np.stack([1 + z, x + z, s + z, x * x + z, x * idp + z, x * s * ide, s * s + z, x * x * s, x ** 4 + z,
                     x ** 3 * idp * idp + z, s ** 3 * ide + z, x * x * s * s * ide], 0)


def reference_exact():
    """<phi> under x ~ N(0,1), s ~ 2 Exp(1) (the bi-Maxwellian in the drift frame): 20001-point trapezoid in x (spectral
    for these analytic integrands) and closed form with E1 in s."""
    x = np.linspace(-14, 14, 20001); w = np.exp(-x * x / 2); w /= w.sum(); idp = 1 / (1 + x * x)
    E = lambda f: float((w * f).sum())
    e1, e2, e4, r1, r3 = E(x), E(x * x), E(x ** 4), E(x * idp), E(x ** 3 * idp ** 2)
    J = 0.5 * _expE1(0.5)                                  # E[1/(1+s)], s = 2 eta
    return np.array([1, e1, 2.0, e2, r1, e1 * (1 - J), 8.0, e2 * 2.0, e4, r3, 2 * 4.0 - 2.0 + 1 - J, e2 * (2.0 - 1 + J)])


def lattice():
    x, wx = np.polynomial.hermite_e.hermegauss(NP); wx = wx / wx.sum()
    e, we = np.polynomial.laguerre.laggauss(NQ); we = we / we.sum()
    return x, wx, 2 * e, we


def delta():
    x, wx, s, ws = lattice()
    lat = (phi_numpy(x[:, None], s[None, :]) * (wx[:, None] * ws[None, :])).sum(axis=(1, 2))
    return reference_exact() - lat


SHAPE_MAXWELL = reference_exact()          # drift-frame shape moments of any bi-Maxwellian
SRC = _build_source()
SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()


# ------------------------------------------------------------------ builds and launch
_cache = {}


def _cpu_lib(dtype, extra=()):
    real = "double" if dtype == np.float64 else "float"
    key = ("cpu", real, tuple(extra))
    if key in _cache: return _cache[key]
    tag = hashlib.sha256((SRC + real + str(extra) + f"{NP}x{NQ}").encode()).hexdigest()[:16]
    d = os.path.join(tempfile.gettempdir(), "gyro_v03_" + tag); os.makedirs(d, exist_ok=True)
    so = os.path.join(d, "gyro.so")
    if not os.path.exists(so):
        open(os.path.join(d, "gyro.cpp"), "w").write(SRC)
        cmd = ["g++", "-O2", "-shared", "-fPIC", "-fopenmp", f"-DREAL={real}", f"-DNPAR={NP}", f"-DNPER={NQ}", *extra, "-o", so, os.path.join(d, "gyro.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError("g++ build failed:\n" + r.stderr)
    lib = ctypes.CDLL(so); _cache[key] = lib; return lib


def _gpu_kernel(dtype):
    import cupy as cp
    real = "double" if dtype == np.float64 else "float"
    key = ("gpu", real)
    if key in _cache: return _cache[key]
    mod = cp.RawModule(code=SRC, options=("-DGYRO_GPU", f"-DREAL={real}", f"-DNPAR={NP}", f"-DNPER={NQ}", "-std=c++14"))
    k = mod.get_function("gyro_v03_kernel"); _cache[key] = k; return k


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


OUTS = ["q_par", "q_perp", "resid", "adm", "cone"]


def run_gyro(n, u_par, P_par, P_perp, S, theta_io=None, mass=1.0, res_tol=None, max_newton=40, warm=False,
             backend="auto", dtype=np.float32, threads=64, cpu_extra=(), rescue=True):
    """FP32 by default with an FP64 rescue: cells that FP32 does not deliver (status 1, 2, 3, 6) are re-solved in FP64,
    so every non-delivery decision, and every hard cell, is made at FP64 reproducibility.  rescue=False: pure precision."""
    out = _run(n, u_par, P_par, P_perp, S, theta_io, mass, res_tol, max_newton, warm, backend, dtype, threads, cpu_extra)
    if not (rescue and dtype == np.float32): return out
    xp = __import__("cupy") if out["status"].__class__.__module__.startswith("cupy") else np
    # rescue: every non-delivered cell, and every delivered cell FP32 cannot resolve: pressed against the integrability
    # cone (cone margin < 1e-5) or needing far more Newton steps than a well-posed FP32 solve (> 32)
    hard = xp.isin(out["status"], xp.asarray([1, 2, 3, 6], dtype=np.int32)) | ((out["status"] != 5) & ((out["cone"] < 1e-5) | (out["iters"] > 32)))
    idx = xp.nonzero(hard)[0]
    out["rescued"] = int(idx.size)
    if idx.size == 0: return out
    sub = lambda a: xp.asarray(a, dtype=np.float64)[idx]
    th = None if theta_io is None else xp.ascontiguousarray(xp.asarray(theta_io, dtype=np.float64)[idx])
    r = _run(sub(n), sub(u_par), sub(P_par), sub(P_perp), xp.ascontiguousarray(xp.asarray(S, dtype=np.float64)[idx]), th, mass,
             None, max_newton, warm, backend, np.float64, threads, cpu_extra)
    for k in OUTS + ["M_recon", "M_flux"]: out[k][idx] = r[k].astype(np.float32)
    out["status"][idx] = r["status"]; out["iters"][idx] = r["iters"]
    if theta_io is not None:
        ok = xp.isin(r["status"], xp.asarray([0, 4], dtype=np.int32))
        theta_io[idx[ok]] = th[ok].astype(theta_io.dtype)
    return out


def _run(n, u_par, P_par, P_perp, S, theta_io, mass, res_tol, max_newton, warm, backend, dtype, threads, cpu_extra):
    """(internal) one precision.  n, u_par, P_par, P_perp: (N,);  S: (N,12) drift-frame shape moments.
    theta_io (N,9) is updated in place for delivered cells. warm=1: short path from a nearby theta (time stepping);
    warm=2: full path from the given theta (uniqueness tests).
    Returns dict with n, u_par, P_par, P_perp (= inputs), q_par, q_perp, resid, adm, cone, M_recon, M_flux, status, iters."""
    if backend == "auto": backend = "cupy" if has_gpu() else "cpu"
    if res_tol is None: res_tol = 1e-4 if dtype == np.float64 else 2e-3   # the FP32 residual floor is ~6e-4
    if backend == "cupy":
        import cupy as cp
        xp = cp
    else:
        xp = np
    N = int(S.shape[0])
    A = lambda a: xp.ascontiguousarray(xp.asarray(a, dtype=dtype))
    n_, u_, pp_, pe_, S_ = A(n), A(u_par), A(P_par), A(P_perp), A(S)
    if theta_io is None: theta_io = xp.zeros((N, N_SUF), dtype=dtype)
    assert theta_io.dtype == np.dtype(dtype) and theta_io.flags.c_contiguous
    o = {k: xp.zeros(N, dtype=dtype) for k in OUTS}
    Mrec = xp.zeros((N, N_FEAT), dtype=dtype); Mflux = xp.zeros((N, N_FEAT), dtype=dtype)
    status = xp.zeros(N, dtype=np.int32); iters = xp.zeros(N, dtype=np.int32)
    x, wx, s, ws = lattice()
    consts = [A(x), A(wx), A(s), A(ws), A(delta())]
    arrs = [n_, u_, pp_, pe_, S_, theta_io, o["q_par"], o["q_perp"], o["resid"], o["adm"], o["cone"], Mrec, Mflux, status, iters] + consts
    sc = np.float64 if dtype == np.float64 else np.float32
    if backend == "cupy":
        k = _gpu_kernel(dtype)
        k(((N + threads - 1) // threads,), (threads,), tuple(arrs) + (np.int32(N), sc(mass), sc(res_tol), np.int32(max_newton), np.int32(int(warm))))
        cp.cuda.runtime.deviceSynchronize()
    else:
        lib = _cpu_lib(dtype, cpu_extra); ct = ctypes.c_double if dtype == np.float64 else ctypes.c_float
        p = lambda a: a.ctypes.data_as(ctypes.c_void_p)
        lib.gyro_v03_cpu(*[p(a) for a in arrs], ctypes.c_int(N), ct(mass), ct(res_tol), ctypes.c_int(max_newton), ctypes.c_int(int(warm)))
    o.update(n=n_, u_par=u_, P_par=pp_, P_perp=pe_, M_recon=Mrec, M_flux=Mflux, status=status, iters=iters)
    return o


if __name__ == "__main__":
    N = 77
    Smax = np.tile(SHAPE_MAXWELL, (N, 1))
    for be in (["cupy"] if has_gpu() else []) + ["cpu"]:
        for dt in (np.float32, np.float64):
            o = run_gyro(np.ones(N), np.full(N, 1.3), np.full(N, 0.4), np.full(N, 2.5), Smax, backend=be, dtype=dt)
            g = lambda a: a.get() if hasattr(a, "get") else a
            print(f"{be:5s} {np.dtype(dt).name}: bi-Maxwellian -> status {np.unique(g(o['status']))}  max|q_par| {np.abs(g(o['q_par'])).max():.1e}  "
                  f"max|q_perp| {np.abs(g(o['q_perp'])).max():.1e}  Newton its {int(g(o['iters'])[0])}  adm {g(o['adm'])[0]:.4f} (Gaussian: 2)")
    print("source sha256", SOURCE_SHA256)
