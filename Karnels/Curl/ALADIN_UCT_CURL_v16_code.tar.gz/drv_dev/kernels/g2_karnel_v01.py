# -*- coding: utf-8 -*-
"""
ALADIN kernel 03 - G2 : geometry / octonion algebra diagnostics      (g2_karnel_v01.py)
=====================================================================================

What this kernel is
-------------------
An EXPERIMENTAL research kernel.  It maps the local plasma state of every cell to a unit-free
imaginary octonion and measures how that 7-dimensional state is arranged in physical space,
using the G2-invariant 3-form phi.  It is a DIAGNOSTIC kernel: it reads the plasma state and
writes diagnostic fields; it never changes the state and adds no force.  (A G2 force term needs
a derivation from an energy or an equation of motion first - see "Not in v01" below.)

Grid contract (identical to uct_curl.py v1.3 and the ALADIN Z-pinch setup)
---------------------------------------------------------------------------
    ghost width g >= 1, z fastest (C order)
    rho, vr, vphi, vz      cell centres   (nr+2g,   nphi+2g,   nz+2g)
    Br                     r-faces        (nr+1+2g, nphi+2g,   nz+2g)
    Bphi                   phi-faces      (nr+2g,   nphi+1+2g, nz+2g)
    Bz                     z-faces        (nr+2g,   nphi+2g,   nz+1+2g)
    r_faces  (nr+1+2g), r_centers (nr+2g)  ghost-extended, uniform dr, use make_grid()
    axis grid: r_faces[g] == 0 is allowed (first cell centre at dr/2)
    outputs: cell-centred (nr+2g, nphi+2g, nz+2g); only the interior is written
The kernel reads NO ghost values: phi is wrapped periodically inside the kernel (nphi*dphi = 2 pi),
r and z use second-order one-sided differences on the first/last ring/layer.  It is therefore
immune to ghost-fill errors in the driver's BoundaryManager (Campaign 05, register Q17).

What it computes per cell
-------------------------
  o = u + (sigma_c + b) l   in O = H + H l            unit-free state  (mu0 = 1), G2-covariant embedding:
        u in Im(H), b in Im(H) l, sigma_c on l.  Spatial rotations act on (u, b) as a subgroup of G2,
        so every phi-based diagnostic is independent of how the axes are oriented (self-test A9).
        u = v / v_ref,  b = B_cc / (sqrt(rho) v_ref)    (b = Alfven velocity in units of v_ref),
        both in Cartesian components so that derivatives act on true vector components
        sigma_c = 2 u.b / (|u|^2 + |b|^2)  in [-1, 1]   normalised cross helicity (a standard MHD
                                                         turbulence diagnostic; replaces the old chi)
  D_r = d o/dr,  D_phi = (1/r) d o/dphi,  D_z = d o/dz  (derivatives along the orthonormal frame r_hat, phi_hat, z_hat;
        Phi is the same in any right-handed orthonormal frame, e.g. x, y, z - tested against a Cartesian oracle)
  Phi    = phi(D_r, D_phi, D_z)          pull-back of the G2 3-form to physical space
  vol    = |D_r ^ D_phi ^ D_z|           3-volume spanned by the gradients  (sqrt of the Gram det)
  calib  = Phi / vol  in [-1, 1]          G2 calibration ratio: |calib| = 1 exactly when the local
                                          image of the plasma state is an ASSOCIATIVE 3-plane
                                          (Harvey & Lawson 1982); 0 where vol vanishes
  ident  = |Phi^2 + |[D_r,D_phi,D_z]|^2/4 - vol^2| / vol^2
                                          Harvey-Lawson associator identity; must be round-off.
                                          A built-in consistency check of the algebra every cell.
  divB   = staggered finite-volume cylindrical divergence (the same discrete divergence as CT / EGLM)
  sigma  = sigma_c at the cell centre

  An axisymmetric, z-independent state (a pure Z-pinch) has D_phi = D_z = 0, so Phi = vol = 0:
  the G2 diagnostics respond only to genuinely three-dimensional structure.

Gradient-tensor invariants (second output block, run_g2 keys)
------------------------------------------------------------
  With A = grad u, B = grad b (full tensors in the local orthonormal frame, connection terms included),
  P = -tr M, Q = (P^2 - tr M^2)/2, R = -det M  (the standard velocity-gradient invariants):
    P_u Q_u R_u, P_b Q_b R_b          invariants of the velocity and Alfven-field gradients
    R_zp, R_zm                        R of the Elsasser gradients grad(u + b), grad(u - b)
    Re_Omega, Im_Omega                Re / Im det grad(u + i b)   (holomorphic volume form of C^3)
    omega_sigma                       grad sigma_c . sum_i grad u_i x grad b_i   (Kahler-form term)
    decomp                            |Phi - (Re_Omega - omega_sigma)| / scale, must be round-off
  Exact relations (proved numerically to round-off, checked in every self-test):
    Phi       = Re_Omega - omega_sigma                 (the SU(3) split of the G2 3-form, phi = Re Omega + dt^omega)
    Re_Omega  = (R_zp + R_zm)/2 - 2 R_u
    Im_Omega  = -(R_zp - R_zm)/2 + 2 R_b
    pure flow  (b = 0): Phi = det grad u = -R_u        pure field (u = 0): Phi = 0
  In the physically consistent (galilean) mode, Phi = Re_Omega: the G2 3-form IS this mixture.  What is
  not reducible to the classical R invariants is the geometry: vol (the 3-volume of the gradient frame in
  the 6-dimensional (u, b) space) and calib = Re_Omega / vol, a normalised "how associative" measure.
  So the G2 form is a specific mixture of the Elsasser third invariants, the quantities whose sign is
  linked to the direction of energy transfer in MHD turbulence.  Whether Phi / Omega carry information
  beyond R_u, R_b, R_z+- is an open research question (see the hypotheses in the campaign notes).
  FP32 note: R-type invariants are cubic in the gradients and cancel strongly; expect ~1e-4 relative
  accuracy in FP32 (self-test E1).  Use FP64 for invariant statistics.

Fixes relative to the v55 kernel (g2_karnel.py), each measured
---------------------------------------------------------------
  1. The Fano-plane orientation of v55 is not an octonion algebra (alternativity violated by
     up to 43, Moufang by 159, norm composition by 5 on random elements).  v01 uses a correctly
     oriented plane: all three identities hold to round-off (self-test A).
  2. v55 evaluated phi(o, o, o), which is identically zero for an alternating 3-form, so its
     'phi after' was always ~1e-18, its Newton step was always zero, and the printed 'reduction'
     compared it with a different (symmetric) polynomial.  v01 evaluates phi on three independent
     vectors (the three spatial gradients).
  3. v55 mixed velocity and magnetic field with different units in one octonion.  v01 uses
     unit-free Alfvenic variables.
  4. v55's energy source was 0.1 * (-v.S), i.e. 90 % unbalanced by design; v01 has no source.
  5. v55's (v_phi^2 - B_phi^2)/r terms are the standard cylindrical MHD geometric sources (and
     lacked rho, mu0); they belong to the RESIDUAL kernel and would be double-counted here.
  6. v55 used collocated arrays with r starting at 0.05; v01 uses the ALADIN staggered Z-pinch grid.
  8. sigma_c changes under a constant velocity boost and has no velocity units, so any Phi that includes
     its gradient depends on the observer's frame (measured: 18 % change under a boost) and is not
     homogeneous in v_ref (9 % deviation).  run_g2(galilean=True), the DEFAULT, removes sigma_c from the
     gradients: then Phi = Re_Omega exactly and every output is boost-invariant (< 2e-13) and scales
     exactly with v_ref.  galilean=False keeps the full 7-slot form for comparison.
  9. Memory: run_g2(outputs=(...)) allocates only the requested arrays (each ~1.1 GB at 512^3 FP64).
  7. v55 put (v, B) into octonion slots in an arbitrary order, so phi changed (by up to ~15) when the
     coordinate axes were rotated.  v01 uses a G2-covariant embedding: rotation changes phi by < 1e-14.

Not in v01 (deliberately)
-------------------------
  No feedback on the plasma.  A G2 coupling should come from a functional (e.g. lambda/2 * int Phi^2 dV)
  whose variation gives a force and an exactly matching energy source.  That is the v02 step, once
  these diagnostics have been characterised on real runs.

Usage
-----
  python g2_karnel_v01.py            # self-test on CPU (g++), and on the GPU too if CuPy + CUDA exist
"""
import ctypes, hashlib, math, os, subprocess, sys, tempfile
import numpy as np

try:
    import cupy as cp
except Exception:
    cp = None

VERSION = "g2_karnel v01"

# Correctly oriented Fano plane (0-based imaginary units): e_a e_b = e_c for each cyclic (a, b, c).
LINES = ((0, 1, 3), (1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 0), (5, 6, 1), (6, 0, 2))


class G2ContractError(ValueError):
    pass


# =============================================================================== kernel source
# One source compiles both with NVRTC (CuPy, GPU) and with g++ (host leg): the same arithmetic runs
# on both execution legs.  REAL_T is replaced by float or double.
_SRC = r'''
#ifdef __CUDACC_RTC__
  #define DEV __device__ __forceinline__
#else
  #include <math.h>
  #define DEV static inline
#endif
typedef REAL_T R;

DEV void cross7(const R* x, const R* y, R* z) {
    const int L[7][3] = {{0,1,3},{1,2,4},{2,3,5},{3,4,6},{4,5,0},{5,6,1},{6,0,2}};
    for (int n = 0; n < 7; ++n) z[n] = (R)0;
    for (int l = 0; l < 7; ++l) {
        int a = L[l][0], b = L[l][1], c = L[l][2];
        z[c] += x[a]*y[b] - x[b]*y[a];
        z[a] += x[b]*y[c] - x[c]*y[b];
        z[b] += x[c]*y[a] - x[a]*y[c];
    }
}
DEV R dot7(const R* x, const R* y) { R s = 0; for (int n = 0; n < 7; ++n) s += x[n]*y[n]; return s; }
/* full octonion product (x0 + x)(y0 + y) */
DEV void mul8(R x0, const R* x, R y0, const R* y, R* z0, R* z) {
    R c[7]; cross7(x, y, c);
    *z0 = x0*y0 - dot7(x, y);
    for (int n = 0; n < 7; ++n) z[n] = x0*y[n] + y0*x[n] + c[n];
}

DEV R det3(const R M[3][3]) {
    return M[0][0]*(M[1][1]*M[2][2] - M[1][2]*M[2][1]) - M[0][1]*(M[1][0]*M[2][2] - M[1][2]*M[2][0])
         + M[0][2]*(M[1][0]*M[2][1] - M[1][1]*M[2][0]);
}
DEV R tr3(const R M[3][3]) { return M[0][0] + M[1][1] + M[2][2]; }
DEV R trsq3(const R M[3][3]) { R s = 0; for (int a = 0; a < 3; ++a) for (int b = 0; b < 3; ++b) s += M[a][b]*M[b][a]; return s; }
DEV void cmul(R ar, R ai, R br, R bi, R* cr, R* ci) { *cr = ar*br - ai*bi; *ci = ar*bi + ai*br; }
/* det(A + i B) for real 3x3 A, B */
DEV void cdet3(const R A[3][3], const R B[3][3], R* re, R* im) {
    R t1r, t1i, t2r, t2i, xr, xi, sr = 0, si = 0;
    const int P[3][3] = {{0,1,2},{1,2,0},{2,0,1}};
    for (int s = 0; s < 3; ++s) {                       /* sum over cyclic minus anticyclic terms */
        int a = P[s][0], b = P[s][1], c = P[s][2];
        cmul(A[0][a], B[0][a], A[1][b], B[1][b], &t1r, &t1i); cmul(t1r, t1i, A[2][c], B[2][c], &xr, &xi); sr += xr; si += xi;
        cmul(A[0][a], B[0][a], A[1][c], B[1][c], &t2r, &t2i); cmul(t2r, t2i, A[2][b], B[2][b], &xr, &xi); sr -= xr; si -= xi;
    }
    *re = sr; *im = si;
}

struct G2Grid {
    int nr, nphi, nz, g, galilean;
    R dr, dphi, dz, vref;
    const R *rho, *vr, *vp, *vz, *Br, *Bp, *Bz, *rf, *rc;
};

DEV long cidx(const G2Grid& G, int i, int j, int k) {
    return ((long)(i + G.g)*(G.nphi + 2*G.g) + (j + G.g))*(G.nz + 2*G.g) + (k + G.g);
}

/* unit-free state of active cell (i, j, k); j is wrapped periodically */
DEV void state(const G2Grid& G, int i, int j, int k, R* o) {
    j = (j % G.nphi + G.nphi) % G.nphi;
    const int g = G.g, NPg = G.nphi + 2*g, NZg = G.nz + 2*g;
    const long c   = cidx(G, i, j, k);
    const long br0 = ((long)(i + g)*NPg + (j + g))*NZg + (k + g);
    const long br1 = ((long)(i + 1 + g)*NPg + (j + g))*NZg + (k + g);
    const long bp0 = ((long)(i + g)*(G.nphi + 1 + 2*g) + (j + g))*NZg + (k + g);
    const long bp1 = bp0 + NZg;
    const long bz0 = ((long)(i + g)*NPg + (j + g))*(G.nz + 1 + 2*g) + (k + g);
    const R rho = G.rho[c];
    const R s = (R)1 / (sqrt(rho) * G.vref);
    const R u0 = G.vr[c] / G.vref, u1 = G.vp[c] / G.vref, u2 = G.vz[c] / G.vref;
    const R b0 = (R)0.5*(G.Br[br0] + G.Br[br1])*s;
    const R b1 = (R)0.5*(G.Bp[bp0] + G.Bp[bp1])*s;
    const R b2 = (R)0.5*(G.Bz[bz0] + G.Bz[bz0 + 1])*s;
    const R e = u0*u0 + u1*u1 + u2*u2 + b0*b0 + b1*b1 + b2*b2;
    const R sg = (e > (R)0) ? (R)2*(u0*b0 + u1*b1 + u2*b2)/e : (R)0;
    /* Cartesian components (cell-centre angle), so that d/dx_i acts on true vector components */
    const R ph = ((R)j + (R)0.5)*G.dphi, cs = cos(ph), sn = sin(ph);
    const R ux = u0*cs - u1*sn, uy = u0*sn + u1*cs, bx = b0*cs - b1*sn, by = b0*sn + b1*cs;
    /* G2-covariant embedding  o = x + y l,  x = u in Im(H) = span(e0, e1, e3),
       y = sigma + b in H, l = e2:  spatial rotations act as a G2 subgroup, so phi is
       rotation invariant (self-test A9).   index map: u -> e0,e1,e3 ; sigma -> e2 ;
       b_x -> e6, b_y -> e4, b_z -> -e5                                                    */
    o[0] = ux; o[1] = uy; o[3] = u2;
    o[2] = sg; o[6] = bx; o[4] = by; o[5] = -b2;
}
DEV R sigma_of(const R* o) { return o[2]; }

#define NQ 18
DEV void g2_cell(const G2Grid& G, int i, int j, int k, R* val) {
    const int g = G.g, NPg = G.nphi + 2*g, NZg = G.nz + 2*g;
    const long c = cidx(G, i, j, k);
    const R rc = G.rc[i + g];

    /* staggered finite-volume divergence (CT / EGLM discretisation) */
    const long br0 = ((long)(i + g)*NPg + (j + g))*NZg + (k + g);
    const long br1 = ((long)(i + 1 + g)*NPg + (j + g))*NZg + (k + g);
    const long bp0 = ((long)(i + g)*(G.nphi + 1 + 2*g) + (j + g))*NZg + (k + g);
    const long bz0 = ((long)(i + g)*NPg + (j + g))*(G.nz + 1 + 2*g) + (k + g);
    val[0] = (G.rf[i + 1 + g]*G.Br[br1] - G.rf[i + g]*G.Br[br0]) / (rc*G.dr)
            + (G.Bp[bp0 + NZg] - G.Bp[bp0]) / (rc*G.dphi)
            + (G.Bz[bz0 + 1] - G.Bz[bz0]) / G.dz;

    R o[7], a[7], b[7], d[7], Dr[7], Dp[7], Dz[7];
    state(G, i, j, k, o);
    val[1] = sigma_of(o);

    /* radial gradient: centred inside, 2nd-order one-sided on the first / last ring (no ghosts) */
    if (i == 0)             { state(G, 1, j, k, a); state(G, 2, j, k, b);
                              for (int n = 0; n < 7; ++n) Dr[n] = (-(R)3*o[n] + (R)4*a[n] - b[n]) / ((R)2*G.dr); }
    else if (i == G.nr - 1) { state(G, i - 1, j, k, a); state(G, i - 2, j, k, b);
                              for (int n = 0; n < 7; ++n) Dr[n] = ((R)3*o[n] - (R)4*a[n] + b[n]) / ((R)2*G.dr); }
    else                    { state(G, i + 1, j, k, a); state(G, i - 1, j, k, b);
                              for (int n = 0; n < 7; ++n) Dr[n] = (a[n] - b[n]) / ((R)2*G.dr); }
    /* azimuthal gradient: periodic, centred */
    if (G.nphi >= 3) { state(G, i, j + 1, k, a); state(G, i, j - 1, k, b);
                       for (int n = 0; n < 7; ++n) Dp[n] = (a[n] - b[n]) / ((R)2*G.dphi*rc); }
    else for (int n = 0; n < 7; ++n) Dp[n] = (R)0;
    /* axial gradient */
    if (G.nz < 3)           { for (int n = 0; n < 7; ++n) Dz[n] = (R)0; }
    else if (k == 0)        { state(G, i, j, 1, a); state(G, i, j, 2, b);
                              for (int n = 0; n < 7; ++n) Dz[n] = (-(R)3*o[n] + (R)4*a[n] - b[n]) / ((R)2*G.dz); }
    else if (k == G.nz - 1) { state(G, i, j, k - 1, a); state(G, i, j, k - 2, b);
                              for (int n = 0; n < 7; ++n) Dz[n] = ((R)3*o[n] - (R)4*a[n] + b[n]) / ((R)2*G.dz); }
    else                    { state(G, i, j, k + 1, a); state(G, i, j, k - 1, b);
                              for (int n = 0; n < 7; ++n) Dz[n] = (a[n] - b[n]) / ((R)2*G.dz); }
    /* Galilean mode: drop the sigma_c direction from the gradients.  sigma_c changes under a constant
       velocity boost, every gradient of u and b does not; with it removed, Phi = Re Omega and all outputs
       are frame-independent (self-test F2).  sigma itself is still reported in val[1]. */
    if (G.galilean) { Dr[2] = (R)0; Dp[2] = (R)0; Dz[2] = (R)0; }

    /* pull-back of phi */
    cross7(Dr, Dp, d);
    const R ph = dot7(d, Dz);
    /* 3-volume |Dr ^ Dp ^ Dz| by modified Gram-Schmidt with re-orthogonalisation
       (stable; a Gram determinant cancels catastrophically for nearly aligned gradients) */
    const R n1 = sqrt(dot7(Dr, Dr)), n2r = sqrt(dot7(Dp, Dp)), n3r = sqrt(dot7(Dz, Dz));
    const R scale = n1*n2r*n3r;
    R q1[7], q2[7], w[7];
    R v = (R)0;
    if (scale > (R)0) {
        for (int n = 0; n < 7; ++n) { q1[n] = Dr[n]/n1; q2[n] = Dp[n]; w[n] = Dz[n]; }
        for (int pass = 0; pass < 2; ++pass) { R t = dot7(q1, q2); for (int n = 0; n < 7; ++n) q2[n] -= t*q1[n]; }
        const R n2 = sqrt(dot7(q2, q2));
        if (n2 > (R)0) {
            for (int n = 0; n < 7; ++n) q2[n] /= n2;
            for (int pass = 0; pass < 2; ++pass) {
                R t1 = dot7(q1, w); for (int n = 0; n < 7; ++n) w[n] -= t1*q1[n];
                R t2 = dot7(q2, w); for (int n = 0; n < 7; ++n) w[n] -= t2*q2[n];
            }
            v = n1*n2*sqrt(dot7(w, w));
        }
    }
    /* associator [Dr, Dp, Dz] */
    R l0, l[7], m0, m[7], q0, q[7], p0, p[7];
    mul8((R)0, Dr, (R)0, Dp, &l0, l);  mul8(l0, l, (R)0, Dz, &m0, m);      /* (Dr Dp) Dz */
    mul8((R)0, Dp, (R)0, Dz, &q0, q);  mul8((R)0, Dr, q0, q, &p0, p);      /* Dr (Dp Dz) */
    R as2 = (m0 - p0)*(m0 - p0);
    for (int n = 0; n < 7; ++n) as2 += (m[n] - p[n])*(m[n] - p[n]);
    /* calib only where the volume is resolvable relative to the gradient norms (scale-free):
       the round-off error of Phi/vol is ~ eps*scale/vol */
    const R tiny = (sizeof(R) == 4 ? (R)1e-2 : (R)1e-6);
    val[2] = ph; val[3] = v;
    val[4] = (scale > (R)0 && v > tiny*scale) ? ph / v : (R)0;
    /* Harvey-Lawson identity, relative to scale^2 (well conditioned for any configuration) */
    val[5] = (scale > (R)0) ? fabs(ph*ph + (R)0.25*as2 - v*v) / (scale*scale) : (R)0;

    /* ---- gradient tensors in the local orthonormal frame (rows = components, cols = r, phi, z directions)
       d/dx acted on Cartesian components, so the connection (1/r) terms of cylindrical geometry are included */
    const R phc = ((R)j + (R)0.5)*G.dphi, cs = cos(phc), sn = sin(phc);
    const R* Dd[3] = {Dr, Dp, Dz};
    R A[3][3], B[3][3], Zp[3][3], Zm[3][3], gs[3];
    for (int q = 0; q < 3; ++q) {
        const R* X = Dd[q];
        const R ux = X[0], uy = X[1], uz = X[3], bx = X[6], by = X[4], bz = -X[5];
        A[0][q] =  ux*cs + uy*sn; A[1][q] = -ux*sn + uy*cs; A[2][q] = uz;
        B[0][q] =  bx*cs + by*sn; B[1][q] = -bx*sn + by*cs; B[2][q] = bz;
        gs[q] = X[2];
    }
    for (int a = 0; a < 3; ++a) for (int b = 0; b < 3; ++b) { Zp[a][b] = A[a][b] + B[a][b]; Zm[a][b] = A[a][b] - B[a][b]; }
    const R Pu = -tr3(A), Pb = -tr3(B);
    R ReO, ImO; cdet3(A, B, &ReO, &ImO);
    R W[3] = {0, 0, 0};                                   /* sum_i grad u_i x grad b_i */
    for (int a = 0; a < 3; ++a) {
        W[0] += A[a][1]*B[a][2] - A[a][2]*B[a][1];
        W[1] += A[a][2]*B[a][0] - A[a][0]*B[a][2];
        W[2] += A[a][0]*B[a][1] - A[a][1]*B[a][0];
    }
    const R Ws = gs[0]*W[0] + gs[1]*W[1] + gs[2]*W[2];
    val[6] = Pu;                                  /* P_u = -div u                          */
    val[7] = (R)0.5*(Pu*Pu - trsq3(A));           /* Q_u                                   */
    val[8] = -det3(A);                            /* R_u                                   */
    val[9] = Pb;                                  /* P_b                                   */
    val[10] = (R)0.5*(Pb*Pb - trsq3(B));           /* Q_b                                   */
    val[11] = -det3(B);                            /* R_b                                   */
    val[12] = -det3(Zp);                           /* R of Elsasser z+ = u + b              */
    val[13] = -det3(Zm);                           /* R of Elsasser z- = u - b              */
    val[14] = ReO;                                 /* Re det grad(u + i b)  = Re Omega      */
    val[15] = ImO;                                 /* Im det grad(u + i b)  = Im Omega      */
    val[16] = Ws;                                  /* grad sigma . sum_i grad u_i x grad b_i (omega term) */
    val[17] = (scale > (R)0) ? fabs(ph - (ReO - Ws)) / scale : (R)0;   /* SU(3) decomposition check */
}

#ifdef __CUDACC_RTC__
extern "C" __global__ void g2_kernel(
    const R* rho, const R* vr, const R* vp, const R* vz, const R* Br, const R* Bp, const R* Bz,
    const R* rf, const R* rc, R dr, R dphi, R dz, R vref, int nr, int nphi, int nz, int g, int galilean,
    const int* slot, R* out) {
    const int k = blockIdx.x*blockDim.x + threadIdx.x;
    const int j = blockIdx.y*blockDim.y + threadIdx.y;
    const int i = blockIdx.z*blockDim.z + threadIdx.z;
    if (i >= nr || j >= nphi || k >= nz) return;
    G2Grid G = {nr, nphi, nz, g, galilean, dr, dphi, dz, vref, rho, vr, vp, vz, Br, Bp, Bz, rf, rc};
    R val[NQ]; g2_cell(G, i, j, k, val);
    const long NC = (long)(nr + 2*g)*(nphi + 2*g)*(nz + 2*g), c = cidx(G, i, j, k);
    for (int q = 0; q < NQ; ++q) if (slot[q] >= 0) out[(long)slot[q]*NC + c] = val[q];
}
#else
extern "C" void g2_host(
    const R* rho, const R* vr, const R* vp, const R* vz, const R* Br, const R* Bp, const R* Bz,
    const R* rf, const R* rc, R dr, R dphi, R dz, R vref, int nr, int nphi, int nz, int g, int galilean,
    const int* slot, R* out) {
    G2Grid G = {nr, nphi, nz, g, galilean, dr, dphi, dz, vref, rho, vr, vp, vz, Br, Bp, Bz, rf, rc};
    const long NC = (long)(nr + 2*g)*(nphi + 2*g)*(nz + 2*g);
    R val[NQ];
    for (int i = 0; i < nr; ++i) for (int j = 0; j < nphi; ++j) for (int k = 0; k < nz; ++k) {
        g2_cell(G, i, j, k, val); const long c = cidx(G, i, j, k);
        for (int q = 0; q < NQ; ++q) if (slot[q] >= 0) out[(long)slot[q]*NC + c] = val[q];
    }
}
#endif
'''
OUTPUTS = ("divB", "sigma", "Phi", "vol", "calib", "ident")
INVARIANTS = ("P_u", "Q_u", "R_u", "P_b", "Q_b", "R_b", "R_zp", "R_zm", "Re_Omega", "Im_Omega", "omega_sigma", "decomp")
KERNEL_SHA256 = hashlib.sha256(_SRC.encode()).hexdigest()


# =============================================================================== grid helpers
def make_grid(nr, dr, g=2, dtype=np.float64, r0=0.0):
    """Ghost-extended radial faces/centres, same as uct_curl.make_grid (r0 = 0 gives an axis grid)."""
    r_faces = (r0 + (np.arange(nr + 1 + 2*g) - g)*dr).astype(dtype)
    r_centers = (r0 + (np.arange(nr + 2*g) - g + 0.5)*dr).astype(dtype)
    return r_faces, r_centers


def shapes(nr, nphi, nz, g):
    C = (nr + 2*g, nphi + 2*g, nz + 2*g)
    return dict(rho=C, vr=C, vphi=C, vz=C, Br=(nr + 1 + 2*g, nphi + 2*g, nz + 2*g),
                Bphi=(nr + 2*g, nphi + 1 + 2*g, nz + 2*g), Bz=(nr + 2*g, nphi + 2*g, nz + 1 + 2*g),
                r_faces=(nr + 1 + 2*g,), r_centers=(nr + 2*g,))


def _host(a):
    return a.get() if (cp is not None and isinstance(a, cp.ndarray)) else np.asarray(a)


def validate_inputs(F, r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g, v_ref):
    """Raise G2ContractError on the first contract violation (pure host check)."""
    E = G2ContractError
    for n, v in (("nr", nr), ("nphi", nphi), ("nz", nz), ("g", g)):
        if not isinstance(v, (int, np.integer)): raise E(f"{n} must be an integer")
    if g < 1: raise E(f"ghost width g must be >= 1 (got {g})")
    if nr < 3: raise E(f"nr must be >= 3 for the one-sided radial stencil (got {nr})")
    if nphi < 1 or nz < 1: raise E("nphi, nz must be >= 1")
    for n, v in (("dr", dr), ("dphi", dphi), ("dz", dz), ("v_ref", v_ref)):
        if not (np.isfinite(v) and v > 0): raise E(f"{n} must be finite and > 0 (got {v})")
    if abs(nphi*dphi - 2*math.pi) > 1e-6*2*math.pi: raise E("nphi*dphi must equal 2*pi (periodic full circle)")
    want = shapes(nr, nphi, nz, g); arrs = dict(F, r_faces=r_faces, r_centers=r_centers)
    dt = None
    for n, shp in want.items():
        a = arrs[n]
        if tuple(a.shape) != shp: raise E(f"{n} has shape {tuple(a.shape)}, expected {shp}")
        if a.dtype not in (np.float32, np.float64): raise E(f"{n} dtype must be float32/float64")
        dt = dt or a.dtype
        if a.dtype != dt: raise E(f"{n} dtype {a.dtype} differs from {dt}")
        if not a.flags.c_contiguous: raise E(f"{n} must be C-contiguous")
    rf, rc = _host(r_faces).astype(np.float64), _host(r_centers).astype(np.float64)
    tol = 64*np.finfo(dt).eps*max(1.0, float(np.max(np.abs(rf))))
    if np.max(np.abs(np.diff(rf) - dr)) > tol: raise E("r_faces must be uniform with spacing dr")
    if np.max(np.abs(rc - 0.5*(rf[:-1] + rf[1:]))) > tol: raise E("r_centers must be the face midpoints")
    if rf[g] < -tol: raise E("first active face must be at r >= 0")
    rho = _host(F["rho"])[g:g + nr, g:g + nphi, g:g + nz]
    if not np.all(np.isfinite(rho)) or np.min(rho) <= 0: raise E("rho must be finite and > 0 in the active cells")
    return np.dtype(dt)


# =============================================================================== execution legs
_host_libs, _gpu_kernels = {}, {}


def _host_lib(dtype):
    name = np.dtype(dtype).name
    if name not in _host_libs:
        d = tempfile.mkdtemp(prefix="g2v01_")
        src = os.path.join(d, "g2.cpp"); lib = os.path.join(d, "g2.so")
        open(src, "w").write(_SRC.replace("REAL_T", {"float32": "float", "float64": "double"}[name]))
        subprocess.run(["g++", "-O2", "-fno-fast-math", "-ffp-contract=off", "-shared", "-fPIC", src, "-o", lib], check=True)
        L = ctypes.CDLL(lib); ct = ctypes.c_float if name == "float32" else ctypes.c_double
        L.g2_host.argtypes = [ctypes.c_void_p]*9 + [ct]*4 + [ctypes.c_int]*5 + [ctypes.c_void_p]*2
        L.g2_host.restype = None; _host_libs[name] = (L, ct)
    return _host_libs[name]


QUANTITIES = OUTPUTS + INVARIANTS          # the order of val[] in the kernel


def run_g2(F, r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g=2, v_ref=1.0, backend="auto",
           outputs=None, galilean=True):
    """Run the kernel.  F: dict with rho, vr, vphi, vz, Br, Bphi, Bz (NumPy or CuPy arrays).
    backend : 'host' (g++ build of the same source), 'gpu' (CuPy), or 'auto' (gpu if available)
    outputs : iterable of names from QUANTITIES to compute and return (default: all 18).
              Only the selected arrays are allocated: at 512^3 FP64 each costs ~1.1 GB.
    galilean: True drops sigma_c from the gradients, so Phi = Re_Omega and every output is
              independent of a constant velocity boost (recommended for physics statistics).
    Returns a dict name -> cell-centred NumPy array (NaN in the ghost cells)."""
    dt = validate_inputs(F, r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g, v_ref)
    names = list(QUANTITIES) if outputs is None else list(outputs)
    bad = [n for n in names if n not in QUANTITIES]
    if bad or not names: raise G2ContractError(f"unknown or empty outputs: {bad}")
    slot = np.full(len(QUANTITIES), -1, dtype=np.int32)
    for s_, n in enumerate(names): slot[QUANTITIES.index(n)] = s_
    if backend == "auto": backend = "gpu" if (cp is not None and _gpu_ok()) else "host"
    C = shapes(nr, nphi, nz, g)["rho"]; order = ("rho", "vr", "vphi", "vz", "Br", "Bphi", "Bz")
    if backend == "host":
        L, ct = _host_lib(dt)
        ins = [np.ascontiguousarray(_host(F[n]), dtype=dt) for n in order] + [np.ascontiguousarray(_host(r_faces), dtype=dt), np.ascontiguousarray(_host(r_centers), dtype=dt)]
        out = np.full((len(names),) + C, np.nan, dtype=dt)
        L.g2_host(*[a.ctypes.data for a in ins], ct(dr), ct(dphi), ct(dz), ct(v_ref), nr, nphi, nz, g, int(bool(galilean)), slot.ctypes.data, out.ctypes.data)
        return dict(zip(names, out))
    if backend == "gpu":
        name = dt.name
        if name not in _gpu_kernels:
            _gpu_kernels[name] = cp.RawKernel(_SRC.replace("REAL_T", {"float32": "float", "float64": "double"}[name]), "g2_kernel")
        ins = [cp.ascontiguousarray(cp.asarray(F[n], dtype=dt)) for n in order] + [cp.asarray(r_faces, dtype=dt), cp.asarray(r_centers, dtype=dt)]
        out = cp.full((len(names),) + C, np.nan, dtype=dt); T = dt.type
        blk = (32, 4, 2); grd = ((nz + 31)//32, (nphi + 3)//4, (nr + 1)//2)
        _gpu_kernels[name](grd, blk, (*ins, T(dr), T(dphi), T(dz), T(v_ref), np.int32(nr), np.int32(nphi), np.int32(nz), np.int32(g),
                                      np.int32(bool(galilean)), cp.asarray(slot), out))
        cp.cuda.Device().synchronize()
        return dict(zip(names, cp.asnumpy(out)))
    raise ValueError(backend)


def _gpu_ok():
    try: return cp.cuda.runtime.getDeviceCount() > 0
    except Exception: return False


# =============================================================================== NumPy reference
def _struct_tensor():
    T = np.zeros((7, 7, 7))
    for a, b, c in LINES:
        T[a, b, c] = T[b, c, a] = T[c, a, b] = 1.0; T[b, a, c] = T[c, b, a] = T[a, c, b] = -1.0
    return T


def octo_mul(x, y, T=None):
    """Full octonion product of 8-vectors (real part first)."""
    T = _struct_tensor() if T is None else T
    return np.concatenate([[x[0]*y[0] - x[1:] @ y[1:]], x[0]*y[1:] + y[0]*x[1:] + np.einsum("i,j,ijk->k", x[1:], y[1:], T)])


# G2-covariant embedding (see kernel source): u -> e0, e1, e3 ; sigma -> e2 ; b -> (e6, e4, -e5)
def embed(u, b, sig):
    O = np.zeros(u.shape[:-1] + (7,))
    O[..., 0], O[..., 1], O[..., 3] = u[..., 0], u[..., 1], u[..., 2]
    O[..., 2], O[..., 6], O[..., 4], O[..., 5] = sig, b[..., 0], b[..., 1], -b[..., 2]
    return O


def cyl_to_cart(V, nphi, dphi):
    """(r, phi, z) components at active cell centres -> Cartesian (x, y, z) components."""
    p = (np.arange(nphi) + 0.5)*dphi; c, s = np.cos(p)[None, :, None], np.sin(p)[None, :, None]
    return np.stack([V[..., 0]*c - V[..., 1]*s, V[..., 0]*s + V[..., 1]*c, V[..., 2]], -1)


def g2_numpy(F, r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g=2, v_ref=1.0, galilean=True):
    """Independent vectorised float64 reference of the same discrete definitions."""
    T = _struct_tensor(); s = slice(g, g + nr), slice(g, g + nphi), slice(g, g + nz)
    H = {n: np.asarray(_host(F[n]), dtype=np.float64) for n in F}
    rf = np.asarray(_host(r_faces), np.float64); rc = np.asarray(_host(r_centers), np.float64)
    Br, Bp, Bz = H["Br"], H["Bphi"], H["Bz"]
    Brc = 0.5*(Br[g:g + nr] + Br[g + 1:g + nr + 1])[:, g:g + nphi, g:g + nz]
    Bpc = 0.5*(Bp[:, g:g + nphi] + Bp[:, g + 1:g + nphi + 1])[g:g + nr, :, g:g + nz]
    Bzc = 0.5*(Bz[:, :, g:g + nz] + Bz[:, :, g + 1:g + nz + 1])[g:g + nr, g:g + nphi]
    rho = H["rho"][s]; sc = 1.0/(np.sqrt(rho)*v_ref)
    U = np.stack([H["vr"][s]/v_ref, H["vphi"][s]/v_ref, H["vz"][s]/v_ref], -1); Bv = np.stack([Brc*sc, Bpc*sc, Bzc*sc], -1)
    e = np.sum(U**2, -1) + np.sum(Bv**2, -1); sig = np.where(e > 0, 2*np.sum(U*Bv, -1)/np.where(e > 0, e, 1), 0.0)
    O = embed(cyl_to_cart(U, nphi, dphi), cyl_to_cart(Bv, nphi, dphi), sig)
    def grad(axis, h):
        D = np.empty_like(O); n = O.shape[axis]
        t = lambda sl: tuple(sl if a == axis else slice(None) for a in range(3))
        if n < 3: return np.zeros_like(O)
        D[t(slice(1, -1))] = (O[t(slice(2, None))] - O[t(slice(None, -2))])/(2*h)
        D[t(slice(0, 1))] = (-3*O[t(slice(0, 1))] + 4*O[t(slice(1, 2))] - O[t(slice(2, 3))])/(2*h)
        D[t(slice(-1, None))] = (3*O[t(slice(-1, None))] - 4*O[t(slice(-2, -1))] + O[t(slice(-3, -2))])/(2*h)
        return D
    Dr, Dz = grad(0, dr), grad(2, dz)
    Dp = (np.roll(O, -1, 1) - np.roll(O, 1, 1))/(2*dphi) if nphi >= 3 else np.zeros_like(O)
    Dp = Dp / rc[g:g + nr, None, None, None]
    if galilean:
        for D_ in (Dr, Dp, Dz): D_[..., 2] = 0.0
    ph = np.einsum("...i,...j,...k,ijk->...", Dr, Dp, Dz, T)
    Mx = np.stack([Dr, Dp, Dz], -1)                                   # (..., 7, 3)
    vol = np.prod(np.linalg.svd(Mx, compute_uv=False), -1)            # |Dr ^ Dp ^ Dz| from singular values
    scale = np.sqrt(np.sum(Dr**2, -1)*np.sum(Dp**2, -1)*np.sum(Dz**2, -1))
    ok = (scale > 0) & (vol > 1e-6*scale)
    divB = ((rf[g + 1:g + nr + 1, None, None]*Br[g + 1:g + nr + 1] - rf[g:g + nr, None, None]*Br[g:g + nr])[:, g:g + nphi, g:g + nz]/(rc[g:g + nr, None, None]*dr)
            + (Bp[g:g + nr, g + 1:g + nphi + 1, g:g + nz] - Bp[g:g + nr, g:g + nphi, g:g + nz])/(rc[g:g + nr, None, None]*dphi)
            + (Bz[g:g + nr, g:g + nphi, g + 1:g + nz + 1] - Bz[g:g + nr, g:g + nphi, g:g + nz])/dz)
    out = dict(divB=divB, sigma=sig, Phi=ph, vol=vol, calib=np.where(ok, ph/np.where(ok, vol, 1), 0.0))
    out.update(gradient_invariants(Dr, Dp, Dz, nphi, dphi))
    return out


def gradient_invariants(Dr, Dp, Dz, nphi, dphi):
    """Invariants of grad u, grad b and of the Elsasser gradients, from the embedded-state gradients
    (independent vectorised implementation, float64)."""
    p = (np.arange(nphi) + 0.5)*dphi; c, s = np.cos(p)[None, :, None], np.sin(p)[None, :, None]
    def frame(D):
        ux, uy, uz, bx, by, bz = D[..., 0], D[..., 1], D[..., 3], D[..., 6], D[..., 4], -D[..., 5]
        return (np.stack([ux*c + uy*s, -ux*s + uy*c, uz], -1), np.stack([bx*c + by*s, -bx*s + by*c, bz], -1), D[..., 2])
    cols = [frame(D) for D in (Dr, Dp, Dz)]
    A = np.stack([q[0] for q in cols], -1); Bm = np.stack([q[1] for q in cols], -1); gs = np.stack([q[2] for q in cols], -1)
    P = lambda M: -np.trace(M, axis1=-2, axis2=-1)
    Q = lambda M: 0.5*(P(M)**2 - np.einsum("...ab,...ba->...", M, M))
    Rr = lambda M: -np.linalg.det(M)
    cd = np.linalg.det(A + 1j*Bm)
    Ws = np.sum(gs*np.sum(np.cross(A, Bm, axis=-1), axis=-2), -1)
    return dict(P_u=P(A), Q_u=Q(A), R_u=Rr(A), P_b=P(Bm), Q_b=Q(Bm), R_b=Rr(Bm), R_zp=Rr(A + Bm), R_zm=Rr(A - Bm),
                Re_Omega=cd.real, Im_Omega=cd.imag, omega_sigma=Ws)


def build_linear(nr, nphi, nz, Mu, Nb, g=2, r0=0.5, r1=1.5, z0=-0.5, z1=0.5, dtype=np.float64):
    """Linear Cartesian fields u = Mu x, B = Nb x, rho = 1, sampled on the staggered grid.
    Exact gradients: grad u = Mu, grad b = Nb everywhere, so every invariant is a known constant."""
    dr, dphi, dz = (r1 - r0)/nr, 2*math.pi/nphi, (z1 - z0)/nz
    rf, rc = make_grid(nr, dr, g, np.float64, r0)
    pf = (np.arange(nphi + 1 + 2*g) - g)*dphi; pc = pf[:-1] + 0.5*dphi
    zf = z0 + (np.arange(nz + 1 + 2*g) - g)*dz; zc = zf[:-1] + 0.5*dz
    def comps(M, r, p, z):
        R, P_, Z = np.meshgrid(r, p, z, indexing="ij"); X = np.stack([R*np.cos(P_), R*np.sin(P_), Z], -1)
        V = X @ M.T; c, s = np.cos(P_), np.sin(P_)
        return V[..., 0]*c + V[..., 1]*s, -V[..., 0]*s + V[..., 1]*c, V[..., 2]
    vr, vp, vz = comps(Mu, rc, pc, zc)
    Br = comps(Nb, rf, pc, zc)[0]; Bp = comps(Nb, rc, pf, zc)[1]; Bz = comps(Nb, rc, pc, zf)[2]
    F = dict(rho=np.ones_like(vr), vr=vr, vphi=vp, vz=vz, Br=Br, Bphi=Bp, Bz=Bz)
    return {k: np.ascontiguousarray(v.astype(dtype)) for k, v in F.items()}, rf.astype(dtype), rc.astype(dtype), dr, dphi, dz


# =============================================================================== test fields
def build_state(nr, nphi, nz, g=2, r0=0.0, r1=1.0, z0=-0.5, z1=0.5, dtype=np.float64, field="helical",
                a=0.5, eps=0.05, m=1, kz=2*math.pi, flow=0.2):
    """Sample a smooth plasma state on the staggered grid.  B comes from an edge vector potential,
    so the staggered divergence of B is zero to round-off by construction (exact discrete identity).
      field='zpinch'  : B_phi = a r, rho = 1, v = 0                    (axisymmetric reference pinch)
      field='helical' : Z-pinch + B_z = 1 + helical m-mode B perturbation, rho(r), helical flow
    Returns F, r_faces, r_centers, dr, dphi, dz."""
    dr, dphi, dz = (r1 - r0)/nr, 2*math.pi/nphi, (z1 - z0)/nz
    rf, rc = make_grid(nr, dr, g, np.float64, r0)
    pf = (np.arange(nphi + 1 + 2*g) - g)*dphi; pc = pf[:-1] + 0.5*dphi
    zf = z0 + (np.arange(nz + 1 + 2*g) - g)*dz; zc = zf[:-1] + 0.5*dz
    M = lambda r, p, z: np.meshgrid(r, p, z, indexing="ij")
    hel = field == "helical"
    # vector potential A on edges:  A_r on (rc, pf, zf), A_phi on (rf, pc, zf), A_z on (rf, pf, zc)
    def Az(r, p, z):   # B_phi = -dAz/dr ;  helical part gives B_r, B_phi
        out = -0.5*a*r**2
        if hel: out = out + eps*r**m*(1 - r**2)*np.cos(m*p + kz*z)
        return out
    def Aphi(r, p, z):  # B_z = (1/r) d(r A_phi)/dr  -> B_z = 1 for A_phi = r/2
        return 0.5*r if hel else 0*r
    def Ar(r, p, z): return 0*r
    R, P, Z = M(rf, pf, zc); AZ = Az(R, P, Z)                   # (nr+1+2g, nphi+1+2g, nz+2g)
    R, P, Z = M(rf, pc, zf); AP = Aphi(R, P, Z)                 # (nr+1+2g, nphi+2g, nz+1+2g)
    R, P, Z = M(rc, pf, zf); AR = Ar(R, P, Z)                   # (nr+2g, nphi+1+2g, nz+1+2g)
    with np.errstate(divide="ignore", invalid="ignore"):
        Br = (AZ[:, 1:, :] - AZ[:, :-1, :])/(rf[:, None, None]*dphi) - (AP[:, :, 1:] - AP[:, :, :-1])/dz
    ax = np.isclose(rf, 0.0)
    if ax.any():   # axis face: point value of B_r from the analytic limit (zero area, never weighted)
        Br[ax] = 0.0
        if hel and m == 1: Br[ax] = (-eps*np.sin(pc[:, None] + kz*zc[None, :]))[None]*1.0
    Bp = (AR[:, :, 1:] - AR[:, :, :-1])/dz - (AZ[1:, :, :] - AZ[:-1, :, :])/dr
    Bz = ((rf[1:, None, None]*AP[1:] - rf[:-1, None, None]*AP[:-1])/dr - (AR[:, 1:, :] - AR[:, :-1, :])/dphi)/rc[:, None, None]
    R, P, Z = M(rc, pc, zc)
    if hel:
        rho = 1.0 + 0.5*np.exp(-4*R**2)
        vr = flow*eps*np.sin(m*P + kz*Z)*R; vp = flow*R*np.exp(-R**2); vz = flow*0.5*np.cos(m*P + kz*Z)
    else:
        rho = np.ones_like(R); vr = vp = vz = np.zeros_like(R)
    F = {k: np.ascontiguousarray(v.astype(dtype)) for k, v in dict(rho=rho, vr=vr, vphi=vp, vz=vz, Br=Br, Bphi=Bp, Bz=Bz).items()}
    return F, rf.astype(dtype), rc.astype(dtype), dr, dphi, dz


def exact_phi(nr, nphi, nz, g=2, r0=0.0, r1=1.0, z0=-0.5, z1=0.5, **kw):
    """Analytic oracle for Phi, computed in CARTESIAN coordinates: o(x, y, z) from closed-form B and
    flow, then phi(d o/dx, d o/dy, d o/dz) with 6th-order finite differences of the continuous
    functions (h = 1e-3).  The kernel works in the rotated orthonormal frame (r_hat, phi_hat, z_hat);
    agreement therefore also tests frame independence (det of the frame rotation = +1)."""
    T = _struct_tensor(); a = kw.get("a", 0.5); eps = kw.get("eps", 0.05); m = kw.get("m", 1)
    kz = kw.get("kz", 2*math.pi); flow = kw.get("flow", 0.2)
    def o(x, y, z):
        r = np.hypot(x, y); p = np.arctan2(y, x); th = m*p + kz*z
        f = r**m*(1 - r**2); fp = m*r**(m - 1) - (m + 2)*r**(m + 1)
        Br = -eps*m*f/r*np.sin(th); Bp = a*r - eps*fp*np.cos(th); Bz = np.ones_like(r)
        rho = 1.0 + 0.5*np.exp(-4*r**2); s = 1/np.sqrt(rho)
        u = np.stack([flow*eps*np.sin(th)*r, flow*r*np.exp(-r**2), flow*0.5*np.cos(th)], -1)
        b = np.stack([Br*s, Bp*s, Bz*s], -1)
        e = np.sum(u*u, -1) + np.sum(b*b, -1); sig = 2*np.sum(u*b, -1)/e
        c, sn = np.cos(p), np.sin(p)
        cart = lambda V: np.stack([V[..., 0]*c - V[..., 1]*sn, V[..., 0]*sn + V[..., 1]*c, V[..., 2]], -1)
        return embed(cart(u), cart(b), sig)
    dr, dphi, dz = (r1 - r0)/nr, 2*math.pi/nphi, (z1 - z0)/nz
    rc = r0 + (np.arange(nr) + 0.5)*dr; pc = (np.arange(nphi) + 0.5)*dphi; zc = z0 + (np.arange(nz) + 0.5)*dz
    R, P, Z = np.meshgrid(rc, pc, zc, indexing="ij"); X, Y = R*np.cos(P), R*np.sin(P); h = 1e-3
    c6 = [(-3, -1/60), (-2, 3/20), (-1, -3/4), (1, 3/4), (2, -3/20), (3, 1/60)]
    Dx = sum(w*o(X + s*h, Y, Z) for s, w in c6)/h
    Dy = sum(w*o(X, Y + s*h, Z) for s, w in c6)/h
    Dz = sum(w*o(X, Y, Z + s*h) for s, w in c6)/h
    return np.einsum("...i,...j,...k,ijk->...", Dx, Dy, Dz, T)


# =============================================================================== self-test
def self_test(backends=("host",), verbose=True):
    rows, ok_all = [], True
    def rec(name, value, tol, cmp="<="):
        nonlocal ok_all
        ok = (value <= tol) if cmp == "<=" else (value >= tol)
        ok_all &= bool(ok); rows.append((name, value, tol, "PASS" if ok else "FAIL"))
    rng = np.random.default_rng(2026); T = _struct_tensor()
    # ---- A. algebra (independent of the grid)
    wa = wm = wn = wi = 0.0
    for _ in range(500):
        x, y, z = rng.normal(size=(3, 8))
        wa = max(wa, np.abs(octo_mul(octo_mul(x, x, T), y, T) - octo_mul(x, octo_mul(x, y, T), T)).max()/np.linalg.norm(x)**2/np.linalg.norm(y))
        wm = max(wm, np.abs(octo_mul(octo_mul(x, y, T), octo_mul(z, x, T), T) - octo_mul(x, octo_mul(octo_mul(y, z, T), x, T), T)).max()/(np.linalg.norm(x)**2*np.linalg.norm(y)*np.linalg.norm(z)))
        wn = max(wn, abs(np.linalg.norm(octo_mul(x, y, T)) - np.linalg.norm(x)*np.linalg.norm(y))/(np.linalg.norm(x)*np.linalg.norm(y)))
        xi = np.concatenate([[x[0]], -x[1:]])/np.dot(x, x); wi = max(wi, np.abs(octo_mul(x, xi, T) - np.eye(8)[0]).max())
    rec("A1 alternativity (xx)y = x(xy), rel", wa, 1e-13); rec("A2 Moufang (xy)(zx) = x((yz)x), rel", wm, 1e-13)
    rec("A3 norm composition |xy| = |x||y|, rel", wn, 1e-13); rec("A4 inverse x x^-1 = 1", wi, 1e-13)
    ws = wc = wh = 0.0
    for _ in range(500):
        a, b, c = rng.normal(size=(3, 7)); ph = lambda u, v, w: np.einsum("i,j,k,ijk->", u, v, w, T)
        ws = max(ws, abs(ph(a, b, c) + ph(b, a, c)), abs(ph(a, b, c) - ph(b, c, a)), abs(ph(a, a, c)))
        Gm = np.array([[u @ v for v in (a, b, c)] for u in (a, b, c)]); vol = math.sqrt(np.linalg.det(Gm))
        wc = max(wc, abs(ph(a, b, c))/vol)
        im = lambda u: np.concatenate([[0.0], u]); As = octo_mul(octo_mul(im(a), im(b), T), im(c), T) - octo_mul(im(a), octo_mul(im(b), im(c), T), T)
        wh = max(wh, abs(ph(a, b, c)**2 + 0.25*As @ As - vol**2)/vol**2)
    rec("A5 phi alternating (antisymmetric, phi(a,a,c) = 0)", ws, 1e-13)
    rec("A6 calibration bound max |phi(a,b,c)| / |a^b^c| (<= 1)", wc, 1.0 + 1e-12)
    rec("A7 Harvey-Lawson phi^2 + |[a,b,c]|^2/4 = vol^2, rel", wh, 1e-12)
    a, b = rng.normal(size=(2, 7)); c = np.einsum("i,j,ijk->k", a, b, T)
    Gm = np.array([[u @ v for v in (a, b, c)] for u in (a, b, c)])
    rec("A8 associative plane span(a, b, a x b): |phi|/vol = 1", abs(abs(np.einsum("i,j,k,ijk->", a, b, c, T))/math.sqrt(np.linalg.det(Gm)) - 1), 1e-12)
    wr = 0.0
    for _ in range(300):
        q, _r = np.linalg.qr(rng.normal(size=(3, 3))); Q = q*np.sign(np.linalg.det(q))
        trip = [(rng.normal(size=3), rng.normal(size=3), rng.normal()) for _ in range(3)]
        p0 = np.einsum("i,j,k,ijk->", *[embed(u, b, sg) for u, b, sg in trip], T)
        p1 = np.einsum("i,j,k,ijk->", *[embed(Q @ u, Q @ b, sg) for u, b, sg in trip], T)
        wr = max(wr, abs(p1 - p0)/(1 + abs(p0)))
    rec("A9 spatial rotation is a G2 symmetry of the embedding: max change of phi", wr, 1e-13)
    # ---- B/C/D. grid tests on each execution leg
    for be in backends:
        for dt, rt in ((np.float64, 1e-11), (np.float32, 5e-4)):
            tag = f"[{be} {np.dtype(dt).name}]"
            F, rf, rc, dr, dphi, dz = build_state(16, 16, 8, field="zpinch", dtype=dt)
            out = run_g2(F, rf, rc, dr, dphi, dz, 16, 16, 8, 2, 1.0, backend=be); I = (slice(2, 18), slice(2, 18), slice(2, 10))
            rec(f"B1 {tag} Z-pinch max |divB|", float(np.nanmax(np.abs(out['divB'][I]))), 1e3*np.finfo(dt).eps)
            rec(f"B2 {tag} Z-pinch max |Phi|, |vol| (axisymmetric -> 0)", float(max(np.abs(out['Phi'][I]).max(), np.abs(out['vol'][I]).max())), 1e3*np.finfo(dt).eps)
            rec(f"B3 {tag} Z-pinch max |sigma| (no flow -> 0)", float(np.abs(out['sigma'][I]).max()), 0.0)
            rec(f"B4 {tag} ghost cells untouched (NaN)", float(np.isfinite(out['Phi'][0]).sum()), 0.0)
            for r0, lab in ((0.0, "axis"), (0.5, "annulus")):
                F, rf, rc, dr, dphi, dz = build_state(24, 24, 12, r0=r0, r1=r0 + 1.0, dtype=dt)
                out = run_g2(F, rf, rc, dr, dphi, dz, 24, 24, 12, 2, 1.0, backend=be, galilean=False); I = (slice(2, 26), slice(2, 26), slice(2, 14))
                Fd = {k: v.astype(np.float64) for k, v in F.items()}
                ref = g2_numpy(Fd, rf.astype(np.float64), rc.astype(np.float64), dr, dphi, dz, 24, 24, 12, 2, 1.0, galilean=False)
                Bmax = max(float(np.abs(Fd[k]).max()) for k in ("Br", "Bphi", "Bz"))
                rec(f"C1 {tag} {lab} helical max |divB| / (Bmax/dr)", float(np.abs(out['divB'][I]).max())/(Bmax/dr), 1e3*np.finfo(dt).eps)
                for q in ("Phi", "vol", "sigma"):
                    scale = max(float(np.abs(ref[q]).max()), 1e-300)
                    rec(f"C2 {tag} {lab} {q}: kernel vs NumPy reference, rel", float(np.abs(out[q][I] - ref[q]).max())/scale, rt)
                both = (out['calib'][I] != 0) & (ref['calib'] != 0)
                rec(f"C2 {tag} {lab} calib: kernel vs NumPy reference (where defined)", float(np.abs(out['calib'][I] - ref['calib'])[both].max()) if both.any() else 0.0, 1e-8 if dt == np.float64 else 2e-3)
                rec(f"C3 {tag} {lab} max |calib| (<= 1)", float(np.abs(out['calib'][I]).max()), 1.0 + 1e-3*(dt == np.float32) + 1e-9)
                rec(f"C4 {tag} {lab} Harvey-Lawson identity / scale^2, max over cells", float(np.max(out['ident'][I])), 1e-13 if dt == np.float64 else 1e-5)
    # ---- E. gradient-tensor invariants: kernel vs reference, built-in identities, analytic convergence
    for be in backends:
        for dt, rt in ((np.float64, 1e-10), (np.float32, 2e-3)):
            tag = f"[{be} {np.dtype(dt).name}]"
            for r0, lab in ((0.0, "axis"), (0.5, "annulus")):
                F, rf, rc, dr, dphi, dz = build_state(24, 24, 12, r0=r0, r1=r0 + 1.0, dtype=dt)
                out = run_g2(F, rf, rc, dr, dphi, dz, 24, 24, 12, 2, 1.0, backend=be, galilean=False); I = (slice(2, 26), slice(2, 26), slice(2, 14))
                ref = g2_numpy({k: v.astype(np.float64) for k, v in F.items()}, rf.astype(np.float64), rc.astype(np.float64), dr, dphi, dz, 24, 24, 12, 2, 1.0, galilean=False)
                worst = max(float(np.abs(out[q][I] - ref[q]).max())/max(float(np.abs(ref[q]).max()), 1e-300) for q in INVARIANTS if q != "decomp")
                rec(f"E1 {tag} {lab} 11 invariants: kernel vs NumPy reference, worst rel", worst, rt)
                rec(f"E2 {tag} {lab} Phi = Re Omega - omega_sigma (SU(3) split), max / scale", float(np.max(out['decomp'][I])), 1e-13 if dt == np.float64 else 1e-5)
                sc = max(float(np.abs(out[q][I]).max()) for q in ("R_u", "R_b", "R_zp", "R_zm", "Re_Omega", "Im_Omega"))
                e3 = max(float(np.abs(out['Re_Omega'][I] - (0.5*(out['R_zp'][I] + out['R_zm'][I]) - 2*out['R_u'][I])).max()),
                         float(np.abs(out['Im_Omega'][I] - (-0.5*(out['R_zp'][I] - out['R_zm'][I]) + 2*out['R_b'][I])).max()))/sc
                rec(f"E3 {tag} {lab} Elsasser form of Re/Im Omega, max rel", e3, 1e-12 if dt == np.float64 else 1e-4)
    Mu = np.array([[0.3, -0.7, 0.2], [0.5, 0.1, -0.4], [0.2, 0.6, -0.4]]); Nb = np.array([[0.1, 0.4, -0.3], [-0.6, 0.2, 0.5], [0.3, -0.2, -0.3]])
    exact = dict(P_u=-np.trace(Mu), Q_u=0.5*(np.trace(Mu)**2 - np.trace(Mu @ Mu)), R_u=-np.linalg.det(Mu),
                 P_b=-np.trace(Nb), Q_b=0.5*(np.trace(Nb)**2 - np.trace(Nb @ Nb)), R_b=-np.linalg.det(Nb),
                 R_zp=-np.linalg.det(Mu + Nb), R_zm=-np.linalg.det(Mu - Nb),
                 Re_Omega=np.linalg.det(Mu + 1j*Nb).real, Im_Omega=np.linalg.det(Mu + 1j*Nb).imag)
    errsE = []
    for n in (16, 32, 64):
        F, rf, rc, dr, dphi, dz = build_linear(n, n, 8, Mu, Nb)
        out = run_g2(F, rf, rc, dr, dphi, dz, n, n, 8, 2, 1.0, backend=backends[0]); I = (slice(2, 2 + n), slice(2, 2 + n), slice(2, 10))
        errsE.append(max(float(np.abs(out[q][I] - v).max()) for q, v in exact.items()))
    ordE = math.log(errsE[-2]/errsE[-1])/math.log(2)
    rec("E4 linear fields: all invariants -> exact constants, last observed order", ordE, 1.8, cmp=">=")
    # ---- F. invariance, scaling, negative controls, output selection
    for be in backends:
        n = 24; I = (slice(2, 2 + n), slice(2, 2 + n), slice(2, 2 + n//2))
        F, rf, rc, dr, dphi, dz = build_state(n, n, n//2, r0=0.5, r1=1.5)
        base = run_g2(F, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=be)            # galilean (default)
        rel = lambda X, Y: float(np.abs(X[I] - Y[I]).max())/max(float(np.abs(Y[I]).max()), 1e-300)
        tag = f"[{be} float64]"
        # F1 v_ref scaling: P ~ 1/v, Q ~ 1/v^2, R / Omega / Phi ~ 1/v^3, calib unchanged
        sv = 3.0; o3 = run_g2(F, rf, rc, dr, dphi, dz, n, n, n//2, 2, sv, backend=be)
        pw = dict(P_u=1, P_b=1, Q_u=2, Q_b=2, R_u=3, R_b=3, R_zp=3, R_zm=3, Re_Omega=3, Im_Omega=3, Phi=3, vol=3)
        # normalise an order-p invariant by gnorm^p (gnorm = gradient magnitude): P_b = -div b nearly cancels,
        # so normalising by its own maximum would only measure round-off amplification.  (Metric revised after
        # the first run failed at 1.2e-12 on P_b for exactly this reason; disclosed in the change log.)
        gn = math.sqrt(max(float(np.abs(base['Q_u'][I]).max()), float(np.abs(base['Q_b'][I]).max())))
        w1 = max(float(np.abs(o3[q][I]*sv**p - base[q][I]).max())/gn**p for q, p in pw.items() if q not in ("Phi", "vol"))
        w1 = max(w1, rel(o3['Phi']*sv**3, base['Phi']), rel(o3['vol']*sv**3, base['vol']), float(np.abs(o3['calib'][I] - base['calib'][I]).max()))
        rec(f"F1 {tag} exact v_ref scaling of all invariants (galilean mode)", w1, 1e-12)
        fu = run_g2(F, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=be, galilean=False)
        fs = run_g2(F, rf, rc, dr, dphi, dz, n, n, n//2, 2, sv, backend=be, galilean=False)
        rec(f"F1n {tag} negative control: full mode Phi is NOT homogeneous in v_ref (rel deviation)", rel(fs['Phi']*sv**3, fu['Phi']), 1e-3, cmp=">=")
        # F2 Galilean boost by a constant Cartesian velocity U
        U = np.array([0.3, -0.2, 0.25]); pc = (np.arange(n + 4) - 2 + 0.5)*dphi
        Fb = dict(F); c_, s_ = np.cos(pc)[None, :, None], np.sin(pc)[None, :, None]
        Fb["vr"] = F["vr"] + (U[0]*c_ + U[1]*s_); Fb["vphi"] = F["vphi"] + (-U[0]*s_ + U[1]*c_); Fb["vz"] = F["vz"] + U[2]
        ob = run_g2(Fb, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=be)
        w2 = max(rel(ob[q], base[q]) for q in QUANTITIES if q not in ("sigma", "divB", "ident", "decomp", "calib"))
        rec(f"F2 {tag} constant boost: every gradient output unchanged (galilean mode)", w2, 1e-11)
        obf = run_g2(Fb, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=be, galilean=False)
        rec(f"F2n {tag} negative control: full-mode Phi changes under the boost (rel)", rel(obf['Phi'], fu['Phi']), 1e-3, cmp=">=")
        # F3 density scaling: (rho, B) -> (lam rho, sqrt(lam) B) leaves b = B/sqrt(rho) and every output unchanged
        for lam in (1e-8, 1e8):
            Fl = dict(F); Fl["rho"] = F["rho"]*lam
            for k in ("Br", "Bphi", "Bz"): Fl[k] = F[k]*math.sqrt(lam)
            ol = run_g2(Fl, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=be)
            w3 = max(rel(ol[q], base[q]) for q in QUANTITIES if q not in ("divB", "ident", "decomp", "calib"))
            rec(f"F3 {tag} extreme density rho x {lam:.0e}: outputs unchanged, rel", w3, 1e-11)
        # F4 output selection returns identical values and allocates only what is asked for
        sel = run_g2(F, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=be, outputs=("Re_Omega", "R_u"))
        rec(f"F4 {tag} selected outputs identical to the full run (2 of {len(QUANTITIES)} allocated)",
            max(float(np.abs(sel[q][I] - base[q][I]).max()) for q in sel) + (0.0 if len(sel) == 2 else 1.0), 0.0)
    # F5 negative control on the algebra: the v55 Fano orientation must be rejected by the same checks as A1-A3
    T55 = np.zeros((7, 7, 7))
    for a_, b_, c_ in ((0, 1, 2), (0, 3, 4), (0, 5, 6), (1, 3, 5), (1, 4, 6), (2, 3, 6), (2, 4, 5)):
        T55[a_, b_, c_] = T55[b_, c_, a_] = T55[c_, a_, b_] = 1.0; T55[b_, a_, c_] = T55[c_, b_, a_] = T55[a_, c_, b_] = -1.0
    w5 = 0.0
    for _ in range(100):
        x, y = rng.normal(size=(2, 8))
        w5 = max(w5, np.abs(octo_mul(octo_mul(x, x, T55), y, T55) - octo_mul(x, octo_mul(x, y, T55), T55)).max()/np.linalg.norm(x)**2/np.linalg.norm(y))
    rec("F5 negative control: v55 table detected as non-octonion (alternativity violation)", w5, 1e-2, cmp=">=")
    # ---- D. convergence of Phi against the analytic oracle (host, FP64, annulus interior)
    errs, hs = [], []
    for n in (16, 32, 64):
        F, rf, rc, dr, dphi, dz = build_state(n, n, n//2, r0=0.5, r1=1.5)
        out = run_g2(F, rf, rc, dr, dphi, dz, n, n, n//2, 2, 1.0, backend=backends[0], galilean=False); I = (slice(2, 2 + n), slice(2, 2 + n), slice(2, 2 + n//2))
        ex = exact_phi(n, n, n//2, r0=0.5, r1=1.5)
        q = slice(n//8, n - n//8)
        errs.append(float(np.abs(out["Phi"][I][q, :, q.start//2:n//2 - q.start//2] - ex[q, :, q.start//2:n//2 - q.start//2]).max())); hs.append(1.0/n)
    orders = [math.log(errs[i]/errs[i + 1])/math.log(2) for i in range(len(errs) - 1)]
    rec("D1 Phi convergence vs analytic oracle: last observed order", orders[-1], 1.8, cmp=">=")
    if verbose:
        print(f"{VERSION}   kernel source SHA-256 {KERNEL_SHA256}")
        w = max(len(r[0]) for r in rows)
        for n, v, t, s in rows: print(f"  {n:<{w}}  {v:10.3e}  (limit {t:.1e})  {s}")
        print(f"  Phi errors {['%.3e' % e for e in errs]}  orders {['%.2f' % o for o in orders]}")
        print(f"  invariant errors (linear fields) {['%.3e' % e for e in errsE]}")
        print(f"SELF-TEST: {'PASS' if ok_all else 'FAIL'}  ({sum(r[3] == 'PASS' for r in rows)}/{len(rows)})")
    return ok_all, rows


if __name__ == "__main__":
    legs = ["host"] + (["gpu"] if (cp is not None and _gpu_ok()) else [])
    if len(legs) == 1: print("GPU leg not available here (no CuPy/CUDA device): host leg only.")
    ok, _ = self_test(tuple(legs))
    sys.exit(0 if ok else 1)
