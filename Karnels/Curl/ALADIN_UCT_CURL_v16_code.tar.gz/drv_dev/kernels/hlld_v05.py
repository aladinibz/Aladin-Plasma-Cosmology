# -*- coding: utf-8 -*-
"""
hlld_v05.py -- ALADIN HLLD v05: second-order HLLD fluxes on the native cylindrical grid (r, phi, z faces).

v05.2 (2026-11-20, Driver v4.0 KW-00 probe): GPU == CPU bit for bit on blended faces too.  The v04 blend weight used the
math-library log10(), whose last-bit rounding differs between CUDA and glibc; in a Z-pinch only the phi sweep has B_n != 0
and reaches it, so KW-00 found HLLD-phi fluxes differing by a few ulp on blended faces (flags identical), and nothing else.
v05.2 replaces it by log10p6(), built from IEEE basic operations only (|error| <~ 1e-15 against log10, a smoothing ramp),
builds the kernel input W (cell-centred B) inside the IEEE module on the GPU (CuPy elementwise arithmetic flushes FP32
subnormals: HLLD-05 run 1, G7), and compiles the GPU module with NVRTC directly with -fmad=false -ftz=false -prec-div=true -prec-sqrt=true (PTX checked
free of .ftz), so FP32 on the GPU is IEEE as well.  Nothing else changes.

v05: REFUSAL.  Healing is for numerical difficulty on VALID data; invalid data must never be healed into a plausible flux.
v04 returned finite fluxes for cells with rho < 0 or p < 0 (flagged only as an ordinary first-order fallback).  v05:
    a face whose own two cells (or whose Riemann input states) are inadmissible -- rho <= 0, p < 0, or any non-finite
    value -- gets a quiet-NaN flux in every component and flag bit 32 (riemann() code 4).  p = 0 (cold plasma) is
    admissible.  Refusal is always on (not affected by the heal switches).  Faces not touching an invalid cell are unchanged.
    Outer stencil cells (I-2, I+1) that are invalid only remove the slope: the face is reconstructed at first order from its
    two valid cells and flagged 1 (legitimate healing).

v04 notes:

v04: the v03 hard HLLD -> HLL switch is replaced by a SMOOTH BLEND  F = w F_HLLD + (1 - w) F_HLL  (HLLD-02 H19 measured a
median jump of 0.37 |F| at the switch).  w = w_m * w_A, both C1 smoothsteps:
    ordering margin  m = min_a rho_a* (S_a - S_M)^2 / B_n^2 - 1:   w_m = 0 for m <= 1e-6, 1 for m >= 1e-5 (smoothstep in log10 m)
    amplification    A = max(|B_t,a*| / |B|_max, |v_t,a* - v_t,a| / c_max):   w_A = 1 for A <= 16, 0 for A >= 32 (smoothstep)
The HLLD flux is only evaluated where w > 0, i.e. on a valid fan with bounded star states, so the blended flux is continuous
in the states and bounded.  HEALING SWITCHES (for tests; default all on): bit 1 first-order reconstruction fallback, bit 2
numerical HLL guards, bit 4 the blend.  Codes from riemann(): 0 HLLD, 1 HLL numerical guard, 2 HLL (w = 0), 3 blended.
Grid flags (bits): 1 first-order face, 2 numerical HLL, 4 blend w = 0 (HLL), 8 blended 0 < w < 1, 16 first order requested.
FIRST-ORDER REQUEST (v04): fluxes(..., first_order_cells=mask) reconstructs every face touching a flagged cell at first order,
so a caller can recover positivity a posteriori (detect bad cells after a provisional update, redo their faces).

v03 notes:

v03 (after the HLLD-01 G1 investigation): WAVE-ORDERING / AMPLIFICATION GUARD.  HLLD is valid only when
S_L <= S_L* <= S_M <= S_R* <= S_R.  With the outer speed estimate min(u_L - c_fL, u_R - c_fR) the Alfven speed of a
star state can fall outside the fan (den = rho*(S - S_M)^2 - B_n^2 < 0; ~0.8 % of random Riemann problems), and close
to that edge the star states and the HLLD flux itself grow like 1/den (verified in 80-bit arithmetic).  v03 falls back
to HLL on such a face (the author's layered-fallback design) when
    (a) the ordering is violated:     rho_a* (S_a - S_M)^2 <= (1 + 1e-6) B_n^2   (a = L, R), or
    (b) the star state is amplified:  |B_t,a*| > K |B|_max   or   |v_t,a* - v_t,a| > K c_max,   K = 32,
and reports it (flag bit 4 on grid faces, code 2 from riemann()).  The outer speeds are those of Miyoshi & Kusano eq. (67),
S_L = min(u_L, u_R) - max(c_fL, c_fR), S_R = max(u_L, u_R) + max(c_fL, c_fR): with v02's narrower Davis-type estimate the
ordering failed in 23-43 % of strong-field states (B_n ~ 10-100), with eq. (67) in 0.1-0.4 %.  Everything else is v02 unchanged.

v02 notes:

Successor of hlld_cylindrical_kernels.py by Mihai Alexandru Bucurenciu (HLLD of Miyoshi & Kusano 2005 in the Athena++
form, one solver in three right-handed local frames, layered HLL fallbacks, Z-pinch equilibrium subtraction).
v02 is a rewrite (new numbered file) to the certified-kernel contract (UCT_CURL v1.3, UCT-EMF v02, EGLM v02):

  * limited linear reconstruction inside the kernel (MC or minmod, as UCT-EMF) -> second order; first-order fallback per
    face if a reconstructed density or pressure is not positive
  * well-balancing generalised (the author's idea): optional equilibrium W_eq (any profile, cell arrays) -- the
    reconstruction acts on W - W_eq and the face state is W_eq,face + reconstructed deviation, W_eq,face given by the
    caller (exact) or the mean of the two neighbouring cells.  An equilibrium state gives identical L and R states,
    hence zero upwind dissipation.
  * face-normal B = the constrained-transport face value (single-valued), not an average of cell centres
  * no HLL fallback for small B_n (HLLD degenerates correctly); scale-free thresholds; exact fast magnetosonic speed
  * fluxes written in GLOBAL order (rho, m_r, m_phi, m_z, E, B_r, B_phi, B_z) for every direction
  * one CUDA/C++ source for GPU (NVRTC) and CPU (g++/OpenMP), FP64 / FP32

GRID CONTRACT (as UCT-EMF v02; z fastest)
    cells rho, vr, vphi, vz, p (nr+2g, nphi+2g, nz+2g), ghosts filled by the caller (g >= 2)
    faces Br (nr+1+2g, nphi+2g, nz+2g), Bphi (nr+2g, nphi+1+2g, nz+2g), Bz (nr+2g, nphi+2g, nz+1+2g)
    flux arrays: F_r (8, nr+1, nphi, nz), F_phi (8, nr, nphi+1, nz), F_z (8, nr, nphi, nz+1)  (interior faces, no ghosts)
    The flux is the planar HLLD flux through the face per unit area (geometry: areas, volumes, source terms belong
    to the residual / assembly kernel).  E = p/(gamma-1) + rho v^2/2 + B^2/2  (mu0 = 1).
"""
import os, hashlib, ctypes, subprocess, tempfile
import numpy as np

VERSION = "hlld v05.2 2026-11-20"

SRC = r"""
#ifdef HLLD_GPU
  #define DEV __device__ __forceinline__
#else
  #include <cmath>
  using namespace std;
  #define DEV static inline
#endif
typedef REAL R;

struct Grid { int nr, nphi, nz, g; long nc; R gamma; int limiter, use_eq, use_eqf, heal; const int* mask; };
#define S_C(a,b,c)   (((long)(a)*(G.nphi+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BR(a,b,c)  (((long)(a)*(G.nphi+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BP(a,b,c)  (((long)(a)*(G.nphi+1+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BZ(a,b,c)  (((long)(a)*(G.nphi+2*G.g) + (b))*(G.nz+1+2*G.g) + (c))

DEV R lim(R dl, R dr_, int kind) {
    if (dl*dr_ <= R(0)) return R(0);
    R s = dl > R(0) ? R(1) : R(-1), a = fabs(dl), b = fabs(dr_);
    if (kind == 0) return s*fmin(a, b);
    return s*fmin(fmin(R(2)*a, R(2)*b), R(0.5)*(a + b));
}

// ---------------- HLLD (Miyoshi & Kusano 2005), local frame: n, t1, t2 ----------------
struct St { R d, vn, vt1, vt2, p, bt1, bt2; };   // primitive state (B_n separate)

DEV R cfast(const St& w, R bn, R gam) {
    R gp = gam*w.p, b2 = bn*bn + w.bt1*w.bt1 + w.bt2*w.bt2, s = gp + b2;
    R disc = fmax(s*s - R(4)*gp*bn*bn, R(0));
    return sqrt(fmax(R(0.5)*(s + sqrt(disc))/w.d, R(0)));
}

DEV void cons_flux(const St& w, R bn, R gam, R* u, R* f) {
    // u, f: d, mn, mt1, mt2, e, bt1, bt2
    R pb = R(0.5)*(bn*bn + w.bt1*w.bt1 + w.bt2*w.bt2), pt = w.p + pb;
    u[0] = w.d; u[1] = w.d*w.vn; u[2] = w.d*w.vt1; u[3] = w.d*w.vt2;
    u[4] = w.p/(gam - R(1)) + R(0.5)*w.d*(w.vn*w.vn + w.vt1*w.vt1 + w.vt2*w.vt2) + pb;
    u[5] = w.bt1; u[6] = w.bt2;
    R vb = w.vn*bn + w.vt1*w.bt1 + w.vt2*w.bt2;
    f[0] = u[1]; f[1] = u[1]*w.vn + pt - bn*bn; f[2] = u[2]*w.vn - bn*w.bt1; f[3] = u[3]*w.vn - bn*w.bt2;
    f[4] = (u[4] + pt)*w.vn - bn*vb; f[5] = w.bt1*w.vn - bn*w.vt1; f[6] = w.bt2*w.vn - bn*w.vt2;
}

DEV void hll(const R* ul, const R* ur, const R* fl, const R* fr, R sl, R sr, R* F) {
    if (sl >= R(0)) { for (int q = 0; q < 7; ++q) F[q] = fl[q]; return; }
    if (sr <= R(0)) { for (int q = 0; q < 7; ++q) F[q] = fr[q]; return; }
    R inv = R(1)/(sr - sl);
    for (int q = 0; q < 7; ++q) F[q] = (sr*fl[q] - sl*fr[q] + sl*sr*(ur[q] - ul[q]))*inv;
}

DEV R smooth01(R t) { t = fmin(fmax(t, R(0)), R(1)); return t*t*(R(3) - R(2)*t); }
// v05.2: log10(m) + 6 = log10(y), y = m * 1e6 in [1, 10] on the blend ramp (1e-6 < m < 1e-5).  Computed with IEEE basic
// operations only (no math-library call, whose rounding differs between CUDA and glibc): q = y^(1/4) by two correctly
// rounded square roots, s = (q - 1)/(q + 1) in [0, 0.28], ln y = 8 atanh(s) by a fixed 17-term series (truncation < 1e-18),
// log10 y = ln y / ln 10.  Same operations in the same order on both backends -> identical bits; |error| <~ 1e-15.
DEV R log10p6(R m) {
    R y = m*R(1e6); y = fmin(fmax(y, R(1)), R(10));
    R q = sqrt(sqrt(y)), s = (q - R(1))/(q + R(1)), s2 = s*s, acc = R(0);
    for (int k = 17; k >= 1; --k) acc = R(1)/R(2*k + 1) + s2*acc;
    return R(8)*s*(R(1) + s2*acc)/R(2.302585092994045684017991454684364208);
}
// returns 0 = HLLD, 1 = HLL (numerical guard), 2 = HLL (blend weight 0), 3 = blended HLLD/HLL (v04)
// header-free IEEE helpers (NVRTC has no standard headers): x - x is 0 for finite x and NaN for +-Inf / NaN
DEV int fin(R x) { R y = x - x; return y == y; }
DEV R qnan() { R z = R(0); return z / z; }
DEV int admissible(const St& w) {
    return (w.d > R(0)) && (w.p >= R(0)) && fin(w.d) && fin(w.p) && fin(w.vn) && fin(w.vt1) && fin(w.vt2) && fin(w.bt1) && fin(w.bt2);
}
DEV int hlld(const St& wl, const St& wr, R bn, R gam, R* F, int heal) {
    if (!admissible(wl) || !admissible(wr) || !fin(bn)) { for (int q = 0; q < 7; ++q) F[q] = qnan(); return 4; }   // v05 refusal
    R ul[7], ur[7], fl[7], fr[7];
    cons_flux(wl, bn, gam, ul, fl); cons_flux(wr, bn, gam, ur, fr);
    R cl = cfast(wl, bn, gam), cr = cfast(wr, bn, gam);
    // v03: outer speeds of Miyoshi & Kusano (2005) eq. (67): S_L = min(u_L, u_R) - max(c_fL, c_fR) (v02 used the
    // narrower min(u_L - c_fL, u_R - c_fR), which leaves the Alfven waves outside the fan in up to 43 % of strong-field states)
    R cmx = fmax(cl, cr);
    R sl = fmin(wl.vn, wr.vn) - cmx, sr = fmax(wl.vn, wr.vn) + cmx;
    if (sl >= R(0)) { for (int q = 0; q < 7; ++q) F[q] = fl[q]; return 0; }
    if (sr <= R(0)) { for (int q = 0; q < 7; ++q) F[q] = fr[q]; return 0; }
    R bsq = bn*bn;
    R ptl = wl.p + R(0.5)*(bsq + wl.bt1*wl.bt1 + wl.bt2*wl.bt2), ptr = wr.p + R(0.5)*(bsq + wr.bt1*wr.bt1 + wr.bt2*wr.bt2);
    R sdl = sl - wl.vn, sdr = sr - wr.vn;
    R den = sdr*wr.d - sdl*wl.d;                                  // > 0 whenever sl < vn_l, sr > vn_r
    R scale = fabs(sdr*wr.d) + fabs(sdl*wl.d);
    if ((heal & 2) && !(fabs(den) > R(1e-12)*scale)) { hll(ul, ur, fl, fr, sl, sr, F); return 1; }
    R sm = (sdr*wr.d*wr.vn - sdl*wl.d*wl.vn - ptr + ptl)/den;
    R sml = sl - sm, smr = sr - sm;
    if ((heal & 2) && (!(fabs(sml) > R(1e-12)*fabs(sdl)) || !(fabs(smr) > R(1e-12)*fabs(sdr)))) { hll(ul, ur, fl, fr, sl, sr, F); return 1; }
    R dsl = wl.d*sdl/sml, dsr = wr.d*sdr/smr;
    if ((heal & 2) && (!(dsl > R(0)) || !(dsr > R(0)))) { hll(ul, ur, fl, fr, sl, sr, F); return 1; }
    // v04 blend weight, part 1: wave-ordering margin m = min rho*(S - S_M)^2 / B_n^2 - 1
    R wgt = R(1);
    if ((heal & 4) && bsq > R(0)) {
        R m = fmin(dsl*sml*sml, dsr*smr*smr)/bsq - R(1);
        if (!(m > R(1e-6))) { hll(ul, ur, fl, fr, sl, sr, F); return 2; }
        if (m < R(1e-5)) wgt = smooth01(log10p6(m));               // log10 m from -6 to -5 (v05.2: deterministic log10)
    }
    R pts = R(0.5)*((ptl + wl.d*sdl*(sm - wl.vn)) + (ptr + wr.d*sdr*(sm - wr.vn)));
    // single-star states (L*, R*)
    R usl[7], usr[7];
    {
        R dnm = wl.d*sdl*sml - bsq, ref = fabs(wl.d*sdl*sml) + bsq;
        R vt1, vt2, bt1, bt2;
        if (fabs(dnm) <= R(1e-12)*ref) { vt1 = wl.vt1; vt2 = wl.vt2; bt1 = wl.bt1; bt2 = wl.bt2; }
        else { R t = bn*(sdl - sml)/dnm; vt1 = wl.vt1 - wl.bt1*t; vt2 = wl.vt2 - wl.bt2*t;
               t = (wl.d*sdl*sdl - bsq)/dnm; bt1 = wl.bt1*t; bt2 = wl.bt2*t; }
        R vbs = sm*bn + vt1*bt1 + vt2*bt2, vb = wl.vn*bn + wl.vt1*wl.bt1 + wl.vt2*wl.bt2;
        usl[0] = dsl; usl[1] = dsl*sm; usl[2] = dsl*vt1; usl[3] = dsl*vt2;
        usl[4] = (sdl*ul[4] - ptl*wl.vn + pts*sm + bn*(vb - vbs))/sml; usl[5] = bt1; usl[6] = bt2;
    }
    {
        R dnm = wr.d*sdr*smr - bsq, ref = fabs(wr.d*sdr*smr) + bsq;
        R vt1, vt2, bt1, bt2;
        if (fabs(dnm) <= R(1e-12)*ref) { vt1 = wr.vt1; vt2 = wr.vt2; bt1 = wr.bt1; bt2 = wr.bt2; }
        else { R t = bn*(sdr - smr)/dnm; vt1 = wr.vt1 - wr.bt1*t; vt2 = wr.vt2 - wr.bt2*t;
               t = (wr.d*sdr*sdr - bsq)/dnm; bt1 = wr.bt1*t; bt2 = wr.bt2*t; }
        R vbs = sm*bn + vt1*bt1 + vt2*bt2, vb = wr.vn*bn + wr.vt1*wr.bt1 + wr.vt2*wr.bt2;
        usr[0] = dsr; usr[1] = dsr*sm; usr[2] = dsr*vt1; usr[3] = dsr*vt2;
        usr[4] = (sdr*ur[4] - ptr*wr.vn + pts*sm + bn*(vb - vbs))/smr; usr[5] = bt1; usr[6] = bt2;
    }
    if (heal & 4) {   // v04 blend weight, part 2: amplification of the single-star states
        const R A0 = R(16), A1 = R(32);
        R bmax = sqrt(fmax(bsq + wl.bt1*wl.bt1 + wl.bt2*wl.bt2, bsq + wr.bt1*wr.bt1 + wr.bt2*wr.bt2));
        R cmax = fmax(cl, cr);
        R btl = sqrt(usl[5]*usl[5] + usl[6]*usl[6]), btr = sqrt(usr[5]*usr[5] + usr[6]*usr[6]);
        R dvl = sqrt((usl[2]/dsl - wl.vt1)*(usl[2]/dsl - wl.vt1) + (usl[3]/dsl - wl.vt2)*(usl[3]/dsl - wl.vt2));
        R dvr = sqrt((usr[2]/dsr - wr.vt1)*(usr[2]/dsr - wr.vt1) + (usr[3]/dsr - wr.vt2)*(usr[3]/dsr - wr.vt2));
        R A = fmax(fmax(btl/bmax, btr/bmax), fmax(dvl/cmax, dvr/cmax));
        if (!(A < A1)) { hll(ul, ur, fl, fr, sl, sr, F); return 2; }
        if (A > A0) wgt *= R(1) - smooth01((A - A0)/(A1 - A0));
        if (!(wgt > R(0))) { hll(ul, ur, fl, fr, sl, sr, F); return 2; }
    }
    R sqdl = sqrt(dsl), sqdr = sqrt(dsr);
    R s1 = sm - fabs(bn)/sqdl, s3 = sm + fabs(bn)/sqdr;
    // double-star states (L**, R**)
    R udl[7], udr[7];
    for (int q = 0; q < 7; ++q) { udl[q] = usl[q]; udr[q] = usr[q]; }
    if (R(0.5)*bsq > R(1e-12)*pts) {
        R isum = R(1)/(sqdl + sqdr), sg = bn > R(0) ? R(1) : R(-1);
        R vt1l = usl[2]/dsl, vt2l = usl[3]/dsl, vt1r = usr[2]/dsr, vt2r = usr[3]/dsr;
        R vt1 = isum*(sqdl*vt1l + sqdr*vt1r + sg*(usr[5] - usl[5]));
        R vt2 = isum*(sqdl*vt2l + sqdr*vt2r + sg*(usr[6] - usl[6]));
        R bt1 = isum*(sqdl*usr[5] + sqdr*usl[5] + sg*sqdl*sqdr*(vt1r - vt1l));
        R bt2 = isum*(sqdl*usr[6] + sqdr*usl[6] + sg*sqdl*sqdr*(vt2r - vt2l));
        R vbss = sm*bn + vt1*bt1 + vt2*bt2;
        R vbsl = sm*bn + vt1l*usl[5] + vt2l*usl[6], vbsr = sm*bn + vt1r*usr[5] + vt2r*usr[6];
        udl[2] = dsl*vt1; udl[3] = dsl*vt2; udl[5] = bt1; udl[6] = bt2; udl[4] = usl[4] - sqdl*sg*(vbsl - vbss);
        udr[2] = dsr*vt1; udr[3] = dsr*vt2; udr[5] = bt1; udr[6] = bt2; udr[4] = usr[4] + sqdr*sg*(vbsr - vbss);
    }
    if (s1 >= R(0)) { for (int q = 0; q < 7; ++q) F[q] = fl[q] + sl*(usl[q] - ul[q]); }
    else if (sm >= R(0)) { for (int q = 0; q < 7; ++q) F[q] = fl[q] + sl*(usl[q] - ul[q]) + s1*(udl[q] - usl[q]); }
    else if (s3 > R(0)) { for (int q = 0; q < 7; ++q) F[q] = fr[q] + sr*(usr[q] - ur[q]) + s3*(udr[q] - usr[q]); }
    else { for (int q = 0; q < 7; ++q) F[q] = fr[q] + sr*(usr[q] - ur[q]); }
    if (wgt < R(1)) {
        R Fh[7]; hll(ul, ur, fl, fr, sl, sr, Fh);
        for (int q = 0; q < 7; ++q) F[q] = wgt*F[q] + (R(1) - wgt)*Fh[q];
        return 3;
    }
    return 0;
}

// ---------------- face states ----------------
// W: 8 cell variables (rho, vr, vphi, vz, p, Br_c, Bphi_c, Bz_c), block layout W[v*nc + cell]
// dir 0 = r, 1 = phi, 2 = z.  Face index (I, J, K) with the face between cells (I-1) and I along dir.
DEV void face_states(const R* W, const R* Weq, const R* Weqf, long fidx, const Grid& G, int dir, int I, int J, int K,
                     R* wl, R* wr, int* fo) {
    int di = dir == 0, dj = dir == 1, dk = dir == 2;
    long cm2 = S_C(I-2*di, J-2*dj, K-2*dk), cm1 = S_C(I-di, J-dj, K-dk), c0 = S_C(I, J, K), cp1 = S_C(I+di, J+dj, K+dk);
    R tl[8], tr[8]; int bad = 0;
    // v05: admissibility of the face's own cells (refusal) and of the outer stencil cells (slope removal)
    int own_ok = 1, outer_ok = 1;
    for (int v = 0; v < 8; ++v) {
        const R* q = W + (long)v*G.nc;
        if (!fin(q[cm1]) || !fin(q[c0])) own_ok = 0;
        if (!fin(q[cm2]) || !fin(q[cp1])) outer_ok = 0;
    }
    if (!(W[cm1] > R(0)) || !(W[c0] > R(0)) || !(W[4*G.nc + cm1] >= R(0)) || !(W[4*G.nc + c0] >= R(0))) own_ok = 0;
    if (!(W[cm2] > R(0)) || !(W[cp1] > R(0)) || !(W[4*G.nc + cm2] >= R(0)) || !(W[4*G.nc + cp1] >= R(0))) outer_ok = 0;
    if (!own_ok) { *fo = 3; return; }
    for (int v = 0; v < 8; ++v) {
        const R* q = W + (long)v*G.nc; R a = q[cm2], b = q[cm1], c = q[c0], d = q[cp1], ef = R(0);
        if (G.use_eq) {
            const R* e = Weq + (long)v*G.nc; a -= e[cm2]; b -= e[cm1]; c -= e[c0]; d -= e[cp1];
            ef = G.use_eqf ? Weqf[fidx*8 + v] : R(0.5)*(e[cm1] + e[c0]);
        }
        tl[v] = ef + b + R(0.5)*lim(b - a, c - b, G.limiter);
        tr[v] = ef + c - R(0.5)*lim(c - b, d - c, G.limiter);
    }
    if ((G.heal & 1) && (!(tl[0] > R(0)) || !(tr[0] > R(0)) || !(tl[4] > R(0)) || !(tr[4] > R(0)))) bad = 1;
    if (G.mask && (G.mask[cm1] || G.mask[c0])) bad = 2;          // v04: first order requested by the caller (a-posteriori recovery)
    if (!outer_ok && !bad) bad = 1;                                // v05: invalid outer stencil cell -> first order from the two own cells
    if (bad) {                                    // first-order fallback on this face
        for (int v = 0; v < 8; ++v) { const R* q = W + (long)v*G.nc; tl[v] = q[cm1]; tr[v] = q[c0]; }
    }
    for (int v = 0; v < 8; ++v) { wl[v] = tl[v]; wr[v] = tr[v]; }
    *fo = bad;
}

// global -> local permutation: (n, t1, t2) = (r, phi, z) | (phi, z, r) | (z, r, phi)
DEV void to_local(const R* w, int dir, St* s) {
    int n = dir, t1 = (dir + 1) % 3, t2 = (dir + 2) % 3;
    s->d = w[0]; s->p = w[4]; s->vn = w[1+n]; s->vt1 = w[1+t1]; s->vt2 = w[1+t2]; s->bt1 = w[5+t1]; s->bt2 = w[5+t2];
}

DEV void flux_one(long t, const R* W, const R* Weq, const R* Weqf, const R* Bn_face, R* Fout, const Grid& G, int dir, int* flags) {
    int n0 = G.nr + (dir == 0), n1 = G.nphi + (dir == 1), n2 = G.nz + (dir == 2);
    int a = int(t / ((long)n1*n2)), b = int((t / n2) % n1), c = int(t % n2);
    int I = a + G.g, J = b + G.g, K = c + G.g;
    R wl[8], wr[8]; int fo;
    face_states(W, Weq, Weqf, t, G, dir, I, J, K, wl, wr, &fo);
    if (fo == 3) {                                                 // v05 refusal: an own cell is inadmissible
        long nf0 = (long)n0*n1*n2;
        for (int q = 0; q < 8; ++q) Fout[q*nf0 + t] = qnan();
        flags[t] = 32; return;
    }
    R bn = dir == 0 ? Bn_face[S_BR(I,J,K)] : (dir == 1 ? Bn_face[S_BP(I,J,K)] : Bn_face[S_BZ(I,J,K)]);
    St sl, sr; to_local(wl, dir, &sl); to_local(wr, dir, &sr);
    R F[7]; int fb = hlld(sl, sr, bn, G.gamma, F, G.heal);
    long nf = (long)n0*n1*n2;
    int nn = dir, t1 = (dir + 1) % 3, t2 = (dir + 2) % 3;
    Fout[0*nf + t] = F[0]; Fout[4*nf + t] = F[4];
    Fout[(1+nn)*nf + t] = F[1]; Fout[(1+t1)*nf + t] = F[2]; Fout[(1+t2)*nf + t] = F[3];
    Fout[(5+nn)*nf + t] = R(0); Fout[(5+t1)*nf + t] = F[5]; Fout[(5+t2)*nf + t] = F[6];
    flags[t] = (fo == 1 ? 1 : 0) | (fo == 2 ? 16 : 0) | (fb == 1 ? 2 : 0) | (fb == 2 ? 4 : 0) | (fb == 3 ? 8 : 0) | (fb == 4 ? 32 : 0);
}

#ifdef HLLD_GPU
extern "C" __global__ void flux_kernel(const R* W, const R* Weq, const R* Weqf, const R* Bn, R* Fout, int* flags, const int* mask, int use_mask,
        int nr, int nphi, int nz, int g, long nc, R gamma, int limiter, int use_eq, int use_eqf, int heal, int dir, long ntot) {
    long t = long(blockIdx.x)*blockDim.x + threadIdx.x; if (t >= ntot) return;
    Grid G; G.nr = nr; G.nphi = nphi; G.nz = nz; G.g = g; G.nc = nc; G.gamma = gamma; G.limiter = limiter; G.use_eq = use_eq; G.use_eqf = use_eqf; G.heal = heal; G.mask = use_mask ? mask : (const int*)0;
    flux_one(t, W, Weq, Weqf, Bn, Fout, G, dir, flags);
}
#else
extern "C" void flux_cpu(const R* W, const R* Weq, const R* Weqf, const R* Bn, R* Fout, int* flags, const int* mask, int use_mask,
        int nr, int nphi, int nz, int g, long nc, R gamma, int limiter, int use_eq, int use_eqf, int heal, int dir, long ntot) {
    Grid G; G.nr = nr; G.nphi = nphi; G.nz = nz; G.g = g; G.nc = nc; G.gamma = gamma; G.limiter = limiter; G.use_eq = use_eq; G.use_eqf = use_eqf; G.heal = heal; G.mask = use_mask ? mask : (const int*)0;
    #pragma omp parallel for schedule(static)
    for (long t = 0; t < ntot; ++t) flux_one(t, W, Weq, Weqf, Bn, Fout, G, dir, flags);
}
// single-interface HLLD for the oracle comparison: states given in local frame (d, vn, vt1, vt2, p, bt1, bt2), bn
extern "C" void riemann_cpu(const R* L, const R* Rr, const R* bn, R* F, int* fb, R gamma, int heal, long n) {
    #pragma omp parallel for schedule(static)
    for (long t = 0; t < n; ++t) {
        St a, b; a.d = L[7*t]; a.vn = L[7*t+1]; a.vt1 = L[7*t+2]; a.vt2 = L[7*t+3]; a.p = L[7*t+4]; a.bt1 = L[7*t+5]; a.bt2 = L[7*t+6];
        b.d = Rr[7*t]; b.vn = Rr[7*t+1]; b.vt1 = Rr[7*t+2]; b.vt2 = Rr[7*t+3]; b.p = Rr[7*t+4]; b.bt1 = Rr[7*t+5]; b.bt2 = Rr[7*t+6];
        fb[t] = hlld(a, b, bn[t], gamma, F + 7*t, heal);
    }
}
#endif
// v05.2: the kernel's input W (cell primitives + cell-centred B = average of the two CT faces) is built HERE, in IEEE
// code, on both backends.  CuPy's own elementwise arithmetic flushes FP32 subnormals to zero (KW-00 / HLLD-05 diag:
// 1e-40f * 1 -> 0 in CuPy), which changed W on the GPU before the flux kernel ran.  Same expression as NumPy: 0.5 * (a + b).
DEV void pack_one(long t, const R* rho, const R* vr, const R* vp, const R* vz, const R* p, const R* Br, const R* Bp, const R* Bz, R* W,
                  int N0, int N1, int N2, long nc) {
    long i = t / ((long)N1*N2), j = (t / N2) % N1, k = t % N2;
    W[0*nc + t] = rho[t]; W[1*nc + t] = vr[t]; W[2*nc + t] = vp[t]; W[3*nc + t] = vz[t]; W[4*nc + t] = p[t];
    long br = (i*N1 + j)*N2 + k, bp = (i*(N1 + 1) + j)*N2 + k, bz = (i*N1 + j)*(N2 + 1) + k;
    W[5*nc + t] = R(0.5)*(Br[br] + Br[br + (long)N1*N2]);
    W[6*nc + t] = R(0.5)*(Bp[bp] + Bp[bp + N2]);
    W[7*nc + t] = R(0.5)*(Bz[bz] + Bz[bz + 1]);
}
#ifdef HLLD_GPU
extern "C" __global__ void pack_kernel(const R* rho, const R* vr, const R* vp, const R* vz, const R* p, const R* Br, const R* Bp, const R* Bz, R* W,
                                       int N0, int N1, int N2, long nc) {
    long t = long(blockIdx.x)*blockDim.x + threadIdx.x; if (t < nc) pack_one(t, rho, vr, vp, vz, p, Br, Bp, Bz, W, N0, N1, N2, nc);
}
#endif
#ifdef HLLD_GPU
extern "C" __global__ void log10p6_kernel(const R* m, R* out, long n) { long t = long(blockIdx.x)*blockDim.x + threadIdx.x; if (t < n) out[t] = log10p6(m[t]); }
#else
extern "C" void log10p6_cpu(const R* m, R* out, long n) { for (long t = 0; t < n; ++t) out[t] = log10p6(m[t]); }
#endif
#ifdef HLLD_GPU
extern "C" __global__ void riemann_kernel(const R* L, const R* Rr, const R* bn, R* F, int* fb, R gamma, int heal, long n) {
    long t = long(blockIdx.x)*blockDim.x + threadIdx.x; if (t >= n) return;
    St a, b; a.d = L[7*t]; a.vn = L[7*t+1]; a.vt1 = L[7*t+2]; a.vt2 = L[7*t+3]; a.p = L[7*t+4]; a.bt1 = L[7*t+5]; a.bt2 = L[7*t+6];
    b.d = Rr[7*t]; b.vn = Rr[7*t+1]; b.vt1 = Rr[7*t+2]; b.vt2 = Rr[7*t+3]; b.p = Rr[7*t+4]; b.bt1 = Rr[7*t+5]; b.bt2 = Rr[7*t+6];
    fb[t] = hlld(a, b, bn[t], gamma, F + 7*t, heal);
}
#endif
"""

SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()
# v05.1: floating-point contraction is OFF on both backends.  NVRTC fuses a*b+c into FMA by default and g++ may do so on
# FMA-capable targets; with contraction off the GPU and CPU builds are bit-identical (FP64 and FP32, HLLD-04 fmad probe) and
# results no longer depend on how the optimiser happens to contract a given source.  Cost on an L4: +12 % FP64, ~0 % FP32.
# v05.2: IEEE semantics pinned explicitly and the GPU module compiled by NVRTC DIRECTLY (as PRIM v01 / RESIDUAL v01 /
# UCT-EMF v02.1): cupy.RawModule appends -ftz=true, which flushed FP32 subnormals in v05.1.  FP64 is not affected by -ftz.
GPU_OPTIONS = ("-DHLLD_GPU", "-std=c++14", "-fmad=false", "-ftz=false", "-prec-div=true", "-prec-sqrt=true")
CPU_FLAGS = ("-O2", "-ffp-contract=off", "-shared", "-fPIC")
GPU_LOADER = "nvrtc-direct (cupy.cuda.nvrtc, no CuPy option injection), -arch=compute_<cc>, PTX checked free of .ftz"
BUILD_SHA256 = hashlib.sha256((SRC + "|" + " ".join(GPU_OPTIONS) + "|" + " ".join(CPU_FLAGS) + "|" + GPU_LOADER).encode()).hexdigest()
_cache = {}
NAMES = ("rho", "m_r", "m_phi", "m_z", "E", "B_r", "B_phi", "B_z")


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


def _cpu_lib(dtype):
    real = "double" if dtype == np.float64 else "float"
    if ("cpu", real) in _cache: return _cache[("cpu", real)]
    d = os.path.join(tempfile.gettempdir(), "hlld_v052_" + hashlib.sha256((BUILD_SHA256 + real).encode()).hexdigest()[:16])
    os.makedirs(d, exist_ok=True); so = os.path.join(d, "hlld5.so")
    if not os.path.exists(so):
        open(os.path.join(d, "hlld.cpp"), "w").write(SRC)
        cmd = ["g++", *CPU_FLAGS, "-fopenmp", f"-DREAL={real}", "-o", so, os.path.join(d, "hlld.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError(r.stderr)
    lib = ctypes.CDLL(so); _cache[("cpu", real)] = lib; return lib


class _NvrtcModule:
    """a CUDA module compiled by NVRTC DIRECTLY with exactly our options (cupy.RawModule appends '-ftz=true').
    The PTX is checked to contain no '.ftz' instruction before it is loaded.  (Same loader as PRIM v01.)"""

    def __init__(self, src, options):
        import cupy as cp
        from cupy.cuda import nvrtc
        cc = cp.cuda.Device().compute_capability
        opts = [*options, f"-arch=compute_{cc}"]
        prog = nvrtc.createProgram(src, "kernel.cu", [], [])
        try:
            try:
                nvrtc.compileProgram(prog, opts)
            except Exception as x:
                raise RuntimeError(f"NVRTC compile failed: {x}\n{nvrtc.getProgramLog(prog)}")
            ptx = nvrtc.getPTX(prog)
        finally:
            nvrtc.destroyProgram(prog)
        text = ptx.decode("latin-1") if isinstance(ptx, (bytes, bytearray)) else ptx
        n_ftz = text.count(".ftz")
        if n_ftz: raise RuntimeError(f"generated PTX contains {n_ftz} '.ftz' instructions: IEEE gradual underflow not guaranteed")
        self.options, self.ptx_ftz_count, self.arch = tuple(opts), n_ftz, cc
        self.module = cp.cuda.function.Module()
        self.module.load(ptx if isinstance(ptx, (bytes, bytearray)) else ptx.encode())

    def get_function(self, name):
        return self.module.get_function(name)


def _gpu_mod(dtype):
    real = "double" if dtype == np.float64 else "float"
    if ("gpu", real) not in _cache:
        _cache[("gpu", real)] = _NvrtcModule(SRC, (*GPU_OPTIONS, f"-DREAL={real}"))
    return _cache[("gpu", real)]


def log10p6(m, dtype=np.float64, backend="cpu"):
    """test entry point: the kernel's deterministic log10(m) + 6 (v05.2) on a 1-D array"""
    m = np.ascontiguousarray(np.asarray(m, dtype)); n = m.size
    if backend == "cupy":
        import cupy as cp
        a = cp.asarray(m); o = cp.empty_like(a)
        _gpu_mod(dtype).get_function("log10p6_kernel")(((n + 127) // 128,), (128,), (a, o, np.int64(n))); return cp.asnumpy(o)
    o = np.empty_like(m); lib = _cpu_lib(dtype); P = lambda a: a.ctypes.data_as(ctypes.c_void_p)
    lib.log10p6_cpu(P(m), P(o), ctypes.c_long(n)); return o


class Grid:
    """Identical to uct_emf_v02.Grid (ghost-extended radii; axis grid iff r_faces[g] == 0)."""

    def __init__(self, nr, nphi, nz, rmin, rmax, zlen=1.0, g=2, dtype=np.float64, xp=np):
        self.nr, self.nphi, self.nz, self.g, self.dtype, self.xp = nr, nphi, nz, g, dtype, xp
        self.dr = (rmax - rmin) / nr; self.dphi = 2 * np.pi / nphi; self.dz = zlen / nz; self.rmin = rmin
        rf = rmin + (np.arange(nr + 1 + 2 * g) - g) * self.dr
        if rmin == 0: rf[g] = 0.0
        self.r_faces = rf; self.r_centers = 0.5 * (rf[:-1] + rf[1:])
        self.phi_c = (np.arange(nphi + 2 * g) - g + 0.5) * self.dphi; self.phi_f = (np.arange(nphi + 1 + 2 * g) - g) * self.dphi
        self.z_c = (np.arange(nz + 2 * g) - g + 0.5) * self.dz; self.z_f = (np.arange(nz + 1 + 2 * g) - g) * self.dz
        self.axis = rmin == 0

    def shape(self, kind):
        n, p, z, g = self.nr, self.nphi, self.nz, self.g
        return dict(cell=(n + 2 * g, p + 2 * g, z + 2 * g), Br=(n + 1 + 2 * g, p + 2 * g, z + 2 * g), Bphi=(n + 2 * g, p + 1 + 2 * g, z + 2 * g),
                    Bz=(n + 2 * g, p + 2 * g, z + 1 + 2 * g), F_r=(8, n + 1, p, z), F_phi=(8, n, p + 1, z), F_z=(8, n, p, z + 1))[kind]

    def zeros(self, kind):
        return self.xp.zeros(self.shape(kind), dtype=self.dtype)


def cell_B(G, Br, Bphi, Bz):
    """cell-centred B as the average of the two CT faces (array arithmetic: with CuPy arrays FP32 subnormals are flushed;
    the flux path uses pack(), which does not go through here on the GPU)"""
    return 0.5 * (Br[:-1] + Br[1:]), 0.5 * (Bphi[:, :-1] + Bphi[:, 1:]), 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])


def pack(G, rho, vr, vphi, vz, p, Br, Bphi, Bz):
    """W (8, cells) in the kernel's block layout.  v05.2: on the GPU the cell-centred B is computed by pack_kernel (IEEE build),
    not by CuPy elementwise arithmetic, which flushes FP32 subnormals; on the CPU NumPy computes the same 0.5 * (a + b)."""
    xp = G.xp
    if xp is np:
        bc = cell_B(G, Br, Bphi, Bz)
        return xp.ascontiguousarray(xp.stack([rho, vr, vphi, vz, p, *bc]).astype(G.dtype))
    dt = G.dtype; sh = G.shape("cell"); nc = int(np.prod(sh)); W = xp.empty((8,) + tuple(sh), dtype=dt)
    a = [xp.ascontiguousarray(x.astype(dt, copy=False)) for x in (rho, vr, vphi, vz, p, Br, Bphi, Bz)]
    _gpu_mod(dt).get_function("pack_kernel")(((nc + 127) // 128,), (128,), (*a, W, np.int32(sh[0]), np.int32(sh[1]), np.int32(sh[2]), np.int64(nc)))
    return W


def fluxes(G, rho, vr, vphi, vz, p, Br, Bphi, Bz, gamma=5 / 3, limiter="mc", W_eq=None, W_eq_faces=None, backend="cpu",
           directions=(0, 1, 2), heal=7, first_order_cells=None):
    """HLLD fluxes through every interior face.  W_eq: optional equilibrium (8 cell arrays, same order as pack();
    its B part may be given as cell-centred values) for well-balanced reconstruction; W_eq_faces: optional dict
    {0|1|2: (8, faces) array} of exact equilibrium face values.  Returns ({dir: F (8, faces)}, {dir: flags}) where
    flags (bits): 1 first-order face fallback, 2 HLL numerical guard, 4 HLL by the blend (w = 0), 8 blended, 16 first order requested by first_order_cells (v04), 32 REFUSED: inadmissible input, flux = NaN (v05).  first_order_cells: optional int cell array (cell shape); a face next to a flagged cell is reconstructed at first order (a-posteriori positivity recovery, MOOD-style, driven by the caller).  heal: bit mask of active healing mechanisms (default 7 = all; tests only)."""
    xp = G.xp; dt = G.dtype; sc = np.float64 if dt == np.float64 else np.float32
    W = pack(G, rho, vr, vphi, vz, p, Br, Bphi, Bz); nc = int(np.prod(G.shape("cell")))
    Weq = xp.ascontiguousarray(xp.stack(list(W_eq)).astype(dt)) if W_eq is not None else W
    out, flg = {}, {}
    for d in directions:
        kind = ("F_r", "F_phi", "F_z")[d]; F = G.zeros(kind); nt = int(np.prod(G.shape(kind)[1:]))
        fl = xp.zeros(nt, dtype=np.int32)
        Weqf = W_eq_faces.get(d) if W_eq_faces else None
        Weqf_a = xp.ascontiguousarray(xp.moveaxis(Weqf.reshape(8, -1), 0, 1).astype(dt)) if Weqf is not None else W
        Bn = (Br, Bphi, Bz)[d]
        mk = xp.ascontiguousarray(first_order_cells.astype(np.int32)) if first_order_cells is not None else fl
        args_s = [np.int32(G.nr), np.int32(G.nphi), np.int32(G.nz), np.int32(G.g), np.int64(nc), sc(gamma), np.int32(1 if limiter == "mc" else 0),
                  np.int32(W_eq is not None), np.int32(Weqf is not None), np.int32(heal), np.int32(d), np.int64(nt)]
        if backend == "cupy":
            _gpu_mod(dt).get_function("flux_kernel")(((nt + 127) // 128,), (128,), (W, Weq, Weqf_a, xp.ascontiguousarray(Bn), F, fl, mk, np.int32(first_order_cells is not None), *args_s))
        else:
            lib = _cpu_lib(dt); P = lambda a: np.ascontiguousarray(a).ctypes.data_as(ctypes.c_void_p)
            ct = ctypes.c_double if dt == np.float64 else ctypes.c_float
            lib.flux_cpu(P(W), P(Weq), P(Weqf_a), P(Bn), F.ctypes.data_as(ctypes.c_void_p), fl.ctypes.data_as(ctypes.c_void_p), P(mk), ctypes.c_int(int(first_order_cells is not None)),
                         ctypes.c_int(G.nr), ctypes.c_int(G.nphi), ctypes.c_int(G.nz), ctypes.c_int(G.g), ctypes.c_long(nc), ct(gamma),
                         ctypes.c_int(1 if limiter == "mc" else 0), ctypes.c_int(int(W_eq is not None)), ctypes.c_int(int(Weqf is not None)),
                         ctypes.c_int(heal), ctypes.c_int(d), ctypes.c_long(nt))
        out[d] = F; flg[d] = fl.reshape(G.shape(kind)[1:])
    return out, flg


def riemann(WL, WR, bn, gamma=5 / 3, dtype=np.float64, backend="cpu", heal=7):
    """Single-interface HLLD in the local frame: WL, WR (n, 7) = (rho, vn, vt1, vt2, p, bt1, bt2), bn (n,).
    Returns F (n, 7) = (rho, mn, mt1, mt2, E, bt1, bt2) fluxes and the HLL-fallback flags."""
    n = len(bn)
    if backend == "cupy":
        import cupy as cp
        L, Rr, B = (cp.ascontiguousarray(cp.asarray(x, dtype=dtype)) for x in (WL, WR, bn))
        F = cp.zeros((n, 7), dtype); fb = cp.zeros(n, np.int32)
        _gpu_mod(dtype).get_function("riemann_kernel")(((n + 127) // 128,), (128,), (L, Rr, B, F, fb, (np.float64 if dtype == np.float64 else np.float32)(gamma), np.int32(heal), np.int64(n)))
        return F.get(), fb.get()
    L, Rr, B = (np.ascontiguousarray(np.asarray(x, dtype=dtype)) for x in (WL, WR, bn))
    F = np.zeros((n, 7), dtype); fb = np.zeros(n, np.int32); lib = _cpu_lib(dtype)
    ct = ctypes.c_double if dtype == np.float64 else ctypes.c_float; P = lambda a: a.ctypes.data_as(ctypes.c_void_p)
    lib.riemann_cpu(P(L), P(Rr), P(B), P(F), P(fb), ct(gamma), ctypes.c_int(heal), ctypes.c_long(n))
    return F, fb
