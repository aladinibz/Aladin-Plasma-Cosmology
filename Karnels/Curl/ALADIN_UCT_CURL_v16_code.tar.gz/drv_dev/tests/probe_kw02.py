# -*- coding: utf-8 -*-
"""KW-02: where do the DRV-01 run-1 D11 differences come from -- the GPU, or the machine?
KW-01 showed GPU = CPU bit for bit on ONE machine for 40 steps.  D11 compared the Colab GPU leg against a CPU leg run on a
DIFFERENT machine.  KW-02 replays the two D11 runs that differed, at their full length, three ways:
   A = CPU Driver on the reference machine (hashes shipped in kw02_reference.json, one per step)
   B = CPU Driver on this machine        C = GPU Driver on this machine (lockstep with B)
 D04: Hall wave, nr 4, nphi 8, nz 64, hall 0.1, branch -1, one period (the run D11 saved; 2365 steps)
 D02: wall pinch mode, 1000 steps, started from the FROZEN eigenmode of the reference machine (kw02_frozen_mode.npz), so the
      LAPACK difference between machines is taken out.  If B = A here, shipping frozen initial states fixes D02 / D08.
Reports, per run: the first step where C != B (GPU vs CPU, same machine) and the first step where B != A (machine vs machine).
Usage: python probe_kw02.py cupy        (python probe_kw02.py reference  = write kw02_reference.json, CPU only)"""
import os, sys, json, hashlib, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
import aladin_driver_v40 as D
from managers import initial_conditions as IC
MODE = sys.argv[1] if len(sys.argv) > 1 else "cupy"
H = lambda a: np.asarray(D.host(a))
K = 2 * np.pi

def sha(d):
    h = hashlib.sha256()
    for x in d.U + d.B: h.update(np.ascontiguousarray(H(x)).tobytes())
    h.update(repr(float(d.t)).encode()); return h.hexdigest()[:16]

def frozen_mode():
    p = os.path.join(HERE, "kw02_frozen_mode.npz")
    if MODE == "reference" and not os.path.exists(p):
        import oracle_linear_pinch as O
        M = O.eigenmode(200, 0, 2 * K); np.savez(p, **{k: np.asarray(v) for k, v in M.items()})
    z = np.load(p); M = {k: z[k] for k in z.files}; M["sigma"] = complex(M["sigma"]); M["k"] = 2 * K; return M

def runs():
    w = IC.ic_circular_wave(K, 1e-2, hall=0.1, branch=-1)
    M = frozen_mode()
    return {"D04 Hall wave nz64 branch-1": (dict(nr=4, nphi=8, nz=64, hall=0.1, r_outer_bc="outflow"), w, dict(t_end=2 * np.pi / abs(w.omega))),
            "D02 wall pinch mode (frozen eigenmode)": (dict(nr=32, nphi=4, nz=16, z_len=2 * np.pi / M["k"], well_balanced=True, r_outer_bc="wall"),
                                                       IC.ic_pinch_mode(M, 1e-3), dict(nsteps=1000))}

def going(d, lim): return (d.t < lim["t_end"] - 1e-14) if "t_end" in lim else (d.step < lim["nsteps"])

if __name__ == "__main__":
    refp = os.path.join(HERE, "kw02_reference.json"); out = {}
    if MODE == "reference":
        for name, (kw, ic, lim) in runs().items():
            d = D.Driver(D.Config(backend="cpu", label="KW-02", **kw), ic); hs = [sha(d)]
            while going(d, lim): d.advance(t_end=lim.get("t_end")); hs.append(sha(d))
            out[name] = hs; print(name, "steps", d.step, "final", hs[-1])
        json.dump(dict(machine=__import__("platform").node(), numpy=np.__version__, hashes=out), open(refp, "w")); sys.exit()
    ref = json.load(open(refp))["hashes"]
    for name, (kw, ic, lim) in runs().items():
        b = D.Driver(D.Config(backend="cpu", label="KW-02", **kw), ic); c = D.Driver(D.Config(backend="cupy", label="KW-02", **kw), ic)
        A = ref[name]; hb = [sha(b)]; first_cb = None if sha(c) == hb[0] else 0; first_ba = None if hb[0] == A[0] else 0
        while going(b, lim):
            b.advance(t_end=lim.get("t_end")); c.advance(t_end=lim.get("t_end")); s = sha(b); hb.append(s)
            if first_cb is None and sha(c) != s:
                first_cb = b.step; dif = {n: float(np.abs(H(x) - H(y)).max()) for n, x, y in zip(("rho", "m_r", "m_phi", "m_z", "E", "Br", "Bphi", "Bz"), b.U + b.B, c.U + c.B)}
                print(f"  GPU != CPU first at step {b.step}: max|diff| {dif}  dt cpu {b.history and b.history[-1].get('dt')}")
            if first_ba is None and (len(A) <= b.step or A[b.step] != s): first_ba = b.step
        out[name] = dict(steps=b.step, final_cpu=hb[-1], final_gpu=sha(c), final_reference=A[-1], first_gpu_vs_cpu_this_machine=first_cb,
                         first_this_cpu_vs_reference_cpu=first_ba)
        print(f"== {name}: {b.step} steps | GPU vs CPU (this machine): {'IDENTICAL every step' if first_cb is None else 'first differs at step %d' % first_cb}"
              f" | this CPU vs reference CPU: {'IDENTICAL every step' if first_ba is None else 'first differs at step %d' % first_ba}", flush=True)
    json.dump(out, open(os.path.join(HERE, "kw02_cupy.json"), "w"), indent=1)
