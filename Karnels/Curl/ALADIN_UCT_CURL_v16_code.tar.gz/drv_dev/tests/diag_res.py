import sys, numpy as np; sys.argv=["x","cpu"]; sys.path.insert(0,".")
import drv01 as C
D, IC, K = C.D, C.IC, C.K
eta=0.05; ex=eta*K*K
def ringamp(d):
    Brc,Bpc,_=C.cellB(d); I=d.grids.I; ph=d.GE.phi_c[None,:,None]; z=d.GE.z_c[None,None,:]
    bx=Brc*np.cos(ph)-Bpc*np.sin(ph); by=Brc*np.sin(ph)+Bpc*np.cos(ph)
    a=((bx+1j*by)*np.exp(-1j*K*z))[I]
    return a.mean(axis=(1,2))
for lv in [(4,8,16),(8,16,32),(16,32,64)]:
    d=D.Driver(C.cfg(nr=lv[0],nphi=lv[1],nz=lv[2],eta=eta,r_outer_bc="outflow"), IC.ic_resistive_decay(K,1e-3,p0=1.0))
    ts=[0.0]; R=[ringamp(d)]
    d.run(t_end=0.5, on_step=lambda dd,r:(ts.append(dd.t),R.append(ringamp(dd))))
    R=np.abs(np.array(R)); ts=np.array(ts)
    rates=[-np.polyfit(ts,np.log(R[:,i]),1)[0] for i in range(R.shape[1])]
    rc=d.GE.r_centers[d.g:d.g+lv[0]]
    print(lv, "ring rel.err of rate:", " ".join(f"r={r:.3f}:{(x-ex)/ex:+.4f}" for r,x in zip(rc,rates)))
