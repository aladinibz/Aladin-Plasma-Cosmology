# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0.2-dev -- campaign DRV-05, parts A, B, C: the DRV-03 wave and decay tests re-run on RESIDUAL v01.1 (10.5281/zenodo.24498958)
with their ORIGINAL thresholds.          python drv05_waves.py cpu|gpu PART [quick] [resume]      PART = A (D03 + D06) | B (D04 +1) | C (D04 -1)
(Part K, the m = 1 kink, is tests/drv05.py: DRV05_K PASS, Tesla T4, 2026-11-24.)
Physics, set-up, levels and measurement: tests/drv03.py, imported unmodified (it imports drv01.py: same initial conditions, transverse-
amplitude measurement, fits and t_end).  Levels (nr, nphi, nz): (4,8,16) (8,16,32) (16,32,64) (32,64,128).
v01 results (DRV-03, A100, 2026-11-22/23): D03 err 0.1846 %, order 1.799 FAIL; D06 err 0.0112 %, order 1.620 FAIL; D04 +1 err 0.0815 %,
order 1.959 PASS; D04 -1 err 0.0466 %, order 2.046 PASS.  (DRV-04R A on v01 + UCT-CURL v1.5: D03 0.1801 %, order 1.794 FAIL.)
THRESHOLDS -- DRV-01's ORIGINAL thresholds as used in DRV-03, unchanged; DRV-05 approved by the author 2026-11-24:
  <test>_err     <= 0.01   relative error at level 4 (D03: decay rate vs eta k^2; D04, D06: wave frequency; D04: per part = its branch)
  <test>_order   >= 1.8    observed order, level 3 -> level 4
  DRV05_gpu_cpu  == 0      ARRAYS whose SHA-256 differs, GPU leg vs CPU leg: levels 1, 2 (final states) + level 4's first 200 steps
                           (DRV-03 compared values; equal SHA-256 <=> every value bit-identical: the threshold keeps its meaning)
No previews: none of these tests had been run with RESIDUAL v01.1 before this file was frozen, except the checkpoint/resume self-test
(level 1 of D03 and D06 on the CPU, interrupted at step 20 and resumed: bit-identical states and errors; the error values were not printed).
Legs: CPU leg here (levels 1, 2 + the 200-step segment; informational), GPU leg on Colab (all levels, verdict).
SAFETY (campaign_safety.py): preflight at minute 0, no overwrite without 'resume', a checkpoint every 20 min inside each level (the measured
time series is saved with the state), a progress file after each level, Drive sync when Google Drive is mounted, autopack at the end.
"""
import os, sys, json, time, math, platform, datetime, traceback, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; PART = sys.argv[2] if len(sys.argv) > 2 else "A"
QUICK = "quick" in sys.argv[3:]; RESUME = "resume" in sys.argv[3:]
if PART not in ("A", "B", "C"): print(f"PART must be A, B or C (got {PART})"); sys.exit(2)
sys.argv = [sys.argv[0], LEG, PART] + (["quick"] if QUICK else [])
import drv03 as W                                                        # DRV-03 harness, unmodified (imports drv01)
import campaign_safety as CS
D, BM, H, K = W.D, W.BM, W.H, W.K
TAG = f"{LEG}_{PART}{'_quick' if QUICK else ''}"
PROG = os.path.join(HERE, f"drv05w_progress_{TAG}.json"); CK = lambda key: os.path.join(HERE, f"drv05w_ckpt_{TAG}_{key}")
CPU_SHA = os.path.join(HERE, f"drv05w_cpu_{PART}_sha256.json"); CK_EVERY = 20 * 60; SEG = 10 if QUICK else 200
TH = dict(D03_err=0.01, D03_order=1.8, D04_err=0.01, D04_order=1.8, D06_err=0.01, D06_order=1.8, DRV05_gpu_cpu=0.0)
MEANING = dict(D03_err="resistive decay rate vs eta k^2, relative, level 4 (32x64x128)", D03_order="observed order, level 3 -> 4",
               D04_err="Hall wave frequency, relative, level 4 (this part's branch)", D04_order="observed order, level 3 -> 4",
               D06_err="Alfven wave frequency, relative, level 4", D06_order="observed order, level 3 -> 4",
               DRV05_gpu_cpu="arrays whose SHA-256 differs GPU vs CPU leg (levels 1, 2; level 4 first 200 steps)")
DRIVE = os.path.isdir("/content/drive/MyDrive")


def sha_arrays(d): return [hashlib.sha256(np.ascontiguousarray(H(a)).tobytes()).hexdigest() for a in d.U + d.B]
def sync():
    if DRIVE:
        try: print(f"  drive sync: {CS.drive_sync(HERE, 'DRV05')} files", flush=True)
        except Exception as e: print(f"  drive sync failed (run continues): {e}", flush=True)


def run_ck(test, br, lv, tag, rb=None, nsteps=None):
    """drv03.run + checkpoints every 20 min (the series is saved with the state)"""
    key = f"{tag}_{'x'.join(map(str, lv))}" + (f"_seg{nsteps}" if nsteps else "")
    c, ic, t_end, w = W.make(test, br, lv); d = rb.driver(c, ic) if rb else D.Driver(c, ic)
    ts, y = [0.0], [W.C.transverse_amp(d, K)]; ck = CK(key); resumed = None
    if RESUME and os.path.exists(ck + ".npz"):
        d.load(ck); s = json.load(open(ck + "_series.json")); ts = s["ts"]; y = [complex(a, b) for a, b in s["y"]]; resumed = d.step
        print(f"  {key}: RESUMED from checkpoint at step {d.step}, t = {d.t:.5f}", flush=True)
    last = [time.time()]
    def rec(dd, r):
        ts.append(dd.t); y.append(W.C.transverse_amp(dd, K))
        if time.time() - last[0] > CK_EVERY:
            dd.save(ck); json.dump(dict(ts=ts, y=[[complex(v).real, complex(v).imag] for v in y]), open(ck + "_series.json", "w")); last[0] = time.time(); sync()
            print(f"  {key}: checkpoint at step {dd.step}, t = {dd.t:.5f} ({100 * dd.t / t_end:.1f} %)", flush=True)
    kw = dict(nsteps=nsteps - (d.step if resumed else 0)) if nsteps else dict(t_end=t_end)
    (rb.run if rb else d.run)(on_step=rec, **kw)
    for ext in (".npz", ".json", "_series.json"):
        if os.path.exists(ck + ext): os.remove(ck + ext)
    if nsteps: return d, None, resumed
    ts = np.array(ts); y = np.array(y)
    if test == "D03":
        rate = -np.polyfit(ts, np.log(np.abs(y)), 1)[0]; err = abs(rate - 0.05 * K * K) / (0.05 * K * K)
    else:
        wm = -np.polyfit(ts, np.unwrap(np.angle(y)), 1)[0]; err = abs(wm - w) / abs(w)
    return d, float(err), resumed


def part(rb):
    prog = json.load(open(PROG)) if (RESUME and os.path.exists(PROG)) else dict(rows={})
    data, meas = {}, {}
    for test, br in W.PARTS[PART]:
        tag = test + ("" if br is None else f"_b{br:+d}"); errs = []
        levels = W.LEVELS[:1] if QUICK else (W.LEVELS if LEG == "gpu" else W.LEVELS[:2])
        for lv in levels:
            key = f"{tag}_{'x'.join(map(str, lv))}"
            if key in prog["rows"]:
                print(f"  {key}: done before (progress file), skipped", flush=True)
            else:
                t0 = time.time(); d, e, res = run_ck(test, br, lv, tag, rb=rb if (lv == W.LEVELS[-1] and (test, br) == W.PARTS[PART][-1]) else None, nsteps=10 if QUICK else None)
                row = dict(steps=d.step, t=d.t, seconds=round(time.time() - t0, 1), status=d.status, resumed_from_step=res, sha256=sha_arrays(d))
                if not QUICK: row["rel_err"] = e; print(f"  {key}: rel err {e:.4e}, {d.step} steps, {row['seconds']} s", flush=True)
                prog["rows"][key] = row; json.dump(prog, open(PROG, "w"), indent=1, default=float); sync()
            if not QUICK: errs.append(prog["rows"][key]["rel_err"])
        sk = f"{tag}_segment_{SEG}"
        if sk not in prog["rows"]:
            d, _, _ = run_ck(test, br, W.LEVELS[-1], tag, nsteps=SEG)
            prog["rows"][sk] = dict(steps=d.step, t=d.t, status=d.status, sha256=sha_arrays(d)); json.dump(prog, open(PROG, "w"), indent=1, default=float)
        if LEG == "gpu" and not QUICK:
            meas[f"{test}_err"] = max(meas.get(f"{test}_err", 0.0), errs[-1])
            meas[f"{test}_order"] = min(meas.get(f"{test}_order", 99.0), math.log2(errs[-2] / errs[-1]))
    data["rows"] = prog["rows"]
    if LEG == "gpu" and not QUICK:
        ref = json.load(open(CPU_SHA)); n = 0; diff = {}
        for k_, hs in ref.items():
            mine = prog["rows"].get(k_, {}).get("sha256"); nd = len(hs) if mine is None else sum(a != b for a, b in zip(hs, mine)); n += nd
            if nd: diff[k_] = nd
        data["gpu_vs_cpu"] = dict(compared=list(ref), differing=diff); meas["DRV05_gpu_cpu"] = float(n)
    return data, meas


if __name__ == "__main__":
    CS.preflight([CPU_SHA] if (LEG == "gpu" and not QUICK) else [], PROG, RESUME)
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, part=PART, quick=QUICK, resume=RESUME,
               platform=platform.platform(), numpy=np.__version__, drive=DRIVE)
    if LEG == "gpu":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    print(f"DRV-05 part {PART} leg={LEG}{' QUICK' if QUICK else ''}{' RESUME' if RESUME else ''} | {D.VERSION} | {env.get('gpu', 'CPU')} | RESIDUAL v01.1", flush=True)
    keys = sorted({k for t, _ in W.PARTS[PART] for k in (f"{t}_err", f"{t}_order")}) + ["DRV05_gpu_cpu"]
    checks = {} if (LEG != "gpu" or QUICK) else {k: (">=" if k.endswith("order") else "<=", TH[k], MEANING[k]) for k in keys}
    rb = BM.RunBundle(os.path.join(HERE, f"runs_drv05w_{TAG}"), f"DRV05_{PART}", thresholds=checks, meta=dict(header=__doc__)); data, meas = {}, {}
    try:
        with rb:
            data, meas = part(rb)
            for k_, v in meas.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    print(f"DRV05_{PART} {res['verdict']}  " + "; ".join(f"{k}={c['value']:.4e} {c['op']} {c['threshold']:g} {c['result']}" for k, c in res["checks"].items() if isinstance(c.get("value"), (int, float))), flush=True)
    if "exception" in data: print(data["exception"])
    json.dump(dict(campaign="DRV-05", part=PART, thresholds=TH, env=env, verdict=res["verdict"], checks=res["checks"], data=data, bundle=os.path.basename(rb.dir)),
              open(os.path.join(HERE, f"drv05w_{TAG}_results.json"), "w"), indent=1, default=float)
    if LEG == "cpu" and not QUICK and "rows" in data:
        json.dump({k: v["sha256"] for k, v in data["rows"].items() if "sha256" in v}, open(CPU_SHA, "w"), indent=1)
    sync()
    if not QUICK:
        CS.autopack(f"/content/DRV05_{TAG}.tar.gz" if os.path.isdir("/content") else os.path.join(HERE, f"DRV05_{TAG}.tar.gz"),
                    [f"runs_drv05w_{TAG}", f"drv05w_{TAG}_results.json", f"drv05w_progress_{TAG}.json"], HERE)
