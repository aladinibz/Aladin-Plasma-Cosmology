# -*- coding: utf-8 -*-
"""ORACLE-2 -- linear ideal-MHD stability of a static cylindrical pinch by CHEBYSHEV COLLOCATION with axis parity.
A second, independent method (oracle_linear_pinch.py uses staggered finite differences and cannot do m = 1).
Equilibrium: rho0(r), p0(r), B0 = b(r) phi-hat (B_z = 0), J0 = Jz0(r) z-hat, mu0 = 1.  Perturbations f(r) exp(i m phi + i k z + sigma t).
Same linearised equations as the FD oracle (written out again here from the physics, not imported):
  d rho1 = -rho0' vr - rho0 div v ,   div v = (1/r)(r vr)' + i m vphi / r + i k vz
  rho0 d vr   = -p1' - Jz0 Bphi1 - J1z b ,   J1z = (1/r)(r Bphi1)' - i m Br1 / r
  rho0 d vphi = -i m p1 / r + Jz0 Br1
  rho0 d vz   = -i k p1 + J1r b ,            J1r = i m Bz1 / r - i k Bphi1
  d p1  = -p0' vr - gamma p0 div v
  d Br1 = i m b vr / r ,   d Bphi1 = -i k b vz - (b vr)' ,   d Bz1 = i m b vz / r
Discretisation (Trefethen, Spectral Methods in MATLAB, ch. 11): Chebyshev points x_j = cos(pi j / N) on [-1, 1], N ODD, so no
point lies on the axis; a field of azimuthal number m has parity f(-r) = +-f(r) (scalars, v_z, B_z: (-1)^m; r and phi components:
(-1)^(m+1)), so only the M = (N+1)/2 points with r > 0 are kept and the derivative folds in the parity.  Wall at r = 1: v_r = B_r = 0.
Growth rate: max Re(sigma) over eigenvalues with |Im sigma| small (static equilibrium: sigma^2 real).  Convergence in N is part
of the output.  python oracle_cheb_pinch.py   (self-tests: sound waves m = 0, 1 vs Bessel zeros; m = 0 vs the FD oracle; m = 1)"""
import numpy as np


def cheb(N):
    """Chebyshev differentiation matrix and points (Trefethen, cheb.m)"""
    x = np.cos(np.pi * np.arange(N + 1) / N)
    c = np.hstack([2.0, np.ones(N - 1), 2.0]) * (-1.0) ** np.arange(N + 1)
    X = np.tile(x, (N + 1, 1)).T; dX = X - X.T
    D = np.outer(c, 1 / c) / (dX + np.eye(N + 1)); D = D - np.diag(D.sum(axis=1))
    return D, x


def readme_pinch(P0=1.0):
    return dict(rho=lambda r: np.ones_like(r), drho=lambda r: np.zeros_like(r), b=lambda r: 0.5 * r, jz=lambda r: np.ones_like(r),
                p=lambda r: P0 - 0.25 * r ** 2, dp=lambda r: -0.5 * r)


def uniform_gas(p=1.0):
    """B = 0, rho = 1, p uniform: sound waves, exact sigma = i c_s sqrt(kappa^2 + k^2), v_r ~ J_m'(kappa r), J_m'(kappa) = 0"""
    z = lambda r: np.zeros_like(r)
    return dict(rho=lambda r: np.ones_like(r), drho=z, b=z, jz=z, p=lambda r: p * np.ones_like(r), dp=z)


def operator(N, m, k, eq, gamma=5 / 3):
    if N % 2 == 0: raise ValueError("N must be odd (no collocation point on the axis)")
    D, x = cheb(N); M = (N + 1) // 2; r = x[:M]                         # r in (0, 1], r[0] = 1 (wall)
    def Dp(par): return D[:M, :M] + par * D[:M, ::-1][:, :M]           # d/dr of a field with parity par, kept half
    ps = (-1) ** m; pv = (-1) ** (m + 1)                                 # scalar / (r, phi)-component parity
    names = ["rho", "vr", "vp", "vz", "p", "Br", "Bp", "Bz"]
    keep = {n: np.arange(M) for n in names}; keep["vr"] = np.arange(1, M); keep["Br"] = np.arange(1, M)   # wall: v_r = B_r = 0
    off = {}; o = 0
    for n in names: off[n] = o; o += len(keep[n])
    L = np.zeros((o, o), complex); I = np.eye(M); R = np.diag(r); Ri = np.diag(1 / r)
    rho0, b, jz, p0, dp0, drho = (np.diag(eq[q](r)) for q in ("rho", "b", "jz", "p", "dp", "drho"))
    rhoi = np.diag(1 / eq["rho"](r))
    def put(row, col, A):                                                 # A: M x M operator acting col -> row
        L[np.ix_(off[row] + np.arange(len(keep[row])), off[col] + np.arange(len(keep[col])))] += A[np.ix_(keep[row], keep[col])]
    im, ik = 1j * m, 1j * k
    # div v as operators on (vr, vp, vz): (1/r) d/dr (r vr) ; r vr has parity -pv... d/dr of (r f) with f parity pv: (r f) parity -pv
    dv_r = Ri @ Dp(-pv) @ R; dv_p = im * Ri; dv_z = ik * I
    for row, coef in (("rho", -rho0), ("p", -gamma * p0)):
        put(row, "vr", coef @ dv_r); put(row, "vp", coef @ dv_p); put(row, "vz", coef @ dv_z)
    put("rho", "vr", -drho); put("p", "vr", -dp0)
    # vr
    put("vr", "p", -rhoi @ Dp(ps)); put("vr", "Bp", -rhoi @ jz)
    put("vr", "Bp", -rhoi @ b @ Ri @ Dp(-pv) @ R); put("vr", "Br", rhoi @ b @ (im * Ri))
    # vphi
    put("vp", "p", -rhoi @ (im * Ri)); put("vp", "Br", rhoi @ jz)
    # vz
    put("vz", "p", -rhoi * ik); put("vz", "Bz", rhoi @ b @ (im * Ri)); put("vz", "Bp", -rhoi @ b * ik)
    # induction;  b vr: b odd, so (b vr) has parity -pv
    put("Br", "vr", b @ (im * Ri)); put("Bp", "vz", -ik * b); put("Bp", "vr", -Dp(-pv) @ b); put("Bz", "vz", b @ (im * Ri))
    return L, r


def growth_rate(N, m, k, eq=None, gamma=5 / 3, imag_tol=1e-6):
    eq = eq or readme_pinch(); L, r = operator(N, m, k, eq, gamma); s = np.linalg.eigvals(L)
    ok = np.isfinite(s) & (np.abs(s.imag) <= imag_tol * max(1.0, np.abs(s[np.isfinite(s)]).max()))
    return (float(s.real[ok].max()) if ok.any() else 0.0), s


def eigenmode(N, m, k, eq=None, gamma=5 / 3):
    """the most unstable mode as callables f(r) for r in [0, 1] (Chebyshev interpolation with the field's axis parity), normalised so that
    v_r(r0) = 1 (real) at a FIXED radius r0 (0 for m = 1, where v_r is largest; 0.5 otherwise): independent of N.  Returns dict(sigma, rho, vr, vp, vz, p, Br, Bp, Bz, divB)
    where divB is max |div B1| / max |B1| of the mode (a self-check: the mode must be solenoidal)."""
    eq = eq or readme_pinch(); L, r = operator(N, m, k, eq, gamma); s, V = np.linalg.eig(L)
    ok = np.isfinite(s) & (np.abs(s.imag) <= 1e-6 * max(1.0, np.abs(s[np.isfinite(s)]).max())); i = np.flatnonzero(ok)[np.argmax(s.real[ok])]
    x = V[:, i]; M = (N + 1) // 2; ps, pv = (-1) ** m, (-1) ** (m + 1)
    names = ["rho", "vr", "vp", "vz", "p", "Br", "Bp", "Bz"]; par = dict(rho=ps, vr=pv, vp=pv, vz=ps, p=ps, Br=pv, Bp=pv, Bz=ps)
    prof = {}; o = 0
    for n in names:
        if n in ("vr", "Br"): f = np.concatenate([[0.0], x[o:o + M - 1]]); o += M - 1
        else: f = x[o:o + M].copy(); o += M
        prof[n] = f
    _, xx = cheb(N); ph, a = 1.0, 1.0
    def interp(n):
        full = np.concatenate([prof[n], par[n] * prof[n][::-1]]) * ph / a        # values on all N+1 points (parity extension)
        w = (-1.0) ** np.arange(N + 1); w[0] *= 0.5; w[-1] *= 0.5                # barycentric weights (Chebyshev points 2nd kind)
        def f(rr):
            rr = np.atleast_1d(np.asarray(rr, float)); d = rr[:, None] - xx[None, :]; hit = np.isclose(d, 0, atol=1e-15)
            q = w / np.where(hit, 1.0, d); val = (q @ full) / q.sum(axis=1)
            for ii, jj in zip(*np.nonzero(hit)): val[ii] = full[jj]
            return val
        return f
    r0 = 0.0 if m == 1 else 0.5; ph = 1.0 / complex(interp("vr")(r0)[0])
    out = dict(sigma=s[i], m=m, k=k, N=N, r0=r0); out.update({n: interp(n) for n in names})
    # self-check: div B1 = (1/r)(r Br)' + i m Bphi / r + i k Bz on a fine interior grid (centred differences)
    rr = np.linspace(0.05, 0.95, 181); h = 1e-5
    dr = ((rr + h) * out["Br"](rr + h) - (rr - h) * out["Br"](rr - h)) / (2 * h) / rr
    dv = dr + 1j * m * out["Bp"](rr) / rr + 1j * k * out["Bz"](rr)
    out["divB"] = float(np.abs(dv).max() / max(np.abs(out[n](rr)).max() for n in ("Br", "Bp", "Bz")))
    return out


if __name__ == "__main__":
    from scipy.special import jnp_zeros
    print("ORACLE-2 (Chebyshev collocation, axis parity) self-tests")
    # 1. sound waves in a uniform gas, m = 0 and m = 1: |Im sigma| = c_s sqrt(kappa^2 + k^2), kappa = j'_{m,1}
    for m in (0, 1):
        kap = jnp_zeros(m, 2)[1] if m == 0 else jnp_zeros(m, 1)[0]     # m = 0: j'_{0,1} = 0 is the trivial mode -> next zero
        for N in (21, 41):
            _, s = growth_rate(N, m, 1.0, uniform_gas(), imag_tol=1)
            ex = np.sqrt(5 / 3) * np.sqrt(kap ** 2 + 1.0); w = np.abs(s.imag); err = np.min(np.abs(w - ex)) / ex
            print(f"  sound m={m} N={N}: exact {ex:.10f}, nearest |Im sigma| rel err {err:.2e}, max|Re sigma| {np.abs(s.real).max():.1e}")
    # 2. README pinch m = 0, k = 4 pi vs the FD oracle (0.28248 at N = 400)
    for N in (31, 61, 91, 121):
        g, s = growth_rate(N, 0, 4 * np.pi); print(f"  README pinch m=0 k=4pi N={N}: growth {g:.10f}")
    # 3. m = 1 kink
    for k in (np.pi, 2 * np.pi, 4 * np.pi):
        out = [growth_rate(N, 1, k)[0] for N in (31, 61, 91, 121)]
        print(f"  README pinch m=1 k={k:.4f}: growth N=31,61,91,121: " + ", ".join(f"{v:.10f}" for v in out))
    # 4. marginal stability of m = 1 (wall at r = 1): bisection on k
    lo, hi = 1.0, 2.0
    for _ in range(40):
        mid = 0.5 * (lo + hi); (lo, hi) = (lo, mid) if growth_rate(61, 1, mid)[0] > 1e-8 else (mid, hi)
    print(f"  m=1 marginal wavenumber (N=61): k_c = {0.5 * (lo + hi):.8f}  (stable below, unstable above)")
    # 5. the K01 mode: m = 1, k = 2 pi, solenoidal
    for N in (61, 91):
        E = eigenmode(N, 1, 2 * np.pi); print(f"  K01 eigenmode N={N}: sigma {E['sigma'].real:.10f}{E['sigma'].imag:+.1e}j, max|div B1|/max|B1| {E['divB']:.1e}, "
                                              f"v_r(0.5) {E['vr'](0.5)[0]:.10f}, v_phi(0) {E['vp'](0.0)[0]:.10f}")
