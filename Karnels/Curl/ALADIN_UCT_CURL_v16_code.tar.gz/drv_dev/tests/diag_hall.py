import sys, numpy as np; sys.argv=["x","cpu"]; sys.path.insert(0,".")
import drv01 as C
D, IC, H = C.D, C.IC, C.H
for n in (32, 64, 128, 256):
    d0, h0 = C.heat_stage(n)
    dh, hh = C.heat_stage(n, hall=0.02)
    G=dh.GE; Ub=[x.copy() for x in dh.U]; Bb=[x.copy() for x in dh.B]; dh.fill(Ub,Bb)
    pr=dh.PR.primitives(dh.GP,*Ub,*Bb,gamma=dh.cfg.gamma,backend="cpu"); P=[pr[k] for k in ("rho","vr","vphi","vz","p")]
    J,_=dh.UC.run_curl(*Bb,G.r_faces,G.r_centers,G.dr,G.dphi,G.dz,n,n,4,dh.g,backend="cpu"); J=[np.ascontiguousarray(x) for x in J]; dh.boundary.fill_cells(J,vector=True)
    Em=dh.E.compute_emf(dh.GE,*Bb,*P[1:4],P[0],P[4],J=J,gamma=dh.cfg.gamma,hall=0.02,backend="cpu")
    Ei=dh.E.compute_emf(dh.GE,*Bb,*P[1:4],P[0],P[4],J=None,gamma=dh.cfg.gamma,backend="cpu")
    divS=H(dh.pipeline.poynting_divergence([a-b for a,b in zip(Em,Ei)],Bb))
    res=np.abs(hh-h0); i=np.unravel_index(np.argmax(res),res.shape)
    rc=G.r_centers[dh.g:dh.g+n]; ph=G.phi_c[dh.g:dh.g+n]
    x,y=rc[i[0]]*np.cos(ph[i[1]]), rc[i[0]]*np.sin(ph[i[1]])
    print(f"n={n}: max|heat| = {res.max():.4e}  max|divS| = {np.abs(divS).max():.4e}  ratio {res.max()/np.abs(divS).max():.4e}  L1-avg ratio {res.mean()/np.abs(divS).mean():.4e}  at r={rc[i[0]]:.3f} (x={x:+.3f}, y={y:+.3f}); dist from tube centre {np.hypot(x-0.4,y):.3f}", flush=True)
