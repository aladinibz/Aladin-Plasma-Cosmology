# -*- coding: utf-8 -*-
"""
CURL-07 -- certification of UCT-CURL v1.5 (axis-mode fix: phi-averaged Br converted to its point value before the Cartesian
rotation).                                                   python curl07.py cpu | gpu   [quick]
Thresholds approved by the author on 2026-11-23 before any CURL-07 run:
  C01  uniform field B = x-hat crossing the axis (J = 0 exactly): max|J|/|B| <= 1e-4 at 128x256; order >= 2.5 (64x128 -> 128x256),
       joint refinement (nr, nphi) = (8,16) (16,32) (32,64) (64,128) (128,256), nz = 4
  C02  README pinch B_phi = r/2: J of v1.5 bit-identical to v1.4 (0 values differing) on (8,8,4) (16,16,8) (32,32,8) (64,64,8) (128,128,4)
  C03  annulus grid (r in [0.25, 1.25]) with an m = 1 field: v1.5 bit-identical to v1.4 (0 differing) on (8,16,8) (16,32,8) (32,64,8)
  C04  Beltrami field B = (sin kz, cos kz, 0), k = 2 pi, through the axis (exact J = k B at cell centres): max relative error
       <= 1 % at 32x64x64; order >= 1.8 (16x32x32 -> 32x64x64); levels (4,8,8) (8,16,16) (16,32,32) (32,64,64)
  C05  resistive decay (eta = 0.05) of B = 1e-3 sin(kz) x-hat: instantaneous decay rate of the axis ring from one Driver RHS vs
       eta k^2: |rel err| <= 1e-3 at 64x128x256; order >= 1.5 (32x64x128 -> 64x128x256)
  C06  GPU leg vs CPU leg: every J array of C01-C05 and C05's dB, 0 values differing (FP64)
CHANGE AFTER THE CPU LEG, BEFORE ANY GPU RUN (harness only, thresholds unchanged; disclosed): C06 compares a SHA-256 of each array
  (curl07_states_cpu_sha256.json, made from the CPU leg's curl07_states_cpu.npz) instead of shipping the 37 MB arrays.  Equal hash
  <=> every value bit-identical; C06 counts the arrays whose hash differs, so its threshold 0 means the same: no value differs.
Disclosed previews (dev runs before the freeze, 2026-11-23): C01-type uniform field at 8..64 x 32 and 16 x 16..128 (v1.5: 4.3e-4 ..
3.5e-3 and 1.3e-2 .. 3.5e-6); C05 axis-ring rate at (4,8,16) .. (32,64,128): +19.4 %, +3.1 %, +0.51 %, +0.09 %; D03 levels 1-3 with
v1.5 (9.53e-3, 1.63e-2, 6.25e-3); D13 with v1.5 (unchanged).  The plumbing run (quick) printed C04 at (4,8,8) and (8,16,16):
1.68e-1, 4.42e-2 (also v1.4: identical).  The verdict grids of C01, C04 and C05 were never run.
"""
import os, sys, json, math, time, platform, datetime, traceback, importlib.util
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT); sys.path.insert(0, HERE)
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; BK = "cupy" if LEG == "gpu" else "cpu"; QUICK = "quick" in sys.argv[2:]
import aladin_driver_v40 as D
from managers import initial_conditions as IC, bundle_manager as BM
from kernels import uct_curl as V15
spec = importlib.util.spec_from_file_location("uct_curl_v14_ref", os.path.join(ROOT, "kernels", "uct_curl_v14_ref.py"))
V14 = importlib.util.module_from_spec(spec); spec.loader.exec_module(V14)
assert V15.VERSION == "1.5" and V14.VERSION == "1.4"
H = lambda a: np.asarray(D.host(a)); K = 2 * np.pi
TH = dict(C01_err=1e-4, C01_order=2.5, C02_diff=0.0, C03_diff=0.0, C04_err=0.01, C04_order=1.8, C05_err=1e-3, C05_order=1.5, C06_gpu_cpu=0.0)
RUNS = os.path.join(HERE, f"runs_curl07_{LEG}{'_quick' if QUICK else ''}"); os.makedirs(RUNS, exist_ok=True)
STATES = {}

def driver(nr, nphi, nz, ic, **kw):
    return D.Driver(D.Config(nr=nr, nphi=nphi, nz=nz, backend="cpu", label="CURL-07", **kw), ic)

def faces(d):
    U = [H(x).copy() for x in d.U]; B = [H(x).copy() for x in d.B]; d.fill(U, B); return B

def curl(mod, d, B):
    G = d.GE; c = d.cfg
    J, _ = mod.run_curl(*B, np.ascontiguousarray(G.r_faces), np.ascontiguousarray(G.r_centers), G.dr, G.dphi, G.dz,
                        c.nr, c.nphi, c.nz, G.g, backend=BK)
    return [H(x) for x in J]

def interior(d, a): g = d.g; return a[g:g + d.cfg.nr, g:g + d.cfg.nphi, g:g + d.cfg.nz]
def uniform_ic(d):
    B = IC.transverse_B(d, lambda z: 1.0 + 0 * z, lambda z: 0.0 * z, 0.0); return dict(U=IC._conserved(d, 1.0, 0.0, 0.0, 0.0, 1.0, B), B=B)
def beltrami_ic(d):
    B = IC.transverse_B(d, lambda z: np.sin(K * z), lambda z: np.cos(K * z), 0.0); return dict(U=IC._conserved(d, 1.0, 0.0, 0.0, 0.0, 1.0, B), B=B)
def m1_annulus_ic(d):
    B = IC.transverse_B(d, lambda z: 1.0 + 0.3 * np.sin(K * z), lambda z: 0.2 * np.cos(K * z), 0.1); return dict(U=IC._conserved(d, 1.0, 0.0, 0.0, 0.0, 1.0, B), B=B)

def C01():
    lv = [(8, 16), (16, 32)] if QUICK else [(8, 16), (16, 32), (32, 64), (64, 128), (128, 256)]
    rows = {}; errs = []
    for nr, nphi in lv:
        d = driver(nr, nphi, 4, uniform_ic, r_outer_bc="outflow"); J = curl(V15, d, faces(d))
        e = max(float(np.abs(interior(d, x)).max()) for x in J); errs.append(e); rows[f"{nr}x{nphi}"] = e
        for i, x in enumerate(J): STATES[f"C01_{nr}x{nphi}_J{i}"] = x
        print(f"  C01 {nr}x{nphi}: max|J|/|B| = {e:.3e}", flush=True)
    return rows, dict(C01_err=errs[-1], C01_order=math.log2(errs[-2] / errs[-1]))

def C02():
    lv = [(8, 8, 4), (16, 16, 8)] if QUICK else [(8, 8, 4), (16, 16, 8), (32, 32, 8), (64, 64, 8), (128, 128, 4)]
    rows = {}; n = 0
    for g_ in lv:
        d = driver(*g_, D.ic_zpinch(), well_balanced=True); B = faces(d); J5 = curl(V15, d, B); J4 = curl(V14, d, B)
        nd = sum(int((a != b).sum()) for a, b in zip(J5, J4)); n += nd
        ez = float(np.abs(interior(d, J5[2]) - 1).max()); rows["x".join(map(str, g_))] = dict(differing=nd, max_abs_Jz_minus_1=ez)
        for i, x in enumerate(J5): STATES[f"C02_{'x'.join(map(str, g_))}_J{i}"] = x
        print(f"  C02 {g_}: v1.5 vs v1.4 differing {nd}, max|Jz-1| {ez:.1e}", flush=True)
    return rows, dict(C02_diff=float(n))

def C03():
    lv = [(8, 16, 8)] if QUICK else [(8, 16, 8), (16, 32, 8), (32, 64, 8)]
    rows = {}; n = 0
    for g_ in lv:
        d = driver(*g_, m1_annulus_ic, r_min=0.25, r_max=1.25, r_outer_bc="outflow"); B = faces(d); J5 = curl(V15, d, B); J4 = curl(V14, d, B)
        nd = sum(int((a != b).sum()) for a, b in zip(J5, J4)); n += nd; rows["x".join(map(str, g_))] = dict(differing=nd)
        for i, x in enumerate(J5): STATES[f"C03_{'x'.join(map(str, g_))}_J{i}"] = x
        print(f"  C03 annulus {g_}: v1.5 vs v1.4 differing {nd}", flush=True)
    return rows, dict(C03_diff=float(n))

def C04():
    lv = [(4, 8, 8), (8, 16, 16)] if QUICK else [(4, 8, 8), (8, 16, 16), (16, 32, 32), (32, 64, 64)]
    rows = {}; errs = []
    for g_ in lv:
        d = driver(*g_, beltrami_ic, r_outer_bc="outflow"); J = curl(V15, d, faces(d)); G = d.GE
        ph = G.phi_c[None, :, None]; z = G.z_c[None, None, :]; bx, by = np.sin(K * z), np.cos(K * z)
        ex = [K * (bx * np.cos(ph) + by * np.sin(ph)) * np.ones_like(G.r_centers)[:, None, None],
              K * (-bx * np.sin(ph) + by * np.cos(ph)) * np.ones_like(G.r_centers)[:, None, None], 0 * z * np.ones_like(G.r_centers)[:, None, None] * ph]
        e = max(float(np.abs(interior(d, a) - interior(d, np.broadcast_to(b, a.shape))).max()) for a, b in zip(J, ex)) / K
        e4 = max(float(np.abs(interior(d, a) - interior(d, np.broadcast_to(b, a.shape))).max()) for a, b in zip(curl(V14, d, faces(d)), ex)) / K
        errs.append(e); rows["x".join(map(str, g_))] = dict(rel_err=e, rel_err_v14=e4)
        for i, x in enumerate(J): STATES[f"C04_{'x'.join(map(str, g_))}_J{i}"] = x
        print(f"  C04 {g_}: max rel err v1.5 {e:.3e}   (v1.4 for reference {e4:.3e})", flush=True)
    return rows, dict(C04_err=errs[-1], C04_order=math.log2(errs[-2] / errs[-1]))

def axis_ring_rate(nr, nphi, nz, eta=0.05):
    d = D.Driver(D.Config(nr=nr, nphi=nphi, nz=nz, eta=eta, r_outer_bc="outflow", backend=BK, label="CURL-07 C05"),
                 IC.ic_resistive_decay(K, 1e-3, p0=1.0))
    U = [x.copy() for x in d.U]; B = [x.copy() for x in d.B]; d.fill(U, B)
    out = d.rhs(U, B); Bn = [x.copy() for x in B]
    d.E.ct_update(d.GE, *Bn, *out["EMF"], 1.0, backend=BK)
    dB = [H(a) - H(b) for a, b in zip(Bn, B)]; Bh = [H(b) for b in B]
    def amp(Bf):
        Brc, Bpc, _ = [np.asarray(x) for x in d.PR.cell_B(d.GP, *Bf)] if BK == "cpu" else [H(x) for x in d.PR.cell_B(d.GP, *[d.xp.asarray(y) for y in Bf])]
        I = d.grids.I; ph = d.GE.phi_c[None, :, None]; z = d.GE.z_c[None, None, :]
        bx = Brc * np.cos(ph) - Bpc * np.sin(ph); by = Brc * np.sin(ph) + Bpc * np.cos(ph)
        return ((bx + 1j * by) * np.exp(-1j * K * z))[I].mean(axis=(1, 2))
    a0, a1 = amp(Bh), amp(dB); r = -(a1 / a0).real
    return (r[0] - eta * K * K) / (eta * K * K), dB

def C05():
    lv = [(8, 16, 32), (16, 32, 64)] if QUICK else [(32, 64, 128), (64, 128, 256)]
    rows = {}; errs = []
    for g_ in lv:
        e, dB = axis_ring_rate(*g_); errs.append(abs(e)); rows["x".join(map(str, g_))] = dict(axis_ring_rel_err=e)
        for i, x in enumerate(dB): STATES[f"C05_{'x'.join(map(str, g_))}_dB{i}"] = x
        print(f"  C05 {g_}: axis-ring decay-rate rel err {e:+.4e}", flush=True)
    return rows, dict(C05_err=errs[-1], C05_order=math.log2(errs[-2] / errs[-1]))

MEANING = dict(C01_err="uniform field: max|J|/|B| at 128x256 (exact 0)", C01_order="order 64x128 -> 128x256",
               C02_diff="README pinch: values differing v1.5 vs v1.4", C03_diff="annulus: values differing v1.5 vs v1.4",
               C04_err="Beltrami field: max relative J error at 32x64x64", C04_order="order 16x32x32 -> 32x64x64",
               C05_err="axis-ring resistive decay rate, |rel err| at 64x128x256", C05_order="order 32x64x128 -> 64x128x256",
               C06_gpu_cpu="arrays whose SHA-256 differs, GPU leg vs CPU leg (all J of C01-C05, C05 dB), FP64; 0 <=> no value differs")

if __name__ == "__main__":
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, quick=QUICK, platform=platform.platform(),
               numpy=np.__version__, uct_curl=V15.VERSION, source_sha256=V15.SOURCE_SHA256)
    if BK == "cupy":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    print(f"CURL-07 leg={LEG}{' QUICK (plumbing only)' if QUICK else ''} | UCT-CURL v{V15.VERSION} | {env.get('gpu', 'CPU')}", flush=True)
    keys = [k for k in TH if k != "C06_gpu_cpu"] + (["C06_gpu_cpu"] if LEG == "gpu" else [])
    checks = {} if QUICK else {k: (">=" if k.endswith("order") else "<=", TH[k], MEANING[k]) for k in keys}
    rb = BM.RunBundle(RUNS, "CURL07", thresholds=checks); data, meas = {}, {}
    try:
        with rb:
            for name, fn in (("C01", C01), ("C02", C02), ("C03", C03), ("C04", C04), ("C05", C05)):
                rows, m = fn(); data[name] = rows; meas.update(m)
            if LEG == "gpu" and not QUICK:
                import hashlib                                     # change 1: per-array SHA-256 instead of the 37 MB states
                ref = json.load(open(os.path.join(HERE, "curl07_states_cpu_sha256.json"))); n = 0; diff = {}
                for k_, hv in ref.items():
                    if k_ not in STATES: n += 1; diff[k_] = "missing"; continue
                    if hashlib.sha256(np.ascontiguousarray(STATES[k_]).tobytes()).hexdigest() != hv: n += 1; diff[k_] = "hash differs"
                data["gpu_vs_cpu"] = dict(arrays=len(ref), differing_arrays=diff); meas["C06_gpu_cpu"] = float(n)
            if not QUICK:
                for k_, v in meas.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    print(f"CURL07 {res['verdict']}  " + "; ".join(f"{k}={c['value']:.3e} {c['op']} {c['threshold']:g} {c['result']}" for k, c in res["checks"].items() if isinstance(c.get("value"), (int, float))), flush=True)
    if "exception" in data: print(data["exception"])
    json.dump(dict(campaign="CURL-07", thresholds=TH, env=env, verdict=res["verdict"], checks=res["checks"], data=data, bundle=os.path.basename(rb.dir)),
              open(os.path.join(HERE, f"curl07_{LEG}{'_quick' if QUICK else ''}_results.json"), "w"), indent=1, default=float)
    if LEG == "cpu" and not QUICK: np.savez_compressed(os.path.join(HERE, "curl07_states_cpu.npz"), **STATES)
