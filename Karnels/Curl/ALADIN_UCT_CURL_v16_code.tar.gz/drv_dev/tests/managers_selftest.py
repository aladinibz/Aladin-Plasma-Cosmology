# -*- coding: utf-8 -*-
"""MG-00: the new refusal rules of the managers (memory fit, checkpoint format) and the memory record."""
import os, sys, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
import aladin_driver_v40 as D
BK = sys.argv[1] if len(sys.argv) > 1 else "cpu"
OUT = {}
def rep(name, ok, **kw): OUT[name] = dict(ok=bool(ok), **kw); print(f"{name}: {'PASS' if ok else 'FAIL'}  {kw}", flush=True)

# M1 a grid that cannot fit is refused BEFORE anything is allocated
try:
    D.Driver(D.Config(nr=4096, nphi=2048, nz=2048, backend=BK), D.ic_zpinch()); r = "ran"
except D.AdmissibilityError as e: r = str(e)
rep("M1_memory_refuses_huge_grid", r.startswith("grid does not fit"), reason=r)

# M2 the memory record: estimate before the run vs measured during the run
d = D.Driver(D.Config(well_balanced=True, backend=BK), D.ic_zpinch()); d.run(nsteps=3)
est = d.manifest["memory"]["estimate_bytes"]; use = d.history[-1]
meas = use.get("gpu_pool_peak_bytes", use.get("host_peak_rss_bytes"))
rep("M2_memory_recorded", est > 0 and meas and meas > 0, estimate_MiB=round(est / 2**20, 2), measured_MiB=round(meas / 2**20, 2),
    note="GPU: pool peak (comparable to the estimate); CPU: whole-process peak RSS (includes Python + compiled kernels, not comparable)")

# M3 checkpoint onto a different grid is refused
ck = os.path.join(HERE, "mg_ckpt"); d.save(ck)
try:
    e = D.Driver(D.Config(nr=16, backend=BK), D.ic_zpinch()); e.load(ck); r = "loaded"
except D.AdmissibilityError as x: r = str(x)
rep("M3_checkpoint_wrong_grid_refused", "this run needs" in r, reason=r)

# M4 a modified checkpoint is refused (sha256)
z = dict(np.load(ck + ".npz")); z["arr_0"] = z["arr_0"] * 1.0000001; np.savez(ck, **z)
try:
    e = D.Driver(D.Config(well_balanced=True, backend=BK), D.ic_zpinch()); e.load(ck); r = "loaded"
except D.AdmissibilityError as x: r = str(x)
rep("M4_checkpoint_tampered_refused", "sha256 mismatch" in r, reason=r)
for f in ("mg_ckpt.npz", "mg_ckpt.json"): os.remove(os.path.join(HERE, f))

# M5 manifest records every manager file with its sha256
m = d.manifest["managers"]
rep("M5_manager_hashes_in_manifest", len(m) == len(D.MANAGER_FILES), managers=len(m))

json.dump(OUT, open(os.path.join(HERE, f"mg00_{BK}.json"), "w"), indent=1, default=str)
print(f"MG-00 {BK}: {sum(v['ok'] for v in OUT.values())}/{len(OUT)} PASS")
