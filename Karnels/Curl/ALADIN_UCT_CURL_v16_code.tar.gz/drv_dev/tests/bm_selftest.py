# -*- coding: utf-8 -*-
"""BM-00: self-test of the MakeReport bundle manager — one bundle of every kind, then checks on the bundles themselves."""
import os, sys, json, time, shutil, signal, subprocess, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import aladin_driver_v40 as D
from managers import bundle_manager as BM
BK = sys.argv[1] if len(sys.argv) > 1 else "cpu"
ROOT = os.path.join(HERE, f"runs_bm00_{BK}")
if os.path.exists(ROOT): shutil.rmtree(ROOT)
os.makedirs(ROOT)
OUT = {}
def res(b): return json.load(open(os.path.join(b, "results.json")))
def rep(name, ok, **kw): OUT[name] = dict(ok=bool(ok), **kw); print(f"{name}: {'PASS' if ok else 'FAIL'}  {kw}", flush=True)

# B1 completed, PASS: static README pinch
with BM.RunBundle(ROOT, "B1 static pinch", {"max_dU": ("==", 0.0, "U unchanged after 20 steps"), "max_dB": ("==", 0.0, "B unchanged")}) as rb:
    d = rb.driver(D.Config(well_balanced=True, backend=BK), D.ic_zpinch()); U0 = [x.copy() for x in d.U]; B0 = [x.copy() for x in d.B]
    rb.run(nsteps=20)
    rb.check("max_dU", max(float(abs(D._host(a) - D._host(b)).max()) for a, b in zip(d.U, U0)))
    rb.check("max_dB", max(float(abs(D._host(a) - D._host(b)).max()) for a, b in zip(d.B, B0)))
b1 = rb.dir; rep("B1_completed_pass", res(b1)["verdict"] == "PASS", verdict=res(b1)["verdict"])

# B2 completed, FAIL: the same run against an impossible threshold must be reported FAIL, not hidden
with BM.RunBundle(ROOT, "B2 impossible threshold", {"t_reached": (">=", 1.0, "deliberately impossible in 5 steps")}) as rb:
    d = rb.driver(D.Config(well_balanced=True, backend=BK), D.ic_zpinch()); rb.run(nsteps=5); rb.check("t_reached", d.t)
rep("B2_completed_fail_reported", res(rb.dir)["verdict"] == "FAIL", verdict=res(rb.dir)["verdict"])

# B3 Driver FAILED (expected): negative density
def ic_bad(d):
    x = D.ic_zpinch()(d); x["U"][0][5, 5, 5] = -1.0; return x
with BM.RunBundle(ROOT, "B3 forced failure", {"expected_status": ("==", "FAILED", "Driver must stop explicitly")}) as rb:
    rb.driver(D.Config(backend=BK), ic_bad); rb.run(nsteps=3)
rep("B3_failed_expected", res(rb.dir)["verdict"] == "FAILED" and res(rb.dir)["checks"]["expected_status"]["result"] == "PASS", verdict=res(rb.dir)["verdict"])

# B4 REFUSED (expected): odd nphi on an axis grid
with BM.RunBundle(ROOT, "B4 refused odd nphi", {"expected_status": ("==", "REFUSED", "axis needs even nphi")}) as rb:
    rb.driver(D.Config(nphi=15, backend=BK), D.ic_zpinch()); rb.run(nsteps=3)
rep("B4_refused_expected", res(rb.dir)["verdict"] == "REFUSED" and os.path.exists(rb.p("traceback.txt")), verdict=res(rb.dir)["verdict"])

# B5 INTERRUPTED by the user (KeyboardInterrupt at step 3)
def stop3(d, rec):
    if d.step == 3: raise KeyboardInterrupt
try:
    with BM.RunBundle(ROOT, "B5 user interrupt", {"anything": ("<=", 1.0)}) as rb:
        rb.driver(D.Config(backend=BK), D.ic_zpinch(perturb=lambda d, r, p, z: 0.01 * np.cos(p) * np.exp(-(r - .4) ** 2 / .01))); rb.run(nsteps=50, on_step=stop3)
    ki = False
except KeyboardInterrupt: ki = True
h = BM._readlines(rb.p("history.jsonl"))
rep("B5_interrupted", ki and res(rb.dir)["status"] == "INTERRUPTED" and len(h) == 3 and os.path.exists(rb.p("final_state.npz")),
    verdict=res(rb.dir)["verdict"], steps_recorded=len(h), reraised=ki)

# B6 CRASHED (a bug in user code)
def bug(d, rec):
    if d.step == 2: raise ValueError("deliberate bug")
try:
    with BM.RunBundle(ROOT, "B6 crash", {}) as rb:
        rb.driver(D.Config(backend=BK), D.ic_zpinch()); rb.run(nsteps=10, on_step=bug)
    cr = False
except ValueError: cr = True
rep("B6_crashed", cr and res(rb.dir)["status"] == "CRASHED" and "deliberate bug" in open(rb.p("traceback.txt")).read(), verdict=res(rb.dir)["verdict"])

# B7 undeclared check refused
try:
    with BM.RunBundle(ROOT, "B7 undeclared", {"a": ("<=", 1.0)}) as rb: rb.check("b", 0.0)
    und = False
except KeyError: und = True
rep("B7_undeclared_check_refused", und and res(rb.dir)["status"] == "CRASHED")

# B8 hard kill: a child process is SIGKILLed mid-run; finalize_stale closes the bundle as INTERRUPTED
child = os.path.join(HERE, "_bm_child.py")
open(child, "w").write(f"""import sys; sys.path.insert(0, {os.path.dirname(HERE)!r}); import numpy as np, aladin_driver_v40 as D
from managers import bundle_manager as BM
with BM.RunBundle({ROOT!r}, "B8 hard kill", {{"x": ("<=", 1.0)}}, checkpoint_every=2) as rb:
    rb.driver(D.Config(backend={BK!r}), D.ic_zpinch(perturb=lambda d, r, p, z: 0.01 * np.cos(p) * np.exp(-(r - .4) ** 2 / .01))); rb.run(nsteps=100000)
""")
pr = subprocess.Popen([sys.executable, child], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
b8 = None; t0 = time.time()
while time.time() - t0 < 300:
    c = [x for x in os.listdir(ROOT) if x.startswith("B8") and os.path.isdir(os.path.join(ROOT, x))]
    if c:
        b8 = os.path.join(ROOT, c[0]); s = json.load(open(os.path.join(b8, "status.json"))) if os.path.exists(os.path.join(b8, "status.json")) else {}
        if (s.get("heartbeat") or {}).get("step", 0) >= 5: break
    time.sleep(0.5)
pr.send_signal(signal.SIGKILL); pr.wait()
before = json.load(open(os.path.join(b8, "status.json")))["status"]
closed = BM.finalize_stale(ROOT)
s8 = json.load(open(os.path.join(b8, "status.json"))); h8 = BM._readlines(os.path.join(b8, "history.jsonl"))
# resume from the checkpoint the killed run left behind
d = D.Driver(D.Config(backend=BK), D.ic_zpinch()); d.load(os.path.join(b8, "checkpoint")); st_resume = d.run(nsteps=d.step + 2)
rep("B8_hard_kill", before == "RUNNING" and b8 in closed and s8["status"] == "INTERRUPTED" and len(h8) >= 5 and os.path.exists(b8 + ".zip") and st_resume == "COMPLETED",
    status_before=before, status_after=s8["status"], steps_recorded=len(h8), resumed_from_step=d.step - 2)
os.remove(child)

# B9 compare: rerun of B1 -> identical final state (threshold 0)
with BM.RunBundle(ROOT, "B9 rerun of B1", {}) as rb:
    rb.driver(D.Config(well_balanced=True, backend=BK), D.ic_zpinch()); rb.run(nsteps=20)
c = BM.compare_bundles(b1, rb.dir, threshold=0.0); BM.finish(rb.dir)
rep("B9_compare_rerun", c["verdict"] == "PASS" and c["max_abs"] == 0.0, max_abs=c["max_abs"])

# B10 every bundle: checksums verify, zip holds the same files, report exists
bad = []
for x in sorted(os.listdir(ROOT)):
    b = os.path.join(ROOT, x)
    if not os.path.isdir(b): continue
    for line in open(os.path.join(b, "SHA256SUMS")):
        sha, f = line.split("  ", 1); f = f.strip()
        if BM._sha(os.path.join(b, f)) != sha: bad.append((x, f))
    if not os.path.exists(os.path.join(b, "report.html")) or not os.path.exists(b + ".zip"): bad.append((x, "report/zip"))
rep("B10_checksums_reports", not bad, bundles=len([x for x in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, x))]), bad=bad,
    pdf=sum(os.path.exists(os.path.join(ROOT, x, "report.pdf")) for x in os.listdir(ROOT)))

json.dump(OUT, open(os.path.join(HERE, f"bm00_{BK}.json"), "w"), indent=1, default=str)
print(f"BM-00 {BK}: {sum(v['ok'] for v in OUT.values())}/{len(OUT)} PASS")
