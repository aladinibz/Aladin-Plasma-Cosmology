# -*- coding: utf-8 -*-
"""CAMPAIGN SAFETY -- the rules every ALADIN campaign harness follows from now on (after RES-02, 2026-11-24), so a GPU run is never lost:
  1. PREFLIGHT at minute 0: every file the run needs at its END (the CPU leg's hashes, frozen modes, ...) must exist BEFORE the run starts;
     if one is missing the run refuses to start (it never fails after hours of GPU).
  2. NO OVERWRITE: a part whose progress file exists refuses to start again unless 'resume' is given (an accidental re-run cannot erase work).
  3. CHECKPOINTS every 20 minutes + a progress file after every level, 'resume' continues bit-identically (CHECKPOINT MANAGER).
  4. AUTOPACK: the moment a part ends (PASS, FAIL or crash) its evidence is packed into ONE tar.gz with its SHA-256 printed:
     a single files.download line saves it.
  5. KEEP-ALIVE (optional, 'keepalive=H'): after the last part the runtime stays busy for H hours, so Colab does not recycle the machine
     before you download.  It costs compute units while it waits -- choose H to the time you wake up."""
import os, sys, glob, time, tarfile, hashlib


def preflight(required, progress_path, resume):
    """call before ANY computation"""
    missing = [p for p in required if not os.path.exists(p)]
    if missing:
        print("PREFLIGHT FAILED -- not started, no GPU time used. Missing:\n  " + "\n  ".join(missing), flush=True); sys.exit(2)
    if os.path.exists(progress_path) and not resume:
        print(f"PREFLIGHT FAILED -- {os.path.basename(progress_path)} exists: this part already has saved work.\n"
              f"  To continue it add 'resume'. To really start over, delete that file yourself first.", flush=True); sys.exit(3)
    print("PREFLIGHT OK: all end-of-run files present" + (" | RESUME" if resume else " | fresh start, nothing to overwrite"), flush=True)


def autopack(out_path, patterns, root):
    """pack the evidence now; prints size and SHA-256"""
    with tarfile.open(out_path, "w:gz") as t:
        for pat in patterns:
            for p in sorted(glob.glob(os.path.join(root, pat))): t.add(p, arcname=os.path.relpath(p, root))
    h = hashlib.sha256(open(out_path, "rb").read()).hexdigest()
    print(f"AUTOPACK {out_path}  {os.path.getsize(out_path)} bytes  sha256 {h}\n"
          f"  download it:  from google.colab import files; files.download('{out_path}')", flush=True)
    return h


def keepalive(hours):
    """hold the runtime for `hours` so it is not recycled before the download (prints once every 30 min)"""
    end = time.time() + 3600 * float(hours)
    while time.time() < end:
        print(f"KEEP-ALIVE: runtime held, {(end - time.time()) / 3600:.1f} h left -- download the AUTOPACK file, then stop this cell", flush=True)
        time.sleep(min(1800, max(1, end - time.time())))


# ---------------------------------------------------------------------------------------------------- 6. DRIVE BACKUP (Colab)
DRIVE_DIR = "/content/drive/MyDrive/ALADIN_runs"
SYNC_PATTERNS = ["runs_*", "*progress_*.json", "*ckpt_*", "*_results.json", "*.log", "*_sha256.json"]


def drive_sync(src_dir, campaign, patterns=SYNC_PATTERNS):
    """copy the run's evidence + checkpoints to Google Drive (only changed files); safe to call any time"""
    import shutil
    dst = os.path.join(DRIVE_DIR, campaign); os.makedirs(dst, exist_ok=True); n = 0
    for pat in patterns:
        for p in glob.glob(os.path.join(src_dir, pat)):
            rel = os.path.relpath(p, src_dir); q = os.path.join(dst, rel)
            if os.path.isdir(p):
                for r, _, fs in os.walk(p):
                    for f in fs:
                        a = os.path.join(r, f); b = os.path.join(dst, os.path.relpath(a, src_dir))
                        if not os.path.exists(b) or os.path.getmtime(a) > os.path.getmtime(b) or os.path.getsize(a) != os.path.getsize(b):
                            os.makedirs(os.path.dirname(b), exist_ok=True); shutil.copy2(a, b); n += 1
            elif not os.path.exists(q) or os.path.getmtime(p) > os.path.getmtime(q) or os.path.getsize(p) != os.path.getsize(q):
                shutil.copy2(p, q); n += 1
    return n


def drive_restore(dst_dir, campaign):
    """bring a campaign's saved work back from Drive into a fresh runtime (then run the part with 'resume')"""
    import shutil
    src = os.path.join(DRIVE_DIR, campaign); n = 0
    for r, _, fs in os.walk(src):
        for f in fs:
            a = os.path.join(r, f); b = os.path.join(dst_dir, os.path.relpath(a, src))
            os.makedirs(os.path.dirname(b), exist_ok=True); shutil.copy2(a, b); n += 1
    print(f"DRIVE RESTORE: {n} files from {src} -> {dst_dir}", flush=True)


if __name__ == "__main__" and len(sys.argv) > 2 and sys.argv[1] == "sync-loop":
    # python campaign_safety.py sync-loop CAMPAIGN [minutes]   -- runs beside the campaign, backs up every N minutes
    camp = sys.argv[2]; every = float(sys.argv[3]) if len(sys.argv) > 3 else 5.0; here = os.path.dirname(os.path.abspath(__file__))
    while True:
        try: n = drive_sync(here, camp); print(f"{time.strftime('%H:%M:%S')} DRIVE SYNC {camp}: {n} files updated", flush=True)
        except Exception as e: print(f"{time.strftime('%H:%M:%S')} DRIVE SYNC error (will retry): {e}", flush=True)
        time.sleep(60 * every)
