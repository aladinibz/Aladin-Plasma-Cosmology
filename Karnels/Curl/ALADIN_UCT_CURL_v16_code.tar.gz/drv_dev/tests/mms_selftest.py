# -*- coding: utf-8 -*-
"""MMS-00: self-test of the source machinery (managers/source_manager.py), independent of the Driver.
At random points it checks, against 6th-order central finite differences of the POINT VALUES (a different route):
  T1  every first partial (x, y, z, t) of rho, p, v, A, B and J from the closed-form derivatives;
  T2  div B = 0 and div J = 0 (closed form);
  T3  the source S_U = dU/dt + div F(U) of all five conserved variables (ideal, resistive, Hall), with F built from point
      values of the exact fields only;
  T4  the induction source: dB*/dt + curl E* = -curl E_S  (E_S = -(dA/dt + E*), the EMF the Driver adds).
python mms_selftest.py"""
import os, sys, math, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
from managers import source_manager as SM

sol = SM.mms01_solution(); GAMMA = 5 / 3
rng = np.random.default_rng(20261123)
PTS = [(float(r), float(p), float(z), float(t)) for r, p, z, t in zip(rng.uniform(0, 1, 12), rng.uniform(0, 2 * np.pi, 12), rng.uniform(0, 1, 12), rng.uniform(0, 0.2, 12))]
PTS[0] = (0.0, 0.7, 0.3, 0.05)                                                   # the axis itself
H = 1e-3; W = [(1, 3 / 4), (2, -3 / 20), (3, 1 / 60)]                            # 6th-order central first derivative


def loc(x, y, z): return SM.Loc([math.hypot(x, y)], [math.atan2(y, x)], [z], np)
def cart(L, vec):
    """cylindrical-free: the Solution works in Cartesian components already (B, J, fields); returns plain floats"""
    return [float(np.asarray(a).ravel()[0]) for a in vec]


def point(x, y, z, t):
    L = loc(x, y, z); e = (0, 0, 0, 0)
    val = lambda F: float(L.eval(F, e, t).ravel()[0])
    rho, p = val(sol.rho), val(sol.p); v = [val(f) for f in sol.v]; A = [val(a) for a in sol.A]
    B = cart(L, sol.B(L, t)); J = cart(L, sol.J(L, t))
    return dict(rho=rho, p=p, v=v, A=A, B=B, J=J)


def fd(f, x, y, z, t, ax):
    s = 0.0
    for k, w in W:
        dp = [0.0] * 4; dp[ax] = k * H; dm = [0.0] * 4; dm[ax] = -k * H
        s += w * (f(x + dp[0], y + dp[1], z + dp[2], t + dp[3]) - f(x + dm[0], y + dm[1], z + dm[2], t + dm[3]))
    return s / H


def U_F(q, eta, hall):
    """conserved U and the Cartesian fluxes F[j] (j = x, y, z) from point values"""
    rho, p, v, B, J = q["rho"], q["p"], q["v"], q["B"], q["J"]
    B2 = sum(b * b for b in B); PT = p + 0.5 * B2; m = [rho * a for a in v]
    E = p / (GAMMA - 1) + 0.5 * rho * sum(a * a for a in v) + 0.5 * B2; vB = sum(a * b for a, b in zip(v, B))
    JxB = SM.cross(J, B); Eni = [eta * J[i] + hall * JxB[i] / rho for i in range(3)]; S = SM.cross(Eni, B)
    U = [rho] + m + [E]
    F = []
    for j in range(3):
        F.append([m[j]] + [m[i] * v[j] - B[i] * B[j] + (PT if i == j else 0.0) for i in range(3)] + [(E + PT) * v[j] - vB * B[j] + S[j]])
    return U, F


rep = {}; worst = {}
def record(name, err, scale):
    rel = err / max(scale, 1e-12); worst[name] = max(worst.get(name, 0.0), rel)

for (r, ph, z, t) in PTS:
    x, y = r * math.cos(ph), r * math.sin(ph); L = loc(x, y, z)
    # T1: first partials
    for nm, F in [("rho", sol.rho), ("p", sol.p)] + [(f"v{i}", f) for i, f in enumerate(sol.v)] + [(f"A{i}", a) for i, a in enumerate(sol.A)]:
        for ax in range(4):
            mi = [0, 0, 0, 0]; mi[ax] = 1
            ex = float(L.eval(F, tuple(mi), t).ravel()[0]); num = fd(lambda a, b, c, d: float(loc(a, b, c).eval(F, (0, 0, 0, 0), d).ravel()[0]), x, y, z, t, ax)
            record("T1 partials of rho, p, v, A", abs(ex - num), 1.0)
    for nm, fun in (("B", sol.B), ("J", sol.J)):
        for ax in range(4):
            mi = [0, 0, 0, 0]; mi[ax] = 1
            ex = cart(L, fun(L, t, tuple(mi)))
            for i in range(3):
                num = fd(lambda a, b, c, d: cart(None, fun(loc(a, b, c), d))[i], x, y, z, t, ax)
                record(f"T1 partials of {nm}", abs(ex[i] - num), 1.0)
    # T2: divergences (closed form)
    dB = sum(float(np.asarray(sol.B(L, t, tuple(1 if q == i else 0 for q in range(4)))[i]).ravel()[0]) for i in range(3))
    dJ = sum(float(np.asarray(sol.J(L, t, tuple(1 if q == i else 0 for q in range(4)))[i]).ravel()[0]) for i in range(3))
    record("T2 div B (closed form)", abs(dB), 1.0); record("T2 div J (closed form)", abs(dJ), 1.0)
    # T3: the source of the conserved variables
    for case, eta, hall in (("ideal", 0.0, 0.0), ("resistive", 0.02, 0.0), ("Hall", 0.0, 0.02), ("resistive+Hall", 0.02, 0.02)):
        Sr, Sm, SE = SM.source_U(sol, L, t, GAMMA, eta, hall)
        Sx = [float(np.asarray(a).ravel()[0]) for a in [Sr] + Sm + [SE]]
        for c in range(5):
            dUdt = fd(lambda a, b, cc, d: U_F(point(a, b, cc, d), eta, hall)[0][c], x, y, z, t, 3)
            divF = sum(fd(lambda a, b, cc, d, j=j: U_F(point(a, b, cc, d), eta, hall)[1][j][c], x, y, z, t, j) for j in range(3))
            record(f"T3 source S_U ({case})", abs(Sx[c] - (dUdt + divF)), max(1.0, abs(dUdt)))
    # T4: induction through the EMF:  -curl E_S must equal dB/dt + curl E*
    for case, eta, hall in (("ideal", 0.0, 0.0), ("resistive+Hall", 0.02, 0.02)):
        def ES(a, b, c, d):
            L_ = loc(a, b, c); E = [float(np.asarray(q).ravel()[0]) for q in SM.ohm_E(sol, L_, d, eta, hall)]
            dA = [float(L_.eval(A, (0, 0, 0, 1), d).ravel()[0]) for A in sol.A]
            return [-(u + w) for u, w in zip(dA, E)]
        def Est(a, b, c, d): return [float(np.asarray(q).ravel()[0]) for q in SM.ohm_E(sol, loc(a, b, c), d, eta, hall)]
        curl = lambda f: [fd(lambda a, b, c, d: f(a, b, c, d)[k], x, y, z, t, j) * s for (i, j, k, s) in SM.EPS]
        cS = curl(ES); cE = curl(Est)
        cSv = [0.0] * 3; cEv = [0.0] * 3
        for (i, j, k, s), a, b in zip(SM.EPS, cS, cE): cSv[i] += a; cEv[i] += b
        dBdt = cart(L, sol.B(L, t, (0, 0, 0, 1)))
        for i in range(3): record(f"T4 induction source ({case})", abs(-cSv[i] - (dBdt[i] + cEv[i])), 1.0)

TOL = 1e-8
print("MMS-00 source self-test (12 points incl. one on the axis; 6th-order FD, h = 1e-3; tolerance 1e-8 relative)")
ok = True
for k, v in worst.items():
    res = "PASS" if v <= TOL else "FAIL"; ok &= v <= TOL
    print(f"  {k:40s} max error {v:.2e}  {res}")
print("MMS-00", "PASS" if ok else "FAIL")
json.dump(dict(test="MMS-00", tolerance=TOL, worst=worst, verdict="PASS" if ok else "FAIL"), open(os.path.join(HERE, "mms00_results.json"), "w"), indent=1)
