# -*- coding: utf-8 -*-
"""MMS-01 part 0: with no source attached the Driver is bit-identical to the tree before the source manager was added.
python mms_off_identity.py TREE [cpu|cupy]  -> prints one SHA-256 per case of every state array after N steps (run once per tree, compare)"""
import sys, hashlib, numpy as np
sys.path.insert(0, sys.argv[1])
import aladin_driver_v40 as D
from managers import initial_conditions as IC
K = 2 * np.pi
BK = sys.argv[2] if len(sys.argv) > 2 else "cpu"
cases = {
  "README pinch, well-balanced, fixed": (D.Config(nr=16, nphi=16, nz=16, well_balanced=True), IC.ic_zpinch(perturb=lambda d, r, p, z: 1e-3 * np.cos(K * z) * np.exp(-4 * r * r))),
  "Alfven wave, outflow":               (D.Config(nr=8, nphi=16, nz=32, r_outer_bc="outflow"), IC.ic_circular_wave(K, 1e-2)),
  "Hall wave +1, outflow":              (D.Config(nr=8, nphi=16, nz=32, hall=0.1, r_outer_bc="outflow"), IC.ic_circular_wave(K, 1e-2, hall=0.1)),
  "resistive decay":                    (D.Config(nr=8, nphi=16, nz=32, eta=0.05, r_outer_bc="outflow"), IC.ic_resistive_decay(K, 1e-3)),
  "flux tube eta+Hall, wall":           (D.Config(nr=12, nphi=16, nz=8, eta=0.01, hall=0.05, r_outer_bc="wall"), IC.ic_flux_tube()),
  "Sod along z, outflow z":             (D.Config(nr=4, nphi=8, nz=64, z_bc="outflow", r_outer_bc="outflow"), IC.ic_sod_z()),
}
for name, (cfg, ic) in cases.items():
    cfg.backend = BK; d = D.Driver(cfg, ic)
    h0 = hashlib.sha256()
    for a in d.U + d.B: h0.update(np.ascontiguousarray(D.host(a)).tobytes())
    d.run(nsteps=25)
    h = hashlib.sha256()
    for a in d.U + d.B: h.update(np.ascontiguousarray(D.host(a)).tobytes())
    h.update(np.float64(d.t).tobytes())
    print(f"{name:38s} {d.status} step {d.step} {h.hexdigest()}  initial {h0.hexdigest()[:16]}")
