import sys, numpy as np; sys.argv=["x","cpu"]; sys.path.insert(0,".")
from diag_res2 import rate
for nphi in (16,32,64,128,256):
    e=rate(32,nphi,256); print(nphi, " ".join(f"{x:+.5f}" for x in e[[0,4,8,16,24,31]]), flush=True)
