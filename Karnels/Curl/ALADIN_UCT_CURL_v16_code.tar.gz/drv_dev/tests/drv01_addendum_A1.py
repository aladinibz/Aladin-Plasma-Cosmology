# -*- coding: utf-8 -*-
"""
DRV-01 ADDENDUM A1 -- declared 2026-11-21 AFTER the full CPU leg showed D03, D04, D06 not converging under z-refinement
(D03 1.02 % vs 1 %, order -0.89; D04 2.4 %, order 0.13; D06 0.72 %, order -0.20).  D03, D04 and D06 STAY FAIL in the record.
Hypothesis: those tests refine z only and keep the cross-section at nr = 4, nphi = 8 (45 degrees per cell); the transverse
field crosses the axis and its discrete curl carries an O(dphi^2) error that z-refinement cannot remove.
A1 refines r, phi and z TOGETHER: (nr, nphi, nz) = (4, 8, 16), (8, 16, 32), (16, 32, 64), with the ORIGINAL thresholds
(D03: 1 %, order 1.8; D04: 1 %, order 1.8; D06: 1 %, order 1.8; error at the finest level, order between the last two).
Same initial conditions, same physics, same measurement as drv01.py (imported, unmodified).
python drv01_addendum_A1.py cpu|gpu [D03] [D04] [D06]
"""
import os, sys, json, math, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
sys.argv = [sys.argv[0], LEG] + [a for a in sys.argv[2:] if not a.startswith("D")]
WHICH = [a for a in os.environ.get("A1_TESTS", "D03 D04 D06").split()]
import drv01 as C
D, IC, K = C.D, C.IC, C.K
LEVELS = [(4, 8, 16), (8, 16, 32), (16, 32, 64)]
TH = dict(D03=(0.01, 1.8), D04=(0.01, 1.8), D06=(0.01, 1.8))

def decay(nr, nphi, nz, eta=0.05, t_end=0.5):
    d = D.Driver(C.cfg(nr=nr, nphi=nphi, nz=nz, eta=eta, r_outer_bc="outflow"), IC.ic_resistive_decay(K, 1e-3, p0=1.0))
    ts, a = [0.0], [abs(C.transverse_amp(d, K))]
    d.run(t_end=t_end, on_step=lambda dd, r: (ts.append(dd.t), a.append(abs(C.transverse_amp(dd, K)))))
    rate = -np.polyfit(np.array(ts), np.log(np.array(a)), 1)[0]; return abs(rate - eta * K * K) / (eta * K * K), d.step

def wave(nr, nphi, nz, hall, branch):
    ic = IC.ic_circular_wave(K, 1e-2, hall=hall, branch=branch); w = ic.omega
    d = D.Driver(C.cfg(nr=nr, nphi=nphi, nz=nz, hall=hall, r_outer_bc="outflow"), ic)
    ts, ph = [0.0], [np.angle(C.transverse_amp(d, K))]
    d.run(t_end=2 * np.pi / abs(w), on_step=lambda dd, r: (ts.append(dd.t), ph.append(np.angle(C.transverse_amp(dd, K)))))
    wm = -np.polyfit(np.array(ts), np.unwrap(np.array(ph)), 1)[0]; return abs(wm - w) / abs(w), d.step

if __name__ == "__main__":
    out = {}
    for t in WHICH:
        rows = {}
        for br in ((+1, -1) if t == "D04" else (+1,)):
            errs = []
            for lv in LEVELS:
                e, n = decay(*lv) if t == "D03" else wave(*lv, 0.1 if t == "D04" else 0.0, br)
                errs.append(e); rows[f"branch{br:+d} {lv}"] = dict(rel_err=e, steps=n); print(t, br, lv, f"rel err {e:.3e} steps {n}", flush=True)
            rows[f"branch{br:+d}"] = dict(err=errs[-1], order=math.log2(errs[-2] / errs[-1]))
        worst_e = max(v["err"] for k, v in rows.items() if "err" in v and "(" not in k); worst_o = min(v["order"] for k, v in rows.items() if "order" in v)
        ok = worst_e <= TH[t][0] and worst_o >= TH[t][1]
        out[t] = dict(rows=rows, err=worst_e, order=worst_o, thresholds=TH[t], result="PASS" if ok else "FAIL")
        print(f"A1 {t}: err {worst_e:.3e} (<= {TH[t][0]}) order {worst_o:.2f} (>= {TH[t][1]}) -> {out[t]['result']}", flush=True)
    json.dump(dict(addendum="A1", declared="2026-11-21, after the full CPU leg of DRV-01", levels=LEVELS, results=out),
              open(os.path.join(HERE, f"drv01_A1_{LEG}_{'_'.join(WHICH)}.json"), "w"), indent=1, default=float)
