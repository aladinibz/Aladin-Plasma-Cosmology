# -*- coding: utf-8 -*-
"""SMK-00: smoke test of ALADIN Driver v4.0 (not the certification campaign; that is DRV-01).
S1 Driver == CHAIN-01 harness, bit for bit (same kernels, same dt, perturbed pinch, 5 steps)
S2 static well-balanced README pinch stays static (max |U - U_eq|, |B - B_eq| = 0) for 50 CFL steps
S3 perturbed pinch: mass and p_z conserved to round-off; div B stays at round-off
S4 restart: run 10 = run 5, save, load in a NEW Driver, run 5 (bit-identical)
S5 forced failure: an inadmissible injected state -> Driver refuses with an explicit FAILED (no silent run)
S6 recovery: a strong pressure jump that needs first-order faces -> recovered (passes > 0) and admissible, or explicit STOP
S7 resistive + Hall path (UCT-CURL -> UCT-EMF) runs, div B at round-off
S8 z outflow boundary runs"""
import os, sys, json, time, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import aladin_driver_v40 as D
BK = sys.argv[1] if len(sys.argv) > 1 else "cpu"
R = {}; STATES = {}

def maxdiff(a, b):
    return max(float(np.abs(D._host(x) - D._host(y)).max()) for x, y in zip(a, b))

def bump(amp=0.01):
    def f(d, rc, ph, zc): return amp * np.exp(-((rc - 0.4) ** 2) / 0.01) * np.cos(ph) * np.cos(2 * np.pi * zc)
    return f

def rep(name, ok, **kw):
    R[name] = dict(ok=bool(ok), **kw); print(f"{name}: {'PASS' if ok else 'FAIL'}  {kw}", flush=True)

# S1 --------------------------------------------------------------------------------------------------------------
sys.path.insert(0, HERE); import zp_step as ZS
cfg = D.Config(well_balanced=True, eglm="monitor", backend=BK, label="S1")
d = D.Driver(cfg, D.ic_zpinch(perturb=bump()))
pz = ZS.Pinch(backend=BK, wb=True)
U, B = pz.initial()
U[4] = U[4] + pz.to(bump()(None, pz.GE.r_centers[:, None, None], pz.GE.phi_c[None, :, None], pz.GE.z_c[None, None, :])) / (5 / 3 - 1)
pz.fill(U, B)
dt = 0.8 * pz.dt_cfl(U, B)
for _ in range(5):
    U, B, _ = pz.step(U, B, dt); d.advance(dt=dt)
g = d.g; I = (slice(g, g + 32), slice(g, g + 16), slice(g, g + 16))
dU = max(float(np.abs(D._host(a)[I] - D._host(b)[I]).max()) for a, b in zip(d.U, U)); dB = maxdiff(d.B, B)
rep("S1_driver_eq_chain01", dU == 0 and dB == 0, max_dU=dU, max_dB=dB, note="interior cells, all faces")

# S2 --------------------------------------------------------------------------------------------------------------
cfg = D.Config(well_balanced=True, backend=BK, label="S2 static")
d = D.Driver(cfg, D.ic_zpinch()); Ue = [x.copy() for x in d.U]; Be = [x.copy() for x in d.B]
st = d.run(nsteps=50)
rep("S2_static_wb", st == "COMPLETED" and maxdiff(d.U, Ue) == 0 and maxdiff(d.B, Be) == 0, status=st, max_dU=maxdiff(d.U, Ue), max_dB=maxdiff(d.B, Be), t=d.t,
    eglm=[e for e in d.events if e["event"] == "eglm_project"][0]["report"])

# S3 --------------------------------------------------------------------------------------------------------------
cfg = D.Config(well_balanced=True, backend=BK, g2_interval=20, label="S3 perturbed")
d = D.Driver(cfg, D.ic_zpinch(perturb=bump())); t0 = d.totals(); st = d.run(nsteps=40); t1 = d.totals()
rel = lambda k: abs(t1[k] - t0[k]) / max(abs(t0[k]), 1.0)
d.write_manifest(os.path.join(HERE, f"smk00_S3_manifest_{BK}.json")); STATES["S3"] = d
rep("S3_perturbed_conservation", st == "COMPLETED" and rel("mass") < 1e-13 and abs(t1["pz"]) < 1e-13 and t1["divB_norm"] < 1e-12,
    status=st, dmass_rel=rel("mass"), pz=t1["pz"], dE_rel=rel("energy"), divB=t1["divB_norm"],
    g2=d.history[-1].get("g2"), note="outer r held fixed: mass can only change through the outer boundary flux, which is zero while the bump stays inside")

# S4 --------------------------------------------------------------------------------------------------------------
ck = os.path.join(HERE, "smk_ckpt")
cfg = D.Config(well_balanced=True, backend=BK, label="S4a")
a = D.Driver(cfg, D.ic_zpinch(perturb=bump())); a.run(nsteps=10)
cfg = D.Config(well_balanced=True, backend=BK, label="S4b")
b = D.Driver(cfg, D.ic_zpinch(perturb=bump())); b.run(nsteps=5); b.save(ck)
c = D.Driver(D.Config(well_balanced=True, backend=BK, label="S4c"), D.ic_zpinch(perturb=bump())); c.load(ck); c.run(nsteps=10)
rep("S4_restart_bitwise", maxdiff(a.U, c.U) == 0 and maxdiff(a.B, c.B) == 0 and a.t == c.t, max_dU=maxdiff(a.U, c.U), max_dB=maxdiff(a.B, c.B), t_a=a.t, t_c=c.t)

# S5 --------------------------------------------------------------------------------------------------------------
def ic_bad(d):
    x = D.ic_zpinch()(d); x["U"][0][5, 5, 5] = -1.0; return x
cfg = D.Config(backend=BK, label="S5 forced failure")
try:
    d = D.Driver(cfg, ic_bad); st = d.run(nsteps=3); ev = d.events[-1]
except D.AdmissibilityError as e:
    st, ev = "REFUSED_AT_START", str(e)
rep("S5_forced_failure", st in ("FAILED", "REFUSED_AT_START") and d.step == 0, status=st, event=ev)

# S6 --------------------------------------------------------------------------------------------------------------
def ic_blast(d):
    x = D.ic_zpinch()(d); G = d.GE; rc = G.r_centers[:, None, None]; zc = G.z_c[None, None, :]; ph = G.phi_c[None, :, None]
    xx, yy = rc * np.cos(ph) - 0.45, rc * np.sin(ph)
    hot = (xx ** 2 + yy ** 2 + (zc - 0.5) ** 2) < 0.15 ** 2
    p = (1 - 0.25 * rc ** 2) * np.ones(x["U"][0].shape); p = np.where(hot, 200.0, 1e-3 + 0 * p)
    x["U"][4] = p / (2 / 3) + 0.5 * (0.5 * rc) ** 2 * np.ones_like(p)        # E = p/(g-1) + B^2/2 (cell B_phi = r/2)
    return x
cfg = D.Config(backend=BK, cfl=0.4, label="S6 blast")
d = D.Driver(cfg, ic_blast); st = d.run(nsteps=30)
STATES["S6"] = d
rec = [e for e in d.events if e["event"] == "recovery_pass"]
tot = d.totals()
rep("S6_recovery", (st == "COMPLETED") or (st == "FAILED" and d.events[-1]["event"] in ("STOP", "FAILED")), status=st, steps=d.step, recovery_passes=len(rec),
    first_rec=rec[:2], last_event=d.events[-1] if d.events else None, divB=tot["divB_norm"])

# S7 --------------------------------------------------------------------------------------------------------------
cfg = D.Config(backend=BK, eta=0.01, hall=0.02, label="S7 resistive+Hall")
d = D.Driver(cfg, D.ic_zpinch(perturb=bump())); st = d.run(nsteps=10); t1 = d.totals(); STATES["S7"] = d
rep("S7_eta_hall", st == "COMPLETED" and t1["divB_norm"] < 1e-12, status=st, dt=d.history[-1]["dt"], divB=t1["divB_norm"])

# S8 --------------------------------------------------------------------------------------------------------------
cfg = D.Config(backend=BK, z_bc="outflow", label="S8 z outflow")
d = D.Driver(cfg, D.ic_zpinch(perturb=bump())); st = d.run(nsteps=10); t1 = d.totals()
rep("S8_z_outflow", st == "COMPLETED" and t1["divB_norm"] < 1e-12, status=st, divB=t1["divB_norm"])

# GPU = CPU comparison (reported here; the threshold-0 test belongs to DRV-01)
np.savez(os.path.join(HERE, f"smk00_states_{BK}.npz"), **{f"{k}_{i}": D._host(x) for k, d_ in STATES.items() for i, x in enumerate(d_.U + d_.B)})
other = os.path.join(HERE, "smk00_states_cpu.npz")
if BK == "cupy" and os.path.exists(other):
    o = np.load(other); mine = np.load(os.path.join(HERE, f"smk00_states_{BK}.npz"))
    R["GPU_vs_CPU"] = {k: float(np.abs(mine[k] - o[k]).max()) for k in o.files}
    for k in STATES: print(f"GPU vs CPU {k}: max |diff| = {max(v for kk, v in R['GPU_vs_CPU'].items() if kk.startswith(k + '_')):.3e}")
json.dump(D._jsonable(R), open(os.path.join(HERE, f"smk00_{BK}.json"), "w"), indent=1, default=str)
print(f"SMK-00 {BK}: {sum(v['ok'] for k, v in R.items() if k != 'GPU_vs_CPU')}/{len(R) - ('GPU_vs_CPU' in R)} PASS")
