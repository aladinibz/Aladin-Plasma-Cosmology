import sys, math; sys.argv=["x","cpu"]; sys.path.insert(0,".")
import drv01_addendum_A1 as A
errs=[]
for lv in [(4,8,16),(8,16,32),(16,32,64)]:
    e,n=A.decay(*lv); errs.append(e); print(lv, f"D03 rel err {e:.4e} steps {n}", flush=True)
print("orders:", [round(math.log2(errs[i]/errs[i+1]),3) for i in range(2)])
