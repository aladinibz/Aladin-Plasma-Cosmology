ALADIN Driver v4.0 2026-11-20 | backend cpu

grid 16x8x4 (axis grid, r in [0,1]), Driver well-balanced, fixed outer boundary:
  B_phi = 0.5 r          : set on the CT faces
  J_z = 1                : max |J_z - 1| = 4.4e-16   (J_r, J_phi max 0.0e+00)
  f_r = -0.5 r           : max |f_r + 0.5 r| = 2.2e-16   (f_phi, f_z max 0.0e+00)
  div B = 0              : max |div B| = 0.0e+00
  P = P0 - r^2/4         : max |P - exact| = 1.1e-16   (cell centres, from the Driver's PRIM)
  static, 100 CFL steps  : COMPLETED, t = 0.7605, max |U - U0| = 0.0e+00, max |B - B0| = 0.0e+00

grid 64x32x8 (axis grid, r in [0,1]), Driver well-balanced, fixed outer boundary:
  B_phi = 0.5 r          : set on the CT faces
  J_z = 1                : max |J_z - 1| = 2.0e-15   (J_r, J_phi max 0.0e+00)
  f_r = -0.5 r           : max |f_r + 0.5 r| = 1.0e-15   (f_phi, f_z max 0.0e+00)
  div B = 0              : max |div B| = 0.0e+00
  P = P0 - r^2/4         : max |P - exact| = 1.1e-16   (cell centres, from the Driver's PRIM)
  static, 100 CFL steps  : COMPLETED, t = 0.0475, max |U - U0| = 0.0e+00, max |B - B0| = 0.0e+00
