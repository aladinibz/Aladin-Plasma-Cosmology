# -*- coding: utf-8 -*-
"""The README reference benchmark (normalised Z-pinch, mu0 = 1) through ALADIN Driver v4.0 (its kernels, its grids, its fills):
   B_phi = r/2  ->  J_z = 1,  f_r = -r/2,  div B = 0,  P = P0 - r^2/4,  and the well-balanced Driver keeps it exactly static.
python readme_benchmark_driver.py [cpu|cupy]"""
import os, sys, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
import aladin_driver_v40 as D
BK = sys.argv[1] if len(sys.argv) > 1 else "cpu"; H = lambda a: np.asarray(D.host(a)); P0 = 1.0
print(D.VERSION, "| backend", BK)
for (nr, nphi, nz) in ((16, 8, 4), (64, 32, 8)):
    d = D.Driver(D.Config(nr=nr, nphi=nphi, nz=nz, backend=BK, well_balanced=True, label="README benchmark"), D.ic_zpinch(P0))
    G = d.GE; g = d.g; I = (slice(g, g + nr), slice(g, g + nphi), slice(g, g + nz)); rc = G.r_centers[g:g + nr][:, None, None]
    B = [H(x) for x in d.B]
    J, _ = d.UC.run_curl(*B, np.ascontiguousarray(G.r_faces), np.ascontiguousarray(G.r_centers), G.dr, G.dphi, G.dz, nr, nphi, nz, g, backend="cpu")
    J = [np.ascontiguousarray(a) for a in J]
    fr, fp, fz = d.E.lorentz_force(G, *B, J)
    pr = d.PR.primitives(d.GP, *[H(x) for x in d.U], *B, gamma=d.cfg.gamma, backend="cpu")
    divB = d.GL.monitor(d.GG, *B)["max_abs_div"]
    eJ = float(np.abs(J[2][I] - 1).max()); eJt = float(max(np.abs(J[0][I]).max(), np.abs(J[1][I]).max()))
    ef = float(np.abs(fr[I] + 0.5 * rc).max()); eft = float(max(np.abs(fp[I]).max(), np.abs(fz[I]).max()))
    eP = float(np.abs(pr["p"][I] - (P0 - 0.25 * rc ** 2)).max())
    U0 = [H(x).copy() for x in d.U]; B0 = [H(x).copy() for x in d.B]; st = d.run(nsteps=100)
    dU = max(float(np.abs(H(a)[I] - b[I]).max()) for a, b in zip(d.U, U0)); dB = max(float(np.abs(H(a) - b).max()) for a, b in zip(d.B, B0))
    print(f"\ngrid {nr}x{nphi}x{nz} (axis grid, r in [0,1]), Driver well-balanced, fixed outer boundary:")
    print(f"  B_phi = 0.5 r          : set on the CT faces")
    print(f"  J_z = 1                : max |J_z - 1| = {eJ:.1e}   (J_r, J_phi max {eJt:.1e})")
    print(f"  f_r = -0.5 r           : max |f_r + 0.5 r| = {ef:.1e}   (f_phi, f_z max {eft:.1e})")
    print(f"  div B = 0              : max |div B| = {divB:.1e}")
    print(f"  P = P0 - r^2/4         : max |P - exact| = {eP:.1e}   (cell centres, from the Driver's PRIM)")
    print(f"  static, 100 CFL steps  : {st}, t = {d.t:.4f}, max |U - U0| = {dU:.1e}, max |B - B0| = {dB:.1e}")
