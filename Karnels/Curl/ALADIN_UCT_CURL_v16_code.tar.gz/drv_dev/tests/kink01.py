# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0 -- DRV-02 test K01: the m = 1 KINK of the README Z-pinch.        python kink01.py cpu | gpu  [quick]
Reference, independent of the Driver: ORACLE-2 (oracle_cheb_pinch.py, Chebyshev collocation, axis parity; cross-checked against the
FD oracle on m = 0 to 7 digits, sound waves to 1e-15).  For the README pinch (rho = 1, B_phi = r/2, J_z = 1, P = 1 - r^2/4, mu0 = 1,
gamma = 5/3) inside a conducting wall at r = 1, the m = 1, k = 2 pi mode grows at  gamma_K = 0.4681760091  (converged to 10 digits).

THRESHOLDS -- declared 2026-11-22 and approved by the author before ANY Driver run of this test (no previews: the Driver has never
been run on the kink).  The 5 % level was chosen with the author: D07 needed 128 radial cells for 0.83 % on m = 0 (64: 5.2 %), the kink
also needs azimuthal resolution, and 128 x 64 x 128 costs hours of GPU time at the axis time step.
  K01_err      <= 0.05   relative growth-rate error at 64 x 32 x 64
  K01_order    >= 1.5    observed order 32x16x32 -> 64x32x64
  K01_monotone == 1      the error decreases at every refinement
  K01_purity   <= 0.01   kinetic energy outside (m, n) = +-(1, 1) / total kinetic energy, at t = 15, finest grid
  K01_gpu_cpu  == 0      values differing (FP64): levels 1 and 2 full runs + the finest level's first 500 steps, GPU leg vs CPU leg
Set-up: README pinch + eps x Re[mode(r) exp(i(phi + k z))], eps = 1e-5, k = 2 pi (z_len = 1), conducting wall, periodic z,
well-balanced.  rho, v, p: the mode at cell centres.  B: B_eq + curl A1 with A1 = (v1 x B0) / sigma = (-b v_z, 0, b v_r) / sigma
(ideal linear induction), put on the Driver's edges and curled by the Driver's own CT operator, so div B = 0 to round-off.
Measured: A(t) = sqrt(sum_r V_r |sum_{phi,z} v_r exp(-i(phi + k z))|^2), growth = slope of ln A over t in [2, 15] (least squares).
Levels refine r, phi and z together: 16x8x16, 32x16x32, 64x32x64.  CPU leg: levels 1 and 2 (informational growth) + the finest
level's first 500 steps (its full run would take ~12 h on a CPU); GPU leg: all three levels (verdict) + the comparisons.
"quick" = plumbing only (8x4x8, 10 steps): prints no growth rate, never reported.
CHANGE AFTER THE CPU LEG, BEFORE ANY GPU RESULT (harness only, thresholds unchanged; disclosed):
  K-b. (after GPU run 2, which completed: physics PASS, K01_gpu_cpu FAIL with 1 463 400 values differing at 1e-11 .. 1e-16 in EVERY
       array, from level 1 on).  The initial state is built from ORACLE-2's LAPACK eigenvector and a BLAS interpolation, which
       differ in the last bits between machines (DRV-01 change d, the same cause).  The initial states are now built once on the
       CPU-leg machine and frozen in kink01_frozen_ic.npz; the GPU leg loads them.  The CPU leg is unchanged (it built exactly
       these states).  The run-2 FAIL stays in the record.
  K-a. GPU run 1 crashed while BUILDING the initial state: ic_kink called the CPU CT operator with the Driver's grid, which on the
       GPU leg carries CuPy (r_faces became a GPU array).  The IC is now built on a host copy of the grid, and the initial div-B check
       uses the Driver's own (backend-aware) monitor instead of calling E-GLM with host arrays on a GPU grid.  On the CPU leg the grid
       already was the host grid: the CPU leg's states are unchanged (level 16x8x16 re-run after the fix: bit-identical).
"""
import os, sys, json, time, math, platform, datetime, traceback, copy
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT); sys.path.insert(0, HERE)
import aladin_driver_v40 as D
from managers import bundle_manager as BM, initial_conditions as IC
import oracle_cheb_pinch as O
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; BK = "cupy" if LEG == "gpu" else "cpu"; QUICK = "quick" in sys.argv[2:]
RUNS = os.path.join(HERE, f"runs_kink01_{LEG}{'_quick' if QUICK else ''}"); os.makedirs(RUNS, exist_ok=True)
H = lambda a: np.asarray(D.host(a))
TH = dict(K01_err=0.05, K01_order=1.5, K01_monotone=1.0, K01_purity=0.01, K01_gpu_cpu=0.0)
GAMMA_K = 0.4681760091; KZ = 2 * np.pi; EPS = 1e-5; T_FIT = (2.0, 15.0)
LEVELS = [(8, 4, 8)] if QUICK else [(16, 8, 16), (32, 16, 32), (64, 32, 64)]
SEG = 10 if QUICK else 500
MODE = O.eigenmode(91, 1, KZ)

def cfg(nr, nphi, nz): return D.Config(nr=nr, nphi=nphi, nz=nz, z_len=1.0, backend=BK, well_balanced=True, r_outer_bc="wall", label="DRV-02 K01")

FROZEN_IC = os.path.join(HERE, "kink01_frozen_ic.npz")              # change K-b: initial states frozen on the CPU-leg machine
def ic_kink(d):
    base = D.ic_zpinch(1.0)(d); key = f"{d.cfg.nr}x{d.cfg.nphi}x{d.cfg.nz}"
    if os.path.exists(FROZEN_IC):
        z = np.load(FROZEN_IC)
        if f"{key}_U0" in z.files:
            out = dict(base); out.update(U=[z[f"{key}_U{i}"] for i in range(5)], B=[z[f"{key}_B{i}"] for i in range(3)]); return out
    if LEG != "cpu": raise RuntimeError(f"{FROZEN_IC} has no frozen initial state {key}: the GPU leg must start from the CPU leg's states (K-b)")
    return build_ic(d, base)

def build_ic(d, base):
    G = d.GE; g = G.g; sig = complex(MODE["sigma"])
    ev = lambda n, r: MODE[n](np.clip(r, -1.0, 1.0))
    rc = G.r_centers; rf = G.r_faces
    ph = lambda phi, z: np.exp(1j * (phi[None, :, None] + KZ * z[None, None, :]))
    cell = lambda n: np.real(ev(n, rc)[:, None, None] * ph(G.phi_c, G.z_c))
    rho = 1 + EPS * cell("rho"); p = (1 - 0.25 * rc ** 2)[:, None, None] + EPS * cell("p")
    vr, vp, vz = EPS * cell("vr"), EPS * cell("vp"), EPS * cell("vz")
    # A1 = (v1 x B0)/sigma on the Driver's edges: Er at (r_c, phi_f, z_f), Ez at (r_f, phi_f, z_c); E = -A, dt = 1 -> B += curl A
    Ar = np.real((-(0.5 * rc) * ev("vz", rc) / sig)[:, None, None] * ph(G.phi_f, G.z_f)) * EPS
    Az = np.real(((0.5 * rf) * ev("vr", rf) / sig)[:, None, None] * ph(G.phi_f, G.z_c)) * EPS
    B = [x.copy() for x in base["B"]]; Er, Ep, Ez = -Ar, np.zeros(G.shape("Ephi")), -Az
    Gh = copy.copy(G); Gh.xp = np                                         # change K-a: the IC is always built on the host grid
    d.E.ct_update(Gh, *B, np.ascontiguousarray(Er), Ep, np.ascontiguousarray(Ez), 1.0, backend="cpu")
    out = dict(base); out.update(U=IC._conserved(d, rho, vr, vp, vz, p, B), B=B); return out

def amp(d):
    G = d.GE; g = d.g; nr, nphi, nz = d.cfg.nr, d.cfg.nphi, d.cfg.nz
    U = [H(x) for x in d.U]; vr = (U[1] / U[0])[g:g + nr, g:g + nphi, g:g + nz]
    w = np.exp(-1j * (G.phi_c[g:g + nphi][None, :, None] + KZ * G.z_c[g:g + nz][None, None, :]))
    a = (vr * w).sum(axis=(1, 2)) / (nphi * nz); V = 0.5 * (G.r_faces[g + 1:g + nr + 1] ** 2 - G.r_faces[g:g + nr] ** 2)
    return float(np.sqrt((V * np.abs(a) ** 2).sum()))

def purity(d):
    g = d.g; nr, nphi, nz = d.cfg.nr, d.cfg.nphi, d.cfg.nz; U = [H(x)[g:g + nr, g:g + nphi, g:g + nz] for x in d.U]
    tot = 0.0; inmode = 0.0
    for c in (1, 2, 3):
        v = U[c] / U[0]; F = np.fft.fft2(v, axes=(1, 2)); e = (np.abs(F) ** 2).sum(axis=0) * U[0].mean()
        tot += e.sum(); inmode += e[1, 1] + e[-1, -1]
    return float(1 - inmode / tot) if tot > 0 else float("nan")

def bundled(tid, thresholds, fn):
    rb = BM.RunBundle(RUNS, tid, thresholds=thresholds); data, measured = {}, {}
    try:
        with rb:
            data, measured = fn(rb)
            for k_, v in measured.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    return dict(id=tid, bundle=os.path.basename(rb.dir), verdict=res["verdict"], checks=res["checks"], data=data)

STATES = {}
def save(name, d):
    for i, x in enumerate(d.U + d.B): STATES[f"{name}_{i}"] = H(x).copy()

def run_level(lv, rb=None, nsteps=None):
    c = cfg(*lv); d = rb.driver(c, ic_kink) if rb else D.Driver(c, ic_kink)
    divB0 = float(d.totals()["divB_norm"])                               # K-a: the Driver's own monitor (backend-aware)
    ts, A = [0.0], [amp(d)]
    def rec(dd, r):
        if dd.step % 5 == 0 or (nsteps is None and dd.t >= T_FIT[1] - 1e-12): ts.append(dd.t); A.append(amp(dd))
    if rb: rb.run(t_end=None if nsteps else T_FIT[1], nsteps=nsteps, on_step=rec)
    else: d.run(t_end=None if nsteps else T_FIT[1], nsteps=nsteps, on_step=rec)
    return d, np.array(ts), np.array(A), divB0

def fit(ts, A):
    m = (ts >= T_FIT[0]) & (ts <= T_FIT[1] + 1e-12); return float(np.polyfit(ts[m], np.log(A[m]), 1)[0])

def K01():
    def fn(rb):
        rows = {}; errs = []
        levels = LEVELS if (LEG == "gpu" or QUICK) else LEVELS[:2]
        for lv in levels:
            t0 = time.time(); d, ts, A, dv = run_level(lv, rb=rb if lv == levels[-1] else None, nsteps=10 if QUICK else None)
            key = "x".join(map(str, lv)); save(f"K01_{key}", d)
            row = dict(steps=d.step, t=d.t, status=d.status, divB_initial=dv, seconds=round(time.time() - t0, 1))
            if not QUICK:
                gm = fit(ts, A); e = abs(gm - GAMMA_K) / GAMMA_K; errs.append(e)
                row.update(growth=gm, rel_err=e, purity=purity(d), A_start=float(A[0]), A_end=float(A[-1]))
                print(f"  K01 {key}: growth {gm:.6f} (exact {GAMMA_K}), rel err {e:.3e}, purity {row['purity']:.2e}, {d.step} steps, {row['seconds']} s", flush=True)
            rows[key] = row
        # the finest level's first SEG steps, for GPU = CPU
        fl = LEVELS[-1]; d = D.Driver(cfg(*fl), ic_kink); d.run(nsteps=SEG); save(f"K01_seg{SEG}", d)
        rows[f"segment_{SEG}"] = dict(steps=d.step, t=d.t, status=d.status)
        meas = {}
        if LEG == "gpu" and not QUICK:
            meas.update(K01_err=errs[-1], K01_order=math.log2(errs[-2] / errs[-1]), K01_monotone=float(all(errs[i + 1] < errs[i] for i in range(len(errs) - 1))),
                        K01_purity=rows["x".join(map(str, LEVELS[-1]))]["purity"])
            p = os.path.join(HERE, "kink01_states_cpu.npz")
            if not os.path.exists(p): raise RuntimeError("kink01_states_cpu.npz (the CPU leg's states) is missing")
            c = np.load(p); n = 0; diff = {}
            for k_ in c.files:
                if k_ not in STATES: diff[k_] = "missing"; n += 1; continue
                nd = int(((STATES[k_] != c[k_]) & ~(np.isnan(STATES[k_]) & np.isnan(c[k_]))).sum()); n += nd
                if nd: diff[k_] = dict(differing=nd, max_abs=float(np.nanmax(np.abs(STATES[k_] - c[k_]))))
            rows["gpu_vs_cpu"] = dict(arrays=len(c.files), differing=diff); meas["K01_gpu_cpu"] = float(n)
        return dict(levels=rows, gamma_exact=GAMMA_K, eps=EPS, t_fit=T_FIT), meas
    checks = {} if (LEG != "gpu" or QUICK) else dict(
        K01_err=("<=", TH["K01_err"], "m = 1 kink growth rate vs ORACLE-2 (0.4681760091), relative, 64x32x64"),
        K01_order=(">=", TH["K01_order"], "observed order 32x16x32 -> 64x32x64"),
        K01_monotone=("==", TH["K01_monotone"], "error decreases at every refinement"),
        K01_purity=("<=", TH["K01_purity"], "kinetic energy outside (m, n) = +-(1, 1), fraction, t = 15, 64x32x64"),
        K01_gpu_cpu=("<=", TH["K01_gpu_cpu"], "values differing GPU leg vs CPU leg (levels 1, 2 full; finest 500 steps), FP64"))
    return bundled("K01", checks, fn)

if __name__ == "__main__":
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, quick=QUICK, platform=platform.platform(), numpy=np.__version__)
    if BK == "cupy":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    print(f"DRV-02 K01 leg={LEG}{' QUICK (plumbing only)' if QUICK else ''} | {D.VERSION} | exact growth {GAMMA_K}", flush=True)
    t0 = time.time(); r = K01(); r["seconds"] = round(time.time() - t0, 1)
    print(f"K01 {r['verdict']}  " + "; ".join(f"{k}={c['value']:.3e} {c['op']} {c['threshold']:.1e} {c['result']}" for k, c in r["checks"].items() if isinstance(c.get("value"), (int, float))), flush=True)
    if "exception" in r["data"]: print(r["data"]["exception"])
    if QUICK: print("quick:", {k: {kk: vv for kk, vv in v.items() if kk in ("steps", "status", "divB_initial")} for k, v in r["data"].get("levels", {}).items()})
    json.dump(dict(campaign="DRV-02 K01", thresholds=TH, env=env, result=r), open(os.path.join(HERE, f"kink01_{LEG}{'_quick' if QUICK else ''}_results.json"), "w"), indent=1, default=float)
    if LEG == "cpu" and not QUICK: np.savez_compressed(os.path.join(HERE, "kink01_states_cpu.npz"), **STATES)
