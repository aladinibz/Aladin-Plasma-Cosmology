# -*- coding: utf-8 -*-
"""PROBE-K01: why K01 run 2 found GPU != CPU in every array.  Hypothesis (change K-b): the initial state differs between machines
(ORACLE-2's LAPACK eigenvector + BLAS interpolation), not the GPU.
 1. the initial state built HERE vs the frozen one built on the CPU-leg machine: values differing (expected > 0 if the hypothesis holds)
 2. level 16x8x16 from the FROZEN state, GPU here vs the CPU leg's final state: values differing (expected 0)
 3. the 64x32x64 500-step segment from the frozen state, GPU here vs the CPU leg: values differing (expected 0)
python probe_k01.py"""
import os, sys, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.argv = [sys.argv[0], "gpu"]
import kink01 as K, aladin_driver_v40 as D
c = np.load(os.path.join(HERE, "kink01_states_cpu.npz")); z = np.load(K.FROZEN_IC)
n = lambda a, b: int(((a != b) & ~(np.isnan(a) & np.isnan(b))).sum())
# 1: build the IC here (host, LAPACK + BLAS of this machine)
cpu = D.Config(nr=16, nphi=8, nz=16, z_len=1.0, backend="cpu", well_balanced=True, r_outer_bc="wall", label="probe")
dh = D.Driver(cpu, K.ic_kink)                                            # a host Driver (its own start state is the frozen one)
holder = K.build_ic(dh, D.ic_zpinch(1.0)(dh))                            # FRESH arrays built here, never touched by a ghost fill
d1 = sum(n(np.asarray(holder["U"][i]), z[f"16x8x16_U{i}"]) for i in range(5)) + sum(n(np.asarray(holder["B"][i]), z[f"16x8x16_B{i}"]) for i in range(3))
mx = max(float(np.abs(np.asarray(holder["U"][i]) - z[f"16x8x16_U{i}"]).max()) for i in range(5))
print(f"1. initial state built on THIS machine vs frozen (CPU-leg machine): {d1} values differ (max |diff| {mx:.1e})", flush=True)
# 2: level 1 on the GPU from the frozen state
d, ts, A, dv = K.run_level((16, 8, 16))
d2 = sum(n(K.H(x), c[f"K01_16x8x16_{i}"]) for i, x in enumerate(d.U + d.B))
print(f"2. 16x8x16 full run ({d.step} steps) on the GPU from the frozen state vs the CPU leg: {d2} values differ", flush=True)
# 3: the finest segment
d = D.Driver(K.cfg(64, 32, 64), K.ic_kink); d.run(nsteps=K.SEG)
d3 = sum(n(K.H(x), c[f"K01_seg{K.SEG}_{i}"]) for i, x in enumerate(d.U + d.B))
print(f"3. 64x32x64 first {K.SEG} steps on the GPU from the frozen state vs the CPU leg: {d3} values differ", flush=True)
