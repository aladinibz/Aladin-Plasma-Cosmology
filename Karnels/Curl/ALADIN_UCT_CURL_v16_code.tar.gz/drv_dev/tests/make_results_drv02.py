# -*- coding: utf-8 -*-
"""MakeResults for DRV-02 (K01, the m = 1 kink): DRV02_RESULTS.json from the raw outputs.  The run-1 / run-2 / probe console lines
were pasted from the GPU machine and are quoted verbatim (their bundles were not kept); run 3 is the qualifying run."""
import os, json, hashlib
HERE = os.path.dirname(os.path.abspath(__file__)); P = lambda *a: os.path.join(HERE, *a)
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
cpu = json.load(open(P("kink01_cpu_results.json"))); gpu = json.load(open(P("kink01_gpu_run3", "kink01_gpu_results.json")))
assert cpu["thresholds"] == gpu["thresholds"]
HIST = dict(
    run1="GPU run 1 (Tesla T4): K01 NOT QUALIFIED (CRASHED) while building the initial state: ic_kink called the CPU CT operator with the "
         "Driver's GPU grid ('ndarray' object has no attribute 'ctypes').  No physics ran.  Change K-a.",
    run2=["K01 16x8x16: growth 0.289205 (exact 0.4681760091), rel err 3.823e-01, purity 4.41e-03, 1973 steps, 85.1 s",
          "K01 32x16x32: growth 0.441313 (exact 0.4681760091), rel err 5.738e-02, purity 8.69e-04, 7896 steps, 305.0 s",
          "K01 64x32x64: growth 0.464741 (exact 0.4681760091), rel err 7.337e-03, purity 9.82e-05, 31597 steps, 1608.4 s",
          "K01 FAIL  K01_err=7.337e-03 <= 5.0e-02 PASS; K01_order=2.967e+00 >= 1.5e+00 PASS; K01_monotone=1.000e+00 == 1.0e+00 PASS; "
          "K01_purity=9.823e-05 <= 1.0e-02 PASS; K01_gpu_cpu=1.463e+06 <= 0.0e+00 FAIL",
          "gpu_vs_cpu: all 24 arrays differ, max |diff| 1e-11 .. 1e-16 (levels 1, 2 and the 500-step segment)"],
    probe=["1. initial state built on THIS machine vs frozen (CPU-leg machine): 18198 values differ (max |diff| 1.1e-16)",
           "2. 16x8x16 full run (1973 steps) on the GPU from the frozen state vs the CPU leg: 0 values differ",
           "3. 64x32x64 first 500 steps on the GPU from the frozen state vs the CPU leg: 0 values differ"])
files = {f: sha(P(f)) for f in ("kink01.py", "oracle_cheb_pinch.py", "probe_k01.py", "kink01_frozen_ic.npz", "kink01_states_cpu.npz", "make_results_drv02.py")}
R = dict(campaign="DRV-02", test="K01 m = 1 kink of the README pinch", thresholds=cpu["thresholds"], gamma_exact=0.4681760091,
         frozen_before_cpu_leg=open(P("kink01_frozen_before_cpu_leg.sha256")).read(),
         oracle2_selftest=open(P("oracle_cheb_selftest.txt")).read(), cpu_leg=cpu, gpu_run3=gpu, history=HIST,
         verdict=gpu["result"]["verdict"], files=files,
         bundle=sha(P("kink01_gpu_run3", "runs_kink01_gpu", gpu["result"]["bundle"] + ".zip")))
json.dump(R, open(P("DRV02_RESULTS.json"), "w"), indent=1, default=float)
print(R["verdict"], {k: v["value"] for k, v in gpu["result"]["checks"].items()})
