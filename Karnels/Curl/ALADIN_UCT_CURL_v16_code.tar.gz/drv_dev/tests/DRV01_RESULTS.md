# DRV-01 results (ALADIN Driver v4.0 2026-11-20)

Final: {'PASS': 9, 'FAIL': 4}

| test | CPU leg | GPU run 1 | GPU run 2 | final |
|---|---|---|---|---|
| D01 | PASS | PASS | PASS | PASS |
| D02 | PASS | PASS | PASS | PASS |
| D03 | FAIL | FAIL | FAIL | FAIL |
| D04 | FAIL | FAIL | FAIL | FAIL |
| D05 | PASS | PASS | PASS | PASS |
| D06 | FAIL | FAIL | FAIL | FAIL |
| D07 | PASS | NOT QUALIFIED (CRASHED) | PASS | PASS |
| D08 | PASS | PASS | PASS | PASS |
| D09 | PASS | NOT QUALIFIED (CRASHED) | PASS | PASS |
| D10 | PASS | NOT QUALIFIED (CRASHED) | PASS | PASS |
| D11 | — | FAIL | PASS | PASS |
| D12 | PASS | FAIL | PASS | PASS |
| D13 | FAIL | NOT QUALIFIED (CRASHED) | FAIL | FAIL |

A1 addendum (declared after the CPU leg; D03/D04/D06 stay FAIL): D03_cpu: err 6.424e-03, order 1.40, FAIL; D06_cpu: err 3.432e-04, order 0.85, FAIL; D04_gpu: err 3.168e-03, order 1.81, PASS
