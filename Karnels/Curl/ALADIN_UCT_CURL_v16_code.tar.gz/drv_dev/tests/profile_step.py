# -*- coding: utf-8 -*-
"""PROFILE-01: where does one Driver step spend its time?  Wraps (does not modify) the kernel entry points and the Driver's per-step
extras with timers (GPU: synchronised), runs N steps of a test problem, prints a table.
python profile_step.py cpu|cupy [nr nphi nz] [steps] [case]      case = hall (D04-like) | ideal (D06-like) | eta (D03-like)"""
import os, sys, time, collections, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
import aladin_driver_v40 as D
from managers import initial_conditions as IC
BK = sys.argv[1] if len(sys.argv) > 1 else "cpu"
nr, nphi, nz = (int(x) for x in sys.argv[2:5]) if len(sys.argv) > 4 else (16, 32, 64)
NS = int(sys.argv[5]) if len(sys.argv) > 5 else 50
CASE = sys.argv[6] if len(sys.argv) > 6 else "hall"
if BK == "cupy":
    import cupy as cp; sync = cp.cuda.Stream.null.synchronize
else:
    sync = lambda: None
T = collections.defaultdict(float); N = collections.defaultdict(int); depth = [0]

def wrap(obj, name, label):
    f = getattr(obj, name)
    def g(*a, **k):
        if depth[0]: return f(*a, **k)                                  # only the outermost timed call counts (no double counting)
        depth[0] += 1; sync(); t0 = time.perf_counter()
        try: return f(*a, **k)
        finally: sync(); T[label] += time.perf_counter() - t0; N[label] += 1; depth[0] -= 1
    setattr(obj, name, g)

K = 2 * np.pi
if CASE == "eta": cfg, ic = D.Config(nr=nr, nphi=nphi, nz=nz, eta=0.05, r_outer_bc="outflow", backend=BK), IC.ic_resistive_decay(K, 1e-3, p0=1.0)
else:
    hall = 0.1 if CASE == "hall" else 0.0
    cfg, ic = D.Config(nr=nr, nphi=nphi, nz=nz, hall=hall, r_outer_bc="outflow", backend=BK), IC.ic_circular_wave(K, 1e-2, hall=hall)
d = D.Driver(cfg, ic); d.run(nsteps=3)                                  # warm-up: compiles, allocates
for obj, name, label in [(d.PR, "primitives", "01 PRIM"), (d.H, "fluxes", "04-06 HLLD"), (d.RS, "residual", "07 RESIDUAL"),
                         (d.UC, "run_curl", "09 UCT-CURL"), (d.E, "compute_emf", "08 UCT-EMF"), (d.E, "ct_update", "11 CT update"),
                         (d.boundary, "fill", "boundary fill"), (d.pipeline, "poynting_divergence", "non-ideal Poynting"),
                         (d.timestep, "dt_cfl", "timestep (CFL)"), (d.diagnostics, "totals", "diagnostics totals (every step)"),
                         (d.memory, "usage", "memory usage (every step)")]:
    wrap(obj, name, label)
sync(); t0 = time.perf_counter(); d.run(nsteps=NS); sync(); wall = time.perf_counter() - t0
host = 0.0
for _ in range(5):                                                       # what a test harness pays to look at the state every step
    sync(); t1 = time.perf_counter(); [np.asarray(D.host(x)) for x in d.U + d.B]; host += time.perf_counter() - t1
host /= 5
print(f"PROFILE-01 {BK} {nr}x{nphi}x{nz} case={CASE}: {NS} steps, {wall / NS * 1e3:.2f} ms/step (Driver alone; tests add the host copy below)")
tot = sum(T.values())
for k in sorted(T, key=lambda k: -T[k]):
    print(f"  {k:34s} {T[k] / NS * 1e3:9.3f} ms/step  {100 * T[k] / wall:5.1f} %   ({N[k] / NS:.0f} calls/step)")
print(f"  {'other (integrator, checks, glue)':34s} {(wall - tot) / NS * 1e3:9.3f} ms/step  {100 * (wall - tot) / wall:5.1f} %")
print(f"  host copy of the whole state (a test's per-step look): {host * 1e3:.2f} ms  = {100 * host / (wall / NS):.0f} % of a Driver step")
