# -*- coding: utf-8 -*-
"""MakeResults for DRV-01: one DRV01_RESULTS.json (+ .md) from the raw outputs of every leg.  Nothing is typed by hand except
the probe lines KW-01/02/03 (pasted from the GPU machine's console, quoted verbatim) and the declared classifications."""
import os, json, hashlib, glob
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
P = lambda *a: os.path.join(HERE, *a)
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
legs = dict(cpu=json.load(open(P("drv01_cpu_results.json"))),
            gpu_run1=json.load(open(P("gpu_leg_run1", "drv01_gpu_results.json"))),
            gpu_run2=json.load(open(P("gpu_leg_run2", "drv01_gpu_results.json"))))
A1 = dict(D03_cpu=json.load(open(P("drv01_A1_cpu_D03.json")))["results"]["D03"],
          D06_cpu=json.load(open(P("drv01_A1_cpu_D06.json")))["results"]["D06"],
          D04_gpu=json.load(open(P("gpu_leg_run1", "drv01_A1_gpu_D04.json")))["results"]["D04"])
T = {k: {t["id"]: t for t in v["tests"]} for k, v in legs.items()}
th = {k: hashlib.sha256(json.dumps(v["thresholds"], sort_keys=True).encode()).hexdigest() for k, v in legs.items()}
assert len(set(th.values())) == 1, "thresholds differ between legs"
ids = ["D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10", "D11", "D12", "D13"]
final = {}
for i in ids:
    c, g = T["cpu"].get(i, {}).get("verdict"), T["gpu_run2"][i]["verdict"]
    if i == "D11": final[i] = g                                          # GPU leg only (needs both legs)
    elif i == "D12": final[i] = g                                        # the GPU pool measurement is the test; CPU RSS informational
    else:
        assert c == g, (i, c, g); final[i] = c
# every check value equal between CPU leg and GPU run 2 (except D02 totals: reduction order; D12: machine)
same = {}
for i in ids:
    if i in ("D11", "D12"): continue
    a, b = T["cpu"][i]["checks"], T["gpu_run2"][i]["checks"]
    same[i] = {k: (a[k]["value"] == b[k]["value"]) for k in a}
KW = dict(
    KW01="Colab, NVIDIA L4, 40 steps on D02 (wall pinch mode) and D04 (Hall wave nz16, branch +1): every kernel fed identical inputs "
         "IDENTICAL on GPU and CPU; lockstep Driver(cpu) vs Driver(gpu): no divergence.",
    KW02=["GPU != CPU first at step 924: max|diff| {'rho': 0.0, 'm_r': 8.673617379884035e-19, 'm_phi': 8.673617379884035e-19, 'm_z': 1.0842021724855044e-19, 'E': 0.0, 'Br': 1.734723475976807e-18, 'Bphi': 1.734723475976807e-18, 'Bz': 0.0}",
          "== D04 Hall wave nz64 branch-1: 2365 steps | GPU vs CPU (this machine): first differs at step 924 | this CPU vs reference CPU: IDENTICAL every step",
          "== D02 wall pinch mode (frozen eigenmode): 1000 steps | GPU vs CPU (this machine): IDENTICAL every step | this CPU vs reference CPU: IDENTICAL every step"],
    KW03=["PART 1 over 2365 states: b2 with ** differs CPU vs GPU in 358 steps (first 6); with x*x in 0 steps; fixed dt_cfl differs in 0 steps",
          "PART 2 fixed Driver, 2365 steps | GPU vs CPU: IDENTICAL every step | this CPU vs reference CPU (run-1 code): IDENTICAL every step"],
    eigen_fingerprint="Colab NumPy 2.4.6: sausage-mode sigma 0.28244909791611245; CPU-leg NumPy 2.5.3: 0.28244909791611117; cos/sin fingerprints identical")
files = {}
for f in ["aladin_driver_v40.py"] + [os.path.join("managers", x) for x in sorted(os.listdir(os.path.join(ROOT, "managers"))) if x.endswith(".py")] + \
         [os.path.join("kernels", x) for x in sorted(os.listdir(os.path.join(ROOT, "kernels"))) if x.endswith(".py")]:
    files[f] = sha(os.path.join(ROOT, f))
for f in ["drv01.py", "drv01_addendum_A1.py", "oracle_linear_pinch.py", "drv01_frozen_modes.npz", "drv01_states_cpu.npz", "readme_benchmark_driver.py",
          "probe_kw01.py", "probe_kw02.py", "probe_kw03.py"]:
    files["tests/" + f] = sha(P(f))
bundles = {}
for leg, d in (("cpu", "runs_drv01_cpu"), ("gpu_run2", os.path.join("gpu_leg_run2", "runs_drv01_gpu"))):
    for z in sorted(glob.glob(P(d, "*.zip"))): bundles[f"{leg}/{os.path.basename(z)}"] = sha(z)
R = dict(campaign="DRV-01", driver=legs["cpu"]["driver"], thresholds=legs["cpu"]["thresholds"], thresholds_sha256=th["cpu"],
         campaign_sha256={k: v["campaign_sha256"] for k, v in legs.items()},
         env={k: v["env"] for k, v in legs.items()}, kernels=legs["gpu_run2"]["kernels"],
         legs={k: v["tests"] for k, v in legs.items()}, addendum_A1=A1, final=final,
         counts={s: sum(v == s for v in final.values()) for s in set(final.values())}, cpu_vs_gpu_run2_values_equal=same, probes=KW,
         readme_benchmark=open(P("readme_benchmark_driver_cpu.txt")).read(), files=files, bundles=bundles)
json.dump(R, open(P("DRV01_RESULTS.json"), "w"), indent=1, default=float)
md = [f"# DRV-01 results ({R['driver']})", "", f"Final: {R['counts']}", "", "| test | CPU leg | GPU run 1 | GPU run 2 | final |", "|---|---|---|---|---|"]
for i in ids: md.append(f"| {i} | {T['cpu'].get(i, {}).get('verdict', '—')} | {T['gpu_run1'].get(i, {}).get('verdict', '—')} | {T['gpu_run2'][i]['verdict']} | {final[i]} |")
md += ["", "A1 addendum (declared after the CPU leg; D03/D04/D06 stay FAIL): " + "; ".join(f"{k}: err {v['err']:.3e}, order {v['order']:.2f}, {v['result']}" for k, v in A1.items())]
open(P("DRV01_RESULTS.md"), "w").write("\n".join(md) + "\n")
print("\n".join(md))
