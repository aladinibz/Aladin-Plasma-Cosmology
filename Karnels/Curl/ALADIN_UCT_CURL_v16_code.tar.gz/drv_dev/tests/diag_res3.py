import sys, numpy as np; sys.argv=["x","cpu"]; sys.path.insert(0,".")
import drv01 as C
D, IC, K = C.D, C.IC, C.K
eps=1e-3
for nr,nphi,nz in [(8,64,256),(16,64,256),(32,64,256),(64,64,256)]:
    d=D.Driver(C.cfg(nr=nr,nphi=nphi,nz=nz,eta=0.05,r_outer_bc="outflow"), IC.ic_resistive_decay(K,eps,p0=1.0))
    G=d.GE; g=d.g; B=[np.asarray(x).copy() for x in d.B]; U=[np.asarray(x).copy() for x in d.U]; d.fill(U,B)
    J,_=d.UC.run_curl(*B, np.ascontiguousarray(G.r_faces), np.ascontiguousarray(G.r_centers), G.dr, G.dphi, G.dz, nr, nphi, nz, g, backend="cpu")
    J=[np.asarray(a) for a in J]
    # edge positions: Jr (rc, phi_f, z_f), Jphi (r_f, phi_c, z_f), Jz (r_f, phi_f, z_c)  [as for E]
    bp = lambda z: eps*K*np.cos(K*z)          # b'(z): J = b' y-hat -> Jr = b' sin(phi), Jphi = b' cos(phi), Jz = 0
    rc=G.r_centers; rf=G.r_faces
    exr=bp(G.z_f)[None,None,:]*np.sin(G.phi_f)[None,:,None]*np.ones_like(rc)[:,None,None]
    exp_=bp(G.z_f)[None,None,:]*np.cos(G.phi_c)[None,:,None]*np.ones_like(rf)[:,None,None]
    sl=lambda a,i0: a[i0, g:g+nphi, g:g+nz]
    mx=eps*K
    print(f"{nr}x{nphi}x{nz}: Jr err ring1 {np.abs(sl(J[0],g)-sl(exr,g)).max()/mx:.2e} mid {np.abs(sl(J[0],g+nr//2)-sl(exr,g+nr//2)).max()/mx:.2e} | "
          f"Jphi err face1 {np.abs(sl(J[1],g+1)-sl(exp_,g+1)).max()/mx:.2e} axisface {np.abs(sl(J[1],g)-sl(exp_,g)).max()/mx:.2e} | Jz max ring-faces {np.abs(J[2][g:g+3, g:g+nphi, g:g+nz]).max()/mx:.2e}", flush=True)
