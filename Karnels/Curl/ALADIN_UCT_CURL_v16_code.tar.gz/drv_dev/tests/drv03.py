# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0 -- campaign DRV-03: JOINT refinement of the DRV-01 wave and decay tests (D03, D04, D06).
    python drv03.py cpu|gpu PART      PART = A (D03 + D06) | B (D04 branch +1) | C (D04 branch -1)      [quick]
Why: DRV-01 refined z only at a fixed 4x8 cross-section and D03, D04, D06 FAILED (kept).  Addendum A1 (post hoc) refined r, phi and z
together on levels 1-3 below.  DRV-03 turns that into a PREDECLARED test by adding level 4, which has never been run.
Levels (nr, nphi, nz): 1 (4, 8, 16)  2 (8, 16, 32)  3 (16, 32, 64)  4 (32, 64, 128).
Disclosed previews: levels 1-3 are exactly addendum A1 (D03 CPU: 8.43e-3, 1.69e-2, 6.42e-3; D04 GPU branch +1: 2.79e-2, 1.11e-2, 3.17e-3,
branch -1: 3.41e-2, 8.15e-3, 1.93e-3; D06 CPU: 5.04e-3, 6.19e-4, 3.43e-4).  Level 4 has never been run.

THRESHOLDS -- DRV-01's ORIGINAL thresholds, unchanged, approved by the author on 2026-11-22 before any level-4 run:
  <test>_err   <= 0.01   relative error at level 4 (D04: worst branch)       D03: decay rate vs eta k^2;  D04, D06: wave frequency
  <test>_order >= 1.8    observed order, level 3 -> level 4
  DRV03_gpu_cpu == 0     values differing (FP64), GPU leg vs CPU leg: levels 1 and 2 full runs + level 4's first 200 steps (every part)
Physics, set-up and measurement: identical to drv01.py (imported unmodified: same initial conditions, same transverse-amplitude
measurement, same fits, same t_end).  The verdict needs level 4 and is evaluated on the GPU leg; the CPU leg runs levels 1-2 in full
(informational) and level 4's first 200 steps (a full CPU level 4 would take days).  "quick" = plumbing (level 1, 10 steps; no numbers).
"""
import os, sys, json, time, math, platform, datetime, traceback
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; PART = sys.argv[2] if len(sys.argv) > 2 else "A"; QUICK = "quick" in sys.argv[3:]
sys.argv = [sys.argv[0], LEG]
import drv01 as C                                                         # the DRV-01 harness, unmodified (cfg, ICs, measurements)
D, IC, K, BM = C.D, C.IC, C.K, C.BM
BK = C.BK; H = C.H
LEVELS = [(4, 8, 16), (8, 16, 32), (16, 32, 64), (32, 64, 128)]
TH = dict(D03_err=0.01, D03_order=1.8, D04_err=0.01, D04_order=1.8, D06_err=0.01, D06_order=1.8, DRV03_gpu_cpu=0.0)
SEG = 10 if QUICK else 200
PARTS = dict(A=[("D03", None), ("D06", +1)], B=[("D04", +1)], C=[("D04", -1)])
RUNS = os.path.join(HERE, f"runs_drv03_{LEG}{'_quick' if QUICK else ''}"); os.makedirs(RUNS, exist_ok=True)
STATES = {}

def make(test, br, lv):
    nr, nphi, nz = lv
    if test == "D03":
        return C.cfg(nr=nr, nphi=nphi, nz=nz, eta=0.05, r_outer_bc="outflow"), IC.ic_resistive_decay(K, 1e-3, p0=1.0), 0.5, None
    hall = 0.1 if test == "D04" else 0.0
    ic = IC.ic_circular_wave(K, 1e-2, hall=hall, branch=br)
    return C.cfg(nr=nr, nphi=nphi, nz=nz, hall=hall, r_outer_bc="outflow"), ic, 2 * np.pi / abs(ic.omega), ic.omega

def run(test, br, lv, rb=None, nsteps=None):
    c, ic, t_end, w = make(test, br, lv); d = rb.driver(c, ic) if rb else D.Driver(c, ic)
    ts, y = [0.0], [C.transverse_amp(d, K)]
    def rec(dd, r): ts.append(dd.t); y.append(C.transverse_amp(dd, K))
    kw = dict(nsteps=nsteps) if nsteps else dict(t_end=t_end)
    (rb.run(on_step=rec, **kw) if rb else d.run(on_step=rec, **kw))
    ts = np.array(ts); y = np.array(y)
    if nsteps: return d, None
    if test == "D03":
        rate = -np.polyfit(ts, np.log(np.abs(y)), 1)[0]; err = abs(rate - 0.05 * K * K) / (0.05 * K * K)
    else:
        wm = -np.polyfit(ts, np.unwrap(np.angle(y)), 1)[0]; err = abs(wm - w) / abs(w)
    return d, err

def save(name, d):
    for i, x in enumerate(d.U + d.B): STATES[f"{name}_{i}"] = H(x).copy()

def part(rb):
    data, meas = {}, {}
    for test, br in PARTS[PART]:
        tag = test + ("" if br is None else f"_b{br:+d}"); rows = {}; errs = []
        levels = LEVELS[:1] if QUICK else (LEVELS if LEG == "gpu" else LEVELS[:2])
        for lv in levels:
            t0 = time.time(); d, e = run(test, br, lv, rb=rb if lv == LEVELS[-1] else None, nsteps=10 if QUICK else None)
            key = "x".join(map(str, lv)); save(f"{tag}_{key}", d); rows[key] = dict(steps=d.step, t=d.t, seconds=round(time.time() - t0, 1), status=d.status)
            if not QUICK:
                rows[key]["rel_err"] = e; errs.append(e)
                print(f"  {tag} {key}: rel err {e:.4e}, {d.step} steps, {rows[key]['seconds']} s", flush=True)
        d, _ = run(test, br, LEVELS[-1], nsteps=SEG); save(f"{tag}_seg{SEG}", d); rows[f"segment_{SEG}"] = dict(steps=d.step, t=d.t)
        data[tag] = rows
        if LEG == "gpu" and not QUICK:
            meas[f"{test}_err"] = max(meas.get(f"{test}_err", 0.0), errs[-1])
            o = math.log2(errs[-2] / errs[-1]); meas[f"{test}_order"] = min(meas.get(f"{test}_order", 99.0), o)
    if LEG == "gpu" and not QUICK:
        p = os.path.join(HERE, f"drv03_states_cpu_{PART}.npz")
        if not os.path.exists(p): raise RuntimeError(f"{p} (the CPU leg's states for part {PART}) is missing")
        c = np.load(p); n = 0; diff = {}
        for k_ in c.files:
            if k_ not in STATES: diff[k_] = "missing"; n += 1; continue
            nd = int(((STATES[k_] != c[k_]) & ~(np.isnan(STATES[k_]) & np.isnan(c[k_]))).sum()); n += nd
            if nd: diff[k_] = dict(differing=nd, max_abs=float(np.nanmax(np.abs(STATES[k_] - c[k_]))))
        data["gpu_vs_cpu"] = dict(arrays=len(c.files), differing=diff); meas["DRV03_gpu_cpu"] = float(n)
    return data, meas

MEANING = dict(D03_err="resistive decay rate vs eta k^2, relative, level 4 (32x64x128)", D03_order="observed order, level 3 -> 4",
               D04_err="Hall wave frequency, relative, level 4, worst branch of this part", D04_order="observed order, level 3 -> 4",
               D06_err="Alfven wave frequency, relative, level 4", D06_order="observed order, level 3 -> 4",
               DRV03_gpu_cpu="values differing GPU vs CPU leg (levels 1, 2 full; level 4 first 200 steps), FP64")

if __name__ == "__main__":
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, part=PART, quick=QUICK, platform=platform.platform(), numpy=np.__version__)
    if BK == "cupy":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    print(f"DRV-03 part {PART} leg={LEG}{' QUICK (plumbing only)' if QUICK else ''} | {D.VERSION} | {env.get('gpu', 'CPU')}", flush=True)
    keys = sorted({k for t, _ in PARTS[PART] for k in (f"{t}_err", f"{t}_order")}) + ["DRV03_gpu_cpu"]
    checks = {} if (LEG != "gpu" or QUICK) else {k: (">=" if k.endswith("order") else "<=", TH[k], MEANING[k]) for k in keys}
    rb = BM.RunBundle(RUNS, f"DRV03_{PART}", thresholds=checks); data, meas = {}, {}
    try:
        with rb:
            data, meas = part(rb)
            for k_, v in meas.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    print(f"DRV03_{PART} {res['verdict']}  " + "; ".join(f"{k}={c['value']:.3e} {c['op']} {c['threshold']:g} {c['result']}" for k, c in res["checks"].items() if isinstance(c.get("value"), (int, float))), flush=True)
    if "exception" in data: print(data["exception"])
    json.dump(dict(campaign="DRV-03", part=PART, thresholds=TH, env=env, verdict=res["verdict"], checks=res["checks"], data=data, bundle=os.path.basename(rb.dir)),
              open(os.path.join(HERE, f"drv03_{LEG}_{PART}{'_quick' if QUICK else ''}_results.json"), "w"), indent=1, default=float)
    if LEG == "cpu" and not QUICK: np.savez_compressed(os.path.join(HERE, f"drv03_states_cpu_{PART}.npz"), **STATES)
