"""CURL-08 GPU leg wrapper (Colab): preflight -> curl08.py gpu -> autopack -> Drive copy.  The frozen harness curl08.py is not modified."""
import os, sys, subprocess, glob
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import campaign_safety as CS
need = [os.path.join(HERE, f) for f in ("curl08.py", "axj01.py", "curl08_states_cpu_sha256.json", "curl08_frozen_before_cpu_leg.sha256")]
CS.preflight(need, os.path.join(HERE, "curl08_gpu_results.json"), "resume" in sys.argv)
rc = subprocess.call([sys.executable, os.path.join(HERE, "curl08.py"), "gpu"], cwd=HERE)
out = "/content/CURL08_gpu.tar.gz" if os.path.isdir("/content") else os.path.join(HERE, "CURL08_gpu.tar.gz")
CS.autopack(out, ["runs_curl08_gpu", "curl08_gpu_results.json", "curl08_frozen_before_cpu_leg.sha256"], HERE)
if os.path.isdir("/content/drive/MyDrive"):
    import shutil; os.makedirs(CS.DRIVE_DIR, exist_ok=True); shutil.copy2(out, CS.DRIVE_DIR); print("DRIVE: copied to", CS.DRIVE_DIR)
sys.exit(rc)
