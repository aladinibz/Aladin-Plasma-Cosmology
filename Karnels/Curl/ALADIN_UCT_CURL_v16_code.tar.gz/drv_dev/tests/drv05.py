# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0.2-dev -- campaign DRV-05: the Driver tests touched by RESIDUAL v01.1, re-run on v01.1 with their ORIGINAL thresholds.
    python drv05.py cpu|gpu PART [quick] [resume]        PART = K  (A, B, C follow in this file later, each frozen before its own run)
Why: RESIDUAL v01.1 (10.5281/zenodo.24498958) corrected the angular-momentum term next to the axis; every non-axisymmetric Driver
result computed with v01 changes.  DRV-05 re-runs them unchanged in physics, set-up, measurement and thresholds, so v01 and v01.1 are
compared on equal terms.

PART K -- K01, the m = 1 kink of the README Z-pinch (DRV-02 test K01, tests/kink01.py, imported unmodified: same frozen initial states
kink01_frozen_ic.npz, same ORACLE-2 reference gamma_K = 0.4681760091, same amplitude measurement and fit over t in [2, 15]).
  Levels 16x8x16, 32x16x32, 64x32x64.  v01 result (DRV-02 run 3, Tesla T4): rel err 0.7337 % at 64x32x64, order 2.967, PASS.
THRESHOLDS -- K01's ORIGINAL thresholds (approved 2026-11-22), unchanged; DRV-05 approved by the author 2026-11-24 ("lets gooo"):
  K01_err      <= 0.05   relative growth-rate error at 64x32x64
  K01_order    >= 1.5    observed order 32x16x32 -> 64x32x64
  K01_monotone == 1      the error decreases at every refinement
  K01_purity   <= 0.01   kinetic energy outside (m, n) = +-(1, 1) / total, t = 15, finest grid
  K01_gpu_cpu  == 0      ARRAYS whose SHA-256 differs, GPU leg vs CPU leg: levels 1, 2 (final states) + the finest level's first 500 steps
                         (DRV-02 compared values; equal SHA-256 <=> every value bit-identical, so the threshold keeps its meaning --
                          the hashes replace shipping 2.5 MB of CPU states, as in CURL-07 C06)
DISCLOSED PREVIEW: the checkpoint/resume self-test (before the freeze) ran level 1 (16x8x16) on the CPU twice, once interrupted at step
900 and resumed: growth 0.289803 both times, bit-identical states (v01: 0.289205).  Levels 2 and 3 had never been run with v01.1.
Legs: CPU leg here (levels 1, 2 in full, informational + the 500-step segment), GPU leg on a free Colab T4 (all three levels, verdict).
SAFETY (tests/campaign_safety.py, rules of 24 Nov 2026): PREFLIGHT at minute 0 (the GPU leg refuses to start without the CPU hashes and
the frozen initial states); NO OVERWRITE (a part with saved progress needs 'resume'); a CHECKPOINT every 20 min inside each level and a
progress file after each level ('resume' continues bit-identically); DRIVE sync after every level when Google Drive is mounted; AUTOPACK
of the part's evidence at the end.
"""
import os, sys, json, time, math, platform, datetime, traceback, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; PART = sys.argv[2] if len(sys.argv) > 2 else "K"
QUICK = "quick" in sys.argv[3:]; RESUME = "resume" in sys.argv[3:]
sys.argv = [sys.argv[0], LEG] + (["quick"] if QUICK else [])
import kink01 as KK                                                    # DRV-02 K01 harness, unmodified
import campaign_safety as CS
D, BM, H = KK.D, KK.BM, KK.H
TAG = f"{LEG}_{PART}{'_quick' if QUICK else ''}"
PROG = os.path.join(HERE, f"drv05_progress_{TAG}.json"); CK = lambda key: os.path.join(HERE, f"drv05_ckpt_{TAG}_{key}")
CPU_SHA = os.path.join(HERE, f"drv05_cpu_{PART}_sha256.json"); CK_EVERY = 20 * 60
TH = dict(K01_err=0.05, K01_order=1.5, K01_monotone=1.0, K01_purity=0.01, K01_gpu_cpu=0.0)
DRIVE = os.path.isdir("/content/drive/MyDrive")


def sha_arrays(d): return [hashlib.sha256(np.ascontiguousarray(H(a)).tobytes()).hexdigest() for a in d.U + d.B]
def sync():
    if DRIVE:
        try: print(f"  drive sync: {CS.drive_sync(HERE, 'DRV05')} files", flush=True)
        except Exception as e: print(f"  drive sync failed (run continues): {e}", flush=True)


def run_level_K(lv, rb=None, nsteps=None):
    """kink01.run_level + checkpoints every 20 min (the amplitude series is saved with the state)"""
    key = "x".join(map(str, lv)) + (f"_seg{nsteps}" if nsteps else ""); c = KK.cfg(*lv); c.label = "DRV-05 K01"
    d = rb.driver(c, KK.ic_kink) if rb else D.Driver(c, KK.ic_kink)
    divB0 = float(d.totals()["divB_norm"]); ts, A = [0.0], [KK.amp(d)]; ck = CK(key); resumed = None
    if RESUME and os.path.exists(ck + ".npz"):
        d.load(ck); s = json.load(open(ck + "_series.json")); ts, A = s["ts"], s["A"]; resumed = d.step
        print(f"  K01 {key}: RESUMED from checkpoint at step {d.step}, t = {d.t:.4f}", flush=True)
    last = [time.time()]
    def rec(dd, r):
        if dd.step % 5 == 0 or (nsteps is None and dd.t >= KK.T_FIT[1] - 1e-12): ts.append(dd.t); A.append(KK.amp(dd))
        if time.time() - last[0] > CK_EVERY:
            dd.save(ck); json.dump(dict(ts=ts, A=A), open(ck + "_series.json", "w")); last[0] = time.time(); sync()
            print(f"  K01 {key}: checkpoint at step {dd.step}, t = {dd.t:.4f} ({100 * dd.t / KK.T_FIT[1]:.1f} %)", flush=True)
    kw = dict(nsteps=nsteps) if nsteps else dict(t_end=KK.T_FIT[1])
    if nsteps and resumed is not None: kw = dict(nsteps=nsteps - d.step)
    (rb.run if rb else d.run)(on_step=rec, **kw)
    for ext in (".npz", ".json", "_series.json"):
        if os.path.exists(ck + ext): os.remove(ck + ext)
    return d, np.array(ts), np.array(A), divB0, resumed


def part_K(rb):
    prog = json.load(open(PROG)) if (RESUME and os.path.exists(PROG)) else dict(levels={})
    levels = KK.LEVELS if (LEG == "gpu" or QUICK) else KK.LEVELS[:2]
    for lv in levels:
        key = "x".join(map(str, lv))
        if key in prog["levels"]: print(f"  K01 {key}: done before (progress file), skipped", flush=True); continue
        t0 = time.time(); d, ts, A, dv, res = run_level_K(lv, rb=rb if lv == levels[-1] else None, nsteps=10 if QUICK else None)
        row = dict(steps=d.step, t=d.t, status=d.status, divB_initial=dv, seconds=round(time.time() - t0, 1), resumed_from_step=res, sha256=sha_arrays(d))
        if not QUICK:
            gm = KK.fit(ts, A); e = abs(gm - KK.GAMMA_K) / KK.GAMMA_K
            row.update(growth=gm, rel_err=e, purity=KK.purity(d), A_start=float(A[0]), A_end=float(A[-1]))
            print(f"  K01 {key}: growth {gm:.6f} (exact {KK.GAMMA_K}), rel err {e:.4e}, purity {row['purity']:.2e}, {d.step} steps, {row['seconds']} s", flush=True)
        prog["levels"][key] = row; json.dump(prog, open(PROG, "w"), indent=1, default=float); sync()
    sk = f"segment_{KK.SEG}"
    if sk not in prog["levels"]:
        d, *_ = run_level_K(KK.LEVELS[-1], nsteps=KK.SEG)
        prog["levels"][sk] = dict(steps=d.step, t=d.t, status=d.status, sha256=sha_arrays(d)); json.dump(prog, open(PROG, "w"), indent=1, default=float)
    data, meas = dict(levels=prog["levels"], gamma_exact=KK.GAMMA_K, t_fit=KK.T_FIT), {}
    if LEG == "gpu" and not QUICK:
        errs = [prog["levels"]["x".join(map(str, lv))]["rel_err"] for lv in KK.LEVELS]
        meas.update(K01_err=errs[-1], K01_order=math.log2(errs[-2] / errs[-1]), K01_monotone=float(all(errs[i + 1] < errs[i] for i in range(2))),
                    K01_purity=prog["levels"]["x".join(map(str, KK.LEVELS[-1]))]["purity"])
        ref = json.load(open(CPU_SHA)); n = 0; diff = {}
        for k_, hs in ref.items():
            mine = prog["levels"].get(k_, {}).get("sha256"); nd = len(hs) if mine is None else sum(a != b for a, b in zip(hs, mine)); n += nd
            if nd: diff[k_] = nd
        data["gpu_vs_cpu"] = dict(compared=list(ref), differing=diff); meas["K01_gpu_cpu"] = float(n)
    return data, meas


if __name__ == "__main__":
    if PART != "K": print(f"PART {PART} is not in this frozen version of drv05.py (only K)"); sys.exit(2)
    need = [os.path.join(HERE, "kink01_frozen_ic.npz")] + ([CPU_SHA] if (LEG == "gpu" and not QUICK) else [])
    CS.preflight(need, PROG, RESUME)
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, part=PART, quick=QUICK, resume=RESUME,
               platform=platform.platform(), numpy=np.__version__, drive=DRIVE)
    if LEG == "gpu":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    print(f"DRV-05 part {PART} leg={LEG}{' QUICK' if QUICK else ''}{' RESUME' if RESUME else ''} | {D.VERSION} | {env.get('gpu', 'CPU')} | RESIDUAL v01.1 | exact growth {KK.GAMMA_K}", flush=True)
    checks = {} if (LEG != "gpu" or QUICK) else dict(
        K01_err=("<=", TH["K01_err"], "m = 1 kink growth rate vs ORACLE-2 (0.4681760091), relative, 64x32x64"),
        K01_order=(">=", TH["K01_order"], "observed order 32x16x32 -> 64x32x64"),
        K01_monotone=("==", TH["K01_monotone"], "error decreases at every refinement"),
        K01_purity=("<=", TH["K01_purity"], "kinetic energy outside (m, n) = +-(1, 1), fraction, t = 15, 64x32x64"),
        K01_gpu_cpu=("<=", TH["K01_gpu_cpu"], "arrays whose SHA-256 differs GPU leg vs CPU leg (levels 1, 2; finest 500 steps)"))
    rb = BM.RunBundle(os.path.join(HERE, f"runs_drv05_{TAG}"), f"DRV05_{PART}", thresholds=checks, meta=dict(header=__doc__)); data, meas = {}, {}
    try:
        with rb:
            data, meas = part_K(rb)
            for k_, v in meas.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    print(f"DRV05_{PART} {res['verdict']}  " + "; ".join(f"{k}={c['value']:.4e} {c['op']} {c['threshold']:g} {c['result']}" for k, c in res["checks"].items() if isinstance(c.get("value"), (int, float))), flush=True)
    if "exception" in data: print(data["exception"])
    out = os.path.join(HERE, f"drv05_{TAG}_results.json")
    json.dump(dict(campaign="DRV-05", part=PART, thresholds=TH, env=env, verdict=res["verdict"], checks=res["checks"], data=data, bundle=os.path.basename(rb.dir)), open(out, "w"), indent=1, default=float)
    if LEG == "cpu" and not QUICK and "levels" in data:
        json.dump({k: v["sha256"] for k, v in data["levels"].items() if "sha256" in v}, open(CPU_SHA, "w"), indent=1)
    sync()
    if not QUICK:
        CS.autopack(f"/content/DRV05_{TAG}.tar.gz" if os.path.isdir("/content") else os.path.join(HERE, f"DRV05_{TAG}.tar.gz"),
                    [f"runs_drv05_{TAG}", f"drv05_{TAG}_results.json", f"drv05_progress_{TAG}.json"], HERE)
