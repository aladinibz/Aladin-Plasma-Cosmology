# -*- coding: utf-8 -*-
"""
DRV-01 D07 ORACLE -- linear ideal-MHD stability of a static cylindrical pinch, written independently of the ALADIN Driver
(no Driver or kernel code is imported).  Equilibrium: rho0(r), p0(r), B0 = B_phi(r) phi-hat (B_z = 0), mu0 = 1.
Perturbations ~ f(r) exp(i m phi + i k z + sigma t).  Linearised equations (static equilibrium, J0 = J_z0 z-hat):
  d rho1/dt = -(rho0' v_r + rho0 div v)
  rho0 dv/dt = -grad p1 + J0 x B1 + J1 x B0
  d p1/dt   = -v_r p0' - gamma p0 div v
  d B1/dt   = curl(v x B0)
Discretisation: second-order finite differences on a STAGGERED radial grid (v_r, B_r on faces r_j = j h; the rest on
centres), rigid conducting wall at r = 1 (v_r = B_r = 0), regularity at the axis (v_r = B_r = 0 on the axis face for m != 1).
The matrix L of the semi-discrete system dU/dt = L U is built explicitly; its eigenvalues sigma are computed with LAPACK
(numpy.linalg.eigvals).  The growth rate is max Re(sigma) over modes with |Im sigma| small (a static equilibrium has real
sigma^2: unstable modes have real sigma).  Convergence in N is part of the oracle's output.
"""
import numpy as np


def readme_pinch(P0=1.0):
    """README normalised Z-pinch: rho = 1, B_phi = r/2, J_z = 1, P = P0 - r^2/4"""
    return dict(rho=lambda r: np.ones_like(r), drho=lambda r: np.zeros_like(r), b=lambda r: 0.5 * r, jz=lambda r: np.ones_like(r),
                p=lambda r: P0 - 0.25 * r ** 2, dp=lambda r: -0.5 * r)


def operator(N, m, k, eq, gamma=5 / 3):
    """the matrix L (complex) of the staggered semi-discrete linear system; unknowns:
    vr[1..N-1], Br[1..N-1] on faces;  rho1, vphi, vz, p1, Bphi, Bz on the N centres"""
    if m == 1: raise NotImplementedError("m = 1 needs the axis-face unknown (v_r(0) != 0); not implemented")
    h = 1.0 / N; rf = np.arange(N + 1) * h; rc = (np.arange(N) + 0.5) * h
    nf = N - 1
    names = ["vr", "Br", "rho", "vp", "vz", "p", "Bp", "Bz"]; size = dict(vr=nf, Br=nf, rho=N, vp=N, vz=N, p=N, Bp=N, Bz=N)
    off = {}; o = 0
    for n_ in names: off[n_] = o; o += size[n_]
    L = np.zeros((o, o), complex)
    I = 1j
    def add(row_var, i, col_var, j, val):
        if col_var in ("vr", "Br"):
            if j <= 0 or j >= N: return                                     # axis and wall faces: v_r = B_r = 0
            L[off[row_var] + (i - 1 if row_var in ("vr", "Br") else i), off[col_var] + j - 1] += val
        else:
            L[off[row_var] + (i - 1 if row_var in ("vr", "Br") else i), off[col_var] + j] += val
    rho0c, b_c, p0c, dp0c, jzc = eq["rho"](rc), eq["b"](rc), eq["p"](rc), eq["dp"](rc), eq["jz"](rc)
    rho0f, b_f, jzf = eq["rho"](rf), eq["b"](rf), eq["jz"](rf)
    drho_c = eq["drho"](rc)
    # ---------------- face equations (j = 1 .. N-1): vr, Br
    for j in range(1, N):
        r = rf[j]; cL, cR = j - 1, j                                         # centres left / right of face j
        # rho0 dvr/dt = -p1' - Jz0 Bphi1 - J1z b ,  J1z = (1/r)(r Bphi1)' - i m Br1 / r
        f = 1.0 / rho0f[j]
        add("vr", j, "p", cR, -f / h); add("vr", j, "p", cL, +f / h)
        add("vr", j, "Bp", cR, -f * jzf[j] * 0.5); add("vr", j, "Bp", cL, -f * jzf[j] * 0.5)
        add("vr", j, "Bp", cR, -f * b_f[j] * rc[cR] / (r * h)); add("vr", j, "Bp", cL, +f * b_f[j] * rc[cL] / (r * h))
        add("vr", j, "Br", j, +f * b_f[j] * I * m / r)
        # dBr/dt = i m vr b / r
        add("Br", j, "vr", j, I * m * b_f[j] / r)
    # ---------------- centre equations (i = 0 .. N-1)
    for i in range(N):
        r = rc[i]; fL, fR = i, i + 1                                         # faces left / right of centre i
        # div v = (1/r)(r vr)' + i m vphi / r + i k vz
        def divv(row, coef):
            add(row, i, "vr", fR, coef * rf[fR] / (r * h)); add(row, i, "vr", fL, -coef * rf[fL] / (r * h))
            add(row, i, "vp", i, coef * I * m / r); add(row, i, "vz", i, coef * I * k)
        # d rho1/dt = -rho0' vr - rho0 div v
        add("rho", i, "vr", fR, -drho_c[i] * 0.5); add("rho", i, "vr", fL, -drho_c[i] * 0.5); divv("rho", -rho0c[i])
        # rho0 dvphi/dt = -i m p1 / r + Jz0 Br1
        f = 1.0 / rho0c[i]
        add("vp", i, "p", i, -f * I * m / r); add("vp", i, "Br", fR, f * jzc[i] * 0.5); add("vp", i, "Br", fL, f * jzc[i] * 0.5)
        # rho0 dvz/dt = -i k p1 + J1r b ,  J1r = i m Bz1 / r - i k Bphi1
        add("vz", i, "p", i, -f * I * k); add("vz", i, "Bz", i, f * b_c[i] * I * m / r); add("vz", i, "Bp", i, -f * b_c[i] * I * k)
        # dp1/dt = -vr p0' - gamma p0 div v
        add("p", i, "vr", fR, -dp0c[i] * 0.5); add("p", i, "vr", fL, -dp0c[i] * 0.5); divv("p", -gamma * p0c[i])
        # dBphi/dt = -i k vz b - (vr b)'
        add("Bp", i, "vz", i, -I * k * b_c[i]); add("Bp", i, "vr", fR, -b_f[fR] / h); add("Bp", i, "vr", fL, +b_f[fL] / h)
        # dBz/dt = i m vz b / r
        add("Bz", i, "vz", i, I * m * b_c[i] / r)
    return L, off


def growth_rate(N, m, k, eq=None, gamma=5 / 3, imag_tol=1e-6):
    eq = eq or readme_pinch()
    L, _ = operator(N, m, k, eq, gamma)
    s = np.linalg.eigvals(L)
    real = s[np.abs(s.imag) <= imag_tol * max(1.0, np.abs(s).max())]
    return float(real.real.max()) if real.size else 0.0, s


if __name__ == "__main__":
    for k in (1.0, 2 * np.pi, 4 * np.pi, 8 * np.pi):
        out = []
        for N in (50, 100, 200):
            g, s = growth_rate(N, 0, k); out.append(g)
        print(f"m=0 k={k:7.3f}: growth N=50,100,200: " + ", ".join(f"{x:.6f}" for x in out), "| max Re(all)", f"{s.real.max():.4e}", "max|Im| of unstable",
              f"{np.abs(s[s.real > 1e-8].imag).max() if (s.real > 1e-8).any() else 0:.2e}")


def eigenmode(N, m, k, eq=None, gamma=5 / 3):
    """the most unstable mode: growth rate and its radial profiles (complex), phase-fixed so that v_r is real and positive
    at its maximum.  Returns dict(sigma, rf, rc, vr (faces), Br (faces), rho, vp, vz, p, Bp, Bz (centres))."""
    eq = eq or readme_pinch()
    L, off = operator(N, m, k, eq, gamma)
    s, V = np.linalg.eig(L)
    ok = np.abs(s.imag) <= 1e-6 * max(1.0, np.abs(s).max()); i = np.flatnonzero(ok)[np.argmax(s.real[ok])]
    x = V[:, i]; h = 1.0 / N; rf = np.arange(N + 1) * h; rc = (np.arange(N) + 0.5) * h
    out = dict(sigma=s[i], rf=rf, rc=rc)
    for n_ in ("vr", "Br"):
        f = np.zeros(N + 1, complex); f[1:N] = x[off[n_]:off[n_] + N - 1]; out[n_] = f
    for n_ in ("rho", "vp", "vz", "p", "Bp", "Bz"): out[n_] = x[off[n_]:off[n_] + N]
    j = np.argmax(np.abs(out["vr"])); ph = np.abs(out["vr"][j]) / out["vr"][j]; amp = np.abs(out["vr"][j])
    for n_ in ("vr", "Br", "rho", "vp", "vz", "p", "Bp", "Bz"): out[n_] = out[n_] * ph / amp
    return out
