# -*- coding: utf-8 -*-
"""
ALADIN Driver v4.0.2-dev -- campaign MMS-01: the METHOD OF MANUFACTURED SOLUTIONS, through the axis, in full 3D.
    python mms01.py cpu|gpu PART [quick] [resume]       PART = 0 | I | R | H | N
What: the Driver solves the MHD equations plus an exact source (managers/source_manager.py) whose exact solution is a chosen smooth
field (MMS-01 solution: rho, p, v, A sums of separable sinusoids in x, y, z, t; B = B0 + curl A with B0 = (0.4, 0.3, 1.0) oblique
through the axis; every field moves).  The error against that exact solution must shrink at the design order (2).
  part 0  M00 source self-test (tests/mms_selftest.py: closed-form derivatives and sources vs 6th-order FD, 12 points, one on the axis)
          M0  MMS OFF = the certified Driver: 6 cases x 25 steps, SHA-256 of every state equal to the tree BEFORE the source manager
              (reference hashes below, produced on the CPU with drv_dev before the change; the GPU leg must reproduce them on CuPy)
  part I  ideal       part R  resistive, eta = 0.02       part H  Hall, hall = 0.02
  part N  NEGATIVE CONTROL: eta = 0.02 in the Driver, eta LEFT OUT of the source -> the B error must stop converging (proves the
          test can see a missing term)
Levels (nr, nphi, nz): L1 (8, 16, 16)  L2 (16, 32, 32)  L3 (32, 64, 64)  L4 (64, 128, 128);  r in [0, 1] (axis grid), z in [0, 1)
periodic, outer boundary 'fixed' = exact solution at the stage time; limiter mc; cfl 0.4; t_end = 0.05.
Error: volume-weighted L1 over the interior of rho, v_r, v_phi, v_z, p (primitives) and the cell-centred B_r, B_phi, B_z, against the
exact point values at the cell centres.  Order = log2(err_coarse / err_fine).

THRESHOLDS -- proposed 2026-11-23 and approved by the author before any verdict run ("we expose what fail and pass"):
  M00_selftest     <= 1e-8    max relative error of the source machinery (both legs)
  M0_off_identity  == 0       cases whose 25-step state hash differs from the pre-MMS reference (both legs)
  M{I,R,H}_order   >= 1.8     L1 order L3 -> L4, the MINIMUM over the 8 variables                    (GPU leg)
  MN_B_order       <= 1.0     L1 order L2 -> L3 of the negative control, the MAXIMUM over B_r, B_phi, B_z (GPU leg)
  divB_max         <= 1e-12   max normalised div B over every step of every level of the part     (GPU leg)
  recovery_passes  == 0       recovery passes summed over every step of every level                (GPU leg)
  gpu_cpu          == 0       arrays whose final-state SHA-256 differs GPU vs CPU leg, L1-L3        (GPU leg)
Reported, not thresholded: L-inf errors; per-variable orders of every pair; the error in the first 4 rings next to the axis.
DISCLOSED PREVIEWS (development, 2026-11-23): ideal L1-L3 (L1 order L2 -> L3: rho 1.87, v_r 1.63, v_phi 1.99, v_z 1.86, p 2.06, B_r 2.22,
B_phi 2.04, B_z 1.90; the v_r error in the first two rings next to the axis did not shrink, 5e-3 -> 7e-3; minmod alike); resistive, Hall
and the negative control at L1-L2.  L4 has never been run.
Legs: the GPU leg runs L1-L4 (N: L1-L3) and carries the verdict; the CPU leg runs L1-L3 (informational) and writes the SHA-256 of every
final state.  Robustness: each level checkpoints every 20 minutes of wall time and the part's progress is written after every level;
'resume' continues from them (the Driver's restart is bit-identical: CHECKPOINT MANAGER).  "quick" = plumbing (L1, 3 steps; no numbers).
"""
import os, sys, json, time, math, platform, datetime, hashlib, traceback, subprocess
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT); sys.path.insert(0, HERE)
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; PART = sys.argv[2] if len(sys.argv) > 2 else "0"
QUICK = "quick" in sys.argv[3:]; RESUME = "resume" in sys.argv[3:]
BK = "cupy" if LEG == "gpu" else "cpu"
import aladin_driver_v40 as D
from managers import bundle_manager as BM, source_manager as SM
H = D.host

LEVELS = [(8, 16, 16), (16, 32, 32), (32, 64, 64), (64, 128, 128)]
T_END = 0.05
PHYS = dict(I=dict(eta=0.0, hall=0.0, omit=()), R=dict(eta=0.02, hall=0.0, omit=()), H=dict(eta=0.0, hall=0.02, omit=()),
            N=dict(eta=0.02, hall=0.0, omit=("eta",)))
VARS = ("rho", "vr", "vphi", "vz", "p", "Br", "Bphi", "Bz")
TH = dict(M00_selftest=1e-8, M0_off_identity=0.0, MI_order=1.8, MR_order=1.8, MH_order=1.8, MN_B_order=1.0, divB_max=1e-12, recovery_passes=0.0, gpu_cpu=0.0)
OFF_REF = {   # mms_off_identity.py on the tree before the source manager (drv_dev, 2026-11-23, CPU): 25-step state SHA-256
    "README pinch, well-balanced, fixed": "aa6b0030abb704d8c0880bd47c85e70ed81821018fe43fdad8aa01731be75e48",
    "Alfven wave, outflow": "1ace86e95346b10d73542ee56373e0204bbd81a65ab7f992f0b02439c78c912c",
    "Hall wave +1, outflow": "4f43e5a4ab34f37c20b43d8d9a845d865c7e6183b6bbacefe30c0bc2498c204f",
    "resistive decay": "84f4ac93d39d02b8f2b18b51b0ef3184bff6030a3b160d2f3290eabc19615253",
    "flux tube eta+Hall, wall": "4dbda7e95e4eda29bee8126510d6ab9d4da0f9aa2a63853140457726d661a512",
    "Sod along z, outflow z": "1fa137b62481f11dcc6feff1c636d74ca461f4d8bed06663147d2bae519f7c67"}
MEANING = dict(M00_selftest="max relative error, closed-form sources vs 6th-order FD (12 points, one on the axis)",
               M0_off_identity="cases (of 6) whose 25-step state SHA-256 differs from the pre-MMS tree",
               MI_order="ideal: L1 order L3 -> L4, minimum over 8 variables", MR_order="resistive (eta 0.02): L1 order L3 -> L4, minimum over 8 variables",
               MH_order="Hall (0.02): L1 order L3 -> L4, minimum over 8 variables",
               MN_B_order="negative control (eta left out of the source): L1 order L2 -> L3, maximum over B_r, B_phi, B_z",
               divB_max="max normalised div B, every step of every level", recovery_passes="recovery passes, every step of every level",
               gpu_cpu="final-state arrays (8 per level, L1-L3) whose SHA-256 differs GPU vs CPU leg")
TAG = f"{LEG}_{PART}{'_quick' if QUICK else ''}"
PROG = os.path.join(HERE, f"mms01_progress_{TAG}.json"); CK = lambda key: os.path.join(HERE, f"mms01_ckpt_{TAG}_{key}")
CK_EVERY = 20 * 60


def sha_arrays(d): return [hashlib.sha256(np.ascontiguousarray(H(a)).tobytes()).hexdigest() for a in d.U + d.B]


def ring_errors(src, d, n=4):
    g = d.g; I = d.grids.I; pr = d.PR.primitives(d.GP, *d.U, *d.B, gamma=d.cfg.gamma, backend=d.bk)
    Lc = SM.Loc(d.GE.r_centers[g:g + d.cfg.nr], d.GE.phi_c[g:g + d.cfg.nphi], d.GE.z_c[g:g + d.cfg.nz], np); ex = src.prims(Lc, d.t)
    return {k: [float(x) for x in np.abs(H(pr[k][I]) - ex[k]).mean(axis=(1, 2))[:n]] for k in ("rho", "vr", "vphi", "vz", "p")}


def run_level(part, lv, rb=None):
    """one level, with checkpoints; returns its record"""
    key = "x".join(map(str, lv)); ph = PHYS[part]
    src = SM.MMSSource(SM.mms01_solution(), omit=ph["omit"])
    cfg = D.Config(nr=lv[0], nphi=lv[1], nz=lv[2], eta=ph["eta"], hall=ph["hall"], r_outer_bc="fixed", backend=BK, label=f"MMS-01 {part} {key}")
    d = rb.driver(cfg, src.ic, source=src) if rb else D.Driver(cfg, src.ic, source=src)
    acc = dict(divB_max=float(d.tot0["divB_norm"]), recovery_passes=0, resumed_from_step=None); ck = CK(key)
    if RESUME and os.path.exists(ck + ".npz"):
        d.load(ck); acc.update(json.load(open(ck + "_acc.json"))); acc["resumed_from_step"] = d.step
        print(f"  {part} {key}: RESUMED from checkpoint at step {d.step}, t = {d.t:.6f}", flush=True)
    last = [time.time()]; t0 = time.time()
    def on_step(dd, r):
        acc["divB_max"] = max(acc["divB_max"], float(r.get("divB_norm", np.nan))); acc["recovery_passes"] += int(r["recovery_passes"])
        if time.time() - last[0] > CK_EVERY:
            dd.save(ck); json.dump(acc, open(ck + "_acc.json", "w")); last[0] = time.time()
            print(f"  {part} {key}: checkpoint at step {dd.step}, t = {dd.t:.6f} ({100 * dd.t / T_END:.1f} %)", flush=True)
    kw = dict(nsteps=3) if QUICK else dict(t_end=T_END)
    st = rb.run(on_step=on_step, **kw) if rb else d.run(on_step=on_step, **kw)
    rec = dict(level=key, status=st, steps=d.step, t=d.t, seconds=round(time.time() - t0, 1), **acc)
    if st == "COMPLETED":
        rec["errors"] = src.errors(d); rec["axis_rings"] = ring_errors(src, d); rec["sha256"] = sha_arrays(d)
    for ext in (".npz", ".json", "_acc.json"):
        if os.path.exists(ck + ext): os.remove(ck + ext)
    return rec


def part0():
    data, meas = {}, {}
    r = subprocess.run([sys.executable, os.path.join(HERE, "mms_selftest.py")], capture_output=True, text=True); print(r.stdout, flush=True)
    st = json.load(open(os.path.join(HERE, "mms00_results.json"))); data["M00"] = st; meas["M00_selftest"] = max(st["worst"].values())
    r = subprocess.run([sys.executable, os.path.join(HERE, "mms_off_identity.py"), ROOT, BK], capture_output=True, text=True); print(r.stdout, r.stderr[-2000:], flush=True)
    got = {}
    for line in r.stdout.splitlines():
        for name in OFF_REF:
            if line.startswith(name): got[name] = line[38:].split()[3]
    data["M0"] = dict(reference=OFF_REF, measured=got, stdout=r.stdout)
    meas["M0_off_identity"] = float(sum(got.get(k) != v for k, v in OFF_REF.items()))
    return data, meas


def part_mms(rb):
    data, meas = {}, {}
    prog = json.load(open(PROG)) if (RESUME and os.path.exists(PROG)) else dict(levels={})
    levels = LEVELS[:1] if QUICK else (LEVELS[:3] if (LEG == "cpu" or PART == "N") else LEVELS)
    for lv in levels:
        key = "x".join(map(str, lv))
        if key in prog["levels"]: print(f"  {PART} {key}: done before (progress file), skipped", flush=True); continue
        rec = run_level(PART, lv, rb=rb if lv == levels[-1] else None); prog["levels"][key] = rec
        json.dump(prog, open(PROG, "w"), indent=1, default=float)
        if rec["status"] != "COMPLETED": raise RuntimeError(f"level {key}: {rec['status']}")
        if not QUICK:
            print(f"  {PART} {key}: {rec['steps']} steps, {rec['seconds']} s, divB {rec['divB_max']:.1e}, recovery {rec['recovery_passes']} | L1 "
                  + " ".join(f"{v} {rec['errors'][v]['L1']:.3e}" for v in VARS), flush=True)
    data["levels"] = prog["levels"]
    if QUICK: return data, meas
    L = [data["levels"]["x".join(map(str, lv))] for lv in levels]
    orders = {f"{L[i]['level']}->{L[i + 1]['level']}": {v: math.log2(L[i]["errors"][v]["L1"] / L[i + 1]["errors"][v]["L1"]) for v in VARS} for i in range(len(L) - 1)}
    data["orders"] = orders; last = orders[list(orders)[-1]]
    for k, o in orders.items(): print(f"  {PART} order {k}: " + " ".join(f"{v} {o[v]:.3f}" for v in VARS), flush=True)
    if LEG == "gpu":
        if PART == "N": meas["MN_B_order"] = max(last[v] for v in ("Br", "Bphi", "Bz"))
        else: meas[f"M{PART}_order"] = min(last.values())
        meas["divB_max"] = max(x["divB_max"] for x in L); meas["recovery_passes"] = float(sum(x["recovery_passes"] for x in L))
        p = os.path.join(HERE, f"mms01_cpu_{PART}_sha256.json")
        if not os.path.exists(p): raise RuntimeError(f"{p} (the CPU leg's state hashes for part {PART}) is missing")
        ref = json.load(open(p)); n = 0; diff = {}
        for key, hs in ref.items():
            mine = data["levels"].get(key, {}).get("sha256")
            nd = len(hs) if mine is None else sum(a != b for a, b in zip(hs, mine)); n += nd
            if nd: diff[key] = nd
        data["gpu_vs_cpu"] = dict(levels=list(ref), differing=diff); meas["gpu_cpu"] = float(n)
    return data, meas


if __name__ == "__main__":
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, part=PART, quick=QUICK, resume=RESUME,
               platform=platform.platform(), numpy=np.__version__)
    if BK == "cupy":
        import cupy as cp; env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    print(f"MMS-01 part {PART} leg={LEG}{' QUICK (plumbing only)' if QUICK else ''}{' RESUME' if RESUME else ''} | {D.VERSION} | {env.get('gpu', 'CPU')}", flush=True)
    if PART == "0": keys = ["M00_selftest", "M0_off_identity"]
    elif LEG == "gpu" and not QUICK: keys = (["MN_B_order"] if PART == "N" else [f"M{PART}_order"]) + ["divB_max", "recovery_passes", "gpu_cpu"]
    else: keys = []
    OP = lambda k: ">=" if k.endswith("_order") and k != "MN_B_order" else "<="
    checks = {k: (OP(k), TH[k], MEANING[k]) for k in keys}
    rb = BM.RunBundle(os.path.join(HERE, f"runs_mms01_{TAG}"), f"MMS01_{PART}", thresholds=checks, meta=dict(header=__doc__)); data, meas = {}, {}
    try:
        with rb:
            data, meas = part0() if PART == "0" else part_mms(rb)
            for k_, v in meas.items(): rb.check(k_, v)
    except Exception:
        data = dict(data, exception=traceback.format_exc())
    res = json.load(open(os.path.join(rb.dir, "results.json")))
    print(f"MMS01_{PART} {res['verdict']}  " + "; ".join(f"{k}={c['value']:.3e} {c['op']} {c['threshold']:g} {c['result']}" for k, c in res["checks"].items() if isinstance(c.get("value"), (int, float))), flush=True)
    if "exception" in data: print(data["exception"])
    json.dump(dict(campaign="MMS-01", part=PART, thresholds=TH, env=env, verdict=res["verdict"], checks=res["checks"], data=data, bundle=os.path.basename(rb.dir)),
              open(os.path.join(HERE, f"mms01_{TAG}_results.json"), "w"), indent=1, default=float)
    if LEG == "cpu" and not QUICK and PART != "0" and "levels" in data:
        json.dump({k: v["sha256"] for k, v in data["levels"].items() if "sha256" in v}, open(os.path.join(HERE, f"mms01_cpu_{PART}_sha256.json"), "w"), indent=1)
