"""
AXIS-01 / AXJ-01 -- current reconstruction at the axis (UCT-CURL v1.5, the Driver's J = curl B operator), exact Bessel and
power-law benchmarks.  CPU only (GPU == CPU bit identity of this kernel is already certified, CURL-06).

FAMILY.  A_z(r, phi) = f(r) cos(m phi),  B = curl(A_z zhat):  B_r = (1/r) dA/dphi,  B_phi = -dA/dr,  B_z = 0,
         J_z = -lap(A_z),  J_r = J_phi = 0 (z-independent field).
FACE VALUES = the exact face averages, i.e. the discrete curl of the exact edge values of A (what CT carries):
         B_phi(face at phi_f, radial cell [r-, r+]) = -(A(r+) - A(r-)) / dr
         B_r  (face at r_f,  phi cell [phi-, phi+]) = (A(phi+) - A(phi-)) / (r_f dphi);  axis face r_f = 0: the limit.
REFERENCE J_z = the exact POINT value at the cell centre (r_c, phi_c), which is what the kernel claims to return.

TESTS (k = 5.0, r in [0, 1]):
  AXJ-0  harness check  A = -r^2/2            B_phi = r     J_z = 2           (README pinch; must be exact to 1e-12)
  AXJ-1  A = -r^4/4                           B_phi = r^3   J_z = 4 r^2
  AXJ-2  A = -r^6/6                           B_phi = r^5   J_z = 6 r^4
  AXJ-3  A = cos(kr)/k                        B_phi = sin(kr)  J_z = sin(kr)/r + k cos(kr)
  AXJ-4  A = J0(kr)/k   (m = 0 Bessel)        B_phi = J1(kr)   J_z = k J0(kr)
  AXJ-5..8  A = J_m(kr) cos(m phi), m = 1, 2, 3, 4   (Bessel eigenmodes: J_z = k^2 A, exact regularity O(r^m))
LEVELS nr = 16, 32, 64, 128; nphi = 2 nr; nz = 4; g = 2; float64.

FROZEN CRITERIA (written before any AXJ-1..8 number was seen):
  P1  global L1 error of J_z (interior):            observed order (64 -> 128) >= 1.8        for AXJ-1..8
  P2  axis ring (ring 0) Linf error of J_z:         observed order (64 -> 128) >= 1.8        for AXJ-1..8
      (tests the v1.2 docstring claim that axis mode is second order at the axis; a FAIL is kept and reported)
  P3  J_r and J_phi (interior):                     max |.| <= 1e-12 at every level          for AXJ-0..8
  P4  harness: AXJ-0 max |J_z - 2| <= 1e-12 at every level (if P4 fails the campaign is void, not a kernel verdict)
Verdict per test = PASS iff all applicable criteria pass.  Errors and orders of every level are recorded.
"""
import sys, json, hashlib, math, os
import numpy as np
from scipy.special import jv
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from kernels import uct_curl as UC

K = 5.0
LEVELS = (16, 32, 64, 128)
G = 2
NZ = 4

def tests():
    def bes(m):
        A = lambda r, p: jv(m, K * r) * np.cos(m * p)
        Jz = lambda r, p: K * K * jv(m, K * r) * np.cos(m * p)
        # limit of A/r at r = 0 (for B_r on the axis face): k/2 cos(phi) for m = 1, else 0
        Ar0 = (lambda p: 0.5 * K * np.cos(p)) if m == 1 else (lambda p: 0.0 * p)
        return dict(m=m, A=A, Jz=Jz, Ar0=Ar0)
    T = {
        "AXJ-0": dict(m=0, A=lambda r, p: -0.5 * r**2 + 0 * p, Jz=lambda r, p: 2.0 + 0 * r * p, Ar0=lambda p: 0.0 * p),
        "AXJ-1": dict(m=0, A=lambda r, p: -0.25 * r**4 + 0 * p, Jz=lambda r, p: 4 * r**2 + 0 * p, Ar0=lambda p: 0.0 * p),
        "AXJ-2": dict(m=0, A=lambda r, p: -r**6 / 6 + 0 * p, Jz=lambda r, p: 6 * r**4 + 0 * p, Ar0=lambda p: 0.0 * p),
        "AXJ-3": dict(m=0, A=lambda r, p: np.cos(K * r) / K + 0 * p,
                      Jz=lambda r, p: np.sin(K * r) / r + K * np.cos(K * r) + 0 * p, Ar0=lambda p: 0.0 * p),
        "AXJ-4": dict(m=0, A=lambda r, p: jv(0, K * r) / K + 0 * p, Jz=lambda r, p: K * jv(0, K * r) + 0 * p,
                      Ar0=lambda p: 0.0 * p),
    }
    for i, m in enumerate((1, 2, 3, 4)): T[f"AXJ-{5 + i}"] = bes(m)
    return T

def run_level(t, nr):
    dr = 1.0 / nr; nphi = 2 * nr; dphi = 2 * math.pi / nphi; dz = 0.25
    rf, rc = UC.make_grid(nr, dr, G, np.float64)
    pf = (np.arange(nphi + 1 + 2 * G) - G) * dphi; pc = (np.arange(nphi + 2 * G) - G + 0.5) * dphi
    Br, Bp, Bz = UC._fields(nr, nphi, NZ, G, dr, dphi, dz, np.float64)
    A = t["A"]
    # B_phi on phi faces (radial cells i, phi faces j): -(A(r+) - A(r-))/dr ; ghost rings included (inner ghosts unused)
    rm, rp = rf[:-1][:, None], rf[1:][:, None]
    Bp[...] = (-(A(rp, pf[None, :]) - A(rm, pf[None, :])) / dr)[:, :, None]
    # B_r on r faces (phi cells j): (A(phi+) - A(phi-)) / (r dphi); axis face: limit
    pm, pp = pf[:-1][None, :], pf[1:][None, :]
    R = rf[:, None]
    with np.errstate(divide="ignore", invalid="ignore"):
        br = (A(R, pp) - A(R, pm)) / (R * dphi)
    ax = G
    br[ax] = (t["Ar0"](pf[1:]) - t["Ar0"](pf[:-1])) / dphi
    br[:ax] = 0.0                                                    # inner ghost faces: never read in axis mode
    Br[...] = br[:, :, None]
    (Jr, Jp, Jz), lab = UC.run_curl(Br, Bp, Bz, rf, rc, dr, dphi, dz, nr, nphi, NZ, G, backend="cpu")
    sl = (slice(G, G + nr), slice(G, G + nphi), slice(G, G + NZ))
    ex = t["Jz"](rc[G:G + nr][:, None], pc[G:G + nphi][None, :])[:, :, None]
    e = Jz[sl] - ex
    w = rc[G:G + nr][:, None, None] * np.ones_like(e)              # area weight r dr dphi
    L1 = float((np.abs(e) * w).sum() / w.sum())
    return dict(nr=nr, nphi=nphi, L1=L1, Linf=float(np.abs(e).max()), ring0_Linf=float(np.abs(e[0]).max()),
                ring1_Linf=float(np.abs(e[1]).max()), Linf_at_ring=int(np.unravel_index(np.abs(e).argmax(), e.shape)[0]),
                JrJp_max=float(max(np.abs(Jr[sl]).max(), np.abs(Jp[sl]).max())),
                sha_Jz=hashlib.sha256(np.ascontiguousarray(Jz[sl]).tobytes()).hexdigest()), lab

def order(a, b): return math.log2(a / b) if a > 0 and b > 0 else float("inf")

def main():
    out = {"campaign": "AXJ-01", "kernel": f"uct_curl v{UC.VERSION}", "k": K, "levels": LEVELS, "tests": {}}
    for name, t in tests().items():
        rows = []
        for nr in LEVELS:
            r, lab = run_level(t, nr); rows.append(r)
        out["backend"] = lab
        rec = dict(m=t["m"], levels=rows)
        P3 = all(r["JrJp_max"] <= 1e-12 for r in rows)
        if name == "AXJ-0":
            P4 = all(r["Linf"] <= 1e-12 for r in rows); rec.update(P3=P3, P4=P4, verdict="PASS" if (P3 and P4) else "FAIL")
        else:
            o1 = order(rows[-2]["L1"], rows[-1]["L1"]); o2 = order(rows[-2]["ring0_Linf"], rows[-1]["ring0_Linf"])
            rec.update(order_L1=o1, order_ring0=o2,
                       orders_L1_all=[order(a["L1"], b["L1"]) for a, b in zip(rows, rows[1:])],
                       orders_ring0_all=[order(a["ring0_Linf"], b["ring0_Linf"]) for a, b in zip(rows, rows[1:])],
                       P1=o1 >= 1.8, P2=o2 >= 1.8, P3=P3)
            rec["verdict"] = "PASS" if (rec["P1"] and rec["P2"] and P3) else "FAIL"
        out["tests"][name] = rec
        s = f"{name} m={t['m']}: " + " ".join(f"[{r['nr']}] L1 {r['L1']:.3e} ring0 {r['ring0_Linf']:.3e}" for r in rows)
        if name != "AXJ-0": s += f" | order L1 {rec['order_L1']:.3f} ring0 {rec['order_ring0']:.3f}"
        print(s, "|", rec["verdict"], flush=True)
    out["void"] = out["tests"]["AXJ-0"]["verdict"] != "PASS"
    out["campaign_verdict"] = "VOID" if out["void"] else ("PASS" if all(v["verdict"] == "PASS" for v in out["tests"].values()) else "FAIL")
    print("CAMPAIGN", out["campaign_verdict"])
    json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "axj01_results.json"), "w"), indent=1)

if __name__ == "__main__":
    main()
