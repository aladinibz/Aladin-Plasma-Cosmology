# -*- coding: utf-8 -*-
"""ZP-STEP harness: the README Z-pinch advanced by the CERTIFIED kernels, unmodified:
    PRIM v01 -> HLLD v05.1 (3 directions) -> RESIDUAL v01  (plasma)   and   UCT-EMF v02 compute_emf + ct_update  (field),
    SSP-RK3 (Shu-Osher).  This is TEST SCAFFOLDING standing in for the Driver (time integrator, boundary conditions); it is
    not a kernel.  UCT-ASSEMBLY (kernel 11) is not certified yet: the CT Faraday update used here is UCT-EMF v02's ct_update.

Boundary conditions (test choice): periodic in phi and z; axis by reflection (uct_emf_v02.fill_axis_ghosts); outer radial
ghosts held at the analytic equilibrium (B_phi = r/2, P = 1 - r^2/4, rho = 1, v = 0 extended beyond r = 1).
Well-balanced mode: HLLD gets W_eq (cells) and W_eq_faces (exact radial face values), RESIDUAL gets R_eq = residual of the
equilibrium (computed once with the same ghost fill)."""
import sys, os, copy, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(HERE), "kernels"))
import prim_v01 as PR, hlld_v05 as H, residual_v01 as RS, uct_emf_v02 as E

GAM = 5 / 3


class Pinch:
    def __init__(self, nr=32, nphi=16, nz=16, zlen=1.0, backend="cpu", wb=True, P0=1.0):
        self.bk = backend; self.wb = wb; self.P0 = P0
        xp = np
        if backend == "cupy":
            import cupy as cp; xp = cp
        self.xp = xp
        mk = lambda M: M.Grid(nr, nphi, nz, 0.0, 1.0, zlen=zlen)
        self.GP, self.GH, self.GR, self.GE = mk(PR), mk(H), mk(RS), mk(E)
        for Gk in (self.GP, self.GH, self.GR, self.GE): Gk.xp = xp
        G = self.GE; self.g = G.g; self.nr, self.nphi, self.nz = nr, nphi, nz
        rc, rf = G.r_centers, G.r_faces
        sh = G.shape("cell"); self.sh = sh
        # analytic equilibrium on every cell / face incl. ghosts (r < 0 ghosts are overwritten by the axis reflection)
        self.rho_eq = np.ones(sh); self.p_eq = (P0 - 0.25 * rc ** 2)[:, None, None] * np.ones(sh)
        self.B_eq = [np.zeros(G.shape("Br")), np.zeros(G.shape("Bphi")), np.zeros(G.shape("Bz"))]
        self.B_eq[1][:] = (0.5 * rc)[:, None, None]
        z0 = np.zeros(sh)
        U = PR.conserved(PR.Grid(nr, nphi, nz, 0.0, 1.0, zlen=zlen), self.rho_eq, z0, z0, z0, self.p_eq, *self.B_eq)
        self.U_eq = [U[k] for k in ("rho", "m_r", "m_phi", "m_z", "E")]
        g = self.g; rfi = rf[g:g + nr + 1][:, None, None]
        self.Wf = np.zeros(self.GH.shape("F_r")); self.Wf[0] = 1; self.Wf[4] = P0 - 0.25 * rfi ** 2; self.Wf[6] = 0.5 * rfi
        self.W8 = H.pack(H.Grid(nr, nphi, nz, 0.0, 1.0, zlen=zlen), self.rho_eq, z0, z0, z0, self.p_eq, *self.B_eq)
        self.U_eq = [self.to(x) for x in self.U_eq]; self.B_eq = [self.to(x) for x in self.B_eq]
        self.W8 = self.to(self.W8); self.Wf = self.to(self.Wf)
        self.R_eq = None
        if wb:
            U0 = [x.copy() for x in self.U_eq]; B0 = [x.copy() for x in self.B_eq]
            self.fill(U0, B0); self.R_eq = self.rhs(U0, B0)[0]          # residual of the equilibrium, same ghost fill
        self.refused = 0

    def to(self, x):
        return self.xp.asarray(x) if self.bk == "cupy" else x

    # ---------------------------------------------------------------- boundaries
    def fill(self, U, B):
        G = self.GE; g = self.g; nr = self.nr
        E.fill_periodic(G, *U, *B, kinds=("cell",) * 5 + ("Br", "Bphi", "Bz"))
        # outer radial ghosts (cells beyond r = 1 and faces beyond the outer face) held at the equilibrium
        for a, ae in zip(U, self.U_eq): a[g + nr:] = ae[g + nr:]
        B[0][g + nr + 1:] = self.B_eq[0][g + nr + 1:]; B[1][g + nr:] = self.B_eq[1][g + nr:]; B[2][g + nr:] = self.B_eq[2][g + nr:]
        E.fill_axis_ghosts(G, cells_scalar=(U[0], U[4]), cells_vector=[(U[1], U[2], U[3])], Br=B[0], Bphi=B[1], Bz=B[2])
        E.fill_periodic(G, *U, *B, kinds=("cell",) * 5 + ("Br", "Bphi", "Bz"))

    # ---------------------------------------------------------------- right-hand side
    def rhs(self, U, B):
        """returns (dU (5, interior) , EMF (Er, Ephi, Ez), prims, flags dict)"""
        pr = PR.primitives(self.GP, *U, *B, gamma=GAM, backend=self.bk)
        prims = [pr[k] for k in ("rho", "vr", "vphi", "vz", "p")]
        kw = dict(W_eq=self.W8, W_eq_faces={0: self.Wf}) if self.wb else {}
        F, fl = H.fluxes(self.GH, *prims, *B, gamma=GAM, backend=self.bk, **kw)
        r = RS.residual(self.GR, F[0], F[1], F[2], *prims, *B, R_eq=self.R_eq, backend=self.bk)
        Er, Ep, Ez = E.compute_emf(self.GE, *B, prims[1], prims[2], prims[3], prims[0], prims[4], gamma=GAM, backend=self.bk)
        nref = int((pr["flags"] & 11).astype(bool).sum()) + int((r["flags"] == 1).sum()) + sum(int(((f & 32) > 0).sum()) for f in fl.values())
        return r["dU"], (Er, Ep, Ez), prims, nref

    def dt_cfl(self, U, B, cfl=0.4):
        xp = self.xp; G = self.GE; g = self.g
        pr = PR.primitives(self.GP, *U, *B, gamma=GAM, backend=self.bk); I = (slice(g, g + self.nr), slice(g, g + self.nphi), slice(g, g + self.nz))
        bc = PR.cell_B(self.GP, *B); b2 = sum(x[I] ** 2 for x in bc)
        cf = xp.sqrt((GAM * pr["p"][I] + b2) / pr["rho"][I]); vmax = max(float(xp.abs(pr[k][I]).max()) for k in ("vr", "vphi", "vz"))
        rc = xp.asarray(G.r_centers[g:g + self.nr])
        h = min(G.dr, float(rc.min()) * G.dphi, G.dz)
        return cfl * h / (vmax + float(cf.max()))

    # ---------------------------------------------------------------- SSP-RK3
    def stage(self, U, B, dt):
        """forward Euler from (U, B): returns new copies"""
        g = self.g; I = (slice(g, g + self.nr), slice(g, g + self.nphi), slice(g, g + self.nz))
        self.fill(U, B); dU, (Er, Ep, Ez), prims, nref = self.rhs(U, B); self.refused += nref
        Un = [x.copy() for x in U]
        for m in range(5): Un[m][I] = U[m][I] + dt * dU[m]
        Bn = [self.xp.ascontiguousarray(x.copy()) for x in B]
        E.ct_update(self.GE, *Bn, Er, Ep, Ez, dt, backend=self.bk)
        return Un, Bn, dU

    def step(self, U, B, dt):
        U1, B1, dU0 = self.stage(U, B, dt)
        U2a, B2a, _ = self.stage(U1, B1, dt)
        U2 = [0.75 * a + 0.25 * b for a, b in zip(U, U2a)]; B2 = [0.75 * a + 0.25 * b for a, b in zip(B, B2a)]
        U3a, B3a, _ = self.stage(U2, B2, dt)
        Un = [a / 3 + 2 * b / 3 for a, b in zip(U, U3a)]; Bn = [self.xp.ascontiguousarray(a / 3 + 2 * b / 3) for a, b in zip(B, B3a)]
        self.fill(Un, Bn)
        return Un, Bn, dU0

    def initial(self):
        U = [x.copy() for x in self.U_eq]; B = [self.xp.ascontiguousarray(x.copy()) for x in self.B_eq]; self.fill(U, B); return U, B

    def interior(self, a):
        g = self.g; return a[g:g + self.nr, g:g + self.nphi, g:g + self.nz]

    def totals(self, U, B):
        """mass, energy, z-momentum, discrete angular momentum (sum V rbar m_phi), max normalised div B"""
        xp = self.xp; G = self.GE; g = self.g
        rf = np.asarray(G.r_faces[g:g + self.nr + 1]); rm, rp = rf[:-1], rf[1:]
        V = xp.asarray((0.5 * (rp ** 2 - rm ** 2) * G.dphi * G.dz)[:, None, None]); rb = xp.asarray(((2 / 3) * (rp ** 3 - rm ** 3) / (rp ** 2 - rm ** 2))[:, None, None])
        tot = dict(mass=float((V * self.interior(U[0])).sum()), energy=float((V * self.interior(U[4])).sum()), pz=float((V * self.interior(U[3])).sum()),
                   L=float((V * rb * self.interior(U[2])).sum()))
        d, dn = E.divergence(G, *B); tot["divB_norm"] = float(xp.abs(dn).max())
        return tot
