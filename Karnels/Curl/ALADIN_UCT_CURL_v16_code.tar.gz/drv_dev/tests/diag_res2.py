import sys, numpy as np; sys.argv=["x","cpu"]; sys.path.insert(0,".")
import drv01 as C
D, IC, K = C.D, C.IC, C.K
eta=0.05; ex=eta*K*K
def amp_of(d, B):
    Brc,Bpc,_=[np.asarray(x) for x in d.PR.cell_B(d.GP,*B)]; I=d.grids.I; ph=d.GE.phi_c[None,:,None]; z=d.GE.z_c[None,None,:]
    bx=Brc*np.cos(ph)-Bpc*np.sin(ph); by=Brc*np.sin(ph)+Bpc*np.cos(ph)
    return ((bx+1j*by)*np.exp(-1j*K*z))[I].mean(axis=(1,2))
def rate(nr,nphi,nz):
    d=D.Driver(C.cfg(nr=nr,nphi=nphi,nz=nz,eta=eta,r_outer_bc="outflow"), IC.ic_resistive_decay(K,1e-3,p0=1.0))
    U=[x.copy() for x in d.U]; B=[x.copy() for x in d.B]; d.fill(U,B)
    out=d.rhs(U,B); Bn=[x.copy() for x in B]
    d.E.ct_update(d.GE,*Bn,*[np.ascontiguousarray(e) for e in out["EMF"]],1.0,backend="cpu")
    dB=[a-b for a,b in zip(Bn,B)]
    a0=amp_of(d,B); a1=amp_of(d,dB)
    r=-(a1/a0).real
    return (r-ex)/ex
kz = 2*np.pi/ (1/np.arange(1))  if False else None
if __name__ == "__main__":
    for lab,grids in [("z only (cross 32x64)",[(32,64,16),(32,64,32),(32,64,64),(32,64,128)]),
                    ("r only (phi64,z256)",[(8,64,256),(16,64,256),(32,64,256),(64,64,256)]),
                    ("phi only (r64,z256)",[(64,8,256),(64,16,256),(64,32,256),(64,64,256)]),
                    ("joint",[(4,8,16),(8,16,32),(16,32,64),(32,64,128)])]:
      print(lab)
      for g in grids:
          e=rate(*g); print(f"  {g}: per-ring rel err  axis {e[0]:+.5f}  mid {e[len(e)//2]:+.5f}  outer {e[-1]:+.5f}   z-stencil theory {-(K/g[2])**2/12:+.5f}", flush=True)
