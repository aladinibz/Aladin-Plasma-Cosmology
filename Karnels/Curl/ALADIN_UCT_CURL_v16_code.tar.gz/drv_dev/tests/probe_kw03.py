# -*- coding: utf-8 -*-
"""KW-03: the D04 GPU != CPU at step 924 (KW-02).  Suspect: timestep_manager b2 = sum(x ** 2): NumPy computes x ** 2 as x * x,
CuPy calls CUDA pow(x, 2.0); the Hall limit dt = cfl h / v_w uses sqrt(b2).max() directly, so one ulp there changes dt.
Part 1 (diagnosis): replay D04 on the CPU; at EVERY step feed the same state to both backends and compare
   (a) cell B squared with ** (the run-1 code)   (b) the same with x * x (the fix)   (c) the Driver dt_cfl (fixed code) CPU vs GPU.
Part 2 (fix): CPU Driver and GPU Driver in lockstep with the fixed manager, full run, plus the reference-CPU hashes (KW-02).
Usage: python probe_kw03.py cupy"""
import os, sys, json, numpy as np, cupy as cp
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, HERE)
sys.argv = [sys.argv[0], "cupy"]
import probe_kw02 as P, aladin_driver_v40 as D
name = "D04 Hall wave nz64 branch-1"; kw, ic, lim = P.runs()[name]
ref = json.load(open(os.path.join(HERE, "kw02_reference.json")))["hashes"][name]
# ---------- part 1
dc = D.Driver(D.Config(backend="cpu", label="KW-03", **kw), ic); dg = D.Driver(D.Config(backend="cupy", label="KW-03", **kw), ic)
I = dc.grids.I; pw = dict(steps=0, pow_differs=0, first_pow=None, mul_differs=0, dt_differs=0, first_dt=None)
while P.going(dc, lim):
    U = [x.copy() for x in dc.U]; B = [np.ascontiguousarray(x.copy()) for x in dc.B]; dc.fill(U, B)
    bcc = dc.PR.cell_B(dc.GP, *B); bcg = dg.PR.cell_B(dg.GP, *[cp.asarray(x) for x in B])
    old_c = sum(x[I] ** 2 for x in bcc); old_g = cp.asnumpy(sum(x[I] ** 2 for x in bcg))
    new_c = sum(x[I] * x[I] for x in bcc); new_g = cp.asnumpy(sum(x[I] * x[I] for x in bcg))
    n_old = int((old_c != old_g).sum()); n_new = int((new_c != new_g).sum())
    if n_old: pw["pow_differs"] += 1; pw["first_pow"] = pw["first_pow"] if pw["first_pow"] is not None else dc.step
    if n_new: pw["mul_differs"] += 1
    tc = dc.dt_cfl(U, B); tg = dg.timestep.dt_cfl([cp.asarray(x) for x in U], [cp.asarray(x) for x in B])
    if tc != tg: pw["dt_differs"] += 1; pw["first_dt"] = pw["first_dt"] if pw["first_dt"] is not None else dc.step
    pw["steps"] += 1; dc.advance(t_end=lim["t_end"])
print(f"PART 1 over {pw['steps']} states: b2 with ** differs CPU vs GPU in {pw['pow_differs']} steps (first {pw['first_pow']}); "
      f"with x*x in {pw['mul_differs']} steps; fixed dt_cfl differs in {pw['dt_differs']} steps", flush=True)
# ---------- part 2
b = D.Driver(D.Config(backend="cpu", label="KW-03", **kw), ic); c = D.Driver(D.Config(backend="cupy", label="KW-03", **kw), ic)
first_cb = None; first_ref = None
while P.going(b, lim):
    b.advance(t_end=lim["t_end"]); c.advance(t_end=lim["t_end"]); s = P.sha(b)
    if first_cb is None and P.sha(c) != s: first_cb = b.step
    if first_ref is None and ref[b.step] != s: first_ref = b.step
print(f"PART 2 fixed Driver, {b.step} steps | GPU vs CPU: {'IDENTICAL every step' if first_cb is None else 'first differs at step %d' % first_cb}"
      f" | this CPU vs reference CPU (run-1 code): {'IDENTICAL every step' if first_ref is None else 'first differs at step %d' % first_ref}", flush=True)
json.dump(dict(part1=pw, part2=dict(first_gpu_vs_cpu=first_cb, first_vs_reference=first_ref)), open(os.path.join(HERE, "kw03_cupy.json"), "w"), indent=1)
