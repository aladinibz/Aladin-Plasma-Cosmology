import sys, numpy as np; sys.argv=["x","cpu"]; sys.path.insert(0,".")
import drv01 as C
D, IC = C.D, C.IC
for m_test in ("uniform x-field (m=1)", "README pinch B_phi=r/2 (m=0)"):
    print(m_test)
    for nr,nphi in [(8,32),(16,32),(32,32),(64,32),(16,16),(16,64),(16,128)]:
        nz=8
        if m_test.startswith("uniform"):
            ic = lambda d: (lambda B: dict(U=IC._conserved(d,1.0,0.0,0.0,0.0,1.0,B),B=B))(IC.transverse_B(d, lambda z: 1.0+0*z, lambda z: 0.0*z, 0.0))
            d=D.Driver(C.cfg(nr=nr,nphi=nphi,nz=nz,r_outer_bc="outflow"), ic)
        else:
            d=D.Driver(C.cfg(nr=nr,nphi=nphi,nz=nz,well_balanced=True), D.ic_zpinch())
        G=d.GE; g=d.g; B=[np.asarray(x).copy() for x in d.B]; U=[np.asarray(x).copy() for x in d.U]; d.fill(U,B)
        J,_=d.UC.run_curl(*B, np.ascontiguousarray(G.r_faces), np.ascontiguousarray(G.r_centers), G.dr, G.dphi, G.dz, nr, nphi, nz, g, backend="cpu")
        J=[np.asarray(a) for a in J]
        I=(slice(g,g+nr+1),slice(g,g+nphi),slice(g,g+nz))
        if m_test.startswith("uniform"):
            e=[np.abs(a[I]).max() for a in J]
            ring=[float(np.abs(J[2][g+i, g:g+nphi, g:g+nz]).max()) for i in range(3)]
            print(f"  {nr}x{nphi}: max|J| r,phi,z = {e[0]:.2e} {e[1]:.2e} {e[2]:.2e}   |Jz| at r-faces 0,1,2: {ring[0]:.2e} {ring[1]:.2e} {ring[2]:.2e}")
        else:
            print(f"  {nr}x{nphi}: max|Jz - 1| = {np.abs(J[2][g:g+nr, g:g+nphi, g:g+nz]-1).max():.2e}, max|Jr|,|Jphi| = {np.abs(J[0][I]).max():.2e} {np.abs(J[1][I]).max():.2e}")
