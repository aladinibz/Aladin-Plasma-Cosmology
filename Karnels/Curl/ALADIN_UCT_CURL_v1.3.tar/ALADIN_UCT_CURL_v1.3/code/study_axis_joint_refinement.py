#!/usr/bin/env python3
"""
STUDY S02-A  --  Joint refinement of the helical-kink (m=1) transverse axis current  (uct_curl.py, FROZEN; campaign02.py, FROZEN)
Question (policeman): Test 019(h) shows ~10% transverse axis-current amplitude error from nphi=12..64. Is it the fixed radial/axial grid?
Method: refine nphi alone, nz alone, nr alone, and all three jointly; compare against the analytic prediction of the z-stencil
        error  1 - sin(k dz)/(k dz)  for B(z) ~ sin/cos(kz) (central difference of a face-staggered field).
Uses only campaign02/campaign01 helpers; no kernel or harness code is modified. Host (CPU) backend; add --gpu to use CuPy.
"""
import sys, os, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import campaign01 as C
import campaign02 as H
K = C.K; F64 = np.float64

def case(nr, nphi, nz, raw):
    fld = H.FIELD["HELICAL KINK (m=1)"]
    G = C.Grid(nr, nphi, nz, r0=0.0, r1=1.0)
    J = G.run(raw, G.sample(fld, F64), F64); ref = G.ref(fld)
    amp = float(np.max(np.hypot(J[0][G.sl][0], J[1][G.sl][0]))); amp_r = float(np.max(np.hypot(ref[0][0], ref[1][0])))
    return dict(nr=nr, nphi=nphi, nz=nz, kdz=H.KK*G.dz, amp_rel_err=abs(amp - amp_r)/amp_r,
                pred_z_stencil=1 - math.sin(H.KK*G.dz)/(H.KK*G.dz), err_Jz=H.nmax(J[2][G.sl] - ref[2]))

def orders(rows, key):
    e = [r[key] for r in rows]; return [math.log2(a/b) if a > 0 and b > 0 else float("nan") for a, b in zip(e[:-1], e[1:])]

def main():
    raw = H.backend_for(C.HostBackend()) if "--gpu" not in sys.argv else H.CupyRaw()
    out = {}
    out["A_nphi_only"] = [case(16, n, 8, raw) for n in (6, 12, 24, 48, 96)]
    out["B_nz_only"]   = [case(16, 24, n, raw) for n in (8, 16, 32, 64)]
    out["C_nr_only"]   = [case(n, 24, 8, raw) for n in (8, 16, 32, 64)]
    out["D_joint"]     = [case(8*2**i, 12*2**i, 8*2**i, raw) for i in range(4)]
    out["order_nz_only"] = orders(out["B_nz_only"], "amp_rel_err")
    out["order_joint"]   = orders(out["D_joint"], "amp_rel_err")
    for k in ("A_nphi_only", "B_nz_only", "C_nr_only", "D_joint"):
        print(f"\n{k}\n  nr nphi  nz   k*dz   amp_rel_err   predicted(1-sinc(k dz))")
        for r in out[k]: print(f"  {r['nr']:3d} {r['nphi']:4d} {r['nz']:3d}  {r['kdz']:.3f}  {r['amp_rel_err']:.3e}   {r['pred_z_stencil']:.3e}")
    print("\norder (nz only): ", [f"{o:.2f}" for o in out["order_nz_only"]]); print("order (joint):   ", [f"{o:.2f}" for o in out["order_joint"]])
    plateau = out["A_nphi_only"][-1]["amp_rel_err"]/out["A_nphi_only"][-2]["amp_rel_err"]
    ok_cause = all(abs(r["amp_rel_err"] - r["pred_z_stencil"]) < 0.15*r["pred_z_stencil"] for r in out["A_nphi_only"] + out["B_nz_only"][:2]) \
               and out["order_nz_only"][-1] >= 1.8 and out["order_joint"][-1] >= 1.8
    out["conclusion"] = ("CAUSE ISOLATED: plateau is the z-discretisation of the k=2*pi kink (8 cells/wavelength, predicted 1-sinc(k dz)); "
                         "it is insensitive to nphi and nr and converges at second order when nz (and jointly nr,nphi,nz) are refined. No kernel defect." if ok_cause
                         else "NOT EXPLAINED by z-stencil model: investigate (possible kernel defect).")
    out["nphi_plateau_ratio_last_pair"] = plateau
    print("\n" + out["conclusion"])
    json.dump(out, open("study_axis_joint_refinement.json", "w"), indent=1, default=float)
    return 0 if ok_cause else 1
if __name__ == "__main__": sys.exit(main())
