# -*- coding: utf-8 -*-
"""Report builder for ALADIN v4.0 Campaign 03 (tests 021-030).  Contract: build_report(R, here, name) -> markdown text (also written to here/name).
R = results dict written by campaign03.py (campaign03_results.json).  Every number in the report comes from R; nothing is typed in by hand
(the prose derivations are statements of identities, each of which is checked numerically by the test named next to it)."""
import os, math

def f(x, p=3):
    if x is None: return "n/a"
    try:
        if isinstance(x, bool): return str(x)
        if isinstance(x, str): return x
        if math.isnan(x): return "nan"
        if math.isinf(x): return "inf" if x > 0 else "-inf"
        if x == 0: return "0"
        return f"{x:.{p}e}" if (abs(x) < 1e-3 or abs(x) >= 1e5) else f"{x:.{p+1}g}"
    except Exception:
        return str(x)

def o(x):
    if x is None or (isinstance(x, float) and (math.isnan(x))): return "n/a"
    if isinstance(x, float) and math.isinf(x): return "exact"
    return f"{x:.2f}"

def olist(xs):
    return ", ".join(o(x) for x in xs) if xs else "n/a"

def oq(errs, orders, floor):
    """observed orders per refinement pair; a pair whose two errors are both at/below the declared round-off floor shows 'floor' (an order of noise is meaningless).
    floor: scalar or per-level list."""
    fl = floor if isinstance(floor, (list, tuple)) else [floor] * len(errs)
    if all(e <= q for e, q in zip(errs, fl)): return "at round-off floor (no order claimed)"
    out = []
    for k, x in enumerate(orders):
        out.append("floor" if (errs[k] <= fl[k] and errs[k + 1] <= fl[k + 1]) else o(x))
    return ", ".join(out)

def comp_order(x, c):
    errs = [r["region_comp_err"][c] for r in x["rows"]]
    if all(e == 0 for e in errs): return "exactly 0"
    return oq(errs, [p[c] for p in x["orders_region"]], [r["floor"] for r in x["rows"]])

def tbl(head, rows):
    esc = lambda c: str(c).replace("|", "\\|")
    out = ["| " + " | ".join(esc(c) for c in head) + " |", "|" + "|".join("---" for _ in head) + "|"]
    for r in rows: out.append("| " + " | ".join(esc(c) for c in r) + " |")
    return "\n".join(out)

def v(e, be):
    return e.get(be, {}).get("verdict", "n/a")

PURPOSE = {
 "021": "Decides, instead of assuming, whether div(curl B) = 0 holds for this staggering. A compatibility analysis shows no 3-point radial divergence can annihilate the kernel's curl; the EXACT residual is derived in closed form and checked to round-off, and the O(h^2) size of the residual is measured by refinement.",
 "022": "Compares the circulation of the interface-averaged cell-centred field around radial, azimuthal and axial block boundaries with the kernel curl times cell area summed over the block: an exact discrete Stokes theorem (round-off), plus the approximate statement 'kernel flux = analytic circulation' with measured convergence.",
 "023": "Gauss/discrete-conservation test: the volume integral of the finite-volume divergence of J equals the net boundary flux exactly (also with the axis face), a non-solenoidal control proves the check can fail, and the closed-form finite-volume divergence of the discrete curl is verified.",
 "024": "C(aB1 + bB2) = aC(B1) + bC(B2) on random, smooth, kink and near-axis fields in FP32/FP64 against a declared round-off bound, with exact sub-cases (zero field, negation, power-of-two scaling) and a perturbation sensitivity guard.",
 "025": "Constant fields give exactly zero current; uniform Cartesian and curl-free manufactured fields give a quantified, converging truncation error. The grid-scale null modes (odd-even patterns the current cannot see) are catalogued as a documented limitation.",
 "026": "Rotating a non-axisymmetric field by whole azimuthal cells must rotate J identically (bitwise in annulus mode), likewise phi-mirror and z-shift symmetry; axis mode must agree to round-off.",
 "027": "Discrete integration by parts for the curl operator: sum(vol (A.C(B) - B.C(A))) = discrete boundary terms + an explicit O(dr^2) metric-mismatch term, verified to round-off. This is an identity of the CURL OPERATOR ALONE; no energy-conservation claim is made.",
 "028": "curl(grad) with the compatible discrete gradient: the residual is computed in closed form (purely axial, O(dr^2)); point-sampled gradients converge at second order and incompatibly staggered data is detected as a first-order residual.",
 "029": "Nearly curl-free fields with large amplitude: absolute/relative error, FP32/FP64 sensitivity and refinement behaviour, with a truncation + round-off error model and an explicit information-loss threshold.",
 "030": "Randomised awkward grids (axis/annulus, ghost widths 1-3, FP32/FP64) with every algebraic check re-run on each, independent reference agreement, canary/ghost integrity, and AddressSanitizer on the host (compute-sanitizer on the GPU leg).",
}
PLOT_FILES = []

def make_plots(R, here):
    PLOT_FILES.clear()
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except Exception:
        return []
    d = os.path.join(here, "campaign03_plots"); os.makedirs(d, exist_ok=True)
    T = {k: e["host"] for k, e in R["tests"].items() if "host" in e}
    def hs_of(n): return [0.125 / 2 ** k for k in range(n)]
    def fig(name, title, series, slope=2.0, ylabel="max error", note=None):
        series = {k: x for k, x in series.items() if x and len(x[0]) == len(x[1]) and all(e > 0 for e in x[1]) and max(x[1]) > 1e-9}   # series at the round-off floor carry no convergence information
        if not series: return
        plt.figure(figsize=(6.6, 4.5)); first = None
        for lab, (hs, es) in series.items():
            plt.loglog(hs, es, "o-", lw=1.4, ms=4, label=lab); first = first or (hs, es)
        h0, e0 = first[0][0], first[1][0]; hh = [min(min(x[0]) for x in series.values()), max(max(x[0]) for x in series.values())]
        plt.loglog(hh, [e0 * (h / h0) ** slope for h in hh], "k--", lw=1, label=f"slope {slope:g}")
        plt.xlabel("h (coarse-grid spacing, halved per level)"); plt.ylabel(ylabel); plt.title(title, fontsize=10); plt.grid(True, which="both", alpha=.3)
        plt.legend(fontsize=7)
        if note: plt.figtext(0.01, 0.005, note, fontsize=6)
        p = os.path.join(d, name); plt.tight_layout(); plt.savefig(p, dpi=130); plt.close(); PLOT_FILES.append(p)
    try:
        c = T["021"]["convergence"]
        fig("t021_div_annulus.png", "021: max |div_w(curl B)| (annulus, region 0.6<=r<=1.4)", {x["field"][:22]: (hs_of(4), x["max_abs_div_region"]) for x in c if x["mode"] == "annulus"}, 2, "max |div_w J|")
        fig("t021_div_axis.png", "021: axis mode, divergence of J, all cells vs region r in [0.25,0.9]", {**{x["field"][:14] + " all": (hs_of(4), x["max_abs_div_all_cells"]) for x in c if x["mode"] == "axis"}, **{x["field"][:14] + " region": (hs_of(4), x["max_abs_div_region"]) for x in c if x["mode"] == "axis"}}, 1, "max |div J|")
        c = T["022"]["convergence"]
        fig("t022_stokes.png", "022: |kernel flux - analytic circulation| (annulus, M1)", {x["orient"]: ([r["h"] for r in x["rows"]], [r["err"] for r in x["rows"]]) for x in c if x["mode"] == "annulus" and x["field"].startswith("M1")}, 2, "abs error of block flux")
        c = T["023"]["convergence"]
        fig("t023_fvdiv.png", "023: max |div_fv J| (all cells)", {x["field"][:22]: ([r["h"] for r in x["rows"]], [r["max_abs_div"] for r in x["rows"]]) for x in c if x["mode"] == "annulus"}, 2, "max |div_fv J|")
        c = T["025"]["convergence"]
        fig("t025_nullspace.png", "025: curl-free / uniform fields, worst component (region)", {x["mode"][:3] + ": " + x["field"][:22]: ([r["h"] for r in x["rows"]], [max(r["region_comp_err"]) for r in x["rows"]]) for x in c if max(max(r["region_comp_err"]) for r in x["rows"]) > 1e-9}, 2, "max |J - J_exact|")
        c = T["028"]["convergence"]
        ser = {}
        for x in c:
            m = x["mode"][:3] + " " + x["psi"][:5]
            ser[m + " point-sampled"] = (hs_of(4), x["pointsampled_region_max"]); ser[m + " INCOMPATIBLE"] = (hs_of(4), x["incompatible_region_max"])
            if max(x["compatible_region_max"]) > 1e-9: ser[m + " compatible"] = (hs_of(4), x["compatible_region_max"])
        fig("t028_curlgrad.png", "028: |curl(grad psi)|: compatible vs point-sampled vs incompatible staggering", ser, 2, "max |J| (region)")
        c = T["029"]["refinement"]
        fig("t029_refinement.png", "029: error / A under refinement (nearly curl-free field)", {x["mode"]: ([r["h"] for r in x["rows"]], [r["err_over_A"] for r in x["rows"]]) for x in c}, 2, "max |J_h - J| / A")
        sw = T["029"]["sweep"]; plt.figure(figsize=(6.6, 4.5))
        for mode in ("annulus", "axis"):
            for dt in ("float64", "float32"):
                rows = [r for r in sw if r["mode"] == mode and r["dtype"] == dt]
                plt.loglog([r["A_over_eps"] for r in rows], [max(r["abs_err"], 1e-30) for r in rows], "o-" if dt == "float64" else "s--", ms=4, label=f"{mode} {dt}")
        plt.xlabel("component amplitude A"); plt.ylabel("max |J_h - J|"); plt.title("029: error vs amplitude of the irrotational background", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=7)
        p = os.path.join(d, "t029_amplitude.png"); plt.tight_layout(); plt.savefig(p, dpi=130); plt.close(); PLOT_FILES.append(p)
    except Exception as ex:
        PLOT_FILES.append(f"(plot error: {ex})")
    return list(PLOT_FILES)

def build_report(R, here, name="CAMPAIGN03_REPORT.md"):
    env, T, cert = R["env"], R["tests"], R["certification"]; TL = R["tolerances"]
    plots = make_plots(R, here); L = []; A = L.append
    A("# ALADIN v4.0 - Campaign 03 report (Tests 021-030)")
    A("**Discrete operator identities, conservation compatibility and algebraic consistency of `uct_curl.py`**\n")
    A(f"**Harness verdict: {cert['verdict']}**  \nCertification rule: *{cert['rule']}*.  ")
    A("This is the harness's own verdict; independent source-level certification still requires examining and reproducing the frozen code and harness.\n")
    A("> Scope: the kernel computes **J = curl(B)** (mu0 = 1) by cell-centred reconstruction. It is **not** the Faraday constrained-transport update; nothing in this report is a statement about CT, div(B) preservation or energy conservation.\n")
    A("## 1. Source, environment, frozen hashes")
    A(tbl(["item", "value"], [["kernel file / version", f"{os.path.basename(env['kernel_file'])} v{env['kernel_version']}"], ["kernel SHA-256", f"`{env['kernel_sha256']}`"],
        ["registered SHA-256 for this version", f"`{env['expected_sha256']}`"], ["source frozen and matches registry", env["source_frozen_and_matches"]],
        ["campaign03.py SHA-256 (harness)", f"`{env['campaign_harness_sha256']}`"], ["campaign01.py SHA-256 (helper)", f"`{env['campaign01_helper_sha256']}`"],
        ["campaign02.py SHA-256 (helper)", f"`{env['campaign02_helper_sha256']}`"], ["UTC", env["utc"]], ["python / numpy", f"{env['python']} / {env['numpy']}"],
        ["platform", env["platform"]], ["g++", env["gxx"]], ["GPU", env.get("gpu", "none")], ["CuPy / CUDA runtime / compute capability", f"{env.get('cupy', 'n/a')} / {env.get('cuda_runtime', 'n/a')} / {env.get('compute_capability', 'n/a')}"],
        ["GPU leg", env["gpu_leg_status"]]]))
    A("\n## 2. Declared criteria (fixed before execution)")
    A(tbl(["name", "value", "meaning"], [
        ["alg_factor", f(TL["alg_factor"]), "exact-identity tolerance = alg_factor x eps(dtype) x (largest term scale), per-level where the scale grows as 1/h or 1/h^2"],
        ["order_min", f(TL["order_min"]), "minimum observed order for second-order claims (last refinement pair), measured in a fixed physical region"],
        ["region_annulus / region_axis", f"{TL['region_annulus']} / {TL['region_axis']}", "physical radius windows used for order claims (never ring indices)"],
        ["axis_div_order_min", f(TL["axis_div_order_min"]), "axis-mode divergence of J is only first order over ALL cells (see F5)"],
        ["incompatible_order_max", f(TL["incompatible_order_max"]), "incompatibly staggered data must show a residual that is NOT second order (detection)"],
        ["sensitivity_min", f(TL["sensitivity_min"]), "every exact test must show a signal >= 10x its tolerance; otherwise it cannot discriminate and fails"],
        ["fp_factor / lin_factor", f"{f(TL['fp_factor'])} / {f(TL['lin_factor'])}", "FP32 bound and linearity bound factors"],
        ["conv_base", str(TL["conv_base"]), "coarsest (nr, nphi, nz) of every 4-level refinement (h halved each level)"]]))
    A("\n## 3. Mathematical framework: exact, approximate, not claimed")
    A("Annulus-mode stencils (cell-centred face averages B_c, 2h central differences D, compact face-weighted radial difference in Jz):")
    A("```\nJr   = (1/rc) D_phi[Bz_c] - D_z[Bphi_c]\nJphi = D_z[Br_c] - D_r[Bz_c]\nJz   = (1/rc) { [rf_{i+1} Bphi_f(i+1) - rf_i Bphi_f(i)]/dr - D_phi[Br_c] }\n```")
    A("Hand-derived consequences (each is **verified numerically** by the test in brackets; none is assumed):")
    A("""
* compact minus wide radial difference = -(1/4) delta_r^2 B, hence **Jz = Jz_wide - (1/(4 rc)) delta_r^2 Bphi_c** (021, 028).
* **EXACT** (021): wide, r-weighted divergence `div_w(C B) = D_z[ -(1/(4 rc)) delta_r^2 Bphi_c ]`. No 3-point radial divergence can satisfy both the Bz- and Bphi-compatibility conditions; the coefficient gap is dr/(4 rc) per ring.
* **EXACT** (023): finite-volume divergence (face-averaged, rf-weighted, conservative): `div_fv(C B) = -(1/(4 rc)) delta_r^2 [ (1/rc) D_phi Bz_c ]`. It is exactly zero when (1/rc) D_phi Bz_c is linear in r, and the wide divergence is its mirror image.
* **EXACT** (028): `C(grad_h psi) = (0, 0, -(1/(4 rc)) delta_r^2 Bphi_c)`; Jr and Jphi vanish identically; the residual is purely axial and O(dr^2).
* **EXACT** (022): discrete Stokes: the sum of kernel curl x cell area over a block equals the circulation of the INTERFACE-AVERAGED cell-centred field around the block boundary, for radial, azimuthal and axial orientations.
* **EXACT** (023): discrete Gauss: volume sum of div_fv J = net boundary flux (axis face flux = 0).
* **EXACT** (027): `S = sum vol (A.C(B) - B.C(A)) = r-boundary + z-boundary terms + (dr dphi dz/4) sum[ Bz_c delta_r^2 Aphi_c - Az_c delta_r^2 Bphi_c ]`, i.e. boundary terms plus an explicit O(dr^2) mismatch.
* **APPROXIMATE** (convergence, not machine zero): all of the above residuals scale as O(h^2); kernel flux vs analytic circulation; curl of point-sampled gradients; constant/uniform truncation.
* **NOT CLAIMED**: any exact identity in axis mode (cubic Cartesian Jz, one-sided ring-0 stencils): convergence only. Energy conservation. Faraday/CT properties. An exact discrete de Rham complex (the data show it does not exist for this staggering).
""")
    A("## 4. Summary")
    rows = []
    for t, e in T.items(): rows.append([t, e["name"], v(e, "host"), v(e, "cupy")])
    A(tbl(["test", "name", "host", "GPU"], rows))
    n_h = sum(1 for e in T.values() if v(e, "host") == "PASS"); n_g = sum(1 for e in T.values() if v(e, "cupy") == "PASS")
    A(f"\nHost: **{n_h}/10 PASS**.  GPU: **{n_g}/10 PASS** ({env['gpu_leg_status']}).  All-pass on both backends: **{cert['all_pass_both_backends']}**.\n")
    if "gpu_vs_host" in R:
        A("### GPU vs host agreement"); A(tbl(["grid", "r_min", "dtype", "max abs diff", "tol", "ok"], [[q["grid"], q["r_min"], q["dtype"], f(q["max_abs_diff"]), f(q["tol"]), q["ok"]] for q in R["gpu_vs_host"]]))
    elif not env["gpu_present"]:
        A("> **GPU leg: BLOCKED in this execution (no GPU/CuPy).** Per the certification rule the campaign is NOT CERTIFIED until the identical harness is run on a real GPU. Nothing is inferred for the GPU from the host results.\n")
    A("## 5. Per-test results (host leg; the GPU leg runs the identical code and is summarised in section 4)")
    for t, e in T.items():
        h = e["host"]; A(f"### Test {t} - {e['name']}  [host {v(e,'host')} | GPU {v(e,'cupy')}]")
        A(f"*Purpose.* {PURPOSE.get(t, '')}\n")
        if h.get("verdict") == "ERROR": A("```\n" + str(h.get("error", ""))[-1500 :] + "\n```")
        for fr in h.get("fail_reasons", []): A(f"* FAIL: {fr}")
        if t == "021":
            ca = h["compatibility_analysis"]; A(f"**Compatibility analysis.** Over {ca['n_rings']} rings the coefficient gap times dr lies in [{f(ca['min_dr_times_coeff_gap'])}, {f(ca['max_dr_times_coeff_gap'])}] (expected {ca['expected']}): the gap is nonzero, so no radial 3-point divergence annihilates the kernel curl.\n")
            A("**Exact identity** `div_w(C B) = D_z[-(1/4rc) delta_r^2 Bphi_c]` (annulus, random fields):"); r = h["exact_identity_rows"]
            A(tbl(["dtype", "grid", "max|div|", "max|prediction|", "|div - prediction|", "tol", "signal/tol", "ok"], [[x["dtype"], x["grid"], f(x["max_abs_div"]), f(x["max_abs_prediction"]), f(x["err_vs_prediction"]), f(x["tol"]), f(x["sensitivity"]), x["ok"]] for x in r]))
            A("\n**Exactly-zero sub-cases** (the identity says div = 0 when the right component vanishes):"); A(tbl(["case", "dtype", "max|div|", "tol", "ok"], [[x["case"], x["dtype"], f(x["max_abs_div"]), f(x["tol"]), x["ok"]] for x in h["exact_zero_subcases"]]))
            A("\n**Approximate: size of the nonzero divergence under refinement** (annulus region 0.6<=r<=1.4; axis all cells and region 0.25<=r<=0.9):")
            A(tbl(["mode", "field", "orders (all cells)", "orders (region)", "formula exact to round-off", "ok"], [[x["mode"], x["field"][:34], oq(x["max_abs_div_all_cells"], x["orders_all_cells"], x["roundoff_floor"]), oq(x["max_abs_div_region"], x["orders_region"], x["roundoff_floor"]), (x.get("exact_formula_holds_to_roundoff") if x["mode"] == "annulus" else "n/a (no exactness claimed in axis mode)"), x["ok"]] for x in h["convergence"]]))
            ax = h["axis_mode_random_field"]; A(f"\nAxis mode, random field: max |div| = {f(ax['max_abs_div'])}, deviation from the annulus formula {f(ax['max_dev_from_annulus_formula'])}. {ax['note']}. For fields whose divergence is at the declared round-off floor at every level the table shows the label instead of an order.\n")
            A("**Finding.** " + h["statement"] + "\n")
        elif t == "022":
            s = h["exact_summary"]; A(f"**Exact discrete Stokes** (kernel curl x area summed over a block vs circulation of interface-averaged field): {s['n']} cases (3 orientations x grids x FP32/FP64 x axis/annulus); worst |diff|/tol = {f(s['worst_diff_over_tol'])}; smallest gross-circulation/tol = {f(s['min_gross_over_tol'])} (every case has a signal far above its tolerance).\n")
            A("**Approximate: kernel block flux vs analytic circulation** (orders depend on the field and orientation - they are whatever is observed; a case whose error is at round-off at every level, i.e. the discrete flux equals the analytic flux to machine precision, is labelled so instead of showing noise):")
            A(tbl(["mode", "field", "orient", "orders", "ok"], [[x["mode"], x["field"][:30], x["orient"], oq([r["err"] for r in x["rows"]], x["orders"], 1e-12), x["ok"]] for x in h["convergence"]]))
            A(f"\nIndependent analytic-circulation self-check (quadrature vs closed form): max rel diff {f(h['analytic_reference_check_max_rel'])}.")
            A("\nBlock touching the axis (axis disc), error vs analytic circulation at the four levels:")
            A(tbl(["field", "errors (coarse to fine)", "orders", ], [[x["field"], ", ".join(f(e) for e in x["errs"]), oq(x["errs"], x["orders"], 1e-12)] for x in h["axis_disc"]]) + "\n")
        elif t == "023":
            A("**Exact discrete Gauss theorem:**"); A(tbl(["mode", "dtype", "volume sum of div_fv J", "net boundary flux", "diff", "tol", "ok"], [[x["mode"], x["dtype"], f(x["volume_integral_div"]), f(x["boundary_flux"]), f(x["diff"]), f(x["tol"]), x["ok"]] for x in h["gauss_identity_rows"]]))
            A("\n**Control (non-solenoidal field; the check must be able to fail):**"); A(tbl(["mode", "volume integral", "boundary flux", "gross", "nonzero fraction", "ok"], [[x["mode"], f(x["volume_integral_div"]), f(x["boundary_flux"]), f(x["gross"]), f(x["nonzero_fraction"]), x["ok"]] for x in h["nonsolenoidal_control"]]))
            A("\n**Exact closed form of the finite-volume divergence of the discrete curl** `div_fv(C B) = -(1/4rc) delta_r^2[(1/rc) D_phi Bz_c]`:"); A(tbl(["dtype", "grid", "max|div|", "max|prediction|", "|div - prediction|", "tol", "signal/tol", "ok"], [[x["dtype"], x["grid"], f(x["max_abs_div"]), f(x["max_abs_prediction"]), f(x["err_vs_prediction"]), f(x["tol"]), f(x["sensitivity"]), x["ok"]] for x in h["fv_closed_form_rows"]]))
            A("\n**Convergence of div_fv(J)** (a divergence-free analytic J gives a discrete divergence that is O(h^2) or exactly zero; 'net/gross' is the boundary-flux cancellation):")
            A(tbl(["mode", "field", "orders (all cells)", "orders (region)", "worst net/gross", "ok"], [[x["mode"], x["field"][:34], oq([r["max_abs_div"] for r in x["rows"]], x["orders_div_all_cells"], 1e-9), oq(x["max_abs_div_region"], x["orders_region"], 1e-9), f(max(r["net_over_gross"] for r in x["rows"])), x["ok"]] for x in h["convergence"]]))
            A("\n'At round-off floor' is shown when |div_fv J| < 1e-9 at every level (the finite-volume divergence vanishes identically for those fields; the declared per-level floor eps*Bmax/h^2 is ~1e-10 on the finest grid).\n")
        elif t == "024":
            s = h["summary"]; A(f"**Linearity:** {s['n_cases']} cases (random, smooth, kink and near-axis fields; FP32/FP64; annulus/axis); worst error/bound = {f(s['max_ratio_err_over_bound'])}; {s['cases_discriminating']} discriminating, {s['cases_perturbation_detected']} detect a deliberate perturbation, {s['cases_non_discriminating']} non-discriminating.\n")
            A("**Exact sub-cases** (zero field, negation, power-of-two scaling must be bitwise):"); A(tbl(["grid type", "grid", "zero field", "negation", "pow2 scaling diffs", "ok"], [[x["grid_type"], x["grid"], f(x["zero_field_max_abs"]), f(x["negation_max_abs_diff"]), f(max(x["pow2_max_abs_diff"].values())), x["ok"]] for x in h["exact"]]))
            A("\n" + s["non_discriminating_note"] + "\n")
        elif t == "025":
            A("**Constant axial field and constants:**"); A(tbl(["mode", "dtype", "max|J|", "bitwise zero", "ok"], [[x["mode"], x["dtype"], f(x["max_abs_J"]), x["bitwise_zero"], x["ok"]] for x in h["constant_axial"]]))
            A("\n**Truncation error of uniform Cartesian / curl-free manufactured fields** (observed order per component over the last refinement pairs, physical region; a component that is identically zero is shown as exactly 0):")
            A(tbl(["mode", "field", "orders (region)", "worst final-level region err", "ok"], [[x["mode"], x["field"][:34], "; ".join(nm + ": " + comp_order(x, c) for c, nm in enumerate(("r", "phi", "z"))), f(max(x["rows"][-1]["region_comp_err"])), x["ok"]] for x in h["convergence"]]))
            A("\n**Spurious grid-scale null modes (documented limitation):**"); A(tbl(["pattern", "dtype", "max|B|", "max|J|", "ok"], [[x["mode"], x["dtype"], f(x["max_abs_B"]), f(x["max_abs_J"]), x["ok"]] for x in h["spurious_null_modes"]]))
            A("\n" + h["limitation"] + "\n")
        elif t == "026":
            sm = h["summary"]; A(f"All annulus rotation/mirror/z-shift cases bitwise identical: **{sm['annulus_all_bitwise']}**; worst axis difference over tolerance: {f(sm['axis_worst_diff_over_tol'])}.\n")
            A(tbl(["mode", "dtype", "field", "shifts", "max abs diff", "bitwise", "ok"], [[x["mode"], x["dtype"], x["field"][:28], x["shifts_tested"], f(x["max_abs_diff"]), x["bitwise"], x["ok"]] for x in h["rotation"]]))
            A(f"\nMirror cases: {len(h['mirror'])}, all ok = {all(x['ok'] for x in h['mirror'])}; z-shift cases: {len(h['z_shift'])}, all ok = {all(x['ok'] for x in h['z_shift'])}. Mirror rule B'r(phi)=Br(-phi), B'phi=-Bphi(-phi), B'z=Bz(-phi) gives J'r=-Jr(-phi), J'phi=+Jphi(-phi), J'z=-Jz(-phi).\n")
        elif t == "027":
            A("**Exact identity** S = boundary terms + (dr dphi dz/4) sum[Bz_c delta_r^2 Aphi_c - Az_c delta_r^2 Bphi_c]:")
            A(tbl(["dtype", "grid", "S direct", "S predicted", "|diff|", "tol", "mismatch/S", "mismatch/tol", "ok"], [[x["dtype"], x["grid"], f(x["S_direct"]), f(x["S_predicted"]), f(x["diff"]), f(x["tol"]), f(x["mismatch_over_S"]), f(x["mismatch_over_tol"]), x["ok"]] for x in h["exact_rows"]]))
            A(f"\nThe mismatch term is necessary (without it the identity fails by orders of magnitude): **{h['mismatch_is_needed']}**. Analytic self-check max rel diff {f(h['analytic_reference_check_max_rel'])}.")
            A("\n**Approximate: discrete S against the analytic boundary flux / volume integral of the continuous identity** (error at the four levels, observed orders; a pair with S ~ 0 by symmetry sits at the round-off floor):")
            A(tbl(["mode", "pair (A / B)", "S analytic", "errors (coarse to fine)", "orders", "ok"], [[x["mode"], x["pair"][:70], f(x["rows"][-1]["flux_analytic"]), ", ".join(f(r["err"]) for r in x["rows"]), oq([r["err"] for r in x["rows"]], x["orders"], 1e-12), x["ok"]] for x in h["convergence"]]))
            A("\n" + h["no_energy_claim"] + "\n")
        elif t == "028":
            A("**Exact identity C(grad_h psi) = (0, 0, -(1/4rc) delta_r^2 Bphi_c) for arbitrary cell data psi:**")
            A(tbl(["dtype", "g", "grid", "err Jr", "err Jphi", "err Jz vs closed form", "tol", "|Jz|/tol", "ok"], [[x["dtype"], x["g"], x["grid"], f(x["err_Jr"]), f(x["err_Jphi"]), f(x["err_Jz_vs_closed_form"]), f(x["tol"]), f(x["sensitivity"]), x["ok"]] for x in h["exact_rows"]]))
            A("\n**Approximate: residual of curl(grad) for smooth potentials** (orders per refinement pair; 'round-off-limited' means the residual is at round-off for every level):")
            def ro(x, key):
                return "round-off-limited" if max(x[key]) < 1e-9 else olist(x[key.replace("_region_max", "_orders").replace("region_max", "orders")])
            A(tbl(["mode", "potential", "compatible gradient", "point-sampled gradient", "INCOMPATIBLE staggering (must NOT be 2nd order)", "ok"],
                  [[x["mode"], x["psi"][:30], "round-off-limited" if max(x["compatible_region_max"]) < 1e-9 else olist(x["compatible_orders"]), olist(x["pointsampled_orders"]), olist(x["incompatible_orders"]), x["ok"]] for x in h["convergence"]]))
            A("\n**Finding.** " + h["statement"] + "\n")
        elif t == "029":
            A("**Amplitude sweep** (B = A grad(psi) + small solenoidal part; true |J| " + f(h["sweep"][0]["J_true_max"]) + "):")
            A(tbl(["mode", "dtype", "A", "max|B|", "abs err", "rel err of J", "model bound", "signal lost", "ok"], [[x["mode"], x["dtype"], f(x["A_over_eps"]), f(x["B_max"]), f(x["abs_err"]), f(x["rel_err"]), f(x["bound"]), x["signal_lost"], x["ok"]] for x in h["sweep"]]))
            A("\nInformation-loss amplitude A* (smallest swept A where the error reaches the signal): " + "; ".join(f"{k}: {f(val)}" for k, val in h["information_loss"].items()) + ".")
            A("\n**Refinement** (err/A and the relative error of the recovered signal):"); A(tbl(["mode", "orders of err/A", "err/A at levels", "ok"], [[x["mode"], olist(x["orders"]), ", ".join(f(r["err_over_A"]) for r in x["rows"]), x["ok"]] for x in h["refinement"]]))
            A("\nLinear scaling of the error with A: " + ", ".join(f"A={f(x['A'])}: err/A ratio {f(x['ratio_to_A1'])}" for x in h["linear_scaling"]) + ".\n")
            A("**Finding.** " + h["statement"] + "\n")
        elif t == "030":
            c = h["coverage"]; A("**Coverage (grids on which each check was exercised):** " + ", ".join(f"{k}: {val}" for k, val in c.items()) + ".\n")
            A(tbl(["grid", "g", "mode", "dtype", "reference rel diff", "linearity", "rotation", "mirror", "canary", "ghosts untouched", "ASAN clean", "ok"],
                  [[x["grid"], x["g"], x["mode"], x["dtype"], f(x["checks"]["reference"]["rel_diff"]), x["checks"]["linearity"]["ok"], x["checks"]["rotation"]["ok"], x["checks"]["mirror"]["ok"], x["canary_intact"], x["ghost_layers_untouched"], (h["host_addresssanitizer"][i]["clean"] if i < len(h["host_addresssanitizer"]) else "n/a"), x["ok"]] for i, x in enumerate(h["grids"])]))
            A("\n" + h["scope_note"] + "\n")
    A("## 6. Convergence plots")
    for p in plots:
        if p.endswith(".png"): A(f"![{os.path.basename(p)}](campaign03_plots/{os.path.basename(p)})")
        else: A(p)
    A("\n## 7. Findings and limitations (not defects of this campaign's harness; properties of the operator)")
    for fi in R["findings"]: A(f"* **{fi['id']} - {fi['title']}.** {fi['detail']}")
    A("""
* **L1.** No exact discrete de Rham complex: div(curl) and curl(grad) are O(dr^2), not zero, with the exact closed forms above. A driver that needs div(J)=0 to round-off (or a curl-free subspace) must not use this kernel's J for that purpose.
* **L2.** Axis mode makes no exact claim; divergence of J is first order next to the axis (F5).
* **L3.** Grid-scale null modes (F6) are invisible to J; the driver must not rely on J to detect odd-even noise in B.
* **L4.** The kernel is the current reconstruction, **not** the Faraday CT update; nothing here bears on div(B) preservation.
* **L5.** FP64 is recommended near the axis (Campaign 02 axis/round-off analysis); this campaign did not change that.
* **L6.** The GPU leg is only as certified as it was executed: see section 4.
* **L7.** Independent source-level review of the frozen code and this harness is still pending.
""")
    A("## 8. Defect and observation register")
    A("No kernel defect was found by Campaign 03 (the kernel source is unchanged and frozen). The observations below are properties of the discretisation, recorded with their evidence:")
    A(tbl(["id", "observation", "kind", "evidence"], [
        ["O1", "div_w(C B) and div_fv(C B) are nonzero O(dr^2)", "property (not a defect)", "Tests 021, 023 exact closed forms"],
        ["O2", "curl(grad_h psi) has a purely axial O(dr^2) residual", "property", "Test 028 exact"],
        ["O3", "axis-mode div J is first order over all cells", "property", "Test 021 (F5)"],
        ["O4", "grid-scale null modes", "property / limitation", "Test 025"],
        ["O5", "integration by parts needs an O(dr^2) mismatch term", "property", "Test 027"]]))
    A("\n## 9. Harness development history and corrections (disclosed)")
    A("Each row is a failure or mis-specification found while building THIS harness, before the final run. No kernel change was made. Where a criterion was changed, the reason is physical/numerical and the whole campaign was re-run.\n")
    A(tbl(["phase", "item", "observation", "resolution"], [[d["phase"], d["item"], d["observation"], d["resolution"]] for d in R.get("dev_log", [])]))
    A("\n## 10. Requirement checklist (from the Campaign 03 specification)")
    gp = env["gpu_present"]; allh = all(v(e, "host") == "PASS" for e in T.values()); allg = all(v(e, "cupy") == "PASS" for e in T.values())
    A(tbl(["requirement", "status", "evidence"], [
        ["All 10 tests on CPU", "MET" if allh else "NOT MET", "section 4"], ["All 10 tests on a real GPU", "MET" if allg else ("NOT MET (blocked: no GPU in this execution)" if not gp else "NOT MET"), "section 4"],
        ["Full source and harness SHA-256 recorded", "MET", "section 1"], ["Independent mathematical references (analytic circulations/fluxes, closed-form residuals, independent multi-index reference), not two copies of one stencil", "MET", "tests 021-030"],
        ["Actual errors, convergence rates, tolerances, failure conditions reported", "MET", "section 5, section 2"], ["Exact identities separated from approximate consistency tests", "MET", "section 3 and per-test"],
        ["Unsupported identities documented, not manufactured", "MET", "findings F1-F7, section 7"], ["Every failure and correction preserved", "MET", "section 9"],
        ["Report, JSON, plots and execution log generated", "MET", "CAMPAIGN03_REPORT.md, campaign03_results.json, campaign03_plots/, campaign03_execution.log"],
        ["Tests 021, 022, 027, 028 establish mathematical compatibility before demanding machine-zero residuals", "MET", "section 3; compatibility analysis in 021"]]))
    A("\n## 11. Reproducibility")
    A("```\nunzip the package into an empty folder (single uct_curl.py + campaign01.py campaign02.py campaign03.py make_report_campaign0*.py)\npython campaign03.py            # host leg always; GPU leg if CuPy + a CUDA device are present\n```\nOutputs: `campaign03_results.json`, `CAMPAIGN03_REPORT.md`, `campaign03_plots/`, `campaign03_execution.log`. The harness prints a STALE PACKAGE banner if `uct_curl.py` is not the newest registered version and a WARNING if its SHA-256 matches no registered source.")
    text = "\n".join(L) + "\n"
    open(os.path.join(here, name), "w", encoding="utf-8").write(text)
    return text
