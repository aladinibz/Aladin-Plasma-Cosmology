#!/usr/bin/env python3
"""
ALADIN v4.0 - Campaign 02: Native cylindrical geometry, axis regularity & boundary integrity   (tests 011-020)
Target : uct_curl.py v1.2 (executed UNMODIFIED; its SHA-256 is checked against EXPECTED_SHA below)

Needs campaign01.py in the same folder (shared grid / backend helpers). Run:  python campaign02.py
Deliverables written next to this file: campaign02_results.json, CAMPAIGN02_REPORT.md

All tolerances are DECLARED BEFORE EXECUTION (TOL2). They are not changed after seeing results; if a change were ever
needed it would be documented with a fresh run (see "Post-hoc changes" in the report: none unless listed).
"""
import os, sys, json, math, hashlib, re, subprocess, datetime, platform, traceback, importlib.util, random
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
sys.path.insert(0, HERE)
import campaign01 as C

K = C.K
F64, F32 = np.float64, np.float32
KNOWN_SHA = {"1.2": "820fedf812877c819c77b68511e854fa853242758f9bfa331b363a1915e542a8",      # v1.2: the file submitted for the first Campaign 02 run
             "1.3": "e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e"}      # v1.3: D8/D9/D10 validator corrections (CUDA source identical to v1.2)
EXPECTED_SHA = KNOWN_SHA.get(getattr(C.K, "VERSION", ""), "")
OUT = os.environ.get("CAMPAIGN_OUT", HERE)

# ----------------------------------------------------------------------------
# DECLARED CRITERIA (fixed before any Campaign 02 result was looked at)
# ----------------------------------------------------------------------------
TOL2 = dict(
    geom_rel=1e-13,             # areas / volumes / edge lengths vs quadrature, relative
    exact_fp64=C.TOL["exact_fp64"], exact_fp32=C.TOL["exact_fp32"],
    order_min=C.TOL["order_min"],         # 1.8: last-pair observed order for any "second-order" claim
    silent_zero_ratio=1e-3,     # a cell with |J| < ratio*|J_ref| where |J_ref| > 5% of the ring maximum is a silently zeroed derivative
    ref_check=1e-9,             # independent Cartesian 6th-order reference vs hand-derived curl
    roll_axis_rel=1e-12,        # rotation-by-k-cells covariance on axis grids (round-off only); annulus grids must be bitwise identical
    seam_wrong_factor=100.0,    # deliberately wrong seam closure must raise the seam error by at least this factor (test sensitivity)
    ghost_parity_rel=1e-12,     # parity-rule ghost values vs analytic continuation, relative to field scale
    equiv_fp64=1e-12,           # kernel vs independent-index reference, relative to max|J|
    fp32_factor=C.TOL["fp32_factor"],
    cond_trunc=20.0,            # declared truncation allowance in the conditioning sweep: err <= cond_trunc*(dr^2+dz^2) + fp_bound
    noise_margin=100.0,         # the start-radius ambiguity threshold must exceed the FP64 construction noise floor (in units of dr) by at least this factor
    tiny_rmin_fraction=1e-3,    # a grid with 0 < r_faces[g] < fraction*dr is axis-like and must be rejected (or treated as an axis)
    overflow_safe=1e-4,         # relative error allowed for finite outputs under amplitude scaling
)

def dn(d): return np.dtype(d).name
EPS = C.EPS
zero = C.zero; const = C.const

# ----------------------------------------------------------------------------
# Regular Cartesian fields (hand-derived curl, then verified against an independent numeric Cartesian curl)
# ----------------------------------------------------------------------------
Z0 = lambda x, y, z: 0*x
EPSK, KK = 0.3, 2*math.pi
CART = {
 "uniform transverse (0.7,-0.4,0)": (lambda x, y, z: 0.7 + 0*x, lambda x, y, z: -0.4 + 0*x, Z0, Z0, Z0, Z0),
 "shear Bx=y -> Jz=-1":             (lambda x, y, z: y, Z0, Z0, Z0, Z0, lambda x, y, z: -1 + 0*x),
 "Bz=x -> Jy=-1":                   (Z0, Z0, lambda x, y, z: x, Z0, lambda x, y, z: -1 + 0*x, Z0),
 "Bz=y -> Jx=+1":                   (Z0, Z0, lambda x, y, z: y, lambda x, y, z: 1 + 0*x, Z0, Z0),
 "QUAD":                            (lambda x, y, z: x*y + z*x, lambda x, y, z: x**2 + y*z, lambda x, y, z: x*y*z,
                                     lambda x, y, z: x*z - y, lambda x, y, z: x - y*z, lambda x, y, z: x),
 "SMOOTH":                          (lambda x, y, z: np.sin(y) + z**2, lambda x, y, z: z*np.cos(x), lambda x, y, z: x*y*z + np.sin(z),
                                     lambda x, y, z: x*z - np.cos(x), lambda x, y, z: 2*z - y*z, lambda x, y, z: -z*np.sin(x) - np.cos(y)),
 "KINK-poly":                       (lambda x, y, z: 0.5 + x*y + np.sin(z) + x*y**2, lambda x, y, z: -0.3 + x**2 + z*y + x**3, lambda x, y, z: 0.2*x*z + y**3,
                                     lambda x, y, z: 3*y**2 - y, lambda x, y, z: np.cos(z) - 0.2*z, lambda x, y, z: x + 3*x**2 - 2*x*y),
 # a straight pinch Bphi=0.5r displaced helically (m=1 kink): B = Bpinch(x - xi(z)), xi = EPS*(cos kz, sin kz)
 "HELICAL KINK (m=1)":              (lambda x, y, z: -0.5*(y - EPSK*np.sin(KK*z)), lambda x, y, z: 0.5*(x - EPSK*np.cos(KK*z)), Z0,
                                     lambda x, y, z: -0.5*EPSK*KK*np.sin(KK*z), lambda x, y, z: 0.5*EPSK*KK*np.cos(KK*z), lambda x, y, z: 1 + 0*x),
}
FIELD = {n: C._cart_field(*v, n) for n, v in CART.items()}

def cart_reference_check(spec):
    """Hand-derived curl vs 6th-order central-difference Cartesian curl at random points (no cylindrical formula involved)."""
    Bx, By, Bz, Jx, Jy, Jz = spec
    def dd(fn, axis, pt, h=1e-3):
        c = np.array([-1/60, 3/20, -3/4, 0, 3/4, -3/20, 1/60]); out = 0.0
        for k, ck in zip(range(-3, 4), c):
            if ck == 0: continue
            q = list(pt); q[axis] = q[axis] + k*h; out = out + ck*fn(*q)
        return out/h
    rng = np.random.default_rng(17); pt = tuple(rng.uniform(-0.9, 0.9, 120) for _ in range(3)); x, y, z = pt
    num = (dd(Bz, 1, pt) - dd(By, 2, pt), dd(Bx, 2, pt) - dd(Bz, 0, pt), dd(By, 0, pt) - dd(Bx, 1, pt))
    ref = (Jx(*pt), Jy(*pt), Jz(*pt))
    return max(float(np.max(np.abs(a - b))) for a, b in zip(num, ref))

def axis_grid(n, r1=1.0, **kw):
    return C.Grid(*n, r0=0.0, r1=r1, **kw)

def levels(base, L, r0=0.0, r1=1.0, g=2):
    return [tuple(b*2**i for b in base) for i in range(L)]

def comp_rule(rows_err, rows_scale, o_last):
    """Declared pass rule for a 'second-order' component: last-pair order >= order_min OR error at round-off at every level."""
    exact = max(rows_err) <= TOL2["exact_fp64"]*max(max(rows_scale), 1.0)     # reference scale floored at the field amplitude (1) when the exact J is identically 0
    return bool(o_last >= TOL2["order_min"] or exact)

def orders_of(seq):
    out = []
    for a, b in zip(seq[:-1], seq[1:]):
        out.append(math.inf if b == 0 else (math.nan if a == 0 else math.log2(a/b)))
    return out

# ----------------------------------------------------------------------------
# Independent reference operator for AXIS grids (multi-index slicing; NOT the module's flat-index emulation)
# ----------------------------------------------------------------------------
def ref_curl_axis(Br, Bp, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g):
    Br, Bp, Bz, rc = [np.asarray(x, dtype=np.float64) for x in (Br, Bp, Bz, rc)]
    npg = nphi + 2*g
    phic = (np.arange(npg) - g + 0.5)*dphi
    cph, sph = np.cos(phic)[:, None], np.sin(phic)[:, None]
    def cart(a):                                     # ring array index a -> (Bx, By) on phi cells 1..npg-3 (cubic stencil), all z
        if a == g: brc = (5*Br[a] + 15*Br[a + 1] - 5*Br[a + 2] + Br[a + 3])/16
        else:      brc = (-Br[a - 1] + 9*Br[a] + 9*Br[a + 1] - Br[a + 2])/16
        P = Bp[a]
        bpc = np.full_like(brc, np.nan)
        bpc[1:npg - 1] = (-P[0:npg - 2] + 9*P[1:npg - 1] + 9*P[2:npg] - P[3:npg + 1])/16
        return brc*cph - bpc*sph, brc*sph + bpc*cph
    ring = {a: cart(a) for a in range(g, g + nr + 1)}
    sl = lambda A, a: A[a, g:g + nphi, g:g + nz]
    sd = math.sin(dphi)
    jr = np.zeros((nr, nphi, nz)); jp = np.zeros_like(jr); jz = np.zeros_like(jr)
    BZ = lambda a: 0.5*(Bz[a][:, :-1] + Bz[a][:, 1:])
    BRc = lambda a: 0.5*(Br[a] + Br[a + 1]); BPc = lambda a: 0.5*(Bp[a][:-1] + Bp[a][1:])
    for i in range(nr):
        a = g + i
        bz = BZ(a)
        jr[i] = (bz[g + 1:g + 1 + nphi, g:g + nz] - bz[g - 1:g - 1 + nphi, g:g + nz])/(2*dphi)/rc[a]
        bpc_phi = BPc(a)                                              # (npg, nzg)
        jr[i] -= (bpc_phi[g:g + nphi, g + 1:g + 1 + nz] - bpc_phi[g:g + nphi, g - 1:g - 1 + nz])/(2*dz)
        brc = BRc(a)
        dbr_dz = (brc[g:g + nphi, g + 1:g + 1 + nz] - brc[g:g + nphi, g - 1:g - 1 + nz])/(2*dz)
        if i == 0: dbz_dr = (-3*BZ(a) + 4*BZ(a + 1) - BZ(a + 2))/(2*dr)
        else:      dbz_dr = (BZ(a + 1) - BZ(a - 1))/(2*dr)
        jp[i] = dbr_dz - dbz_dr[g:g + nphi, g:g + nz]
        fx, fy = ring[a]
        if i == 0:
            f1x, f1y = ring[a + 1]; f2x, f2y = ring[a + 2]
            dxr = (-3*fx + 4*f1x - f2x)/(2*dr); dyr = (-3*fy + 4*f1y - f2y)/(2*dr)
        else:
            px, py = ring[a + 1]; mx, my = ring[a - 1]
            dxr = (px - mx)/(2*dr); dyr = (py - my)/(2*dr)
        den = 2*rc[a]*sd
        dxt = (fx[g + 1:g + 1 + nphi] - fx[g - 1:g - 1 + nphi])/den; dyt = (fy[g + 1:g + 1 + nphi] - fy[g - 1:g - 1 + nphi])/den
        c0, s0 = cph[g:g + nphi], sph[g:g + nphi]
        jz[i] = (c0*dyr[g:g + nphi] - s0*dxr[g:g + nphi] - s0*dyt - c0*dxt)[:, g:g + nz]
    return [jr, jp, jz]

# ============================================================================
# TEST 011  Cylindrical metric identities
# ============================================================================
def t011(be):
    res = {}; fails = []
    xg, wg = np.polynomial.legendre.leggauss(6)
    def quad(f, a, b):                                  # Gauss-Legendre on [a,b], exact for polynomials up to degree 11
        return (b - a)/2*np.sum(wg*f((b - a)/2*xg + (a + b)/2))
    rows = []
    for (nr, nphi, nz, g, r0, dr, dz) in [(16, 16, 8, 2, 0.0, 0.0625, 0.125), (17, 11, 9, 2, 0.0, 0.037, 0.11), (7, 5, 3, 3, 0.0, 0.2, 0.3),
                                         (16, 16, 8, 2, 0.5, 0.0625, 0.125), (5, 3, 2, 2, 1.3, 0.17, 0.05)]:
        dphi = 2*math.pi/nphi
        rf = r0 + (np.arange(nr + 1 + 2*g) - g)*dr; rc = r0 + (np.arange(nr + 2*g) - g + 0.5)*dr          # independent closed forms
        Gm = C.Grid(nr, nphi, nz, g=g, r0=r0, r1=r0 + nr*dr, z0=0.0, z1=nz*dz)
        km_rf, km_rc = K.make_grid(nr, dr, g, F64) if r0 == 0.0 else (None, None)
        e_coord = max(float(np.max(np.abs(Gm.rf - rf))), float(np.max(np.abs(Gm.rc - rc))))
        e_mk = max(float(np.max(np.abs(km_rf - rf))), float(np.max(np.abs(km_rc - rc)))) if km_rf is not None else 0.0
        mid = float(np.max(np.abs(rc - 0.5*(rf[:-1] + rf[1:]))))
        inner = slice(g, g + nr)
        # face areas, volumes, edge lengths: closed forms vs numerical quadrature of the defining integrals
        e_area = e_vol = e_edge = 0.0
        for i in range(nr):
            a, b = rf[g + i], rf[g + i + 1]
            Ar_hi = b*dphi*dz; Ar_q = quad(lambda r: r*0 + b, 0, 1)*dphi*dz      # radial face at r=b: area = r dphi dz
            Az_cf = 0.5*(b**2 - a**2)*dphi; Az_q = quad(lambda r: r, a, b)*dphi           # axial face (annular sector)
            V_cf = Az_cf*dz; V_q = quad(lambda r: r, a, b)*dphi*dz                         # volume = integral of r dr dphi dz
            Ap_cf = (b - a)*dz; Ap_q = quad(lambda r: r*0 + 1, a, b)*dz                  # azimuthal face (r-z plane)
            L_phi = rc[g + i]*dphi; L_phi_q = quad(lambda p: 0*p + rc[g + i], 0, dphi)    # edge length along phi at r_c
            e_area = max(e_area, abs(Az_cf - Az_q)/max(abs(Az_q), 1e-300), abs(Ap_cf - Ap_q)/max(abs(Ap_q), 1e-300), abs(Ar_hi - Ar_q)/max(abs(Ar_q), 1e-300))
            e_vol = max(e_vol, abs(V_cf - V_q)/V_q)
            e_edge = max(e_edge, abs(L_phi - L_phi_q)/L_phi_q)
        # total volume = pi (R^2 - r0^2) * L and the Gauss identity for F = (r, 0, 0): flux = div F * V with div F = 2
        Vtot = sum(0.5*(rf[g + i + 1]**2 - rf[g + i]**2)*dphi*dz for i in range(nr))*nphi*nz
        Vexact = math.pi*((r0 + nr*dr)**2 - r0**2)*nz*dz
        gauss = max(abs((rf[g + i + 1]**2 - rf[g + i]**2)*dphi*dz - 2*(0.5*(rf[g + i + 1]**2 - rf[g + i]**2)*dphi*dz))/((rf[g + i + 1]**2 - rf[g + i]**2)*dphi*dz) for i in range(nr))
        inv = float(np.max(np.abs(1.0/rc[inner]*rc[inner] - 1.0)))
        rows.append(dict(grid=[nr, nphi, nz], g=g, r_min=r0, dr=dr, dz=dz, coord_err_Grid=e_coord, coord_err_make_grid=e_mk, centre_is_midpoint=mid,
                         area_rel_err=e_area, volume_rel_err=e_vol, edge_rel_err=e_edge, total_volume_rel_err=abs(Vtot - Vexact)/Vexact,
                         gauss_identity=gauss, one_over_r_roundtrip=inv, positive_active_radii=bool(np.all(rc[inner] > 0))))
    res["geometry_rows"] = rows
    tol = TOL2["geom_rel"]
    for r in rows:
        for k in ("coord_err_Grid", "coord_err_make_grid", "centre_is_midpoint", "area_rel_err", "volume_rel_err", "edge_rel_err", "total_volume_rel_err", "gauss_identity", "one_over_r_roundtrip"):
            if r[k] > tol*max(1.0, r["dr"]*0 + 1) and not (k.startswith("coord") and r[k] <= 4*np.finfo(float).eps*max(1.0, r["r_min"] + 20*r["dr"])):
                fails.append(f"{k} = {r[k]:.2e} on grid {r['grid']} (tol {tol:.0e})")
        if not r["positive_active_radii"]: fails.append("non-positive active radius")
    # metric sensitivity: the kernel must actually consume r_centers (as 1/r) and r_faces (as flux radii) - raw kernel, launcher bypassed
    G = C.Grid(16, 16, 8, r0=0.5, r1=1.5); B = G.sample(C.ADV, F64)
    raw = be if be.name == "host" else CupyRaw()
    Jb = G.run(raw, B, F64)
    s = G.g + 5; delta = 0.2*G.dr; ph = 4
    rc2 = G.rc.copy(); rc2[s] += delta
    J2 = raw.run(*B, G.rf, rc2, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
    ref0 = C.ref_curl(*B, G.rf, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g); ref2 = C.ref_curl(*B, G.rf, rc2, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
    changed = [bool(np.any(J2[c][G.sl] != Jb[c][G.sl])) for c in range(3)]
    only_cell = all(np.array_equal(J2[c][G.sl][np.arange(G.nr) != s - G.g], Jb[c][G.sl][np.arange(G.nr) != s - G.g]) for c in range(3))
    err_rc = max(float(np.max(np.abs(J2[c][G.sl] - ref2[c])))/max(float(np.max(np.abs(ref2[c]))), 1e-30) for c in range(3))
    # Jr scales exactly as r_c/(r_c+delta) in that ring (Jr = (1/r_c) dBz/dphi - dBphi/dz  ->  only the first term scales)
    rf2 = G.rf.copy(); rf2[s + 1] += delta
    J3 = raw.run(*B, rf2, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
    ref3 = C.ref_curl(*B, rf2, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
    err_rf = max(float(np.max(np.abs(J3[c][G.sl] - ref3[c])))/max(float(np.max(np.abs(ref3[c]))), 1e-30) for c in range(3))
    res["metric_sensitivity"] = dict(perturbed_r_center_index=int(s), delta=delta, outputs_changed_per_component=changed, only_that_ring_changed=bool(only_cell),
                                     max_rel_diff_vs_reference_with_perturbed_r_centers=err_rc, max_rel_diff_vs_reference_with_perturbed_r_faces=err_rf)
    if not (changed[0] and changed[2] and only_cell): fails.append("kernel does not respond to r_centers exactly in the perturbed ring")
    if err_rc > TOL2["equiv_fp64"] or err_rf > TOL2["equiv_fp64"]: fails.append("kernel metric response disagrees with independent reference")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

class CupyRaw(C.CupyBackend):
    """CuPy backend with the launcher's validation switched OFF (for deliberately inconsistent inputs)."""
    def run(self, Br, Bp, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g, J=None, ptr_override=None):
        import cupy as cp
        dt = Br.dtype.type; shp = (nr + 2*g, nphi + 2*g, nz + 2*g)
        d = [cp.asarray(a) for a in (Br, Bp, Bz)]
        dJ = [cp.asarray(x) for x in J] if J is not None else [cp.full(shp, np.nan, dtype=dt) for _ in range(3)]
        getattr(self.mod, self.launcher)(*d, *dJ, cp.asarray(rf.astype(dt)), cp.asarray(rc.astype(dt)), dr, dphi, dz, nr, nphi, nz, g, False)
        cp.cuda.Device().synchronize()
        return [cp.asnumpy(x) for x in dJ]

# ============================================================================
# TEST 012  Axis regularity
# ============================================================================
def axis_errors(G, J, fld):
    ref = G.ref(fld)
    r0 = [float(np.max(np.abs(J[c][G.sl][0].astype(np.float64) - ref[c][0]))) for c in range(3)]
    r1 = [float(np.max(np.abs(J[c][G.sl][1].astype(np.float64) - ref[c][1]))) for c in range(3)]
    gl = [float(np.max(np.abs(J[c][G.sl].astype(np.float64) - ref[c]))) for c in range(3)]
    return r0, r1, gl, ref

def t012(be):
    res = dict(fields={}); fails = []
    refchk = {}
    for name in ("uniform transverse (0.7,-0.4,0)", "shear Bx=y -> Jz=-1", "Bz=x -> Jy=-1", "Bz=y -> Jx=+1", "QUAD", "SMOOTH", "KINK-poly"):
        refchk[name] = cart_reference_check(CART[name])
        if refchk[name] > TOL2["ref_check"]: fails.append(f"reference for '{name}' disagrees with independent Cartesian curl: {refchk[name]:.2e}")
    res["reference_check_max_abs_diff"] = refchk
    for name in ("uniform transverse (0.7,-0.4,0)", "shear Bx=y -> Jz=-1", "Bz=x -> Jy=-1", "Bz=y -> Jx=+1", "QUAD", "SMOOTH", "KINK-poly"):
        fld = FIELD[name]; fres = {}
        for base in C.GRIDS:
            rows = []
            for n in levels(base, 4):
                G = axis_grid(n); J = G.run(be, G.sample(fld, F64), F64)
                r0, r1, gl, ref = axis_errors(G, J, fld)
                fin = all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3))
                # silently zeroed derivatives on the first active ring
                zc = 0
                for c in range(3):
                    rr = ref[c][0]; m = np.abs(rr) > 0.05*max(float(np.max(np.abs(ref[c][0]))), 1e-300)
                    zc += int(np.sum(np.abs(J[c][G.sl][0][m]) < TOL2["silent_zero_ratio"]*np.abs(rr[m])))
                rows.append(dict(n=list(n), ring0=r0, ring1=r1, global_=gl, Jmax=[float(np.max(np.abs(x))) for x in ref], finite=fin, silently_zeroed=zc))
            o0 = [orders_of([r["ring0"][c] for r in rows])[-1] for c in range(3)]; og = [orders_of([r["global_"][c] for r in rows])[-1] for c in range(3)]
            ok0 = [comp_rule([r["ring0"][c] for r in rows], [r["Jmax"][c] for r in rows], o0[c]) for c in range(3)]
            okg = [comp_rule([r["global_"][c] for r in rows], [r["Jmax"][c] for r in rows], og[c]) for c in range(3)]
            key = "x".join(map(str, base))
            fres[key] = dict(rows=rows, ring0_last_orders=o0, global_last_orders=og, ring0_ok=ok0, global_ok=okg)
            if not all(ok0): fails.append(f"'{name}' {key}: ring-0 order below {TOL2['order_min']}: {[round(x, 2) for x in o0]}")
            if not all(okg): fails.append(f"'{name}' {key}: global order below {TOL2['order_min']}: {[round(x, 2) for x in og]}")
            if any(not r["finite"] for r in rows): fails.append(f"'{name}' {key}: non-finite output")
            if any(r["silently_zeroed"] for r in rows): fails.append(f"'{name}' {key}: silently zeroed derivative cells {[r['silently_zeroed'] for r in rows]}")
        res["fields"][name] = fres
    # no guard / no zeroing in the source; first active centre strictly positive
    res["source_checks"] = dict(guard_threshold_in_kernel=("1e-8" in C.KSRC), first_centre_over_dr=0.5)
    if res["source_checks"]["guard_threshold_in_kernel"]: fails.append("a fixed 1/r guard threshold is present in the kernel source")
    # FP32 on the first ring against FP64 (declared bound)
    f32 = []
    for L in range(3):
        n = tuple(b*2**L for b in (16, 16, 8)); G = axis_grid(n)
        B64 = G.sample(FIELD["KINK-poly"], F64); J64 = G.run(be, B64, F64); J32 = G.run(be, G.sample(FIELD["KINK-poly"], F32), F32)
        d = max(float(np.max(np.abs(J32[c][G.sl].astype(np.float64) - J64[c][G.sl]))) for c in range(3)); bnd = C.fp32_bound(G, max(float(np.max(np.abs(b))) for b in B64))
        f32.append(dict(n=list(n), diff=d, bound=bnd, ok=bool(d <= bnd)))
    res["fp32_vs_fp64_KINK-poly"] = f32
    if not all(r["ok"] for r in f32): fails.append("FP32 vs FP64 outside declared bound near the axis")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 013  Non-axisymmetric m=1 kink
# ============================================================================
def t013(be):
    res = dict(fields={}); fails = []
    nm = "HELICAL KINK (m=1)"
    res["reference_check_max_abs_diff"] = {nm: cart_reference_check(CART[nm]), "KINK-poly": cart_reference_check(CART["KINK-poly"])}
    if max(res["reference_check_max_abs_diff"].values()) > TOL2["ref_check"]: fails.append("kink reference disagrees with independent Cartesian curl")
    res["field"] = dict(description="straight pinch Bphi=0.5r displaced helically: B=Bpinch(x-xi(z)), xi=eps(cos kz, sin kz), eps=%.2f, k=2pi" % EPSK,
                        analytic_J="Jx=-0.5 eps k sin kz, Jy=0.5 eps k cos kz, Jz=1", transverse_current_at_axis=0.5*EPSK*KK)
    for name in (nm, "KINK-poly"):
        fld = FIELD[name]; fres = {}
        for base in C.GRIDS:
            rows = []
            for n in levels(base, 4):
                G = axis_grid(n); J = G.run(be, G.sample(fld, F64), F64)
                r0, r1, gl, ref = axis_errors(G, J, fld)
                rows.append(dict(n=list(n), ring0=r0, ring1=r1, global_=gl, Jmax=[float(np.max(np.abs(x))) for x in ref]))
            o0 = [orders_of([r["ring0"][c] for r in rows])[-1] for c in range(3)]; o1 = [orders_of([r["ring1"][c] for r in rows])[-1] for c in range(3)]
            og = [orders_of([r["global_"][c] for r in rows])[-1] for c in range(3)]
            ok = [comp_rule([r[w][c] for r in rows], [r["Jmax"][c] for r in rows], o[c]) for w, o in (("ring0", o0), ("ring1", o1), ("global_", og)) for c in range(3)]
            key = "x".join(map(str, base))
            fres[key] = dict(rows=rows, ring0_last_orders=o0, ring1_last_orders=o1, global_last_orders=og, all_ok=bool(all(ok)))
            if not all(ok): fails.append(f"'{name}' {key}: second-order claim not demonstrated (ring0 {[round(x, 2) for x in o0]}, ring1 {[round(x, 2) for x in o1]}, global {[round(x, 2) for x in og]})")
        res["fields"][name] = fres
    # the kink is genuinely non-axisymmetric: transverse current on the axis is nonzero and phi-dependent in (Jr, Jphi); kernel must reproduce it
    amp_rows = []
    for n in levels((8, 8, 4), 4):
        G = axis_grid(n); J = G.run(be, G.sample(FIELD[nm], F64), F64); ref = G.ref(FIELD[nm])
        amp = float(np.max(np.hypot(J[0][G.sl][0], J[1][G.sl][0]))); amp_ref = float(np.max(np.hypot(ref[0][0], ref[1][0])))
        amp_rows.append(dict(n=list(n), kernel=amp, analytic_at_cell_centres=amp_ref, abs_err=abs(amp - amp_ref), rel_err=abs(amp - amp_ref)/amp_ref))
    oa = orders_of([r["abs_err"] for r in amp_rows])
    res["axis_ring_transverse_amplitude"] = dict(rows=amp_rows, orders=oa, expected_0p5_eps_k=0.5*EPSK*KK, nonzero_and_phi_dependent=True)
    if oa[-1] < TOL2["order_min"]: fails.append(f"transverse axis-current amplitude error does not converge at second order: {[round(x, 2) for x in oa]}")
    G = axis_grid((32, 32, 16)); J = G.run(be, G.sample(FIELD[nm], F64), F64)
    # FP32
    G = axis_grid((32, 32, 16)); J32 = G.run(be, G.sample(FIELD[nm], F32), F32)
    d32 = max(float(np.max(np.abs(J32[c][G.sl].astype(np.float64) - J[c][G.sl]))) for c in range(3)); b32 = C.fp32_bound(G, 1.0)
    res["fp32_vs_fp64"] = dict(diff=d32, bound=b32, ok=bool(d32 <= b32))
    if d32 > b32: fails.append("FP32 outside bound for kink field")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# shared helpers for tests 014-020
# ============================================================================
def ref_any(G, B, dtype=F64):
    """Independent-index reference of the discrete operator (annulus: campaign01.ref_curl, axis: ref_curl_axis)."""
    fn = ref_curl_axis if G.rf[G.g] == 0.0 else C.ref_curl
    return fn(*B, G.rf, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)

def nmax(x):
    """max|x| that returns +inf when any element is NaN/Inf (a NaN must never make a comparison silently pass)."""
    x = np.abs(np.asarray(x, dtype=np.float64))
    return float('inf') if not np.isfinite(x).all() else float(x.max())

def equiv_err(G, J, ref):
    sc = max(max(nmax(r) for r in ref), 1e-300)
    return max(nmax(J[c][G.sl].astype(np.float64) - ref[c]) for c in range(3))/sc

def random_B(G, dtype, rng):
    g = G.g; sh = lambda a, b, c: (G.nr + a + 2*g, G.nphi + b + 2*g, G.nz + c + 2*g)
    return [rng.uniform(-1, 1, sh(*d)).astype(dtype) for d in ((1, 0, 0), (0, 1, 0), (0, 0, 1))]

def backend_for(be):
    return be if be.name == "host" else CupyRaw()

def finite_in(J, G):
    return all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3))

def nonfinite_mask(J, G):
    m = np.zeros((G.nr, G.nphi, G.nz), bool)
    for c in range(3): m |= ~np.isfinite(J[c][G.sl])
    return m

# ============================================================================
# TEST 014  Radial ghost parity
# ============================================================================
def parity_ghosts(G, B):
    """Fill the inner radial ghost layers (index < g) by the regularity rule: (r,phi)->(-r,phi+pi); Br,Bphi change sign, Bz does not."""
    g = G.g; h = G.nphi//2
    Br, Bp, Bz = [b.copy() for b in B]
    jc = lambda j: g + ((j - g + h) % G.nphi)                  # phi centre / phi face index shifted by pi (periodic)
    for a in range(g + 1):                                      # Br faces a < g -> a' = 2g - a  (a == g is the axis face itself: kept)
        if a == g: continue
        ap = 2*g - a
        for j in range(G.nphi + 2*g): Br[a, j, :] = -B[0][ap, jc(j), :]
    for a in range(g):                                          # Bphi/Bz centres a < g -> a' = 2g-1-a
        ap = 2*g - 1 - a
        for j in range(G.nphi + 1 + 2*g): Bp[a, j, :] = -B[1][ap, jc(j), :]
        for j in range(G.nphi + 2*g): Bz[a, j, :] = B[2][ap, jc(j), :]
    return [Br, Bp, Bz]

def t014(be):
    res = dict(rows=[]); fails = []
    raw = backend_for(be)
    for name in ("QUAD", "SMOOTH", "KINK-poly", "HELICAL KINK (m=1)"):
        fld = FIELD[name]
        for n in [(16, 16, 8), (12, 8, 6), (9, 20, 5)]:
            G = axis_grid(n); B = G.sample(fld, F64); scale = max(float(np.max(np.abs(b))) for b in B)
            Bp_ = parity_ghosts(G, B)
            gh = lambda X: [(X[0][:G.g]), (X[1][:G.g]), (X[2][:G.g])]
            d_par = max(float(np.max(np.abs(a - b))) for a, b in zip([x[:G.g] for x in Bp_], [x[:G.g] for x in B]))/scale
            # deliberately wrong rule (no sign change) -> must be clearly different (test sensitivity)
            Bw = [x.copy() for x in Bp_]
            Bw[0][:G.g] = -Bw[0][:G.g]; Bw[1][:G.g] = -Bw[1][:G.g]
            d_wrong = max(float(np.max(np.abs(a - b))) for a, b in zip([x[:G.g] for x in Bw], [x[:G.g] for x in B]))/scale
            # kernel must not depend on inner-ghost content: analytic / parity / NaN / huge / zero  -> bitwise identical
            variants = {"analytic": B, "parity": Bp_}
            for tag, val in (("NaN", np.nan), ("+1e300", 1e300), ("zero", 0.0)):
                X = [b.copy() for b in B]
                X[0][:G.g] = val; X[1][:G.g] = val; X[2][:G.g] = val
                variants[tag] = X
            outs = {k: G.run(raw, v, F64) for k, v in variants.items()}
            same = {k: all(np.array_equal(outs[k][c][G.sl], outs["analytic"][c][G.sl]) for c in range(3)) for k in outs}
            ref = G.ref(fld); e = max(float(np.max(np.abs(outs["parity"][c][G.sl] - ref[c]))) for c in range(3))
            row = dict(field=name, n=list(n), parity_vs_analytic_rel=d_par, wrong_rule_rel=d_wrong, bitwise_identical_output=same, parity_run_err_vs_analytic=e)
            res["rows"].append(row)
            if d_par > TOL2["ghost_parity_rel"]: fails.append(f"{name} {n}: parity ghosts differ from analytic continuation by {d_par:.2e}")
            if d_wrong < 1e-3: fails.append(f"{name} {n}: wrong-sign rule not distinguishable (test insensitive)")
            if not all(same.values()): fails.append(f"{name} {n}: kernel output depends on inner ghost content: {[k for k, v in same.items() if not v]}")
    # odd nphi: phi+pi is not a grid cell -> parity layer is undefined; the kernel must still run and be ghost-independent
    G = axis_grid((12, 11, 6)); B = G.sample(FIELD["SMOOTH"], F64); X = [b.copy() for b in B]
    for x in X: x[:G.g] = np.nan
    a1 = G.run(raw, B, F64); a2 = G.run(raw, X, F64)
    res["odd_nphi_11"] = dict(parity_constructible=False, bitwise_identical_with_NaN_inner_ghosts=all(np.array_equal(a1[c][G.sl], a2[c][G.sl]) for c in range(3)),
                              finite=finite_in(a2, G))
    if not (res["odd_nphi_11"]["bitwise_identical_with_NaN_inner_ghosts"] and res["odd_nphi_11"]["finite"]): fails.append("odd nphi: output depends on inner ghosts / non-finite")
    # the axis face value Br(r=0) IS read: must hold the limiting value (a wrong value must change the result)
    # (a uniform radial perturbation c*r_hat is curl-free, so the probe must carry a phi dependence: sin(2 phi))
    G = axis_grid((16, 16, 8)); B = G.sample(FIELD["QUAD"], F64); X = [b.copy() for b in B]
    X[0][G.g] += np.sin(2*G.pc)[:, None]
    Jb, Jx = G.run(raw, B, F64), G.run(raw, X, F64)
    d = max(float(np.max(np.abs(Jx[c][G.sl] - Jb[c][G.sl]))) for c in range(3))
    d_ring = max(float(np.max(np.abs(Jx[c][G.sl][0] - Jb[c][G.sl][0]))) for c in range(3)); d_far = max(float(np.max(np.abs(Jx[c][G.sl][2:] - Jb[c][G.sl][2:]))) for c in range(3))
    res["axis_face_is_consumed"] = dict(output_change_when_axis_face_Br_perturbed_by_sin2phi=d, change_ring0=d_ring, change_rings_ge2=d_far, as_documented=bool(d_ring > 1e-3 and d_far <= 1e-12))
    if not res["axis_face_is_consumed"]["as_documented"]: fails.append(f"axis face Br(r=0): expected to be consumed by ring 0 only (ring0 change {d_ring:.2e}, rings>=2 change {d_far:.2e})")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 015  Periodic azimuthal closure
# ============================================================================
def fourier_fields(m):
    w = lambda x, y: (x + 1j*y)**m
    wm = lambda x, y: (x + 1j*y)**max(m - 1, 0)
    A = _cartfield = C._cart_field
    # family A: Bz = Re w^m  ->  Jx = -m Im w^(m-1), Jy = -m Re w^(m-1), Jz = 0
    fa = A(Z0, Z0, lambda x, y, z: np.real(w(x, y)) + 0*z,
           lambda x, y, z: -m*np.imag(wm(x, y)) + 0*z, lambda x, y, z: -m*np.real(wm(x, y)) + 0*z, Z0, f"Bz=Re w^{m}")
    # family B: (Bx,By) = (Re w^m, Im w^m)  ->  Jz = 2m Im w^(m-1), Jx = Jy = 0
    fb = A(lambda x, y, z: np.real(w(x, y)) + 0*z, lambda x, y, z: np.imag(w(x, y)) + 0*z, Z0, Z0, Z0,
           lambda x, y, z: 2*m*np.imag(wm(x, y)) + 0*z, f"B=(Re,Im) w^{m}")
    return fa, fb

# Bz = 0.6x + 0.8y (neither even nor odd about phi=0, so every deliberately wrong closure changes the seam result): Jx = 0.8, Jy = -0.6
SEAM_LIN = C._cart_field(Z0, Z0, lambda x, y, z: 0.6*x + 0.8*y + 0*z, lambda x, y, z: 0.8 + 0*x, lambda x, y, z: -0.6 + 0*x, Z0, "Bz=0.6x+0.8y")

def t015(be):
    res = dict(fourier={}, seam={}, rotation={}); fails = []
    raw = backend_for(be)
    for m in (1, 2, 3, 4):
        for fld in fourier_fields(m):
            for r0, tag in ((0.0, "axis"), (0.5, "annulus")):
                rows = []
                for n in levels((16, 16, 8), 4):
                    G = C.Grid(*n, r0=r0, r1=1.0 if r0 == 0.0 else 1.5)
                    J = G.run(raw, G.sample(fld, F64), F64); ref = G.ref(fld)
                    rows.append(dict(n=list(n), errs=C.err_vs_ref(G, J, ref), Jmax=[float(np.max(np.abs(x))) for x in ref]))
                od = orders_of  # per component last-pair order
                lo = [orders_of([r["errs"][c] for r in rows])[-1] for c in range(3)]
                ok = [comp_rule([r["errs"][c] for r in rows], [r["Jmax"][c] for r in rows], lo[c]) for c in range(3)]
                key = f"{fld.name} [{tag}]"; res["fourier"][key] = dict(m=m, rows=rows, last_orders=lo, ok=ok)
                if not all(ok): fails.append(f"{key}: order {[round(x, 2) for x in lo]} below {TOL2['order_min']}")
    # Seam probes. (i) m=3 non-axisymmetric field: error at the seam cells (phi index 0 and nphi-1) must not exceed 10x the interior error.
    # (ii) sensitivity of the test itself: m=1 field Bz=0.6x+0.8y on a 48-cell phi grid (truncation ~ dphi^2/6 ~ 3e-3); closures that are deliberately wrong
    #      (zero / edge-copy / swapped ghosts) must change the seam output by >= seam_wrong_factor x the correct-closure seam error.
    def mk(r0, n):
        return C.Grid(*n, r0=r0, r1=1.0 if r0 == 0.0 else 1.5)
    def ghosted(B, G, mode):
        X = [b.copy() for b in B]
        for x in X:
            lo, hi = x[:, :G.g, :].copy(), x[:, -G.g:, :].copy()
            if mode == "zero": x[:, :G.g, :] = 0; x[:, -G.g:, :] = 0
            elif mode == "edge": x[:, :G.g, :] = x[:, G.g:G.g + 1, :]; x[:, -G.g:, :] = x[:, -G.g - 1:-G.g, :]
            elif mode == "swapped": x[:, :G.g, :] = hi; x[:, -G.g:, :] = lo
            elif mode == "wrap":
                idx = G.g + np.mod(np.arange(x.shape[1]) - G.g, G.nphi); x[:] = x[:, idx, :]
        return X
    def seam_cells(a, G):
        return np.concatenate([a[:, :1, :].ravel(), a[:, -1:, :].ravel()])
    for r0, tag in ((0.0, "axis"), (0.5, "annulus")):
        G = mk(r0, (32, 24, 8)); fld = fourier_fields(3)[0]; B = G.sample(fld, F64); ref = G.ref(fld); J = G.run(raw, B, F64)
        es = max(float(np.max(np.abs(seam_cells(J[c][G.sl] - ref[c], G)))) for c in range(3))
        ei = max(float(np.max(np.abs((J[c][G.sl] - ref[c])[:, 3:-3, :]))) for c in range(3))
        Jw = G.run(raw, ghosted(B, G, "wrap"), F64)
        wrap = max(float(np.max(np.abs(Jw[c][G.sl] - J[c][G.sl]))) for c in range(3))/max(max(float(np.max(np.abs(ref[c]))) for c in range(3)), 1e-30)
        G1 = mk(r0, (32, 48, 8)); f1 = SEAM_LIN; B1 = G1.sample(f1, F64); ref1 = G1.ref(f1); J1 = G1.run(raw, B1, F64)
        e_good = max(float(np.max(np.abs(seam_cells(J1[c][G1.sl] - ref1[c], G1)))) for c in range(3))
        amp = {}
        for mode in ("zero", "edge", "swapped"):
            Jb = G1.run(raw, ghosted(B1, G1, mode), F64)
            amp[mode] = max(float(np.max(np.abs(seam_cells(Jb[c][G1.sl] - J1[c][G1.sl], G1)))) for c in range(3))/max(e_good, 1e-300)
        res["seam"][tag] = dict(m3_seam_error=es, m3_interior_error=ei, m3_periodic_wrap_vs_analytic_ghosts_rel_diff=wrap, m1_correct_closure_seam_error=e_good, wrong_closure_effect_over_good_error=amp)
        if es > 10*ei: fails.append(f"{tag}: seam error {es:.2e} exceeds 10x interior error {ei:.2e}")
        if wrap > TOL2["equiv_fp64"]: fails.append(f"{tag}: periodic wrap closure differs from analytic closure ({wrap:.1e})")
        if min(amp.values()) < TOL2["seam_wrong_factor"]: fails.append(f"{tag}: seam test not sensitive enough to deliberately wrong closures (needs >= {TOL2['seam_wrong_factor']:g}x): {amp}")
    # Rotation covariance. Annulus: the same cylindrical field sampled with phi origin shifted by k cells must give the output rolled by k (bitwise).
    # Axis: the physical field is rotated by k*dphi about z (Cartesian field evaluated at the rotated point, components rotated back) - round-off only.
    for r0, tag in ((0.5, "annulus"), (0.0, "axis")):
        G = C.Grid(16, 16, 8, r0=r0, r1=1.0 if r0 == 0.0 else 1.5)
        base = C.ADV if r0 else FIELD["SMOOTH"]; B0 = G.sample(base, F64); J0 = G.run(raw, B0, F64); rows = []
        for k in (1, 3, 8, 15):
            s_ = k*G.dphi
            if r0:
                sh = C.Field(lambda r, p, z, f=base, s=s_: f.Br(r, p + s, z), lambda r, p, z, f=base, s=s_: f.Bp(r, p + s, z),
                             lambda r, p, z, f=base, s=s_: f.Bz(r, p + s, z), zero, zero, zero, "shifted")
            else:     # in cylindrical components a rotation of the physical field is the same phi shift (components are rotation-invariant)
                sh = C.Field(lambda r, p, z, f=base, s=s_: f.Br(r, p + s, z), lambda r, p, z, f=base, s=s_: f.Bp(r, p + s, z),
                             lambda r, p, z, f=base, s=s_: f.Bz(r, p + s, z), zero, zero, zero, "shifted")
            Js = G.run(raw, G.sample(sh, F64), F64)
            sc = max(float(np.max(np.abs(J0[c][G.sl]))) for c in range(3))
            e = max(float(np.max(np.abs(np.roll(J0[c][G.sl], -k, axis=1) - Js[c][G.sl]))) for c in range(3))/sc
            bit = all(np.array_equal(np.roll(J0[c][G.sl], -k, axis=1), Js[c][G.sl]) for c in range(3))
            rows.append(dict(k=k, max_rel_diff=e, bitwise=bool(bit)))
        res["rotation"][tag] = dict(rows=rows)
        if any(r["max_rel_diff"] > TOL2["roll_axis_rel"] for r in rows): fails.append(f"rotation covariance on {tag} grid beyond round-off ({TOL2['roll_axis_rel']:.0e}): {rows}")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 016  Yee staggered geometry
# ============================================================================
def impulse_probe(raw, G, rng_pos):
    """Single-face unit impulses: kernel output must equal the independent reference everywhere (value AND support)."""
    rows = []
    shp = lambda extra: (G.nr + extra[0] + 2*G.g, G.nphi + extra[1] + 2*G.g, G.nz + extra[2] + 2*G.g)
    shapes = [shp((1, 0, 0)), shp((0, 1, 0)), shp((0, 0, 1))]
    for comp in range(3):
        for pos in rng_pos[comp]:
            B = [np.zeros(s) for s in shapes]; B[comp][pos] = 1.0
            J = G.run(raw, B, F64); ref = ref_any(G, B)
            sup_k = {c: set(map(tuple, np.argwhere(J[c][G.sl] != 0))) for c in range(3)}
            sup_r = {c: set(map(tuple, np.argwhere(ref[c] != 0))) for c in range(3)}
            d = max(nmax(J[c][G.sl] - ref[c]) for c in range(3)); sc = max(max(nmax(r) for r in ref), 1e-300)
            # tolerate round-off-level support differences: a cell counts only if |value| > 1e-12*scale
            thr = 1e-12*sc
            sk = {c: set(map(tuple, np.argwhere(np.abs(J[c][G.sl]) > thr))) for c in range(3)}
            sr = {c: set(map(tuple, np.argwhere(np.abs(ref[c]) > thr))) for c in range(3)}
            rows.append(dict(array=("Br", "Bphi", "Bz")[comp], pos=list(pos), rel_value_diff=d/sc, support_cells=[len(sk[c]) for c in range(3)],
                             support_match=bool(all(sk[c] == sr[c] for c in range(3)))))
    return rows

def t016(be):
    res = dict(grids=[]); fails = []
    raw = backend_for(be); rng = np.random.default_rng(16)
    awkward = [  # (nr, nphi, nz, g, r0)    annulus and axis; includes extreme aspect ratios, nz=1, nr=1, prime sizes, g=1,2,3
        (1, 3, 1, 2, 0.5), (3, 3, 2, 2, 0.5), (5, 4, 3, 1, 0.5), (7, 13, 3, 3, 0.5), (33, 5, 2, 2, 0.5), (2, 2, 2, 2, 0.5), (1, 1, 1, 1, 0.5), (13, 7, 11, 2, 1.7),
        (3, 5, 2, 2, 0.0), (7, 13, 3, 3, 0.0), (33, 5, 2, 2, 0.0), (4, 3, 1, 2, 0.0), (5, 6, 2, 2, 0.0), (11, 17, 9, 2, 0.0), (64, 4, 3, 3, 0.0)]
    for (nr, nphi, nz, g, r0) in awkward:
        dr = 0.083 if r0 == 0.0 else 0.11
        G = C.Grid(nr, nphi, nz, g=g, r0=r0, r1=r0 + nr*dr, z0=-0.3, z1=-0.3 + nz*0.07)
        row = dict(grid=[nr, nphi, nz], g=g, r_min=r0, mode="axis" if r0 == 0.0 else "annulus")
        # (a) coordinate arrays: every face/centre against closed forms
        e_rf = float(np.max(np.abs(G.rf - (r0 + (np.arange(nr + 1 + 2*g) - g)*G.dr)))); e_rc = float(np.max(np.abs(G.rc - (r0 + (np.arange(nr + 2*g) - g + 0.5)*G.dr))))
        km = K.make_grid(nr, G.dr, g, F64) if r0 == 0.0 else None
        e_mk = 0.0 if km is None else max(float(np.max(np.abs(km[0] - G.rf))), float(np.max(np.abs(km[1] - G.rc))))
        cp_, sp_, sd_, ax_ = K.axis_inputs(G.rf, G.dphi, nphi, g, F64)
        phic = (np.arange(nphi + 2*g) - g + 0.5)*G.dphi
        e_ai = max(float(np.max(np.abs(cp_ - np.cos(phic)))), float(np.max(np.abs(sp_ - np.sin(phic)))), abs(sd_ - math.sin(G.dphi)))
        # (b) required array extents (the kernel's stride arithmetic assumes exactly these)
        ext = dict(Br=(nr + 1 + 2*g, nphi + 2*g, nz + 2*g), Bphi=(nr + 2*g, nphi + 1 + 2*g, nz + 2*g), Bz=(nr + 2*g, nphi + 2*g, nz + 1 + 2*g), J=(nr + 2*g, nphi + 2*g, nz + 2*g))
        B = random_B(G, F64, rng); shp_ok = [B[i].shape == t for i, t in enumerate((ext["Br"], ext["Bphi"], ext["Bz"]))]
        # (c) random-field equivalence and unit-impulse support probes
        accepted = True
        try:
            K.validate_inputs(*B, *[np.zeros(ext["J"]) for _ in range(3)], G.rf, G.rc, G.dr, G.dphi, G.dz, nr, nphi, nz, g)
        except K.CurlContractError as ex:
            accepted = False; row["rejected_message"] = str(ex)[:100]
        row.update(rf_err=e_rf, rc_err=e_rc, make_grid_err=e_mk, axis_inputs_err=e_ai, axis_flag=int(ax_), expected_axis_flag=int(r0 == 0.0),
                   extents_ok=bool(all(shp_ok)), validator_accepts=accepted)
        if max(e_rf, e_rc, e_mk, e_ai) > 4*EPS[F64]*max(1.0, r0 + nr*G.dr + 2*g): fails.append(f"grid {row['grid']}: coordinate/trig arrays deviate")
        if int(ax_) != int(r0 == 0.0): fails.append(f"grid {row['grid']}: wrong axis flag")
        if accepted:
            J = G.run(raw, B, F64); ref = ref_any(G, B)
            row["random_field_rel_diff"] = equiv_err(G, J, ref)
            if row["random_field_rel_diff"] > TOL2["equiv_fp64"]: fails.append(f"grid {row['grid']} g={g}: random-field kernel/reference mismatch {row['random_field_rel_diff']:.2e}")
            # impulse positions: first/last/middle of each array, including ghost corners and the axis face
            pos = []
            for extra in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
                sh = (nr + extra[0] + 2*g, nphi + extra[1] + 2*g, nz + extra[2] + 2*g)
                ps = {(0, 0, 0), tuple(s - 1 for s in sh), tuple(s//2 for s in sh), (g, g, g), (g + 1 if g + 1 < sh[0] else g, sh[1]//2, sh[2]//2), (sh[0]//2, g, g), (sh[0]//2, sh[1] - 1 - g, sh[2] - 1 - g)}
                pos.append(sorted(p for p in ps if all(0 <= p[i] < sh[i] for i in range(3))))
            row["impulses"] = impulse_probe(raw, G, pos)
            bad = [i for i in row["impulses"] if i["rel_value_diff"] > TOL2["equiv_fp64"] or not i["support_match"]]
            row["impulse_failures"] = len(bad)
            if bad: fails.append(f"grid {row['grid']} g={g}: {len(bad)} impulse probes disagree with reference (first: {bad[0]['array']} {bad[0]['pos']})")
        else:
            row["note"] = "grid rejected by the launcher validator (contract) - no kernel launch"
        # (d) off-by-one extents must be rejected
        rej = {}
        for nm, i, dim in (("Br", 0, 0), ("Bphi", 1, 1), ("Bz", 2, 2)):
            for ax_i in range(3):
                for dlt in (-1, 1):
                    Bm = [b for b in B]; shp2 = list(B[i].shape); shp2[ax_i] += dlt
                    if min(shp2) < 1: continue
                    Bm[i] = np.zeros(shp2)
                    try:
                        K.validate_inputs(*Bm, *[np.zeros(ext["J"]) for _ in range(3)], G.rf, G.rc, G.dr, G.dphi, G.dz, nr, nphi, nz, g); rej[f"{nm}[axis{ax_i}]{dlt:+d}"] = False
                    except K.CurlContractError: rej[f"{nm}[axis{ax_i}]{dlt:+d}"] = True
        row["off_by_one_extent_rejected"] = all(rej.values()); row["off_by_one_cases"] = len(rej)
        if accepted and not all(rej.values()): fails.append(f"grid {row['grid']}: off-by-one array extent accepted: {[k for k, v in rej.items() if not v][:3]}")
        res["grids"].append(row)
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 017  Cylindrical manufactured solutions
# ============================================================================
# native cylindrical fields, curl derived by hand from  Jr=(1/r)dBz/dphi-dBphi/dz, Jphi=dBr/dz-dBz/dr, Jz=(1/r)(d(rBphi)/dr-dBr/dphi)
M1 = C.Field(lambda r, p, z: r**2*z*np.sin(2*p) + np.cos(z), lambda r, p, z: r*z*np.cos(p) + r**3*np.sin(z), lambda r, p, z: r**2*np.sin(p)*np.cos(z),
             lambda r, p, z: r*np.cos(p)*np.cos(z) - r*np.cos(p) - r**3*np.cos(z),
             lambda r, p, z: r**2*np.sin(2*p) - np.sin(z) - 2*r*np.sin(p)*np.cos(z),
             lambda r, p, z: 2*z*np.cos(p) + 4*r**2*np.sin(z) - 2*r*z*np.cos(2*p), "M1 (mixed r,phi,z polynomial-trig)")
M2 = C.Field(lambda r, p, z: np.sin(p)*np.cos(2*z)/r + r*z, lambda r, p, z: r*np.cos(3*p)*np.sin(z) + 1/r, lambda r, p, z: np.sin(2*r)*np.cos(p) + z**2*np.cos(2*p),
             lambda r, p, z: (-np.sin(2*r)*np.sin(p) - 2*z**2*np.sin(2*p))/r - r*np.cos(3*p)*np.cos(z),
             lambda r, p, z: -2*np.sin(p)*np.sin(2*z)/r + r - 2*np.cos(2*r)*np.cos(p),
             lambda r, p, z: 2*np.cos(3*p)*np.sin(z) - np.cos(p)*np.cos(2*z)/r**2, "M2 (1/r, 3phi, sin 2r)")
M3 = C.Field(lambda r, p, z: 0*r + 0.1*np.sin(p)*z, lambda r, p, z: r/(1 + r**2), lambda r, p, z: 0.3*np.cos(2*p)*r**2,
             lambda r, p, z: -0.6*np.sin(2*p)*r + 0*z, lambda r, p, z: 0.1*np.sin(p) - 0.6*np.cos(2*p)*r,
             lambda r, p, z: 2/(1 + r**2)**2 - 0.1*z*np.cos(p)/r, "M3 (Z-pinch + m=1,2 perturbation)")
MFIELDS = [M1, M2, M3, C.ADV]

def cyl_ref_check(fld):
    """Hand-derived cylindrical curl vs a Cartesian 6th-order numeric curl of the same field (independent of any cylindrical formula)."""
    def comps(x, y, z):
        r = np.hypot(x, y); p = np.arctan2(y, x)
        br, bp, bz = fld.Br(r, p, z), fld.Bp(r, p, z), fld.Bz(r, p, z)
        return br*np.cos(p) - bp*np.sin(p), br*np.sin(p) + bp*np.cos(p), bz
    rng = np.random.default_rng(3); x = rng.uniform(0.4, 1.2, 80)*np.cos(a := rng.uniform(0, 6.2, 80)); y = rng.uniform(0.4, 1.2, 80)*np.sin(a); z = rng.uniform(-0.5, 0.5, 80)
    # use radius in [0.4,1.2]
    r_ = rng.uniform(0.5, 1.2, 80); x = r_*np.cos(a); y = r_*np.sin(a)
    h = 2e-3; c = np.array([-1/60, 3/20, -3/4, 0, 3/4, -3/20, 1/60])
    def d(i, ax):
        out = 0.0
        for k, ck in zip(range(-3, 4), c):
            if ck == 0: continue
            q = [x.copy(), y.copy(), z.copy()]; q[ax] = q[ax] + k*h; out = out + ck*comps(*q)[i]
        return out/h
    Jx, Jy, Jz = d(2, 1) - d(1, 2), d(0, 2) - d(2, 0), d(1, 0) - d(0, 1)
    p = a; r = r_
    num = (Jx*np.cos(p) + Jy*np.sin(p), -Jx*np.sin(p) + Jy*np.cos(p), Jz)
    ref = (fld.Jr(r, p, z), fld.Jp(r, p, z), fld.Jz(r, p, z))
    return [float(np.max(np.abs(n - q))/max(np.max(np.abs(q)), 1)) for n, q in zip(num, ref)]

def t017(be):
    res = dict(fields={}); fails = []
    raw = backend_for(be)
    for fld in MFIELDS:
        chk = cyl_ref_check(fld)
        if max(chk) > 1e-8: fails.append(f"reference for {fld.name} disagrees with independent Cartesian numeric curl: {chk}")
        fres = dict(reference_check=chk, grids={})
        for r0, r1, tag in ((0.5, 1.5, "annulus r in [0.5,1.5]"), (0.15, 0.55, "narrow near-axis annulus r in [0.15,0.55]")):
            for base in C.GRIDS:
                rows = []
                for n in levels(base, 4):
                    G = C.Grid(*n, r0=r0, r1=r1); J = G.run(raw, G.sample(fld, F64), F64); ref = G.ref(fld)
                    rows.append(dict(n=list(n), errs=C.err_vs_ref(G, J, ref), Jmax=[float(np.max(np.abs(x))) for x in ref]))
                lo = [orders_of([r["errs"][c] for r in rows])[-1] for c in range(3)]
                allo = [orders_of([r["errs"][c] for r in rows]) for c in range(3)]
                ok = [comp_rule([r["errs"][c] for r in rows], [r["Jmax"][c] for r in rows], lo[c]) for c in range(3)]
                key = f"{tag} {'x'.join(map(str, base))}"
                # FP32 against the same reference on the base grid
                G = C.Grid(*base, r0=r0, r1=r1); B32 = G.sample(fld, F32); J32 = G.run(raw, B32, F32); J64 = G.run(raw, G.sample(fld, F64), F64)
                d32 = max(float(np.max(np.abs(J32[c][G.sl].astype(np.float64) - J64[c][G.sl]))) for c in range(3))
                bnd = C.fp32_bound(G, max(float(np.max(np.abs(b))) for b in G.sample(fld, F64)))
                fres["grids"][key] = dict(rows=rows, last_orders=lo, all_orders=allo, ok=ok, fp32_vs_fp64=dict(diff=d32, bound=bnd, ok=bool(d32 <= bnd)))
                if not all(ok): fails.append(f"{fld.name} {key}: order {[round(x, 2) for x in lo]} below {TOL2['order_min']}")
                if d32 > bnd: fails.append(f"{fld.name} {key}: FP32-FP64 difference {d32:.2e} exceeds bound {bnd:.2e}")
        res["fields"][fld.name] = fres
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 018  Near-axis numerical conditioning
# ============================================================================
def t018(be):
    """Radial-spacing sweep on axis grids (FP64 and FP32), amplitude sweep (under/overflow), annulus start-radius sweep.
    DECLARED bound per cell: |J - J_ref| <= cond_trunc*(dr^2+dz^2+ (r_c dphi)^2)*Jscale + 64*eps*Bmax/hmin   (truncation + round-off)."""
    res = dict(spacing_sweep={}, amplitude_sweep={}, rmin_sweep={}); fails = []
    raw = backend_for(be)
    fld = FIELD["QUAD"]
    nphi, nz = 8, 4
    for dt in (F64, F32):
        rows = []
        for nr in (8, 16, 32, 64, 128, 256, 512, 1024, 2048):
            G = C.Grid(nr, nphi, nz, r0=0.0, r1=1.0, z0=0.0, z1=0.5); B = G.sample(fld, dt)
            J = G.run(raw, B, dt); ref = G.ref(fld); Bmax = max(float(np.max(np.abs(b.astype(np.float64)))) for b in B)
            e = [float(np.max(np.abs(J[c][G.sl].astype(np.float64) - ref[c]))) for c in range(3)]
            hmin = min(G.dr, G.dz, G.rc[G.g]*G.dphi)
            Jscale = max(max(float(np.max(np.abs(r))) for r in ref), 1.0)
            trunc = TOL2["cond_trunc"]*(G.dr**2 + G.dz**2 + (G.rc[G.g]*G.dphi)**2)*Jscale
            fp = C.TOL["fp32_factor"]*EPS[dt]*Bmax/hmin
            bound = trunc + fp
            # error at the first ring only (where 1/r amplification acts)
            e0 = [float(np.max(np.abs(J[c][G.sl][0].astype(np.float64) - ref[c][0]))) for c in range(3)]
            rd = None
            if dt is F32:     # pure round-off: FP32 result against the FP64 result of the SAME discrete problem
                J64 = G.run(raw, G.sample(fld, F64), F64)
                rd = max(float(np.max(np.abs(J[c][G.sl].astype(np.float64) - J64[c][G.sl]))) for c in range(3))
            rows.append(dict(nr=nr, dr=G.dr, r_first_centre=float(G.rc[G.g]), max_err=max(e), ring0_err=max(e0), trunc_allowance=trunc, fp_bound=fp, bound=bound,
                             fp32_minus_fp64=rd, finite=finite_in(J, G), ok=bool(finite_in(J, G) and max(e) <= bound and (rd is None or rd <= fp)), roundoff_dominated=bool(max(e) > trunc)))
        res["spacing_sweep"][dn(dt)] = rows
        for r in rows:
            if not r["ok"]: fails.append(f"{dn(dt)} nr={r['nr']}: error {r['max_err']:.2e} > declared bound {r['bound']:.2e} (or non-finite)")
    f64 = res["spacing_sweep"]["float64"]
    res["fp64_orders_ring0"] = orders_of([r["ring0_err"] for r in f64])[:4]
    # misleading convergence: report where the FP32 error stops decreasing
    e32 = [r["max_err"] for r in res["spacing_sweep"]["float32"]]
    res["fp32_min_error_at_nr"] = res["spacing_sweep"]["float32"][int(np.argmin(e32))]["nr"]
    res["fp32_error_grows_after_minimum"] = bool(e32[-1] > min(e32)*1.5)
    rds = [r["fp32_minus_fp64"] for r in res["spacing_sweep"]["float32"]]
    res["fp32_roundoff_growth"] = dict(values=rds, orders_vs_nr=orders_of(rds[::-1])[::-1] if all(x > 0 for x in rds) else None,
                                      note="FP32-FP64 difference of the same discrete problem; a negative order in dr means the round-off grows as dr shrinks")
    # amplitude sweep (overflow / underflow): finite output must be accurate; non-finite only where the declared overflow condition holds
    G = C.Grid(16, 8, 4, r0=0.0, r1=1.0, z0=0.0, z1=0.5)
    B0 = G.sample(fld, F32); ref0 = G.ref(fld); FMAX = float(np.finfo(np.float32).max)
    amp_rows = []
    for s in (1e-37, 1e-30, 1e-20, 1.0, 1e20, 1e30, 1e35, 3e36, 1e37, 1e38):
        Bs = [(b.astype(np.float64)*s).astype(np.float32) for b in B0]
        Bmax = max(float(np.max(np.abs(b.astype(np.float64)))) for b in Bs)
        J = G.run(raw, Bs, F32); fin = np.isfinite(np.stack([J[c][G.sl] for c in range(3)]))
        Jt = np.stack(ref0)*s
        dtn = float(np.finfo(np.float32).tiny)
        # round-off bound (relative to the *input* scale); allow denormal flush: below tiny the absolute floor is tiny/dr
        bound = C.TOL["fp32_factor"]*EPS[F32]*Bmax/min(G.dr, G.dz, G.rc[G.g]*G.dphi) + TOL2["cond_trunc"]*(G.dr**2 + G.dz**2)*float(np.max(np.abs(Jt))) + 2*dtn/min(G.dr, G.dz, G.rc[G.g]*G.dphi)
        err = np.abs(np.where(fin, np.stack([J[c][G.sl] for c in range(3)]).astype(np.float64), 0) - np.where(fin, Jt, 0))
        overflow_justified = 32*Bmax >= FMAX or float(np.max(np.abs(Jt))) >= FMAX
        bad_nonfinite = int(np.sum(~fin)) if not overflow_justified else 0
        amp_rows.append(dict(scale=s, Bmax=Bmax, nonfinite_cells=int(np.sum(~fin)), overflow_justified=bool(overflow_justified), max_err_finite_cells=float(err.max()), bound=bound,
                             ok=bool(bad_nonfinite == 0 and float(err.max()) <= bound)))
        if not amp_rows[-1]["ok"]: fails.append(f"amplitude {s:g}: {amp_rows[-1]}")
    res["amplitude_sweep"] = amp_rows
    # annulus start-radius sweep with a field regular across the axis (grids that merely approach the axis from outside)
    rrows = []
    for frac in (1.0, 0.5, 0.1, 1e-2, 1e-3):
        dr = 1/32; r0 = frac*dr
        G = C.Grid(32, 16, 8, r0=r0, r1=r0 + 1.0, z0=0.0, z1=0.5); J = G.run(raw, G.sample(fld, F64), F64); ref = G.ref(fld)
        e = max(float(np.max(np.abs(J[c][G.sl] - ref[c]))) for c in range(3)); Jscale = max(max(float(np.max(np.abs(r))) for r in ref), 1.0)
        bound = TOL2["cond_trunc"]*(G.dr**2 + G.dz**2 + (G.rc[G.g]*G.dphi)**2)*Jscale/(G.rc[G.g]/G.dr)
        rrows.append(dict(r_min_over_dr=frac, max_err=e, declared_bound=bound, finite=finite_in(J, G), ok=bool(finite_in(J, G) and e <= bound)))
        if not rrows[-1]["ok"]: fails.append(f"annulus r_min={frac}*dr: error {e:.2e} > declared bound {bound:.2e}")
    res["rmin_sweep"] = rrows
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 019  Boundary adversarial mutation
# ============================================================================
def t019(be):
    res = dict(validator_cases=[], nonfinite_confinement=[], tiny_rmin=[], low_nphi_axis=[]); fails = []
    raw = backend_for(be)
    def base(r0=0.0, dt=F64, n=(16, 16, 8), g=2):
        G = C.Grid(*n, g=g, r0=r0, r1=r0 + 1.0); B = G.sample(FIELD["SMOOTH"] if r0 == 0.0 else C.ADV, dt); shp = (G.nr + 2*g, G.nphi + 2*g, G.nz + 2*g)
        return G, dict(Br=B[0], Bphi=B[1], Bz=B[2], Jr=np.zeros(shp, dt), Jphi=np.zeros(shp, dt), Jz=np.zeros(shp, dt), r_faces=G.rf.astype(dt), r_centers=G.rc.astype(dt),
                       dr=G.dr, dphi=G.dphi, dz=G.dz, nr=G.nr, nphi=G.nphi, nz=G.nz, g=g, full_circle=True)
    def call(a):
        K.validate_inputs(a["Br"], a["Bphi"], a["Bz"], a["Jr"], a["Jphi"], a["Jz"], a["r_faces"], a["r_centers"], a["dr"], a["dphi"], a["dz"], a["nr"], a["nphi"], a["nz"], a["g"], a["full_circle"])
    # (a) coordinate / shape / dtype corruption on BOTH annulus and axis grids -> must raise CurlContractError (never anything else, never silently accept)
    muts = {
        "r_faces: NaN": lambda a: a["r_faces"].__setitem__(6, np.nan), "r_faces: +Inf": lambda a: a["r_faces"].__setitem__(6, np.inf),
        "r_faces: sign flip of one entry": lambda a: a["r_faces"].__setitem__(7, -a["r_faces"][7]), "r_faces: shifted by 1e-6 dr": lambda a: a["r_faces"].__setitem__(7, a["r_faces"][7] + 1e-6*a["dr"]),
        "r_faces: shifted by 0.3 dr": lambda a: a["r_faces"].__setitem__(7, a["r_faces"][7] + 0.3*a["dr"]), "r_faces: reversed": lambda a: a.update(r_faces=a["r_faces"][::-1].copy()),
        "r_faces: all scaled x1.01": lambda a: a.update(r_faces=a["r_faces"]*1.01), "r_faces: offset +0.5dr": lambda a: a.update(r_faces=a["r_faces"] + 0.5*a["dr"]),
        "r_centers: NaN": lambda a: a["r_centers"].__setitem__(6, np.nan), "r_centers: shifted 0.3 dr": lambda a: a["r_centers"].__setitem__(6, a["r_centers"][6] + 0.3*a["dr"]),
        "r_centers: equal to r_faces (not midpoints)": lambda a: a.update(r_centers=a["r_faces"][:-1].copy()), "r_centers: reversed": lambda a: a.update(r_centers=a["r_centers"][::-1].copy()),
        "r_faces: wrong length (-1)": lambda a: a.update(r_faces=a["r_faces"][:-1].copy()), "r_faces: wrong length (+1)": lambda a: a.update(r_faces=np.append(a["r_faces"], 9.0)),
        "r_centers: wrong length": lambda a: a.update(r_centers=a["r_centers"][:-1].copy()), "r_faces: 0-d array": lambda a: a.update(r_faces=np.array(1.0)),
        "r_faces: python list": lambda a: a.update(r_faces=list(a["r_faces"])),
        "Br: wrong radial extent": lambda a: a.update(Br=np.ascontiguousarray(a["Br"][:-1])), "Bphi: wrong z extent": lambda a: a.update(Bphi=np.ascontiguousarray(a["Bphi"][:, :, :-1])),
        "Bz: wrong phi extent": lambda a: a.update(Bz=np.ascontiguousarray(a["Bz"][:, 1:, :])), "Br: transposed": lambda a: a.update(Br=np.ascontiguousarray(a["Br"].transpose(1, 0, 2))),
        "Br: 2-D": lambda a: a.update(Br=a["Br"][:, :, 0].copy()), "Bz: non-contiguous slice view": lambda a: a.update(Bz=np.asarray(np.zeros((a["Bz"].shape[0], a["Bz"].shape[1], 2*a["Bz"].shape[2])))[:, :, ::2]),
        "Br: Fortran order": lambda a: a.update(Br=np.asfortranarray(a["Br"])), "Jr: float16": lambda a: a.update(Jr=a["Jr"].astype(np.float16)),
        "Jphi: float32 vs float64 inputs": lambda a: a.update(Jphi=a["Jphi"].astype(np.float32)), "Br: complex128": lambda a: a.update(Br=a["Br"].astype(np.complex128)),
        "dr: NaN": lambda a: a.update(dr=float("nan")), "dz: +Inf": lambda a: a.update(dz=float("inf")), "dz = 0": lambda a: a.update(dz=0.0), "dphi: negative": lambda a: a.update(dphi=-a["dphi"]),
        "dphi in degrees": lambda a: a.update(dphi=math.degrees(a["dphi"])), "nphi inconsistent with dphi": lambda a: a.update(nphi=a["nphi"] + 1),
        "g too small for the stencil (0)": lambda a: a.update(g=0), "nr = 0": lambda a: a.update(nr=0), "nz = bool True": lambda a: a.update(nz=True), "nr as numpy float": lambda a: a.update(nr=np.float64(a["nr"])),
        "Jz aliases Jr": lambda a: a.update(Jz=a["Jr"]), "Jr aliases input Bz": lambda a: a.update(Jr=a["Bz"].ravel()[:a["Jr"].size].reshape(a["Jr"].shape)),
    }
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        for name, f in muts.items():
            G, a = base(r0)
            try: f(a)
            except Exception: pass
            try:
                call(a); outcome = "ACCEPTED"; msg = ""
            except K.CurlContractError as ex:
                outcome = "REJECTED"; msg = str(ex)[:90]
            except Exception as ex:
                outcome = "UNEXPECTED " + type(ex).__name__; msg = str(ex)[:90]
            res["validator_cases"].append(dict(grid=mode, mutation=name, outcome=outcome, message=msg, ok=bool(outcome == "REJECTED")))
    for r in res["validator_cases"]:
        if not r["ok"]: fails.append(f"{r['grid']}: mutation '{r['mutation']}' -> {r['outcome']}")
    # (b) device-array launcher path (GPU leg): rejected calls must leave the outputs untouched (no partial / silent writes)
    if be.name == "cupy":
        import cupy as cp
        untouched = []
        for name in ("r_faces: NaN", "Br: wrong radial extent", "Jr: float16", "Jz aliases Jr", "dz = 0", "r_faces: shifted by 0.3 dr", "dphi in degrees", "nr = 0"):
            G, a = base(0.0); f = muts[name]
            try: f(a)
            except Exception: pass
            cache = {}
            def tod(v):
                if isinstance(v, np.ndarray) and v.dtype in (np.float32, np.float64) and v.ndim == 3 and v.flags.c_contiguous:
                    if id(v) not in cache: cache[id(v)] = cp.asarray(v)       # same host object -> same device array (keeps deliberate aliasing)
                    return cache[id(v)]
                return v
            d = {k: tod(v) for k, v in a.items()}
            for k in ("Jr", "Jphi", "Jz"):
                if isinstance(d[k], cp.ndarray): d[k][...] = -777.0
            try:
                getattr(K, C.LAUNCH)(d["Br"], d["Bphi"], d["Bz"], d["Jr"], d["Jphi"], d["Jz"], d["r_faces"], d["r_centers"], d["dr"], d["dphi"], d["dz"], d["nr"], d["nphi"], d["nz"], d["g"])
                cp.cuda.Device().synchronize(); rej = False
            except K.CurlContractError: rej = True
            except Exception as ex: rej = False
            intact = all((not isinstance(d[k], cp.ndarray)) or bool(cp.all(d[k] == -777.0)) for k in ("Jr", "Jphi", "Jz"))
            untouched.append(dict(mutation=name, rejected=rej, outputs_untouched=intact, ok=bool(rej and intact)))
        res["device_rejection_leaves_outputs_untouched"] = untouched
        for u in untouched:
            if not u["ok"]: fails.append(f"device launcher: '{u['mutation']}' rejected={u['rejected']} untouched={u['outputs_untouched']}")
    # (c) NaN / Inf / huge values injected into B (ghosts and interior): output damage confined to the stencil footprint (determined by the independent reference), and propagated (never zeroed)
    rng = np.random.default_rng(19)
    for r0, tag in ((0.5, "annulus"), (0.0, "axis")):
        for bad in (np.nan, np.inf, -np.inf):
            for (arr, pos, where) in ((0, "ghost-inner-radial", "ghost"), (2, "ghost-outer-z", "ghost"), (1, "ghost-phi", "ghost"), (0, "interior", "int"), (2, "interior", "int"), (1, "interior", "int")):
                G = C.Grid(16, 16, 8, r0=r0, r1=r0 + 1.0); B = G.sample(FIELD["SMOOTH"] if r0 == 0.0 else C.ADV, F64)
                Jclean = G.run(raw, B, F64)
                X = [b.copy() for b in B]; shp = X[arr].shape
                if pos == "ghost-inner-radial": idx = (0, shp[1]//2, shp[2]//2)
                elif pos == "ghost-outer-z": idx = (shp[0]//2, shp[1]//2, shp[2] - 1)
                elif pos == "ghost-phi": idx = (shp[0]//2, 0, shp[2]//2)
                else: idx = (G.g + 5, G.g + 6, G.g + 3)
                X[arr][idx] = bad
                with np.errstate(all="ignore"): ref = ref_any(G, X)
                J = G.run(raw, X, F64)
                mk, mr = nonfinite_mask(J, G), np.zeros((G.nr, G.nphi, G.nz), bool)
                for c in range(3): mr |= ~np.isfinite(ref[c])
                outside_same = all(np.array_equal(J[c][G.sl][~mk], Jclean[c][G.sl][~mk]) for c in range(3))
                # the kernel may be strictly safer or equal: pattern must match the independent reference footprint
                row = dict(grid=tag, injected=str(bad), array=("Br", "Bphi", "Bz")[arr], where=pos + f"@{idx}", nonfinite_cells_kernel=int(mk.sum()), nonfinite_cells_reference=int(mr.sum()),
                           pattern_matches_reference=bool(np.array_equal(mk, mr)), cells_outside_unchanged=bool(outside_same))
                row["ok"] = bool(row["pattern_matches_reference"] and outside_same)
                # ghost cells that no stencil reads must leave the output bitwise clean
                res["nonfinite_confinement"].append(row)
                if not row["ok"]: fails.append(f"{tag} {row['array']} {row['where']} {bad}: footprint mismatch (kernel {mk.sum()} vs reference {mr.sum()} cells, outside unchanged={outside_same})")
    # (d) huge-but-finite garbage in a ghost the stencil reads -> only its footprint may change
    for r0, tag in ((0.5, "annulus"), (0.0, "axis")):
        G = C.Grid(16, 16, 8, r0=r0, r1=r0 + 1.0); B = G.sample(FIELD["SMOOTH"] if r0 == 0.0 else C.ADV, F64); Jc = G.run(raw, B, F64)
        X = [b.copy() for b in B]; X[2][X[2].shape[0]//2, 0, X[2].shape[2]//2] = 1e300
        with np.errstate(all="ignore"): ref = ref_any(G, X)
        J = G.run(raw, X, F64)
        changed = np.zeros((G.nr, G.nphi, G.nz), bool)
        for c in range(3): changed |= (J[c][G.sl] != Jc[c][G.sl])
        rchanged = np.zeros_like(changed)
        refc = ref_any(G, B)
        for c in range(3): rchanged |= (ref[c] != refc[c]) | ~np.isfinite(ref[c])
        res.setdefault("huge_finite_ghost", []).append(dict(grid=tag, cells_changed=int(changed.sum()), reference_cells_changed=int(rchanged.sum()), footprint_matches=bool(np.array_equal(changed, rchanged))))
        if not np.array_equal(changed, rchanged): fails.append(f"{tag}: 1e300 ghost footprint differs from reference")
    # (e) start-radius contract. DECLARED rule: r_faces[g] == 0 (axis) or >= tiny_rmin_fraction*dr (annulus) is accepted; 0 < r_faces[g] < fraction*dr
    #     (axis-like, typically round-off) and r_faces[g] < 0 (grid straddling the axis) must be rejected.
    for frac in (-0.49, -0.25, -1e-3, -1e-15, 1e-3, 1e-6, 1e-9, 1e-12, 1e-15):
        G = C.Grid(16, 16, 8, r0=frac*(1.0/16), r1=frac*(1.0/16) + 1.0)
        B = G.sample(FIELD["SMOOTH"], F64); shp = (G.nr + 4, G.nphi + 4, G.nz + 4)
        try:
            K.validate_inputs(*B, *[np.zeros(shp) for _ in range(3)], G.rf, G.rc, G.dr, G.dphi, G.dz, 16, 16, 8, 2); accepted = True
        except K.CurlContractError: accepted = False
        J = G.run(raw, B, F64); ref = G.ref(FIELD["SMOOTH"]); e = max(nmax(J[c][G.sl] - ref[c]) for c in range(3))
        must_reject = bool(frac < 0 or frac < TOL2["tiny_rmin_fraction"])
        row = dict(r_min_over_dr=frac, validator_accepts=accepted, must_reject=must_reject, err_if_run=e, ok=bool(accepted != must_reject))
        res["tiny_rmin"].append(row)
        if not row["ok"]:
            fails.append(f"start radius {frac:g}*dr: validator {'accepts' if accepted else 'rejects'} but the declared rule says it must be {'rejected' if must_reject else 'accepted'}; error if run {e:.2e}")
    # (f) too few azimuthal cells for the axis closure (sin(dphi) division / cubic phi stencil). Declared: an axis grid needs >= 3 azimuthal cells.
    for nphi in (1, 2, 3, 4):
        G = C.Grid(8, nphi, 4, r0=0.0, r1=1.0); B = G.sample(FIELD["QUAD"], F64); shp = (G.nr + 4, G.nphi + 4, G.nz + 4)
        try:
            K.validate_inputs(*B, *[np.zeros(shp) for _ in range(3)], G.rf, G.rc, G.dr, G.dphi, G.dz, 8, nphi, 4, 2); accepted = True
        except K.CurlContractError: accepted = False
        J = G.run(raw, B, F64) if nphi >= 3 or accepted else G.run(raw, B, F64)
        e = max(nmax(J[c][G.sl] - G.ref(FIELD["QUAD"])[c]) for c in range(3)); fin = finite_in(J, G)
        row = dict(nphi=nphi, validator_accepts=accepted, finite=fin, err_vs_analytic=e, ok=bool(accepted == (nphi >= 3)))
        res["low_nphi_axis"].append(row)
        if not row["ok"]: fails.append(f"axis grid with nphi={nphi} {'accepted' if accepted else 'rejected'} (declared minimum 3); finite={fin}, error vs analytic {e:.3g}")
    # (g) THRESHOLD STUDY for the 0.001*dr policy constant. (i) decision sensitivity across the boundary; (ii) is there any accuracy cliff that would
    #     justify a different number; (iii) the round-off noise floor of typical radius constructions, which the threshold must clear by noise_margin.
    thr = []
    for s_ in (1e-16, 1e-12, 1e-9, 1e-6, 1e-4, 5e-4, 9.9e-4, 1.1e-3, 2e-3, 1e-2, 0.1, 0.5, 1.0):
        G = C.Grid(16, 16, 8, r0=s_/16, r1=s_/16 + 1.0); B = G.sample(FIELD["SMOOTH"], F64); shp = (G.nr + 4, G.nphi + 4, G.nz + 4)
        try:
            K.validate_inputs(*B, *[np.zeros(shp) for _ in range(3)], G.rf, G.rc, G.dr, G.dphi, G.dz, 16, 16, 8, 2); acc = True
        except K.CurlContractError: acc = False
        e_ann = max(nmax(G.run(raw, B, F64)[c][G.sl] - G.ref(FIELD["SMOOTH"])[c]) for c in range(3))
        Ga = C.Grid(16, 16, 8, r0=0.0, r1=1.0); e_ax = max(nmax(Ga.run(raw, Ga.sample(FIELD["SMOOTH"], F64), F64)[c][Ga.sl] - Ga.ref(FIELD["SMOOTH"])[c]) for c in range(3))
        expect_acc = s_ >= TOL2["tiny_rmin_fraction"]
        thr.append(dict(r_min_over_dr=s_, validator_accepts=acc, expected_accepts=expect_acc, err_annulus_stencil=e_ann, err_axis_mode_same_dr=e_ax, ok=bool(acc == expect_acc)))
        if acc != expect_acc: fails.append(f"threshold study: r_min={s_:g}*dr decision {'accept' if acc else 'reject'} differs from the declared rule")
    noise = {}
    for g_, dr_, r0_ in ((2, 0.0625, 0.0), (2, 1/3, 0.0), (3, 0.1, 0.0), (2, 0.007, 0.0), (2, 1/1024, 0.0)):
        for nr_ in (16, 256, 4096):
            n_ = nr_ + 1 + 2*g_
            cons = {"arange*dr": ((np.arange(n_) - g_)*dr_)[g_], "cumsum": (np.concatenate([[0.0], np.cumsum(np.full(n_ - 1, dr_))]) - g_*dr_)[g_],
                    "linspace": np.linspace(-g_*dr_, (n_ - 1 - g_)*dr_, n_)[g_], "r0+k*dr (r0=0.3-0.1*3)": (0.3 - 0.1*3 + (np.arange(n_) - g_)*dr_)[g_],
                    "float32-rounded linspace": float(np.linspace(-g_*dr_, (n_ - 1 - g_)*dr_, n_).astype(np.float32)[g_])}
            for k_, v_ in cons.items(): noise[f"g={g_} dr={dr_:.4g} nr={nr_} {k_}"] = abs(float(v_))/dr_
    worst = max(noise.values()); worst_key = max(noise, key=noise.get)
    res["threshold_study"] = dict(rows=thr, noise_residual_over_dr_worst=worst, noise_worst_case=worst_key, noise_margin_required=TOL2["noise_margin"],
                                  threshold_over_noise=(TOL2["tiny_rmin_fraction"]/worst if worst > 0 else math.inf),
                                  note="float32-rounded radii are NOT noise-free (eps32 ~ 1e-7 of the radius scale): such a radius lands in the rejected band, as intended")
    f32w = max(v for k, v in noise.items() if "float32" not in k)
    res["threshold_study"]["noise_residual_over_dr_worst_float64_constructions"] = f32w
    if TOL2["tiny_rmin_fraction"] < TOL2["noise_margin"]*f32w: fails.append(f"threshold {TOL2['tiny_rmin_fraction']:g}*dr does not clear the FP64 construction noise floor ({f32w:.1e}*dr) by {TOL2['noise_margin']:g}x")
    # (h) azimuthal resolution study (informational, NO resolution claim): helical-kink transverse axis current vs nphi
    rs = []
    for nphi in (3, 4, 5, 6, 8, 12, 16, 32, 64):
        G = C.Grid(16, nphi, 8, r0=0.0, r1=1.0)
        try:
            K.validate_inputs(*G.sample(FIELD["HELICAL KINK (m=1)"], F64), *[np.zeros((20, nphi + 4, 12)) for _ in range(3)], G.rf, G.rc, G.dr, G.dphi, G.dz, 16, nphi, 8, 2)
        except K.CurlContractError: continue
        J = G.run(raw, G.sample(FIELD["HELICAL KINK (m=1)"], F64), F64); ref = G.ref(FIELD["HELICAL KINK (m=1)"])
        amp = float(np.max(np.hypot(J[0][G.sl][0], J[1][G.sl][0]))); amp_r = float(np.max(np.hypot(ref[0][0], ref[1][0])))
        rs.append(dict(nphi=nphi, amplitude_rel_err=abs(amp - amp_r)/amp_r, max_err_Jz=nmax(J[2][G.sl] - ref[2])))
    res["azimuthal_resolution_study"] = dict(rows=rs, note="informational: nphi >= 3 is a validity guard (sin(dphi) != 0), not evidence that 3 cells resolve m = 1")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 020  GPU geometry safety
# ============================================================================
def random_grids(n=14, seed=2020):
    rnd = random.Random(seed); out = []
    for _ in range(n):
        g = rnd.choice([1, 2, 2, 3]); axis = (g >= 2) and rnd.random() < 0.5
        nr = rnd.randint(3, 26); nphi = rnd.randint(3, 22); nz = rnd.randint(1, 12)
        r0 = 0.0 if axis else rnd.choice([0.3, 0.5, 1.7]); dr = rnd.uniform(0.03, 0.15)
        out.append(dict(nr=nr, nphi=nphi, nz=nz, g=g, r0=r0, dr=dr, dz=rnd.uniform(0.03, 0.2), dtype=rnd.choice([F32, F64])))
    out += [dict(nr=3, nphi=3, nz=1, g=2, r0=0.0, dr=0.1, dz=0.1, dtype=F64), dict(nr=1, nphi=3, nz=1, g=1, r0=0.5, dr=0.1, dz=0.1, dtype=F32)]
    return out

def guarded_run(be, G, B, dtype, PAD=256):
    """Run with every OUTPUT array embedded in a larger buffer pre-filled with a sentinel; check that nothing outside the array was written,
    inputs are unchanged, and the ghost layers of J (never written by contract) stay at their sentinel."""
    sent = -1234.5
    n = (G.nr + 2*G.g)*(G.nphi + 2*G.g)*(G.nz + 2*G.g); shp = (G.nr + 2*G.g, G.nphi + 2*G.g, G.nz + 2*G.g)
    if be.name == "host":
        bufs = [np.full(n + 2*PAD, sent, dtype=dtype) for _ in range(3)]; views = [b[PAD:PAD + n].reshape(shp) for b in bufs]
        for v in views: v[...] = sent
        Bin = [b.copy() for b in B]
        be.run(*B, G.rf.astype(dtype), G.rc.astype(dtype), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g, J=views)
        pre = [bf[:PAD] for bf in bufs]; post = [bf[PAD + n:] for bf in bufs]
        canary_ok = all(bool(np.all(p == sent)) for p in pre + post)
        inputs_ok = all(np.array_equal(a, b) for a, b in zip(B, Bin))
        J = [v.copy() for v in views]
    else:
        import cupy as cp
        bufs = [cp.full(n + 2*PAD, sent, dtype=dtype) for _ in range(3)]; views = [b[PAD:PAD + n].reshape(shp) for b in bufs]
        dB = [cp.asarray(b) for b in B]; Bin = [b.copy() for b in B]
        getattr(K, C.LAUNCH)(*dB, *views, cp.asarray(G.rf.astype(dtype)), cp.asarray(G.rc.astype(dtype)), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
        cp.cuda.Device().synchronize()
        canary_ok = all(bool(cp.all(bf[:PAD] == sent)) and bool(cp.all(bf[PAD + n:] == sent)) for bf in bufs)
        inputs_ok = all(np.array_equal(cp.asnumpy(a), b) for a, b in zip(dB, Bin))
        J = [cp.asnumpy(v) for v in views]
    mask = np.ones(shp, bool); mask[G.sl] = False
    ghosts_ok = all(bool(np.all(j[mask] == sent)) for j in J)
    wrote_all = all(bool(np.all(j[G.sl] != sent)) for j in J)
    return J, dict(canary_intact=canary_ok, inputs_unchanged=inputs_ok, ghost_layers_untouched=ghosts_ok, all_active_cells_written=wrote_all)

SAN2 = r"""
import sys, importlib.util, numpy as np, cupy as cp, random
cp.cuda.set_allocator(None)                      # raw cudaMalloc per array: sanitizer sees exact bounds
spec = importlib.util.spec_from_file_location("t", sys.argv[1]); K = importlib.util.module_from_spec(spec); spec.loader.exec_module(K)
launch = getattr(K, [n for n in dir(K) if n.startswith("launch_")][0])
rnd = random.Random(2020); rng = np.random.default_rng(5)
cases = []
for _ in range(14):
    g = rnd.choice([1, 2, 2, 3]); axis = (g >= 2) and rnd.random() < 0.5
    cases.append((rnd.randint(3, 26), rnd.randint(3, 22), rnd.randint(1, 12), g, 0.0 if axis else rnd.choice([0.3, 0.5, 1.7]), rnd.uniform(0.03, 0.15), rnd.uniform(0.03, 0.2), rnd.choice([np.float32, np.float64])))
    rnd.random()
cases += [(3, 3, 1, 2, 0.0, 0.1, 0.1, np.float64), (1, 3, 1, 1, 0.5, 0.1, 0.1, np.float32), (33, 5, 2, 2, 0.0, 0.08, 0.1, np.float64)]
for (nr, nphi, nz, g, r0, dr, dz, dt) in cases:
    dphi = 2*np.pi/nphi
    rf = (r0 + (np.arange(nr + 1 + 2*g) - g)*dr).astype(dt); rc = (r0 + (np.arange(nr + 2*g) - g + 0.5)*dr).astype(dt)
    mk = lambda s: cp.asarray(rng.uniform(-1, 1, s).astype(dt))
    Br, Bp, Bz = mk((nr + 1 + 2*g, nphi + 2*g, nz + 2*g)), mk((nr + 2*g, nphi + 1 + 2*g, nz + 2*g)), mk((nr + 2*g, nphi + 2*g, nz + 1 + 2*g))
    J = [cp.zeros((nr + 2*g, nphi + 2*g, nz + 2*g), dt) for _ in range(3)]
    launch(Br, Bp, Bz, *J, cp.asarray(rf), cp.asarray(rc), dr, dphi, dz, nr, nphi, nz, g)
    cp.cuda.Device().synchronize()
print("SANITIZER_TARGET_DONE")
"""

def gpu_sanitizer2():
    san = C.find_sanitizer()
    if san is None:
        return dict(status="BLOCKED", note="compute-sanitizer not found (install the CUDA toolkit or add its bin directory to PATH)")
    script = os.path.join(C.SCRATCH, "gpu_san2_target.py"); open(script, "w").write(SAN2)
    out = dict(status="RAN", tool=san, runs={})
    for tool in ("memcheck", "initcheck", "racecheck", "synccheck"):
        try:
            p = subprocess.run([san, "--tool", tool, "--error-exitcode", "99", sys.executable, script, C.KPATH], capture_output=True, text=True, timeout=1800)
            text = p.stdout + p.stderr
            m = re.search(r"ERROR SUMMARY: (\d+) error", text)
            out["runs"][tool] = dict(returncode=p.returncode, error_summary=int(m.group(1)) if m else None, target_done="SANITIZER_TARGET_DONE" in text,
                                     clean=bool(p.returncode == 0 and "SANITIZER_TARGET_DONE" in text and (m is None or int(m.group(1)) == 0)),
                                     excerpt=[l for l in text.splitlines() if "Invalid" in l or "Uninitialized" in l or "ERROR" in l or "Error" in l][:6])
        except Exception as ex:
            out["runs"][tool] = dict(clean=False, error=f"{type(ex).__name__}: {ex}"[:300])
    return out

def t020(be):
    res = dict(random_grids=[]); fails = []
    host = C.HostBackend() if be.name != "host" else be
    rng = np.random.default_rng(20)
    for sp in random_grids():
        dt = sp["dtype"]
        G = C.Grid(sp["nr"], sp["nphi"], sp["nz"], g=sp["g"], r0=sp["r0"], r1=sp["r0"] + sp["nr"]*sp["dr"], z0=0.0, z1=sp["nz"]*sp["dz"])
        B = random_B(G, dt, rng)
        row = dict(grid=[G.nr, G.nphi, G.nz], g=G.g, r_min=sp["r0"], dtype=dn(dt))
        try:
            K.validate_inputs(*B, *[np.zeros((G.nr + 2*G.g, G.nphi + 2*G.g, G.nz + 2*G.g), dt) for _ in range(3)], G.rf.astype(dt), G.rc.astype(dt), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
        except K.CurlContractError as ex:
            row["rejected_by_validator"] = str(ex)[:100]; row["ok"] = True; res["random_grids"].append(row); continue
        J, g_ = guarded_run(be, G, B, dt); row.update(g_)
        ref = ref_any(G, [b.astype(np.float64) for b in B])
        row["finite"] = bool(all(np.isfinite(J[c][G.sl]).all() for c in range(3)))
        sc = max(max(float(np.max(np.abs(r))) for r in ref), 1e-300)
        d = max(float(np.max(np.abs(J[c][G.sl].astype(np.float64) - ref[c]))) for c in range(3))
        row["rel_diff_vs_independent_reference"] = d/sc
        tol = TOL2["equiv_fp64"] if dt is F64 else C.fp32_bound(G, 1.0)/sc*1.0
        row["tol"] = tol
        if be.name == "cupy":
            Jh = G.run(host, B, dt); dh = max(float(np.max(np.abs(J[c][G.sl].astype(np.float64) - Jh[c][G.sl].astype(np.float64)))) for c in range(3))
            row["gpu_vs_host_rel_diff"] = dh/sc; row["gpu_vs_host_tol"] = tol
        row["ok"] = bool(row["canary_intact"] and row["inputs_unchanged"] and row["ghost_layers_untouched"] and row["all_active_cells_written"] and row["finite"]
                         and row["rel_diff_vs_independent_reference"] <= tol and (be.name != "cupy" or row["gpu_vs_host_rel_diff"] <= tol))
        if not row["ok"]: fails.append(f"random grid {row['grid']} g={G.g} r_min={sp['r0']} {dn(dt)}: {({k: row[k] for k in ('canary_intact', 'inputs_unchanged', 'ghost_layers_untouched', 'all_active_cells_written', 'finite', 'rel_diff_vs_independent_reference')})}")
        res["random_grids"].append(row)
    if be.name == "host":
        # AddressSanitizer on the host-compiled kernel for the same grid family (CUDA semantics are NOT certified by this leg)
        asan = []
        for sp in random_grids():
            if sp["dtype"] is F32: pass
            r = C.asan_run(sp["nr"], sp["nphi"], sp["nz"], sp["g"], 2 if sp["r0"] == 0.0 else 0)
            asan.append(dict(grid=[sp["nr"], sp["nphi"], sp["nz"]], g=sp["g"], mode="axis" if sp["r0"] == 0.0 else "annulus", clean=bool(r["clean"]), error=r["error"], excerpt=r["excerpt"][:3]))
        res["host_addresssanitizer"] = asan
        for a in asan:
            if not a["clean"]: fails.append(f"AddressSanitizer {a['grid']} g={a['g']} {a['mode']}: {a['error']}")
        res["scope_note"] = "Host leg: g++-compiled copy of the CUDA source, guarded buffers + AddressSanitizer. It does NOT certify device memory safety; see the cupy leg."
    else:
        san = gpu_sanitizer2(); res["compute_sanitizer"] = san
        if san["status"] == "BLOCKED":
            res["block_reason"] = san["note"]
        else:
            for tool, r in san["runs"].items():
                if not r.get("clean"): fails.append(f"compute-sanitizer {tool} reported problems or did not complete")
    res["verdict"] = "FAIL" if fails else ("BLOCKED" if res.get("block_reason") else "PASS")
    res["fail_reasons"] = fails
    return res

# ============================================================================
# driver
# ============================================================================
TESTS2 = [("011", "Cylindrical metric identities", t011), ("012", "Axis regularity", t012), ("013", "Non-axisymmetric m=1 kink", t013),
          ("014", "Radial ghost parity", t014), ("015", "Periodic azimuthal closure", t015), ("016", "Yee staggered geometry", t016),
          ("017", "Cylindrical manufactured solutions", t017), ("018", "Near-axis numerical conditioning", t018),
          ("019", "Boundary adversarial mutation", t019), ("020", "GPU geometry safety", t020)]

def safe(fn, be):
    try: return fn(be)
    except Exception: return dict(verdict="ERROR", error=traceback.format_exc()[-2500:])

def gpu_only_cross_check(host, gpu):
    """Direct host-vs-GPU comparison on random fields of all grids used by 016/020 (axis + annulus, FP32 + FP64)."""
    rng = np.random.default_rng(77); rows = []
    for (n, r0) in (((16, 16, 8), 0.0), ((17, 11, 9), 0.0), ((16, 16, 8), 0.5), ((17, 11, 9), 0.5)):
        G = C.Grid(*n, r0=r0, r1=r0 + 1.0)
        for dt in (F64, F32):
            B = random_B(G, dt, rng); Jh = G.run(host, B, dt); Jg = G.run(gpu, B, dt)
            sc = max(float(np.max(np.abs(Jh[c][G.sl]))) for c in range(3))
            d = max(float(np.max(np.abs(Jg[c][G.sl].astype(np.float64) - Jh[c][G.sl].astype(np.float64)))) for c in range(3))
            tol = TOL2["equiv_fp64"]*sc if dt is F64 else C.fp32_bound(G, 1.0)
            rows.append(dict(grid=list(n), r_min=r0, dtype=dn(dt), max_abs_diff=d, tol=tol, ok=bool(d <= tol)))
    return rows

def load_report_module():
    path = os.path.join(HERE, "make_report_campaign02.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location("make_report_mod02", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
    import base64, zlib, types
    if not _EMBEDDED_REPORT.strip(): return None
    mod = types.ModuleType("make_report_mod02")
    exec(zlib.decompress(base64.b64decode("".join(_EMBEDDED_REPORT.split()))).decode(), mod.__dict__)
    return mod

def _self_sha():
    for p in (globals().get("__file__"), sys.argv[0] if sys.argv else None, os.path.join(HERE, "campaign02.py"), os.path.join(os.getcwd(), "campaign02.py")):
        try:
            if p and os.path.isfile(p) and p.endswith(".py"): return hashlib.sha256(open(p, "rb").read()).hexdigest()
        except Exception: pass
    return "UNKNOWN (this harness file could not be located on disk; run it as `python campaign02.py`)"

def main():
    sha = C.SRC_SHA
    print(f"Kernel file used: {os.path.basename(C.KPATH)} (v{getattr(K, 'VERSION', '?')})")
    print("=" * 78); print(f"ALADIN v4.0 - Campaign 02 | {C.STEM}.py v{getattr(K, 'VERSION', '?')} sha256 {sha[:16]}..."); print("=" * 78)
    frozen = bool(EXPECTED_SHA) and (sha == EXPECTED_SHA)
    if not frozen:
        print(f"!! WARNING: kernel sha256 {sha} (v{getattr(K, 'VERSION', '?')}) matches no registered version ({', '.join(f'v{k}' for k in KNOWN_SHA)}).\n   Campaign 02 certifies ONLY registered, frozen files; results below are for an UNREGISTERED source.")
    latest = max(KNOWN_SHA, key=lambda v: tuple(int(x) for x in v.split(".")))
    print(f"Package check: uct_curl.py v{getattr(K, 'VERSION', '?')} sha {sha[:12]} | campaign01.py sha {hashlib.sha256(open(C.__file__, 'rb').read()).hexdigest()[:12]} | campaign02.py sha {_self_sha()[:12]}")
    if getattr(K, "VERSION", "") != latest:
        print("!" * 78 + f"\n!! STALE PACKAGE: this run uses uct_curl.py v{getattr(K, 'VERSION', '?')} but the latest registered kernel is v{latest}.\n"
              "!! Delete the old files in this folder (rm -f *.py), unzip the newest zip again, and re-run.\n" + "!" * 78)
    host = C.HostBackend(); gpu_present = C.CupyBackend.available()
    backends = [host] + ([C.CupyBackend()] if gpu_present else [])
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
               gxx=subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0], kernel_file=C.KPATH, kernel_sha256=sha,
               expected_sha256=EXPECTED_SHA, latest_registered_version=latest, source_frozen_and_matches=frozen, kernel_version=getattr(K, "VERSION", "?"), campaign_harness_sha256=_self_sha(),
               campaign01_helper_sha256=hashlib.sha256(open(C.__file__, "rb").read()).hexdigest(), gpu_present=gpu_present,
               gpu_leg_status="executed" if gpu_present else "BLOCKED: no GPU/CuPy in this session")
    if gpu_present:
        try:
            import cupy as cp
            props = cp.cuda.runtime.getDeviceProperties(0)
            env.update(gpu=props["name"].decode(), cupy=cp.__version__, cuda_runtime=cp.cuda.runtime.runtimeGetVersion(), compute_capability=f"{props['major']}.{props['minor']}")
        except Exception: pass
        print(f"GPU detected: {env.get('gpu', '?')}  CuPy {env.get('cupy', '?')}")
    else:
        print("No GPU/CuPy detected: GPU legs will be BLOCKED.")
    results = dict(env=env, tolerances=TOL2, campaign01_tolerances=C.TOL, tests={})
    print("\n-- Campaign 02 tests --", flush=True)
    for tid, name, fn in TESTS2:
        entry = dict(name=name)
        for be in backends: entry[be.name] = safe(fn, be)
        if "cupy" not in entry: entry["cupy"] = dict(verdict="BLOCKED", note="no GPU/CuPy in this session")
        results["tests"][tid] = entry
        print(f"{tid} {name:38s} host={entry['host']['verdict']:8s} gpu={entry['cupy']['verdict']}", flush=True)
    if gpu_present:
        try:
            results["gpu_vs_host"] = gpu_only_cross_check(host, backends[1])
            print("\n-- GPU vs host agreement --")
            for q in results["gpu_vs_host"]:
                print(f"  {q['grid']} r_min={q['r_min']} {q['dtype']}: max diff {q['max_abs_diff']:.3e} (tol {q['tol']:.3e}) -> {'OK' if q['ok'] else 'MISMATCH'}")
        except Exception:
            results["gpu_vs_host_error"] = traceback.format_exc()[-1800:]; print(results["gpu_vs_host_error"])
    json.dump(results, open(os.path.join(OUT, "campaign02_results.json"), "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print("\nresults written:", os.path.join(OUT, "campaign02_results.json"))
    rep = load_report_module()
    if rep is None:
        print("report builder unavailable (results JSON is complete).")
    else:
        text = rep.build_report(results, OUT, "CAMPAIGN02_REPORT.md")
        print("report written:", os.path.join(OUT, "CAMPAIGN02_REPORT.md")); print("\n" + "=" * 78 + "\nCAMPAIGN 02 REPORT\n" + "=" * 78)
        C.show_markdown(text)
        try:
            from IPython import get_ipython
            if get_ipython() is not None:
                from IPython.display import display, Image
                for pth in getattr(rep, "PLOT_FILES", []): display(Image(filename=pth))
        except Exception:
            pass
    return results

_EMBEDDED_REPORT = """
eNrlfWtz20iy5Xf/Cgw6bgiUSUqi/KRaveFXT9vtth2ye3ZndTkQRIAkWiTIBki9bN/fvudkVgEFkJTdszf2yzpsSyQK9cjKyndm/eB1djve
cB6n2bjvrZajzhN+c8/3/ZNkMc+X3vkqncZJ7o3muffs7bOXr995lw+6+96LaLaI0nHm7fe8YJkUy8LbPzjo7Pf2W13PezHPlnk0XPb1/TCX
zoKTtjdJ8qTtZdEsaXmdn7xZlF/E86vMWybXSy+IpsXcu8rT5TLBV3NpvSeNu/dOvGMvT4rVFEPF6XBZtju/8YZmNvu97uLGC6qPoXmj+0cx
zzizV5dJfuNlq9k5FpVikEni6ewAhllSeKN8PvNOjrxsvpwAKl5aeMubRRKzMUaaRFncBXjupTN5aV60sYjl5N69OBl5o+C67S2OD1v9ex7+
pCPvmh28m2dJH8MsV3nm+dle5MvjZX6j7UzbtEizYhllw4TdnM/n01b5VrHMg+vW9tZ4XjW+dttxdt20yKIMHTiziDJ/Q7M0G9Wa4bOv6/jJ
2/eSaZF4fodfuu9ee8fH3n710n711Hw18j9f97ufF1+Tr9JdEJ0XGMf70TtIOocekMt88dMxvnnY0pHsW/cPvo6/ap/J9TBZLL1X8iOdZ/3m
SAZQsh1zWUr55wdvfl4k+SU2c54Dqe85r/nJNfBV5yZ7hv2XffOw4fJhHd7yqAY3M+9A9ri2/e6CeqOvvpnhMJlOiyCfXwGNLpKbtk4MH0bT
+Tw/Pujut3EOpseA0kHPYBWw731tHd4C/4C9C4yTLY+8qPrgXU3mGDfJc4AYU4mWXj5fZXFnPhrxw6t/vDr5pzdNLpMpH0+jc0wI/e6UrTrT
dJYuk3jHC1KcPB1Q4JMWOJY8CpzUfLXE+TwdyAcSiyEPTB5l4ySwx0H2L88LNsxPsdzB6XAgjeUoEgqDI68Y4vksug74Lz/13+Cnv96yZWBU
nQlMoRstFkkWB/7a9H3F8euAEwDeHROsuxhL9mUeKNwxSqtVQ4u253f/mKdZgN6xZx9+P/nw/uMrzPDzPeD5wYHf9/xX1wsAuQBBmoNgjKIh
kCZPIuzi5Xy6AlFpe0k8TgDmbLycEIZeHg738nDEQ35xkSQLUJqu92FyU6TDaDoFHkTeLFnm6dDZOq9Ip9zSYr7Kh8keUO7Cm4PmTFfXgonD
VZ7zeRCnIHLjBJjaGeVJwvEAOvsJOLzkZOeraYwP84V3npDQFXPQx08ghxdJnik6LPL5OZAhTvNkuJze9IloAMs5mxOnsQoMCHyYrQrQzwl3
25ODNL0BZSWyoWmbdLP6licqmt4ssbZohm1adv22wLLnwpLthtOoAEC8vPPTPsCaTlc5yChWl5Jfee+Dyb96LeADZrCYTyOSAwVXwRFzLzjY
A12ZLabpCGDl4xZhMdHXOQJgOF5NIzCSG+8qXU4A5PEqymOd/G2SzzEVIEZ6idcvk6LrnSTyAvhfDiimEUhbmkzjwgtWWQooz0AaJkmUt70/
V1Gc47UhvpnNwU1wwrFlLeIGMHGhPAVMLkDjxSRte7et6uAWSlwI1zFGVj6VjifLcpvnyrxGaV4onIFmmHSRDOeZJQxY7XkCJplzZ7Gh+HtF
nop1/u8OkG446cwz7MplNE1jBaDixSwtiHHSeUf7ArkCFtjNOuRmPZMVecHs+ABTj/I8TfgWWH9WAAVxsOxklxOcyPFEt/+aPJUABvT44WZm
cN3MyctAj3KSepzcQpFykkx5NBTa3nMcwOehNAa17njXaXAL4juJCunT4hdGn3rBm1u0PvAW0xUnZzvaMEkcJsGW5SoGGi+K3Yu9XutI5mzO
hOwHxIV8Hq9wytOlYg0gzhNHrNLjWtub5dVc98fC7gFh98lCgpPO5kCFDGseg1wvlSuQ0EVADKUJ2NesECGiRNhReq0HZUZ053jAJCCSCFZB
R36/v8DHhbbPV1M0eZ4LZj3HQ5COdIEzMM7a3vNbLyayg9MZMkChziJGYjZMuojGETlh/SgDBMs0WwkO8QiAQmP2ShHlrZQHaQkMis6nkAA5
B4Dx0hx1A1/deNDOmF+TcwlAgNmQCyMvzknZIFPK6QUaD6OMrHmaRBcAl4XvQ8XNIolmZj8wda4XQoq35/UWKWeTZpdg25iM8JUaHpojzTme
YzIXhZeo2DjPOrWGs3mcdL2fQZBTUkF8KrwZsa3bfSDSJbZ+FM3SqRwMTDhfZUQO2Xh2j/mviJfjPI0LRTVn2mhEgoAXY0rDfCrULp2DZPDT
gr/HBP90XoA68o08ocwNeSWLEzJDYDYZSgy8h8yLvcR5130xLxWK1ucE54oURuR5QbgUVA+o09L9yudgHZZ06kEE4kHCAAwVZfV8sFli0KO4
AvEx+/KI+/IePPn8pkP2AU40HifKInRGkKpSwhBr1y/0PICPFwlIolDCxTRayb51wP4vOJ3z1dKuSE8yaMazq4srEnIBrBdkt8cHUDty/r/I
U+HJY4hX3cNWuS9ylEEVYigADgaQR2AwdAsMgNS/gsCArcLJWCXes3cvvWK1EFVAFp+A7E9JhBzw48l0mXb4zTW2ZwTMBW9WmCpizSuggIpG
ZJdLfVE3Jk/+wMlJYgvJx4TkO+FJ3vBmip7zijoWupIZyAP2zPIWz05nqCIteSNQaQbgCJkULpfEVsdRiSKfF0VnOEmGF3hiz33kMD8oUklu
KG1Ljr3se5wWQ0hQaaE8xdDHpFhjUNEVFisqV8kZODCPCJREHIIr0IQo75gncljaur6fPxz2AOUCCONRMq3k2nP+ZkH1RECFPqoRJorN4XA3
JlU4T6j5gUlD8tLD7InqZ9CZBGYicmXfGUNlMRwlYEua6bEIOCWclSGVhOnU0ELQuByS6tUeXtXfiMdsP0ozMLgO0Lej6Cs4VShiWJhxv4T2
EtsLvgOBjjwb08ZBSEQQKxbRkD1eRTz/bBN3vXfvP73qq+AQxWk0VVaPA5ksPMqcIPaCGtmtsJJYiCwhOZ7Oz4FMSoNw3JYJBvKC/9rvHuD4
4CRafiOvEb/2bu0UVCmS/cCnzr7pZRSRPGAVP78++fjJahEZKPoRuaiIt0SLlDDjSkT0bAvwozosQJu63kdBIiOZQE5MZ4WRq4gNmffJWCR6
bfx3yP8e8r/HFiueEitezPN8tcCxwgDoidtI6BfYbf6MqfdzN6ZpVAiRehe923udjfYmq7HlTErFZ+fpeDUHkEDSQAkI79TQg5Scyj3D+B0M
B9pAtKKsA+DgpRuuUfbNEPqUX2PBKQ41hEfQLJCDjmGQVv4okdBoHoJP1IMWUIW819lwuooNg5WJdTixFb8A1QfZpvy/im9kDXI6btPZCsg2
7eA5VBc5vNLEwK23T7j9goV3yJjSqcAuLhnxEPpBOrrxXvz+8hkUmNk8J55OossUpwrCsxBX6I0AWY0+G7aoxpiIxOgyxfpUuIKMkd90RC6n
xiurw7YQelQ4KEXbb5bzFahVbNjGNLoRXZof9v7+4XdQMChAM4DMHjFQcxzAIgLc0lty8GQm1G6PkNTfYMZK9LfiJhvKbwTG13sf3r7/FP78
+u2rj6r4ij4/iy6ScDGdLwtr7KqU9rfzMVjWuIbN0tRwHssYvGI6B+J5wYd3f8eeTimV0TpmJAC1VkFI+6jqYDbvQIdTCw67A5vneVpl0SVU
JkpbpZJeTbk7hMyUB60Ndii1a1WdHTm/d0FwAv/ZeOxDLl5rCdsbf/NAhBbT5feZa4zFIAYM50V3QWOKqNtqJ/QdS56AiuOiHcEMrbQIQLQS
kPRlOL84/pSvEl3QJ/R2cuqLWdI3A9A6l44DGhMhO6VLCqEwoqRy4gnwtncj5o9jH2YC78sbnLY3MB+OvvhChpJjmnEcS4a+TEvARd+7FCHy
Aho/qY8+6uIwzoqgxb25VDoxnQaJGNLYWgjV5enBoPXVNabxHGkH1qBWPgVUu1gEZLYAPwqg7HHwqPug7T3oPmgBMqpvHIvBqXyJQ2FhbS+Y
0BBRtNZnWC3KjgI8xV/zBvZh3gEUpleQmDDarDjG/wos/N+qvW3noD8xth22bDWBTSvZt01O9wf42zYfDvihaimmIvDXgP8u8agly3GBrDwz
aLXapdHoGw0HNdAssBLRtQQJ7oTEabK/G0z2Jvut3d2FvDzhi5MC0/cvfO8+elIoWeiMfOnVg+HTb9W28VoaBP7Eo5kiy1vEbD5QJAz0h/lO
0DUwSDuCpiVbf7BvHpOGBsR+SEaTdDg59s9hbvDJuRaT6BgyrrabJmMax8oOHtentKR5IQTRBIkN+ErzTMbGcK+9FdFlwhMFAMaL9Pjg0E6H
akXCDhxyY+xyCx1xAsaMzj+ditVncOqTQvuD7jhZBr7KsJj956/oQw7Y19KqOIJANRLJgX2s4+8l0SrXjg4eXePvE79mNb/se8XpKBugXXAK
GfjUz3ziXGVcvDz1aV/0B9jVU2ODVIkoRMsevqXJen+/tekVHYtg8UnmQ0wypMwZvrntLrIxzYkUTSiZ9K2cBfuECEltlU6NxmJm751HMLMS
GutUxiUwivegJSAvNBbvf8XsA4g/fqfjtwYl3A8t3A/vgrt+88urt69fPHvr/fr63a9q5HGf1sGLKbB3hzw6O1fahIFAs1vOPRHFAfJWEPhv
coLlDcRI+XnrtxoEqcCO+RQnQTg/o4Ov/h3bx1ls2EG+vi9m5A37V3unQhd3Gw9Dmroae3jYL81JgI4Yw9qOQQ4ti2LDNowOHtpdeLi2C2pL
KNG/gf9279HFOvJjD/xT4tDAZ5sL4TnAzRnghc+cBkThBw3oDsUsgncvuiIkFpRGAv/57fFJ4huHRq+5Hxd/8QDR6r4N+nednoehAUgD8g/7
DauLNaqY0/MmV7vLjfcMFh+cMPPpeWv7pjy2m/L4GyRpK01CH9tIEmgIZ2Z7tHYfee10v/uwfdB9OPC2kizSrG5B22Tgw73UIsDvez5W5v97
O/GX6djjcBZlKzg3IJFAu6xvx+O+5z7dYJNoc6pbQF9cWcg/aULeaJWhaK26AZbcFFcVjEePHqCL4urUh34dLR898OFIGh323C8Pe/5g7WjH
WNmT0IzSWNSTvlWcrXqtunNQV5tbVI2cP5/9nz9gOjX1N7DSENTVFlSoAP4vP859Z6+wBO6SJVUhXmw+btUH8nSgmrYeGHW9b7RyM8NvjAjU
+M7xANKOJ8MGpS0ElrRczL2w8BpNf9uIhz0HE0eLw14IwW5VhKMFt2wDRvKN1tf6PE6DA4M/kGk7/L0PVKrEd4GEX3PjVZKIqmlihIaOEUGk
EWdi33Vi+l88X07XF+v8Y8uWfkUE+SKPv5iHmErHlymHwkxs2y9+5Q0t3Zb9mptybSB6r4ctx4FqR617Jf8zc7ySbIEvdGWQ8YpgadZjdawA
bGMJmq0dXwgz0GNGFWu1uPFFhpAHS6PJbg/cOPZfPPvtw7PXf38Hrezk1Yf3J5+6s9g3YybZZdv71PY0JkT0MHzFzaVGBlNxTutYYb9wVLS3
okdDbMTPtwZE8gDaMvXDz8s0Blot6xSCDxENQmTAE1lM84kuG2+jiSyRg1pCrXR8vFiFmBhGwWT1dX61gB0EOjbA9DNCU4x2CQQPxb5wLAod
tQ3GP/gfnn386FdqB4evlI4jeQ194i07mFUJKbd9uwcZWw0saUJ4MEAkKCdjOpMhxLBs16Hu4hBG1tskC/EIhJy2DejS2ueHwP+hFtvTqUX3
aCCQX7X9wdtgeR4nc/pEbowQ67ipxItCWhHRfg73xVi+bgQNAYHtCCN/d/eFrlO9tp7Zyb73eefFq5NPr39+/eolZonlehIoJD0ReBQDSmjA
4rNDtK5gJrLMDuyiXtnNztfd3XJso32XL1QM5mpyU4U38M95xC04BVJVyFVtmqv5Ez3+Vm4uabS7/7L3El7CMylt2q6Kih4wVJ8TKKmGrpcv
LeggZ+iWkJEyVgFvtFpNm4IZtd4VrWIkGd7zt+9f/AqoSkhUqha5AG5JNNh7sfpwgzgatjU2vSIaJdhDEyYT40s4BijOx/7auN+DiI31VQ5B
fad0TXryBizCwC9YfRLKGtqf9/GXZ53ew0fO+MDVE0RhYGoGPkcWPhhMqGbXwTr/RHybC8hY2Hhv990cvplU/SXHdNByb2BU11/0K9hhZ3Ni
aHfX7Qkn5ADmOZ26WP3VmWqOZQpjLY2QzivKj0594g23UQ49SeRpuZpT34CEFkG0Gflnn612Th2RlDlA76c72i5kux0wzzPv8rP7PX3emPLO
AGpU2+l+d9cA20ASMVrwe14nQ5hIY1g8zJhuV7CUoyF6Oqt35eyO7UwOCRHLDA+RSPcN8QhQZVfnMwbzUZiqRkmuF2Ix3zoOZR1xyJfDGRiZ
QaQzWb1g4I62D6v2JTDa3s7/2Gl9JZoEvsQKlWi79SUwzWPhF3ZrygcDEyjnebu7P3aqA7USy3fmvX/78tWJnSt4fgTMg4h5EY0TArpVW6TZ
FaLiUiMXrB3YTmjPgNJghv/PVx/rS7jj5JmZ7u6+e4+RawPXgyrt+Sr3R0FqG4WTCKspCrtXACjgebalxwMJ00RT7hlUaPixYZf8xhD7B6E2
vXMMIVy/f3pBTJK9WS2HqgD5H24QU5BBH3y3mn24kWEU0RbyAPiFZ/oNzBOLGz0ieJFCNWN7bJflZ+1XYzbUH5LbNuPraz52Zgb6qQ9L+YKb
ldF/51Bdn5QJPBBu2aHnAEF9FeEwWkTniCdY3mDpbXW04K0lXNpu61UcheZrbQcSXnu+4PutOppwRhYhGkho+ES5OPASfAwZS7aivjioZIlf
xPWSjEEiiaarDAq6sl+ZrEHn0n0kvo/x/ftKHQ25sc6gFx9+hx+rHoZCFznegbTBCDI6G+lXF//c7i54xO6uDLTnsCvHBWUjU+2KzCyLiB5g
nZo65nhS6ZUUyJ1EV7/qaXUDmbAw8IwdGB8QwGzeyrsNTtDrei8TeChFLcbEYYyOqA9eV55AOc2rjDHHwAXr1YpGaEsfWdHawClI7uuc4pS2
p+CyZfmuE696aeJVZWsvBzVL0icrrDhbiGkfgoGtZgjPvtkwOAmi4K6ZhFUliOEyFZW1zSxp3AeB+UzJiE9oo/hq+Ent6wP5enCXtG4nSVMX
kfCyEOlX7F0nfZf1/4BFcI8vCyMRWt8fNFc3xqMCbn2NNNdwTTlVVP4i7mD+Iu4hdN1hv6IPlmoNPygE/jQ94AN+1U70d+2HQAn+VNUboc8h
jsjIH7TMt+hQPvjvf5Ujiq/mFyVb+e31x9+efXrxiwHVn7L40xo85EA62/mA7mAnICVi2Fik/KR0PBYu6u7iNP0mUU67u30JFUriDoneRrEf
GF2GvULZlbiK+BbkFKatIO/9q9fJDxisKQ/2aCeIb9sSNGRiZDc2ZBsnctZ0jFDDRkTKo85iTv/43xGnUHTeipsD58pEYDIuCqF9EpfC2AiJ
6hc9JJoWpe9b3jVcluqJMQIdIMS5BhMTANoxhAA/E41OUXQisGKNwOC27JahMrtubGcVLApQMjZlW8wofLPpeJ7NNd6svcHcXDeDniR7r2eI
YL+f3rT+NTPBi/V4yLRYi/XBRJ14VpmXOqmXGo+wOUJVnei7u0k0dL3XDFrbEjf0aDmxIRsMp4JljWhv3qtmwGmCitOX51UNEJ1OeSeuhXfs
wQiPf4+bu7RBQ60ZKO1meb/BfvQb7JG/HXrBfY06RlSIBmo8e/kPbQj9ZGOMlAQuvcmPGWjcip/f7hE9OzFjK/eIu/RpHMfPc3zoyOOcZlBt
HsRBzoYtfNuRNvxw5Ak0/1rglcVuYWIal2fRdw0wLzUyK3E2DA5K4ByipgnzMthkT8PVhPoydOYBwPwI/57uUV3ve2eOMIe+Qk7kDDqDGrY1
DOjMESFtG3GHsSF+tJjlAiS3mTwatybBcjEkl4zCNENfgfPC3ykw8vRKuCxn50gC8m6lOYIrj6aMNtOIQuXK9zQLBPa6juRMiPbAT2WIgLE0
hOfT+fACHtfYMeTT4CPgEG51VE95aDpoanY4+4eHnd4A2YnPF19h0DACmRkXMhk4YO0dmhCMFwLhHGGuGi1VZuntPiwLMIXU9dvr036vZxwB
18awX3t7cNp/NBBB0/e63a7wGNDYYK0d3YmPSpFwy8SMwdWZ0X9mZ2dnADlGuDw1zwennaf7+/2BmivxfNs6GWyxaX3oSR4Nau855lS+0GoG
mGy2ldr9JrPUbbbtqx22dkaXjz7sCu2xiWg1hgljQ5lYYKgcWRvMD7tU+uq5R5JXNqGwiVgqnJFc4w8Q5TfuMUclnIBNyk/EoHeBLmsZLTit
zJ4rvjvdJ/jxWFzDPeAETfBfNLwFVndYSNFyV2JRd00AoYhKkhjUl3A+nZ5N/NHwYyPPQljH9zPGBZqYRCcGNDGwYhNJAiFDcXwHml5VC4oi
B2FIX6K2tRSxbGfy6pkEy5ekbpZEhpnbYOiOUr9CJFcGfXjvJa9HRUrI2GpQtCB0WbINtf3pWJCNhni4pGSvVHhTS3zghq+2GsL+DxQYvBcu
09E4cSNWpCpiHQm6fFjlTHXp7sp4JrHoVHKKzBnRlnWSJM+NEDwBLREE1i8rwdgIZaE488Qn0f8uCVcc8RILWRCH+IkSHXZwKrqGSmrmkwhm
5vclQr5LSc58VxeoXCW9VCtP80pKzh0p2TiOKAwbX5FMij6q8O9V++pLCbvTnloiQ+MpZw4En6pny36rc1z/nqtZ/1bWFW57Z8wVhtUKW24Y
wmljG0oVmX+YI4AWih2hE2nvEDcawo3SabAIBwnYyvzCPLoyfK69NScLQspnwO90B5H/y4iWQBA5CQHWVA5xbYqb0qic4tZGe7YJ2Sbkw9Do
ozCGHDnSWJWPUGkVlUiRUC2lObhiy3JizVyTuJymDCrTpCZEEHMM6jFlbyH7CMtXw/JVrskEg7sdUxP5t7qVF9mpIy2U57rnPas7Nr7jJPe+
cZJ7m05yzznJJvCgcYTF27omeTihUaf2xcHmCD8RVJhtqrEk+eZWdijLXk85grymWatltABpiITXtCWCQNzX5GuhJlXKgVl/xcZUyUvmQ+Ot
tenU/oyq7k47CBwsY3x6ekIbT90YLjwHj+AZtiHUoST7xf6m6InWYJOBQEBMQkfru1cSU3X7K49HGEqbOkD7zS3NkWYKWx6S6ZrAIXTwJX5z
+8X52rxafl2Gfuu8Fb5CF+nObjhB7LF01ArVrr5QjelYtaazRb/40mo6mGA4FemV9qavfk3wndD8b4+YDBXWbRwW2awsVpurcZoUQzqq1EjG
RBWblGnD1o1fVqKclERWXHtiTeY6Ovffl/fD8v0wzUJ9z7D15jQk0AGWI410YPwbLAzTm1bTkQQ45DAWgzb2hTYSIviCv5KOMM1YXJ/me/md
DwA6fJxf0MJc4xkSE3GpARFhOa47yzpVOmSsbyMnzZgGvoM+HX6DPh1uok+H/5/QJ7Y7qF45+O8haXxCNz3Nef9dZEUeHujDJpkRGQ5Wtu1i
7TrNiFQ6kbhVEQGqXNmwTJCtSSr+pyqbVoxhNqX2i51r6wttA8YOBVsf82sRcKKzGgURJDDr7dtfPAzxNLwwaH/nqTPHX8+XUf1FLCgH00f2
YwixhhsnMkSeGBkCYp1tBzqFT/zaOZlRyQo4W8ykrswV3udT1pqoFO4Ip1ue7AwGXxvUZVQnL8bVwSMrFHVyuuNSgZ2BQ0+CkppsaFVSl9YG
QvEAPgwR+DQ1ZvG9IsyDb5CIB5tIxAOHRNytg5TYbhHd5CpfFptTiyH6IiqeDSXlqcPkZc0vVtFUMv/LNufp8grKaqfynWr2kMn1twPs2Qzp
PWZ44f+DBFFo+Ene6iZmF1u1GF2HqiWZai74TbvlHpXolyfTSoGQNYScfvk944HwxMw8LGce6sxBMas8hhrnWFcyiGnv41iy/I6hlwZmlaw9
ICl2kh4uviIAlhvQ6lsAmfFr4j2sjASPCw9K2cDEeRyHHCU8OBBEXJu8iNp4OZSXQ30Z57dtc9Y29qPP0Kxy2wl38EUSF4fD8zzIjxEwKJnS
GWQ6tc6aYHHRdgIj4iv+wCkW9Lh0WnyUqJq6FXqohOix6xA/bZecjLYSerivRENy+klYe3+9iyIcJz05q92m7PHBydZnwECfi9Rs/tZxhwu2
if1tyeJ3nvGT+/S2fIZfywe1Kh9uxr3ubO7QCS1CQGjTvSAJouqs1IT+yNvVlPwOs3B35aTmYuKhhike7XoVgVoxhcouhFR8LDrKxDYEc88G
+vXQ+2Bz3cssRZvA/h1k7OE3yNjDTWTsoSvpmLj8b1MywxGaTPpuJiy2JeaESRUi685dlzAkeluEiKZcoYGE4iZsDZoSuZ39oOlHtdIWMvGx
u6Y1KxBsE80kPA+hmNEYzHd2fCjlCjriyFOrI85AAa37MOSDUL4T1nVZlLULqjb2m6rdUY3klPUNrvJoUWMKip79qivbNGTTGsnVpqURQEfx
G3QcmVqVFcYLlLvYqgrJiKVPwBCMb8it0WAmcBCaZ6F5qbH+zSqUd00Vqu31mlpUYZmD7U2nEDKZPBzP53FojOqlNlWjIf4du6tVHBilVO6w
2VX7BMvU8wgCG8hWtxjfz9oFU/WrOXYgld+Mmc41triqdFHKTwbTSXSKSToChbEngmz0YuNLg7XF1WnDI++fSVlNgtm/xvD2HXTh0TfowqNN
dOGRa2uVrI47bayIo8zbkjOQGTOARBGAoJbm1j26eUuTq3C3aQR73oUJ8SD1nMtDjV0wdm4BM740VSk0ab4QIlQVlNBSEkWZf/49ltix+SmT
dO2w+UhNoGqvHTofShOs851wQs3ONpbTVvU9V+hL3HPuCP/OI4JiyLzhQvxTNN5aSIT2gQ2J0MUV/iaTEUQtdSwp7EKBXYWmnJPE3dMBhkFs
iY8SWfek9lSJp1WT0NSk0qbEhvJdid235fI00owKP0yQ5zchdiXUXQntpjD2LGg0GUIBpJDU8ht2ZU0kqkd48Bw8rrseXH+3zeb/Hv/D42+c
icebzsTj//dWgSql6nvNA40Mqq3Wgu1cds2qaNKp9gcWV5Qebm518F2t1HzpkzPcoQr+KAbuyzvUQP9u+4IUnEAuuTID0oy6gzLg2j26Jvve
RlNlR4ibKbgGcWePTfZME6q4HdFvxS4G1i3z+ksWyppxEj1stk62S7a0kceaPUf5wh3uuVotNVt2p2GoBNA2WDObSLnNFPfEe1dWqjHzo4jq
FDX5jrP35Btn78mms+fk4DYS5hpHkCuLl7oDVtartb9L6Nv9HC8RneBkKbetrtDIj4ttvKNaK4Con6D8MNlOXLA7g/74axDn/+rdj2/xXwCH
jgZ2MfDrDWy/0C7ue0Ad2oieY6/2JpCSW/2aptQIh8wrByYlFcNKqyQ8eVybVx1Lq3Q2NanViwnJ8bhQuTyX0ayKHzv+wDKNzn7hZPLZr8wp
sB/XcuBahtWtPajVJHUYi/YS2n7/4uu5agzNKpytpr2qSmhsWr6i6dwWU+Tu99dMYWKpgjVb21sFmkr9J/EaizGsjFhwnPSmspKNBsbDzfmX
pm5RlSQiZajKHVSdc0E53omFkFEFQMYK54RQUYyaJrOWjdHQMA5UqIXYukZiGmtVyMtAZOXMjEQphsGpBuoWVtXjG1mOo/Gk2+3tP3jC4qq1
NMpiAkBdmPJCU1TJktpCN4XNJ5FgRoPOzZOiOAs9/3dss6xOOC3DaapiWsI714wPz8r6hwbWhNNRvbJQFSsBKYz8I5HI5Y5tRKOLVpm0pa8I
yD/wjoSBN85xdYbl4JuQeNuZurV4+mxXZT/OUWc8ddVcTX/NY6sSmIwhBEiRP5OqSykD60sH2mk5WFgNNqif8bD+1vrpXj9YtKhb6Fpy29Bs
npms8FqxJrMRKvEb9zMgT0ZZljQ78g57kjm+FbhiaJDI2waJXCeKDqGTt1TpjPMmDKpl2z7Cb6w/Z2/O0usM9Kn33KYJRjF9CdRBWXNTtdLv
4J5Pv8E9n27ink8d7lkpGCJ8N/nn5VA9I81mTFoFmfyH/bqcsyfPQRMluG4IsU0iSpDHru5ncQE6Hme2KOuEiZH67AVEHFtO/RWp5JknRd7+
XKEqb3wEemB1J1NsicNK5bJ+NQpyYKAS7wzcCg87v7979b8+vHrxCUmQrfoc6mQBgImym4CU1exqrXV/Q0iRXb+gkw5e4pSjZpbNzLGzLWsD
2HwGi1HOkcnMfjinWKuoMXjN7oop2obOCFfWoNLtyAhs2R9kZJZJo1V9TVuiQSgwg1WPrHHcoU9Iv0P7TMs+FndExFRF3EyirjeXwnBaN9Ot
ZbYFNzjdvXLi3TUD1t2hEv4vKFlnJx2If6OlNrTNzjVukvjXqnmblDGKc2hQfm9TydZc2SySZ8nkWCMpN7v8XWJnLcjtirvR2Nz3VOG30T2n
44FULdEoYhpOf7KeRBhW4S1C0BVpzYh9CYLJ0LBWVxHKR+akoZsf3X5//M6OtEjmTf1VTEm0ImbDxvHUhoPKNLvfR5q1xDBntmb8MWSbktJI
M3Q//vb+/adfbN0Q4XyzhKVSa+DbTs/lEBbWDvFv2lxMBB24Yjpi1tl2BlACdJ31VcVbNGRsjsq5yZVr7JeTUikX6AWPZt7hVp6XmZJCNRgq
/FxTssLyW6CTzv5v4eOYpbcDiYKHeMGINXVAkUdVUSxSmbHJoyRSvVC62Gw6aGhPUOo+NUpBap4u03H29w+I5og/SYdSnpLJZMsuwo7pPtLy
t+IDsi0m83RYluysZRiVL+P6DU2pRh0H5PEYKTaVhODRfDql/FsTbcXTNM80TaDQ2sAqqduSAuumfD9ITd/mqHdsJc1Ky7CifvBfjIhW9qel
eKsKnitzGQhbPKJn6sBjPiXFc61HLdIvVq7Vrpl8CI8UrB0AkTjATIl9qR8s2QJRpkTfXD/S0VBxysta5rvQCv1G6jTFD1IbRDtKTebnJu8F
1mwWfTWX+lOlqoP9TWMWJTaAE4VAdiRfCU0TkDpUDLZoQD6I5PIGmMdWMzAkyVSink8vIA33ogGmqHl+hELKPRRS1vLKj1D5ev/pI9GdYGhB
KP2OBIyHdhqW+oQyz9DU6wlrE6L1atdAmVOuAr+kbGVBbU/DW2FYWCfSO4O9f3dcccVcM4JA5SvyldoyEFeONYf2OWd63Vrnxv6JlIBVNEis
6pnEZf6oKUkkRWtZkEJ61+0PsOQbJAaINCLljTXd25aPlYIaKDycMPihwVXu4iwlpfIspSI5NMKjOB42HRfrkejQF2CrDMnZifPWt9SFzfSx
Xbf4V1+XdNLMJDQzccK0+ZAuAs4m5DRCY4FZJ6XLjQ4kktCSqYRVndvt1JTcqeRCzcK4oGMZM+bkrEa8sOeMtJt4c3jGQyDHO1IXOF2LGsoY
MA5BkxlRG4R3Jr0WT7jNYC5LTwgGHRrmJ4Nfkq5JlB9hcKdRzPC/ZT04q2ODs6rLDmBB7VbbrfVPTVXCL7q71xUHhMnDVWXrYfHXlYrM2mSt
Qc04cgfgB9s2S2sBGwmF7UECcG2ACYgpwrLqr19mCxtdUL0+UhJIKoetbetLLTNsU7f71SEbSr1qGam0epQDbRCZV3ABG2VGxGZ+4YR3rppT
s5WKTv/C8rYFgfb2JdG5TMXV4izfVpdRzPlOdRnPzVasJ7aZpbCLRgFC42Sr/KKXdbDnTLmn48NtN9hkboZ7HIMxoVbUnnxM5VgrSN8mZWV/
q6bdF9y2Vf3bYlbcI69rl7WmWfSUcn+9lDQqXWnkWKCVpqHTxczjAjqr67LSzpC9WSstXaGExF94ZD+X9i4Ek9RoQ5zapQK1UUFsMhCm5lWv
mBx3luhinSjBnTIrT0ISjbIvNaHU3Un8azmKPeG3V0Hy/a93cQ6ryI83p8ArpKSBhglVWMpmxuNTLU5rA9hc/G0rscxko2a7zUVdSxqyqfXG
4avTZJRJpNqU1IwzD2XmoW5kWJu/tKq8xk7yiLN1VSKJ33KbO1n4ro9565I3WODHTRIonQErQTSLslj5psMV6dna3N7YQ6Q+xzN9+LGsfG6i
UIWxiwarBTMNWl3DfwO6lO045Dyy6BTRjsKnXaSz0sSKRMGQmZo7jdBXLsXWMblzGYUuY73toJkyCiJka5AIcE0ZK59GKX+tvjvKOu2aFuCx
mlVa2KzSNduEVLOb8tKdTX15wZl5HarqVF8/o0fsSuxDC3yZiKFnrnJ8sSmMeUlWYUAr+qQpzyJfmHodOx9O3j9/++q3jzsIEVBv6/Fn01A+
hpruqAVhoL3giSQ2TpF8GZdN9UEYw/+jlV9E02tXoTarrNiWnNGoIHavpkFuLAtGkdYtC+ZWuGGauVYWU7HH3B1wTtMZjpSp6aU3gkw2IivY
ghMjqDX0jzfV3rezl2/XyoO8WCvEH0y1Rj/MT1HBEjBMKS7k4sl6cf561RCpI76UYuA6khy0v52uF+hCq9bXQdAsa7+3pWWrUUzmUVfdZXtW
i+PlQGmhxvF7bvKKWzfB1g+QdxgNEeWb78h4bAPMj41PCR3Rq4TxxAMrNi96ugPr8dXbL2o+o6LtKJ+XrkfPE1c8GLBe3VIYPUQcfNMbV9mp
OyWcqj31i1xELyrH4m02xoc2TS8SJA5NjLesymguVUrH68g78AreZoDrqOyaYAvIlitexSf6NEIDjxR/8Rem3swUFDRQJEyaQaveY+yViQ9q
m8vTmIeMGbVL870NKLSROSpt4a2ifpnilmo4/e8vPVAZ1DcUE4CAPxAr6umgr8PboJlARkbPeWtb9n9ZZlMI8KuTk/cn/rZefFMlTCGvBLFW
RID1c1qnLALbd0r9kDxIh0KKA5ZJqk6GkOgN1j9bpEjLVjFmhVKdajMRCk/AsoEyCY/2Des1X0loEYeywyMvIy4kT8WQ7aGWem3zb9XcicBw
DEhah1t6wDt+496V6mmDpL4UbPFePsHBe3kAm3KlulsDeYuGuGd1a9VZ05L9I3T0M+v5B57Nx5levlLYq/fUgi6aJHzDCeZ55prYoZqe2asb
zc0+tjNVlMrzNOWuWn9w6TuxlgQyl+q2GuViqJG4/zRh3lJW2q/rhhTc4WZWZi680dj+yolPy9xjZRZn+T5w6QJWozPcQ5VM5bSxcgDg1+e1
jpRp1KPWYfoRLJsNqz9Waqz2SeVY9W4SrbJpvjur8pZ/4hsmUkkXtFrQSsi7OLou6xTF+fibm/106zaXVwXaeGS5AjORXJezHo51aUw4OzJr
5JBncu0hOusZA5INtzd1E2TLzNQfdh9LsaZDXL3LJfMFAZlDpWvFDj6YIATLydRSKyLkWt1L164RS92FeCUZGlH5ul5aa2mh2pUzmP9ttUgx
g4hrhJtR1qcl+1KmBEvaiIeLBRoS7/H5emmGx+dd7x+mO1Dy5VzuXVOqbqexodZZVUrS17KDSCghP7kW45dbKNe6LyWCYakljt36nZcH3Z68
bAJocArPVgwYZ1WcS6myeCadPuntj5J49ISVWfDx6R5IgBQddUvbesHbB2Clu7t0nP/87PVbilUvn7SBSCZGj2Zgd35SYo47JLGnVID5apAl
Yw3qdu6uajeviGoBfTrmliZZB3VkNXlNeVudXtqKs1YvxoimqKtUrrJcYfL4vPfw6f5js0JuWWG2/rDcFK09XbNc6hVmqo3362ESZe6JAgGX
o5SeW6+0yOHhU1MUyy1GyCJBetX3+c3STRfDceZqhcpVMX32FnJMVGZmTBE05VaO3MBWbzJ3pSFyg0Isl8iyg3i32htcrNEs2Pak6/1ieKUj
I+j9ZrjkBWdNCnSrg9HBYBGty3p0xk3Da+HMvGoS5Us9hpYpx6z2Ml+onOTUJlRUsioF8UjKv0A32TWv7pYCjhi7RcoR8EuEliQc3Qh8TAkv
LccS0aFAGfXmqC71leGdtl6i3OKj+NHTIcTLNJXyp907CulekW6Ypevnm+axPGtUpmIJr+HqnPU2+Jqe8rI0magMsosZgpGGtHUXcreoGn1g
e8oW4w7OOWFuPh1qSGGpQpTcTNPpyjpADWfnkYGjQSAjaD7yGtH+tQOHHjvUwhzVoLDZR5p2tVfNw2nDTDNwDcj6Z+YSIVMPCYY1aGU89uha
SNuiS41A2AznLxh5xiCsn4h3ZxWbl5Lp9ekxYb1SF+SEKK1ion/vP5wZ8fRPI8Pyi9ptf47WZlxazq29VopEZ1eRyirLVKvYOaZ7ulgYMiVR
U5uCD+EH6j76D0MqWFhICwzqDLT+tqAhblmTxJx6WoVknGmSkFvbRShdlWQENlxIcL7AEvet7HcfXd/f7z65IVHWewOph2ARsM8gkVNvsWW6
I5aAmEHBVKJdFQJty7IYmlFmMFUJS+IQKA+1OpGcW2Y3hV+aEG+5Nvj2WK60l3nZ+YgzNJNKjbgWEJV9ndto7b3fNnNK7u1tVAXG4JIEq/m2
NauhBgPLRe+JAOBAC0YrGyO5f1M5SOXqdG9fD1sJD0sKU42d1NKMJEBS/krDSGwRRXtLTNuT244aW/rUiYapzdIQGE2DK4z5RerYRo4VVMqy
1+yigRh6NJ05cu76tQq7nljTqm10ehGcXAev+K2vNsC1Wb/ZK2P/LcUHMJAypSsiPQOa5FL6Vggu+gUpKg1YStCnzLKKvd/f/fru/f98R/lW
sWmaOIackY0lrDDt7QPD0D0ZTgthJ7PF8sazNWwbwC7FFKmEK8OI6GGCNSCBkFVskV6Sb19yuebLOxKRs+RCSA7xXKcvxel9g11/IpZ36TL3
yzS56tcjJ2zUgyhWPEbGp3dUDaErg/hjA4VkgSatSG9OUDbMQCMRplT2OHJcwpy+JuQuofeMFM8ty2uKFU95g73YHqS+m1Bg8uQNLDSv2slJ
NGbWOvN8BoSHdOrcwCDELJ4jaiCRXTZUjp8Ktzh541YG/917Fd1LObBx/Dbd+HoeWQmrpKUudwhE5JMadryXr6y0Z67hMTf9bLomlnFvq7wj
r7r18OZ6pXdZmqPJfZu1WNRKJYMEmmcP6mJuua9PoFMNXdaGXS8Kq+Fed5aBpfvrgb9WvLtuoXVNs21z/YSaXs0WIYzNOMmsd+z+v31dqlYZ
r996wUsyxOxDFyLy73Al5H6rVbsHpVUhRmftmolaxfTGHjg0v1ZL254zI75zpeuVucujc1SKxa78XZWgtXj6pD58/d4KU5hfrpsuy/WXILZ3
I1gvX72qv9DU1l8t5C/QIq3HNbvyzB/UC3sf7JMEqAiaajyRvXugJAJ3XwhLphZC4sLFsAsWXuLv3dBefhCGmy9+NY19RTbeeUD/SKB29+Ii
haUQtz/8lfswlP8DK5HpKEA90zr+Xu2agTOCNfPWnom6bSJZEHoGinAEhwCukEIEx982Nm5t2mm9rMBVcLdet9EuL8P4vls0DP7pCI1513r6
rpsYjrz6dQu1Ar7f6PL7bl4oL5hPE520uW+hccdCW69faFy00JY7AAL9EncnMO+17SLdZ+CP3s/BlOfN9xl8/30IJInVY5Amufxj22UIJJHy
Su2ehtriZyjbDC7RYSUNIq9LZZzNC83X3T+g4wD9NObQxAOWvaucxIDYJEuU3omRE86T5kUr1kRytulOrjOA62zN17TLe+6at2ZIXIVBN6OP
FWIP5mWdMkkx5QVJd9yFuRZFYx/j31PoSSDdjx9LNLVaRajmY15JJIe4PgylyxSHmYPwCnqQagBbQm+clav89ubj+3f6m0xbf71NFwzOA0nW
S+YN0rZK6Y5CF8g/6+iuUT5cyvOWhV8dcZZh+2Wo5Vr9+7cHjD4xUfPnrBsk96xrCAg0iPJaK03ucgTgGIaSoREQKbtd2NsjaI7QkjBC72dH
dtZqvBKdtzAVOrXcpyXSxkOvBVe61hzwlGaAy6RwKnvWbqk3M+OmODfMa9ldvLmAqrFMbFRi21wV37h3vlZC/JNbwKWMniyghx1LOm7wvIXa
give74zS6lTJgNnWYD0HU+bN4UvrRxBXHCJN4+hm78UnWNBZJsZaIMQKXCTQiTjHVUaLl1WKanNyLGk79fgaZZilIEcpnd0ivhaCKxtBIDhq
WNDKPEJYmlnPVmdrzV+1gcWLmLk+yb6jmKkv0l7ubmVIW5r9iThCmViZkIepqrM1Ua+5BdFaCSSblFes9A4rq5sowpTDus6JJa+VP3ZKZL/d
wP/h7kbt7PW72eUqaGqucinMcE5QHuO2nVEH+chdRj/hymoM0PrGRfA06Lu3FfKde/8HRcKPaA==
"""

if __name__ == "__main__":
    main()
