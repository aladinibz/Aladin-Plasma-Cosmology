# -*- coding: utf-8 -*-
"""Report builder for ALADIN v4.0 Campaign 02 (tests 011-020).  Contract: build_report(R, here, name) -> markdown text (also written to here/name).
R = results dict written by campaign02.py (campaign02_results.json).  Every number in the report comes from R; nothing is typed in by hand."""
import os, math

def f(x, p=3):
    if x is None: return "n/a"
    try:
        if isinstance(x, bool): return str(x)
        if isinstance(x, str): return x
        if math.isnan(x): return "nan"
        if math.isinf(x): return "inf" if x > 0 else "-inf"
        if x == 0: return "0"
        return f"{x:.{p}e}" if (abs(x) < 1e-3 or abs(x) >= 1e5) else f"{x:.{p+1}g}"
    except Exception:
        return str(x)

def o(x):          # observed order
    return "exact" if (x is not None and not isinstance(x, str) and math.isinf(x)) else ("n/a" if x is None else f"{x:.2f}")

def cells(rows, key, orders, floor=1.0, tol=1e-12):
    """Observed order per component; a component whose error is at round-off at EVERY level is labelled 'round-off-limited' (its order is noise)."""
    out = []
    for c in range(3):
        errs = [r[key][c] for r in rows]; sc = max(max(r["Jmax"][c] for r in rows), floor)
        out.append("round-off-limited" if max(errs) <= tol*sc else o(orders[c]))
    return ", ".join(out)

PURPOSE = {
 "011": "Exposes wrong face areas, volumes, edge lengths or r_c/r_f bookkeeping. Physically, a metric error is a silent source/sink of flux and current (divergence-free or force-free states would stop being so). The kernel is probed directly: perturbing one r_center must change exactly that ring, by exactly the analytic amount.",
 "012": "Exposes the classic r->0 failure: dividing O(h^2) interpolation errors by r (1/r amplification) or hiding the singularity with a guard that zeroes derivatives. Regular Cartesian fields (uniform, shear, quadratic, smooth, kink) are mapped into (r, phi, z) components and must give the right current on the first rings, at second order or better. This is where a Z-pinch-only validation would miss a first-order defect.",
 "013": "A kink (m=1) carries a transverse current through the axis that an axisymmetric Z-pinch never excites. The helical field B = B_pinch(x - xi(z)) has an analytic curl (Jz = 1 plus a helical transverse current of amplitude eps*k/2); the kernel must reproduce it with converging error on the first two rings.",
 "014": "The axis has no inner ghost cells in a physical sense: regularity fixes them by the (r,phi) -> (-r,phi+pi) parity rule (Br and Bphi flip sign, Bz does not). The test validates that rule against the analytic continuation, shows a wrong rule is detectable, and proves the kernel never reads those ghosts, so a driver bug there cannot leak in.",
 "015": "A seam error at phi = 0 / 2pi is invisible for axisymmetric fields and breaks every non-axisymmetric mode. Fourier modes m = 1..4 in two families are run on axis and annulus grids; the seam error is compared to the interior, the periodic closure is rebuilt independently, deliberately wrong closures must be caught (test sensitivity), and rotating the field by whole cells must rotate the answer.",
 "016": "Off-by-one staggering, wrong strides or wrong ghost offsets give plausible-looking but wrong currents. Awkward grids (nz=1, nr=1, primes, g=1..3) are run with random fields and single-entry impulses; value AND support must equal an independent multi-index reference, and every off-by-one array extent must be rejected.",
 "017": "Native cylindrical fields with mixed r, phi, z dependence and 1/r terms (curl derived by hand and cross-checked against a Cartesian numeric curl) show the discretisation converges at second order away from the axis and on a narrow near-axis annulus, with FP32 inside its round-off bound.",
 "018": "Near the axis h and r_c*dphi become small. Four things must not happen: round-off silently dominating (FP32), cancellation, overflow/underflow giving finite-but-wrong values, and convergence that looks fine only because one spacing was refined. NOTE: the radial-only sweep keeps nphi, nz fixed, so its global error plateaus (~0.11, set by the fixed phi/z spacing) and its ring-0 error falls at FIRST order in dr; it is a conditioning probe, not a convergence test. Second-order claims are made in Tests 012, 013, 015, 017.",
 "019": "Corrupted coordinates, shapes, dtypes, aliasing, NaN/Inf/huge ghosts and ambiguous start radii must either be rejected before launch or stay confined to their stencil footprint - never produce silently wrong finite output. Includes the start-radius threshold study and the azimuthal-resolution study.",
 "020": "Host-compiled code cannot certify CUDA memory behaviour. Randomised awkward grids run on the real device with canary-guarded outputs, unchanged inputs, untouched ghost layers, host/GPU agreement, and compute-sanitizer memcheck/initcheck/racecheck/synccheck.",
}
PLOT_FILES = []

def make_plots(R, here):
    """Log-log convergence plots with reference slopes (PNG files next to the report). Silent no-op if matplotlib is unavailable."""
    PLOT_FILES.clear()
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except Exception:
        return []
    d = os.path.join(here, "campaign02_plots"); os.makedirs(d, exist_ok=True)
    T = R["tests"]
    def fig(name, title, series, slope, ylabel="max |J - J_ref|", note=None):
        series = {k: v for k, v in series.items() if v and all(e > 0 for e in v[1])}
        if not series: return
        plt.figure(figsize=(6.4, 4.4)); first = None
        for lab, (hs, es) in series.items():
            plt.loglog(hs, es, "o-", lw=1.4, ms=4, label=lab)
            first = first or (hs, es)
        h0, e0 = first[0][0], first[1][0]
        hs = [min(min(v[0]) for v in series.values()), max(max(v[0]) for v in series.values())]
        for p, ls in slope:
            plt.loglog(hs, [e0*(h/h0)**p for h in hs], "k" + ls, lw=1, label=f"slope {p}")
        plt.xlabel("h  (1/nr)"); plt.ylabel(ylabel); plt.title(title, fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=7)
        plt.tight_layout(); p = os.path.join(d, name); plt.savefig(p, dpi=130); plt.close(); PLOT_FILES.append(p)
    h012 = T["012"]["host"].get("fields", {}); s = {}
    for fn, fr in h012.items():
        v = fr.get("16x16x8")
        if v: s[fn] = ([1/r["n"][0] for r in v["rows"]], [max(r["global_"][2], 1e-300) for r in v["rows"]])
    fig("conv_012_axis_Jz.png", "Test 012: global Jz error, axis grids (16x16x8 base)", {k: v for k, v in s.items() if max(v[1]) > 1e-10}, [(2, "--")])
    h013 = T["013"]["host"].get("fields", {}).get("HELICAL KINK (m=1)", {}).get("16x16x8")
    if h013:
        ss = {}
        for c, nmz in enumerate(("Jr", "Jphi", "Jz")):
            ss[f"ring 0 {nmz}"] = ([1/r["n"][0] for r in h013["rows"]], [max(r["ring0"][c], 1e-300) for r in h013["rows"]])
        fig("conv_013_kink.png", "Test 013: helical m=1 kink, first ring", ss, [(2, "--")])
    f15 = T["015"]["host"].get("fourier", {}); ss = {}
    for k, v in f15.items():
        if "[axis]" in k and v["m"] in (2, 3, 4):
            c = 0 if k.startswith("Bz=Re") else 2
            ss[k] = ([1/r["n"][0] for r in v["rows"]], [max(r["errs"][c], 1e-300) for r in v["rows"]])
    fig("conv_015_fourier.png", "Test 015: Fourier modes on axis grids (Jr family A / Jz family B)", ss, [(2, "--")])
    f17 = T["017"]["host"].get("fields", {}); ss = {}
    for fn, fr in f17.items():
        v = fr["grids"].get("annulus r in [0.5,1.5] 16x16x8")
        if v: ss[fn.split(" (")[0] + " Jz"] = ([1/r["n"][0] for r in v["rows"]], [max(r["errs"][2], 1e-300) for r in v["rows"]])
    fig("conv_017_manufactured.png", "Test 017: manufactured cylindrical fields, Jz", ss, [(2, "--")])
    sw = T["018"]["host"].get("spacing_sweep", {})
    if sw:
        f64 = sw["float64"]; f32 = sw["float32"]
        fig("cond_018_spacing.png", "Test 018: radial-spacing sweep (nphi, nz fixed)",
            {"FP64 ring-0 error (first order)": ([r["dr"] for r in f64], [r["ring0_err"] for r in f64]),
             "FP64 global error (plateau: phi/z fixed)": ([r["dr"] for r in f64], [r["max_err"] for r in f64]),
             "FP32 - FP64 (round-off, grows as dr falls)": ([r["dr"] for r in f32], [max(r["fp32_minus_fp64"], 1e-300) for r in f32])},
            [(1, "--"), (-1, ":")], ylabel="error")
    return PLOT_FILES

def table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join("---" for _ in head) + "|"]
    for r in rows: out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out) + "\n"

def legs(t):
    return [(k, t[k]) for k in ("host", "cupy") if k in t]

def build_report(R, here, name="CAMPAIGN02_REPORT.md"):
    env, T, tests = R["env"], R["tolerances"], R["tests"]
    L = []; P = L.append
    verd = {tid: (t["host"].get("verdict"), t["cupy"].get("verdict")) for tid, t in tests.items()}
    gpu_ran = env.get("gpu_present", False)
    all_host = all(v[0] == "PASS" for v in verd.values()); all_gpu = gpu_ran and all(v[1] == "PASS" for v in verd.values())
    certified = bool(all_host and all_gpu and env.get("source_frozen_and_matches"))
    P("# ALADIN v4.0 - Campaign 02 Report")
    P("## Native cylindrical geometry, axis regularity and boundary integrity (tests 011-020)\n")
    P(f"**Certification verdict: {'CERTIFIED - all ten tests PASS on host and GPU' if certified else 'NOT CERTIFIED'}**\n")
    if not certified:
        why = []
        bad = [tid for tid, v in verd.items() if v[0] != "PASS" or (gpu_ran and v[1] not in ("PASS",))]
        if bad: why.append("tests not passing: " + ", ".join(bad))
        if not gpu_ran: why.append("GPU legs BLOCKED in this run (no GPU/CuPy): GPU memory safety is not demonstrated")
        if not env.get("source_frozen_and_matches"): why.append("the kernel source does not match a registered frozen SHA-256")
        P("Reasons: " + "; ".join(why) + ".\n")
    P("Rule applied: *No evidence = no PASS. No PASS = no promotion.*\n")
    P("## 1. Source under test and environment\n")
    P(table(["item", "value"], [
        ["kernel file", f"`{os.path.basename(env['kernel_file'])}` v{env['kernel_version']}"],
        ["**source SHA-256 (as executed)**", f"`{env['kernel_sha256']}`"],
        ["registered SHA-256 for this version (frozen when submitted)", f"`{env['expected_sha256']}`"],
        ["latest registered kernel version", f"v{env.get('latest_registered_version', '?')}" + ("" if env.get("latest_registered_version") == env["kernel_version"] else "  **<- this run used an OLDER kernel (stale package)**")],
        ["source identical to the registered/frozen file", "YES" if env.get("source_frozen_and_matches") else "**NO**"],
        ["campaign02.py SHA-256", f"`{env.get('campaign_harness_sha256', '')}`"],
        ["campaign01.py (shared helpers) SHA-256", f"`{env.get('campaign01_helper_sha256', '')}`"],
        ["run (UTC)", env["utc"]], ["Python / NumPy", f"{env['python']} / {env['numpy']}"], ["platform", env["platform"]], ["host compiler", env["gxx"]],
        ["GPU", env.get("gpu", "none in this run") + (f" (cc {env.get('compute_capability')}, CUDA runtime {env.get('cuda_runtime')}, CuPy {env.get('cupy')})" if env.get("gpu") else "")],
        ["GPU leg", env["gpu_leg_status"]]]))
    P("Host leg = the unmodified CUDA source compiled with g++ and executed on the CPU. It validates the arithmetic and indexing, **not** CUDA/GPU memory behaviour. "
      "GPU leg = the same source launched as a CuPy RawKernel through the module's own launcher.\n")
    P("## 2. Declared criteria (fixed before the run; none changed afterwards)\n")
    P(table(["name", "value"], [[k, f(v) if not isinstance(v, str) else v] for k, v in T.items()]))
    P("## 3. Summary\n")
    P(table(["test", "name", "host", "GPU"], [[tid, t["name"], f"**{verd[tid][0]}**", f"**{verd[tid][1]}**"] for tid, t in tests.items()]))
    if "gpu_vs_host" in R:
        P("### GPU vs host agreement (random fields)\n")
        P(table(["grid", "r_min", "dtype", "max |GPU-host|", "tolerance", ""], [[q["grid"], q["r_min"], q["dtype"], f(q["max_abs_diff"]), f(q["tol"]), "OK" if q["ok"] else "MISMATCH"] for q in R["gpu_vs_host"]]))

    P("## 4. Independent mathematical references\n")
    P("* **Metric**: closed-form cylindrical geometry (face areas r dphi dz / 0.5(r2^2-r1^2) dphi / dr dz, cell volume 0.5(r2^2-r1^2) dphi dz, edge length r dphi) checked against 6-point Gauss-Legendre quadrature of the defining integrals and the Gauss identity (Test 011).")
    P("* **Regular-through-the-axis fields**: defined in *Cartesian* components (uniform, linear shear, quadratic, smooth trigonometric, helical m=1 kink, Fourier modes Re/Im (x+iy)^m); the analytic curl is derived by hand in Cartesian form, converted to (r, phi, z) components, and **each reference is cross-checked against a 6th-order central-difference Cartesian curl** (max differences listed in Tests 012/013/017).")
    P("* **Native cylindrical manufactured fields** M1, M2, M3 (+ the corrected ADV field): curl derived by hand from Jr=(1/r)dBz/dphi-dBphi/dz, Jphi=dBr/dz-dBz/dr, Jz=(1/r)(d(rBphi)/dr-dBr/dphi); each cross-checked against a Cartesian numeric curl of the same field (Test 017).")
    P("* **Discrete reference operators** (footprint/index tests, 014/016/019/020): `campaign01.ref_curl` (annulus) and `campaign02.ref_curl_axis` (axis), both written with multi-dimensional slicing, sharing no index arithmetic with the kernel's flat strides.\n")

    # ---- per test ----
    def verdict_block(tid):
        t = tests[tid]; out = []
        for k, v in legs(t):
            line = f"* **{k}: {v.get('verdict')}**"
            if v.get("fail_reasons"): line += " - " + "; ".join(x[:220] for x in v["fail_reasons"][:6]) + (" ..." if len(v["fail_reasons"]) > 6 else "")
            if v.get("error"): line += "\n```\n" + v["error"][-900:] + "\n```"
            if v.get("note"): line += " - " + v["note"]
            out.append(line)
        return "\n".join(out) + "\n"
    def host(tid): return tests[tid]["host"]

    P("## 5. Test results\n")
    P("*Reading the order columns:* an observed order is the last-pair slope log2(err_h / err_h/2). **round-off-limited** marks a component whose error is at round-off (<= 1e-12 x max(|J_ref|, 1)) at *every* refinement level: its slope is noise, the criterion is met because the discrete result is exact to round-off, and no convergence is claimed for it. `exact` has the same meaning in the per-field summaries. Orders for truncation-limited components must be >= " + str(T["order_min"]) + " (second order).\n")
    P("### 011 Cylindrical metric identities\n"); P("*Purpose.* " + PURPOSE["011"] + "\n"); P(verdict_block("011"))
    h = host("011")
    if "geometry_rows" in h:
        P(table(["grid", "r_min", "dr", "coords err", "area rel", "volume rel", "edge rel", "total volume rel", "Gauss identity"],
                [[r["grid"], r["r_min"], r["dr"], f(max(r["coord_err_Grid"], r["coord_err_make_grid"])), f(r["area_rel_err"]), f(r["volume_rel_err"]), f(r["edge_rel_err"]), f(r["total_volume_rel_err"]), f(r["gauss_identity"])] for r in h["geometry_rows"]]))
        m = h["metric_sensitivity"]
        P(f"Kernel metric response (raw kernel, perturbing one r_center by {f(m['delta'])}): only that radial ring changes = {m['only_that_ring_changed']}; difference to the independent reference evaluated with the same perturbed r_centers = {f(m['max_rel_diff_vs_reference_with_perturbed_r_centers'])}, with perturbed r_faces = {f(m['max_rel_diff_vs_reference_with_perturbed_r_faces'])}.\n")

    P("### 012 Axis regularity\n"); P("*Purpose.* " + PURPOSE["012"] + "\n"); P(verdict_block("012"))
    h = host("012")
    if "fields" in h:
        rows = []
        for fn, fr in h["fields"].items():
            for key, v in fr.items():
                rows.append([fn, key, cells(v["rows"], "ring0", v["ring0_last_orders"]), cells(v["rows"], "global_", v["global_last_orders"]),
                             f(v["rows"][-1]["ring0"][2]), f(v["rows"][-1]["global_"][2]), sum(r["silently_zeroed"] for r in v["rows"])])
        P(table(["field", "base grid", "ring-0 order (Jr,Jphi,Jz)", "global order (Jr,Jphi,Jz)", "finest ring-0 |dJz|", "finest global |dJz|", "silently zeroed cells"], rows))
        P("Reference cross-check (max |hand-derived - Cartesian numeric curl|): " + ", ".join(f"{k}: {f(v)}" for k, v in h["reference_check_max_abs_diff"].items()) + "\n")
        P("Source scan: fixed 1/r guard threshold present in kernel = " + str(h["source_checks"]["guard_threshold_in_kernel"]) + "\n")
        P("FP32 vs FP64 (KINK-poly): " + "; ".join(f"{r['n']}: diff {f(r['diff'])} <= bound {f(r['bound'])}: {r['ok']}" for r in h["fp32_vs_fp64_KINK-poly"]) + "\n")

    P("### 013 Non-axisymmetric m=1 kink\n"); P("*Purpose.* " + PURPOSE["013"] + "\n"); P(verdict_block("013"))
    h = host("013")
    if "fields" in h:
        rows = []
        for fn, fr in h["fields"].items():
            for key, v in fr.items():
                rows.append([fn, key, cells(v["rows"], "ring0", v["ring0_last_orders"]), cells(v["rows"], "ring1", v["ring1_last_orders"]), cells(v["rows"], "global_", v["global_last_orders"]), v["all_ok"]])
        P(table(["field", "base grid", "ring-0 order (Jr,Jphi,Jz)", "ring-1 order", "global order", "all >= " + str(T["order_min"])], rows))
        a = h["axis_ring_transverse_amplitude"]
        P("Transverse axis current |(Jr,Jphi)| (analytic 0.5 eps k = " + f(a["expected_0p5_eps_k"]) + "): " + "; ".join(f"{r['n']}: kernel {f(r['kernel'])}, analytic {f(r['analytic_at_cell_centres'])}, err {f(r['abs_err'])}" for r in a["rows"]) + f"; observed orders {[o(x) for x in a['orders']]}\n")
        P(f"FP32 vs FP64 on the kink: {f(h['fp32_vs_fp64']['diff'])} (bound {f(h['fp32_vs_fp64']['bound'])})\n")

    P("### 014 Radial ghost parity\n"); P("*Purpose.* " + PURPOSE["014"] + "\n"); P(verdict_block("014"))
    h = host("014")
    if "rows" in h:
        P(table(["field", "grid", "parity vs analytic continuation (rel)", "wrong-sign rule differs by (rel)", "bitwise-identical output with analytic / parity / NaN / 1e300 / zero inner ghosts"],
                [[r["field"], r["n"], f(r["parity_vs_analytic_rel"]), f(r["wrong_rule_rel"]), all(r["bitwise_identical_output"].values())] for r in h["rows"]]))
        P(f"Odd nphi=11 (parity mapping phi+pi not on grid): output bitwise independent of NaN inner ghosts = {h['odd_nphi_11']['bitwise_identical_with_NaN_inner_ghosts']}, finite = {h['odd_nphi_11']['finite']}. "
          f"Axis face Br(r=0) is consumed by ring 0 only (perturbation sin(2 phi): ring-0 change {f(h['axis_face_is_consumed']['change_ring0'])}, rings >= 2 change {f(h['axis_face_is_consumed']['change_rings_ge2'])}).\n")
        P("Parity rule used: Br(-r,phi)=-Br(r,phi+pi), Bphi(-r,phi)=-Bphi(r,phi+pi), Bz(-r,phi)=Bz(r,phi+pi). The kernel never reads inner radial ghosts in axis mode, so the rule is a *driver-side* contract that this test validates; the kernel result is invariant to it.\n")

    P("### 015 Periodic azimuthal closure\n"); P("*Purpose.* " + PURPOSE["015"] + "\n"); P(verdict_block("015"))
    h = host("015")
    if "fourier" in h:
        P(table(["field", "orders (Jr,Jphi,Jz)", "all >= " + str(T["order_min"]) + " or exact"], [[k, cells(v["rows"], "errs", v["last_orders"]), all(v["ok"])] for k, v in h["fourier"].items()]))
        for tag, s in h["seam"].items():
            P(f"* {tag}: m=3 seam-cell error {f(s['m3_seam_error'])} vs interior {f(s['m3_interior_error'])}; independent periodic wrap vs analytic ghosts: {f(s['m3_periodic_wrap_vs_analytic_ghosts_rel_diff'])}; "
              f"sensitivity (wrong-closure effect / correct seam error {f(s['m1_correct_closure_seam_error'])}): " + ", ".join(f"{k} x{f(v, 2)}" for k, v in s["wrong_closure_effect_over_good_error"].items()))
        P("")
        for tag, s in h["rotation"].items(): P(f"* rotation covariance ({tag}): max relative difference " + f(max(r["max_rel_diff"] for r in s["rows"])) + " over shifts " + str([r["k"] for r in s["rows"]]))
        P("")

    P("### 016 Yee staggered geometry\n"); P("*Purpose.* " + PURPOSE["016"] + "\n"); P(verdict_block("016"))
    h = host("016")
    if "grids" in h:
        P(table(["grid (nr,nphi,nz)", "g", "mode", "coord/trig err", "axis flag ok", "validator", "random-field diff", "impulse probes", "off-by-one extents rejected"],
                [[r["grid"], r["g"], r["mode"], f(max(r["rf_err"], r["rc_err"], r["make_grid_err"], r["axis_inputs_err"])), r["axis_flag"] == r["expected_axis_flag"], "accepts" if r["validator_accepts"] else "rejects",
                  f(r.get("random_field_rel_diff")), (str(len(r["impulses"])) + " / fail " + str(r["impulse_failures"])) if "impulses" in r else "-", f"{r['off_by_one_extent_rejected']} ({r['off_by_one_cases']})"] for r in h["grids"]]))

    P("### 017 Cylindrical manufactured solutions\n"); P("*Purpose.* " + PURPOSE["017"] + "\n"); P(verdict_block("017"))
    h = host("017")
    if "fields" in h:
        rows = []
        for fn, fr in h["fields"].items():
            for key, v in fr["grids"].items():
                rows.append([fn.split(" (")[0], key, cells(v["rows"], "errs", v["last_orders"]), f(v["rows"][-1]["errs"][0]) + " / " + f(v["rows"][-1]["errs"][1]) + " / " + f(v["rows"][-1]["errs"][2]), f"{f(v['fp32_vs_fp64']['diff'])} <= {f(v['fp32_vs_fp64']['bound'])}"])
        P(table(["field", "configuration", "observed order (last pair: Jr,Jphi,Jz)", "finest-grid errors (Jr/Jphi/Jz)", "FP32-FP64 diff vs bound"], rows))
        P("Reference cross-check (hand-derived vs Cartesian numeric curl, relative): " + ", ".join(f"{k.split(' (')[0]}: {f(max(v['reference_check']))}" for k, v in h["fields"].items()) + "\n")

    P("### 018 Near-axis numerical conditioning\n"); P("*Purpose.* " + PURPOSE["018"] + "\n"); P(verdict_block("018"))
    h = host("018")
    if "spacing_sweep" in h:
        for dt, rows in h["spacing_sweep"].items():
            P(f"**{dt}**, axis grid, radial spacing sweep (declared bound = {T['cond_trunc']:g}(dr^2+dz^2+(r_c dphi)^2) Jscale + 64 eps Bmax/hmin):\n")
            P(table(["nr", "dr", "max err", "ring-0 err", "declared bound", "FP32-FP64 (round-off)", "round-off bound", "ok"], [[r["nr"], f(r["dr"]), f(r["max_err"]), f(r["ring0_err"]), f(r["bound"]), f(r["fp32_minus_fp64"]) if r["fp32_minus_fp64"] is not None else "-", f(r["fp_bound"]) if r["fp32_minus_fp64"] is not None else "-", r["ok"]] for r in rows]))
        P(f"FP64 ring-0 observed orders along the sweep: {[o(x) for x in h['fp64_orders_ring0']]}. Total FP32 error is truncation-dominated on this sweep (nphi, nz fixed), so it does not show round-off; the pure round-off (FP32 minus FP64 of the same problem) is the column above: " + ", ".join(f(x) for x in h["fp32_roundoff_growth"]["values"]) + " for nr = 8..2048 (it grows as dr shrinks and always stays under the declared 64 eps Bmax/hmin bound). Use FP64 for fine near-axis grids.\n")
        P("Amplitude sweep (FP32; finite outputs must be accurate; non-finite only where overflow is justified):\n")
        P(table(["scale", "non-finite cells", "overflow justified", "max err (finite cells)", "bound", "ok"], [[f"{r['scale']:g}", r["nonfinite_cells"], r["overflow_justified"], f(r["max_err_finite_cells"]), f(r["bound"]), r["ok"]] for r in h["amplitude_sweep"]]))
        P("Annulus start-radius sweep (field regular across the axis; 32x16x8):\n")
        P(table(["r_min / dr", "max err", "declared bound", "ok"], [[r["r_min_over_dr"], f(r["max_err"]), f(r["declared_bound"]), r["ok"]] for r in h["rmin_sweep"]]))

    P("### 019 Boundary adversarial mutation\n"); P("*Purpose.* " + PURPOSE["019"] + "\n"); P(verdict_block("019"))
    h = host("019")
    if "validator_cases" in h:
        vc = h["validator_cases"]; P(f"Validator mutation cases: {len(vc)} total, {sum(r['ok'] for r in vc)} rejected with `CurlContractError` as required; unexpected exception types: {sum(r['outcome'].startswith('UNEXPECTED') for r in vc)}.\n")
        if any(not r["ok"] for r in vc): P(table(["grid", "mutation", "outcome"], [[r["grid"], r["mutation"], r["outcome"]] for r in vc if not r["ok"]]))
        nc = h["nonfinite_confinement"]; P(f"NaN/Inf injection: {len(nc)} cases (ghost and interior, annulus and axis); output non-finite pattern equals the independent reference footprint and all other cells unchanged in {sum(r['ok'] for r in nc)}/{len(nc)}. "
                                           f"Huge-finite (1e300) ghost: " + "; ".join(f"{r['grid']}: footprint matches = {r['footprint_matches']}" for r in h["huge_finite_ghost"]) + "\n")
        P("Start-radius contract, declared rule: accept r_faces[g] = 0 (axis) or >= " + f(T["tiny_rmin_fraction"]) + "*dr (annulus); reject 0 < r_faces[g] < " + f(T["tiny_rmin_fraction"]) + "*dr and any r_faces[g] < 0 (grid straddling the axis).\n")
        P(table(["r_min / dr", "must reject", "validator", "max error if run (SMOOTH 16x16x8)", "meets declared rule"], [[r["r_min_over_dr"], r["must_reject"], "accepts" if r["validator_accepts"] else "rejects", f(r["err_if_run"]), r["ok"]] for r in h["tiny_rmin"]]))
        P("Axis grids with too few azimuthal cells (declared minimum 3):\n")
        P(table(["nphi", "validator", "error vs analytic if run", "meets declared rule"], [[r["nphi"], "accepts" if r["validator_accepts"] else "rejects", f(r["err_vs_analytic"]), r["ok"]] for r in h["low_nphi_axis"]]))
        if "threshold_study" in h:
            ts = h["threshold_study"]
            P("**Threshold study for the 0.001*dr policy constant.** The value is a policy choice, not a mathematical constant. Evidence: (i) the decision follows the declared rule on both sides of the boundary; "
              "(ii) the annulus-stencil error is the same (~1e-1) for every start radius from 1e-16 to 1 times dr, so accuracy shows **no cliff** that would single out another number - the only physics-free justification is identifiability; "
              f"(iii) the worst round-off residual of the FP64 constructions of r_faces[g] tried (arange, cumsum, linspace, shifted origin; g=2..3, nr=16..4096) is {f(ts['noise_residual_over_dr_worst_float64_constructions'])}*dr, so the threshold clears it by {f(T['tiny_rmin_fraction']/ts['noise_residual_over_dr_worst_float64_constructions'], 2)}x (required >= {f(ts['noise_margin_required'])}x). "
              "Radii that were rounded through float32 are NOT noise-free (they land inside the rejected band by design).\n")
            P(table(["r_min / dr", "validator accepts", "expected", "annulus-stencil error", "axis-mode error (same dr)", "ok"], [[r["r_min_over_dr"], r["validator_accepts"], r["expected_accepts"], f(r["err_annulus_stencil"]), f(r["err_axis_mode_same_dr"]), r["ok"]] for r in ts["rows"]]))
        if "azimuthal_resolution_study" in h:
            P("Azimuthal resolution study (informational): `nphi >= 3` is only a validity guard (sin(dphi) != 0). It is **not** evidence that 3 cells resolve an m=1 mode:\n")
            P(table(["nphi", "transverse axis-current amplitude rel. error", "max |Jz error|"], [[x["nphi"], f(x["amplitude_rel_err"]), f(x["max_err_Jz"])] for x in h["azimuthal_resolution_study"]["rows"]]))
        if "device_rejection_leaves_outputs_untouched" in tests["019"].get("cupy", {}):
            P("Device launcher: rejected calls leave outputs untouched: " + "; ".join(f"{u['mutation']}: {u['ok']}" for u in tests["019"]["cupy"]["device_rejection_leaves_outputs_untouched"]) + "\n")

    P("### 020 GPU geometry safety\n"); P("*Purpose.* " + PURPOSE["020"] + "\n"); P(verdict_block("020"))
    for k, v in legs(tests["020"]):
        if "random_grids" in v:
            rg = v["random_grids"]
            P(f"**{k} leg**: {len(rg)} randomized grids (annulus + axis, g=1..3, FP32/FP64, awkward sizes); guarded output buffers (canary padding), inputs unchanged, J ghost layers untouched, all active cells written, finite, matches independent reference"
              + (", matches host" if k == "cupy" else "") + f": {sum(bool(r.get('ok')) for r in rg)}/{len(rg)} OK.\n")
            P(table(["grid", "g", "r_min", "dtype", "canary", "ghosts untouched", "diff vs reference", "GPU vs host" if k == "cupy" else "", "ok"],
                    [[r["grid"], r["g"], r["r_min"], r["dtype"], r.get("canary_intact", "-"), r.get("ghost_layers_untouched", "-"), f(r.get("rel_diff_vs_independent_reference")), f(r.get("gpu_vs_host_rel_diff")) if k == "cupy" else "", r["ok"]] for r in rg]))
        if "host_addresssanitizer" in v:
            a = v["host_addresssanitizer"]; P(f"Host AddressSanitizer on the same grid family: {sum(x['clean'] for x in a)}/{len(a)} clean. {v['scope_note']}\n")
        if "compute_sanitizer" in v:
            s = v["compute_sanitizer"]
            if s["status"] == "BLOCKED": P("compute-sanitizer: **BLOCKED** - " + s["note"] + "\n")
            else: P("compute-sanitizer (`" + s["tool"] + "`, raw non-pooled allocations): " + "; ".join(f"{t}: {'clean' if r.get('clean') else 'PROBLEMS'} (errors={r.get('error_summary')}, target completed={r.get('target_done')})" for t, r in s["runs"].items()) + "\n")
    if not gpu_ran:
        P("**GPU memory safety is NOT demonstrated in this run** (no GPU). It cannot be inferred from the host AddressSanitizer leg.\n")

    plots = make_plots(R, here)
    if plots:
        P("### Convergence plots (log-log, dashed lines = reference slopes)\n")
        for pth in plots: P(f"![{os.path.basename(pth)}](campaign02_plots/{os.path.basename(pth)})\n")
    P("## 6. FP32 / FP64 comparison\n")
    P("FP32 differences against FP64 appear in Tests 012, 013, 017 (bound = 64 eps32 Bmax / hmin) and 018 (spacing and amplitude sweeps, round-off vs truncation split); FP32 is accepted only inside the declared bound. "
      "Near the axis the round-off term grows like 1/h under refinement, so the FP32 error stops improving and eventually worsens; this is quantified in Test 018.\n")

    P("## 7. Failures, defects found, required corrections\n")
    fails = []
    for tid, t in tests.items():
        for k, v in legs(t):
            for r in v.get("fail_reasons", []) or []: fails.append((tid, k, r))
            if v.get("verdict") == "ERROR": fails.append((tid, k, "harness error: " + v.get("error", "")[-300:]))
    if not fails: P("(none)\n")
    else:
        P(table(["test", "leg", "finding"], [[a, b, c[:260]] for a, b, c in fails]))
    kinds = " ".join(c for _, _, c in fails)
    if "start radius" in kinds or "threshold study" in kinds:
        P("**Defect D8 / D10 (validator contract).** A start radius `0 < r_faces[g] << dr` is not recognised as an axis (axis mode needs `r_faces[g] == 0` exactly) and is not rejected, so the less accurate annulus stencil runs silently (error 1.09e-1 on 16x16x8). "
          "A radius produced by round-off (1e-17 from `r0 + k*dr`) selects it. D10: a grid with `-0.5 dr < r_faces[g] < 0` straddles the axis yet passes the `r_centers > 0` check (error up to 4.4).\n")
    if "nphi=" in kinds:
        P("**Defect D9 (validator contract).** The axis closure divides by `2 r sin(dphi)`; with `nphi` = 1 or 2 the result is meaningless (error 5.7 / 0.35) yet the grid is accepted.\n")
    P("Per the campaign rule the source under test is **not** edited during a campaign; a correction is a new version that must pass Campaigns 01 and 02 afresh (see 7b).\n")
    P("### 7b. Version history of this campaign\n")
    P(table(["version", "sha256 (prefix)", "Campaign 02 outcome", "notes"], [
        ["v1.2 (preserved as `uct_curl_v02.py`)", "820fedf8...", "9/10 PASS host and GPU (L4); **019 FAIL** (D8, D9)", "first Campaign 02 run; the extended 019 (negative start radii, threshold study) re-run on v1.2 additionally exposes D10"],
        ["v1.3 (`uct_curl.py`)", "e7b25907...", "see section 3 of this report", "validator-only change: start-radius contract (D8, D10) and axis nphi >= 3 (D9); the CUDA source string is byte-identical to v1.2, so numerical results of valid grids are unchanged (checked by the regression leg of Campaign 01)"]]))

    P("## 8. Harness corrections made while building this campaign (no tolerance value was changed)\n")
    P("During harness development, before the first complete run, these *harness* defects were found and fixed. They are listed for transparency; the declared numeric criteria in section 2 were not altered.\n")
    P(table(["item", "what changed", "why"], [
        ["`ref_curl_axis` phi-cubic range", "Cartesian conversion now covers phi cells 1..npg-2 (was 1..npg-3)", "reference produced NaN in the last azimuthal cell; found by the Test 016 impulse probes"],
        ["NaN-safe comparisons", "all kernel/reference comparisons use `nmax`, which returns +inf on NaN", "np.max with NaN made `err > tol` silently False"],
        ["013 amplitude check", "fixed 2% comparison replaced by second-order convergence of the amplitude error", "2% was not tied to resolution (the 32x32x16 error is truncation, 2.6%); the per-point order tests were unaffected"],
        ["015 seam sensitivity", "sensitivity measured with Bz=0.6x+0.8y (neither even nor odd at phi=0) on 48 phi-cells, relative to the correct-closure seam error", "the first design compared truncation-dominated errors and Bz=x is even at phi=0 so an edge-copy closure is exactly correct there"],
        ["comp_rule zero reference", "scale floored at 1 when the exact J is identically 0", "relative tolerance is undefined for J_ref = 0 (Fourier family B, m=1)"],
        ["019 footprint reference", "changed-cell set computed as reference(bad) vs reference(clean)", "was compared against kernel(clean), differing at round-off everywhere"],
        ["campaign02.py SHA field", "harness fingerprint now searched in several locations and flagged UNKNOWN if the file cannot be found", "the first L4 report printed an empty value"],
        ["019 extended after the v1.2 run", "added negative start radii, the threshold study and the azimuthal resolution study; new declared key noise_margin = 100", "requested by the review: the 0.001*dr constant needed evidence; declared after seeing the v1.2 failure and before any v1.3 result; the rejection rule itself is unchanged"]]))

    P("## 9. Requirement checklist\n")
    P(table(["requirement", "status"], [
        ["All 10 tests PASS with documented measurements", "YES" if certified else "NO (see section 3)"],
        ["Second-order claims backed by measured convergence (>= 3 levels, last-pair order)", "Tests 012, 013, 015, 017: four-level refinement on two base grids"],
        ["Non-axisymmetric axis tests (not only Z-pinch)", "Tests 012-015, 017: uniform, shear, quadratic, SMOOTH, helical m=1 kink, Fourier m=1..4"],
        ["GPU memory safety demonstrated, not inferred", "YES (guarded buffers + compute-sanitizer memcheck/initcheck/racecheck/synccheck)" if (gpu_ran and verd.get("020", (0, 0))[1] == "PASS") else "NO - not demonstrated in this run"],
        ["No tolerance changed after seeing results", "Declared criteria unchanged; harness corrections listed in section 8"],
        ["kernel source frozen and registered", "YES (SHA-256 matches the registered file)" if env.get("source_frozen_and_matches") else "NO - SHA mismatch"]]))
    P("## 10. Reproducibility package\n")
    try:
        import matplotlib as _mpl; mpl = _mpl.__version__
    except Exception: mpl = "not installed (plots skipped)"
    P(table(["item", "value"], [
        ["exact command", "`python campaign01.py` then `python campaign02.py` (same folder; Colab: `!python campaign02.py`)"],
        ["kernel", f"`uct_curl.py` v{env['kernel_version']}, SHA-256 `{env['kernel_sha256']}`"],
        ["harness", f"`campaign02.py` SHA-256 `{env.get('campaign_harness_sha256', '')}`; shared helpers `campaign01.py` SHA-256 `{env.get('campaign01_helper_sha256', '')}`"],
        ["dependencies", f"Python {env['python']}, NumPy {env['numpy']}, g++ ({env['gxx']}), matplotlib {mpl}" + (f", CuPy {env.get('cupy')}, CUDA runtime {env.get('cuda_runtime')}, GPU {env.get('gpu')}" if env.get("gpu") else ", no GPU in this run")],
        ["machine-readable results", "`campaign02_results.json` (every number in this report is generated from it)"],
        ["report", "`CAMPAIGN02_REPORT.md` + `campaign02_plots/*.png`"],
        ["randomness", "fixed seeds in every test (e.g. 16, 17, 19, 20, 77); results are repeatable"],
        ["archival", "keep together: this report, the JSON, the plots, the zip (record its SHA-256) and the console log"]]))
    P("## 11. Limitations and qualifications\n")
    P("* **L1**: finite but wrong ghost or boundary values cannot be detected by any kernel that consumes them; the contract places that responsibility on the driver. Test 019 proves only that NaN/Inf/huge values are confined to, and propagate through, the stencil footprint.")
    P("* The kernel reconstructs J = curl(B) (mu0 = 1, caller divides once); it is not the Faraday/CT update, which is a separate unbuilt kernel.")
    P("* Campaign 01's independent source-level review is still pending; this campaign does not assume it is complete.")
    P("* FP32 near the axis: round-off grows with refinement (Test 018); FP64 recommended for fine near-axis grids.")
    P("* The axis face Br(r=0) must be supplied by the driver (Test 014).\n")
    text = "\n".join(L)
    try:
        open(os.path.join(here, name), "w", encoding="utf-8").write(text)
    except Exception:
        pass
    return text
