# -*- coding: utf-8 -*-
"""Report builder for ALADIN v4.0 Campaign 05 (tests 041-050).  Contract: build_report(R, here, name) -> markdown text (also written to here/name).
R = results dict written by campaign05.py (campaign05_results.json).  Every number in the report comes from R; the prose states what each test claims and what it does NOT claim."""
import os, math

def f(x, p=3):
    if x is None: return "n/a"
    try:
        if isinstance(x, bool): return str(x)
        if isinstance(x, str): return x
        if math.isnan(x): return "nan"
        if math.isinf(x): return "inf" if x > 0 else "-inf"
        if x == 0: return "0"
        return f"{x:.{p}e}" if (abs(x) < 1e-3 or abs(x) >= 1e5) else f"{x:.{p+1}g}"
    except Exception:
        return str(x)

def o(x):
    if x is None or (isinstance(x, float) and math.isnan(x)): return "n/a"
    if isinstance(x, float) and math.isinf(x): return "exact"
    return f"{x:.2f}"

def olist(xs): return ", ".join(o(x) for x in xs) if xs else "n/a"
def tbl(head, rows):
    esc = lambda c: str(c).replace("|", "\\|").replace("\n", " ")
    out = ["| " + " | ".join(esc(c) for c in head) + " |", "|" + "|".join("---" for _ in head) + "|"]
    for r in rows: out.append("| " + " | ".join(esc(c) for c in r) + " |")
    return "\n".join(out)
def v(e, be): return e.get(be, {}).get("verdict", "n/a")
def last(xs): return xs[-1] if xs else None
def short(s, n=26): return s if len(s) <= n else s[:n - 1] + "~"

PURPOSE = {
 "041": "Compatible discrete gradients (B = grad psi, exact potentials incl. m = 1,2,3 non-axisymmetric modes) are fed to the kernel on annulus and axis grids in FP32/FP64. A DEC curl built here from circulations on the dual faces is the compatible yard-stick (d.d = 0); the kernel's reconstruction curl is NOT assumed to annihilate gradients - the residual, its closed form (annulus), orders and round-off floors are measured.",
 "042": "The independent cylindrical divergence of the kernel's current (wide centred and finite-volume) is compared with the DEC node divergence (identically zero for a compatible complex), the closed forms of Campaign 03, and analytic div J = 0 for smooth fields, including the first interior ring and the boundary flux.",
 "043": "Bessel force-free fields B = (0, J1(alpha r), J0(alpha r)) (alpha = 2, 3.8317 = first zero of J1, 5.5) and non-axisymmetric Chandrasekhar-Kendall fields (m = 0, 1, 2). J - alpha B is evaluated with B at the analytic cell centres (where J lives); a mislocated oracle is a control. Profiles, axis behaviour, orders, residual force J x B.",
 "044": "E_H = eta_H (J x B) with kernel J and face-averaged B_cc against the analytic cylindrical cross product at the same centres (pinch, screw, reversal, CK m=1, SMOOTH, KINK, helical m=2). Components, signs, alignment, E.B leakage; error split into the J part and the B-interpolation part; SI-unit mu0 test; negative controls (missing / doubled 1/mu0, wrong stagger, reversed cross product, mislocated J).",
 "045": "eta |J|^2 from the kernel current for positive, zero, spatially varying and compact-support eta: non-negativity cell by cell, exact zero where eta = 0, second-order agreement with analytic eta|J|^2 and with Gauss-Legendre volume integrals; magnetic energy integral; negative-eta control. No full-system energy conservation is inferred.",
 "046": "Z-pinch B_phi = a r (a = 0.5): J_z = 2a and (J x B)_r = -2 a^2 r; screw and Gaussian pinches with force-balanced pressure. Pointwise force error, axis regularity, convergence, current-form pressure-force residual; a conservative-form Maxwell-stress balance (harness reference) shows what a different discretisation of the same equilibrium preserves; the real driver's ScienceManager is evaluated on real driver states; time-stepped equilibrium is BLOCKED.",
 "047": "Pinch + solenoidal helical perturbations m = 1, 2, 3 with three (k, eps, phase) sets each, all three current components against hand-derived Cartesian derivatives; azimuthal DFT on a fixed-radius ring: amplitude, phase, complex error, leakage; ring-0 absolute error on axis grids.",
 "048": "Five refinement levels jointly and along r, phi, z independently, ten held-out extreme aspect-ratio grids (up to ~200:1 cells): L1/L2/Linf, observed orders, axis versus interior, conditioning kappa; an additive error law e = A_r h_r^2 + A_phi h_phi^2 + A_z h_z^2 fitted on calibration grids must predict the held-out grids. CPU/GPU agreement never enters the verdict.",
 "049": "Checkerboard modes exactly invisible to J (Campaign 03/04 null space) are added at three amplitudes; the Hall EMF and Lorentz force are compared with the clean analytic references, with the exact identity dE = eta[J x dB_cc + dJ x B_cc], and with the DEC current of the pure pattern (the 'high-resolution / compatible' reference). Axis grids are reported separately.",
 "050": "Integration against the REAL, unmodified driver objects (geometry, grid, registry, boundary manager, science manager, execution controller): component inventory (stubs are BLOCKED), shape / location / units contracts, immutability, determinism, ghost ownership with the driver's own boundary manager, CPU/GPU agreement, source hashes, and the complete Campaign 01-04 regression incl. the three preserved non-discriminating FP32 metric cases.",
}
PLOT_FILES = []

def make_plots(R, here):
    PLOT_FILES.clear()
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except Exception:
        return []
    d = os.path.join(here, "campaign05_plots"); os.makedirs(d, exist_ok=True); T = {k: e["host"] for k, e in R["tests"].items() if "host" in e}
    def save(name):
        p = os.path.join(d, name); plt.tight_layout(); plt.savefig(p, dpi=130); plt.close(); PLOT_FILES.append(p)
    def safe(fn):
        try: fn()
        except Exception as ex: plt.close("all")
    def p041():
        plt.figure(figsize=(6.6, 4.5))
        for e in T["041"]["convergence"]:
            if e["dtype"] == "float64" and e["mode"] == "annulus" and e["psi"].startswith(("psi_m1", "psi_m2")) or (e["dtype"] == "float64" and e["mode"] == "axis" and e["psi"].startswith("psi_m1")):
                h = [r["h"] for r in e["rows"]]; plt.loglog(h, [max(r["region_Linf"], 1e-18) for r in e["rows"]], "o-", label=f"{e['mode']} {short(e['psi'], 18)}")
        h = [r["h"] for r in T["041"]["convergence"][0]["rows"]]; plt.loglog(h, [x**2*h[0]**-2*0.05 for x in h], "k--", label="h^2")
        plt.xlabel("h"); plt.ylabel("max |curl(grad psi)| (region)"); plt.legend(fontsize=6); plt.title("041: kernel curl of compatible gradients (DEC curl = round-off)"); save("t041_curl_grad.png")
    def p043():
        plt.figure(figsize=(6.6, 4.5))
        for e in T["043"]["cases"]:
            if e["mode"] == "annulus": plt.loglog([r["h"] for r in e["rows"]], [r["region"]["Linf"] for r in e["rows"]], "o-", label=short(e["field"], 24))
        plt.xlabel("h"); plt.ylabel("max |J - alpha B| (region)"); plt.legend(fontsize=6); plt.title("043: force-free fields, annulus"); save("t043_beltrami.png")
        plt.figure(figsize=(6.6, 4.5)); e = T["043"]["cases"][2 if len(T["043"]["cases"]) > 2 else 0]; p = e["profile"]
        plt.plot(p["r"], p["Jz"], "o", ms=3, label="kernel Jz"); plt.plot(p["r"], p["alphaBz"], "-", label="alpha Bz (analytic)"); plt.plot(p["r"], p["Jphi"], "s", ms=3, label="kernel Jphi"); plt.plot(p["r"], p["alphaBphi"], "-", label="alpha Bphi")
        plt.xlabel("r"); plt.title(f"043: radial profile, {short(e['field'], 30)} ({e['mode']})"); plt.legend(fontsize=7); save("t043_profile.png")
    def p044():
        plt.figure(figsize=(6.6, 4.5))
        for e in T["044"]["cases"]:
            if e["mode"] == "annulus": plt.loglog([max(r["grid"][0], 1) for r in e["rows"]], [max(r["region"]["Linf"], 1e-18) for r in e["rows"]], "o-", label=short(e["field"], 22))
        plt.xlabel("nr (joint refinement)"); plt.ylabel("max |E_H - E_ref| (region)"); plt.legend(fontsize=6); plt.title("044: Hall EMF error, annulus"); save("t044_hall.png")
    def p046():
        plt.figure(figsize=(6.6, 4.5))
        for e in T["046"]["cases"]:
            if e["mode"] == "annulus": plt.loglog([r["grid"][0] for r in e["rows"]], [max(r["conservative_stress_residual_region"], 1e-18) for r in e["rows"]], "o-", label="cons. stress " + short(e["field"], 14)); plt.loglog([r["grid"][0] for r in e["rows"]], [max(r["pressure_force_residual_region"], 1e-18) for r in e["rows"]], "s--", label="current form " + short(e["field"], 14))
        plt.xlabel("nr"); plt.ylabel("radial force-balance residual (region)"); plt.legend(fontsize=6); plt.title("046: equilibrium defect by discretisation form"); save("t046_equilibrium.png")
    def p047():
        plt.figure(figsize=(6.6, 4.5))
        for e in T["047"]["cases"]:
            if e["mode"] == "annulus" and e["eps"] == 0.3: plt.loglog([r["grid"][0] for r in e["rows"]], [max(x, 1e-18) for x in e["harmonic_Jz"]["complex_err"]], "o-", label=f"m={e['m']} k={e['k']:.1f}")
        plt.xlabel("nr"); plt.ylabel("complex harmonic error of Jz (scaled)"); plt.legend(fontsize=7); plt.title("047: harmonic amplitude+phase error, annulus"); save("t047_harmonics.png")
    def p048():
        plt.figure(figsize=(6.6, 4.5)); e = T["048"]["cases"][0]
        for k, s in e["series"].items(): plt.loglog([r["grid"][0]*r["grid"][1]*r["grid"][2] for r in s], [max(r["region"]["Linf"], 1e-18) for r in s], "o-", label=k)
        plt.xlabel("number of cells"); plt.ylabel("region Linf error"); plt.legend(fontsize=7); plt.title(f"048: {short(e['field'], 20)} {e['mode']} - independent and joint refinement"); save("t048_aniso.png")
        plt.figure(figsize=(6.6, 4.0))
        for e in T["048"]["cases"]: plt.plot(range(len(e["extreme_predictions"])), [x["ratio_obs_over_pred"] for x in e["extreme_predictions"]], "o-", label=f"{short(e['field'], 12)} {e['mode']}")
        plt.axhline(1, color="k", lw=0.5); plt.xlabel("held-out extreme grid #"); plt.ylabel("observed / predicted error"); plt.legend(fontsize=6); plt.title("048: additive error law on held-out grids"); save("t048_model.png")
    def p049():
        plt.figure(figsize=(6.6, 4.5)); rows = [r for r in T["049"]["rows"] if r["dtype"] == "float64" and r["field"].startswith("SMOOTH")]
        for pn in sorted({r["pattern"] for r in rows}):
            rr = [r for r in rows if r["pattern"] == pn]; plt.loglog([r["amp_rel"] for r in rr], [max(r["dE_region_Linf"], 1e-18) for r in rr], "o-", label="dE " + short(pn, 26))
        plt.axhline(rows[0]["clean_truncation_err"], color="k", ls=":", label="clean truncation error"); plt.xlabel("pattern amplitude / Bmax"); plt.ylabel("Hall EMF change (region Linf)"); plt.legend(fontsize=6); plt.title("049: Hall response to J-invisible modes"); save("t049_hall_nullspace.png")
    for fn in (p041, p043, p044, p046, p047, p048, p049): safe(fn)
    return PLOT_FILES

def build_report(R, here, name="CAMPAIGN05_REPORT.md"):
    env, T, cert, TL, gate = R["env"], R["tests"], R["certification"], R["tolerances"], R["exit_gate"]
    plots = make_plots(R, here); L = []; A = L.append; reg = R.get("register", [])
    A("# ALADIN v4.0 - Campaign 05 report (Tests 041-050)")
    A("**Production adversarial validation of `uct_curl.py` as the current-density operator of ALADIN's Hall-MHD system**\n")
    A(f"**Harness verdict: {cert['verdict']}**  \n{cert['detail']}.  \nCertification rule: *{cert['rule']}*.  ")
    A("This is the harness's own verdict; independent source-level certification of the frozen code and of this harness is still pending.\n")
    A("> Inspector's question: is UCT_CURL merely numerically well-behaved in isolation, or trustworthy as the current-density operator of the Hall-MHD driver? Finite output and CPU/GPU agreement are never evidence: every verdict is decided against an INDEPENDENT oracle (ANALYTIC, EXACT-DISCRETE or DEC, named in every table). The kernel computes **J = curl(B)** (mu0 = 1) by cell-centred reconstruction; it is **not** the Faraday CT update. A PASS that characterises a limitation is never evidence that the limitation is gone.\n")
    A("## 1. Source, environment, frozen hashes")
    A(tbl(["item", "value"], [["kernel file / version", f"{os.path.basename(env['kernel_file'])} v{env['kernel_version']}"], ["kernel SHA-256", f"`{env['kernel_sha256']}`"], ["registered (frozen) SHA-256", f"`{env['expected_sha256']}`"], ["source frozen and matches", env["source_frozen_and_matches"]],
        ["campaign05.py SHA-256", f"`{env['campaign_harness_sha256']}`"], ["helper SHA-256 (campaign01 / 02 / 03 / 04)", " / ".join(f"`{env['helper_shas'][k][:16]}`" for k in ("campaign01", "campaign02", "campaign03", "campaign04"))],
        ["helpers equal the registered package", all(env["helper_shas"][k] == env["registered_shas"][k] for k in env["helper_shas"])], ["driver (unmodified, read-only)", f"{env.get('driver_available')}  `{env.get('driver_sha256')}`"],
        ["driver import side effect blocked by the harness", str(env.get("driver_import_pip_blocked"))], ["seeds", str(env.get("seeds"))], ["UTC", env["utc"]], ["python / numpy / scipy", f"{env['python']} / {env['numpy']} / {env.get('scipy')}"], ["platform", env["platform"]], ["g++", env["gxx"]],
        ["GPU", env.get("gpu", "none")], ["CuPy / CUDA runtime / compute capability", f"{env.get('cupy', 'n/a')} / {env.get('cuda_runtime', 'n/a')} / {env.get('compute_capability', 'n/a')}"], ["GPU leg", env["gpu_leg_status"]]]))
    A("\n## 2. Declared criteria (fixed before execution)")
    A(tbl(["name", "value"], [[k, str(val)] for k, val in TL.items()]))
    A("\n## 3. Summary and exit gate")
    A(tbl(["test", "name", "host", "GPU", "dispositions (register classes)"], [[t, e["name"], v(e, "host"), v(e, "cupy"), ", ".join(gate["dispositions"].get(t, [])) or "none"] for t, e in T.items()]))
    A(f"\nTarget **10/10**. PASS on every backend: **{gate['tests_pass_both_backends']}/10**; BLOCKED: **{gate['tests_blocked']}**; FAIL: **{gate['tests_failed']}**. Every test has an explicit disposition: **{gate['every_test_has_disposition']}**. Open BLOCKER entries: {', '.join(gate['open_blockers']) or 'none'}.")
    A("\n**A BLOCKED test is not a PASS.** Test 050 is BLOCKED because the real components it must integrate with do not exist in the supplied driver; nothing was stubbed in their place. Required accuracy / integration checks that cannot execute prevent full certification.\n")
    if "gpu_vs_host" in R:
        A("### GPU vs host agreement (informational; never a verdict)"); A(tbl(["grid", "r_min", "dtype", "max abs diff", "tol", "ok"], [[q["grid"], q["r_min"], q["dtype"], f(q["max_abs_diff"]), f(q["tol"]), q["ok"]] for q in R["gpu_vs_host"]]))
    elif not env["gpu_present"]:
        A("> **GPU leg: BLOCKED in this execution (no GPU/CuPy).** Nothing is inferred for the GPU from the host results; run the identical harness on a real GPU.\n")
    A("## 4. Per-test results (host leg unless stated; the GPU leg runs identical code)")
    for t, e in T.items():
        h = e["host"]; A(f"### Test {t} - {e['name']}  [host {v(e,'host')} | GPU {v(e,'cupy')}]"); A(f"*Purpose.* {PURPOSE.get(t, '')}\n")
        if h.get("verdict") == "ERROR": A("```\n" + str(h.get("error", ""))[-1500:] + "\n```")
        for be in ("host", "cupy"):
            for fr in e.get(be, {}).get("fail_reasons", []): A(f"* {'BLOCKED' if fr.startswith('BLOCKED') else 'FAIL'} [{be}]: {fr}")
        if t == "041":
            A("**DEC oracle (compatible complex)** - max |div(DEC curl B)| and max circulation of grad psi against " + f"{TL['dec_zero_factor']:g} eps scaling:")
            A(tbl(["dtype", "g", "grid", "max |div curl|", "tol", "max circ(grad)", "tol", "ok"], [[r["dtype"], r["g"], r["grid"], f(r["max_abs_div_of_dec_curl"]), f(r["tol_div"]), f(r["max_circulation_of_grad"]), f(r["tol_circ"]), r["ok"]] for r in h["dec_oracle_self_check"]]))
            A("\nDEC curl vs analytic curl (SMOOTH): errors " + ", ".join(f(x) for x in h["dec_oracle_vs_analytic"][0]["errs"]) + f"; orders {olist(h['dec_oracle_vs_analytic'][0]['orders'])}.\n")
            A("**Kernel curl of compatible gradients (FP64)** - residual is real signal, second order; annulus closed form C(grad psi) = (0, 0, -(1/4rc) delta_r^2 Bphi_c) verified:")
            A(tbl(["mode", "psi", "region Linf (levels)", "region orders", "global orders", "ring-0 orders", "closed-form err (max)", "DEC curl of grad (max / tol)", "nonzero signal", "ok"],
                  [[x["mode"], short(x["psi"], 30), ", ".join(f(r["region_Linf"]) for r in x["rows"]), olist(x["region_orders"]), olist(x["global_orders"]), olist(x["ring0_orders"]),
                    (f(max(r["closed_form_err"] for r in x["rows"])) if x["mode"] == "annulus" else "n/a"), (f"{f(max(r['dec_curl_max'] for r in x['rows']))} / {f(max(r['dec_curl_tol'] for r in x['rows']))}" if x["mode"] == "annulus" else "n/a"), x.get("nonzero_signal"), x["ok"]]
                   for x in h["convergence"] if x["dtype"] == "float64"]))
            f32 = [x for x in h["convergence"] if x["dtype"] == "float32"]
            A(f"\nFP32: {sum(1 for x in f32 if x['ok'])}/{len(f32)} series within 64 eps Bmax kappa of the FP64 kernel on identical stored inputs; non-discriminating rows (bound > {TL['disc_fraction']} x |J|): {sum(sum(x['fp32_rows_nondiscriminating']) for x in f32)} of {sum(len(x['fp32_rows_nondiscriminating']) for x in f32)}. " + h["statement"])
        elif t == "042":
            A("**DEC divergence of the DEC curl (arbitrary B)**:"); A(tbl(["dtype", "grid", "max |div|", "tol", "ok"], [[r["dtype"], r["grid"], f(r["dec_div_max"]), f(r["tol"]), r["ok"]] for r in h["dec_div_curl"]]))
            A("\n**Closed forms of the kernel's divergence (random data)**:"); A(tbl(["dtype", "wide vs closed form", "finite-volume vs closed form", "tol", "max |div| wide", "max |div| fv"], [[r["dtype"], f(r["err_wide_vs_closed_form"]), f(r["err_fv_vs_closed_form"]), f(r["tol"]), f(r["max_abs_div_wide"]), f(r["max_abs_div_fv"])] for r in h["exact_discrete_closed_forms"]]))
            A("\n**Smooth fields, analytic div J = 0**:"); A(tbl(["mode", "field", "wide region orders", "fv region orders", "wide global orders", "fv global orders", "boundary-leakage orders", "Gauss identity", "first-ring (wide) per level", "ok"],
                  [[c["mode"], c["field"], olist(c["wide_region_orders"]), olist(c["fv_region_orders"]), olist(c["wide_global_orders"]), olist(c["fv_global_orders"]), olist(c["boundary_leakage_orders"]), c["gauss_identity_ok"], ", ".join(f(r["first_ring_wide"]) for r in c["rows"]),
                    c["wide_region_ok"] and c["fv_region_ok"] and c["wide_global_ok"] and c["fv_global_ok"] and c["boundary_leakage_ok"]] for c in h["convergence"]])); A("\n" + h["statement"])
        elif t == "043":
            oc = h["oracle_self_check"]; A(f"Oracle self-check: all analytic currents agree with a 6th-order numeric Cartesian curl (max difference {f(max(r['max_abs_diff_vs_numeric_curl'] for r in oc['rows']))}); Beltrami identity J_ref = alpha B exact; scipy available = {oc['scipy_available']} (series implementation independent: {f(oc['bessel_series_vs_reference_max_abs'])}); continuation to r < 0 consistent ({f(oc['negative_r_continuation_err'])}).\n")
            A(tbl(["field", "mode", "region Linf (levels)", "region L2 (finest)", "region L1 (finest)", "region orders", "global orders", "ring-0 abs err (levels)", "ring-0 orders", "|JxB|/|J||B| orders", "location control ratio", "ok"],
                  [[short(c["field"], 30), c["mode"], ", ".join(f(r["region"]["Linf"]) for r in c["rows"]), f(c["rows"][-1]["region"]["L2"]), f(c["rows"][-1]["region"]["L1"]), olist(c["region_orders"]), olist(c["global_orders"]), ", ".join(f(x) for x in c["ring0_abs_err"]), olist(c["ring0_orders"]), olist(c["lorentz_orders"]),
                    f(c.get("location_control_ratio")) if c.get("location_control_ratio") is not None else "n/a", c["region_ok"] and c["global_ok"]] for c in h["cases"]]))
            A(f"\nFP32 (consistency vs FP64 kernel; non-discriminating rows): {sum(1 for c in h['cases'] for r in c['fp32'] if r['non_discriminating'])} of {sum(len(c['fp32']) for c in h['cases'])}. " + h["statement"])
        elif t == "044":
            A(tbl(["field", "mode", "region Linf (levels)", "region orders", "global orders", "err from J (finest)", "err from B interp (finest)", "sign viol.", "max angle (rad)", "max |E.B|/|E||B|", "FP32 ok"],
                  [[short(c["field"], 28), c["mode"], ", ".join(f(r["region"]["Linf"]) for r in c["rows"]), olist(c["region_orders"]), olist(c["global_orders"]), f(c["rows"][-1]["err_from_J_Linf"]), f(c["rows"][-1]["err_from_Binterp_Linf"]), sum(r["sign_violations"] for r in c["rows"]), f(c["rows"][-1]["max_angle_rad"]), f(c["rows"][-1]["max_E_dot_B_over_EB"]), all(r["ok"] for r in c["fp32"])] for c in h["cases"]]))
            A("\n**Negative controls** (must be detected: error ratio vs the correct implementation >= %g on >= 75%% of the fields with signal; DEGENERATE = wrong and correct coincide for that field):" % TL["neg_control_min_ratio"])
            A(tbl(["field", "control", "error (wrong)", "error (correct)", "ratio", "detected"], [[short(c["field"], 26), c["control"], f(c["error_wrong"]), f(c["error_correct"]), f(c["ratio"]), ("DEGENERATE" if c.get("degenerate") else c.get("detected"))] for c in h["negative_controls"]])); A("\n" + h["statement"])
        elif t == "045":
            A(tbl(["field", "eta", "mode", "min P (finest)", "# negative", "P err region orders", "V rel err (levels)", "V orders", "W (magnetic energy) orders", "ok"],
                  [[short(c["field"], 24), short(c["eta"], 26), c["mode"], f(c["rows"][-1]["min_P"]), sum(r["n_negative"] for r in c["rows"]), olist(c["region_orders"]), ", ".join(f(r["V_rel_err"]) for r in c["rows"]), olist(c.get("V_orders", [])), olist(c.get("W_orders", [])), c["region_ok"] and c["global_ok"]] for c in h["cases"]]))
            A(f"\nNegative-eta control: min P = {f(h['negative_eta_control']['min_P'])}, {h['negative_eta_control']['n_negative']} negative cells, detected = {h['negative_eta_control']['detected']}. FP32 rows ok: {sum(1 for r in h['fp32'] if r['ok'])}/{len(h['fp32'])}.  " + h["statement"])
        elif t == "046":
            A(tbl(["field", "mode", "force region Linf (levels)", "force global (finest)", "ring 0 (finest)", "last ring (finest)", "pressure-force residual orders", "conservative-stress residual (levels)", "cons. region orders", "cons. global orders", "axis F_r/r err (finest)"],
                  [[short(c["field"], 22), c["mode"], ", ".join(f(r["force_region"]["Linf"]) for r in c["rows"]), f(c["rows"][-1]["force_global"]["Linf"]), f(c["rows"][-1]["force_ring0"]["Linf"]), f(c["rows"][-1]["force_outer_ring"]["Linf"]), olist(c["pressure_orders"]), ", ".join(f(r["conservative_stress_residual_region"]) for r in c["rows"]), olist(c["conservative_orders"]), olist(c["conservative_global_orders"]), f(last(c.get("axis_regularity_err", [None])))] for c in h["cases"]]))
            A(f"\nFP32 Z-pinch within 64 eps Bmax^2 kappa: {sum(1 for r in h['fp32_pinch'] if r['ok'])}/{len(h['fp32_pinch'])} rows; non-discriminating {sum(1 for r in h['fp32_pinch'] if r['non_discriminating'])}.\n")
            d = h.get("driver_force", {})
            if d.get("rows"):
                A("**Real driver states (64 x 16 x 8, r in [0, 1], FP32 registry) - driver ScienceManager vs UCT_CURL vs analytic:**")
                A(tbl(["state", "driver Jz err first cell", "driver Jz err interior", "driver F_r 'validated_jz_only' interior", "driver F_r 'full' interior", "kernel Jz err interior", "kernel Jz err last ring", "kernel F_r err interior", "kernel F_r err last ring"],
                      [[r["case"], f(r["driver_jz_err_first"]), f(r["driver_jz_err_inner"]), f(r["driver_Fr_validated_jz_only_err_inner"]), f(r["driver_Fr_full_err_inner"]), f(r["kernel_Jz_err_inner"]), f(r["kernel_Jz_err_last_ring"]), f(r["kernel_Fr_err_inner"]), f(r["kernel_Fr_err_last_ring"])] for r in d["rows"]]))
            for b in h.get("blocked_items", []): A(f"\n**BLOCKED:** {b['item']} - {b['reason']}")
            A("\n" + h["statement"])
        elif t == "047":
            A(tbl(["m", "k", "eps", "phase", "mode", "region Linf orders", "Jr/Jphi/Jz complex err orders (finest)", "phase err (finest, Jz)", "amp err (finest, Jz)", "leakage (finest, Jz)", "ring-0 abs orders (axis)", "ok"],
                  [[c["m"], f(c["k"]), c["eps"], c["delta"], c["mode"], olist(c["region_orders"]), " / ".join(o(last(c[f"harmonic_{n}"]["complex_orders"])) for n in ("Jr", "Jphi", "Jz")), f(last(c["harmonic_Jz"]["phase_err"])), f(last(c["harmonic_Jz"]["amp_err"])), f(last(c["harmonic_Jz"]["leakage"])),
                    (olist([last(c[f"ring0_abs_orders_{n}"]) for n in ("Jr", "Jphi", "Jz")]) if c["mode"] == "axis" else "n/a"), c["region_ok"] and c["global_ok"] and all(c[f"harmonic_{n}"]["ok"] for n in ("Jr", "Jphi", "Jz"))] for c in h["cases"]]))
            A(f"\nFP32 rows ok {sum(1 for r in h['fp32'] if r['ok'])}/{len(h['fp32'])}; non-discriminating {sum(1 for r in h['fp32'] if r['non_discriminating'])}.  " + h["statement"])
        elif t == "048":
            for c in h["cases"]:
                A(f"**{c['field']} - {c['mode']}**:  joint orders L1 {olist(c['joint']['L1_orders'])} | L2 {olist(c['joint']['L2_orders'])} | Linf {olist(c['joint']['Linf_orders'])}; global orders {olist(c['joint']['global_orders'])}; model A = ({', '.join(f(x) for x in c['model_A'])}); worst calibration deviation {f(c['model_worst_calibration_deviation'])}")
                A(tbl(["series", "grids", "region Linf", "orders", "monotone"], [[k, " ".join("x".join(map(str, r["grid"])) for r in s), ", ".join(f(r["region"]["Linf"]) for r in s), olist(c[f"{k}_orders"]), c[f"{k}_monotone"]] for k, s in c["series"].items()]))
                A(tbl(["extreme grid", "kappa", "aspect (max h / min h)", "observed Linf", "predicted", "ratio", "L1", "L2", "global Linf", "ring-0 Linf", "within envelope"],
                      [[x["grid"], f(x["kappa"]), f(x["aspect"][0]), f(x["observed"]), f(x["predicted"]), f(x["ratio_obs_over_pred"]), f(x["L1"]), f(x["L2"]), f(x["global_Linf"]), f(x["ring0_Linf"]), x["within_envelope"]] for x in c["extreme_predictions"]])); A("")
            A("CPU/GPU agreement entered the verdict: **" + str(h["verdict_uses_cpu_gpu_agreement"]) + "**. " + (f"(informational GPU vs host max diff on the base grid: {f(h.get('gpu_vs_host_joint_base_max_diff'))})" if "gpu_vs_host_joint_base_max_diff" in h else "") + " " + h["statement"])
        elif t == "049":
            s = h["summary"]; A(tbl(["quantity", "value"], [["rows", s["n_rows"]], ["all patterns exactly invisible to J", s["all_invisible_to_J"]], ["patterns that leak into the Hall EMF through B_cc", ", ".join(s["patterns_with_hall_leak"]) or "none"], ["patterns that do not", ", ".join(s["patterns_without_hall_leak"]) or "none"],
                    ["DEC current of the pure pattern x h / amplitude (min)", f(s["min_dec_J_over_amp_h"])], ["blind ratio = DEC current of pattern / smooth |J|max (max)", f(s["max_blind_ratio"])], ["smallest amplitude (x Bmax) with blind ratio >= 1", s["critical_amplitude_rel_for_blind_ratio_1"]], ["smallest amplitude (x Bmax) where the Hall EMF change exceeds the clean truncation error", s["critical_amplitude_rel_for_Hall_above_truncation"]]]))
            rows = [r for r in h["rows"] if r["dtype"] == "float64" and r["field"].startswith("SMOOTH")]
            A("\n**SMOOTH field, FP64:**"); A(tbl(["pattern", "amp/Bmax", "max dJ", "invisible", "dB_cc/amp", "dE (region)", "dE/truncation", "dE/E_ref", "DEC J(pattern) h/amp", "blind ratio"], [[short(r["pattern"], 34), r["amp_rel"], f(r["J_change"]), r["invisible"], f(r["dBcc_over_amp"]), f(r["dE_region_Linf"]), f(r["dE_over_truncation"]), f(r["dE_over_Eref"]), f(r["dec_J_over_amp_times_h"]), f(r["blind_ratio"])] for r in rows]))
            A("\n**Axis grid (annulus invisibility is NOT claimed there):**"); A(tbl(["pattern", "max dJ", "dJ h/amp", "ring-0 dJ", "dE"], [[short(r["pattern"], 38), f(r["J_change"]), f(r["J_change_over_amp"]), f(r["ring0_J_change"]), f(r["dE"])] for r in h["axis_grid_patterns"]]))
            A(f"\nIdentity dE = eta[J x dB_cc + dJ x B_cc] satisfied in {sum(1 for r in h['rows'] if r['identity_ok'])}/{len(h['rows'])} rows; Hall contamination linear in the amplitude (checked). **Limitation recorded: {h['limitation_recorded']}.**\n\n{h['limitation_text']}")
        elif t == "050":
            A("**Component inventory (driver manifest)**:"); A(tbl(["slot", "driver status", "operator returns", "call changes state", "disposition"], [[r["slot"], r["driver_status"], r.get("operator_returns", ""), r.get("call_changes_state", ""), r.get("disposition", "not required here")] for r in h["component_inventory"]]))
            for b in h.get("blocked", []): A(f"* **BLOCKED** `{b['component']}`: {b['reason']}")
            A("\n**Shape / location / dtype contracts on real driver arrays (adaptation layer needed because the driver's geometry arrays carry no ghosts)**:")
            A(tbl(["dims", "r_min", "validator accepts", "shapes match staggering", "dtype", "interior geometry dev", "driver r_faces len", "kernel needs"], [[r["dims"], r["r_min"], r["validator_accepts"], r["shapes_match"], r["dtype"], f(r["interior_geometry_dev"]), r["driver_r_faces_len"], r["kernel_needs_len"]] for r in h["shape_contracts"]]))
            A("\n**Immutability, determinism, GPU/host**:"); A(tbl(["dims", "r_min", "dtype", "inputs unchanged", "registry unchanged", "bitwise deterministic", "finite", "GPU==host"], [[r["dims"], r["r_min"], r["dtype"], r["inputs_unchanged"], r["registry_unchanged"], r["deterministic"], r["finite"], r.get("gpu_vs_host_ok", "n/a (host leg)")] for r in h["controlled_runs"]]))
            A("\n**Ghost ownership - kernel output with analytic ghosts vs with the driver's own BoundaryManager (core = cells not adjacent to a radial / axial boundary):**")
            A(tbl(["state", "|J|max", "core diff", "ring-0 diff", "last-ring diff", "first z layer diff", "last z layer diff", "max phi-layer diff (core)", "Br axis face: driver / analytic", "# Br inner-face entries changed", "ring-0 err: driver BC / analytic ghosts"],
                  [[r["case"], f(r["Jmax"]), f(r["core_max_diff"]), f(r["ring0_diff"]), f(r["last_ring_diff"]), f(r["z_first_layer_diff"]), f(r["z_last_layer_diff"]), f(max(r["phi_layer_diffs"])), f"{f(r['axis_face_Br_driver_max'])} / {f(r['axis_face_Br_analytic_max'])}", r["driver_bc_changed_Br_inner_face_entries"], f"{f(r['ring0_err_driver_bc'])} / {f(r['ring0_err_analytic_ghost'])}"] for r in h["ghost_ownership"]]))
            A("\nFindings: " + "; ".join(f"{k} = {x}" for k, x in h["ghost_findings"].items()))
            if "units" in h: A(f"\nUnits: driver J scales as 1/mu0 exactly once = {h['units']['driver_jz_scales_as_1_over_mu0']} (max deviation {f(h['units']['max_rel_dev'])}); kernel contract: {h['units']['kernel_contract']}.")
            A(f"\n**Regression (Campaigns 01-04, this backend):** {sum(1 for x in h['regression'].values() if x['verdict'] == 'PASS')}/{h['regression_count']} PASS.  Source hashes unchanged during the test: **{h['sources_unchanged_during_test']}**.")
            A(tbl(["test", "name", "verdict"], [[k, x["name"], x["verdict"]] for k, x in sorted(h["regression"].items())]))
            nd = h["non_discriminating_fp32_cases"]; A(f"\nPreserved Campaign 04 pathology P19 (non-discriminating FP32 metric cases): found {nd['found']}; exactly the expected three: **{nd['preserved']}**.\n\n" + h["statement"])
    A("## 5. Register (VERIFIED / LIMITATION / INCONCLUSIVE / BLOCKER / RESOLVED)")
    A("**BLOCKER** (kind *BLOCKED component*) means a required real component does not exist; (kind *defect*) means an exposed defect or unmet required check. No kernel defect entry appears unless listed with kind *defect*. Entries `C04-*` are the Campaign 04 pathology register recomputed from this run's regression data.\n")
    A(tbl(["id", "class", "kind", "test", "finding", "evidence", "restriction / safeguard"], [[x["id"], f"**{x['cls']}**", x.get("kind") or "", x["test"], x["title"], x["evidence"], x["restriction"]] for x in reg]))
    cnt = {}
    for x in reg: cnt[x["cls"]] = cnt.get(x["cls"], 0) + 1
    A(f"\nCounts: {cnt}.  Open defect entries (kernel or harness; read the register): **{sum(1 for x in reg if x['cls'] == 'BLOCKER' and 'defect' in str(x.get('kind')))}**. RESOLVED entries: **{cnt.get('RESOLVED', 0)}** (none: no earlier open item was closed by this campaign's evidence). *Every LIMITATION is characterised by a PASS, never eliminated by it.*\n")
    A("## 6. Plots")
    for p in plots: A(f"![{os.path.basename(p)}](campaign05_plots/{os.path.basename(p)})")
    A("\n## 7. Findings and what they mean for ALADIN's Hall-MHD")
    for fi in R["findings"]: A(f"* **{fi['id']} - {fi['title']}.** {fi['detail']}")
    A("""
**Answer to the Inspector's question.** Within the tested domain UCT_CURL is a *second-order accurate, deterministic, contract-respecting current reconstruction* that reproduces analytic currents, Hall EMFs, Lorentz forces and harmonic content at the declared accuracy and is not misled by anisotropy. It is **not** a mimetic operator (div J != 0, curl grad != 0, grid-scale B content invisible) and its trustworthiness inside the *driver* cannot be certified yet: HLLD, UCT_EMF, the residual and the CT update do not exist as real kernels, there is no `current_curl` slot or J storage, and the driver's own boundary manager breaks the kernel's input contract in four measured ways.

**Proposed separately versioned changes (none applied; the kernel stays frozen).**
1. *Driver* (`Aladin_Driver_v3.2`, not a kernel change): apply the axis closure only when `r_min == 0`; fill the axis Br face with the point value (or the m = 1 limit) that the kernel reads, not zero; fix the axial ghost mapping (mirror or replicate adjacent layers, not layers `g..2g-1`) and the Bphi/face periodic mapping (off by one); extend the outer radial boundary consistently with the equilibrium (linear or analytic extrapolation) so the last radial ring of J is not corrupted; add ghost-extended coordinate arrays and J storage; register a `current_curl` slot distinct from the CT `uct_curl` slot; remove the import-time `pip install`.
2. *Driver diagnostics*: `ScienceManager.jz` is wrong in the first radial cell (axis mask uses `r < 0.5 dr`, the first centre is exactly 0.5 dr) and `lorentz_radial('validated_jz_only')` omits J_phi B_z; use UCT_CURL output for diagnostics once registered.
3. *Kernel*: no defect was exposed, so no `uct_curl_v1.4` is proposed. If a mimetic discrete complex is required (exact div J = 0, curl grad = 0), that is a different operator (a DEC / Yee edge-current formulation) and would be a new kernel, not a patch.
""")
    A("## 8. Harness development history and corrections (disclosed)")
    A("Every row is a failure or mis-specification found while building THIS harness. No kernel change was made; where a criterion changed, the reason is recorded and the whole campaign was re-run from scratch.\n")
    A(tbl(["phase", "item", "observation", "resolution"], [[d["phase"], d["item"], d["observation"], d["resolution"]] for d in R.get("dev_log", [])]))
    A("\n## 9. Requirement checklist (Campaign 05 specification)")
    gp = env["gpu_present"]; allh = all(v(e, "host") in ("PASS",) for t, e in T.items() if t != "050"); allg = all(v(e, "cupy") == "PASS" for t, e in T.items() if t != "050")
    A(tbl(["requirement", "status", "evidence"], [
        ["Frozen source v1.3, SHA-256 e7b25907...f58e", "MET" if env["source_frozen_and_matches"] else "NOT MET", "section 1"],
        ["Two real execution legs (NumPy CPU, CuPy GPU; FP32 & FP64)", "MET" if gp else "PARTIAL (GPU blocked)", "section 3"], ["Independent oracles distinguished (analytic / exact-discrete / DEC)", "MET", "section 4, every table"],
        ["Predeclared thresholds, observed orders, absolute errors incl. near-axis cells", "MET", "section 2, per-test tables (ring-0 columns)"], ["Classification VERIFIED / LIMITATION / INCONCLUSIVE / BLOCKER / RESOLVED; no limitation reported as eliminated", "MET", "section 5"],
        ["MakeReport + Evidence Bundle (results, config, environment, seeds, hashes, logs, failures, references, commands)", "MET", "campaign05_evidence_bundle.zip"], ["Campaign 04 pathologies preserved incl. the three non-discriminating FP32 cases", "MET" if T["050"]["host"].get("non_discriminating_fp32_cases", {}).get("preserved") else "NOT MET", "Test 050, register C04-*"],
        ["Tests 041-049 PASS on CPU", "MET" if allh else "NOT MET", "section 3"], ["Tests 041-049 PASS on a real GPU", "MET" if allg else ("NOT MET (blocked: no GPU in this execution)" if not gp else "NOT MET"), "section 3"],
        ["Test 050 integration with real HLLD / UCT_EMF / CT", "NOT MET - BLOCKED (components are stubs)", "Test 050 inventory"], ["Exit gate 10/10", "NOT MET" if gate["tests_pass_both_backends"] < 10 else "MET", "section 3"],
        ["Kernel not modified to make tests pass", "MET" if env["source_frozen_and_matches"] else "NOT MET", "section 1"]]))
    A("\n## 10. Reproducibility")
    A("```\nunzip the package into an empty folder (ONE uct_curl.py, campaign01.py ... campaign05.py, make_report_campaign01..05.py, Aladin_Driver_v3.1_AIL.py)\npython campaign05.py      # host leg always; GPU leg if CuPy + a CUDA device are present\n```\nOutputs: `campaign05_results.json`, `CAMPAIGN05_REPORT.md`, `campaign05_plots/`, `campaign05_execution.log`, `campaign05_evidence_bundle.zip` (sources, results, configuration, environment, seeds, SHA256SUMS, failures, reproduction commands).\n")
    text = "\n".join(L) + "\n"
    open(os.path.join(here, name), "w", encoding="utf-8").write(text)
    return text

if __name__ == "__main__":
    import json
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
    print(build_report(json.load(open(os.path.join(here, "campaign05_results.json"))), here)[:3000])
