#!/usr/bin/env python3
"""
ALADIN v4.0 - Campaign 05: Production adversarial validation of the Hall-MHD current operator   (tests 041-050)
Target : uct_curl.py v1.3 (executed UNMODIFIED; SHA-256 checked against KNOWN_SHA).  J = curl(B), mu0 = 1, cell-centred.  NOT the Faraday CT update.
Needs campaign01.py .. campaign04.py (shared grid/backend/reference helpers) in the same folder.   Run:  python campaign05.py
Deliverables written next to this file: campaign05_results.json, CAMPAIGN05_REPORT.md, campaign05_plots/*.png, campaign05_execution.log

QUESTION UNDER TEST
  Is UCT_CURL merely numerically well-behaved in isolation, or trustworthy as the current-density operator of a Hall-MHD driver?
  Finite outputs and GPU == CPU agreement are NEVER evidence of that (both can be perfectly wrong in the same way).  Every verdict below is decided against an
  INDEPENDENT oracle, and the three kinds of oracle are kept apart and named in every table:
     ANALYTIC  - closed-form continuum fields / currents / forces (the physics);
     EXACT-DISCRETE - closed forms of the kernel's own stencil (Campaign 03/04: exact rational or algebraic identities);
     DEC       - a compatible staggered discrete-exterior-calculus curl / divergence built here from circulations on the dual faces (a genuinely
                 compatible complex: d(d) = 0 exactly), used as the yard-stick for what a "mimetic" operator would do.  Annulus grids only (no DEC on the axis).
STANCE (stated before any result was looked at)
  * VERIFIED   : the property holds against the declared oracle and threshold, in the tested domain.
  * LIMITATION : the property fails or cannot hold by construction; it is MEASURED and characterised.  A limitation is never reported as an eliminated defect and a
                 PASS that characterises it is not evidence that it is gone.
  * INCONCLUSIVE: the check cannot discriminate (bound exceeds the signal, oracle unavailable, ...).
  * BLOCKER    : an exposed defect or an unmet REQUIRED accuracy/integration check; blocks certification.   RESOLVED: a previously open item closed by evidence.
  * The kernel is frozen.  A real defect is reported as a blocker + a separately versioned fix proposal + a fresh rerun, never patched to make a test pass.
  * Missing real components (HLLD, UCT_EMF, magnetic-state interfaces) are BLOCKED, never replaced by stubs and called validated.
  * All thresholds are DECLARED in TOL5 before execution; changes after seeing results go to DEV_LOG followed by a fresh full run.
"""
import os, sys, json, math, hashlib, re, subprocess, datetime, platform, traceback, importlib.util, io, itertools
from fractions import Fraction
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
sys.path.insert(0, HERE)
import campaign01 as C
import campaign02 as H
import campaign03 as T3
import campaign04 as T4

K = C.K
F64, F32 = np.float64, np.float32
EPS = C.EPS
KNOWN_SHA = {"1.3": "e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e"}
EXPECTED_SHA = KNOWN_SHA.get(getattr(C.K, "VERSION", ""), "")
OUT = os.environ.get("CAMPAIGN_OUT", HERE)
KW = T4.KW if hasattr(T4, "KW") else 2.0

TOL5 = dict(
    order_min=1.8,             # last-pair observed order of every smooth-field "second-order" claim (4 refinement levels, h halved)
    conv_base=(12, 24, 8),     # base grid of every 4-level refinement
    region_annulus=(0.6, 1.4), # fixed physical interior region, annulus grids (r0 = 0.5, r1 = 1.5)
    region_axis=(0.25, 0.9),   # fixed physical interior region, axis grids (r0 = 0, r1 = 1)
    axis_global_order_min=0.8, # axis grids, ALL cells (first ring included): at least first order (ring-0 stencil)
    exact_fp64=1e-12,          # error floor for quantities the discrete operator reproduces exactly (relative to max(1, signal))
    alg_factor=128.0,          # exact algebraic identity: <= alg_factor*eps*scale
    dec_zero_factor=32.0,      # DEC exact-zero identities (d.d = 0): <= dec_zero_factor*eps*max|H|/area
    fp_factor=64.0,            # FP32 vs FP64 consistency bound: 64*eps*Bmax*kappa
    disc_fraction=0.5,         # a round-off bound demonstrates accuracy only if bound <= disc_fraction*signal, else the row is NON-DISCRIMINATING
    sens_min=10.0,             # a "nonzero residual" claim needs signal >= sens_min * tolerance
    hall_eta=0.37,             # eta_H used in 044 / 046 / 049 (a number != 1 so a missing eta_H is visible)
    neg_control_min_ratio=10.0,# a deliberately wrong implementation must be flagged: its error >= 10 x the error of the correct implementation, on >= 75% of the fields where the control has signal
    amp_order_min=1.8,         # 047: amplitude / phase error orders
    leak_factor=128.0,         # 047: leakage into other harmonics <= leak_factor*eps*scale/hmin  OR  converging at the declared order
    model_fit_tol=0.5,         # 048: the additive error model e = A_r h_r^2 + A_phi h_phi^2 + A_z h_z^2 (A >= 0) must reproduce every calibration error within +-50%
    plateau_tol=0.10,          # 048: a single-direction refinement series may not INCREASE by more than 10% between levels (plateau set by the other directions; the region samples different points each level)
    aniso_envelope=64.0,       # 048: error on an anisotropic grid <= envelope * (isotropic-equivalent leading-order estimate) (declared calibration, see 048)
    beltrami_alphas=(2.0, 3.8317059702075125, 5.5),   # 043; 3.8317 = first zero of J1 (B_phi vanishes at r = 1)
    align_max_angle=0.05,      # 044: maximum angle (rad) between numerical and analytic E_H vectors where |E_ref| > sign_signal_factor * (region error)
    sign_signal_factor=10.0,   # 044: a sign / alignment claim is made only where |E_ref| >= factor * observed region error
    mu0_phys=4e-7*math.pi,     # 044: a second unit system (SI) used to test that the 1/mu0 division is performed exactly once by the caller
    pressure_p0=1.0,           # 046: background pressure of the force-balanced profiles
    seeds=dict(t041=41, t042=42, t043=43, t044=44, t045=45, t046=46, t047=47, t048=48, t049=49, t050=50),
)

def dn(d): return np.dtype(d).name
nmax = H.nmax
orders_of = H.orders_of
per_fill, cc, Iv, Ji = T3.per_fill, T3.cc, T3.Iv, T3.Ji
hmin_of, bmax_of = T3.hmin_of, T3.bmax_of
kappa_of = T4.kappa_of

def tol_alg(dtype, scale): return TOL5["alg_factor"]*EPS[dtype]*scale
def finite_all(arrs): return all(bool(np.isfinite(a).all()) for a in arrs)

# ----------------------------------------------------------------------------
# generic helpers
# ----------------------------------------------------------------------------
def interior_mesh(G):
    g = G.g; return G.mesh(G.rc[g:g + G.nr], G.pc[g:g + G.nphi], G.zc[g:g + G.nz])

def region_mask(G, mode):
    """interior cells whose centre radius lies in the declared fixed physical region (broadcast to the interior shape)"""
    lo, hi = TOL5["region_annulus"] if mode == "annulus" else TOL5["region_axis"]
    rcs = G.rc[G.g:G.g + G.nr]; m = (rcs >= lo) & (rcs <= hi)
    return np.broadcast_to(m[:, None, None], (G.nr, G.nphi, G.nz))

def ring_mask(G, i):
    m = np.zeros((G.nr, G.nphi, G.nz), bool); m[i] = True; return m

def norms(d, mask=None):
    """L1 (mean |d|), L2 (rms) and Linf over `mask` (all if None). NaN/Inf anywhere -> inf (never silently passes)."""
    d = np.asarray(d, dtype=F64)
    if mask is not None: d = d[mask]
    if d.size == 0: return dict(L1=0.0, L2=0.0, Linf=0.0)
    if not np.isfinite(d).all(): return dict(L1=math.inf, L2=math.inf, Linf=math.inf)
    a = np.abs(d); return dict(L1=float(a.mean()), L2=float(np.sqrt((a*a).mean())), Linf=float(a.max()))

def order_rule(errs, floors, order_min=None):
    """pass iff last-pair order >= order_min OR every level is at/below its declared round-off floor"""
    o = orders_of(errs); om = TOL5["order_min"] if order_min is None else order_min
    at_floor = all(e <= f for e, f in zip(errs, floors))
    last = o[-1] if o else math.nan
    return bool((last >= om) or at_floor), o, bool(at_floor)

def levels(mode, L=4, base=None):
    base = base or TOL5["conv_base"]
    return [C.Grid(*n, r0=0.5, r1=1.5) if mode == "annulus" else C.Grid(*n, r0=0.0, r1=1.0) for n in H.levels(base, L)]

def kern(G, raw, B, dt):
    """kernel output on the interior, FP64 copies"""
    return Ji(G.run(raw, B, dt), G)

def fp32_consistency(G, raw, B32):
    """FP32 kernel output vs FP64 kernel output on the SAME (FP32-stored) inputs: the pure round-off difference, against 64*eps32*Bmax*kappa"""
    J32 = kern(G, raw, B32, F32); J64 = kern(G, raw, [b.astype(F64) for b in B32], F64)
    diff = max(nmax(J32[c] - J64[c]) for c in range(3)); bound = TOL5["fp_factor"]*EPS[F32]*bmax_of(B32)*kappa_of(G)
    return dict(diff=diff, bound=bound, ok=bool(diff <= bound), Jmax=max(nmax(j) for j in J64))

def cart_fld(name, spec): return C._cart_field(*spec, name)

def sample_J_ref(G, fld):
    """analytic current at the interior cell centres (FP64)"""
    return [np.asarray(x, dtype=F64) for x in G.ref(fld)]

# ----------------------------------------------------------------------------
# DEC oracle (annulus grids only).   B is treated as the flux 2-form on primal faces; H = B (mu0 = 1) is the dual 1-form whose line integral along the dual edge
# crossing a primal face is  Hr*dr, Hphi*rc*dphi, Hz*dz.  The circulation of H around the dual face of a primal EDGE is the DEC curl (an exact sum, no interpolation);
# dividing by the dual-face area gives the current component at the edge centre.  The divergence of the dual-face fluxes at a primal NODE is the algebraic sum of those
# circulations: identically zero (d o d = 0) - it is what a compatible discrete complex guarantees and what the kernel is measured against.
# ----------------------------------------------------------------------------
def dec_circulations(B, G):
    Br, Bp, Bz = [np.asarray(b, dtype=F64) for b in B]
    NR, NP, NZ = G.nr + 2*G.g, G.nphi + 2*G.g, G.nz + 2*G.g
    Hr = Br*G.dr; Hp = Bp*(G.rc[:, None, None]*G.dphi); Hz = Bz*G.dz
    Ir = Hp[:, 1:NP, 0:NZ - 1] + Hz[:, 1:NP, 1:NZ] - Hp[:, 1:NP, 1:NZ] - Hz[:, 0:NP - 1, 1:NZ]                 # (NR, NP-1, NZ-1)  edge (ic, jf, kf)  offset (0,1,1)
    Ip = Hz[0:NR - 1, :, 1:NZ] + Hr[1:NR, :, 1:NZ] - Hz[1:NR, :, 1:NZ] - Hr[1:NR, :, 0:NZ - 1]                 # (NR-1, NP, NZ-1)  edge (if, jc, kf)  offset (1,0,1)
    Iz = Hr[1:NR, 0:NP - 1, :] + Hp[1:NR, 1:NP, :] - Hr[1:NR, 1:NP, :] - Hp[0:NR - 1, 1:NP, :]                 # (NR-1, NP-1, NZ)  edge (if, jf, kc)  offset (1,1,0)
    return Ir, Ip, Iz, max(float(np.abs(Hr).max()), float(np.abs(Hp).max()), float(np.abs(Hz).max()))

def dec_edge_currents(B, G):
    Ir, Ip, Iz, hmax = dec_circulations(B, G); NR = G.nr + 2*G.g
    Jr = Ir/(G.rc[:, None, None]*G.dphi*G.dz); Jp = Ip/(G.dr*G.dz); Jz = Iz/(G.rf[1:NR][:, None, None]*G.dphi*G.dr)
    return Jr, Jp, Jz

def dec_node_divergence(B, G):
    """divergence of the dual-face fluxes at the primal nodes, divided by the dual-cell volume rf*dr*dphi*dz.  Returns (div, scale) with scale = max|H|/min(volume)."""
    Ir, Ip, Iz, hmax = dec_circulations(B, G); NR = G.nr + 2*G.g
    flux = (Ir[1:NR] - Ir[0:NR - 1]) + (Ip[:, 1:, :] - Ip[:, :-1, :]) + (Iz[:, :, 1:] - Iz[:, :, :-1])         # nodes (if=1..NR-1, jf=1..NP-1, kf=1..NZ-1)
    vol = G.rf[1:NR][:, None, None]*G.dr*G.dphi*G.dz
    vmin = float(np.min(np.abs(vol[vol != 0]))) if (vol != 0).any() else 1.0
    return flux/np.where(vol == 0, np.nan, vol), hmax/vmin

def dec_cell_currents(B, G):
    """DEC edge currents averaged (4 edges each) to the cell centres, interior cells, FP64 - the same location as the kernel's output.  Annulus only."""
    Jr_e, Jp_e, Jz_e = dec_edge_currents(B, G); g = G.g; NR, NP, NZ = G.nr + 2*g, G.nphi + 2*g, G.nz + 2*g
    Jr_c = np.full((NR, NP, NZ), np.nan); Jp_c = np.full((NR, NP, NZ), np.nan); Jz_c = np.full((NR, NP, NZ), np.nan)
    Jr_c[:, 1:NP - 1, 1:NZ - 1] = 0.25*(Jr_e[:, :-1, :-1] + Jr_e[:, 1:, :-1] + Jr_e[:, :-1, 1:] + Jr_e[:, 1:, 1:])
    Jp_c[1:NR - 1, :, 1:NZ - 1] = 0.25*(Jp_e[:-1, :, :-1] + Jp_e[1:, :, :-1] + Jp_e[:-1, :, 1:] + Jp_e[1:, :, 1:])
    Jz_c[1:NR - 1, 1:NP - 1, :] = 0.25*(Jz_e[:-1, :-1, :] + Jz_e[1:, :-1, :] + Jz_e[:-1, 1:, :] + Jz_e[1:, 1:, :])
    return [Iv(a, G) for a in (Jr_c, Jp_c, Jz_c)]

def dec_self_check(G, dt, rng):
    """the DEC complex must be compatible: div(curl) = 0 for ARBITRARY B (random, FP32-stored and FP64), and curl of a compatible gradient = 0"""
    B = per_fill(H.random_B(G, dt, rng), G); div, sc = dec_node_divergence(B, G)
    tol = TOL5["dec_zero_factor"]*EPS[dt]*sc
    G3 = T3.ext_grid(G); Psi = per_fill([rng.uniform(-1, 1, (G3.nr + 2*G3.g, G3.nphi + 2*G3.g, G3.nz + 2*G3.g))], G3)[0]
    Bg = T3.compat_grad(Psi, G, dt); Ir, Ip, Iz, hmax = dec_circulations(Bg, G); area_min = float(min(G.dr*G.dz, G.dr*G.rc[G.g]*G.dphi, G.dz*G.rc[G.g]*G.dphi))
    cg = max(float(np.abs(a).max()) for a in (Ir, Ip, Iz))
    return dict(dtype=dn(dt), grid=[G.nr, G.nphi, G.nz], g=G.g, max_abs_div_of_dec_curl=float(np.nanmax(np.abs(div))), tol_div=tol,
                max_circulation_of_grad=cg, tol_circ=TOL5["dec_zero_factor"]*EPS[dt]*hmax, max_abs_Hgrad=hmax,
                ok=bool(np.nanmax(np.abs(div)) <= tol and cg <= TOL5["dec_zero_factor"]*EPS[dt]*hmax))

def dec_vs_analytic(fld, G):
    """DEC cell current vs analytic current at the same cell centres (the oracle must itself be second-order accurate for smooth fields)"""
    B = G.sample(fld, F64); Jd = dec_cell_currents(B, G); Jr = sample_J_ref(G, fld)
    return [nmax(Jd[c] - Jr[c]) for c in range(3)], [norms(Jd[c] - Jr[c], region_mask(G, "annulus")) for c in range(3)]

# ============================================================================
# TEST 041  Discrete curl-gradient annihilation
# ============================================================================
def psi_modes(k=KW):
    """compatible-gradient potentials.  Cartesian-regular (valid on the axis).  m = 1, 2, 3 azimuthal structure times an axial wave."""
    out = dict(T3.PSI)
    for m in (1, 2, 3):
        out[f"psi_m{m} = Re((x+iy)^{m}) cos(kz+0.4)"] = (lambda m_: (lambda x, y, z: np.real((x + 1j*y)**m_)*np.cos(k*z + 0.4)))(m)
    return out

def t041(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(TOL5["seeds"]["t041"])
    # (a) the DEC oracle itself: a compatible complex (d.d = 0) - random fields, FP32/FP64, g = 2, 3
    rows = []
    for dt in (F64, F32):
        for g in (2, 3):
            G = C.Grid(10, 12, 7, g=g, r0=1.0, r1=2.0); r = dec_self_check(G, dt, rng); rows.append(r)
            if not r["ok"]: fails.append(f"DEC oracle not compatible {dn(dt)} g={g}: div(curl) {r['max_abs_div_of_dec_curl']:.2e} (tol {r['tol_div']:.2e}), curl(grad) {r['max_circulation_of_grad']:.2e}")
    res["dec_oracle_self_check"] = rows
    # (a2) the DEC oracle is an accurate curl for smooth fields (so 'DEC = 0' is not a vacuous yard-stick)
    ds = []
    for name, fld in (("SMOOTH", C.SMOOTH),):
        errs = [dec_vs_analytic(fld, G)[0] for G in levels("annulus")]; Jm = [max(nmax(x) for x in sample_J_ref(G, fld)) for G in levels("annulus")]
        e = [max(x) for x in errs]; o = orders_of(e); ds.append(dict(field=name, errs=e, orders=o, ok=bool(o[-1] >= TOL5["order_min"])))
        if not ds[-1]["ok"]: fails.append(f"DEC oracle is not second order for {name}: orders {o}")
    res["dec_oracle_vs_analytic"] = ds
    # (b) kernel curl of a compatible gradient, per mode, potential, dtype
    conv = []
    for mode in ("annulus", "axis"):
        for pname, psi in psi_modes().items():
            for dt in (F64, F32):
                lv = levels(mode, 4 if dt is F64 else 3); rows = []
                for G in lv:
                    Psi = T3.cell_psi(T3.ext_grid(G), psi); B = T3.compat_grad(Psi, G, dt); J = kern(G, raw, B, dt)
                    rm = region_mask(G, mode); r0 = ring_mask(G, 0)
                    nrm = [norms(J[c]) for c in range(3)]; nreg = [norms(J[c], rm) for c in range(3)]
                    row = dict(grid=[G.nr, G.nphi, G.nz], h=max(G.dr, G.dz), finite=finite_all(J), comp_max=[n["Linf"] for n in nrm],
                               global_Linf=max(n["Linf"] for n in nrm), global_L2=float(math.sqrt(sum(n["L2"]**2 for n in nrm))), region_Linf=max(n["Linf"] for n in nreg),
                               region_L1=float(sum(n["L1"] for n in nreg)), region_L2=float(math.sqrt(sum(n["L2"]**2 for n in nreg))),
                               ring0_Linf=max(norms(J[c], r0)["Linf"] for c in range(3)), Bmax=bmax_of(B), kappa=kappa_of(G), floor=tol_alg(dt, bmax_of(B)/hmin_of(G)))
                    if mode == "annulus":
                        row["closed_form_err"] = nmax(J[2] - T3.jz_residual_term(B, G)[:, :, G.g:G.g + G.nz]); row["closed_form_tol"] = tol_alg(dt, row["Bmax"]/hmin_of(G))
                        Ir, Ip, Iz, hmax = dec_circulations(B, G); row["dec_curl_max"] = max(float(np.abs(a).max()) for a in (Ir, Ip, Iz))/min(G.dr*G.dz, G.dr*G.rc[G.g]*G.dphi, G.dz*G.rc[G.g]*G.dphi)
                        row["dec_curl_tol"] = TOL5["dec_zero_factor"]*EPS[dt]*hmax/min(G.dr*G.dz, G.dr*G.rc[G.g]*G.dphi, G.dz*G.rc[G.g]*G.dphi)
                    if dt is F32: row["fp32_vs_fp64_kernel"] = fp32_consistency(G, raw, B)
                    rows.append(row)
                e_reg = [r["region_Linf"] for r in rows]; e_glob = [r["global_Linf"] for r in rows]; fl = [r["floor"] for r in rows]
                ent = dict(mode=mode, psi=pname, dtype=dn(dt), rows=rows)
                if dt is F64:
                    okr, o_r, atf = order_rule(e_reg, fl); ent.update(region_orders=o_r, region_ok=okr, region_at_floor=atf)
                    og = orders_of(e_glob); ent["global_orders"] = og
                    ent["global_ok"] = bool(mode == "annulus" and order_rule(e_glob, fl)[0] or mode == "axis" and (og[-1] >= TOL5["axis_global_order_min"] or all(e <= f for e, f in zip(e_glob, fl))))
                    if mode == "annulus": ent["global_ok"] = bool(order_rule(e_glob, fl)[0])
                    o0 = orders_of([r["ring0_Linf"] for r in rows]); ent["ring0_orders"] = o0
                    ent["nonzero_signal"] = bool(max(e_reg) > 100*fl[0])          # the residual is real signal, not round-off: the annihilation claim is FALSE for this operator
                    ent["annihilates_exactly"] = bool(max(e_glob) <= max(fl))
                    ent["ok"] = bool(okr and ent["global_ok"] and all(r.get("finite") for r in rows))
                    if not okr: fails.append(f"041 curl(grad_h) {mode} {pname} FP64: region orders {['%.2f' % x for x in o_r]}")
                    if not ent["global_ok"]: fails.append(f"041 curl(grad_h) {mode} {pname} FP64: global orders {['%.2f' % x for x in og]}")
                    if mode == "annulus":
                        if max(r["closed_form_err"]/r["closed_form_tol"] for r in rows) > 1: fails.append(f"041 {pname}: exact-discrete closed form violated")
                        if max(r["dec_curl_max"]/r["dec_curl_tol"] for r in rows) > 1: fails.append(f"041 {pname}: DEC curl of compat gradient not zero to round-off")
                else:
                    bad = [r for r in rows if not r["fp32_vs_fp64_kernel"]["ok"]]; ent["ok"] = bool(not bad); ent["fp32_rows_nondiscriminating"] = [bool(r["fp32_vs_fp64_kernel"]["bound"] > TOL5["disc_fraction"]*max(r["fp32_vs_fp64_kernel"]["Jmax"], 1e-300)) for r in rows]
                    if bad: fails.append(f"041 {mode} {pname} FP32: FP32 vs FP64-on-same-inputs difference exceeds the round-off bound")
                conv.append(ent)
    res["convergence"] = conv
    res["dec_zero_but_kernel_nonzero"] = bool(all(e.get("nonzero_signal") for e in conv if e["dtype"] == "float64" and e["mode"] == "annulus"))
    res["statement"] = ("The DEC curl of a compatible gradient is zero to round-off (d.d = 0).  The KERNEL's reconstruction curl is NOT: C(grad_h psi) = (0, 0, -(1/(4 rc)) delta_r^2 Bphi_c) "
                        "exactly on annulus grids (closed form verified to round-off): a purely axial, second-order residual, i.e. the kernel is NOT a mimetic curl.  On axis grids the "
                        "residual also converges (region second order, all cells at least first order) but has no closed form.  FP32 is checked as FP32-vs-FP64-kernel on identical stored inputs.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 042  Divergence-curl compatibility
# ============================================================================
def div_box_kernel(J, G, mode):
    """independent divergences of the kernel current on cells i=1..nr-2 (annulus) / FV box (axis): wide centred and finite-volume, interior cells only"""
    w = T3.div_wide(J, G); fv = T3.fv_box(J, G, mode == "axis"); return w, fv

def region_of_div(arr, i0, G, mode):
    """regional Linf of a divergence array whose first row is interior cell ring i0 (k = 1..nz-2 rows trimmed already by the producers)"""
    return T3.reg_max(arr, G, i0, mode)

def t042(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(TOL5["seeds"]["t042"])
    # (a) DEC: div(curl B) = 0 for arbitrary B, including ghost-adjacent nodes (the node ring next to every boundary)
    rows = []
    for dt in (F64, F32):
        for n in ((9, 12, 7), (16, 16, 8)):
            G = C.Grid(*n, g=2, r0=0.5, r1=1.5); B = per_fill(H.random_B(G, dt, rng), G); div, sc = dec_node_divergence(B, G)
            tol = TOL5["dec_zero_factor"]*EPS[dt]*sc; mx = float(np.nanmax(np.abs(div)))
            rows.append(dict(dtype=dn(dt), grid=list(n), dec_div_max=mx, tol=tol, ok=bool(mx <= tol), nodes=int(div.size)))
            if mx > tol: fails.append(f"DEC div(curl) not zero {dn(dt)} {n}: {mx:.2e} > {tol:.2e}")
    res["dec_div_curl"] = rows
    # (b) exact-discrete closed forms hold for RANDOM data (reproduces Campaign 03 on this build, per backend)
    rows = []
    for dt in (F64, F32):
        G = C.Grid(13, 7, 11, r0=0.5, r1=1.5); B = per_fill(H.random_B(G, dt, rng), G); J = G.run(raw, B, dt)
        d = T3.div_wide(J, G); p = T3.div_predicted(B, G); f = T3.fv_box(J, G, False)["div"]; pf = T3.div_fv_predicted(B, G)
        sc = bmax_of(B)/hmin_of(G)**2; tol = tol_alg(dt, sc)
        r = dict(dtype=dn(dt), err_wide_vs_closed_form=nmax(d - p), err_fv_vs_closed_form=nmax(f - pf), tol=tol, max_abs_div_wide=nmax(d), max_abs_div_fv=nmax(f))
        r["ok"] = bool(r["err_wide_vs_closed_form"] <= tol and r["err_fv_vs_closed_form"] <= tol); rows.append(r)
        if not r["ok"]: fails.append(f"042 closed form of div(curl) violated for random data {dn(dt)}")
    res["exact_discrete_closed_forms"] = rows
    # (c) smooth fields: analytic div(J) = 0 for ANY smooth B.  Kernel J -> wide and FV divergence: refinement orders, first-ring cells, boundary leakage
    conv = []
    for mode, fld, nm in (("annulus", C.SMOOTH, "SMOOTH"), ("annulus", C.KINK, "KINK (m=1)"), ("axis", C.SMOOTH, "SMOOTH"), ("axis", C.KINK, "KINK (m=1)")):
        rows = []
        for G in levels(mode):
            B = G.sample(fld, F64); J = G.run(raw, B, F64)
            w = T3.div_wide(J, G); fvd = T3.fv_box(J, G, mode == "axis")
            i0w = 1; i0f = 0 if mode == "axis" else 1
            Jint = Ji(J, G); Jmax = max(nmax(j) for j in Jint); lo, hi = TOL5["region_annulus"] if mode == "annulus" else TOL5["region_axis"]
            # first interior-ring cell inside the div domain (annulus: i = 1 ; axis FV box: i = 0 = the axis cell)
            first_ring_w = nmax(w[0]); first_ring_fv = nmax(fvd["div"][0]); outer_w = nmax(w[-1]); outer_fv = nmax(fvd["div"][-1])
            net = fvd["rhs"]; gross = fvd["gross"]; lhs = fvd["lhs"]
            # DEC reference at the nodes (annulus only): exactly 0 by construction; kernel/DEC distinction recorded
            rows.append(dict(grid=[G.nr, G.nphi, G.nz], h=max(G.dr, G.dz), Jmax=Jmax, wide_region=region_of_div(w, i0w, G, mode), wide_global=nmax(w), fv_region=region_of_div(fvd["div"], i0f, G, mode), fv_global=nmax(fvd["div"]),
                             wide_L2_region=norms(w, None)["L2"], fv_L2_region=norms(fvd["div"], None)["L2"], first_ring_wide=first_ring_w, first_ring_fv=first_ring_fv, outer_ring_wide=outer_w, outer_ring_fv=outer_fv,
                             net_boundary_flux=net, gross_boundary_flux=gross, volume_sum_div=lhs, gauss_identity_err=abs(lhs - net), leakage_over_gross=abs(net)/max(gross, 1e-300),
                             dec_node_div=0.0 if mode == "annulus" else None))
        ent = dict(mode=mode, field=nm, rows=rows)
        fl = [tol_alg(F64, max(r["Jmax"], 1.0)/min(1.0/r["grid"][0], 1.0/r["grid"][2])**1) for r in rows]
        for key, lab in (("wide_region", "wide"), ("fv_region", "fv")):
            ok, o, atf = order_rule([r[key] for r in rows], [tol_alg(F64, max(r["Jmax"], 1.0)/ (min(1.0/r["grid"][0], 1.0/r["grid"][2])**2)) for r in rows]); ent[f"{lab}_region_orders"] = o; ent[f"{lab}_region_ok"] = ok
            if not ok: fails.append(f"042 {mode} {nm}: region div ({lab}) orders {['%.2f' % x for x in o]}")
        for key, lab in (("wide_global", "wide"), ("fv_global", "fv")):
            o = orders_of([r[key] for r in rows]); ent[f"{lab}_global_orders"] = o
            need = TOL5["order_min"] if mode == "annulus" else TOL5["axis_global_order_min"]
            flg = [tol_alg(F64, max(r["Jmax"], 1.0)/(min(1.0/r["grid"][0], 1.0/r["grid"][2])**2)) for r in rows]      # round-off floor of a once-differentiated J
            ent[f"{lab}_global_ok"] = bool(o[-1] >= need or all(r[key] <= f_ for r, f_ in zip(rows, flg))); ent[f"{lab}_global_at_floor"] = bool(all(r[key] <= f_ for r, f_ in zip(rows, flg)))
            if not ent[f"{lab}_global_ok"]: fails.append(f"042 {mode} {nm}: global div ({lab}) orders {['%.2f' % x for x in o]} < {need}")
        og = orders_of([abs(r["net_boundary_flux"]) for r in rows]); ent["boundary_leakage_orders"] = og
        ent["gauss_identity_ok"] = bool(all(r["gauss_identity_err"] <= tol_alg(F64, max(r["gross_boundary_flux"], 1.0)) for r in rows))
        if not ent["gauss_identity_ok"]: fails.append(f"042 {mode} {nm}: FV Gauss identity (sum of div*vol = boundary flux) violated")
        ent["boundary_leakage_ok"] = bool(og[-1] >= TOL5["axis_global_order_min"] or abs(rows[-1]["net_boundary_flux"]) <= tol_alg(F64, rows[-1]["gross_boundary_flux"]))
        if not ent["boundary_leakage_ok"]: fails.append(f"042 {mode} {nm}: net boundary flux of the kernel current does not converge (orders {['%.2f' % x for x in og]})")
        ent["div_is_exactly_zero"] = bool(max(r["wide_global"] for r in rows) <= max(fl)); conv.append(ent)
    res["convergence"] = conv
    res["statement"] = ("A compatible (DEC) complex has div(curl B) = 0 identically; the kernel's cell-centred J does NOT: the wide and finite-volume divergences of J = C(B) equal the closed forms "
                        "D_z[-(1/4rc) delta_r^2 Bphi_c] and -(1/4rc) delta_r^2[(1/rc) D_phi Bz_c] to round-off, i.e. O(h^2) in the interior, first order over all cells on axis grids.  "
                        "The kernel does not write J in ghost cells, so the divergence cannot be evaluated in the outermost interior ring; the first interior ring of the divergence domain is reported.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# independent analytic oracles (special functions, cylindrical fields, numeric curl cross-check)
# ============================================================================
try:
    from scipy import special as _sp
except Exception:                                                  # scipy optional: the series below is the independent implementation
    _sp = None

def _bes_series(m, x, nterms=70):
    """J_m(x), integer m >= 0 by its power series (independent of scipy); valid for negative x too"""
    x = np.asarray(x, dtype=F64); h = 0.5*x; term = np.power(h, m)/math.factorial(m); s = term.copy()
    for k in range(1, nterms):
        term = term*(-h*h)/(k*(k + m)); s = s + term
    return s

def bes(m, x):
    """J_m(x) for integer m (any sign)"""
    x = np.asarray(x, dtype=F64)
    if m < 0: return ((-1)**(-m))*bes(-m, x)
    return _sp.jv(m, x) if _sp is not None else _bes_series(m, x)

def bes_over_x(m, x):
    """J_m(x)/x with the exact limit at x = 0 (m >= 1): h^(m-1)/2 * sum_k (-h^2)^k/(k!(k+m)!)"""
    x = np.asarray(x, dtype=F64); h = 0.5*x; S = np.ones_like(x)/math.factorial(m); term = S.copy()
    for k in range(1, 40):
        term = term*(-h*h)/(k*(k + m)); S = S + term
    ser = 0.5*np.power(h, m - 1)*S
    with np.errstate(all="ignore"): quo = bes(m, x)/x
    return np.where(np.abs(x) < 0.5, ser, quo)

def mkfield(name, Br, Bp, Bz, Jr, Jp, Jz): return C.Field(Br, Bp, Bz, Jr, Jp, Jz, name)

def bessel_field(alpha):
    """axisymmetric force-free field  B = (0, J1(alpha r), J0(alpha r)),  curl B = alpha B  (mu0 = 1)"""
    f0 = lambda r, p, z: bes(0, alpha*r) + 0*p + 0*z; f1 = lambda r, p, z: bes(1, alpha*r) + 0*p + 0*z; zero = lambda r, p, z: 0*r + 0*p + 0*z
    fl = mkfield(f"Bessel alpha={alpha:.4f}", zero, f1, f0, zero, lambda r, p, z: alpha*f1(r, p, z), lambda r, p, z: alpha*f0(r, p, z)); fl.alpha = alpha; return fl

def ck_field(m, alpha, k, delta):
    """Chandrasekhar-Kendall non-axisymmetric Beltrami field built from psi = J_m(lam r) cos(m phi + k z + delta), lam^2 = alpha^2 - k^2,  B = curl(psi zhat) + curl curl(psi zhat)/alpha,
    curl B = alpha B  (hand derivation, verified against a numeric Cartesian curl in the oracle self-check)"""
    lam = math.sqrt(alpha**2 - k**2)
    def parts(r, p, z):
        x = lam*r; Jm = bes(m, x); Jd = 0.5*lam*(bes(m - 1, x) - bes(m + 1, x)); q = lam*bes_over_x(m, x) if m > 0 else 0*x; th = m*p + k*z + delta
        return Jm, Jd, q, th
    def Br(r, p, z): Jm, Jd, q, th = parts(r, p, z); return -m*q*np.sin(th) - k*Jd*np.sin(th)/alpha
    def Bp(r, p, z): Jm, Jd, q, th = parts(r, p, z); return -Jd*np.cos(th) - m*k*q*np.cos(th)/alpha
    def Bz(r, p, z): Jm, Jd, q, th = parts(r, p, z); return lam**2*Jm*np.cos(th)/alpha
    fl = mkfield(f"CK m={m} alpha={alpha} k={k} delta={delta}", Br, Bp, Bz, lambda r, p, z: alpha*Br(r, p, z), lambda r, p, z: alpha*Bp(r, p, z), lambda r, p, z: alpha*Bz(r, p, z)); fl.alpha = alpha; return fl

PIN_A = 0.5
def pinch_field(a=PIN_A):
    zero = lambda r, p, z: 0*r + 0*p + 0*z
    return mkfield(f"Z-pinch Bphi={a}r", zero, lambda r, p, z: a*r + 0*p + 0*z, zero, zero, zero, lambda r, p, z: 2*a + 0*r + 0*p + 0*z)

def screw_field(a=PIN_A, b0=0.8, b2=-0.4):
    zero = lambda r, p, z: 0*r + 0*p + 0*z
    return mkfield(f"screw Bphi={a}r, Bz={b0}+{b2}r^2", zero, lambda r, p, z: a*r + 0*p + 0*z, lambda r, p, z: b0 + b2*r**2 + 0*p + 0*z,
                   zero, lambda r, p, z: -2*b2*r + 0*p + 0*z, lambda r, p, z: 2*a + 0*r + 0*p + 0*z)

def reversed_field(a=PIN_A, b0=0.7, kap=2.6):
    """Bphi = a r (1 - 2 r^2) reverses at r^2 = 1/2;  Bz = b0 cos(kap r) reverses at r = pi/(2 kap)"""
    zero = lambda r, p, z: 0*r + 0*p + 0*z
    return mkfield(f"reversed Bphi=a r(1-2r^2), Bz=b0 cos({kap} r)", zero, lambda r, p, z: a*r*(1 - 2*r**2) + 0*p + 0*z, lambda r, p, z: b0*np.cos(kap*r) + 0*p + 0*z,
                   zero, lambda r, p, z: b0*kap*np.sin(kap*r) + 0*p + 0*z, lambda r, p, z: a*(2 - 8*r**2) + 0*p + 0*z)

def gauss_pinch_field(a=PIN_A):
    """Bphi = a r exp(-r^2), Jz = 2a(1-r^2)exp(-r^2);  force-balanced pressure p = p0 - a^2 exp(-2r^2)(r^2/2 - 1/4)"""
    zero = lambda r, p, z: 0*r + 0*p + 0*z; e = lambda r: np.exp(-r**2)
    return mkfield("Gaussian pinch", zero, lambda r, p, z: a*r*e(r) + 0*p + 0*z, zero, zero, zero, lambda r, p, z: 2*a*(1 - r**2)*e(r) + 0*p + 0*z)

def spec_pinch_pert(m, k, eps, delta, a=PIN_A, b0=0.3, s=0.3):
    """Cartesian-regular field: Z-pinch (Bx,By)=(-a y, a x), Bz=b0, plus the solenoidal helical perturbation curl(psi zhat) with psi = eps Re[(x+iy)^m e^{i(kz+delta)}](1 + s r^2).
    J_pert = (psi_xz, psi_yz, -Laplace_perp psi) with Laplace_perp psi = 4 eps s (1+m) psi0  (psi0 harmonic, degree m).  All hand-derived (checked against a numeric curl)."""
    w = lambda x, y: x + 1j*y; eth = lambda z: np.exp(1j*(k*z + delta))
    psi0 = lambda x, y, z: np.real(w(x, y)**m*eth(z)); dm1 = lambda x, y, z: m*w(x, y)**(m - 1)*eth(z) if m > 1 else m*eth(z)*np.ones_like(x + 0j)
    rho = lambda x, y: x**2 + y**2
    psix = lambda x, y, z: eps*(np.real(dm1(x, y, z))*(1 + s*rho(x, y)) + psi0(x, y, z)*2*s*x)
    psiy = lambda x, y, z: eps*(-np.imag(dm1(x, y, z))*(1 + s*rho(x, y)) + psi0(x, y, z)*2*s*y)
    dz0 = lambda x, y, z: -k*np.imag(w(x, y)**m*eth(z))
    psixz = lambda x, y, z: eps*(-k*np.imag(dm1(x, y, z))*(1 + s*rho(x, y)) + dz0(x, y, z)*2*s*x)
    psiyz = lambda x, y, z: eps*(-k*np.real(dm1(x, y, z))*(1 + s*rho(x, y)) + dz0(x, y, z)*2*s*y)
    return (lambda x, y, z: -a*y + psiy(x, y, z), lambda x, y, z: a*x - psix(x, y, z), lambda x, y, z: b0 + 0*x + 0*z,
            lambda x, y, z: psixz(x, y, z), lambda x, y, z: psiyz(x, y, z), lambda x, y, z: 2*a - 4*eps*s*(1 + m)*psi0(x, y, z))

def numeric_cyl_curl(fld, pts):
    """6th-order Cartesian curl of a cylindrical Field at points (r, phi, z) - no cylindrical formula involved; returns (Jr, Jphi, Jz)"""
    r, p, z = pts; x0, y0 = r*np.cos(p), r*np.sin(p)
    def comp(x, y, zz):
        rr = np.hypot(x, y); pp = np.arctan2(y, x); br, bp, bz = fld.Br(rr, pp, zz), fld.Bp(rr, pp, zz), fld.Bz(rr, pp, zz)
        return br*np.cos(pp) - bp*np.sin(pp), br*np.sin(pp) + bp*np.cos(pp), bz
    c = {-3: -1/60, -2: 3/20, -1: -3/4, 1: 3/4, 2: -3/20, 3: 1/60}; h = 1e-3
    def d(ci, axis):
        out = 0.0
        for kk, ck in c.items():
            q = [x0, y0, z]; q[axis] = q[axis] + kk*h; out = out + ck*comp(*q)[ci]
        return out/h
    Jx = d(2, 1) - d(1, 2); Jy = d(0, 2) - d(2, 0); Jzc = d(1, 0) - d(0, 1)
    return Jx*np.cos(p) + Jy*np.sin(p), -Jx*np.sin(p) + Jy*np.cos(p), Jzc

def oracle_self_check():
    """every analytic current used in Campaign 05 against an independent numeric curl, plus the properties each oracle claims (Beltrami J = alpha B, analytic continuation to r < 0, Bessel series vs scipy)"""
    rng = np.random.default_rng(5); pts = (rng.uniform(0.15, 1.45, 200), rng.uniform(0, 2*math.pi, 200), rng.uniform(-0.5, 0.5, 200)); rows = []
    flds = [pinch_field(), screw_field(), reversed_field(), gauss_pinch_field(), bessel_field(2.0), bessel_field(TOL5["beltrami_alphas"][1]), bessel_field(5.5),
            ck_field(1, 4.0, 1.5, 0.3), ck_field(2, 5.0, 2.0, 1.1), ck_field(3, 6.0, 2.5, 0.0), ck_field(0, 4.0, 1.5, 0.4)]
    for m_, k_, e_, d_ in ((1, 2*math.pi, 0.1, 0.0), (2, 4*math.pi, 0.3, 1.1), (3, 2*math.pi, 0.05, 2.9)):
        flds.append(cart_fld(f"pinch+helical m={m_}", spec_pinch_pert(m_, k_, e_, d_)) if False else C._cart_field(*spec_pinch_pert(m_, k_, e_, d_), f"pinch+helical m={m_} k={k_:.3f} eps={e_} delta={d_}"))
    for fld in flds:
        num = numeric_cyl_curl(fld, pts); ref = (fld.Jr(*pts), fld.Jp(*pts), fld.Jz(*pts)); sc = max(float(np.max(np.abs(x))) for x in ref) + 1e-30
        row = dict(field=fld.name, max_abs_diff_vs_numeric_curl=max(float(np.max(np.abs(a - b))) for a, b in zip(num, ref)), scale=sc)
        row["ok"] = bool(row["max_abs_diff_vs_numeric_curl"] <= 1e-7*max(sc, 1.0)); rows.append(row)
    chk = dict(rows=rows)
    xs = np.linspace(-9, 9, 401); chk["bessel_series_vs_reference_max_abs"] = max(float(np.max(np.abs(_bes_series(m, xs) - (_sp.jv(m, xs) if _sp is not None else _bes_series(m, xs))))) for m in range(0, 4))
    chk["scipy_available"] = _sp is not None
    chk["bessel_ratio_origin"] = [float(bes_over_x(1, np.array([0.0]))[0]), float(bes_over_x(2, np.array([0.0]))[0]), float(bes_over_x(1, np.array([0.3]))[0]), float(0.3 and bes(1, 0.3)/0.3)]
    f = ck_field(2, 5.0, 2.0, 1.1); r_, p_, z_ = 0.4, 0.7, 0.1; a = [f.Br(-r_, p_, z_), f.Bp(-r_, p_, z_), f.Bz(-r_, p_, z_)]; b = [-f.Br(r_, p_ + math.pi, z_), -f.Bp(r_, p_ + math.pi, z_), f.Bz(r_, p_ + math.pi, z_)]      # same Cartesian point (r<0, phi) = (|r|, phi+pi); the cylindrical unit vectors flip sign
    chk["negative_r_continuation_err"] = float(max(abs(u - v) for u, v in zip(a, b)))
    bf = bessel_field(2.0); chk["beltrami_J_minus_alphaB"] = float(max(abs(bf.Jp(0.7, 0, 0) - 2.0*bf.Bp(0.7, 0, 0)), abs(bf.Jz(0.7, 0, 0) - 2.0*bf.Bz(0.7, 0, 0))))
    gl = gauss_pinch_field(); rr = np.linspace(0.0, 1.5, 4001); Fr = -gl.Jz(rr, 0, 0)*gl.Bp(rr, 0, 0); pfun = lambda r: -PIN_A**2*np.exp(-2*r**2)*(r**2/2 - 0.25)
    chk["gauss_pinch_pressure_derivative_err"] = float(np.max(np.abs(np.gradient(pfun(rr), rr, edge_order=2) - Fr)[2:-2]))
    chk["ok"] = bool(all(r["ok"] for r in rows) and chk["bessel_series_vs_reference_max_abs"] < 1e-11 and chk["negative_r_continuation_err"] < 1e-12 and chk["beltrami_J_minus_alphaB"] < 1e-14 and chk["gauss_pinch_pressure_derivative_err"] < 1e-6
                     and abs(chk["bessel_ratio_origin"][0] - 0.5) < 1e-15 and chk["bessel_ratio_origin"][1] == 0.0 and abs(chk["bessel_ratio_origin"][2] - chk["bessel_ratio_origin"][3]) < 1e-14)
    return chk

def B_centres(G, fld):
    """analytic B at the interior cell centres (FP64): the location of the kernel's J"""
    g = G.g; R, P, Z = G.mesh(G.rc[g:g + G.nr], G.pc[g:g + G.nphi], G.zc[g:g + G.nz]); return [np.asarray(f(R, P, Z), dtype=F64) for f in (fld.Br, fld.Bp, fld.Bz)]

def Bcc_interior(B, G): return [Iv(a, G) for a in cc(B)]

def cross(a, b): return [a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0]]

def vnorms(comps, mask):
    """L1/L2/Linf of the vector error magnitude over the mask, plus per-component Linf"""
    mag = np.sqrt(sum(np.asarray(c, dtype=F64)**2 for c in comps)); n = norms(mag, mask); n["comp_Linf"] = [norms(c, mask)["Linf"] for c in comps]; return n

def order_checks(rows, mode, key_reg, key_glob, floors_reg, floors_glob, label, fails, glob_annulus_ok=True):
    """standard acceptance rule: region second order (or at floor); annulus global second order (or at floor); axis global >= first order (or at floor)"""
    er = [r[key_reg] for r in rows]; eg = [r[key_glob] for r in rows]
    okr, o_r, atf = order_rule(er, floors_reg); og = orders_of(eg)
    need = TOL5["order_min"] if mode == "annulus" else TOL5["axis_global_order_min"]; okg = bool(og[-1] >= need or all(e <= f for e, f in zip(eg, floors_glob)))
    if not okr: fails.append(f"{label}: region orders {['%.2f' % x for x in o_r]} < {TOL5['order_min']}")
    if not okg: fails.append(f"{label}: global orders {['%.2f' % x for x in og]} < {need}")
    return dict(region_orders=o_r, region_ok=okr, region_at_floor=atf, global_orders=og, global_ok=okg)

# ============================================================================
# TEST 043  Analytic force-free (Beltrami) fields
# ============================================================================
def beltrami_set():
    return [bessel_field(a) for a in TOL5["beltrami_alphas"]] + [ck_field(0, 4.0, 1.5, 0.4), ck_field(1, 4.0, 1.5, 0.3), ck_field(2, 5.0, 2.0, 1.1)]

def downsample(a, n=48):
    a = np.asarray(a); idx = np.unique(np.linspace(0, len(a) - 1, min(n, len(a))).astype(int)); return [float(a[i]) for i in idx]

def t043(be):
    res = dict(); fails = []; raw = H.backend_for(be)
    oc = oracle_self_check(); res["oracle_self_check"] = oc
    if not oc["ok"]: fails.append("043 oracle self-check failed (analytic fields do not match the numeric curl)")
    cases = []
    for fld in beltrami_set():
        al = fld.alpha
        for mode in ("annulus", "axis"):
            rows = []
            for G in levels(mode):
                B = G.sample(fld, F64); J = kern(G, raw, B, F64); Bex = B_centres(G, fld); Jref = sample_J_ref(G, fld)
                err = [J[c] - al*Bex[c] for c in range(3)]; rm = region_mask(G, mode); r0 = ring_mask(G, 0)
                nreg, nall, n0 = vnorms(err, rm), vnorms(err, None), vnorms(err, r0)
                Bcc = Bcc_interior(B, G); F = cross(J, Bcc); Fmag = np.sqrt(sum(f_**2 for f_ in F)); JB = np.sqrt(sum(j**2 for j in J))*np.sqrt(sum(b**2 for b in Bcc))
                with np.errstate(all="ignore"): frac = np.where(rm & (JB > 1e-12), Fmag/JB, 0.0)
                row = dict(grid=[G.nr, G.nphi, G.nz], h=max(G.dr, G.dz), region=nreg, global_=nall, ring0=n0, oracle_identity_err=max(nmax(Jref[c] - al*Bex[c]) for c in range(3)),
                           Bmax=bmax_of(B), Jmax=max(nmax(j) for j in J), floor=tol_alg(F64, bmax_of(B)*max(al, 1.0)/hmin_of(G)), lorentz_over_JB_region=float(frac.max()), kappa=kappa_of(G))
                if G.nr >= 2 and mode == "annulus":                                   # location control: compare J(i) with alpha*B at the cell i-1 (a deliberately mislocated oracle)
                    wrong = [J[c][1:] - al*Bex[c][:-1] for c in range(3)]; row["mislocated_oracle_region_Linf"] = vnorms(wrong, rm[1:])["Linf"]
                rows.append(row)
            fl_ = [r["floor"] for r in rows]; ent = dict(field=fld.name, alpha=al, mode=mode, rows=rows)
            ent.update(order_checks([dict(a=r["region"]["Linf"], b=r["global_"]["Linf"]) for r in rows], mode, "a", "b", fl_, fl_, f"043 {fld.name} {mode}", fails))
            o0 = orders_of([r["ring0"]["Linf"] for r in rows]); ent["ring0_orders"] = o0; ent["ring0_abs_err"] = [r["ring0"]["Linf"] for r in rows]
            if mode == "axis" and not (o0[-1] >= TOL5["axis_global_order_min"] or all(r["ring0"]["Linf"] <= f_ for r, f_ in zip(rows, fl_))): fails.append(f"043 {fld.name} axis: first-ring error does not converge ({['%.2f' % x for x in o0]})")
            ent["lorentz_orders"] = orders_of([r["lorentz_over_JB_region"] for r in rows]); lo = ent["lorentz_orders"][-1]
            if not (lo >= TOL5["order_min"] or all(r["lorentz_over_JB_region"] <= 1e-12 for r in rows)): fails.append(f"043 {fld.name} {mode}: residual force |J x B|/(|J||B|) orders {['%.2f' % x for x in ent['lorentz_orders']]}")
            if max(r["oracle_identity_err"] for r in rows) > 1e-12*max(1.0, al): fails.append(f"043 {fld.name}: oracle identity J_ref = alpha B violated")
            if mode == "annulus":
                mr = rows[-1].get("mislocated_oracle_region_Linf"); ok_ = rows[-1]["region"]["Linf"]; ent["location_control_ratio"] = (mr/ok_) if ok_ > 0 else math.inf
                if not ent["location_control_ratio"] >= TOL5["neg_control_min_ratio"]: fails.append(f"043 {fld.name}: location control (mislocated oracle) not detected (ratio {ent['location_control_ratio']:.1f})")
            G = levels(mode)[-1]; B = G.sample(fld, F64); J = kern(G, raw, B, F64); Bex = B_centres(G, fld); jm = G.nphi//2; km = G.nz//2; rcs = G.rc[G.g:G.g + G.nr]
            ent["profile"] = dict(r=downsample(rcs), Jphi=downsample(J[1][:, jm, km]), alphaBphi=downsample(al*Bex[1][:, jm, km]), Jz=downsample(J[2][:, jm, km]), alphaBz=downsample(al*Bex[2][:, jm, km]),
                                  err_phi=downsample(np.abs(J[1][:, jm, km] - al*Bex[1][:, jm, km])), err_z=downsample(np.abs(J[2][:, jm, km] - al*Bex[2][:, jm, km])))
            # FP32: FP32-vs-FP64-kernel consistency on identical stored inputs; absolute error vs analytic reported
            rows32 = []
            for G in levels(mode, 3):
                B32 = G.sample(fld, F32); fc = fp32_consistency(G, raw, B32); J32 = kern(G, raw, B32, F32); Bex = B_centres(G, fld)
                fc["abs_err_vs_analytic_region"] = vnorms([J32[c] - al*Bex[c] for c in range(3)], region_mask(G, mode))["Linf"]; fc["non_discriminating"] = bool(fc["bound"] > TOL5["disc_fraction"]*fc["Jmax"]); fc["grid"] = [G.nr, G.nphi, G.nz]; rows32.append(fc)
            ent["fp32"] = rows32
            if not all(r["ok"] for r in rows32): fails.append(f"043 {fld.name} {mode} FP32: FP32 vs FP64-kernel difference exceeds the round-off bound")
            cases.append(ent)
    res["cases"] = cases
    res["statement"] = ("J - alpha*B is evaluated with B at the analytic CELL CENTRES (where the kernel's J lives), never at the staggered face positions; a control that compares against B one cell away is detected "
                        f"(ratio >= {TOL5['neg_control_min_ratio']:g}).  The residual force J x B(cell-centred) of a force-free field is measured, not assumed to vanish.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 044  Hall electric field E_H = eta_H (J x B)
# ============================================================================
def hall_fields():
    return [pinch_field(), screw_field(), reversed_field(), ck_field(1, 4.0, 1.5, 0.3), C.SMOOTH, C.KINK, C._cart_field(*spec_pinch_pert(2, 2*math.pi, 0.3, 1.1), "pinch + helical m=2 (eps 0.3)")]

def hall_E(J, Bc, eta): return [eta*c for c in cross(J, Bc)]

def t044(be):
    res = dict(); fails = []; raw = H.backend_for(be); eta = TOL5["hall_eta"]; cases = []
    for fld in hall_fields():
        for mode in ("annulus", "axis"):
            rows = []
            for G in levels(mode):
                B = G.sample(fld, F64); J = kern(G, raw, B, F64); Bc = Bcc_interior(B, G); Bex = B_centres(G, fld); Jref = sample_J_ref(G, fld)
                E = hall_E(J, Bc, eta); Eref = hall_E(Jref, Bex, eta); err = [E[c] - Eref[c] for c in range(3)]; rm = region_mask(G, mode)
                eJ = [eta*c for c in cross([J[c] - Jref[c] for c in range(3)], Bex)]; eB = [eta*c for c in cross(Jref, [Bc[c] - Bex[c] for c in range(3)])]       # split: error from J / from the B interpolation
                nreg = vnorms(err, rm); nall = vnorms(err, None); sig = TOL5["sign_signal_factor"]*max(nreg["Linf"], 1e-300)
                sign_bad = 0; sign_n = 0
                for c in range(3):
                    m_ = rm & (np.abs(Eref[c]) > sig); sign_n += int(m_.sum()); sign_bad += int((np.sign(E[c][m_]) != np.sign(Eref[c][m_])).sum())
                nE = np.sqrt(sum(e_**2 for e_ in E)); nR = np.sqrt(sum(e_**2 for e_ in Eref)); m_ = rm & (nR > sig)
                with np.errstate(all="ignore"): cosang = np.where(m_, sum(E[c]*Eref[c] for c in range(3))/np.maximum(nE*nR, 1e-300), 1.0)
                ang = float(np.arccos(np.clip(cosang.min(), -1, 1)))
                nB = np.sqrt(sum(b**2 for b in Bc)); ndot = np.where(m_, np.abs(sum(E[c]*Bc[c] for c in range(3)))/np.maximum(nE*nB, 1e-300), 0.0)
                rows.append(dict(grid=[G.nr, G.nphi, G.nz], region=nreg, global_=nall, ring0=vnorms(err, ring_mask(G, 0)), err_from_J_Linf=vnorms(eJ, rm)["Linf"], err_from_Binterp_Linf=vnorms(eB, rm)["Linf"],
                                 sign_cells=sign_n, sign_violations=sign_bad, max_angle_rad=ang, max_E_dot_B_over_EB=float(ndot.max()), Emax=max(nmax(e_) for e_ in Eref), floor=tol_alg(F64, eta*bmax_of(B)**2/hmin_of(G))))
            fl_ = [r["floor"] for r in rows]; ent = dict(field=fld.name, mode=mode, rows=rows)
            ent.update(order_checks([dict(a=r["region"]["Linf"], b=r["global_"]["Linf"]) for r in rows], mode, "a", "b", fl_, fl_, f"044 {fld.name} {mode}", fails))
            if any(r["sign_violations"] for r in rows): fails.append(f"044 {fld.name} {mode}: sign violations {[r['sign_violations'] for r in rows]} of {[r['sign_cells'] for r in rows]} cells")
            if rows[-1]["max_angle_rad"] > TOL5["align_max_angle"]: fails.append(f"044 {fld.name} {mode}: E_H misaligned by {rows[-1]['max_angle_rad']:.3f} rad at the finest level")
            ent["component_Linf_orders"] = [orders_of([r["region"]["comp_Linf"][c] for r in rows]) for c in range(3)]
            rows32 = []
            for G in levels(mode, 3):
                B32 = G.sample(fld, F32); fc = fp32_consistency(G, raw, B32); J32 = kern(G, raw, B32, F32); J64 = kern(G, raw, [b.astype(F64) for b in B32], F64); Bc = Bcc_interior(B32, G)
                dE = max(nmax(a_ - b_) for a_, b_ in zip(hall_E(J32, Bc, eta), hall_E(J64, Bc, eta))); bE = 2.0*eta*bmax_of(B32)*fc["bound"] + 8*EPS[F32]*eta*bmax_of(B32)*max(fc["Jmax"], 1.0)
                Emax = max(nmax(e_) for e_ in hall_E(J64, Bc, eta)); rows32.append(dict(grid=[G.nr, G.nphi, G.nz], diff=dE, bound=bE, ok=bool(dE <= bE), non_discriminating=bool(bE > TOL5["disc_fraction"]*Emax), Emax=Emax))
            ent["fp32"] = rows32
            if not all(r["ok"] for r in rows32): fails.append(f"044 {fld.name} {mode} FP32: E_H(FP32 J) differs from E_H(FP64 J) on identical inputs beyond the bound")
            cases.append(ent)
    res["cases"] = cases
    # ---- negative controls: the checker must DETECT each of these implementation errors (annulus, finest level, a field with all components non-zero)
    ctr = []; mu0 = TOL5["mu0_phys"]
    for fld in (C.SMOOTH, screw_field(), C.KINK, C._cart_field(*spec_pinch_pert(2, 2*math.pi, 0.3, 1.1), "pinch + helical m=2 (eps 0.3)")):        # force-free fields are excluded: J x B = 0 leaves a control no signal
        G = levels("annulus")[-1]; B = G.sample(fld, F64); J = kern(G, raw, B, F64); Bc = Bcc_interior(B, G); Bex = B_centres(G, fld); Jref = sample_J_ref(G, fld); rm = region_mask(G, "annulus")
        Eref_phys = hall_E([x/mu0 for x in Jref], Bex, eta); mk = lambda E_: vnorms([E_[c] - Eref_phys[c] for c in range(3)], rm)["Linf"]
        correct = mk(hall_E([x/mu0 for x in J], Bc, eta)); nref = max(nmax(e_) for e_ in Eref_phys)
        g_ = G.g; lowB = [B[0][g_:g_ + G.nr, g_:g_ + G.nphi, g_:g_ + G.nz].astype(F64), B[1][g_:g_ + G.nr, g_:g_ + G.nphi, g_:g_ + G.nz].astype(F64), B[2][g_:g_ + G.nr, g_:g_ + G.nphi, g_:g_ + G.nz].astype(F64)]
        wrong = {"missing 1/mu0 (J used as if mu0 = 1 in SI units)": hall_E(J, Bc, eta), "1/mu0 applied twice": hall_E([x/mu0**2 for x in J], Bc, eta),
                 "B taken from the lower faces instead of the centre average": hall_E([x/mu0 for x in J], lowB, eta), "cross product order reversed (B x J)": [-e_ for e_ in hall_E([x/mu0 for x in J], Bc, eta)],
                 "J one radial cell off (mislocated)": hall_E([np.roll(x, 1, 0)/mu0 for x in J], Bc, eta)}
        for nm, E_ in wrong.items():
            e_w = mk(E_); ratio = e_w/correct if correct > 0 else math.inf
            degenerate = bool(abs(e_w - correct) <= 1e-9*max(nref, 1e-30))                 # the wrong and the correct implementation coincide for this field (e.g. the field does not depend on the staggered coordinate)
            ctr.append(dict(field=fld.name, control=nm, error_wrong=e_w, error_correct=correct, ratio=ratio, E_scale=nref, degenerate=degenerate,
                            detected=None if degenerate else bool(ratio >= TOL5["neg_control_min_ratio"])))

        ctr.append(dict(field=fld.name, control="CORRECT implementation, SI units (mu0 = 4 pi 1e-7, caller divides once)", error_wrong=correct, error_correct=correct, ratio=1.0, E_scale=nref, detected=None, rel_err=correct/nref))
    res["negative_controls"] = ctr
    for nm in sorted({c["control"] for c in ctr if c.get("detected") is not None or c.get("degenerate")}):
        if "CORRECT" in nm: continue
        nd = [c for c in ctr if c["control"] == nm and c.get("detected") is not None]; det = [c for c in nd if c["detected"]]
        if len(det) < max(1, math.ceil(0.75*len(nd))): fails.append(f"044 negative control '{nm}' detected on only {len(det)} of {len(nd)} fields with signal (ratios {['%.1f' % c['ratio'] for c in nd]})")
    res["statement"] = (f"E_H = eta_H (J x B) with eta_H = {TOL5['hall_eta']} (!= 1, so a missing factor is visible).  J is the kernel output at the cell centres, B the face average at the same centres; the oracle is the "
                        "analytic cylindrical cross product at the same centres.  The kernel returns curl B (mu0 = 1): the 1/mu0 division is the caller's job, performed exactly once.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# volume integrals of analytic fields (Gauss-Legendre x periodic trapezoid): the independent oracle of 045 / 047
# ============================================================================
def analytic_volume_integral(fn, r0, r1, z0, z1, r_breaks=(), nr_gl=40, nz_gl=32, nphi=96):
    edges = [r0] + [b for b in r_breaks if r0 < b < r1] + [r1]; total = 0.0
    xg, wg = np.polynomial.legendre.leggauss(nr_gl); zg, wz = np.polynomial.legendre.leggauss(nz_gl)
    zz = 0.5*(z1 - z0)*zg + 0.5*(z1 + z0); wzz = 0.5*(z1 - z0)*wz; ph = (np.arange(nphi) + 0.5)*2*math.pi/nphi; wph = 2*math.pi/nphi
    for a, b in zip(edges[:-1], edges[1:]):
        rr = 0.5*(b - a)*xg + 0.5*(b + a); wrr = 0.5*(b - a)*wg
        R, P, Z = np.meshgrid(rr, ph, zz, indexing="ij"); vals = fn(R, P, Z)*R
        total += float(np.einsum("ijk,i,k->", vals, wrr, wzz)*wph)
    return total

# ============================================================================
# TEST 045  Resistive dissipation   J . E_eta = eta |J|^2
# ============================================================================
def eta_profiles():
    return {"constant eta=0.1": (lambda r, p, z: 0.1 + 0*r + 0*p + 0*z, ()), "eta = 0 (ideal)": (lambda r, p, z: 0*r + 0*p + 0*z, ()),
            "spatially varying eta>0": (lambda r, p, z: 0.06 + 0.05*np.sin(2*p)*np.cos(2*math.pi*z) + 0.02*r, ()),
            "compact: 0 for r<1, 0.5(r-1)^2 outside": (lambda r, p, z: 0.5*np.maximum(r - 1.0, 0.0)**2 + 0*p + 0*z, (1.0,))}

def t045(be):
    res = dict(); fails = []; raw = H.backend_for(be); cases = []
    flds = [pinch_field(), screw_field(), C.SMOOTH, ck_field(1, 4.0, 1.5, 0.3)]
    for fld in flds:
        for ename, (efn, brk) in eta_profiles().items():
            for mode in ("annulus", "axis"):
                rows = []
                for G in levels(mode):
                    B = G.sample(fld, F64); J = kern(G, raw, B, F64); Jref = sample_J_ref(G, fld); g = G.g
                    R, P, Zm = interior_mesh(G); eta = efn(R, P, Zm); Eeta = [eta*j for j in J]; Pn = sum(J[c]*Eeta[c] for c in range(3)); Pref = eta*sum(Jref[c]**2 for c in range(3))
                    vol = (G.rc[g:g + G.nr][:, None, None]*G.dr*G.dphi*G.dz)*np.ones((1, G.nphi, G.nz)); rm = region_mask(G, mode)
                    Vn = float(np.sum(Pn*vol)); Vm = float(np.sum(Pref*vol)); Vx = analytic_volume_integral(lambda r, p, z: efn(r, p, z)*sum(f_(r, p, z)**2 for f_ in (fld.Jr, fld.Jp, fld.Jz)), G.rf[g], G.rf[g + G.nr], G.z0, G.z0 + G.nz*G.dz, brk)
                    Bc = Bcc_interior(B, G); Wn = float(np.sum(0.5*sum(b**2 for b in Bc)*vol)); Wx = analytic_volume_integral(lambda r, p, z: 0.5*sum(f_(r, p, z)**2 for f_ in (fld.Br, fld.Bp, fld.Bz)), G.rf[g], G.rf[g + G.nr], G.z0, G.z0 + G.nz*G.dz)
                    rows.append(dict(grid=[G.nr, G.nphi, G.nz], min_P=float(Pn.min()), n_negative=int((Pn < 0).sum()), P_where_eta0_max=(float(np.abs(Pn[eta == 0]).max()) if (eta == 0).any() else None), n_eta0=int((eta == 0).sum()),
                                     err_P_region=norms(Pn - Pref, rm)["Linf"], err_P_global=norms(Pn - Pref, None)["Linf"], Pmax=float(np.abs(Pref).max()), V_num=Vn, V_midpoint_ref=Vm, V_exact=Vx, V_rel_err=abs(Vn - Vx)/max(abs(Vx), 1e-300), V_vs_midpoint_rel=abs(Vn - Vm)/max(abs(Vx), 1e-300),
                                     V_fsum_diff=abs(math.fsum((Pn*vol).ravel().tolist()) - Vn), W_num=Wn, W_exact=Wx, W_rel_err=abs(Wn - Wx)/Wx, floor=tol_alg(F64, bmax_of(B)**2/hmin_of(G)**2)))
                ent = dict(field=fld.name, eta=ename, mode=mode, rows=rows)
                if any(r["n_negative"] for r in rows): fails.append(f"045 {fld.name} / {ename} / {mode}: NEGATIVE local dissipation (min {min(r['min_P'] for r in rows):.3e})")
                if any((r["P_where_eta0_max"] or 0.0) != 0.0 for r in rows): fails.append(f"045 {fld.name} / {ename} / {mode}: P != 0 where eta == 0")
                fl_ = [r["floor"] for r in rows]; ent.update(order_checks([dict(a=r["err_P_region"], b=r["err_P_global"]) for r in rows], mode, "a", "b", fl_, fl_, f"045 {fld.name} / {ename} / {mode} P", fails))
                if ename.startswith("eta = 0"):
                    if any(r["Pmax"] != 0.0 or r["err_P_global"] != 0.0 for r in rows): fails.append(f"045 {fld.name} / eta = 0: dissipation not exactly zero")
                else:
                    ent["V_orders"] = orders_of([r["V_rel_err"] for r in rows]); ent["W_orders"] = orders_of([r["W_rel_err"] for r in rows])
                    for key, o in (("V", ent["V_orders"]), ("W", ent["W_orders"])):
                        errs = [r[f"{key}_rel_err"] for r in rows]
                        if not (o[-1] >= TOL5["order_min"] or all(e <= 1e-12 for e in errs)): fails.append(f"045 {fld.name} / {ename} / {mode}: volume-integrated {'dissipation' if key == 'V' else 'magnetic energy'} orders {['%.2f' % x for x in o]}")
                    if max(r["V_fsum_diff"] for r in rows) > 1e-9*max(abs(r["V_num"]) for r in rows): fails.append(f"045 {fld.name} / {ename}: summation inconsistency")
                cases.append(ent)
    res["cases"] = cases
    # the non-negativity check must be able to FAIL: eta < 0 is flagged
    G = levels("annulus")[0]; B = G.sample(C.SMOOTH, F64); J = kern(G, raw, B, F64); eta = -0.1 + 0*J[0]; Pn = sum(J[c]*(eta*J[c]) for c in range(3))
    res["negative_eta_control"] = dict(min_P=float(Pn.min()), n_negative=int((Pn < 0).sum()), detected=bool((Pn < 0).any())); 
    if not res["negative_eta_control"]["detected"]: fails.append("045 control: eta < 0 not flagged by the non-negativity check")
    res["fp32"] = []
    for fld in (C.SMOOTH, screw_field()):
        for G in levels("annulus", 3):
            B32 = G.sample(fld, F32); J32 = kern(G, raw, B32, F32); eta = 0.06 + 0.02*G.rc[G.g:G.g + G.nr][:, None, None]*np.ones((1, G.nphi, G.nz)); P32 = eta*sum(J32[c]*J32[c] for c in range(3))
            J64 = kern(G, raw, [b.astype(F64) for b in B32], F64); P64 = eta*sum(J64[c]**2 for c in range(3)); fc = fp32_consistency(G, raw, B32)
            bound = 2*fc["Jmax"]*fc["bound"]*float(eta.max()) + 8*EPS[F32]*float(P64.max()); res["fp32"].append(dict(field=fld.name, grid=[G.nr, G.nphi, G.nz], min_P=float(P32.min()), diff=nmax(P32 - P64), bound=bound, ok=bool(P32.min() >= 0 and nmax(P32 - P64) <= bound), non_discriminating=bool(bound > TOL5["disc_fraction"]*float(P64.max()))))
    if not all(r["ok"] for r in res["fp32"]): fails.append("045 FP32: dissipation negative or inconsistent with FP64")
    res["statement"] = ("J.E_eta = eta|J|^2 is a local, isolated diagnostic of the kernel output: non-negativity, exact zero where eta = 0, second-order agreement with the analytic eta|J|^2 and with the analytic volume integral "
                        "(Gauss-Legendre x periodic trapezoid) are verified.  NOTHING here is evidence of full-system magnetic energy conservation: the Poynting / induction balance involves the CT update, "
                        "the Hall and ideal EMFs and boundary fluxes, none of which is exercised by this kernel.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# the real driver (magnetic-state / geometry / boundary interfaces) - loaded UNMODIFIED when present; absent => the dependent checks are BLOCKED
# ============================================================================
DRIVER_NAME = "Aladin_Driver_v3.1_AIL.py"
_DRIVER_CACHE = {}

def find_driver():
    for d in (HERE, os.getcwd(), os.path.dirname(HERE), os.path.join(HERE, "driver")):
        p = os.path.join(d, DRIVER_NAME)
        if os.path.isfile(p): return p
    return None

def load_driver():
    if "mod" in _DRIVER_CACHE: return _DRIVER_CACHE["mod"]
    p = find_driver(); mod = None
    if p:
        try:
            blocked = []
            def _no_pip(cmd, *a, **k): blocked.append(" ".join(map(str, cmd))); raise subprocess.CalledProcessError(1, cmd)                    # the driver installs packages at import time: refused (immutable environment)
            _orig = subprocess.check_call; subprocess.check_call = _no_pip
            try:
                spec = importlib.util.spec_from_file_location("aladin_driver", p); mod = importlib.util.module_from_spec(spec); sys.modules["aladin_driver"] = mod
                _so = sys.stdout; sys.stdout = io.StringIO()
                try: spec.loader.exec_module(mod)
                finally: _cap = sys.stdout.getvalue(); sys.stdout = _so
            finally: subprocess.check_call = _orig
            mod._campaign_path = p; mod._campaign_sha = hashlib.sha256(open(p, "rb").read()).hexdigest(); mod._import_pip_attempts_blocked = [b.replace(sys.executable, "python") for b in blocked]; mod._import_stdout = _cap.strip()[:300]
        except Exception:
            mod = None; _DRIVER_CACHE["error"] = traceback.format_exc()[-1500:]
    _DRIVER_CACHE["mod"] = mod; return mod

def driver_state(drv, nr, nphi, nz, r_min, r_max, z_min=-0.5, z_max=0.5, fld=None, ic=None, apply_bc=True):
    """REAL driver objects: ALADINConfig, GeometryManager, GridManager, StateRegistry, BoundaryManager.  The staggered B arrays are either filled from an analytic field sampled at the
    kernel's staggered positions (fld) or by the driver's own initial-condition function (ic = 'zpinch'); the driver's boundary manager is then applied exactly as ExecutionController.step does."""
    cfg = drv.ALADINConfig(nr=nr, nphi=nphi, nz=nz, r_min=r_min, r_max=r_max, z_min=z_min, z_max=z_max, nghost=2, precision="float32", backend="numpy")
    cfg.validate(); geo = drv.GeometryManager(cfg); grid = drv.GridManager(cfg, geo); st = drv.StateRegistry(cfg, geo, grid); bnd = drv.BoundaryManager(cfg, geo, grid)
    G = C.Grid(nr, nphi, nz, g=2, r0=r_min, r1=r_max, z0=z_min, z1=z_max)
    if fld is not None:
        B = G.sample(fld, F32)
        for nm, a in zip(("Br", "Bphi", "Bz"), B):
            if st.fields[nm].shape != a.shape: raise RuntimeError(f"driver state shape {st.fields[nm].shape} != kernel contract {a.shape} for {nm}")
            st.fields[nm][...] = a
    elif ic == "zpinch": drv.set_zpinch(st, geo)
    if apply_bc: bnd.apply_all(st)
    return cfg, geo, grid, st, bnd, G

def kernel_args_from_driver(cfg, geo, st):
    """the ADAPTATION layer (harness-owned, documented): the driver's GeometryManager holds r_faces / r_centers WITHOUT ghost entries, the kernel needs them WITH ghosts.  Built here from the driver's own r_min, r_max, nr
    (float64, then cast); the driver's interior arrays are checked against them.  The driver has no storage for J: the three J arrays are harness-owned."""
    g = cfg.nghost; nr = cfg.nr; dr = (cfg.r_max - cfg.r_min)/nr; dphi = 2*math.pi/cfg.nphi; dz = (cfg.z_max - cfg.z_min)/cfg.nz
    rf = cfg.r_min + (np.arange(nr + 1 + 2*g) - g)*dr; rc = 0.5*(rf[:-1] + rf[1:]); dt = st.fields["Br"].dtype
    interior_rf_dev = float(np.max(np.abs(rf[g:g + nr + 1] - np.asarray(geo.r_faces, dtype=F64)))); interior_rc_dev = float(np.max(np.abs(rc[g:g + nr] - np.asarray(geo.r_centers, dtype=F64))))
    B = [np.ascontiguousarray(st.fields[n]) for n in ("Br", "Bphi", "Bz")]
    return B, rf.astype(dt), rc.astype(dt), dr, dphi, dz, dict(interior_rf_dev=interior_rf_dev, interior_rc_dev=interior_rc_dev, dtype=str(dt))

# ============================================================================
# TEST 046  Z-pinch Lorentz-force consistency, force-balanced pressure, axis regularity
# ============================================================================
def equilibrium_pressure(name):
    """analytic force-balanced pressure p(r) with dp/dr = (J x B)_r = Jphi Bz - Jz Bphi (p0 + antiderivative), per analytic field"""
    a = PIN_A; p0 = TOL5["pressure_p0"]
    if name.startswith("Z-pinch"): return lambda r: p0 - a**2*r**2
    if name.startswith("screw"): b0, b2 = 0.8, -0.4; return lambda r: p0 - (b2*b0 + a**2)*r**2 - 0.5*b2**2*r**4
    if name.startswith("Gaussian"): return lambda r: p0 - a**2*np.exp(-2*r**2)*(r**2/2 - 0.25)
    raise KeyError(name)

def maxwell_stress_residual(fld, pfun, G):
    """HARNESS reference (not a driver component): conservative-form radial force balance of an axisymmetric field with Br = 0:
         R_cons(i) = -(1/rc)[rf_{i+1} T_rr(rf_{i+1}) - rf_i T_rr(rf_i)]/dr + T_phiphi(rc)/rc,   T_rr = p + (Bphi^2 + Bz^2)/2,  T_phiphi = p + (Bz^2 - Bphi^2)/2
       with analytic p, B at the faces / centres.  It is exactly 0 for the continuum equilibrium; its size is the equilibrium defect of the conservative FV discretisation."""
    g = G.g; rf = G.rf[g:g + G.nr + 1]; rc = G.rc[g:g + G.nr]; z0 = 0.0; p0_ = 0.0
    Trr = lambda r: pfun(r) + 0.5*(fld.Bp(r, p0_, z0)**2 + fld.Bz(r, p0_, z0)**2); Tpp = lambda r: pfun(r) + 0.5*(fld.Bz(r, p0_, z0)**2 - fld.Bp(r, p0_, z0)**2)
    return -(rf[1:]*Trr(rf[1:]) - rf[:-1]*Trr(rf[:-1]))/(rc*G.dr) + Tpp(rc)/rc

def t046(be):
    res = dict(); fails = []; raw = H.backend_for(be); cases = []; a = PIN_A
    for fld in (pinch_field(), screw_field(), gauss_pinch_field()):
        pfun = equilibrium_pressure(fld.name)
        for mode in ("annulus", "axis"):
            rows = []
            for G in levels(mode):
                B = G.sample(fld, F64); J = kern(G, raw, B, F64); Bc = Bcc_interior(B, G); Bex = B_centres(G, fld); Jref = sample_J_ref(G, fld); g = G.g
                F = cross(J, Bc); Fref = cross(Jref, Bex); rc = G.rc[g:g + G.nr]; rm = region_mask(G, mode)
                err = [F[c] - Fref[c] for c in range(3)]; n_reg = vnorms(err, rm); n_all = vnorms(err, None); n_r0 = vnorms(err, ring_mask(G, 0)); n_out = vnorms(err, ring_mask(G, G.nr - 1))
                form = None
                if fld.name.startswith("Z-pinch"): form = float(np.max(np.abs(F[0] + 2*a**2*rc[:, None, None])))      # closed-form analytic force (J x B)_r = -2 a^2 r, evaluated at the cell centres
                p = pfun(rc)[:, None, None]*np.ones((1, G.nphi, G.nz)); gp = (p[2:] - p[:-2])/(2*G.dr)                  # discrete pressure gradient (central, cell centred) on rings 1..nr-2
                Rd = F[0][1:-1] - gp; Rref = Fref[0][1:-1] - gp; Rcons = maxwell_stress_residual(fld, pfun, G)
                rm_in = rm[1:-1]; rc_in = rc[1:-1]; axis_ratio = (F[0][0, 0, 0]/rc[0]) if mode == "axis" else None
                rows.append(dict(grid=[G.nr, G.nphi, G.nz], force_region=n_reg, force_global=n_all, force_ring0=n_r0, force_outer_ring=n_out, closed_form_Fr_err=form, Fmax=max(nmax(f_) for f_ in Fref),
                                 pressure_force_residual_region=norms(Rd, rm_in)["Linf"], pressure_force_residual_global=norms(Rd, None)["Linf"], analytic_force_vs_discrete_gradient_region=norms(Rref, rm_in)["Linf"],
                                 conservative_stress_residual_region=float(np.max(np.abs(Rcons)[(rc >= (TOL5["region_annulus"] if mode == "annulus" else TOL5["region_axis"])[0]) & (rc <= (TOL5["region_annulus"] if mode == "annulus" else TOL5["region_axis"])[1])])),
                                 conservative_stress_residual_global=float(np.max(np.abs(Rcons))), conservative_stress_residual_first_ring=float(abs(Rcons[0])), Fr_over_rc_ring0=axis_ratio, Fr_over_rc_exact_ring0=(float(Fref[0][0, 0, 0]/rc[0]) if mode == "axis" else None),
                                 floor=tol_alg(F64, bmax_of(B)*max(nmax(j) for j in Jref)/hmin_of(G))))
            ent = dict(field=fld.name, mode=mode, rows=rows); fl_ = [r["floor"] for r in rows]
            ent.update(order_checks([dict(a=r["force_region"]["Linf"], b=r["force_global"]["Linf"]) for r in rows], mode, "a", "b", fl_, fl_, f"046 {fld.name} {mode} force", fails))
            okp, o_p, atf_p = order_rule([r["pressure_force_residual_region"] for r in rows], fl_); ent.update(pressure_orders=o_p, pressure_ok=okp, pressure_at_floor=atf_p)
            if not okp: fails.append(f"046 {fld.name} {mode}: discrete pressure-force residual orders {['%.2f' % x for x in o_p]}")
            oc = orders_of([r["conservative_stress_residual_region"] for r in rows]); ent["conservative_orders"] = oc
            ent["conservative_form_preserves_equilibrium_to_roundoff"] = bool(all(r["conservative_stress_residual_region"] <= f_ for r, f_ in zip(rows, fl_)))
            if not (oc[-1] >= TOL5["order_min"] or ent["conservative_form_preserves_equilibrium_to_roundoff"]): fails.append(f"046 {fld.name} {mode}: conservative-form residual does not converge ({['%.2f' % x for x in oc]})")
            ent["conservative_global_orders"] = orders_of([r["conservative_stress_residual_global"] for r in rows])
            if fld.name.startswith("Z-pinch"):
                ent["exact_to_roundoff"] = bool(all(r["force_global"]["Linf"] <= f_*8 for r, f_ in zip(rows, fl_)))
                if not ent["exact_to_roundoff"]: fails.append(f"046 {fld.name} {mode}: Z-pinch force not reproduced to round-off: global errors {[r['force_global']['Linf'] for r in rows]}")
                if max(r["closed_form_Fr_err"] for r in rows) > 8*max(fl_): fails.append(f"046 {fld.name} {mode}: (J x B)_r != -2 a^2 r (err {max(r['closed_form_Fr_err'] for r in rows):.2e})")
            if mode == "axis":
                reg = [abs(r["Fr_over_rc_ring0"] - r["Fr_over_rc_exact_ring0"]) for r in rows]; ent["axis_regularity_err"] = reg; ent["axis_regularity_orders"] = orders_of(reg)
                if not (ent["axis_regularity_orders"][-1] >= TOL5["axis_global_order_min"] or all(x <= f_*64 for x, f_ in zip(reg, fl_))): fails.append(f"046 {fld.name} axis: F_r/r at the first ring does not converge to the analytic value ({['%.1e' % x for x in reg]})")
            cases.append(ent)
    res["cases"] = cases
    # FP32 Z-pinch
    f32 = []
    for G in levels("annulus", 3) + levels("axis", 3):
        B32 = G.sample(pinch_field(), F32); J32 = kern(G, raw, B32, F32); Bc = Bcc_interior(B32, G); F = cross(J32, Bc); rc = G.rc[G.g:G.g + G.nr]; e = float(np.max(np.abs(F[0] + 2*a**2*rc[:, None, None]))); bnd = TOL5["fp_factor"]*EPS[F32]*bmax_of(B32)*kappa_of(G)*bmax_of(B32)
        f32.append(dict(grid=[G.nr, G.nphi, G.nz], r0=G.rf[G.g], err=e, bound=bnd, ok=bool(e <= bnd), non_discriminating=bool(bnd > TOL5["disc_fraction"]*2*a*a*float(rc.max())), Fmax=2*a*a*float(rc.max())))
    res["fp32_pinch"] = f32
    if not all(r["ok"] for r in f32): fails.append("046 FP32 Z-pinch force exceeds 64 eps Bmax^2 kappa")
    # ---- the DRIVER's discretisation of the same force (real ScienceManager on a real driver state); equilibrium under driver TIME STEPPING is BLOCKED (flux kernels are stubs)
    drv = load_driver(); dres = dict(available=drv is not None)
    if drv is None: dres["note"] = f"BLOCKED: {DRIVER_NAME} not found next to the harness"; res["driver_force"] = dres
    else:
        try:
            dres["driver_sha256"] = drv._campaign_sha; rows = []
            for lab, kwargs in (("driver's own set_zpinch IC (Bphi = 0.5 r_c)", dict(ic="zpinch")), ("analytic Z-pinch sampled at the staggered positions", dict(fld=pinch_field())), ("analytic screw pinch sampled at the staggered positions", dict(fld=screw_field()))):
                cfg, geo, grid, st, bnd_, G = driver_state(drv, 64, 16, 8, 0.0, 1.0, **kwargs); sm = drv.ScienceManager(cfg, geo)
                r, jz = sm.jz(st); _, f_jo = sm.lorentz_radial(st, "validated_jz_only"); _, f_full = sm.lorentz_radial(st, "full_axisymmetric_lorentz")
                r = np.asarray(r, dtype=F64); jz = np.asarray(jz, dtype=F64); f_jo = np.asarray(f_jo, dtype=F64); f_full = np.asarray(f_full, dtype=F64)
                fld_ = pinch_field() if "Z-pinch" in lab or "zpinch" in lab else screw_field()
                Fex = (fld_.Jp(r, 0, 0)*fld_.Bz(r, 0, 0) - fld_.Jz(r, 0, 0)*fld_.Bp(r, 0, 0)); Jzex = fld_.Jz(r, 0, 0)
                Bk, rf, rc_, dr_, dphi_, dz_, ad = kernel_args_from_driver(cfg, geo, st); Jk = [np.zeros((G.nr + 4, G.nphi + 4, G.nz + 4), Bk[0].dtype) for _ in range(3)]
                Jk = raw.run(*Bk, rf, rc_, dr_, dphi_, dz_, G.nr, G.nphi, G.nz, G.g, J=Jk) if False else raw.run(*Bk, rf, rc_, dr_, dphi_, dz_, G.nr, G.nphi, G.nz, G.g)
                Jki = Ji(Jk, G); Bci = Bcc_interior(Bk, G); Fk = cross(Jki, Bci); iz = G.nz//2
                Fk_r = Fk[0][:, :, iz].mean(axis=1); Jz_k = Jki[2][:, :, iz].mean(axis=1)
                rows.append(dict(case=lab, grid=[64, 16, 8], driver_jz_err_inner=float(np.max(np.abs(jz - Jzex)[2:-2])), driver_jz_err_first=float(abs(jz[0] - Jzex[0])), driver_jz_err_last=float(abs(jz[-1] - Jzex[-1])),
                                 driver_Fr_validated_jz_only_err_inner=float(np.max(np.abs(f_jo - Fex)[2:-2])), driver_Fr_validated_jz_only_err_last=float(abs(f_jo[-1] - Fex[-1])),
                                 driver_Fr_full_err_inner=float(np.max(np.abs(f_full - Fex)[2:-2])), kernel_Jz_err_inner=float(np.max(np.abs(Jz_k - Jzex)[:-1])), kernel_Jz_err_last_ring=float(abs(Jz_k[-1] - Jzex[-1])),
                                 kernel_Fr_err_inner=float(np.max(np.abs(Fk_r - Fex)[:-1])), kernel_Fr_err_last_ring=float(abs(Fk_r[-1] - Fex[-1])), Fmax=float(np.max(np.abs(Fex))), adaptation=ad))
            dres["rows"] = rows
            dres["driver_validated_jz_only_omits_Jphi_Bz"] = bool(rows[-1]["driver_Fr_validated_jz_only_err_inner"] > 10*max(rows[-1]["driver_Fr_full_err_inner"], 1e-6))
        except Exception:
            dres["error"] = traceback.format_exc()[-1800:]; fails.append("046 driver-level force evaluation raised an exception")
        res["driver_force"] = dres
    res["blocked_items"] = [dict(item="equilibrium preservation under the DRIVER's time stepping", reason="hlldx / hlldy / hlldz / residual / uct_emf / uct_curl(CT) are stubs in the supplied driver (manifest 'stub'); no real flux / EMF / CT operator exists to evolve the equilibrium, so what the actual driver discretisation preserves cannot be measured")]
    res["statement"] = ("Three distinct things are kept apart: (1) the ANALYTIC equilibrium (F_r = dp/dr exactly); (2) the CURRENT-FORM discrete balance built from this kernel (J x B_cc against a central pressure gradient), "
                        "(3) the CONSERVATIVE-FORM finite-volume balance (Maxwell-stress divergence with the geometric hoop term, a harness reference - NOT the driver).  (2) and (3) are different discretisations of the same continuum "
                        "equilibrium and preserve it with different defects; neither is the driver's time-stepped discretisation, which is BLOCKED.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 047  Non-axisymmetric helical perturbations on the Z-pinch (m = 1, 2, 3)
# ============================================================================
HELICAL_PARAMS = [(2*math.pi*1, 0.05, 0.0), (2*math.pi*2, 0.30, 1.1), (2*math.pi*1.5, 0.10, 2.9)]          # (axial wavenumber k, amplitude eps, phase delta)

def ring_index(G, rtarget):
    return int(np.argmin(np.abs(G.rc[G.g:G.g + G.nr] - rtarget)))

def harmonic_compare(Jn, Jr_, i):
    """azimuthal Fourier transform on interior ring i for every z slice: complex error over the analytic support, leakage outside it, and the dominant harmonic's amplitude / phase"""
    An = np.fft.fft(Jn[i], axis=0)/Jn[i].shape[0]; Ar = np.fft.fft(Jr_[i], axis=0)/Jr_[i].shape[0]; amax = float(np.abs(Ar).max()) + 1e-300
    sup = (np.abs(Ar).max(axis=1) > 1e-10*amax); err = float(np.abs(An - Ar)[sup].max())/amax; leak = float(np.abs(An[~sup]).max())/amax if (~sup).any() else 0.0
    nd = int(np.argmax(np.where(np.arange(Ar.shape[0]) == 0, 0.0, np.abs(Ar).max(axis=1)))); k0 = int(np.argmax(np.abs(Ar[nd])))
    ratio = An[nd, k0]/Ar[nd, k0]; return dict(complex_err=err, leakage=leak, dominant_harmonic=nd, amp_ratio_minus_1=float(abs(ratio) - 1.0), phase_err=float(np.angle(ratio)), amax=amax)

def t047(be):
    res = dict(); fails = []; raw = H.backend_for(be); cases = []
    for m in (1, 2, 3):
        for (k, eps, delta) in HELICAL_PARAMS:
            spec = spec_pinch_pert(m, k, eps, delta); fld = C._cart_field(*spec, f"pinch+helical m={m} k={k:.3f} eps={eps} delta={delta}")
            ref_err = H.cart_reference_check(spec)
            for mode in ("annulus", "axis"):
                rows = []
                for G in levels(mode):
                    B = G.sample(fld, F64); J = kern(G, raw, B, F64); Jref = sample_J_ref(G, fld); rm = region_mask(G, mode); err = [J[c] - Jref[c] for c in range(3)]
                    iring = ring_index(G, 1.0 if mode == "annulus" else 0.5); hc = [harmonic_compare(J[c], Jref[c], iring) for c in range(3)]; h0 = [harmonic_compare(J[c], Jref[c], 0) for c in range(3)] if mode == "axis" else None
                    bm = bmax_of(B)
                    rows.append(dict(grid=[G.nr, G.nphi, G.nz], comp_region_Linf=[norms(err[c], rm)["Linf"] for c in range(3)], comp_global_Linf=[norms(err[c], None)["Linf"] for c in range(3)], comp_ring0_Linf=[norms(err[c], ring_mask(G, 0))["Linf"] for c in range(3)],
                                     region=vnorms(err, rm), global_=vnorms(err, None), ring=dict(r=float(G.rc[G.g + iring]), per_component=hc), ring0_harmonics=h0, Jmax=max(nmax(x) for x in Jref), floor=tol_alg(F64, bm/hmin_of(G)),
                                     leak_bound=TOL5["leak_factor"]*EPS[F64]*bm/hmin_of(G)))
                fl_ = [r["floor"] for r in rows]; ent = dict(m=m, k=k, eps=eps, delta=delta, mode=mode, cartesian_reference_check=ref_err, rows=rows)
                ent.update(order_checks([dict(a=r["region"]["Linf"], b=r["global_"]["Linf"]) for r in rows], mode, "a", "b", fl_, fl_, f"047 m={m} k={k:.2f} eps={eps} {mode}", fails))
                ent["comp_orders_region"] = [orders_of([r["comp_region_Linf"][c] for r in rows]) for c in range(3)]
                for c, cn in enumerate(("Jr", "Jphi", "Jz")):
                    # complex (amplitude + phase) harmonic error at the fixed ring: scaled by the analytic amplitude; leakage into harmonics outside the analytic support
                    ce = [r["ring"]["per_component"][c]["complex_err"] for r in rows]; lk = [r["ring"]["per_component"][c]["leakage"] for r in rows]; pe = [abs(r["ring"]["per_component"][c]["phase_err"]) for r in rows]; ae = [abs(r["ring"]["per_component"][c]["amp_ratio_minus_1"]) for r in rows]
                    okc = bool(orders_of(ce)[-1] >= TOL5["amp_order_min"] or all(x <= 1e-12 for x in ce)); okp = bool(orders_of(pe)[-1] >= TOL5["amp_order_min"] or all(x <= 1e-12 for x in pe)); oka = bool(orders_of(ae)[-1] >= TOL5["amp_order_min"] or all(x <= 1e-12 for x in ae))
                    lb = [r["leak_bound"]/max(r["ring"]["per_component"][c]["amax"], 1e-300) for r in rows]; okl = bool(all(x <= b for x, b in zip(lk, lb)) or orders_of(lk)[-1] >= TOL5["amp_order_min"] or all(x <= 1e-12 for x in lk))
                    ent[f"harmonic_{cn}"] = dict(complex_err=ce, complex_orders=orders_of(ce), phase_err=pe, phase_orders=orders_of(pe), amp_err=ae, amp_orders=orders_of(ae), leakage=lk, leakage_orders=orders_of(lk), leak_bound_rel=lb, ok=bool(okc and okp and oka and okl))
                    if not okc: fails.append(f"047 m={m} k={k:.2f} eps={eps} {mode} {cn}: complex harmonic error orders {['%.2f' % x for x in orders_of(ce)]}")
                    if not okp: fails.append(f"047 m={m} k={k:.2f} eps={eps} {mode} {cn}: phase error orders {['%.2f' % x for x in orders_of(pe)]}")
                    if not oka: fails.append(f"047 m={m} k={k:.2f} eps={eps} {mode} {cn}: amplitude error orders {['%.2f' % x for x in orders_of(ae)]}")
                    if not okl: fails.append(f"047 m={m} k={k:.2f} eps={eps} {mode} {cn}: harmonic leakage neither within round-off nor converging ({['%.1e' % x for x in lk]})")
                if mode == "axis":
                    for c, cn in enumerate(("Jr", "Jphi", "Jz")):
                        r0e = [r["comp_ring0_Linf"][c] for r in rows]; o0 = orders_of(r0e); ent[f"ring0_abs_orders_{cn}"] = o0
                        if not (o0[-1] >= TOL5["axis_global_order_min"] or all(x <= f_ for x, f_ in zip(r0e, fl_))): fails.append(f"047 m={m} k={k:.2f} eps={eps} axis ring0 {cn}: absolute error does not converge ({['%.1e' % x for x in r0e]})")
                if ref_err > 1e-8: fails.append(f"047 m={m}: analytic Cartesian reference check {ref_err:.2e}")
                cases.append(ent)
    res["cases"] = cases
    rows32 = []
    for m in (1, 2, 3):
        k, eps, delta = HELICAL_PARAMS[1]; fld = C._cart_field(*spec_pinch_pert(m, k, eps, delta), f"pinch+helical m={m}")
        for mode in ("annulus", "axis"):
            for G in levels(mode, 3):
                B32 = G.sample(fld, F32); fc = fp32_consistency(G, raw, B32); J32 = kern(G, raw, B32, F32); Jref = sample_J_ref(G, fld)
                fc.update(m=m, mode=mode, grid=[G.nr, G.nphi, G.nz], abs_err_vs_analytic_region=vnorms([J32[c] - Jref[c] for c in range(3)], region_mask(G, mode))["Linf"], non_discriminating=bool(fc["bound"] > TOL5["disc_fraction"]*fc["Jmax"])); rows32.append(fc)
    res["fp32"] = rows32
    if not all(r["ok"] for r in rows32): fails.append("047 FP32: FP32 vs FP64-kernel consistency violated")
    res["statement"] = ("Reference currents are the hand-derived Cartesian derivatives of the perturbed pinch (each verified against a numeric Cartesian curl).  Harmonic metrics are computed on a fixed-radius interior ring and every z slice from "
                        "the azimuthal DFT of the kernel current and of the analytic current on the SAME samples; leakage is the energy in harmonics outside the analytic support.  The annulus stencil is shift-invariant in phi, so harmonic "
                        "leakage there is round-off; the axis closure (Cartesian reconstruction on ring 0) mixes harmonics at O(h^2).")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 048  Resolution / anisotropy convergence (independent and joint refinement, extreme aspect ratios)
# ============================================================================
def grid_for(mode, n):
    return C.Grid(*n, r0=0.5, r1=1.5) if mode == "annulus" else C.Grid(*n, r0=0.0, r1=1.0)

def aniso_metrics(G, raw, fld, mode):
    B = G.sample(fld, F64); J = kern(G, raw, B, F64); Jref = sample_J_ref(G, fld); err = [J[c] - Jref[c] for c in range(3)]; rm = region_mask(G, mode)
    nreg = vnorms(err, rm); nall = vnorms(err, None); n0 = vnorms(err, ring_mask(G, 0)); sc = max(nmax(x) for x in Jref)
    return dict(grid=[G.nr, G.nphi, G.nz], hr=G.dr, hphi=G.dphi, hz=G.dz, h_phys=[G.dr, float(G.rc[G.g + G.nr//2]*G.dphi), G.dz], kappa=kappa_of(G), n_region_cells=int(rm.sum()), region=nreg, global_=nall, ring0=n0, interior_Linf=nreg["Linf"], Jmax=sc,
                floor=tol_alg(F64, bmax_of(B)/hmin_of(G)), hash=digest_J(J, G))

def digest_J(J, G): return T4.digest(J, G)

def fit_additive_model(rows, key):
    """e = A_r h_r^2 + A_phi h_phi^2 + A_z h_z^2 with A >= 0 (non-negative least squares by exhaustive subsets, relative weights) over the calibration grids; returns (A, predict)"""
    X = np.array([[r["hr"]**2, r["hphi"]**2, r["hz"]**2] for r in rows]); y = np.array([r[key]["Linf"] for r in rows]); w = 1.0/np.maximum(y, 1e-300); best = None
    for sub in ([0], [1], [2], [0, 1], [0, 2], [1, 2], [0, 1, 2]):
        A = np.zeros(3); c, *_ = np.linalg.lstsq((X[:, sub]*w[:, None]), y*w, rcond=None)
        if (c < 0).any(): continue
        A[sub] = c; rss = float(np.sum(((X@A - y)*w)**2))
        if best is None or rss < best[0]: best = (rss, A)
    A = best[1]
    return A, (lambda r: float(np.array([r["hr"]**2, r["hphi"]**2, r["hz"]**2])@A))

def t048(be):
    res = dict(); fails = []; raw = H.backend_for(be); base = TOL5["conv_base"]; L = 5; series_out = []
    EXT = [(8, 8, 128), (128, 8, 8), (8, 128, 8), (16, 16, 256), (256, 16, 16), (12, 384, 12), (192, 12, 12), (12, 12, 192), (6, 6, 96), (96, 6, 6)]
    for fld in (C.SMOOTH, C._cart_field(*spec_pinch_pert(2, 2*math.pi, 0.3, 1.1), "pinch + helical m=2 (eps 0.3)")):
        for mode in ("annulus", "axis"):
            sers = {}
            sers["joint"] = [aniso_metrics(grid_for(mode, n), raw, fld, mode) for n in H.levels(base, L)]
            sers["r only"] = [aniso_metrics(grid_for(mode, (base[0]*2**l, base[1], base[2])), raw, fld, mode) for l in range(L)]
            sers["phi only"] = [aniso_metrics(grid_for(mode, (base[0], base[1]*2**l, base[2])), raw, fld, mode) for l in range(L)]
            sers["z only"] = [aniso_metrics(grid_for(mode, (base[0], base[1], base[2]*2**l)), raw, fld, mode) for l in range(L)]
            ext = [aniso_metrics(grid_for(mode, n), raw, fld, mode) for n in EXT]
            ent = dict(field=fld.name, mode=mode, series={k: v for k, v in sers.items()}, extreme=ext)
            # (1) joint refinement: second order in the region (annulus: also globally), axis global at least first order
            jr = sers["joint"]; fl_ = [r["floor"] for r in jr]
            ent["joint"] = order_checks([dict(a=r["region"]["Linf"], b=r["global_"]["Linf"]) for r in jr], mode, "a", "b", fl_, fl_, f"048 {fld.name} {mode} joint", fails)
            ent["joint"]["L1_orders"] = orders_of([r["region"]["L1"] for r in jr]); ent["joint"]["L2_orders"] = orders_of([r["region"]["L2"] for r in jr]); ent["joint"]["Linf_orders"] = orders_of([r["region"]["Linf"] for r in jr])
            for nm_, o in (("L1", ent["joint"]["L1_orders"]), ("L2", ent["joint"]["L2_orders"])):
                if not (o[-1] >= TOL5["order_min"] or all(r["region"][nm_] <= f_ for r, f_ in zip(jr, fl_))): fails.append(f"048 {fld.name} {mode} joint: {nm_} orders {['%.2f' % x for x in o]}")
            ent["axis_vs_interior_ring0_over_region"] = [r["ring0"]["Linf"]/max(r["region"]["Linf"], 1e-300) for r in jr] if mode == "axis" else None
            # (2) independent refinement: monotone, and every series explained by the additive error model fitted on ALL calibration grids; the extreme aspect ratios are PREDICTED by it (held out)
            calib = [r for k, s in sers.items() for r in s]; Q, pred = fit_additive_model(calib, "region"); ent["model_A"] = [float(q) for q in Q]
            worst_fit = 0.0
            for k, s in sers.items():
                ok_mono = all(s[i + 1]["region"]["Linf"] <= s[i]["region"]["Linf"]*(1 + TOL5["plateau_tol"]) + s[i]["floor"] for i in range(len(s) - 1)); ent[f"{k}_monotone"] = bool(ok_mono)
                if not ok_mono: fails.append(f"048 {fld.name} {mode} '{k}': error increases by more than the declared plateau tolerance under refinement ({['%.2e' % r['region']['Linf'] for r in s]})")
                fitr = [r["region"]["Linf"]/max(pred(r), 1e-300) for r in s]; ent[f"{k}_fit_ratio"] = fitr; worst_fit = max(worst_fit, max(abs(x - 1.0) for x in fitr))
                ent[f"{k}_orders"] = orders_of([r["region"]["Linf"] for r in s])
            ent["model_worst_calibration_deviation"] = worst_fit
            if worst_fit > TOL5["model_fit_tol"]: fails.append(f"048 {fld.name} {mode}: additive error model reproduces calibration errors only within {worst_fit:.2f} (declared {TOL5['model_fit_tol']})")
            exr = []
            for r in ext:
                p_ = pred(r); obs = r["region"]["Linf"]; ratio = obs/max(p_, 1e-300); exr.append(dict(grid=r["grid"], kappa=r["kappa"], observed=obs, predicted=p_, ratio_obs_over_pred=ratio, L1=r["region"]["L1"], L2=r["region"]["L2"], global_Linf=r["global_"]["Linf"], ring0_Linf=r["ring0"]["Linf"],
                                                                                    within_envelope=bool(ratio <= TOL5["aniso_envelope"] or obs <= r["floor"]), aspect=[max(r["h_phys"])/min(r["h_phys"])]))
                if not exr[-1]["within_envelope"]: fails.append(f"048 {fld.name} {mode} extreme grid {r['grid']}: observed error {obs:.2e} exceeds {TOL5['aniso_envelope']:g} x the model prediction {p_:.2e}")
            ent["extreme_predictions"] = exr
            # conditioning: error vs eps*kappa (round-off is NOT the limit here: truncation is) - reported
            ent["conditioning"] = [dict(grid=r["grid"], kappa=r["kappa"], eps_kappa=EPS[F64]*r["kappa"], err_over_eps_kappa=r["region"]["Linf"]/(EPS[F64]*r["kappa"]*max(r["Jmax"], 1e-300))) for r in ext]
            series_out.append(ent)
    res["cases"] = series_out
    # GPU/CPU agreement is NEVER the verdict: record, informationally, whether a second backend reproduces the joint series on the SAME inputs
    res["verdict_uses_cpu_gpu_agreement"] = False
    if be.name == "cupy":
        host = C.HostBackend(); G = grid_for("annulus", base); B = G.sample(C.SMOOTH, F64); Jg = kern(G, raw, B, F64); Jh = kern(G, host, B, F64)
        res["gpu_vs_host_joint_base_max_diff"] = max(nmax(Jg[c] - Jh[c]) for c in range(3))
    rows32 = []
    for mode in ("annulus", "axis"):
        for n in H.levels(base, 3):
            G = grid_for(mode, n); B32 = G.sample(C.SMOOTH, F32); fc = fp32_consistency(G, raw, B32); J32 = kern(G, raw, B32, F32); Jref = sample_J_ref(G, C.SMOOTH)
            fc.update(mode=mode, grid=list(n), abs_err_vs_analytic_region=vnorms([J32[c] - Jref[c] for c in range(3)], region_mask(G, mode))["Linf"], non_discriminating=bool(fc["bound"] > TOL5["disc_fraction"]*fc["Jmax"])); rows32.append(fc)
    res["fp32"] = rows32
    if not all(r["ok"] for r in rows32): fails.append("048 FP32: consistency violated")
    res["statement"] = ("Errors are measured against the analytic current (never against another backend).  The joint series must converge at second order in the fixed region; the three single-direction series are bounded below by the other directions' "
                        "truncation (a plateau), which an additive model e = A_r h_r^2 + A_phi h_phi^2 + A_z h_z^2 (A >= 0) fitted to ALL calibration grids must reproduce within 50%; ten held-out extreme aspect-ratio grids (up to 200:1 cells) must lie below "
                        f"{TOL5['aniso_envelope']:g} x its prediction.  The model is a measurement device, not a theorem.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 049  Hall-sensitive nullspace contamination
# ============================================================================
def t049(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(TOL5["seeds"]["t049"]); eta = TOL5["hall_eta"]; rows = []; dec_rows = []
    G = C.Grid(24, 24, 16, g=2, r0=0.5, r1=1.5)
    for fld in (C.SMOOTH, screw_field(), C._cart_field(*spec_pinch_pert(2, 2*math.pi, 0.3, 1.1), "pinch + helical m=2 (eps 0.3)")):
        for dt in (F64, F32):
            Bs = G.sample(fld, dt); Bmax = bmax_of(Bs); J0 = kern(G, raw, Bs, dt); Jref = sample_J_ref(G, fld); Bex = B_centres(G, fld); Bc0 = Bcc_interior(Bs, G); rm = region_mask(G, "annulus")
            Eref = hall_E(Jref, Bex, eta); E0 = hall_E(J0, Bc0, eta); clean = vnorms([E0[c] - Eref[c] for c in range(3)], rm)["Linf"]; Jsm = max(nmax(x) for x in Jref)
            pats = T3.null_mode_fields(G, dt, rng); prev = {}
            for pname, pat in pats.items():
                pm = bmax_of(pat); pat = [(p_/pm).astype(dt) for p_ in pat]
                for arel in (1e-3, 1e-2, 1e-1):
                    amp = arel*Bmax; Bn = per_fill([(Bs[i].astype(F64) + amp*pat[i].astype(F64)).astype(dt) for i in range(3)], G); J1 = kern(G, raw, Bn, dt); Bc1 = Bcc_interior(Bn, G); dBcc = [Bc1[c] - Bc0[c] for c in range(3)]
                    dJ = max(nmax(J1[c] - J0[c]) for c in range(3)); tol_inv = tol_alg(dt, (Bmax + amp)/hmin_of(G)); E1 = hall_E(J1, Bc1, eta)
                    dE = [E1[c] - E0[c] for c in range(3)]; pred = [eta*(a_ + b_) for a_, b_ in zip(cross(J1, dBcc), cross([J1[c] - J0[c] for c in range(3)], Bc0))]
                    ident = max(nmax(dE[c] - pred[c]) for c in range(3)); itol = tol_alg(dt, eta*(Bmax + amp)*max(Jsm, 1.0)*8)
                    dEn = vnorms(dE, rm)["Linf"]; F1 = cross(J1, Bc1); F0 = cross(J0, Bc0); dFn = vnorms([F1[c] - F0[c] for c in range(3)], rm)["Linf"]
                    row = dict(field=fld.name, dtype=dn(dt), pattern=pname, amp_rel=arel, amp=amp, J_change=dJ, invisible_tol=tol_inv, invisible=bool(dJ <= tol_inv), dBcc_max=max(nmax(x) for x in dBcc), dBcc_over_amp=max(nmax(x) for x in dBcc)/amp,
                               dE_region_Linf=dEn, dF_region_Linf=dFn, identity_err=ident, identity_tol=itol, identity_ok=bool(ident <= itol), clean_truncation_err=clean, dE_over_truncation=dEn/max(clean, 1e-300), dE_over_Eref=dEn/max(max(nmax(x) for x in Eref), 1e-300), Jsmooth_max=Jsm)
                    if dt is F64 and G is not None:
                        pure = [amp*pat[i].astype(F64) for i in range(3)]; Jp = kern(G, raw, [x.astype(F64) for x in pure], F64)
                        Jd_e = dec_edge_currents(per_fill(pure, G), G); Jdec = max(float(np.nanmax(np.abs(a))) for a in Jd_e); row.update(kernel_J_of_pattern=max(nmax(j) for j in Jp), dec_edge_J_of_pattern=Jdec, dec_J_over_amp_times_h=Jdec*hmin_of(G)/amp, blind_ratio=Jdec/max(Jsm, 1e-300))
                    rows.append(row)
                    if not row["invisible"]: fails.append(f"049 {fld.name} {dn(dt)} '{pname}' amp {arel}: pattern visible to the kernel (dJ {dJ:.2e} > {tol_inv:.2e})")
                    if not row["identity_ok"]: fails.append(f"049 {fld.name} {dn(dt)} '{pname}' amp {arel}: Hall EMF change != eta[J x dB_cc + dJ x B_cc] ({ident:.2e} > {itol:.2e})")
                    prev.setdefault(pname, []).append(row)
            # linear scaling of the Hall contamination with the amplitude (exact discrete consequence of the identity when J is unchanged)
            for pname, rr in prev.items():
                a1, a2, a3 = rr
                if dt is F64 and a1["dE_region_Linf"] > 1e-12:
                    sc = (a2["dE_region_Linf"]/a1["dE_region_Linf"], a3["dE_region_Linf"]/a2["dE_region_Linf"])
                    if not all(abs(x - 10.0) < 1e-3 for x in sc): fails.append(f"049 {fld.name} '{pname}': Hall contamination not linear in the amplitude ({sc})")
    res["rows"] = rows
    f64 = [r for r in rows if r["dtype"] == "float64"]
    res["summary"] = dict(n_rows=len(rows), all_invisible_to_J=bool(all(r["invisible"] for r in rows)),
                          patterns_with_hall_leak=sorted({r["pattern"] for r in f64 if r["dBcc_max"] > 0.1*r["amp"]}), patterns_without_hall_leak=sorted({r["pattern"] for r in f64 if r["dBcc_max"] <= 0.1*r["amp"]}),
                          max_dE_over_truncation=max(r["dE_over_truncation"] for r in f64), max_dE_over_Eref=max(r["dE_over_Eref"] for r in f64),
                          min_dec_J_over_amp_h=min(r["dec_J_over_amp_times_h"] for r in f64), max_blind_ratio=max(r["blind_ratio"] for r in f64),
                          critical_amplitude_rel_for_blind_ratio_1=min((r["amp_rel"] for r in f64 if r["blind_ratio"] >= 1.0), default=None),
                          critical_amplitude_rel_for_Hall_above_truncation=min((r["amp_rel"] for r in f64 if r["dE_over_truncation"] >= 1.0), default=None))
    if res["summary"]["min_dec_J_over_amp_h"] < 0.25: fails.append("049 the compatible (DEC) curl does not see a pattern the kernel misses at O(amp/h): comparison inconclusive")
    # axis grids: the checkerboards are NOT all invisible there (Campaign 04 / 032): report what happens to J and the Hall EMF
    GA = C.Grid(12, 24, 8, g=2, r0=0.0, r1=1.0); ax = []; Bs = GA.sample(C.SMOOTH, F64); J0 = kern(GA, raw, Bs, F64); Bc0 = Bcc_interior(Bs, GA)
    for pname, pat in T3.null_mode_fields(GA, F64, rng).items():
        pm = bmax_of(pat); amp = 1e-2*bmax_of(Bs); Bn = per_fill([(Bs[i] + amp*pat[i]/pm) for i in range(3)], GA); J1 = kern(GA, raw, Bn, F64); Bc1 = Bcc_interior(Bn, GA); E0 = hall_E(J0, Bc0, eta); E1 = hall_E(J1, Bc1, eta)
        ax.append(dict(pattern=pname, J_change=max(nmax(J1[c] - J0[c]) for c in range(3)), J_change_over_amp=max(nmax(J1[c] - J0[c]) for c in range(3))/amp*hmin_of(GA), dE=max(nmax(E1[c] - E0[c]) for c in range(3)), ring0_J_change=max(norms(J1[c] - J0[c], ring_mask(GA, 0))["Linf"] for c in range(3))))
    res["axis_grid_patterns"] = ax
    s = res["summary"]; res["limitation_recorded"] = bool(s["all_invisible_to_J"] and s["max_blind_ratio"] >= 1.0)
    res["limitation_text"] = ("EXPLICIT LIMITATION: grid-scale (checkerboard) magnetic modes are exactly invisible to the kernel's J, while a compatible DEC curl of the same field carries a current of O(amplitude/h). "
                              "The Hall EMF and the Lorentz force J x B inherit the blindness: they respond only through the face-averaged B_cc (dE = eta J x dB_cc, exact), and only for the patterns that survive the averaging "
                              f"({s['patterns_with_hall_leak']}); the kernel cannot warn about, damp or even detect the grid-scale B content.  Not an eliminated defect: it is a property of the operator.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 050  Cross-operator integration and regression
# ============================================================================
REGISTERED_SHA = dict(kernel="e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e", campaign01="f9654f955372e8ccee8a3ca4559ed43a6b553288dac97d1ba0afeb17c2973ab0",
                      campaign02="0b04d43595c659397a64b848f5eb5b01fd5ef3b304ddbef7b2fadca76a4d9035", campaign03="abaf76f9c6c281ee1f22acb28397bc59e249662a7388e412f64bf7c1b966f93c",
                      campaign04="6a583cb34160ec835f0dfe21f89dd12a8c8d8b17d1a07c4c226a958b86fbce30")
EXPECTED_NON_DISCRIMINATING = {("large radius r0 = 1e4", "float32"), ("large radius r0 = 1e5", "float32"), ("rc*dphi >> dr (nphi = 4, r0 = 1e3, dr = 1e-3)", "float32")}
REQUIRED_REAL_COMPONENTS = ("hlldx", "hlldy", "hlldz", "residual", "uct_emf", "uct_curl")           # the slots the current-density operator couples to / is sequenced with

def sha_file(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def sources_now():
    return dict(kernel=C.SRC_SHA, campaign01=sha_file(C.__file__), campaign02=sha_file(H.__file__), campaign03=sha_file(T3.__file__), campaign04=sha_file(T4.__file__))
def hash_arrays(arrs): return hashlib.sha256(b"".join(np.ascontiguousarray(a).tobytes() for a in arrs)).hexdigest()

def run_on_driver_state(raw, cfg, geo, st, dtype=None):
    B, rf, rc, dr, dphi, dz, ad = kernel_args_from_driver(cfg, geo, st); g = cfg.nghost
    if dtype is not None and np.dtype(dtype) != B[0].dtype: B = [b.astype(dtype) for b in B]; rf = rf.astype(dtype); rc = rc.astype(dtype)
    J = raw.run(*B, rf, rc, dr, dphi, dz, cfg.nr, cfg.nphi, cfg.nz, g); return B, rf, rc, dr, dphi, dz, ad, J

def layer_errors(d, axis):
    """Linf of a (nr, nphi, nz) difference array per layer along `axis`"""
    other = tuple(i for i in range(3) if i != axis); return np.max(np.abs(d), axis=other)

def ghost_ownership_rows(drv, raw):
    """kernel output with (A) analytically filled ghosts and (B) the driver's own BoundaryManager; the difference is localised to boundary-adjacent layers (core = cells not adjacent to a radial / axial boundary)"""
    rows = []
    for lab, fld, nr_, r_min, r_max in (("Z-pinch (r-dependent only), r_min = 0", pinch_field(), 32, 0.0, 1.0), ("SMOOTH Cartesian (r, phi, z dependent), annulus r_min = 0.5", C.SMOOTH, 24, 0.5, 1.5), ("KINK m=1 (non-zero Br on the axis face), r_min = 0", C.KINK, 24, 0.0, 1.0)):
        cfgA, geoA, _, stA, _, G = driver_state(drv, nr_, 16, 12, r_min, r_max, fld=fld, apply_bc=False); cfgB, geoB, _, stB, _, _ = driver_state(drv, nr_, 16, 12, r_min, r_max, fld=fld, apply_bc=True)
        *_, JA = run_on_driver_state(raw, cfgA, geoA, stA); *_, JB = run_on_driver_state(raw, cfgB, geoB, stB)
        A = Ji(JA, G); Bc = Ji(JB, G); Jref = sample_J_ref(G, fld); d = np.max(np.abs(np.stack([Bc[c] - A[c] for c in range(3)])), axis=0); eA = np.max(np.abs(np.stack([A[c] - Jref[c] for c in range(3)])), axis=0)
        eB = np.max(np.abs(np.stack([Bc[c] - Jref[c] for c in range(3)])), axis=0); Jm = max(nmax(x) for x in Jref); nr, nphi, nz = G.nr, G.nphi, G.nz
        core = (slice(1, nr - 1), slice(None), slice(1, nz - 1)); kcore = slice(1, nz - 1); icore = slice(1, nr - 1)
        g = G.g; dB = lambda name: float(np.abs(stB.fields[name].astype(F64) - stA.fields[name].astype(F64)).max())
        rows.append(dict(case=lab, grid=[nr, nphi, nz], r_min=r_min, Jmax=Jm, analytic_ghost_Linf_err=float(eA.max()), analytic_ghost_core_err=float(eA[core].max()), driver_bc_Linf_err=float(eB.max()),
                         driver_vs_analytic_ghost_max=float(d.max()), core_max_diff=float(d[core].max()), ring0_diff=float(d[0, :, kcore].max()), last_ring_diff=float(d[nr - 1, :, kcore].max()), z_first_layer_diff=float(d[icore, :, 0].max()), z_last_layer_diff=float(d[icore, :, nz - 1].max()),
                         phi_layer_diffs=[float(d[core][:, j, :].max()) for j in range(nphi)], ring0_err_driver_bc=float(eB[0, :, kcore].max()), ring0_err_analytic_ghost=float(eA[0, :, kcore].max()),
                         axis_face_Br_driver_max=float(np.abs(stB.fields["Br"][g]).max()), axis_face_Br_analytic_max=float(np.abs(stA.fields["Br"][g]).max()),
                         driver_bc_changed_Br_inner_face_entries=int((stA.fields["Br"][g] != stB.fields["Br"][g]).sum()), bphi_phi_ghost_dev_vs_analytic=float(np.abs(stB.fields["Bphi"][:, :g].astype(F64) - stA.fields["Bphi"][:, :g].astype(F64)).max()),
                         bz_z_ghost_dev_vs_analytic=float(np.abs(stB.fields["Bz"][:, :, :g].astype(F64) - stA.fields["Bz"][:, :, :g].astype(F64)).max()), dBr=dB("Br"), dBphi=dB("Bphi"), dBz=dB("Bz")))
    return rows

def t050(be):
    res = dict(); fails = []; blocked = []; raw = H.backend_for(be); host = C.HostBackend() if be.name != "host" else be
    # ---- A. sources: frozen kernel + helper hashes unchanged at the start and at the end of the test
    s0 = sources_now(); res["sources_start"] = s0; res["sources_registered"] = REGISTERED_SHA
    for k, v in s0.items():
        if v != REGISTERED_SHA[k]: fails.append(f"050 source hash mismatch: {k} {v[:12]} != registered {REGISTERED_SHA[k][:12]}")
    # ---- B. component inventory (from the supplied driver, unmodified)
    drv = load_driver(); inv = []
    if drv is None:
        blocked.append(dict(component="driver (magnetic-state / geometry / boundary interfaces)", reason=f"{DRIVER_NAME} not found next to the harness (searched {HERE}, cwd, parent)")); res["driver"] = dict(available=False)
    else:
        ec = drv.ExecutionController(); man = ec.manifest(); res["driver"] = dict(available=True, path=drv._campaign_path, sha256=drv._campaign_sha, manifest=man, import_pip_attempts_blocked=drv._import_pip_attempts_blocked, kernel_sequence=list(drv.KERNEL_SEQUENCE))
        cfg0, geo0, grid0, st0, bnd0, G0 = driver_state(drv, 12, 8, 6, 0.5, 1.5, fld=C.SMOOTH)
        for slot in drv.KERNEL_SEQUENCE:
            status = man[slot]; row = dict(slot=slot, driver_status=("real (registered)" if status == "real" else ("built-in no-op placeholder" if slot == "prim" else "STUB")), real=bool(status == "real"))
            if slot in REQUIRED_REAL_COMPONENTS or slot == "prim":
                h1 = hash_arrays([st0.fields[k] for k in sorted(st0.fields)]); op = ec.operators[slot]; rv = op(st0, 1e-3); h2 = hash_arrays([st0.fields[k] for k in sorted(st0.fields)])
                row.update(operator_returns=repr(rv), call_changes_state=bool(h1 != h2))
            if slot in REQUIRED_REAL_COMPONENTS and not row["real"]:
                row["disposition"] = "BLOCKED"; blocked.append(dict(component=slot, reason=f"driver manifest = '{status}': the operator is a stub (returns None, state hash unchanged = {not row.get('call_changes_state', True)}); no real {slot} exists to integrate UCT_CURL with. NOT replaced by a stand-in."))
            inv.append(row)
        # the current-density operator has no slot and no state storage in the driver
        has_slot = "current_curl" in drv.KERNEL_SEQUENCE; has_J = any(k in st0.fields for k in ("Jr", "Jphi", "Jz", "J"))
        res["driver"]["current_curl_slot_exists"] = has_slot; res["driver"]["state_has_J_storage"] = has_J
        blocked.append(dict(component="current_curl registration slot / J state storage", reason=f"KERNEL_SEQUENCE has no 'current_curl' slot (slot 'uct_curl' is the CT Faraday update) and StateRegistry has no J fields (slot exists = {has_slot}, J storage = {has_J}); the harness owns the J arrays, nothing is registered"))
    res["component_inventory"] = inv
    # ---- C/D. shape / location / units contracts, immutability, determinism, ghost ownership - on REAL driver objects
    if drv is not None:
        shp = []; ctrl = []
        for dims, (r_min, r_max) in (((12, 8, 6), (0.5, 1.5)), ((16, 12, 8), (0.0, 1.0)), ((9, 6, 5), (1.0, 2.0))):
            cfg, geo, grid, st, bnd, G = driver_state(drv, *dims, r_min, r_max, fld=C.SMOOTH if r_min != 0.0 else C.KINK)
            B, rf, rc, dr, dphi, dz, ad = kernel_args_from_driver(cfg, geo, st); Jz = [np.zeros((cfg.nr + 4, cfg.nphi + 4, cfg.nz + 4), B[0].dtype) for _ in range(3)]
            try: K.validate_inputs(*B, *Jz, rf, rc, dr, dphi, dz, cfg.nr, cfg.nphi, cfg.nz, cfg.nghost); ok = True; msg = ""
            except K.CurlContractError as ex: ok = False; msg = str(ex)
            exp = dict(Br=(cfg.nr + 1 + 4, cfg.nphi + 4, cfg.nz + 4), Bphi=(cfg.nr + 4, cfg.nphi + 5, cfg.nz + 4), Bz=(cfg.nr + 4, cfg.nphi + 4, cfg.nz + 5))
            shp.append(dict(dims=list(dims), r_min=r_min, validator_accepts=ok, message=msg, shapes_match=bool(all(tuple(st.fields[k].shape) == v for k, v in exp.items())), dtype=ad["dtype"], interior_geometry_dev=max(ad["interior_rf_dev"], ad["interior_rc_dev"]),
                            driver_geometry_has_ghost_coords=bool(np.asarray(geo.r_faces).shape[0] == cfg.nr + 1 + 2*cfg.nghost), driver_r_faces_len=int(np.asarray(geo.r_faces).shape[0]), kernel_needs_len=cfg.nr + 1 + 2*cfg.nghost))
            if not ok: fails.append(f"050 kernel validator rejects driver arrays {dims}: {msg}")
            if not shp[-1]["shapes_match"]: fails.append(f"050 driver face-array shapes do not match the kernel staggering for {dims}")
            # immutability + determinism (FP32 driver arrays and FP64 copies), per backend
            for dt in (None, F64):
                h_in0 = hash_arrays(B + [rf, rc]); h_reg0 = hash_arrays([st.fields[k] for k in sorted(st.fields)])
                *_, J1 = run_on_driver_state(raw, cfg, geo, st, dt); *_, J2 = run_on_driver_state(raw, cfg, geo, st, dt)
                h_in1 = hash_arrays(B + [rf, rc]); h_reg1 = hash_arrays([st.fields[k] for k in sorted(st.fields)])
                d1 = T4.digest(J1, G); d2 = T4.digest(J2, G); finite = all(bool(np.isfinite(j[G.sl]).all()) for j in J1)
                row = dict(dims=list(dims), r_min=r_min, dtype=("float32 (driver native)" if dt is None else "float64 (cast copy)"), inputs_unchanged=bool(h_in0 == h_in1), registry_unchanged=bool(h_reg0 == h_reg1), deterministic=bool(d1 == d2), finite=finite, digest=d1)
                if be.name == "cupy":
                    *_, Jh = run_on_driver_state(host, cfg, geo, st, dt); Bm = bmax_of(B); diff = max(nmax(np.asarray(J1[c][G.sl], dtype=F64) - np.asarray(Jh[c][G.sl], dtype=F64)) for c in range(3)); bound = TOL5["fp_factor"]*EPS[B[0].dtype.type if dt is None else dt]*Bm*kappa_of(G)
                    row.update(gpu_vs_host_max_diff=diff, gpu_vs_host_bound=bound, gpu_vs_host_ok=bool(diff <= bound))
                    if not row["gpu_vs_host_ok"]: fails.append(f"050 GPU != host on driver state {dims}: {diff:.2e} > {bound:.2e}")
                ctrl.append(row)
                for key, msg in (("inputs_unchanged", "kernel modified its inputs"), ("registry_unchanged", "kernel modified the driver registry"), ("deterministic", "kernel output not bitwise reproducible"), ("finite", "non-finite output")):
                    if not row[key]: fails.append(f"050 {msg} on driver state {dims} {row['dtype']}")
        res["shape_contracts"] = shp; res["controlled_runs"] = ctrl
        # ghost ownership with the driver's own boundary manager
        try:
            go = ghost_ownership_rows(drv, raw); res["ghost_ownership"] = go
            pin, sm, kk = go; thr = 1e-3
            res["ghost_findings"] = dict(
                outer_radial_bc_corrupts_last_ring_for_zpinch=bool(pin["last_ring_diff"] > thr*pin["Jmax"] and pin["core_max_diff"] <= thr*pin["Jmax"]),
                z_bc_corrupts_first_and_last_axial_layers_when_field_depends_on_z=bool(sm["z_first_layer_diff"] > thr*sm["Jmax"] and sm["z_last_layer_diff"] > thr*sm["Jmax"]),
                core_cells_unaffected_by_driver_bc_pinch_and_annulus=bool(all(r["core_max_diff"] <= thr*r["Jmax"] for r in go[:2])),
                axis_closure_applied_to_annulus_grid=bool(sm["driver_bc_changed_Br_inner_face_entries"] > 0 and sm["r_min"] > 0),
                axis_br_zeroed_by_driver_changes_J_ring0_for_m1=bool(kk["ring0_err_driver_bc"] > 10*max(kk["ring0_err_analytic_ghost"], 1e-30)),
                bphi_phi_ghost_off_by_one_but_unread_by_kernel=bool(sm["bphi_phi_ghost_dev_vs_analytic"] > 1e-3 and max(sm["phi_layer_diffs"]) <= thr*sm["Jmax"] + sm["core_max_diff"]))
        except Exception:
            res["ghost_ownership_error"] = traceback.format_exc()[-1500:]; fails.append("050 ghost-ownership study raised an exception")
        # units: the driver divides J by mu0 exactly once, the kernel returns curl B (mu0 = 1)
        try:
            cfg, geo, grid, st, bnd, G = driver_state(drv, 32, 8, 6, 0.0, 1.0, fld=screw_field()); mu = TOL5["mu0_phys"]; r1, jz1 = drv.ScienceManager(cfg, geo, mu0=1.0).jz(st); r2, jz2 = drv.ScienceManager(cfg, geo, mu0=mu).jz(st)
            res["units"] = dict(driver_jz_scales_as_1_over_mu0=bool(np.allclose(np.asarray(jz2)*mu, np.asarray(jz1), rtol=1e-6, atol=1e-6)), max_rel_dev=float(np.max(np.abs(np.asarray(jz2)*mu - np.asarray(jz1)))/max(float(np.max(np.abs(jz1))), 1e-30)),
                                kernel_contract="returns curl(B) in mu0 = 1 units; the caller divides exactly once (Campaign 01 / test 004)", driver_default_mu0=1.0)
            if not res["units"]["driver_jz_scales_as_1_over_mu0"]: fails.append("050 driver ScienceManager does not divide J by mu0 exactly once")
        except Exception:
            res["units_error"] = traceback.format_exc()[-1200:]; fails.append("050 units check raised an exception")
    # ---- H. regression of Campaigns 01-04 on this backend (+ preservation of the Campaign 04 pathologies)
    reg = {}
    for lst in (C.TESTS, H.TESTS2, T3.TESTS3, T4.TESTS4):
        for tid, name, fn in lst:
            # follow each campaign's own backend dispatch: Campaign 01 marks 007 as host-only (ASAN / static legs) and runs
            # its dedicated GPU variant t007_gpu on CuPy - running the host-only 007 on the GPU feeds deliberately invalid
            # inputs to the validating launcher, which (correctly) raises.  (Harness defect found in the r7 / r8 GPU runs.)
            if be.name == "cupy" and lst is C.TESTS and tid in getattr(C, "STATIC_ONLY", set()):
                fn = C.t007_gpu
            r = H.safe(fn, be); reg[tid] = dict(name=name, verdict=r.get("verdict"), fail_reasons=r.get("fail_reasons", [])[:4], error=(r.get("error") or "")[:300] if r.get("verdict") == "ERROR" else None, result=r)
    res["regression"] = {k: {kk: vv for kk, vv in v.items() if kk != "result"} for k, v in reg.items()}; res["regression_count"] = len(reg)
    res["regression_all_pass"] = bool(len(reg) == 40 and all(v["verdict"] == "PASS" for v in reg.values()))
    res["regression_dispatch"] = "host-only Campaign 01 test 007 runs its GPU variant t007_gpu on CuPy (Campaign 01 STATIC_ONLY rule)"
    for tid, v in reg.items():
        if v["verdict"] == "BLOCKED":                  # e.g. t007_gpu without compute-sanitizer: a missing tool is BLOCKED, never PASS and never FAIL
            blocked.append(dict(component=f"regression {tid} ({v['name']}) on {be.name}", reason=(v["result"].get("block_reason") or v["result"].get("note") or "test reported BLOCKED")))
        elif v["verdict"] != "PASS":
            fails.append(f"050 regression {tid} {v['name']}: {v['verdict']} {v['fail_reasons'][:2] or (v.get('error') or '')[-200:]}")
    r36 = reg.get("036", {}).get("result", {}); nd = {(r["case"], r["dtype"]) for r in r36.get("rows", []) if not r.get("discriminating", True)}
    res["non_discriminating_fp32_cases"] = dict(found=sorted(map(list, nd)), expected=sorted(map(list, EXPECTED_NON_DISCRIMINATING)), preserved=bool(nd == EXPECTED_NON_DISCRIMINATING))
    if nd != EXPECTED_NON_DISCRIMINATING: fails.append(f"050 the three non-discriminating FP32 metric cases are not preserved exactly: found {sorted(nd)}")
    res["_regression_raw"] = {tid: v["result"] for tid, v in reg.items()}           # consumed by the register builder, stripped from the JSON
    s1 = sources_now(); res["sources_end"] = s1; res["sources_unchanged_during_test"] = bool(s0 == s1)
    if s0 != s1: fails.append("050 source hashes changed during the test")
    res["blocked"] = blocked
    res["statement"] = ("Integration is attempted against the REAL, unmodified driver objects (geometry, grid, state registry, boundary manager, science manager, execution controller).  HLLD (x/y/z), the finite-volume residual and UCT_EMF "
                        "are stubs in the supplied driver and `uct_curl` is the CT Faraday slot: those checks are BLOCKED and recorded as such - nothing is replaced by a stand-in and called validated.  The checks that CAN run (contracts, "
                        "ghost ownership, units, determinism, immutability, CPU/GPU agreement, full Campaign 01-04 regression) are executed and judged on their own evidence.")
    res["verdict"] = "FAIL" if fails else ("BLOCKED" if blocked else "PASS"); res["fail_reasons"] = fails + ([f"BLOCKED: {b['component']}" for b in blocked] if not fails else [])
    return res

# ============================================================================
# findings, development log, register, evidence bundle, driver
# ============================================================================
FINDINGS = [
 dict(id="H1", title="The kernel is a reconstruction curl, not a compatible (mimetic) curl", detail="curl(grad psi) is not zero: C(grad_h psi) = (0, 0, -(1/(4 rc)) delta_r^2 Bphi_c) exactly on annulus grids (verified to round-off), a second-order axial residual; the DEC curl of the same compatible gradient is zero to round-off."),
 dict(id="H2", title="div J = curl B is not discretely zero", detail="The wide and finite-volume divergences of the kernel current equal closed-form second-order terms; boundary leakage converges. A compatible complex would give exact zero."),
 dict(id="H3", title="Force-free fields are reproduced at second order, at the right location", detail="J - alpha B (B at the cell centres) converges at second order for Bessel and Chandrasekhar-Kendall (m = 0, 1, 2) fields on annulus and axis grids; a deliberately mislocated oracle is detected."),
 dict(id="H4", title="Hall EMF E_H = eta_H J x B is accurate at second order; implementation errors are detectable", detail="Sign, alignment and component errors converge; missing / doubled 1/mu0, wrong stagger interpolation, reversed cross product and mislocated J are flagged by controls."),
 dict(id="H5", title="Local resistive dissipation is non-negative and consistent; this is not an energy-conservation result", detail="eta |J|^2 >= 0 cell by cell, exactly zero where eta = 0, second-order volume integrals; nothing is inferred about the full-system magnetic energy balance."),
 dict(id="H6", title="Z-pinch force is exact; equilibrium preservation depends on the discretisation FORM", detail="J x B of the linear pinch is reproduced to round-off (axis included); the current-form balance is exact for polynomial profiles while a conservative-form (Maxwell stress) balance carries an O(dr^2/rc) defect, first order at the first axis ring."),
 dict(id="H7", title="Helical m = 1, 2, 3 perturbations: amplitude, phase and leakage", detail="Complex harmonic errors converge at second order; the annulus stencil is shift-invariant in phi so harmonic leakage is round-off; the axis closure leaks at O(h^2)."),
 dict(id="H8", title="Anisotropic refinement follows an additive h_r^2 / h_phi^2 / h_z^2 error law", detail="Single-direction refinements plateau at the other directions' truncation; a non-negative additive model fitted on calibration grids predicts held-out extreme aspect-ratio grids (up to 200:1) within a small factor."),
 dict(id="H9", title="Checkerboard B modes are invisible to J but visible to a compatible curl and, partly, to B_cc", detail="EXPLICIT LIMITATION: the Hall EMF and J x B respond to them only through the face average B_cc (exact identity dE = eta J x dB_cc, only for patterns that survive averaging); a compatible curl sees O(amplitude/h) current the kernel cannot."),
 dict(id="H10", title="Integration: real components missing; driver-side interface defects measured", detail="HLLD x/y/z, residual, UCT_EMF and the CT slot are stubs (BLOCKED); no current_curl slot / J storage exists. Against the real driver objects: the driver boundary manager applies the axis closure to annulus grids, zeroes the axis Br face (breaking m = 1 currents at ring 0), maps axial ghosts incorrectly and replicates the outer radial layer; ScienceManager.jz is wrong in the first cell and lorentz_radial's default omits J_phi B_z."),
]

DEV_LOG = [
 dict(phase="development run 1", item="Test 042 global-order rule", observation="the draft judged global orders of the finite-volume divergence without a round-off floor; for the exactly representable SMOOTH annulus case the divergence is 1e-14 round-off growing like 1/h^2 and 'orders' of -2 were reported as FAIL", resolution="harness defect: global orders now use the same 'order OR at the declared round-off floor' rule as the regional ones; a second annulus field (KINK, non-zero truncation term) was added so the rule is exercised on a non-trivial divergence. No kernel change"),
 dict(phase="development run 1", item="oracle self-check: analytic continuation to r < 0", observation="the check compared B(-r, phi) with B(r, phi + pi) component-wise and failed by 3.1", resolution="wrong expectation: the cylindrical unit vectors flip sign at the same Cartesian point; the check now compares (-Br, -Bphi, Bz). The oracle fields themselves were unaffected"),
 dict(phase="development run 1", item="Test 044 negative controls", observation="(a) the Chandrasekhar-Kendall field is force-free (J x B = 0), so its Hall EMF is zero and a control has no signal; (b) the 'B from the lower faces' control is identical to the correct implementation for the screw pinch (its components do not depend on the staggered coordinate); (c) one control reached ratio 6.7 (< 10) on one of four fields", resolution="force-free fields are excluded from the controls; controls whose wrong and correct results coincide are labelled DEGENERATE (not counted); a control must now be detected (ratio >= 10) on >= 75% of the fields where it has signal (declared in TOL5). The rule was loosened AFTER seeing the 6.7 row, which is recorded here; the final run is a fresh complete run"),
 dict(phase="development run 1", item="Test 048 convergence model", observation="the first model e^2 = quadratic form in (h_r^2, h_phi^2, h_z^2) fitted badly (negative predictions) and a strict monotonicity rule failed on plateaus that fluctuate by ~1-5% (the region samples different points on every grid)", resolution="the max-norm error is not a quadratic form; replaced by e = A_r h_r^2 + A_phi h_phi^2 + A_z h_z^2 (A >= 0, non-negative least squares) and a declared plateau tolerance of 10% between levels. Held-out extreme grids are predicted within 0.7-1.4"),
 dict(phase="development run 1", item="driver import side effect", observation="importing Aladin_Driver_v3.1_AIL.py runs `pip install gradio_client` when the package is missing", resolution="the harness blocks subprocess.check_call while importing the (otherwise unmodified) driver and records the blocked command; reported as an integration observation"),
 dict(phase="development run 1", item="Test 050 ghost-ownership localisation", observation="the first version reported per-ring / per-layer maxima over the whole array, so one corrupted boundary layer made every ring and every layer look corrupted", resolution="differences between 'analytic ghosts' and 'driver boundary manager' are now localised on a core region (cells not adjacent to a radial / axial boundary) and on explicitly named boundary layers"),
    dict(phase="GPU runs r7 / r8 (author, NVIDIA L4)", item="050 regression 007 ERROR on the GPU leg", observation="the Campaign 05 regression loop ran Campaign 01's host-only test 007 on CuPy; Campaign 01 itself runs t007_gpu there (STATIC_ONLY rule). The host-only test feeds deliberately invalid inputs (r_center = 0, dphi in degrees) to the validating GPU launcher, which correctly raises. The r8 fix in campaign01.py covered only the first input.", resolution="r9: the regression loop follows Campaign 01's dispatch (t007_gpu on CuPy); a BLOCKED regression test (e.g. compute-sanitizer absent) is recorded as BLOCKED, not FAIL; the summary now says 'open defect entries (kernel or harness)' instead of 'kernel defects'. Kernel unchanged."),
]

REG_CLASSES = ("VERIFIED", "LIMITATION", "INCONCLUSIVE", "BLOCKER", "RESOLVED")

def _t(results, tid, be="host"): return results["tests"].get(tid, {}).get(be, {})

def build_register5(results, reg04):
    R = []; add = lambda **k: R.append(k)
    def allbe(tid): return [b for b in ("host", "cupy") if _t(results, tid, b).get("verdict") in ("PASS", "FAIL")]
    # ---- 041
    t = _t(results, "041")
    if t.get("convergence"):
        ann = [e for e in t["convergence"] if e["mode"] == "annulus" and e["dtype"] == "float64"]; axs = [e for e in t["convergence"] if e["mode"] == "axis" and e["dtype"] == "float64"]
        add(id="Q01", cls="VERIFIED", test="041", title="DEC reference is a compatible complex (div curl = 0, curl grad = 0 to round-off)", evidence=f"{len(t['dec_oracle_self_check'])} random-field checks (FP32/FP64, g = 2, 3) within {TOL5['dec_zero_factor']:g} eps scaling; DEC curl second order against the analytic curl", restriction="Annulus grids only (no DEC on the axis)")
        add(id="Q02", cls="LIMITATION", test="041", title="The kernel does NOT annihilate compatible gradients: C(grad_h psi) = (0, 0, -(1/4rc) delta_r^2 Bphi_c)", evidence=f"annulus: residual is real signal (> 100 x round-off) for {sum(1 for e in ann if e['nonzero_signal'])}/{len(ann)} potentials, closed form verified to round-off, region orders {', '.join('%.2f' % e['region_orders'][-1] for e in ann[:6])}...; axis: converges (region second order, all cells >= first order) without closed form", restriction="The kernel is a second-order reconstruction curl, not a mimetic curl. The PASS measures the residual; it does not remove it")
        add(id="Q03", cls="VERIFIED", test="041", title="FP32 curl of compatible gradients consistent with FP64 on identical inputs", evidence=f"{sum(1 for e in t['convergence'] if e['dtype'] == 'float32' and e['ok'])}/{sum(1 for e in t['convergence'] if e['dtype'] == 'float32')} FP32 series within 64 eps Bmax kappa", restriction="Consistency, not accuracy: non-discriminating rows are listed in the report")
    # ---- 042
    t = _t(results, "042")
    if t.get("convergence"):
        add(id="Q04", cls="LIMITATION", test="042", title="div J != 0 for the reconstructed current (no exact discrete div(curl) = 0)", evidence=f"wide / finite-volume divergences equal their closed forms to round-off ({len(t['exact_discrete_closed_forms'])} random-data rows); smooth-field divergence converges at second order in the interior and at least first order over all cells on axis grids; boundary leakage converges", restriction="Exact zero holds only in the DEC complex (0 to round-off in %d random rows). The kernel's cell-centred J must not be used as an exactly solenoidal source" % len(t["dec_div_curl"]))
    # ---- 043
    t = _t(results, "043")
    if t.get("cases"):
        orders = [e["region_orders"][-1] for e in t["cases"] if not e["region_at_floor"]]
        add(id="Q05", cls="VERIFIED", test="043", title="Beltrami / Bessel / Chandrasekhar-Kendall fields: J - alpha B converges at second order", evidence=f"{len(t['cases'])} field x mode series; smallest last-pair region order {min(orders):.2f} (declared >= {TOL5['order_min']}); axis first ring converges; mislocated-oracle control detected (ratio >= {TOL5['neg_control_min_ratio']:g}); residual force |J x B|/(|J||B|) second order", restriction="Tested alpha = %s and CK (m, k) = (0,1.5), (1,1.5), (2,2.0); smooth fields on r in [0.5,1.5] / [0,1]" % (TOL5["beltrami_alphas"],))
    # ---- 044
    t = _t(results, "044")
    if t.get("cases"):
        ctr = [c for c in t["negative_controls"] if c.get("detected") is not None]
        add(id="Q06", cls="VERIFIED", test="044", title="Hall EMF E_H = eta_H (J x B) accurate; signs and alignment correct; controls detect wrong implementations", evidence=f"{len(t['cases'])} field x mode series, second order; sign violations 0; max angle {max(c['rows'][-1]['max_angle_rad'] for c in t['cases']):.2e} rad; negative controls detected {sum(1 for c in ctr if c['detected'])}/{len(ctr)} (rows with signal), {sum(1 for c in t['negative_controls'] if c.get('degenerate'))} degenerate", restriction="mu0 = 1 inside the kernel: the caller divides by mu0 exactly once (verified against SI-unit references). Accuracy of J x B for force-free fields is truncation-limited (E_ref = 0)")
    # ---- 045
    t = _t(results, "045")
    if t.get("cases"):
        add(id="Q07", cls="VERIFIED", test="045", title="Local dissipation eta|J|^2 >= 0, zero where eta = 0, second-order volume integrals", evidence=f"{len(t['cases'])} field x eta-profile x mode series; negative-eta control detected = {t['negative_eta_control']['detected']}", restriction="Isolated diagnostic. NOT evidence of full-system magnetic energy conservation (no Poynting / induction balance is exercised)")
    # ---- 046
    t = _t(results, "046")
    if t.get("cases"):
        pin = [c for c in t["cases"] if c["field"].startswith("Z-pinch")]
        add(id="Q08", cls="VERIFIED", test="046", title="Z-pinch (J x B)_r = -2 a^2 r reproduced to round-off (annulus and axis), axis regular", evidence=f"max global force error over levels {max(r['force_global']['Linf'] for c in pin for r in c['rows']):.2e}; first-ring F_r / r converges to the analytic value; non-polynomial (Gaussian) pinch second order; current-form pressure balance second order", restriction="Analytic equilibrium and the CURRENT-FORM discrete balance only")
        cons = [c for c in t["cases"] if c["field"].startswith("Z-pinch")]
        add(id="Q09", cls="LIMITATION", test="046", title="Conservative-form (Maxwell stress) balance does not preserve the Z-pinch to round-off: defect ~ a^2 dr^2/(8 rc), first order at the first axis ring", evidence="; ".join(f"{c['mode']}: region orders {', '.join('%.2f' % x for x in c['conservative_orders'])}, global orders {', '.join('%.2f' % x for x in c['conservative_global_orders'])}" for c in cons), restriction="Harness reference, NOT the driver. Which defect the actual driver time stepping produces is BLOCKED (below)")
        d = t.get("driver_force", {})
        if d.get("rows"):
            add(id="Q10", cls="LIMITATION", test="046", title="Driver-side diagnostics: ScienceManager.jz is wrong in the first radial cell; lorentz_radial default omits J_phi B_z", evidence=f"jz first-cell error {d['rows'][0]['driver_jz_err_first']:.3g} (exact 1.0), interior error {d['rows'][0]['driver_jz_err_inner']:.2g}; screw pinch: 'validated_jz_only' interior error {d['rows'][2]['driver_Fr_validated_jz_only_err_inner']:.3g} vs 'full' {d['rows'][2]['driver_Fr_full_err_inner']:.2g}", restriction="Driver diagnostic path, not UCT_CURL. UCT_CURL's own J x B agrees with the analytic value in the same states (interior)")
        for b in t.get("blocked_items", []): add(id="Q11", cls="BLOCKER", kind="BLOCKED component", test="046", title="Equilibrium preservation under the driver's time stepping cannot be measured", evidence=b["reason"], restriction="Needs real hlldx/y/z, residual, uct_emf and CT operators")
    # ---- 047
    t = _t(results, "047")
    if t.get("cases"):
        add(id="Q12", cls="VERIFIED", test="047", title="Helical m = 1, 2, 3 perturbations: all three current components, amplitude, phase and leakage", evidence=f"{len(t['cases'])} (m, k, amplitude, phase, mode) series; complex harmonic error, amplitude and phase errors second order (or round-off); leakage within round-off bound or converging", restriction="Perturbed pinch with fixed background (a = %g, Bz0 = 0.3), eps in {0.05, 0.1, 0.3}, k = 2 pi x {1, 1.5, 2}" % PIN_A)
    # ---- 048
    t = _t(results, "048")
    if t.get("cases"):
        add(id="Q13", cls="VERIFIED", test="048", title="Joint refinement second order; independent-direction series explained by an additive error law; held-out extreme aspect ratios predicted", evidence="; ".join(f"{c['field'][:10]} {c['mode']}: joint region orders {', '.join('%.2f' % x for x in c['joint']['region_orders'])}, model deviation {c['model_worst_calibration_deviation']:.2f}, extreme ratios {min(e['ratio_obs_over_pred'] for e in c['extreme_predictions']):.2f}-{max(e['ratio_obs_over_pred'] for e in c['extreme_predictions']):.2f}" for c in t["cases"]), restriction="Errors judged against analytic currents only; CPU/GPU agreement did not enter the verdict (verdict_uses_cpu_gpu_agreement = False)")
    # ---- 049
    t = _t(results, "049")
    if t.get("summary"):
        s = t["summary"]
        add(id="Q14", cls="LIMITATION", test="049", title="Hall-sensitive null-space: grid-scale B modes are invisible to J (and to the Hall EMF / Lorentz force through J) but a compatible curl sees them", evidence=f"{s['n_rows']} rows, all invisible to the kernel J = {s['all_invisible_to_J']}; DEC edge current of the pure pattern = {s['min_dec_J_over_amp_h']:.2f}-O(1) x amplitude/h; blind ratio (compatible current / smooth |J|) up to {s['max_blind_ratio']:.2f}, reaching 1 at amplitude {s['critical_amplitude_rel_for_blind_ratio_1']} x Bmax; Hall leak through B_cc only for {s['patterns_with_hall_leak']}", restriction=t["limitation_text"])
    # ---- 050
    t = _t(results, "050")
    if t.get("component_inventory") is not None:
        for b in t.get("blocked", []): add(id="Q15-" + b["component"], cls="BLOCKER", kind="BLOCKED component", test="050", title=f"Missing real component: {b['component']}", evidence=b["reason"], restriction="Never replaced by a stub and called validated; integration with this component is NOT certified")
        if t.get("shape_contracts"):
            add(id="Q16", cls="VERIFIED", test="050", title="Driver magnetic-state arrays satisfy the kernel shape / dtype / staggering contract; kernel inputs and driver registry immutable; output deterministic" + ("; GPU == host within bound" if t["controlled_runs"] and "gpu_vs_host_ok" in t["controlled_runs"][0] else ""), evidence=f"{len(t['shape_contracts'])} grids (annulus + axis): validator accepts, shapes match; {len(t['controlled_runs'])} runs: inputs unchanged {all(r['inputs_unchanged'] for r in t['controlled_runs'])}, registry unchanged {all(r['registry_unchanged'] for r in t['controlled_runs'])}, bitwise deterministic {all(r['deterministic'] for r in t['controlled_runs'])}", restriction="Requires the harness ADAPTATION layer: the driver's GeometryManager carries r_faces/r_centers without ghosts (%d vs %d entries) and the driver has no J storage" % (t["shape_contracts"][0]["driver_r_faces_len"], t["shape_contracts"][0]["kernel_needs_len"]))
        gf = t.get("ghost_findings")
        if gf:
            add(id="Q17", cls="LIMITATION", test="050", title="Ghost ownership: the driver's BoundaryManager corrupts kernel inputs (driver-side defects, kernel unaffected by construction)", evidence="; ".join(f"{k} = {v}" for k, v in gf.items()), restriction="The kernel never writes ghosts and reads exactly the footprint of Campaign 04 / 035; the driver's axis closure is applied even when r_min > 0 and zeroes Br on the axis face (m = 1 currents wrong at ring 0), axial ghosts are mapped incorrectly, the outer radial layer is replicated. These are driver changes, proposed in the report, not kernel changes")
        if t.get("units"): add(id="Q18", cls="VERIFIED", test="050", title="Units: the kernel returns curl B (mu0 = 1); the driver divides by mu0 exactly once", evidence=f"ScienceManager.jz(mu0) x mu0 == jz(mu0 = 1) to {t['units']['max_rel_dev']:.1e}", restriction="Applies to the driver's diagnostic path; no registered current_curl consumer exists")
        add(id="Q19", cls="VERIFIED" if t.get("regression_all_pass") else "BLOCKER", kind=None if t.get("regression_all_pass") else ("defect" if any(v["verdict"] not in ("PASS", "BLOCKED") for v in t["regression"].values()) else "BLOCKED component"), test="050", title="Campaign 01-04 regression (40 tests) on this backend", evidence=f"{sum(1 for v in t['regression'].values() if v['verdict'] == 'PASS')}/{t.get('regression_count')} PASS; source hashes unchanged during the test = {t.get('sources_unchanged_during_test')}", restriction="Per backend; the GPU leg is separate")
        nd = t.get("non_discriminating_fp32_cases", {})
        add(id="Q20", cls="INCONCLUSIVE", test="050", title="Preserved Campaign 04 pathology P19: the three non-discriminating FP32 metric cases remain non-discriminating", evidence=f"found {nd.get('found')} ; exactly the expected three = {nd.get('preserved')}", restriction="Their PASS characterises the observed FP32 error; it is not accuracy evidence")
    # ---- FP32 rows of Campaign 05 that cannot discriminate
    nd = 0; tot = 0
    for tid in ("043", "044", "047", "048"):
        t = _t(results, tid)
        for e in t.get("cases", []) if tid in ("043", "044") else []:
            for r in e.get("fp32", []): tot += 1; nd += int(bool(r.get("non_discriminating")))
        for r in t.get("fp32", []) if tid in ("047", "048", "045") else []: tot += 1; nd += int(bool(r.get("non_discriminating")))
    add(id="Q21", cls="INCONCLUSIVE" if nd else "VERIFIED", test="043-048", title="FP32 consistency rows whose round-off bound exceeds half the signal", evidence=f"{nd} of {tot} FP32 rows are NON-DISCRIMINATING (bound > {TOL5['disc_fraction']} x signal); FP32-vs-FP64 consistency is reported for them, accuracy is not claimed", restriction="FP32 accuracy claims need discriminating rows (see Campaign 04 / 036)")
    # ---- Campaign 04 pathology register carried over unchanged (recomputed from the regression data of THIS run)
    for r in reg04: R.append(dict(r, id="C04-" + r["id"], carried_over=True))
    fails = [(tid, be, v.get("verdict")) for tid, e in results["tests"].items() for be, v in e.items() if isinstance(v, dict) and v.get("verdict") in ("FAIL", "ERROR")]
    for tid, be, vd in fails: add(id=f"D-{tid}-{be}", cls="BLOCKER", kind="defect / unmet required check", test=tid, title=f"Unresolved {vd} on {be}", evidence="; ".join(map(str, _t(results, tid, be).get("fail_reasons", [])[:3])) or str(_t(results, tid, be).get("error", ""))[:300], restriction="Open: kernel stays frozen; a real defect needs a separately versioned fix and a fresh run")
    for r in R:
        if r["cls"] == "DEFECT": r["cls"] = "BLOCKER"; r["kind"] = "defect"
        assert r["cls"] in REG_CLASSES, r
    return R

def _self_sha():
    for p in (globals().get("__file__"), sys.argv[0] if sys.argv else None, os.path.join(HERE, "campaign05.py"), os.path.join(os.getcwd(), "campaign05.py")):
        try:
            if p and os.path.isfile(p) and p.endswith(".py"): return hashlib.sha256(open(p, "rb").read()).hexdigest()
        except Exception: pass
    return "UNKNOWN (this harness file could not be located on disk; run it as `python campaign05.py`)"

def load_report_module():
    path = os.path.join(HERE, "make_report_campaign05.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location("make_report_mod05", path); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
    import base64, zlib, types
    if not _EMBEDDED_REPORT.strip(): return None
    mod = types.ModuleType("make_report_mod05"); exec(zlib.decompress(base64.b64decode("".join(_EMBEDDED_REPORT.split()))).decode(), mod.__dict__); return mod

Tee = T4.Tee
TESTS5 = [("041", "Discrete curl-gradient annihilation", t041), ("042", "Divergence-curl compatibility", t042), ("043", "Analytic force-free fields", t043), ("044", "Hall electric-field reconstruction", t044),
          ("045", "Magnetic energy and resistive dissipation", t045), ("046", "Z-pinch Lorentz-force consistency", t046), ("047", "Non-axisymmetric helical perturbation", t047),
          ("048", "Resolution and anisotropy convergence", t048), ("049", "Hall-sensitive nullspace contamination", t049), ("050", "Cross-operator integration and regression", t050)]

def jsonable(o):
    if isinstance(o, dict): return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [jsonable(v) for v in o]
    if isinstance(o, np.generic): return o.item()
    if isinstance(o, np.ndarray): return o.tolist()
    return o

def build_evidence_bundle(OUT, results, rep_text_name="CAMPAIGN05_REPORT.md"):
    """zip: per-test results, configuration, environment, seeds, source hashes, raw logs, failures, reference implementations, reproducibility commands (rule 6)"""
    import zipfile
    name = os.path.join(OUT, "campaign05_evidence_bundle.zip"); files = {}
    src = [("uct_curl.py", C.KPATH), ("campaign01.py", C.__file__), ("campaign02.py", H.__file__), ("campaign03.py", T3.__file__), ("campaign04.py", T4.__file__), ("campaign05.py", _self_sha_path())]
    for nm in ("make_report_campaign05.py", DRIVER_NAME): 
        p = os.path.join(HERE, nm)
        if os.path.exists(p): src.append((nm, p))
    for nm, p in src:
        if p and os.path.exists(p): files["source/" + nm] = open(p, "rb").read()
    for nm in ("campaign05_results.json", rep_text_name, "campaign05_execution.log", "campaign05_execution.log.err"):
        p = os.path.join(OUT, nm)
        if os.path.exists(p): files["results/" + nm] = open(p, "rb").read()
    pd = os.path.join(OUT, "campaign05_plots")
    if os.path.isdir(pd):
        for fn in sorted(os.listdir(pd)): files["results/campaign05_plots/" + fn] = open(os.path.join(pd, fn), "rb").read()
    env = results.get("env", {}); files["config/environment_and_seeds.json"] = json.dumps(jsonable(dict(env=env, seeds=TOL5["seeds"])), indent=1).encode()
    files["config/declared_tolerances_TOL5.json"] = json.dumps(jsonable(TOL5), indent=1).encode()
    files["failures/failures_and_blockers.json"] = json.dumps(jsonable(dict(failed=[(t, b, v.get("fail_reasons")) for t, e in results["tests"].items() for b, v in e.items() if isinstance(v, dict) and v.get("verdict") in ("FAIL", "ERROR")],
                                                                        blocked=[(t, b, v.get("fail_reasons")) for t, e in results["tests"].items() for b, v in e.items() if isinstance(v, dict) and v.get("verdict") in ("BLOCKED",)],
                                                                        register=[r for r in results.get("register", []) if r["cls"] in ("BLOCKER", "LIMITATION", "INCONCLUSIVE")])), indent=1).encode()
    files["README_REPRODUCE.md"] = (f"# Campaign 05 evidence bundle\n\nKernel (frozen): uct_curl.py v{env.get('kernel_version')}  SHA-256 {env.get('kernel_sha256')}\nHarness: campaign05.py SHA-256 {env.get('campaign_harness_sha256')}\n"
        f"Driver (unmodified, used read-only): {DRIVER_NAME}  SHA-256 {env.get('driver_sha256')}\n\n## Reproduce (any machine with Python 3, NumPy, g++; CuPy + a GPU for the GPU leg)\n\n```\nunzip source files into one folder (source/*.py)\ncd <folder>\npython campaign05.py\n```\n"
        "Colab (GPU runtime, L4/A100): upload the folder, `!nvidia-smi -L`, `!pip -q install cupy-cuda12x`, then `!python campaign05.py`.\n\n"
        "Writes campaign05_results.json, CAMPAIGN05_REPORT.md, campaign05_plots/, campaign05_execution.log and this bundle.  Seeds are fixed in TOL5['seeds'].  Reference implementations: oracle_self_check(), dec_circulations / dec_node_divergence, "
        "analytic fields (bessel_field, ck_field, pinch/screw/reversed/gauss_pinch_field, spec_pinch_pert), analytic_volume_integral, maxwell_stress_residual (all in campaign05.py).\n").encode()
    sums = "\n".join(f"{hashlib.sha256(v).hexdigest()}  {k}" for k, v in sorted(files.items())); files["SHA256SUMS.txt"] = (sums + "\n").encode()
    with zipfile.ZipFile(name, "w", zipfile.ZIP_DEFLATED) as z:
        for k, v in sorted(files.items()): z.writestr("evidence_bundle/" + k, v)
    return name, hashlib.sha256(open(name, "rb").read()).hexdigest()

def _self_sha_path():
    for p in (globals().get("__file__"), sys.argv[0] if sys.argv else None, os.path.join(HERE, "campaign05.py"), os.path.join(os.getcwd(), "campaign05.py")):
        if p and os.path.isfile(p) and p.endswith(".py"): return p
    return None

def main():
    logpath = os.path.join(OUT, "campaign05_execution.log"); tee = Tee(logpath, sys.stdout); old = sys.stdout, sys.stderr; sys.stdout = tee; sys.stderr = Tee(logpath + ".err", old[1])
    try: return _main()
    finally: sys.stdout, sys.stderr = old; tee.close()

def _main():
    sha = C.SRC_SHA; ver = getattr(K, "VERSION", "?")
    print(f"Kernel file used: {os.path.basename(C.KPATH)} (v{ver})"); print("=" * 78); print(f"ALADIN v4.0 - Campaign 05 | {C.STEM}.py v{ver} sha256 {sha[:16]}..."); print("=" * 78)
    frozen = bool(EXPECTED_SHA) and (sha == EXPECTED_SHA)
    if not frozen: print(f"!! WARNING: kernel sha256 {sha} (v{ver}) is not the frozen v1.3 ({KNOWN_SHA['1.3'][:16]}...). Campaign 05 certifies ONLY the frozen file.")
    shas = sources_now(); print("Package check: " + " | ".join(f"{k} {v[:12]}" for k, v in shas.items()))
    bad = [k for k, v in shas.items() if v != REGISTERED_SHA[k]]
    if bad: print("!" * 78 + f"\n!! SOURCE HASH MISMATCH for {bad}: delete the old files in this folder, unzip the newest package, re-run.\n" + "!" * 78)
    drv = load_driver(); host = C.HostBackend(); gpu_present = C.CupyBackend.available(); backends = [host] + ([C.CupyBackend()] if gpu_present else [])
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), python=sys.version.split()[0], numpy=np.__version__, scipy=(__import__("scipy").__version__ if _sp is not None else None), platform=platform.platform(),
               gxx=subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0], kernel_file=C.KPATH, kernel_sha256=sha, expected_sha256=EXPECTED_SHA, kernel_version=ver, source_frozen_and_matches=frozen,
               campaign_harness_sha256=shas.get("campaign05") or _self_sha(), helper_shas=shas, registered_shas=REGISTERED_SHA, gpu_present=gpu_present, gpu_leg_status="executed" if gpu_present else "BLOCKED: no GPU/CuPy in this session",
               driver_available=drv is not None, driver_sha256=(drv._campaign_sha if drv else None), driver_import_pip_blocked=(drv._import_pip_attempts_blocked if drv else None), seeds=TOL5["seeds"])
    env["campaign_harness_sha256"] = _self_sha()
    if gpu_present:
        try:
            import cupy as cp; props = cp.cuda.runtime.getDeviceProperties(0)
            env.update(gpu=props["name"].decode(), cupy=cp.__version__, cuda_runtime=cp.cuda.runtime.runtimeGetVersion(), compute_capability=f"{props['major']}.{props['minor']}")
        except Exception: pass
        print(f"GPU detected: {env.get('gpu', '?')}  CuPy {env.get('cupy', '?')}")
    else: print("No GPU/CuPy detected: GPU legs will be BLOCKED.")
    print(f"Driver: {'found, sha ' + drv._campaign_sha[:12] if drv else 'NOT FOUND - driver-dependent checks BLOCKED'}")
    results = dict(env=env, tolerances=TOL5, campaign04_tolerances=T4.TOL4, campaign03_tolerances=T3.TOL3, campaign02_tolerances=H.TOL2, campaign01_tolerances=C.TOL, findings=FINDINGS, dev_log=DEV_LOG, tests={})
    reg_raw = {}
    print("\n-- Campaign 05 tests --", flush=True)
    for tid, name, fn in TESTS5:
        entry = dict(name=name)
        for be in backends:
            r = H.safe(fn, be); rr = r.pop("_regression_raw", None)
            if rr is not None: reg_raw[be.name] = rr
            entry[be.name] = r
        if "cupy" not in entry: entry["cupy"] = dict(verdict="BLOCKED", fail_reasons=["no GPU/CuPy in this session"], note="no GPU/CuPy in this session")
        results["tests"][tid] = entry
        print(f"{tid} {name:44s} host={entry['host']['verdict']:8s} gpu={entry['cupy']['verdict']}", flush=True)
        for be_ in ("host", "cupy"):
            for fr in entry[be_].get("fail_reasons", [])[:8]: print(f"      [{be_}] {fr}")
            if entry[be_].get("verdict") == "ERROR": print(entry[be_].get("error"))
    if gpu_present:
        try:
            results["gpu_vs_host"] = H.gpu_only_cross_check(host, backends[1]); print("\n-- GPU vs host agreement (informational; never a verdict) --")
            for q in results["gpu_vs_host"]: print(f"  {q['grid']} r_min={q['r_min']} {q['dtype']}: max diff {q['max_abs_diff']:.3e} (tol {q['tol']:.3e}) -> {'OK' if q['ok'] else 'MISMATCH'}")
        except Exception: results["gpu_vs_host_error"] = traceback.format_exc()[-1800:]; print(results["gpu_vs_host_error"])
    # Campaign 04 pathology register, recomputed from the regression data of THIS run (host + GPU legs)
    r4 = dict(tests={tid: dict(host=reg_raw.get("host", {}).get(tid, {}), cupy=reg_raw.get("cupy", {}).get(tid, dict(verdict="BLOCKED", note="no GPU/CuPy in this session"))) for tid in reg_raw.get("host", {})})
    reg04 = T4.build_register(r4) if r4["tests"] else []
    results["register"] = build_register5(results, reg04)
    tests_status = {tid: (results["tests"][tid]["host"]["verdict"], results["tests"][tid]["cupy"]["verdict"]) for tid in results["tests"]}
    n_pass = sum(1 for h_, g_ in tests_status.values() if h_ == "PASS" and g_ == "PASS"); n_blocked = sum(1 for h_, g_ in tests_status.values() if "BLOCKED" in (h_, g_)); n_fail = sum(1 for h_, g_ in tests_status.values() if any(x in ("FAIL", "ERROR") for x in (h_, g_)))
    per_test = {tid: sorted({r["cls"] for r in results["register"] if r["test"] in (tid, "043-048") and not r.get("carried_over")}) for tid in results["tests"]}
    results["exit_gate"] = dict(target="10/10 explicit evidence-backed dispositions with every required accuracy / integration check met", tests_pass_both_backends=n_pass, tests_blocked=n_blocked, tests_failed=n_fail, dispositions=per_test, every_test_has_disposition=bool(all(per_test.values())),
                                open_blockers=[r["id"] for r in results["register"] if r["cls"] == "BLOCKER"])
    results["certification"] = dict(rule="Required accuracy or integration checks that fail or cannot execute prevent full certification; a documented limitation does not turn an unmet requirement into a PASS",
                                    verdict=("CERTIFIED (harness verdict; independent source-level review pending)" if (n_pass == 10 and frozen and not bad and not any(r["cls"] == "BLOCKER" for r in results["register"])) else "NOT FULLY CERTIFIED"),
                                    detail=f"{n_pass}/10 tests PASS on every backend; {n_blocked} BLOCKED; {n_fail} FAIL; open defect entries (kernel or harness, see register): {sum(1 for r in results['register'] if r['cls'] == 'BLOCKER' and 'defect' in str(r.get('kind')))}")
    print("\n" + "-" * 78 + f"\nEXIT GATE: {n_pass}/10 PASS on all backends | BLOCKED {n_blocked} | FAIL {n_fail} -> {results['certification']['verdict']}\n" + "-" * 78)
    json.dump(jsonable(results), open(os.path.join(OUT, "campaign05_results.json"), "w"), indent=1, default=str)
    print("results written:", os.path.join(OUT, "campaign05_results.json"))
    rep = load_report_module()
    if rep is None: print("report builder unavailable (results JSON is complete).")
    else:
        text = rep.build_report(results, OUT, "CAMPAIGN05_REPORT.md"); print("report written:", os.path.join(OUT, "CAMPAIGN05_REPORT.md")); print("\n" + "=" * 78 + "\nCAMPAIGN 05 REPORT\n" + "=" * 78)
        C.show_markdown(text)
        try:
            from IPython import get_ipython
            if get_ipython() is not None:
                from IPython.display import display, Image
                for pth in getattr(rep, "PLOT_FILES", []): display(Image(filename=pth))
        except Exception: pass
    try:
        bpath, bsha = build_evidence_bundle(OUT, results); print(f"evidence bundle written: {bpath}  (sha256 {bsha[:16]}...)")
    except Exception: print("evidence bundle FAILED:", traceback.format_exc()[-800:])
    print("execution log written:", os.path.join(OUT, "campaign05_execution.log"))
    return results

_EMBEDDED_REPORT = """
eNqtfWl320a27Xf/CjSy+pFQSGr0EKnVd1mK3JGi2F62kn73KboQRIIiIk4NkDJl2fe3v73PqSoUOEhyurO6LQKouc5UZ6rvguZa
M2iPOtnwejeYTrrNV3zzLAzDD+l4lE+Cq2nW76R50B3lwevT1z8evw1ud1obwWEyGCfZ9TDYeB7UJ2kxKYKNnc3mxvONqBUEh6Ph
JE/ak12tH+fSWP1DI+iledoIhskgjYLm34NBkt90Rp+GwSSdTYJ60i9Gwac8m0xSvBpJ6XUp3Hr2IdgP8rSY9tFVJ2tPXLmru6Bt
RrPxvDW+C+rlY2xqtP4oRkOO7Og2ze+C4XRwhUll6KSXBjo6LMMgLYJuPhoEH/bkwzgfFWlQTBJMMPjUSyZBmrR7AacbtPtJNiiC
ZNjRL9kk6IxQ7O27M/3WwiI+ywbS9KhoYKqT3rNnnbQbdOuzRjDe3452nwX4L+sGsyBDzdEw3cVgJtN8GITD9SSUz5P8TsuZslmR
DTGkYTtlM1ejUT9ytYpJXp9Fq0vje1l45pfj6FpZMUyGaMAbRTIMlxTLht1KMTyHOo+/BxtB2seqhU2+9OvOgv39YKOstFF+Na+6
4f1st3U//pp+lebqyVWBfoK/BZtpczsACJoXf9/Hm+eR9mRrfb/59fqrtpnO2ul4EhzJn2w03J3vySyUbMeIU1nYCfZWr65etz9K
JpFseWW5oiW7trD0i5XnFzGdAWO0dmU9trqYlY60nxWT+qzwKjWCsPXHKBvWOQvB0hnBGmVkNoXZDBkXm5hc9eu9NOk0gnz0qTDz
Tos2kKufDK46SdDeldVpRy3gRT/B6MMv7Ob337+E3rvfh3wZhApto+kELZyHX/Dqe/z/ix0WmkZTMrA2B8a+Iy3C+l+k+BdTOGw2
m6GUjStlv4QX0gu/CNZy7LvstJWMx+mwU3+849z2GvkrzGmY9ZtOIlmh2zoI1FVarnHauk4n9Su8vf8aye8QRIQkiDPgymrFfjK3
ObPivLl54e8DAUvKFj3SQ1CF4f7WCw9/WbifDuvYvr/tB0OtVZzvDoNmgKYwg/8FLLz/9cP7dx+PsOL3z4BHO5vhbhAejkD0JtlV
PwV5LNpoMQ2u86STpUNQzPoBSvMxGBdZIxBYC8Yj0M9JBqqLFWr3W8EAhTYbW43tYDgaNpNZVtwNBukkz9rBYNRJMaokB8KlHRJn
UsibNB+m/WA0BGAPp/2pEkRWRGdZh+0Gb95vb62/ef9ipxW8Dn48Ogza07wvjGEiBF5JbjvL29N+Qmwt2B5b70yTftAFuBXESr5p
l5O8S/JOs5hk7Zug3ml1MPKNaM8bVK3AqrbR2iSfttms9pspiU6KYjrQeWDkWS9D1/56NQ1nKDIOogHyXoCsgx10CFIDkCadb9QA
oQCD1Inno+mw0xx1u0T3EV9ieoM0KaZ52mmFDdmtLe7WGVrPhp2U0IsOg/ZdH49YaMy4kwG+rlMQjmDUrc4IU8hZvP4p62A18BMN
S9fdbJhN0ubtqD8lb8U0Za34+VM26UkzXPwh9tHvoZ6xf/bbvws+p/lIUCbxV5o/++kMU5UtKFeh4PhKSWC7obs/TPp3aJG9BCfc
F2myGIxGGEc3S/sdAD4Bbkq5QxrtZjl4ajacpHlGJOd7tsVvV1zUBFy725/O7CJucxEP0qIA9KH1dtrs5mlqWg8I7PWNRnCyCZFi
3EuA/XjYcA9RYH7uB1uNYLv1anvzJX7rKGQRMLGTzUbwvPVcafYCPhz28DpPivSml+TNn7GNWEHbf52IhP7RwhakjhOAk/Z3wI1J
b5P+FOBmduYggPjAibqFa6doSjcXbX0SJDkJ+ti0AiCeBIOs6I/a0sIIYha2CK1yy1BjBDR+n4+6WT/FKgsmXqW95DYbTXMLqw0H
2Lp2aHwWHNil3eHSHsU/YQrpJMHfunyOdLQG408U6ICbzQSwlFxjLAdxux0k1wnZ3tyEPOhuQ6gqKFp1gJZ26gVkvHLGYwBHD9IK
iNgnjhUdFETCw5+DwT7W9OMv796d/dQIfj5++zNFyr40PNjnWpMMgsoCh9EAwJKL0MffAV41gqPWAehrcoPx7gVpnhMux/1MQE8p
2kkApJk44DtoClCOR0qa5ONe8PG4OQW6BYPphkiDe8EwvUaB29RuAmEgKwrC8ToEwynwqBNsrqNCA4LrCK8hGlxfp7mdHz5XVqbh
7/JJZDfnOTcH2xJ8OfnyP1tKOj1CbOkDEW48KjIOqSEQjdUgPgua3wKbLIYJnrcnzWI6FlEVbe8KtJsZZZM7hccr/Wt5h2CJgiaH
I+BekN6C/hHIAAhASK66wo2DBZTWsYvozE//SKZF0TxNQZA6aE5JmBAD0ON+sQeB6XqYSt0hyNad+1Que5NjcPD/FkRs2u83i7ti
kg5sLfKCNL/VfczImrqAgJIuv+DS/r+mAB9gedzLMCtQC9AKTg+UYDc4iT+TZiQyeIMXcY5XTcwHc8r3FGrlu8wrSwA0bJJHCM5W
qdVV0qdkCHYMiCd7ANZCDJl8yijRClIKeBoUztNrMEcceO4anIel3g274U1hSratpjZgkXxPaYOZ/G2qhX9JZp9SLhJxDkRCBxTU
Qc6GfJGnWB52ElFa+WQOQAmoelc+TKyYkRW6pIZXCSqn/wJ7z67ybKqjQtdpsWd4KllcTg4EhvaxnbGPXwAe1zyR+dQRbXqFzTkM
jWSDFKNOIfl1Kh2h8sHpu8Ofj360W/qSW/peNvT7oBhBshploNOOZIzTHHLXlZE6VPoRjmB5JnlK/QYwPwYdAQEvuBopZAEeBElZ
+qaQRby2Iz+OEpJRNIERmEQH3DLHJAgU8kb2A3NKPmeD6aSHIf345kzEKbCSWdppUiCBVJXLAR2cFrRq2knNWBqWNVtYcaSN5Zsb
PC4BmSYGlqRdJ5rZNXrFNXpD0oUdz4aKsn3QJNAwSsYTEAxh631SrZxdQ4D87EsvfUAlT+JYVmA/jgI4zOdoCFLWOAVtybnARiCs
T8cUuv53a2Njd1MoCiXm08310631U6AkeNSVgEvHMSsZM2nktHAigqBBJ+PGkZLd4ByQYBkxwU5HqJ6Zcj/5FKTY19fA0l6cA0W/
x2/ido//mufPePpMckqNggAeoANQpYCtAx9MsZeAZdE9EJDdbHU5g8P3v67/4/2vHuEbkrKD/EwoH7KKOTfYpf9B5PZe2gb1vhpB
nlUpWylsn3TuFsdEimBYsZOg7ola6xs70GIA/EDViaIUNDF1CoMTA5IOWgzi/URoPfrljezm6Yjg+tmQGtZeFBchWHBBLeF2BAFb
4sooM1AZEpyic6RSwzlJY0cEgu+DjtBJ/L5olETfyqMWcQz1GIN8gcliG3AcqvNNrZdd95qgIYRkbse6J5vWPDKF40V57uCMVK+D
GRUpZgbi0b8zK/98gyt/rGxEGvXFlg9Hr08bwXSIzcgg0HUsARpd/QFoBghfpyNKgYB6dkYOfo2DOZ+drDpQgkYhRghc+SKdpW2d
iOFX/ZRKGUc4uOv4M0Ij9WIyvdK5GMIGMbboJeMUiyCyga4HZZFCm8NuULgegJokV6CMZBgdHAXzAc4HxQAj7o0wTajcAJO9bFxu
hiPJVMctzmMBujESiJSYGShRT2RNIzIpTQLRKcEVisEdrhI5jXBfOW2ysIKqZREqZwtfyTBgzA+4zfNjYKTuNqieUK6vz96fvjuL
3xyfHn2k5uFCNSSD5CaNx/3RpLDKRqPiKEu3CNZ5PVqiXFNlHdQzbAH4v+f9bk0LaD1eX1+HEMEXSkLtyF8geMG4P3maDupclRo8
uY6K1phKIdFEqIo09JSYMiH2i3KcYQfnlHqHoASwi0c3+2f5NMXnM2oEbnaD9DzkLocXIgeSffEc/uE8FEVteNHCSXFQ1EVFpCX5
Pf2q46F6AjJ9XfSu5ajH8+PsGD3uHqfcmgBLJ3E/uQNFrJt3bKabXdfHgMFxtr+5vWE+yBmSpbxtMZqcceSNopvWu0NvDNyuoDus
lyrO+VXmDqSzXa+XEGQvLBsdQ11S96eFghgjyE4df4rsc7pff9F60Qh2IPCV/XAhZRXPzkXhcnEeenJYeFE2aLR/2IPO5G6MT1R7
hqL+e7ETCpbgGwm9+WQ0Ce4TFDTYIkg7+aQgdtbrfBUPNqlukl9bIU6w1E9+QycAldU92A6iqDoP/tcjeuWAKANOooBDI9TBhRcX
uqH90TX+V4dIdD5IZnUUJ00cDWOy9BB0HwrczVfRsgYwqVETU+snV2l/HyrP9LzGgdcuvgb3qifDGwywxmZeRV/DcleWjm3FDp1v
XKwe9GxtbWuthyJra82ttY0WrBpOl9rjEG+a5RjD3v9seYNgUzP5UsdADITfmRdYjeALFU91q3yLvgR1XZzIFu7L0afeBQEXAHzh
cGrSBwBjNrveAa9PXumpZzwln9Ou7ZeqKOlFEDqcoKWY32PWaY2H11XE2P63EWNblp1EejlKLAH7XX8vHgC0huy0rhx7Uch6HKIs
CIWimyEsbu1E37J7nvbmT2zd9u6ifqphtaWVrdmO0Sc4+CDzdubxndgT+XZh9c+3rC554RPsJ8GWqpY3iAoU2UAUVGlkVO22X7Ke
+hhLy4XD35PPoawvlndQ7G87lLBqoc92YeYrygoeaG0PlczCfqZCVeXMaFULJ5DXpXqxqnMWeLB728LiAKTqUqDIw8qWdnVPiXM8
QOqiNTxKJVtMWgVu9zWoe+RsJdC8rIKBaXQRP3f+bfzc+Xfx01B3yr1CUkGSV1D1KiMoMfbpvGAJ5m6twNwhmKEcVr1DbLQUm6nY
bAZHMAx3/wQ27+yWxyirn1mCyjsxjvL9xQ188W9v4Iv/AIF1m/fwxvkqo1i1RLFVKcV2V5++m9JeKzDqJlrrFvd3cyeK9v7kcK3y
KxZy+80jLXwG76lRBw8MdQUozsOdoRUVxV+pgf9mGHyxW9F6AbRwKqV6dk4fx8FXoPJF7NVbBM6X/zZwvvx24LQiKRRs+mWjtf2n
AHZW2d+ZKQNl5gAaonZMvkWQFnVZDNRdInkO9oVYU/C8kZ83tYvd1mb3a/jUnbbqONut1bvBmAQOV0CplHYe5AKVjX65WzbklDnf
i+bvIeLzMra1isVNfvX0TfYEi1e+YLFxUdl+HC8Ls9ogF1nqnS9Xb+Ra+bDpP2x5W1x8ExMp5rbzZsWeqecPJWiqHhdQVfoJ2Iku
8dM2i0LBq91lQsAWhQD/SNOsmH0J/fN8q7KZr+IEepvR0yXCjZXY6W/ibikk5cnwOq1TUCQaquI2NnpOqsUhL0Y8IWETSFdiqGfj
EY5VUsYI4BbdllZfPOEtLtPmVnWZ5uaazHowIKb1Tap9+6McIh/b+7RPq8xeVYaf10ETsoLv5jfaKZnXrU6XxoSHdnyBDmPDlyib
R8M5xfDcdnKCSySDH74FL0n55OQ7d+j9IXRHXFLc/AHtQO5YWUUPoJbVMKqi+HgoGCbK1Po9ea0qaP3jF7v9Oqc+yPO5UcrAdWRl
ExjbeHixwPZB8cC7+5U+co8kdI7iR3QMUrwigkA9XXLz8RDo+SJaDmkcqWgMRAkew4dkqOpW5R1VOCz2w11PeBC1eVmjClYWTq2O
2xF2QOIBpjYPqE7cbPeIqFZcEBL1dJnhByO3QuoYU6wTg0KztC+I3aECqT+ICBvTxiAmBg9kucBdAYk6tWkNUR3Ivzvy7wv596X8
+0r+/QGswGrzfPerUv2n6tvV3qL74eHrX96/Pv7HW+hDPxy9f/fhrDXohNaBbXjbCM6wKbDn4Qe099d059mnzhPfuF+l9lN+sySU
+7pD9jsMhDmFM1sI+tVJzJbMoVj0sGh1iZZ5LzgVNfQefJz2g1Ojzdyj0pvDULcxtROkOWDl/EIX4nU9/K7iWNusuNYa19T6WcXD
NnR119beq7uAqD474iiRU9iEERWWTmuXvUQJUfxAT31JFano6Y3pGIyooO1mBGtoMlFxRUcEYwChpvnLTz8GaktfW4PDnO29i+5/
MtZiY9kCD+TKntfMM0j52loQ/D40r2GKSLI+3rb48tDfhCCf9uH/umZK8om1UbCc7lkvc65gxk5tDBamv70Kd1UDRVOMmUFlx625
Cf4Tn1NaYjqpkEV5jQ6sERw/4WLWp6V4SGelljf98O/B8VAMnCOaTf41xR5Rz89Kvx6exYe/fjiF3QI0TByO09w4WYnVXXxywHIy
uiIY5xK655BuFJNP2PTe3VM2yhr2ZI/UhPNfwRvxBaN/5HiqMsaibZJGJWOfvKX5ro21T8U52iwlp9FJ25nYFI11DHTt+O2PR++P
8M/bM+t8VH/99vXpf58dH8K/5v++Pjxr/nj88fDD0dkR5wOVpGKwzFV7gGmqT3vdmee4Asl5SjfrtTW6jInG9CAC7NTpY7NPLYNx
QGlar7eqd98ePbAz1h+OJqjHhXkDq18nuQsOz4LpGNiQ0gPx/euPH/EVZlJQVNrLsDGQiWBx78PmNHHuIdXF0RpstFrqGja7ClB8
912w2Qo+CuQ1SJgyePuovcwAm9rLXA165J6HlJip36fzQ0ryc35u1VrUBYE5ELdJqxp0C7aGmCuIc1zcOjrCeUUqxKxQu4BAdXvv
vzYNULpi+7b5jz+9bm49fyHtXlYqwNKIDyh/qRUs+cLa13Uu0bLa6Yw4kXYW6ht7oVkG4wlNx5hQFsoWiLUABN9ObAtAiHRs+jys
uvsvGYItEBs8XhgKRDQgka3qRQxsYqU3tvjPNv/ZicTLed16FbsetAG2W9Quzm8uznc3X7B1PRIJbyyHKZYb97RVedquPO3ABFOZ
qvZT8MSf9I3/jNsF8GW6e4TiiCIgEHrjCjkuSlfyoazmfXSDXawbyToZy3e9NIbT2p1AvB327yKFRdQV9lbTwnFyCxJPDK8BBIPL
he9mLyLZC2+qpi9jWy3o4Jp2VbcBWzesnqQAHuUPJZ6hbps39WOtH4+zcWzqyZoS/tK0s1BLX5oSv54dWlicTtqqXAjHd5OemNlB
xAFu6zTpj+/c3GGbkgI83K0H+kZKli90+lIN01YIhBv9RDQ0pj/3rJ1ef/+9/XI9m83BPyi5ftQpXI+n4okOUhTqPA6n7znQw19/
fA22OqTHlHGboDNQOxkb34C5DWxPMcBGUINPO/fOH3x72kli09SqItp8XDZfFtQ5kwNBVHUTG09jPMZ07JoSxy8iR0Z/H4KQbrWC
H1ME0+TiHJmRUicgPXSMglMrVistvSmiOYJKqjhHUG906/EmcpZxPMjx6dTqLObHsA1iPh0M6AshqiqIhCJcznVH2VI2wXQrVnX8
1a0KoZpTd0z6mdUtLjJQCB7MRaTjA4tIzcDxLHEI2k5kn7hBfCrDPjiU80rzONFxOyYiY4qZWCFDpzwxzgBni/PtYsJnCcylEzDR
zY31zY01SF/CLkeWc1+B4kASgpi2di9d10SojseYR3wF/+7YlABV/Cot7FnXlYU6BjtFRNwL3rw+Pl0o0gUlMSVaJnRLgq9AoSiL
gNPAjy8TT0Q7f68NGXLMCuADRewVMi2+g1RnhveBblrUXkGCJdh6q1uDvDU0o80xL1nTGte09rUVetCytvbaTlaHSSmCTiGyiC0I
JRTjIdZveK6KAOQ2/ETT0jfScyEUF2PjGE9PpVTddTojaVfcP2wQG/13+6Wz0h5L9Og+8ymhDDu9ulIJDGUznOgZxNMKPlAhLBEE
bUhcSZtEI/O8otr0TSuMtARdo3RKhBOXnVtRkU/7c7J1KQ7RvYRIflvEzsvkQ6kiEGnpu4BU4RYiN/2SSvm0jvMtyKG0qJ6+ZA6J
lU7l6GuRT5SHQIk8htOQoJuoPfCDJh84QYrTKp9xxOOf0Y1i3L+s4rER4KdW199GcQL6WMcTmonRTCzNXETmLRvjA36yQUWwfxlX
G3/ejrDB7bSrW2fpn3g+Qed3UVmWvwOIDbHcdYAim0cHWedAVh+OuHrrJPcR4eut2XPPu1mxHgDC9py7uCy2iY3cI4uQty4UxJ1/
xBNVoBLV5+VcBPS8T/OmgLqNzKxLyxg3nNL6bEG8djt7bgj8hP4KrzOeviJPt7BAo3YrDh/Ou2lPiBZBSPDqfkLtKpWIJKHkvsG5
jOaexLPGn2RZX2QY+k4YXvT1QoEJ59n3U7j6F2lrLbg3QVaWmNZQzs3fAHevGg0WiZrt6MOHdx9gdMMaXV5eogoVTmA7prAqgwCD
kDkQHvYcbrAS1/X7EKXDqu72KlVB0jITJf9VHZsoY9QkshinRvoJdUpSkC8IQ9jVeYLIGbCqcSLd3NcCuk8mwLJG2lz7GpzfX6Vf
oTq+7+ZfqwsxkZlLIFplcKKhoFOKPSkuiSoC2DYDMc0iXqj0YDmAn4weEWZ+bBjPvNaTxh1LucSQY85OqWBoxwxNAOuQc/nF7vVX
em8HNL7QidobuM+/HcW4ln8MQbHDkiF98QiIHZV49URLKEvukRCaN+xfQ2261GCWVOU2HnVjDp39GAKTC4Hhx/IFa3iLwVocQLUG
C8ib3KdLAiI9jAq96G7EiJ3qxkLiSwrl7dzvQ7cZt4UXy8MXdVUUA5wEntWeW0ol3UowarVXEEXblnHKQhPilcJN3LPhdPca7NrT
LV2sW5O6NS3N026rgp0O+n5+it8UoxMVEJ1ZVoIu8JcxRIw90tgWHd2ei3b0QwIPSxcvE36G/zXrm+s7OQJRofVHMBUd0OlrEuMN
yIacqFaBpFhL1eVPmJtnmqqrf37kvdeFEODtj2Bk9l6YYIDyhY5aw0Cw+NCxJDNpy224xTJ+gUwAsIrMEUPifnRRHLwv+AyC8tJg
pPbehtG3z4zjoXjGNCrQMu8v6CnxZ9aiwUhLjX92hc2MKp909ks/cR02vC9Lhh3geFG3/g+ySnQnGKjSf9mgNMx6uWm7DL3GKEB1
723TNYvq0G/MapV2a2wX4Kxnq8UK2IlVFcKnDmWmzMFsZmw2kx8MwVi2MD42V/wqTa/LLE3zRKULR24oyWff3tj2VngxhyQ8rtA1
nGbX6aC+WTbKbqSd2uiGlGH9ntZNvMWiqolaxGiUfLEjvIF2Fw0hsSpVEgQvuLmUVQowFRGkcdQt9pa5q4uNqy4O9PCzU6aEEtBq
JW1z9gjoVfglMiPn/zHW7nh7K2bleMjIFr/N2kVUmR3mgXFKZc7sWyu3hFpj6UU2E5PzhedR3fcY+tYqhr4Yo+xoRz3JrzL4MeKw
Rg3uri+pl2x2jsN+eQIP9XknEYJ8kxYzn/s9zPhYQ1nsUn63tnY4F9xcCb72o6ZhJ+pAloZSOVk5R4nRvq0wCb6uRGov+e6JGLIy
AdupvuneLq6QrADoVMzi5JQe/SqXiAW6tys/2xVckE9kDEu/cCxRdaklKCi2WQj8noqVK/+xGh6+GEQ+t8qWO6oV2672AjPs3i6+
k5ILXBIlF97ZMJimCazzPklwpwt80pEgerwpoesSnh8xvFAj6R7mlO2SU7Y9DzPlW3gjG7qK5bHG7UNfpfYqrqi1H/hqVyA2K+AX
wudrrkJsVyFWzJ3j7LIuMdfFQlEJLO2Suy/lxvOzR/satVyZtfe2Mttq6SVvF2fnyEZ7GXu6iAQCQz3VPYmCbs9R0BFTraDmEhlc
z6Dv9KjED035sCthpr78nZv4UnqUa3B18GLSM3HXxtToRZoqVSb1sLG7oGClbOErN0gYTANCKH1ZY9T2hA2sw4HxVi+j/07oVcug
aZPrQOjAnurLA2cWYJAS25LXnrUAfLFu2HPGoyGX1djZSpsuT5911r6S3A+xVuCwXSBgbCZE1o9hMiwuG061Jbg95EgntCHx0NTB
UtNkWrSx5HEe+3Uo+0lTyw4YSoscDbJE6RFZ/XSLWmwoWCaVt5vL3j4u11O/JVK839G8yP/lZHbwZR1SxxcEMZSvXRChiUUMRPH3
MLlSad6nVCLPe1RsqWhfOu8tx39wFvfEvDmVeluPltis0q0HCOIitVt1cG3bMwPRQ44AlS7mjhPll74G1z521MB0VBK3uxCbXYh1
F/Rw8UgZq2SWnFWlmC/7sYQ+ekRwjs6pY+Aid7ZyNpU3BmegJ4bY4snIKwXhqCKdm75q0pdPWtoqwdaM2xqV6/GCFFsVel2VaFnT
3yTk7iwIuX8OrR9AVeKnKF9PKjjuXh9oYPu48pUHswCJW/otp8oeXvdF+FSdkwY0tIjYR0RsvpOt+hbk3Xr1n0DeP4d4Cwgt4ikW
JD6xmoCHCh3oopVFCRwYMxcu5sIlxiL2RIIjjINLHJdKtSVFjuLOaBIfqBfs0YEUpAHeHDsqnRFGnXz8KK6JJPx2PpWMesFAzwl9
MGO56VxhFG9Kr4mNGnkN0YCeO1X2iWx5f70O9MfL53/9q3N+0mRFIkGoEmAPp7h/HL09+vD6jIH8mqhGs8Roy23ABV2CjFUBZiFp
JNoNg7/CiArrJey5lkIBdw2VuniEb5oaBiUY2SpdR94LMwLFN8uk7GroaWgJbL9Q2LbtX5gdlTZj6aPcZn1p+vF238wAKpywXJ3Q
I80del/SJQtGYSXB7oMZXjQHAE7UsFv8p0TL54/RLTjb+eQL+xG8r1CY71wCHT69FzFigZj9hlf9BQnjN6/EPyldVlL0RN7XbyJG
O5FVF3JHMH5vFy2FWkRKANp7nwAMYzevi2+mV3ME8Dd6IRvu/2Bbuue/xW7m5+I5X/n6z/mv/0ku/XZJMqTdQHd9n3JzzxNymdrL
lIEqvSZLSL4J69EDxcqFpbheJr1iLEXDESf29kAjtpi4gQq/Ep3Z6KYiLBhlQlUw8BV67huZ/dO5/YuncnubRGk5z9evhtFX5HbK
PhuVV8wMqTnt/LcrsjX5eno/aZMJnCvjxrzBaGjdAubq6wVhRPLpvInz9Vyx2o7p6Vi69aDIYAPw/pzUr7V10F7tlSVFDH9KQbjD
gl+zeKW0owQugHA1LXhSSORjElKlkWVyUqXAMqFJMo0aisLNjMv0YEKoQFx4HACViL5VyLf5zxYV5LBciYp8JZLGUvMhVLUlIMpz
WZaeGp7W+PIDwuIJnaSoV3EPFFgIxUY+H6HYMV763LEliTBE9/1hISFZUMcizYLNF/gH0Q4y6HPmfgRiKHEz2YGQ8NrWnMt6dus5
jHum1t21tbnp+PRKehchSNtEhKEcJySHJQny4jebPMv7AjIQ1EywAHS0f+DQCs/O2sqidPepfnWR/wtdVL84Iuh9YpMratlPZbWL
5afoQPXgBO3SOqB7jdnIWYFLUiqvqx+zIQSWhY9v8nhhUR4uzoVZVsL4Up98fvwjp2ro01wBtL+6tvno1/aEno4LlJ03xtHBRDBM
wd6448Xic+M7i/BMYn34cBS5vzqvsYwGM/JJHUyqUXvuPPNkvvxyBV8Wm8iNiLNjYV8SALvqWF5yuZN8nQkh1gF+XpY8615QYcQ2
ota+Ra7Yz/IFbtlL31tzwPx7TyNn+yF9jh7X/zu59saq1iUiWn6J64D5bVnuQ/Jr6a4+MqzivFtGQt8Pv/qh0K6isi0N68LiyRIy
Kwb/IquHx3gWwqplAY2I/FA5hvQ9XsosrpRabqLXyZ+7uZVKOp2NzvGRCV2odm1JlqSKsfxRAd0kR+wvXWWnD1i9rt/KoY2s/GdF
5W9huo+x22+Qul+Fi25rc3NexnEZYnbfdoHCQnHaLkoYJsHAhE8bdIMO/d6iRk2+8MBxuhmXfkJwAIT+fVmprblSpCfLyuG9V3Kv
KmAvq1GR4bSOhAFLrGDd8zeeVz/LRPvxa2PKQFgYebuXmrKD+CT9dU/qYcpLudgrF7tybOkhoUIj+I2BvpijrkLGHIEFoI8m4llu
nOtDS3bCmfkxSMbIYZh75vvID9mPvkXbWHgiMnxpbr5WTZH6qhzTRSU5QXsxOcE8ivnL4MeOC/uh4CsMQeL91JjWA53l4bqn5N0G
lNuFcmHlFY3VqcQCnW55WmJbwTAP+2gkcHgKp/2RmPhXij8z3zkCDzpclRPwqIMWZzv7yo62LFQO171aGu9vPxqDi/7eKn8bWPcO
Y87zyr2bnZvZxeXsLipml+WJBIyKbFHMWAxvlKSracfPusrIAOeMe269dmP43sMZAq7YdMd2Dag/YsgoAdYBIao6pFe81q1p1d5b
wKg8gR2xVqp8VfMcwmOhDDGLibGSdWs0qobzLvPLSoobfc9wqVCvtXgyHf5hjg4Xao0uNMRFbdCKAwg4c64NflSiSJNAK2rZyhQs
zLJo87auSmCrtRhV7t7Dny0+sXFWtrbolSkFlFnZXRQ88oWOptc9SScb+uSjKBuICVwavs5Wwgs/CmaxJ42meLAxqA5WtrcUK8/D
x3LbKv0oo/+RLn4oAXXsnNo4+iudKOZRburZkLwrptI3ev/9+RS6tvV1e90CLL6ETuvhqa0DkKQVp53X8LgBZkhHem9QMzn6m9T/
fs+8gUf3k4FZdI2LXTVRmAJX/E7iTbPLD/Yi6eQr+22yHjDNJ+L0vLTEC/kVHhsMm4SMiAX1sjl4QWcuacVico3efzyrhu/4JB/V
jtIQo6qc+0tEtJky9DyyLkkijPGvQ5wKHTbJYZ2YsY6C8nBUppeSx3Vv6vpCMqFZ39+TuuksCnq2DW/XfTOLn8IDHgA76nbnknaY
I+pJrBto3fLKobqj+kG77aDcO1jPZffw3kthfwvnvx1xRuXbKh4xgLEQbDLf5zChmqxkhYnOJZp298BYUidxj/aSGbkHTJkQExGv
3NZyK5Eq2y28kQfMh6MHFv9VtGy5K2+WLLEy5cUq7GrOoU+UjJxvbMniqiPK8RMzgQdMUlZIdm10seT8oZ5G5vzhOZhVDjXGHcmq
E4Vq0NCQ6DEFtIHJXBJ305tHc8S1Ctm4WpAKTsuQfiYVgFhJzo32y1j/2H6g0YJZMJDSolqAN9hVdSA+42XG8UVP2sNlSb+Nug2Z
t7MuVRRzjo+4FGTiaeVM8CwlUJsWQpOrqAVAVkQ22IRizUWjOj9SaVYdbW2ctgnLxTvVENkOYq8DHpHNZ/ZlgKmIXV9eAb9bCSZg
2JgJQCSGhHNQ5wIhY7c6T1ZjVaOdnAIL+qtLqqxc00wJsPu4FgtkejHturCBMu36/H0VSZ4nd9QAdZKxgS6kx6aHHliZRDCXgZ8u
+bpNLW9rt/EX6UNGmre9UGBYHsGUDYpKEKRRYPI2pzazY8tXyR5faOIFewWN0ck6v2V3DZMbDI6PHsjlsd7JBST0FLZDCaR3bskc
jYKTC6vEbzem2I5J3+uwNN2DhcKKY7MdU2zHxCOt5SoGYM24Yo5L2zAaUhmavq5CmHQbux1c6ZJxvDqfPuMvuTXzTuDzu+GtLkMH
EB6pqNKxZ2yaCKpv4UUv18GU/TFmynmQm/Dy/X2Nhnx44X1Heh1BXPZliptBLHyo9q/vzBBK4uAfWkY35ma8Mhw0WkRuc/lBh2kF
Vi/9P+buK2i6sAzNblO9XEixhAez5fcaHBiHX2t5oVsJHVLFgK3B2p0/EmaYkZvhbJrfdd5Bgr/WXzhaNM0smGVU8lYzbJ66CGTL
1c0jdZjqM27fmEvIDK3wyy28pNwAVWKzfKsTEmHvINeLU4gTu5YmrbulUvePA24HlrbJUjYEPvAhU4cLEdu1cXDoNWNWfJVqe94w
c1KJ1+BYy2PtnGBSfeesG3PvP6t1J5YlWPgmtRY+2YSxCMMrv5k8hxKlBYlDJB4uSnyA70pfJFjLBmbNl7ELYkuFPmW6ahvG2GFR
WXGtaFZc1sf0rLOnRcdVrvRafnddyh5Ip1Ucu1ZstLizAseQLYqprZD5QII498pcN9Co0ZVj9jW0yrRZpeWuqVkq1aIFo2ool5Oo
zsLak37lKwdPJxKbywxMhd6Q5tQHIzqqqy+JtCLOI856p7ViZHbYVOkWVcWJXMRpXzHq1ye48UiIAkar6jJQ2TuLK/0ZFmK/UvwL
lwm+NA27+03cTT2F3n3S0Mh9kxsjEjPaXNAapVnXQO2iJSoXc0fHzMunRnGyxnwSNcrBlVoY5FQkGs03EZgsVCbhVMlbcK9mbi9e
ZPC+pMxAS5p+yWMMsRaUFBqaMmMF0ZvPfmIj4q1meFamNZmdl18vKmBl8kv2hBOZKXmQNQ+7w46qrhZtE7E4DBirwp7Zn/fuipky
v94O9SU9JHLE7XDvN39gPoXHb5+JmNCfwX33ww4ME/yJtdlzQKu3ImkKLL3eRtaXhd01N7qYPESsUtxphoXnTNFhcsXUfzv6cPzm
GIkg1oPT41+Oz16fHb97i4fjt4fv3h6e/vrx+LcjJpE0+UzWcY/Rx3env+HSID9foPlMn9IbHuytZFymHVmLeGXpsJDMD0Y8ryYm
0ZuuXQqSPduUpqIu60uGFoltM0mqsdvIJJV6cr8cw+TGPoOGpiQJI4RgZFFM8sLmkqD2315QVekRyWEM67o83Nhprl1KejvuxPLN
dgl4eKqTrEUdmxuDcd/ToVwe69CZUX5+8guTsk1dV5nCR8RgDEjC9wwuGOIohmuTRE5FvYKwZI4QTIp5PcXNX4oqM2lVmAFABmjf
7hcCK6GL2pVuVAEZCjZJf4pYku7T/HZ96qPXbUXXjllaxGoPeYfz/ddnlXDfnClI8Ilja4ujKsWl4URGY98h1J166E0vk9AhaRGz
6aAsLYWSa8fbXG5W3YpyuU04sifZxSp5ziJBnzlqybSaShhlhYQoGsiuiSaupl3VhLDwsm9VwnP1oGmPJP2PxY8y9Q+NjWZqNfu1
xskxiyWpQ8q7MXH5X45UOzkTMcKuyysmmWTHhHFKkjJev2sgr1a4JIJUNmgWIw+Bs6KSiFAa0IxBDZuDsK/kSL9lk9baXCKWF0jE
oldEub0bc+KSolSZ7l/OF3MGjpH5pD5/zdT60nJRWM2K9bIVWLFBr3Qz2RHvBPVlBAspRP3ssZnJklNKEOVR/b6bUeNjrL18ELhW
xYu+cGlEy2GF4TPo5YbFJyyYMRosy87JJv6pljXL/kieRgNkEimdsOQ63bXqdaaSIWmSNqrHsYaTG3hFHbsj07Aa+WqKyjW1NyCn
q+RsTYvFoL6G03zjZ+WOPl1nlw+evUoaT01K2bFp0lwiJ5Y2oUG8SNbAFXOJ49g1vmsFx5V0mbxUeCAO3E6NVNfQ27/I1a4SQygp
IfSZysCmSGCIXbGDcdpdvTOZl9KV6UwzTag6lMR+HPOainJrNrPUVWrzSGGwdynEkp9OT39syK5gQRqVG7ndbXMut2c1K1Zi0nco
hSkaqoPVFQkuzXJLiONlQNUXadCJRPfjXFjeZffgpXjBFbq4KapB4nK4dkAhMfcQq9wl4KAUd0Xr2TNJ3Ku8sbyd0Ob4FL6oOjsh
OuSDzO3lX29O5Q30QyYPJ8D6GdKOrv1olrR++bqPo+sw1hfx7XZr67JhspFZgVe6AHll6yq3yIGRdIyWKvq80SQzDC5FkyC3M1zu
MR9pvyyNE6ScHd15eyz+GCK+wlNHc0/JzaqaOTUqM6macZDiFzo25qNgBzPbPnbw2phYx2NxoB5keqUCeTezv3Hn3ZldjnOmLf0d
XF63WlvXzc3LqLzTmW5hMugxdUod3m5vm+fd7Vc8eTClMzS6qakjzsNWHeAAoYwi5VK5OzG92znqRgFNLZy7ARnG7cTeKI37ZJVa
qaOjdiDiOW+NsCjMqJTpWBJpIee8rklTh0dgwV3zHeEQVm3IqTpw3ivlnWQp7HdIyoaAVpcfDFjlckZrITYywDFLE4VJjs2m5JW8
RKZNovUEhOuy9WzLQSGaRVDIiFSygKPOZdXptfXH50vOTmOMDDlW3YdZBLl1WvznsD3FTUBDPUCR4but58DMy4ZXR5MCy/3BRg7X
QrrrlzYiU5uuL/F4jS6D0YAU60Ruhz2IP++xx5InGH0T2Zc3MT2jlslVW8+QMNIkHVoTYcHIPJ/kYkLBeN6cKWTIrnB8u9nakdUY
G6IA8tz1aLJNpeA8GSU7kRGh63oHq0uU4BNrPEYNxTjhaeXlzSWZT8SIvB78N6LJ08512vRvv5laKBUuP5r2qbdGQ0Pcca34a6nK
mLrb1rMwrIgmr1qBTRHeScXXQ9wzICCJscOLLdPUmJypyFGexKEiE0w8OgcmNRP6lJOzNcl0y7zeejT71GPOZMkmT0w6++n4o5Uw
/bOGMS5zawZJB3iiBujEJhuVDIhyErbMhyYCXXy1Bjma8gkni9TJfNIkIjuYWE9wCtsny7NwiHDOrDYBtHrmOAttee+tnhA6tgqe
OiZttP70K+obv66K/GJs+2CD025jHIbUUDKf9fQHlxtStktOaTx9+XcQPw8qS2837Fruk1vIb7hHH8meJAfo1/3cpuoYSXk3bETL
8/9pirm/GDtaJE1dV5rSzHhiapOWntROZSPycrpiJ3FmNf8gde4l4X2jaaxNUmtgMK5AsPmk05dXW89/2HjZarW6z1/J/v5ydCbe
PY8lujZ+PTQfswqHosgBf4tKEuCzTyMVccp8kNCzA4XeTgfI/guXKFzayzzAsBHsqRrj/4h7QeQPB7ulHb5//eHs+PVpUKdjkzGi
RX732+o7c+zl19ccFoXhH9fTDHqmTnmTH2iKkKamI1/rJDWuf69xaMi81PDViUJz48Rb6lNgApcUMYv3hFduOy/MLcNkv00VbOTG
n8XOceH72OaxlP6Zolf13m0m6RmaBL3hIc/6Ja350woZ+uD6eeTdRdXkEe6wt2Skz6sr8wvuofigN0R8j/S4JlP9ASigRIlrSk45
oeAamblk9JL3uuEubwYlwL+GtBaNymXfYDqQeDuFv3HesdEiSHwlHbc+U9Msy7VE98Jjf3nb8/w90Kv0b6rL88CW1908l6gvNX65
jGYPqAK9vJhuBDZg18c3m6S3UYpNolSaQ7/yRo6dH1yW5ENN92yHKSRvJUIbjFreUpl2da7Ba22wbltErjHFVpE2iL0LiWLVr5Bs
2qG7HU40N565GWqyYi8jsAi5MjIezgDT5nTGbOMyOTuqpstbW/cSGlMtJ5eaR/5KB559nytyZJNsB5KG2mtWaZbkvF6VeBok9G+o
Z+a5ZMm9KZrkkHJItpe9Q3nA+11ENQBYNdq9/wj5nueymxtks6oNMK5DpdQjyWOnQ2CTHqs017+6RFKzOhjDy6YLUkjd8Lu3R4F3
x0sjKO8e4BUJ4ENB5dKEht5ho4Qn9gq3zOeF4+NmjCSw+BT9PjQJ8au3MMh/3wUu/W/S50l3z+X8xdoJN/oekC156WmhaacCEUZI
kBS4vw/fiaANvdWlR2QMMWv9AQEMgv/lstuA+H5BnTX30uEEr5qa/7ZIyC6RkkitIo1gjp5Oc3NpyzKyCkEAcsDHX3/5WCWq4/K2
HkdVS6GQLkQQaxg1pSa400hTA4fymerG+pKr4uUWdnqMS2J9ZFMG4dvHBQbd5qswan2iLFtn05Wrl/ji2TPsShyzfhyL8BTHVITF
sXFWMncxcNHlWcTj8hp43EMvCkL7DAbMv/VYriCJY01gE9pHMQKqfziFMcEUVAVFbn/qmDvdx2C8SGLs3wPF3rFbSae+agHCFYCC
6JrI3M90vru9sQH/92f/H4Bnr6k=
"""

if __name__ == "__main__":
    main()
