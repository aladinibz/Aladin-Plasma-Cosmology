# -*- coding: utf-8 -*-
"""Report builder for ALADIN v4.0 Campaign 04 (tests 031-040).  Contract: build_report(R, here, name) -> markdown text (also written to here/name).
R = results dict written by campaign04.py (campaign04_results.json).  Every number in the report comes from R; the prose states what each test claims and what it does NOT claim."""
import os, math

def f(x, p=3):
    if x is None: return "n/a"
    try:
        if isinstance(x, bool): return str(x)
        if isinstance(x, str): return x
        if math.isnan(x): return "nan"
        if math.isinf(x): return "inf" if x > 0 else "-inf"
        if x == 0: return "0"
        return f"{x:.{p}e}" if (abs(x) < 1e-3 or abs(x) >= 1e5) else f"{x:.{p+1}g}"
    except Exception:
        return str(x)

def o(x):
    if x is None or (isinstance(x, float) and math.isnan(x)): return "n/a"
    if isinstance(x, float) and math.isinf(x): return "exact"
    return f"{x:.2f}"

def olist(xs): return ", ".join(o(x) for x in xs) if xs else "n/a"

def tbl(head, rows):
    esc = lambda c: str(c).replace("|", "\\|")
    out = ["| " + " | ".join(esc(c) for c in head) + " |", "|" + "|".join("---" for _ in head) + "|"]
    for r in rows: out.append("| " + " | ".join(esc(c) for c in r) + " |")
    return "\n".join(out)

def v(e, be): return e.get(be, {}).get("verdict", "n/a")

PURPOSE = {
 "031": "Smooth Cartesian-regular fields (m = 0..3) are compared with the ANALYTIC Cartesian curl, including the first physical ring and the phi-averaged ring-0 current against the on-axis analytic current. Global, first-ring and fixed-interior errors are ordered separately; finite output alone is never accepted.",
 "032": "Every odd-even (checkerboard) pattern of Br, Bphi, Bz over all axis combinations is injected. Invisible current is a documented LIMITATION, not a FAIL; the claim 'the kernel detects all grid-scale structure' must be falsified. Contamination by a null pattern added to a physical field and the rank of the operator are measured; an exact rational evaluation of the discrete operator separates round-off from truncation.",
 "033": "The amplitude 2^k of a fixed smooth field is swept to the edges of the floating-point range in FP32/FP64: overflow, underflow, subnormal results, loss of significance and false zeros are detected and classified against the exact rational evaluation of the operator.",
 "034": "Nearly curl-free fields (large gradient background of amplitude A + a small physical signal) are evaluated against an exact rational reference. Absolute error, relative error, signal-to-error ratio and the amplitude where the signal becomes unrecoverable (signal < 10 x error) are reported with round-off and truncation separated.",
 "035": "The dependency footprint is measured entry by entry (NaN poisoning) and compared with an independent stencil implementation; unused padding is poisoned with NaN/Inf/adversarial values; required ghost entries are poisoned and must propagate, never pass silently; the launcher validator is probed.",
 "036": "Extreme radial aspect ratios, tiny positive radii, very large annular radii and anisotropic cells. Fields the discrete operator reproduces exactly must match within a conditioning-aware round-off bound; random fields must agree with the independent reference; the curl-free vortex Bphi = 1/r measures metric truncation near the axis.",
 "037": "Analytic helical kink (m = 1, two amplitudes, two phases) and z-modulated m = 1..4 fields. Azimuthal harmonics of the reconstructed current are extracted by DFT; amplitude error and phase error are measured independently (per z plane), together with leakage into other harmonics, at an interior ring and at the first axis ring, under 4-level refinement.",
 "038": "Sharp (grid-aligned and offset) and smoothed tanh transitions of Bz(r), Bphi(r) and Br(z). Checks: the integrated sheet current equals the discrete telescoping sum of the stored boundary values; no opposite-sign current (overshoot); localisation; weak (test-function) convergence of the sharp sheet; pointwise convergence only for the RESOLVED smoothed sheet.",
 "039": "Awkward dimensions (primes, minimal, nz = 1, nr = 1), g = 1..3, FP32/FP64, axis and annulus: canaries, input immutability, ghost layers untouched, reference agreement, repeated launches (and hostile output pre-fills) bitwise identical, NaN in unused padding inert, NaN in required inputs propagating, IEEE power-of-two scaling exact, explicit device error check, non-default stream launch, compute-sanitizer (memcheck/initcheck/racecheck/synccheck). The host leg is the same suite on the CPU-compiled copy and is NOT GPU evidence.",
 "040": "Randomised grids (seeded) crossed with hostile families (random, smooth, uniform fields, checkerboards, huge/tiny amplitudes, near-uniform + noise, grid-aligned current sheet, helical kink); two identical passes must be bitwise identical; nothing may be silently non-finite; earlier weaknesses (025, 029, 031, 032, 035, 036) are re-run with all their failures preserved.",
}
PLOT_FILES = []

def make_plots(R, here):
    PLOT_FILES.clear()
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except Exception:
        return []
    d = os.path.join(here, "campaign04_plots"); os.makedirs(d, exist_ok=True)
    T = {k: e["host"] for k, e in R["tests"].items() if "host" in e}
    def save(name):
        p = os.path.join(d, name); plt.tight_layout(); plt.savefig(p, dpi=130); plt.close(); PLOT_FILES.append(p)
    try:
        # 031: convergence of the three metrics for the m = 1,2,3 fields
        plt.figure(figsize=(6.6, 4.5)); h0 = None
        for fd in T["031"]["fields"]:
            if not fd["field"].startswith(("m1", "m2", "m3")): continue
            hs = [l["h"] for l in fd["levels"]]
            for key, st in (("region_err", "o-"), ("global_err", "s--")):
                es = [l[key] for l in fd["levels"]]
                if max(es) > 1e-9: plt.loglog(hs, es, st, ms=4, label=f"{fd['field'][:16]} {key.split('_')[0]}"); h0 = h0 or (hs[0], es[0])
        if h0: plt.loglog([0.125, 0.0078], [h0[1] * (h / h0[0]) ** 2 for h in (0.125, 0.0078)], "k--", lw=1, label="slope 2")
        plt.xlabel("h"); plt.ylabel("max |J - J_analytic|"); plt.title("031: axis grids, global and fixed-interior errors", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=6); save("t031_axis_convergence.png")
    except Exception as ex: PLOT_FILES.append(f"(plot error 031: {ex})")
    try:
        plt.figure(figsize=(6.6, 4.5))
        for (mode, dt), mk in (((m, d_), s) for m in ("annulus", "axis") for d_, s in (("float64", "-"), ("float32", "--"))):
            rows = [r for r in T["033"]["rows"] if r["mode"] == mode and r["dtype"] == dt and r["finite"] and r["rel_err"] is not None]
            plt.semilogy([r["k"] for r in rows], [max(r["rel_err"], 1e-18) for r in rows], mk, lw=1, label=f"{mode} {dt}")
        plt.xlabel("binary exponent k of the amplitude 2^k"); plt.ylabel("relative error vs exact evaluation"); plt.title("033: dynamic range sweep", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=7); save("t033_dynamic_range.png")
    except Exception as ex: PLOT_FILES.append(f"(plot error 033: {ex})")
    try:
        plt.figure(figsize=(6.6, 4.5))
        for mode in ("annulus", "axis"):
            for dt, mk in (("float64", "o-"), ("float32", "s--")):
                rows = [r for r in T["034"]["rows"] if r["mode"] == mode and r["dtype"] == dt and r["grid"] == [32, 32, 16] and r["amplitude"] > 0]
                plt.loglog([r["amplitude"] for r in rows], [r["signal_to_error"] for r in rows], mk, ms=4, label=f"{mode} {dt}")
        plt.axhline(10.0, color="k", ls=":", label="recoverable if S/E >= 10"); plt.xlabel("background amplitude A"); plt.ylabel("signal / error"); plt.title("034: signal-to-error ratio (32x32x16)", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=7); save("t034_signal_to_error.png")
    except Exception as ex: PLOT_FILES.append(f"(plot error 034: {ex})")
    try:
        plt.figure(figsize=(6.6, 4.5)); first = None
        for c in T["037"]["cases"]:
            if c["ring"] != "mid" or c["mode"] != "axis": continue
            for q in ("Jr+iJphi", "Jz"):
                qd = c["quantities"].get(q, {})
                if "amplitude_error" not in qd or qd["amplitude_error"]["at_floor"]: continue
                hs = [l["h"] for l in c["levels"]]; es = qd["amplitude_error"]["errors"]
                plt.loglog(hs, es, "o-", ms=3, label=f"{c['case'][:22]} {q}"); first = first or (hs[0], es[0])
        if first: plt.loglog([0.125, 0.0078], [first[1] * (h / first[0]) ** 2 for h in (0.125, 0.0078)], "k--", lw=1, label="slope 2")
        plt.xlabel("h"); plt.ylabel("scaled amplitude error"); plt.title("037: azimuthal harmonic amplitude error (axis grid, mid ring)", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=5); save("t037_amplitude.png")
    except Exception as ex: PLOT_FILES.append(f"(plot error 037: {ex})")
    try:
        plt.figure(figsize=(6.6, 4.5))
        for r in T["038"]["rows"]:
            if r["dtype"] == "float64" and r["kind"] == "sharp" and r.get("weak_errors") and max(r["weak_errors"]) > 1e-9:
                plt.loglog([l["h"] for l in r["levels"]], r["weak_errors"], "o-", ms=4, label=f"{r['direction']} {r['alignment']}")
        plt.xlabel("h"); plt.ylabel("|weak integral error|"); plt.title("038: sharp sheet, weak (test-function) convergence", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=6); save("t038_weak.png")
    except Exception as ex: PLOT_FILES.append(f"(plot error 038: {ex})")
    try:
        plt.figure(figsize=(6.6, 4.5))
        for dt, mk in (("float64", "o"), ("float32", "s")):
            rows = [r for r in T["036"]["rows"] if r["dtype"] == dt and r["exact_field_rel_err"] > 0]
            plt.loglog([r["kappa"] for r in rows], [r["exact_field_rel_err"] for r in rows], mk, ms=4, label=dt)
        plt.xlabel("conditioning factor kappa"); plt.ylabel("relative error (exact-for-operator field)"); plt.title("036: accuracy vs conditioning", fontsize=10); plt.grid(True, which="both", alpha=.3); plt.legend(fontsize=7); save("t036_conditioning.png")
    except Exception as ex: PLOT_FILES.append(f"(plot error 036: {ex})")
    return list(PLOT_FILES)

def build_report(R, here, name="CAMPAIGN04_REPORT.md"):
    env, T, cert, TL = R["env"], R["tests"], R["certification"], R["tolerances"]
    plots = make_plots(R, here); L = []; A = L.append
    A("# ALADIN v4.0 - Campaign 04 report (Tests 031-040)")
    A("**Numerical pathologies, axis robustness and adversarial stress of `uct_curl.py`**\n")
    A(f"**Harness verdict: {cert['verdict']}**  \nCertification rule: *{cert['rule']}*.  ")
    A("This is the harness's own verdict; independent source-level certification of the frozen code and this harness is still pending.\n")
    A("> Scope: the kernel computes **J = curl(B)** (mu0 = 1) by cell-centred reconstruction. It is **not** the Faraday constrained-transport update. A PASS that characterises a limitation (checkerboard null modes, cancellation, dynamic range, ghost ownership, ...) is **never** evidence that the limitation has been eliminated; each such finding is classified in the pathology register (section 5).\n")
    A("## 1. Source, environment, frozen hashes")
    A(tbl(["item", "value"], [["kernel file / version", f"{os.path.basename(env['kernel_file'])} v{env['kernel_version']}"], ["kernel SHA-256", f"`{env['kernel_sha256']}`"],
        ["registered SHA-256 for this version", f"`{env['expected_sha256']}`"], ["source frozen and matches registry", env["source_frozen_and_matches"]],
        ["campaign04.py SHA-256 (harness)", f"`{env['campaign_harness_sha256']}`"], ["campaign01.py / 02 / 03 SHA-256 (helpers)", f"`{env['campaign01_helper_sha256']}` / `{env['campaign02_helper_sha256']}` / `{env['campaign03_helper_sha256']}`"],
        ["seeds", str(env.get("seeds"))], ["UTC", env["utc"]], ["python / numpy", f"{env['python']} / {env['numpy']}"], ["platform", env["platform"]], ["g++", env["gxx"]],
        ["GPU", env.get("gpu", "none")], ["CuPy / CUDA runtime / compute capability", f"{env.get('cupy', 'n/a')} / {env.get('cuda_runtime', 'n/a')} / {env.get('compute_capability', 'n/a')}"], ["GPU leg", env["gpu_leg_status"]]]))
    A("\n## 2. Declared criteria (fixed before execution)")
    meaning = dict(order_min="last-pair observed order for smooth-field convergence claims", conv_base="coarsest (nr, nphi, nz) of every 4-level refinement", region_axis="fixed physical window for interior order claims on axis grids",
                   exact_fp64="error floor for fields the discrete operator reproduces exactly", alg_factor="exact identity: <= alg_factor x eps x scale", fp_factor="round-off bound vs exact rational reference: <= fp_factor x eps x Bmax x cond",
                   ref_equiv_fp64="FP64 kernel vs independent reference (relative)", safe_k_fp64="declared safe binary-exponent window FP64", safe_k_fp32="declared safe binary-exponent window FP32",
                   recover_ratio="signal is recoverable only if |signal| >= ratio x |error|", kink_amp_order="order of amplitude / phase / leakage convergence (037)", leak_factor="leakage round-off bound factor",
                   sheet_weak_order="weak convergence order across a discontinuity", sheet_resolved_order="pointwise order of a resolved smoothed sheet", sheet_int_factor="integrated sheet identity tolerance factor",
                   repeat_launches="identical launches that must be bitwise equal", seeds="per-test seeds")
    A(tbl(["name", "value", "meaning"], [[k, str(val), meaning.get(k, "")] for k, val in TL.items()]))
    A("\n## 3. Summary")
    A(tbl(["test", "name", "host", "GPU"], [[t, e["name"], v(e, "host"), v(e, "cupy")] for t, e in T.items()]))
    n_h = sum(1 for e in T.values() if v(e, "host") == "PASS"); n_g = sum(1 for e in T.values() if v(e, "cupy") == "PASS")
    A(f"\nHost: **{n_h}/10 PASS**.  GPU: **{n_g}/10 PASS** ({env['gpu_leg_status']}).  All-pass on both backends: **{cert['all_pass_both_backends']}**.  Unresolved defects in the register: **{cert['unresolved_defects']}**.\n")
    if "gpu_vs_host" in R:
        A("### GPU vs host agreement"); A(tbl(["grid", "r_min", "dtype", "max abs diff", "tol", "ok"], [[q["grid"], q["r_min"], q["dtype"], f(q["max_abs_diff"]), f(q["tol"]), q["ok"]] for q in R["gpu_vs_host"]]))
    elif not env["gpu_present"]:
        A("> **GPU leg: BLOCKED in this execution (no GPU/CuPy).** The campaign is NOT CERTIFIED until the identical harness is run on a real GPU; nothing is inferred for the GPU from the host results, and Test 039 in particular cannot be passed by CPU emulation.\n")
    A("## 4. Per-test results (host leg unless stated; the GPU leg runs the identical code)")
    for t, e in T.items():
        h = e["host"]; A(f"### Test {t} - {e['name']}  [host {v(e,'host')} | GPU {v(e,'cupy')}]")
        A(f"*Purpose.* {PURPOSE.get(t, '')}\n")
        if h.get("verdict") == "ERROR": A("```\n" + str(h.get("error", ""))[-1500:] + "\n```")
        for be in ("host", "cupy"):
            for fr in e.get(be, {}).get("fail_reasons", []): A(f"* FAIL [{be}]: {fr}")
        if t == "031":
            A(tbl(["field", "global orders", "first-ring (ring 0) orders", "fixed interior orders", "phi-averaged axis limit orders", "final global err", "final ring-0 err", "final interior err", "ok"],
                  [[x["field"][:30], olist(x["global"]["orders"]) + (" (round-off)" if x["global"]["at_round_off_floor"] else ""), olist(x["ring0"]["orders"]) + (" (round-off)" if x["ring0"]["at_round_off_floor"] else ""),
                    olist(x["region"]["orders"]) + (" (round-off)" if x["region"]["at_round_off_floor"] else ""), olist(x["axis_limit"]["orders"]) + (" (round-off)" if x["axis_limit"]["at_round_off_floor"] else ""),
                    f(x["levels"][-1]["global_err"]), f(x["levels"][-1]["ring0_err"]), f(x["levels"][-1]["region_err"]), all(x[k]["ok"] for k in ("global", "ring0", "region", "axis_limit")) and x["finite_everywhere"]] for x in h["fields"]]))
            A("\n" + h["statement"] + "\n")
        elif t == "032":
            A(f"**{h['n_invisible']} of {h['n_patterns']}** pattern/mode/dtype combinations produce no current; {h['n_visible']} are visible (axis stencil). Claim *'the kernel detects every grid-scale structure'* = **{h['claim_all_gridscale_detected']['holds']}** (must be False).\n")
            A("Patterns that DO produce current (counterexamples to invisibility):"); A(tbl(["mode", "dtype", "component", "alternating axes", "max|J|"], [[x["mode"], x["dtype"], x["component"], x["alternating_axes"], f(x["max_abs_J"])] for x in h["patterns"] if not x["invisible"]][:12]))
            A("\n**Contamination** (null pattern of amplitude `a` added to a physical field):"); A(tbl(["dtype", "family", "amplitude", "delta J", "|J|", "round-off bound", "within bound"], [[x["dtype"], x["family"][:30], f(x["amplitude"]), f(x["delta_J"]), f(x["J_scale"]), f(x["roundoff_bound"]), x["within_bound"]] for x in h["contamination"]][:24]))
            A(f"\nCritical amplitude at which a null pattern's round-off contamination reaches the physical signal: {h['critical_amplitude']}.\n")
            A("**Operator rank** (unit-vector probing; singular-value gap):"); A(tbl(["mode", "grid", "unknowns", "influencing", "outputs", "rank", "nullity (influencing)", "nullity fraction", "sv gap"], [[x["mode"], x["grid"], x["unknowns"], x["influencing_unknowns"], x["outputs"], x["rank"], x["nullity_of_influencing"], f(x["nullity_fraction"]), ", ".join(f(s) for s in x["singular_value_gap"])] for x in h["operator_rank"]]))
            A("\n**Safeguard statement.** " + h["safeguard_statement"] + "\n")
        elif t == "033":
            cc = {}
            for r in h["rows"]: cc.setdefault((r["mode"], r["dtype"]), {}).setdefault(r["classification"], 0); cc[(r["mode"], r["dtype"])][r["classification"]] += 1
            A(tbl(["mode", "dtype", "observed safe exponent window", "class counts"], [[m, d_, str(h["safe_range_observed"].get(f"{m}/{d_}")), str(c)] for (m, d_), c in cc.items()]))
            A(f"\nZero field -> exactly zero current in all modes/dtypes: {all(z['exact_zero_in_exact_zero_out'] for z in h['zero_field'])}.\n")
            A(f"**Silent wrong-but-finite results** (kernel returns finite numbers that disagree with the exact evaluation; {len(h['silent_wrong_finite_rows'])} rows, first 10):"); A(tbl(["mode", "dtype", "k", "class", "rel err"], [[x["mode"], x["dtype"], x["k"], x["cls"], f(x["rel_err"])] for x in h["silent_wrong_finite_rows"][:10]]))
            A("\n" + h["statement"] + "\n")
        elif t == "034":
            A(tbl(["config", "largest recoverable A", "first unrecoverable A", "largest A recoverable if only round-off", "first A lost by round-off alone"], [[k, f(x["largest_recoverable_background_amplitude"]), f(x["first_unrecoverable_amplitude"]), f(x["largest_amplitude_recoverable_if_only_roundoff"]), f(x["first_amplitude_unrecoverable_by_roundoff_alone"])] for k, x in h["minimum_recoverable"].items()]))
            A("\nError table (finest grid, both modes/dtypes):"); A(tbl(["mode", "dtype", "A", "Bmax", "signal max", "abs err (total)", "rel err", "round-off err", "round-off bound", "truncation err", "signal/error", "recoverable"],
                  [[r["mode"], r["dtype"], f(r["amplitude"]), f(r["Bmax"]), f(r["signal_max"]), f(r["total_abs_err"]), f(r["total_rel_err"]), f(r["roundoff_err_vs_exact"]), f(r["roundoff_bound"]), f(r["truncation_err_exact_discrete"]), f(r["signal_to_error"]), r["recoverable"]] for r in h["rows"] if r["grid"] == [32, 32, 16]]))
            A(f"\nTruncation scaling under 2x refinement (error ratio): {h.get('truncation_scaling_ratio_2x_refinement')}.\n\n" + h["statement"] + "\n")
        elif t == "035":
            A(tbl(["mode", "g", "entries", "read by kernel", "unused padding", "footprint mismatches vs independent ref", "required ghost entries", "cells depending on them"], [[x["mode"], x["g"], x["entries"], x["used_entries"], x["unused_entries"], x["footprint_mismatches_vs_independent_reference"], x["required_ghost_entries"], x["cells_depending_on_required_ghosts"]] for x in h["grids"]]))
            A("\nGhost layers read (below / above the core block), per component and axis:")
            for x in h["grids"]: A(f"* {x['mode']} g={x['g']}: " + "; ".join(f"{cn}: " + ", ".join(f"{ax} {d['below']}/{d['above']}" for ax, d in rr.items()) for cn, rr in x["reach"].items()))
            A("\nPoison runs:"); A(tbl(["mode", "g", "kind", "dtype", "poison", "result"], [[x["mode"], x["g"], "unused padding", p["dtype"], p["poison"], f"bitwise identical to clean = {p['output_bitwise_identical_to_clean']} ({p['unused_entries']} entries)"] for x in h["grids"] for p in x["unused_padding_poison"]] +
                  [[x["mode"], x["g"], "REQUIRED ghosts", p["dtype"], p["poison"], (f"non-finite cells {p['nonfinite_cells']} / expected {p['expected_cells']}; matches footprint = {p['mask_matches_footprint']}" if "nonfinite_cells" in p else f"output changed vs clean = {p['output_changed_vs_clean']}; agrees with reference on the same inputs (rel {f(p['rel_diff_vs_reference_on_same_inputs'])}); SILENT finite wrong current = {p['finite_wrong_current_is_silent']}")] for x in h["grids"] for p in x["required_ghost_poison"]]))
            A("\n**Launcher validator probes:**"); A(tbl(["case", "rejected", "message"], [[x["case"], x["rejected"], x.get("message", "(accepted: no content inspection)")] for x in h["validator"]]))
            A(f"\nB content inspected by the validator: **{not h['B_content_not_inspected']}**.\n\n" + h["statement"] + "\n")
        elif t == "036":
            A(tbl(["case", "dtype", "r0/dr", "r dphi / dr", "dz / dr", "kappa", "bound", "bound / |J|", "exact-field rel err", "random vs reference (rel)", "discriminating", "ok"], [[x["case"][:30], x["dtype"], f(x["r0_over_dr"]), f(x["aspect_rdphi_over_dr"]), f(x["aspect_dz_over_dr"]), f(x["kappa"]), f(x["roundoff_bound"]), f(x.get("bound_over_signal")), f(x["exact_field_rel_err"]), f(x["random_vs_reference_rel"]), ("yes" if x.get("discriminating") else "NO (bound can't fail)"), x["ok"]] for x in h["rows"] if "rejected_by_validator" not in x]))
            A("\n**Curl-free vortex Bphi = 1/r near the axis** (metric truncation): " + ", ".join(f"r0/dr={x['r0_over_dr']}: max|Jz| = {f(x['max_abs_Jz_spurious'])}" for x in h["vortex_truncation"]) + ".\n\n" + h["statement"] + "\n")
        elif t == "037":
            rows = []
            for c in h["cases"]:
                for q, d_ in c["quantities"].items():
                    if "skipped" in d_: continue
                    rows.append([c["case"][:38], f"{c['mode']}/{c['ring']}", q, olist(d_["amplitude_error"]["orders"]) + (" (floor)" if d_["amplitude_error"]["at_floor"] else ""), olist(d_["phase_error"]["orders"]) + (" (floor)" if d_["phase_error"]["at_floor"] else ""),
                                 f(d_["amplitude_error"]["errors"][-1]), f(d_["phase_error"]["errors"][-1]), f(d_["leakage"]["values"][-1]), "round-off" if d_["leakage"]["within_roundoff"] else "orders " + olist(d_["leakage"]["orders"]),
                                 "LIMITATION" if (d_["amplitude_error"]["relative_limitation"] or d_["phase_error"]["relative_limitation"]) else "ok"])
            A(tbl(["case", "mode/ring", "quantity", "amplitude orders (scaled)", "phase orders (scaled)", "final amp err", "final phase err", "final leakage", "leakage behaviour", "relative first-ring metric"], rows))
            A(f"\nAmplitude independence of the relative amplitude error (helical kink eps 0.01 vs 0.3): {h['amplitude_independence']}.\n")
            A(f"First-ring relative-metric limitations ({len(h['ring0_relative_limitations'])}): " + "; ".join(h["ring0_relative_limitations"][:8]) + ("; ..." if len(h["ring0_relative_limitations"]) > 8 else "") + "\n\n" + h["statement"] + "\n")
        elif t == "038":
            A(tbl(["dtype", "direction", "alignment", "kind", "integral identity", "max undershoot/peak", "support cells", "peak*h/B0", "weak order", "pointwise orders (resolved)", "continuum residual"],
                  [[x["dtype"], x["direction"], x["alignment"], x["kind"], x["integral_identity_ok"], f(x.get("max_undershoot_over_peak")), x.get("max_support_cells"), (f(x["peak_times_h_over_B0"][-1]) if x.get("peak_times_h_over_B0") else "n/a"),
                    (o(x["weak_order_fit"]) if x.get("weak_order_fit") is not None and abs(x["weak_order_fit"]) < 50 else ("round-off" if x.get("weak_at_floor") else "n/a")), (olist(x["pointwise_orders"]) if x.get("pointwise_orders") else "n/a"), f(x["levels"][-1].get("continuum_residual"))] for x in h["rows"]]))
            A("\n" + h["statement"] + "\n")
        elif t == "039":
            A(f"**Executed on:** {h.get('backend_executes_on')}" + (f" - device {h.get('device')}" if h.get("device") else "") + "\n")
            cols = ["mode", "grid", "g", "dtype", "canary", "inputs unchanged", "ghosts untouched", "all written", "ref rel diff", "repeat bitwise", "unused padding (NaN inert)", "required NaN propagates", "pow2 exact"]
            rows = []
            for x in h["grids"]:
                if "rejected_by_validator" in x: rows.append([x["mode"], x["grid"], x["g"], x["dtype"], "rejected by validator"] + [""] * 8); continue
                rows.append([x["mode"], x["grid"], x["g"], x["dtype"], x["canary_intact"], x["inputs_unchanged"], x["ghost_layers_untouched"], x["all_active_cells_written"], f(x["rel_diff_vs_reference"]), x["repeat_bitwise_identical"], f"{x['unused_padding_entries']} entries, inert = {not x['padding_nan_changes_output']}", x["required_nan_propagates"], x["pow2_scaling_bitwise"]])
            A(tbl(cols, rows))
            if h["grids"] and "gpu_vs_host_rel_diff" in h["grids"][0]:
                A("\n**GPU vs host, stream launch and explicit error check:**"); A(tbl(["grid", "g", "dtype", "gpu-vs-host rel diff", "non-default stream bitwise identical", "device error check"], [[x["grid"], x["g"], x["dtype"], f(x.get("gpu_vs_host_rel_diff")), x.get("stream_launch_bitwise_identical"), x.get("device_error_check")] for x in h["grids"] if "gpu_vs_host_rel_diff" in x]))
            if h.get("host_addresssanitizer"): A("\n**AddressSanitizer (host-compiled copy):** " + ", ".join(f"{a['mode']} {a['grid']} g={a['g']}: {'clean' if a['clean'] else a['error']}" for a in h["host_addresssanitizer"]))
            for key in ("compute_sanitizer_campaign02_cases", "compute_sanitizer_campaign04_cases"):
                if key in h:
                    s = h[key]; A(f"\n**compute-sanitizer ({key.split('_')[-2]} cases)**: status {s['status']}" + (f", tool `{s.get('tool')}`" if s.get("tool") else ""))
                    if s.get("runs"): A(tbl(["tool", "return code", "error summary", "target completed", "clean"], [[k, r.get("returncode"), r.get("error_summary"), r.get("target_done"), r.get("clean")] for k, r in s["runs"].items()]))
            A("\n*Stencil reach used to define 'unused padding':* " + "; ".join(f"{k}: " + "; ".join(f"{cn} " + ",".join(f"{ax}{d['below']}/{d['above']}" for ax, d in rr.items()) for cn, rr in tbl_.items()) for k, tbl_ in h.get("reach_tables", {}).items()))
            if h.get("scope_note"): A("\n" + h["scope_note"])
            A("")
        elif t == "040":
            fam = {}
            for r in h["rows"]:
                if "family" not in r: continue
                d_ = fam.setdefault(r["family"], dict(n=0, ok=0, silent=0, maxd=0.0)); d_["n"] += 1; d_["ok"] += r["classification"] == "ok"; d_["silent"] += bool(r["silent_nonfinite"]); d_["maxd"] = max(d_["maxd"], r.get("rel_diff_vs_reference") or 0.0)
            A(tbl(["family", "cases", "agree with independent reference", "silent non-finite", "worst relative difference"], [[k, d_["n"], d_["ok"], d_["silent"], f(d_["maxd"])] for k, d_ in sorted(fam.items())]))
            A(f"\nTotal cases {h['cases']} (+ validator rejections); two identical seeded passes bitwise identical: **{h['reproducible_bitwise']}** ({h['reproducibility_cases']} compared). Unclassified behaviours preserved: {len(h['unclassified'])}.")
            if "gpu_vs_host_identical_digests" in h: A(f"GPU vs host: {h['gpu_vs_host_identical_digests']} digest-identical cases, {h['gpu_vs_host_differing_digests']} differing (differences are value-checked against the reference per case; FMA contraction may change last bits).")
            A("\n**Re-run of earlier weaknesses:**"); A(tbl(["sub-suite", "verdict", "failures preserved"], [[k, x["verdict"], "; ".join(x["fail_reasons"][:2]) or "none"] for k, x in h["weakness_reruns"].items()]))
            A("\nAxis-grid checkerboards (annulus-only invisibility claim): " + (", ".join(f"{r['grid']} {r['family'].split(': ')[-1][:20]} visible={r['axis_pattern_visible']}" for r in h["rows"] if r.get("axis_pattern_visible") is not None) or "none in this seed set") + "\n")
    A("## 5. Numerical pathology register")
    A("Classes: **DEFECT** (incorrect implementation or violated contract), **LIMITATION** (known mathematical / numerical behaviour needing documented restrictions or safeguards), **INCONCLUSIVE** (insufficient evidence), **VERIFIED** (property demonstrated within the tested domain and declared tolerances). Every entry is computed from the measured data above.\n")
    reg = R.get("register", [])
    A(tbl(["id", "class", "test", "finding", "evidence", "restriction / safeguard"], [[x["id"], f"**{x['cls']}**", x["test"], x["title"], x["evidence"], x["restriction"]] for x in reg]))
    cnt = {}
    for x in reg: cnt[x["cls"]] = cnt.get(x["cls"], 0) + 1
    A(f"\nCounts: {cnt}.  " + ("**No kernel DEFECT was found**: the kernel source is unchanged and frozen." if cnt.get("DEFECT", 0) == 0 else "**Defect entries are open and unresolved**; the kernel stays frozen until triage and a separately versioned fix."))
    A("\n*Every LIMITATION above is characterised by a PASS, not eliminated by it.*\n")
    A("## 6. Convergence and sweep plots")
    for p in plots:
        if p.endswith(".png"): A(f"![{os.path.basename(p)}](campaign04_plots/{os.path.basename(p)})")
        else: A(p)
    A("\n## 7. Findings and explicit limitations")
    for fi in R["findings"]: A(f"* **{fi['id']} - {fi['title']}.** {fi['detail']}")
    A("""
* **L1.** The kernel cannot detect or damp odd-even B content; the driver must.
* **L2.** The kernel does no range checking and does not inspect B; outside the safe amplitude window it returns overflow, underflow or finite wrong values silently. The caller owns amplitudes and ghost correctness.
* **L3.** Cancellation limit is truncation A c h^2; it moves as h^-2 with refinement.
* **L4.** Pointwise values of J across a discontinuity do not converge; only weak/integral quantities do.
* **L5.** Relative accuracy of m >= 2 currents at the first axis ring is not a meaningful metric (absolute converges).
* **L6.** FP32 accuracy follows eps*kappa; FP64 is recommended for tiny r0/dr and extreme aspect ratios.
* **L7.** The kernel is a current reconstruction, not the Faraday CT update; nothing here bears on div(B).
* **L8.** The GPU leg is only as certified as it was executed (section 3). The host leg of Test 039 is not a GPU PASS.
* **L9.** Independent source-level review of the frozen code and this harness is pending.
""")
    A("## 8. Harness development history and corrections (disclosed)")
    A("Each row is a failure or mis-specification found while building THIS harness. No kernel change was made; where a criterion changed, the reason is mathematical/numerical and the whole campaign was re-run.\n")
    A(tbl(["phase", "item", "observation", "resolution"], [[d["phase"], d["item"], d["observation"], d["resolution"]] for d in R.get("dev_log", [])]))
    A("\n## 9. Requirement checklist (Campaign 04 specification)")
    gp = env["gpu_present"]; allh = all(v(e, "host") == "PASS" for e in T.values()); allg = all(v(e, "cupy") == "PASS" for e in T.values())
    san_ok = None
    if "039" in T and T["039"].get("cupy", {}).get("compute_sanitizer_campaign04_cases"): san_ok = all(r.get("clean") for r in T["039"]["cupy"]["compute_sanitizer_campaign04_cases"].get("runs", {}).values())
    A(tbl(["requirement", "status", "evidence"], [
        ["All 10 tests on CPU", "MET" if allh else "NOT MET", "section 3"], ["All 10 tests on a real GPU", "MET" if allg else ("NOT MET (blocked: no GPU in this execution)" if not gp else "NOT MET"), "section 3"],
        ["Frozen kernel and harness SHA-256 recorded", "MET", "section 1"], ["Exact configurations and seeds recorded", "MET", "section 1, 2"],
        ["Independent references (analytic Cartesian curl, exact rational evaluation, multi-index reference)", "MET", "tests 031-040"],
        ["Error tables and convergence plots", "MET", "sections 4, 6"], ["CPU/GPU results", "MET" if gp else "PARTIAL (GPU blocked)", "sections 3, 4"],
        ["CUDA sanitizer evidence", "MET" if san_ok else ("NOT MET (blocked)" if not gp else "NOT MET"), "Test 039"], ["Every failure and correction preserved", "MET", "section 8, per-test FAIL lines"],
        ["Numerical pathology register (DEFECT / LIMITATION / INCONCLUSIVE / VERIFIED)", "MET", "section 5"], ["Explicit limitations", "MET", "section 7"],
        ["Kernel not modified to make tests pass", "MET" if env["source_frozen_and_matches"] else "NOT MET (sha mismatch)", "section 1"]]))
    A("\n## 10. Reproducibility")
    A("```\nunzip the package into an empty folder (single uct_curl.py + campaign01.py ... campaign04.py + make_report_campaign0*.py)\npython campaign04.py            # host leg always; GPU leg if CuPy + a CUDA device are present\n```\nOutputs: `campaign04_results.json`, `CAMPAIGN04_REPORT.md`, `campaign04_plots/`, `campaign04_execution.log`. The harness prints a STALE PACKAGE banner if `uct_curl.py` is not the newest registered version and a WARNING if its SHA-256 matches no registered source.")
    text = "\n".join(L) + "\n"
    open(os.path.join(here, name), "w", encoding="utf-8").write(text)
    return text
