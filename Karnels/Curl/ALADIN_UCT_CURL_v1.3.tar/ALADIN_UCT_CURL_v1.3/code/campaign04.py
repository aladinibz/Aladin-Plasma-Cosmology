#!/usr/bin/env python3
"""
ALADIN v4.0 - Campaign 04: Numerical pathologies, axis robustness & adversarial stress   (tests 031-040)
Target : uct_curl.py v1.3 (executed UNMODIFIED; SHA-256 checked against KNOWN_SHA).  J = curl(B), mu0 = 1.  NOT the Faraday CT update.
Needs campaign01.py, campaign02.py, campaign03.py (shared grid/backend/reference helpers) in the same folder.   Run:  python campaign04.py
Deliverables written next to this file: campaign04_results.json, CAMPAIGN04_REPORT.md, campaign04_plots/*.png, campaign04_execution.log

STANCE (stated before any result was looked at)
  * A PASS means "the property was correctly CHARACTERISED within the tested domain and declared tolerances".  A PASS that characterises a limitation
    (checkerboard null modes, cancellation loss, dynamic-range edges, ...) is NEVER evidence that the limitation has been eliminated.
  * Every finding is classified in the numerical pathology register as DEFECT / LIMITATION / INCONCLUSIVE / VERIFIED, from the measured data.
  * The kernel is frozen.  A real defect would be reported as FAIL + a separately versioned fix + a fresh rerun; never patched to make a test pass.
  * Independent references: analytic Cartesian curls (cross-checked against a 6th-order numeric Cartesian curl), an EXACT RATIONAL (fractions.Fraction)
    evaluation of the discrete operator on the stored inputs (separates round-off from truncation), and the multi-index FP64 reference of Campaigns 01-02.
  * All tolerances are DECLARED in TOL4 before execution.  Changes after seeing results are documented in DEV_LOG and followed by a fresh full run.
"""
import os, sys, json, math, hashlib, re, subprocess, datetime, platform, traceback, importlib.util, random, io, itertools
from fractions import Fraction
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
sys.path.insert(0, HERE)
import campaign01 as C
import campaign02 as H
import campaign03 as T3

K = C.K
F64, F32 = np.float64, np.float32
EPS = C.EPS
KNOWN_SHA = {"1.3": "e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e"}
EXPECTED_SHA = KNOWN_SHA.get(getattr(C.K, "VERSION", ""), "")
OUT = os.environ.get("CAMPAIGN_OUT", HERE)

TOL4 = dict(
    order_min=1.8,             # last-pair observed order for every smooth-field convergence claim (4 levels, h halved)
    conv_base=(12, 24, 8),     # base grid of every 4-level refinement
    region_axis=(0.25, 0.9),   # fixed physical interior region (axis grids)
    exact_fp64=1e-12,          # error floor for fields the discrete operator reproduces exactly (relative to max(1, |J|max))
    alg_factor=128.0,          # exact identity: <= alg_factor*eps*scale
    fp_factor=64.0,            # round-off bound against the EXACT rational reference: err <= fp_factor*eps*Bmax*cond/hmin
    ref_equiv_fp64=1e-12,      # FP64 kernel vs FP64 independent reference, relative to max|J_ref|
    safe_k_fp64=(-900, 900),   # 033: promised safe binary-exponent range of the amplitude 2^k (B ~ 1) in FP64 ...
    safe_k_fp32=(-100, 100),   # ... and FP32
    recover_ratio=10.0,        # 034: signal is 'recoverable' only if |signal| >= recover_ratio * |error|
    kink_amp_order=1.8,        # 037: amplitude / phase error orders
    leak_factor=128.0,         # 037: spectral leakage into other azimuthal harmonics <= leak_factor*eps*scale/hmin (circulant operator)
    sheet_weak_order=0.8,      # 038: weak (integral) convergence order across a discontinuity
    sheet_resolved_order=1.5,  # 038: pointwise order of a RESOLVED smoothed sheet (last pair)
    sheet_int_factor=128.0,    # 038: integrated sheet current identity <= factor*eps*scale
    disc_fraction=0.5,         # 036: a round-off bound DEMONSTRATES accuracy only if bound <= disc_fraction * |J|max (otherwise it cannot fail: row is NON-DISCRIMINATING)
    repeat_launches=5,         # 039: identical repeated launches must be bitwise identical
    seeds=dict(t031=31, t032=32, t033=33, t034=34, t035=35, t036=36, t037=37, t038=38, t039=39, t040=40),
)

def dn(d): return np.dtype(d).name
nmax = H.nmax
orders_of = H.orders_of
per_fill, cc, Iv, Ji = T3.per_fill, T3.cc, T3.Iv, T3.Ji
hmin_of, bmax_of = T3.hmin_of, T3.bmax_of

def tol_alg(dtype, scale): return TOL4["alg_factor"]*EPS[dtype]*scale

def lbl_order(errs, floor):
    """order list or 'floor' marker; pass if last-pair order >= order_min or every level at/below the floor"""
    o = orders_of(errs); at_floor = all(e <= floor for e in errs)
    return bool(o[-1] >= TOL4["order_min"] or at_floor), o, at_floor

# ----------------------------------------------------------------------------
# Cartesian-regular analytic fields (hand-derived curl, cross-checked by a 6th-order numeric Cartesian curl)
# spec = (Bx, By, Bz, Jx, Jy, Jz) functions of (x, y, z)
# ----------------------------------------------------------------------------
Z0 = H.Z0
KW = 2*math.pi
def _w(x, y, m): return (x + 1j*y)**m
def _wm(x, y, m): return (x + 1j*y)**max(m - 1, 0)
def _re(a): return np.real(a); _im = np.imag

def spec_modulated(m, k=KW):
    c = lambda z: np.cos(k*z); s = lambda z: np.sin(k*z)
    return (lambda x, y, z: np.real(_w(x, y, m))*c(z) + 0*x, lambda x, y, z: np.imag(_w(x, y, m))*c(z) + 0*x, Z0,
            lambda x, y, z: k*np.imag(_w(x, y, m))*s(z) + 0*x, lambda x, y, z: -k*np.real(_w(x, y, m))*s(z) + 0*x,
            lambda x, y, z: 2*m*np.imag(_wm(x, y, m))*c(z) + 0*x)

SPEC031 = {}
# m = 0 (axisymmetric)
SPEC031["m0 rigid rotation B=(-y,x,0)"] = (lambda x, y, z: -y + 0*z, lambda x, y, z: x + 0*z, Z0, Z0, Z0, lambda x, y, z: 2 + 0*x)
SPEC031["m0 Bz=x^2+y^2"] = (Z0, Z0, lambda x, y, z: x**2 + y**2 + 0*z, lambda x, y, z: 2*y + 0*z, lambda x, y, z: -2*x + 0*z, Z0)
SPEC031["m0 smooth Bphi=r exp(-r^2)"] = (lambda x, y, z: -y*np.exp(-(x**2 + y**2)) + 0*z, lambda x, y, z: x*np.exp(-(x**2 + y**2)) + 0*z, Z0, Z0, Z0,
                                         lambda x, y, z: 2*np.exp(-(x**2 + y**2))*(1 - (x**2 + y**2)) + 0*z)
# m = 1,2,3 : two Fourier families (Campaign 02) and a z-modulated family
for m in (1, 2, 3):
    wm1 = lambda x, y, m=m: _wm(x, y, m)
    SPEC031[f"m{m} Bz=Re w^{m}"] = (Z0, Z0, lambda x, y, z, m=m: np.real(_w(x, y, m)) + 0*z,
                                    lambda x, y, z, m=m: -m*np.imag(_wm(x, y, m)) + 0*z, lambda x, y, z, m=m: -m*np.real(_wm(x, y, m)) + 0*z, Z0)
    SPEC031[f"m{m} B=(Re,Im) w^{m}"] = (lambda x, y, z, m=m: np.real(_w(x, y, m)) + 0*z, lambda x, y, z, m=m: np.imag(_w(x, y, m)) + 0*z, Z0, Z0, Z0,
                                        lambda x, y, z, m=m: 2*m*np.imag(_wm(x, y, m)) + 0*z)
    SPEC031[f"m{m} modulated cos(2 pi z)"] = spec_modulated(m)
for nm in ("KINK-poly", "HELICAL KINK (m=1)", "SMOOTH"):
    SPEC031[nm] = H.CART[nm]

def cart_field(name, spec): return C._cart_field(*spec, name)

def axis_limit_error(G, J, spec):
    """Cartesian current averaged over phi on the first physical ring (r = dr/2) versus the analytic current ON the axis, per z plane."""
    g = G.g; p = G.pc[g:g + G.nphi][:, None]
    Jr, Jp, Jz = [np.asarray(j[g, g:g + G.nphi, g:g + G.nz], dtype=F64) for j in J]
    Jx = Jr*np.cos(p) - Jp*np.sin(p); Jy = Jr*np.sin(p) + Jp*np.cos(p)
    zc = G.zc[g:g + G.nz]; zero = np.zeros_like(zc)
    ax = [spec[3](zero, zero, zc), spec[4](zero, zero, zc), spec[5](zero, zero, zc)]
    return max(float(np.max(np.abs(Jx.mean(0) - ax[0]))), float(np.max(np.abs(Jy.mean(0) - ax[1]))), float(np.max(np.abs(Jz.mean(0) - ax[2]))))

# ============================================================================
# TEST 031  Axis singularity torture
# ============================================================================
def t031(be):
    res = dict(fields=[]); fails = []; raw = H.backend_for(be)
    lo, hi = TOL4["region_axis"]
    for name, spec in SPEC031.items():
        row = dict(field=name, spec_numeric_check=H.cart_reference_check(spec))
        if row["spec_numeric_check"] > 1e-8: fails.append(f"{name}: hand-derived curl disagrees with 6th-order numeric curl ({row['spec_numeric_check']:.2e})")
        fld = cart_field(name, spec); lev = []
        for n in H.levels(TOL4["conv_base"], 4):
            G = C.Grid(*n, r0=0.0, r1=1.0); B = G.sample(fld, F64); J = G.run(raw, B, F64); ref = G.ref(fld)
            fin = all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3))
            e = [np.abs(np.asarray(J[c][G.sl], dtype=F64) - ref[c]) for c in range(3)]
            rcs = G.rc[G.g:G.g + G.nr]; reg = (rcs >= lo) & (rcs <= hi)
            scale = max(max(nmax(r) for r in ref), 1.0)
            lev.append(dict(h=max(G.dr, G.dz), grid=list(n), finite=fin, global_err=max(nmax(x) for x in e), ring0_err=max(nmax(x[0]) for x in e),
                            region_err=max(nmax(x[reg]) for x in e), axis_limit_err=axis_limit_error(G, J, spec), Jscale=scale,
                            ring0_err_by_comp=[nmax(x[0]) for x in e]))
        row["levels"] = lev; row["finite_everywhere"] = all(l["finite"] for l in lev)
        scale = max(l["Jscale"] for l in lev); floor = TOL4["exact_fp64"]*scale
        for key in ("global_err", "ring0_err", "region_err", "axis_limit_err"):
            ok, o, at_floor = lbl_order([l[key] for l in lev], floor)
            row[key.replace("_err", "")] = dict(orders=o, at_round_off_floor=at_floor, ok=ok)
            if not ok: fails.append(f"{name}: {key} orders {['%.2f' % x for x in o]} (last < {TOL4['order_min']})")
        if not row["finite_everywhere"]: fails.append(f"{name}: non-finite current")
        res["fields"].append(row)
    res["statement"] = ("Reconstructed current compared with the ANALYTIC Cartesian curl (not with another discretisation), for m = 0, 1, 2, 3 Cartesian-regular modes, "
                        "including the first physical ring (r = dr/2, one-sided stencils) and the phi-averaged ring-0 current against the analytic current ON the axis. "
                        "Global (all cells incl. ring 0), first-ring and fixed-interior (0.25<=r<=0.9) errors are reported and ordered separately.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 032  Odd-even nullspace attack
# ============================================================================
AXES = ("r", "phi", "z")
def pattern_field(G, dtype, comp, alt):
    """B component `comp` (0 Br,1 Bphi,2 Bz) = (-1)^(sum of indices over the alternating axes) on the staggered array; other components 0.  Ghost layers included."""
    g = G.g; shp = [(G.nr + 1 + 2*g, G.nphi + 2*g, G.nz + 2*g), (G.nr + 2*g, G.nphi + 1 + 2*g, G.nz + 2*g), (G.nr + 2*g, G.nphi + 2*g, G.nz + 1 + 2*g)]
    B = [np.zeros(s, dtype=dtype) for s in shp]
    I = np.indices(shp[comp]); sgn = np.ones(shp[comp], dtype=np.int64)
    for a in alt: sgn = sgn*np.where((I[AXES.index(a)] - g) % 2 == 0, 1, -1)
    B[comp] = sgn.astype(dtype)
    return B

def exact_B(B): return np.vectorize(lambda v: Fraction(float(v)), otypes=[object])(B)

def exact_curl_annulus(B, G, dtype):
    """EXACT rational evaluation of the annulus-mode discrete operator on the STORED inputs (rf, rc, dr, dphi, dz rounded to the working dtype as the kernel receives them)."""
    g, nr, nphi, nz = G.g, G.nr, G.nphi, G.nz; dt = dtype
    Br, Bp, Bz = [exact_B(b) for b in B]; rf = exact_B(G.rf.astype(dt)); rc = exact_B(G.rc.astype(dt))
    dr, dphi, dz = [Fraction(float(dt(v))) for v in (G.dr, G.dphi, G.dz)]
    sh = lambda A, i, j, k: A[g + i:g + i + nr, g + j:g + j + nphi, g + k:g + k + nz]
    half = Fraction(1, 2)
    BRC = lambda i, j, k: half*(sh(Br, i, j, k) + sh(Br, i + 1, j, k))
    BPC = lambda i, j, k: half*(sh(Bp, i, j, k) + sh(Bp, i, j + 1, k))
    BZC = lambda i, j, k: half*(sh(Bz, i, j, k) + sh(Bz, i, j, k + 1))
    BPF = lambda i: half*(BPC(i - 1, 0, 0) + BPC(i, 0, 0))
    r_c = rc[g:g + nr][:, None, None]; inv = np.vectorize(lambda v: 1/v, otypes=[object])(r_c)
    rfp = rf[g + 1:g + 1 + nr][:, None, None]; rfm = rf[g:g + nr][:, None, None]
    Jr = inv*(BZC(0, 1, 0) - BZC(0, -1, 0))/(2*dphi) - (BPC(0, 0, 1) - BPC(0, 0, -1))/(2*dz)
    Jp = (BRC(0, 0, 1) - BRC(0, 0, -1))/(2*dz) - (BZC(1, 0, 0) - BZC(-1, 0, 0))/(2*dr)
    Jz = inv*((rfp*BPF(1) - rfm*BPF(0))/dr - (BRC(0, 1, 0) - BRC(0, -1, 0))/(2*dphi))
    return [Jr, Jp, Jz]

def exact_curl_axis(B, G, dtype):
    """EXACT rational evaluation of the axis-mode operator (cubic Cartesian reconstruction), on stored inputs; cos/sin tables rounded to dtype as the kernel receives them."""
    g, nr, nphi, nz = G.g, G.nr, G.nphi, G.nz; dt = dtype; npg = nphi + 2*g; nzg = nz + 2*g
    Br, Bp, Bz = [exact_B(b) for b in B]; rc = exact_B(G.rc.astype(dt))
    dr, dphi, dz = [Fraction(float(dt(v))) for v in (G.dr, G.dphi, G.dz)]
    phic = (np.arange(npg) - g + 0.5)*G.dphi
    cph = exact_B(np.cos(phic).astype(dt))[:, None]; sph = exact_B(np.sin(phic).astype(dt))[:, None]
    sd = Fraction(float(dt(math.sin(G.dphi)))); half = Fraction(1, 2); s16 = Fraction(1, 16)
    zero = Fraction(0)
    def cart(a):
        if a == g: brc = s16*(5*Br[a] + 15*Br[a + 1] - 5*Br[a + 2] + Br[a + 3])
        else:      brc = s16*(-Br[a - 1] + 9*Br[a] + 9*Br[a + 1] - Br[a + 2])
        P = Bp[a]; bpc = np.full(brc.shape, zero, dtype=object)
        bpc[1:npg - 1] = s16*(-P[0:npg - 2] + 9*P[1:npg - 1] + 9*P[2:npg] - P[3:npg + 1])
        return brc*cph - bpc*sph, brc*sph + bpc*cph
    ring = {a: cart(a) for a in range(g, g + nr + 1)}
    jr = np.full((nr, nphi, nz), zero, dtype=object); jp = jr.copy(); jz = jr.copy()
    BZ = lambda a: half*(Bz[a][:, :-1] + Bz[a][:, 1:]); BRc = lambda a: half*(Br[a] + Br[a + 1]); BPc = lambda a: half*(Bp[a][:-1] + Bp[a][1:])
    for i in range(nr):
        a = g + i; bz = BZ(a)
        jr[i] = (bz[g + 1:g + 1 + nphi, g:g + nz] - bz[g - 1:g - 1 + nphi, g:g + nz])/(2*dphi)/rc[a]
        bpc_phi = BPc(a)
        jr[i] = jr[i] - (bpc_phi[g:g + nphi, g + 1:g + 1 + nz] - bpc_phi[g:g + nphi, g - 1:g - 1 + nz])/(2*dz)
        brc = BRc(a); dbr_dz = (brc[g:g + nphi, g + 1:g + 1 + nz] - brc[g:g + nphi, g - 1:g - 1 + nz])/(2*dz)
        dbz_dr = (-3*BZ(a) + 4*BZ(a + 1) - BZ(a + 2))/(2*dr) if i == 0 else (BZ(a + 1) - BZ(a - 1))/(2*dr)
        jp[i] = dbr_dz - dbz_dr[g:g + nphi, g:g + nz]
        fx, fy = ring[a]
        if i == 0:
            f1x, f1y = ring[a + 1]; f2x, f2y = ring[a + 2]; dxr = (-3*fx + 4*f1x - f2x)/(2*dr); dyr = (-3*fy + 4*f1y - f2y)/(2*dr)
        else:
            px, py = ring[a + 1]; mx, my = ring[a - 1]; dxr = (px - mx)/(2*dr); dyr = (py - my)/(2*dr)
        den = 2*rc[a]*sd
        dxt = (fx[g + 1:g + 1 + nphi] - fx[g - 1:g - 1 + nphi])/den; dyt = (fy[g + 1:g + 1 + nphi] - fy[g - 1:g - 1 + nphi])/den
        c0, s0 = cph[g:g + nphi], sph[g:g + nphi]
        jz[i] = (c0*dyr[g:g + nphi] - s0*dxr[g:g + nphi] - s0*dyt - c0*dxt)[:, g:g + nz]
    return [jr, jp, jz]

_EXACT_CACHE = {}
def exact_curl(B, G, dtype):
    """cached exact rational reference (shared by the host and GPU legs)"""
    key = (hashlib.sha256(b"".join(np.ascontiguousarray(b).tobytes() for b in B)).hexdigest(), G.nr, G.nphi, G.nz, G.g, G.r0, G.dr, G.dz, np.dtype(dtype).name)
    if key not in _EXACT_CACHE:
        _EXACT_CACHE[key] = (exact_curl_axis if G.rf[G.g] == 0.0 else exact_curl_annulus)(B, G, dtype)
    return _EXACT_CACHE[key]

def fr_max_abs(A): return max((abs(v) for v in A.flat), default=Fraction(0))
def fr_err(J, Jex, G):
    """max over interior cells and components of |J - Jex| as a Fraction, and max|Jex|"""
    e = Fraction(0); m = Fraction(0)
    for c in range(3):
        Jc = np.asarray(J[c][G.sl]); d = np.vectorize(lambda a, b: abs(Fraction(float(a)) - b) if math.isfinite(float(a)) else Fraction(10**400), otypes=[object])(Jc, Jex[c])
        e = max(e, fr_max_abs(d)); m = max(m, fr_max_abs(Jex[c]))
    return e, m
def fr_f(x):
    try: return float(x)
    except OverflowError: return float("inf")

def pattern_rank(raw, G, dtype, rng_seed=0):
    """Rank of the linear map B -> J on the physical unknowns (core phi entries, r/z ghost layers fixed at zero) by unit-vector probing of the KERNEL."""
    g, nr, nphi, nz = G.g, G.nr, G.nphi, G.nz
    base = pattern_field(G, dtype, 0, ())
    def idxs(comp):
        shp = base[comp].shape; ir = range(g, g + shp[0] - 2*g); jr_ = range(g, g + nphi) if comp != 1 else range(g, g + nphi)
        ks = range(g, g + shp[2] - 2*g)
        return [(i, j, k) for i in ir for j in jr_ for k in ks]
    cols = []; unknowns = []
    for comp in range(3):
        for (i, j, k) in idxs(comp):
            B = [np.zeros_like(b) for b in base]; B[comp][i, j, k] = 1
            if j == g:                                    # periodic images of the phi entry (ghost copies)
                B[comp][i, g + nphi, k] = 1 if comp == 1 else 0
            B = per_fill(B, G)
            J = G.run(raw, B, dtype); cols.append(np.concatenate([np.asarray(J[c][G.sl], dtype=F64).ravel() for c in range(3)])); unknowns.append((comp, i, j, k))
    M = np.array(cols).T
    s = np.linalg.svd(M, compute_uv=False); smax = s[0]
    infl = np.any(M != 0, axis=0); rank = int((s > 1e-9*smax).sum())
    gap = (float(s[rank - 1]/smax), float(s[rank]/smax) if rank < len(s) else 0.0)
    return dict(unknowns=int(M.shape[1]), influencing_unknowns=int(infl.sum()), outputs=int(M.shape[0]), rank=rank, nullity_of_influencing=int(infl.sum() - rank),
                nullity_fraction=float((infl.sum() - rank)/max(infl.sum(), 1)), singular_value_gap=gap)

def t032(be):
    res = dict(patterns=[]); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(TOL4["seeds"]["t032"])
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        G = C.Grid(6, 6, 4, g=2, r0=r0, r1=r0 + 1.0 if r0 else 1.0)
        for dt in (F64, F32):
            for comp, cn in enumerate(("Br", "Bphi", "Bz")):
                for k in range(1, 4):
                    for alt in itertools.combinations(AXES, k):
                        B = pattern_field(G, dt, comp, alt)
                        if comp == 0 and mode == "axis" and "r" in alt: pass
                        J = G.run(raw, B, dt); Jm = max(nmax(J[c][G.sl]) for c in range(3)); fin = all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3))
                        exact_zero = None; exact_max = None
                        if dt is F64 and G.nr*G.nphi*G.nz <= 160:
                            Jex = exact_curl(B, G, dt); exact_max = max(fr_f(fr_max_abs(Jex[c])) for c in range(3)); exact_zero = bool(exact_max == 0)
                        tol = tol_alg(dt, 1.0/hmin_of(G))
                        row = dict(mode=mode, dtype=dn(dt), component=cn, alternating_axes="+".join(alt), max_abs_B=1.0, max_abs_J=Jm, finite=fin, invisible=bool(Jm <= tol),
                                   exact_reference_zero=exact_zero, exact_reference_max_abs_J=exact_max)
                        if exact_max is not None and (exact_max <= tol) != row["invisible"]: fails.append(f"{mode} {cn} alt={alt}: kernel invisibility {row['invisible']} disagrees with the exact rational reference (max|J_exact| {exact_max:.2e}, tol {tol:.2e})")
                        if not fin: fails.append(f"{mode} {cn} alt={alt}: non-finite current")
                        res["patterns"].append(row)
    inv = [p for p in res["patterns"] if p["invisible"]]; vis = [p for p in res["patterns"] if not p["invisible"]]
    res["n_patterns"] = len(res["patterns"]); res["n_invisible"] = len(inv); res["n_visible"] = len(vis)
    res["claim_all_gridscale_detected"] = dict(claim="the kernel's current detects every grid-scale (odd-even) magnetic structure", holds=bool(len(inv) == 0),
                                              counterexamples=[f"{p['mode']}/{p['dtype']}/{p['component']}/{p['alternating_axes']}" for p in inv][:12])
    if res["claim_all_gridscale_detected"]["holds"]: fails.append("claim 'all grid-scale current structures are detected' was NOT falsified (it must fail): no invisible pattern found")
    # contamination: B = smooth + a*N for N in the four Campaign-03 null families (annulus, FP64 and FP32)
    cont = []
    G = C.Grid(12, 12, 8, g=2, r0=0.5, r1=1.5)
    for dt in (F64, F32):
        Bs = per_fill(G.sample(H.M1, dt), G); Js = G.run(raw, Bs, dt); scale = max(nmax(j[G.sl]) for j in Js)
        for nm, N in T3.null_mode_fields(G, dt, np.random.default_rng(TOL4['seeds']['t032'])).items():
            for a in (1e-6, 1e-3, 1.0, 1e3, 1e6):
                if dt is F32 and a > 1e6: continue
                B = [(b + dt(a)*n).astype(dt) for b, n in zip(Bs, N)]; J = G.run(raw, B, dt)
                d = max(nmax(np.asarray(J[c][G.sl], dtype=F64) - np.asarray(Js[c][G.sl], dtype=F64)) for c in range(3))
                bound = TOL4["fp_factor"]*EPS[dt]*(max(bmax_of(Bs), a))/hmin_of(G)
                cont.append(dict(dtype=dn(dt), family=nm, amplitude=a, delta_J=d, J_scale=scale, roundoff_bound=bound, within_bound=bool(d <= bound),
                                 contaminates_signal=bool(d > 0.1*scale)))
                if d > bound: fails.append(f"contamination {dn(dt)} {nm} a={a:g}: dJ {d:.2e} > round-off bound {bound:.2e}")
    res["contamination"] = cont
    # critical amplitude of checkerboard content at which round-off alone corrupts a signal of size J_scale (declared model: fp_factor*eps*a/h = 0.1*J)
    res["critical_amplitude"] = {dn(dt): 0.1*max(c["J_scale"] for c in cont if c["dtype"] == dn(dt))*hmin_of(G)/(TOL4["fp_factor"]*EPS[dt]) for dt in (F64, F32)}
    # operator rank by unit-vector probing of the kernel on small grids
    rk = []
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        Gs = C.Grid(5, 6, 4, g=2, r0=r0, r1=r0 + 1.0 if r0 else 1.0); rk.append(dict(mode=mode, grid=[5, 6, 4], **pattern_rank(raw, Gs, F64)))
    res["operator_rank"] = rk
    for r in rk:
        if r["nullity_of_influencing"] <= 0: fails.append(f"rank probe {r['mode']}: no nullity found although odd-even patterns are exactly invisible")
    res["safeguard_statement"] = ("Odd-even content in B is invisible to J = curl B and is neither detected nor damped by this kernel; its only effect on J is round-off at the "
                                  "eps*a/h level. The driver (CT update / divergence cleaning / filtering) must therefore control odd-even modes itself: the kernel cannot serve as a detector.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 033  Extreme magnetic dynamic range
# ============================================================================
def base_field_B0(G, dtype):
    return G.sample(H.M1 if G.rf[G.g] != 0.0 else cart_field("SMOOTH", H.CART["SMOOTH"]), F64)

def t033(be):
    res = dict(rows=[]); fails = []; raw = H.backend_for(be)
    ks = {F64: [-1074, -1030, -1000, -900, -700, -500, -300, -100, -30, 0, 30, 100, 300, 500, 700, 900, 1000, 1020],
          F32: [-149, -140, -130, -126, -120, -100, -60, -30, 0, 30, 60, 100, 120, 125, 126, 127]}
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        G = C.Grid(8, 8, 4, g=2, r0=r0, r1=r0 + 1.0 if r0 else 1.0)
        B0 = base_field_B0(G, F64)
        for dt in (F64, F32):
            tiny, huge = np.finfo(dt).tiny, np.finfo(dt).max
            safe_lo, safe_hi = TOL4["safe_k_fp64"] if dt is F64 else TOL4["safe_k_fp32"]
            rel_bound = None; rows = []
            for k in ks[dt]:
                with np.errstate(all="ignore"):
                    B = [np.ldexp(b, k).astype(dt) for b in B0]
                    if not all(np.isfinite(b).all() for b in B): continue
                    J = G.run(raw, B, dt)
                Jex = exact_curl(B, G, dt)
                e, m = fr_err(J, Jex, G); fin = all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3))
                Jmax_exact = fr_f(m); err = fr_f(e); rel = err/Jmax_exact if Jmax_exact > 0 else (0.0 if err == 0 else float("inf"))
                Jk = max(nmax(np.asarray(J[c][G.sl], dtype=F64)) if fin else float("inf") for c in range(3))
                if k == 0:
                    rel_bound = TOL4["fp_factor"]*EPS[dt]*max(bmax_of(B), 1e-300)/(hmin_of(G)*max(Jmax_exact, 1e-300))
                row = dict(mode=mode, dtype=dn(dt), k=k, B_max=bmax_of(B), J_exact_max=Jmax_exact, J_kernel_max=Jk, finite=fin, rel_err=rel, in_declared_safe_range=bool(safe_lo <= k <= safe_hi))
                rows.append(row)
            for r in rows:
                if not r["finite"]: cls = "OVERFLOW_OR_NONFINITE"
                elif r["J_exact_max"] < tiny and r["J_kernel_max"] == 0: cls = "UNDERFLOW_TO_ZERO (result below the normal range)"
                elif r["J_exact_max"] < tiny: cls = "SUBNORMAL_RESULT" if r["rel_err"] > rel_bound else "OK"
                elif r["J_kernel_max"] == 0 and r["J_exact_max"] > 0: cls = "FALSE_ZERO"
                elif r["rel_err"] > rel_bound: cls = "LOSS_OF_SIGNIFICANCE (intermediate under/overflow)"
                else: cls = "OK"
                r["classification"] = cls; r["rel_bound"] = rel_bound
                if r["in_declared_safe_range"] and cls != "OK": fails.append(f"{mode} {r['dtype']} k={r['k']}: {cls} inside the declared safe range (rel err {r['rel_err']:.2e} bound {rel_bound:.2e})")
            ok_ks = [r["k"] for r in rows if r["classification"] == "OK"]
            res["rows"] += rows
    zero_rows = []
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        G = C.Grid(8, 8, 4, g=2, r0=r0, r1=r0 + 1.0 if r0 else 1.0)
        for dt in (F64, F32):
            B = [np.zeros_like(b) for b in G.sample(H.M1 if r0 else cart_field("SMOOTH", H.CART["SMOOTH"]), dt)]; J = G.run(raw, B, dt)
            z = all(bool(np.all(np.asarray(J[c][G.sl]) == 0)) for c in range(3)); zero_rows.append(dict(mode=mode, dtype=dn(dt), exact_zero_in_exact_zero_out=z))
            if not z: fails.append(f"{mode} {dn(dt)}: zero field did not give exactly zero current")
    res["zero_field"] = zero_rows
    res["safe_range_observed"] = {}
    for mode in ("annulus", "axis"):
        for dtn in ("float64", "float32"):
            rr = [r for r in res["rows"] if r["mode"] == mode and r["dtype"] == dtn]
            ok = sorted(r["k"] for r in rr if r["classification"] == "OK"); res["safe_range_observed"][f"{mode}/{dtn}"] = [ok[0], ok[-1]] if ok else None
    res["classification_counts"] = {}
    for r in res["rows"]: res["classification_counts"][r["classification"]] = res["classification_counts"].get(r["classification"], 0) + 1
    res["silent_wrong_finite_rows"] = [dict(mode=r["mode"], dtype=r["dtype"], k=r["k"], cls=r["classification"], rel_err=r["rel_err"]) for r in res["rows"]
                                       if r["finite"] and r["classification"] not in ("OK",) and not r["classification"].startswith("UNDERFLOW_TO_ZERO")]
    res["statement"] = ("The amplitude 2^k of a fixed smooth field is swept to the edges of the floating-point range; the kernel's result is compared with an EXACT rational "
                        "evaluation of the same operator on the stored inputs. Inside the declared safe range every row must be OK; outside it every deviation is classified "
                        "(overflow, underflow-to-zero, subnormal result, loss of significance, false zero). Silent wrong-but-finite results outside the safe range are "
                        "recorded as a LIMITATION: the kernel does no range checking, the driver must keep amplitudes inside the observed safe range.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 034  Cancellation catastrophe (exact rational reference)
# ============================================================================
def t034(be):
    res = dict(rows=[]); fails = []; raw = H.backend_for(be)
    gx = lambda x, y, z: np.cos(x + z/2)*np.cos(y); gy = lambda x, y, z: -np.sin(x + z/2)*np.sin(y); gz = lambda x, y, z: 0.5*np.cos(x + z/2)*np.cos(y)
    bg = cart_field("grad psi", (gx, gy, gz, Z0, Z0, Z0)); sg = cart_field("signal", H.CART["SMOOTH"])
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        for n in ((16, 16, 8), (32, 32, 16)):
            G = C.Grid(*n, g=2, r0=r0, r1=r0 + 1.0 if r0 else 1.0)
            for dt in (F64, F32):
                Bg = G.sample(bg, dt); Bs = G.sample(sg, dt); Jsig = G.ref(sg); Jsig_max = max(nmax(j) for j in Jsig)
                for A in (0.0, 1e-3, 1e-2, 1e-1, 1.0, 3.0, 10.0, 30.0, 1e2, 1e4, 1e6, 1e8, 1e10):
                    if dt is F32 and A > 1e8: continue
                    B = [(dt(A)*a + b).astype(dt) for a, b in zip(Bg, Bs)]
                    J = G.run(raw, B, dt); Jex = exact_curl(B, G, dt)
                    e_rt, m_ex = fr_err(J, Jex, G)                                    # pure round-off error of the kernel (exact discrete operator on the same stored B)
                    d_tr = Fraction(0)
                    for c in range(3):
                        dd = np.vectorize(lambda a_, b_: abs(a_ - Fraction(float(b_))), otypes=[object])(Jex[c], np.asarray(Jsig[c], dtype=F64)); d_tr = max(d_tr, fr_max_abs(dd))
                    e_tot = max(nmax(np.asarray(J[c][G.sl], dtype=F64) - np.asarray(Jsig[c], dtype=F64)) for c in range(3))
                    bound = TOL4["fp_factor"]*EPS[dt]*max(bmax_of(B), 1e-300)/hmin_of(G)
                    r_ = dict(mode=mode, dtype=dn(dt), grid=list(n), amplitude=A, Bmax=bmax_of(B), signal_max=Jsig_max, roundoff_err_vs_exact=fr_f(e_rt), roundoff_bound=bound,
                              truncation_err_exact_discrete=fr_f(d_tr), total_abs_err=e_tot, total_rel_err=e_tot/Jsig_max, signal_to_error=Jsig_max/max(e_tot, 1e-300),
                              roundoff_signal_to_error=Jsig_max/max(fr_f(e_rt), 1e-300), recoverable=bool(Jsig_max >= TOL4["recover_ratio"]*e_tot),
                              roundoff_alone_recoverable=bool(Jsig_max >= TOL4["recover_ratio"]*fr_f(e_rt)))
                    if r_["roundoff_err_vs_exact"] > bound: fails.append(f"{mode} {dn(dt)} {n} A={A:g}: round-off error {r_['roundoff_err_vs_exact']:.2e} exceeds declared bound {bound:.2e}")
                    res["rows"].append(r_)
    res["minimum_recoverable"] = {}
    for mode in ("annulus", "axis"):
        for dtn in ("float64", "float32"):
            for n in ((16, 16, 8), (32, 32, 16)):
                rr = sorted([r for r in res["rows"] if r["mode"] == mode and r["dtype"] == dtn and r["grid"] == list(n)], key=lambda r: r["amplitude"])
                rec = [r["amplitude"] for r in rr if r["recoverable"]]; rrec = [r["amplitude"] for r in rr if r["roundoff_alone_recoverable"]]
                res["minimum_recoverable"][f"{mode}/{dtn}/{n[0]}x{n[1]}x{n[2]}"] = dict(
                    largest_recoverable_background_amplitude=max(rec) if rec else None,
                    first_unrecoverable_amplitude=min([r["amplitude"] for r in rr if not r["recoverable"]], default=None),
                    largest_amplitude_recoverable_if_only_roundoff=max(rrec) if rrec else None,
                    first_amplitude_unrecoverable_by_roundoff_alone=min([r["amplitude"] for r in rr if not r["roundoff_alone_recoverable"]], default=None))
    for r in res["rows"]:
        if r["recoverable"] != (r["signal_to_error"] >= TOL4["recover_ratio"]): fails.append("recoverable flag inconsistent with signal-to-error ratio")
        if (not r["recoverable"]) and r["total_rel_err"] < 0.1: fails.append(f"{r['mode']} {r['dtype']} A={r['amplitude']:g}: unrecoverable flag but relative error < 10%")
    # the truncation part scales like A*h^2: coarse -> fine grid ratio for the largest FP64 amplitude (sanity of the error model)
    for mode in ("annulus", "axis"):
        a = [r for r in res["rows"] if r["mode"] == mode and r["dtype"] == "float64" and r["amplitude"] == 1e4]
        if len(a) == 2:
            res.setdefault("truncation_scaling_ratio_2x_refinement", {})[mode] = a[0]["truncation_err_exact_discrete"]/a[1]["truncation_err_exact_discrete"]   # informational (ratio ~4 = second order)
    res["statement"] = ("Background A*grad(psi) (analytic curl exactly 0) plus a physical solenoidal signal with known curl. The kernel is compared with an EXACT rational "
                        "evaluation of its own operator on the same stored inputs, which separates pure round-off from truncation; the signal is recoverable only if signal >= 10 x total error "
                        "(the declared recover_ratio), and round-off alone is reported separately.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 035  Ghost-cell poisoning
# ============================================================================
SHAPES = lambda G: [(G.nr + 1 + 2*G.g, G.nphi + 2*G.g, G.nz + 2*G.g), (G.nr + 2*G.g, G.nphi + 1 + 2*G.g, G.nz + 2*G.g), (G.nr + 2*G.g, G.nphi + 2*G.g, G.nz + 1 + 2*G.g)]
def core_box(G):
    """index ranges (per component, per axis) of the entries lying on/inside the physical domain (the rest are ghost layers)"""
    g = G.g
    return [[(g, g + G.nr), (g, g + G.nphi - 1), (g, g + G.nz - 1)], [(g, g + G.nr - 1), (g, g + G.nphi), (g, g + G.nz - 1)], [(g, g + G.nr - 1), (g, g + G.nphi - 1), (g, g + G.nz)]]

def nonfinite_mask_any(J, G):
    m = np.zeros((G.nr, G.nphi, G.nz), bool)
    for c in range(3): m |= ~np.isfinite(np.asarray(J[c][G.sl], dtype=F64))
    return m

def ref_nonfinite_mask(G, B64):
    with np.errstate(all="ignore"):
        ref = H.ref_any(G, B64)
    return np.zeros((G.nr, G.nphi, G.nz), bool) | np.any([~np.isfinite(r) for r in ref], axis=0)

def footprint_scan(raw, G, rng):
    """poison every B entry (ghosts included) individually with NaN; footprint of an entry = set of interior cells whose current becomes non-finite.
    Kernel footprints are compared one by one with the footprints of the independent multi-index reference (which encodes the stencil independently)."""
    shp = SHAPES(G); B0 = [rng.uniform(-1, 1, s) for s in shp]; used = [np.zeros(s, bool) for s in shp]; foot = {}; mism = []
    for comp in range(3):
        for idx in np.ndindex(*shp[comp]):
            B = [b.copy() for b in B0]; B[comp][idx] = np.nan
            mk = nonfinite_mask_any(G.run(raw, B, F64), G)
            mr = ref_nonfinite_mask(G, B)
            if not np.array_equal(mk, mr): mism.append((comp, idx))
            used[comp][idx] = bool(mk.any()); foot[(comp, idx)] = mk
    return used, foot, mism

def reach_table(G, used):
    """ghost layers actually read, per component and axis: (layers below the core block, layers above)"""
    box = core_box(G); out = {}
    for comp, cn in enumerate(("Br", "Bphi", "Bz")):
        idx = np.argwhere(used[comp]); row = {}
        for ax, an in enumerate(AXES):
            lo, hi = box[comp][ax]
            row[an] = dict(below=int(max(0, lo - idx[:, ax].min())) if len(idx) else 0, above=int(max(0, idx[:, ax].max() - hi)) if len(idx) else 0)
        out[cn] = row
    return out

def t035(be):
    res = dict(grids=[]); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(TOL4["seeds"]["t035"])
    for mode, r0, g in (("annulus", 0.5, 2), ("annulus", 0.5, 3), ("axis", 0.0, 2), ("axis", 0.0, 3)):
        G = C.Grid(6, 6, 4, g=g, r0=r0, r1=r0 + 1.0 if r0 else 1.0); row = dict(mode=mode, g=g, grid=[6, 6, 4])
        used, foot, mism = footprint_scan(raw, G, rng)
        row["entries"] = int(sum(u.size for u in used)); row["used_entries"] = int(sum(u.sum() for u in used)); row["unused_entries"] = row["entries"] - row["used_entries"]
        row["footprint_mismatches_vs_independent_reference"] = len(mism)
        if mism: fails.append(f"{mode} g={g}: kernel dependency footprint differs from the independent reference for {len(mism)} entries, e.g. {mism[:3]}")
        row["reach"] = reach_table(G, used)
        # documented contract: axis mode never reads inner radial ghosts (index < g), but DOES read the axis face of Br (index g)
        if mode == "axis":
            inner_used = bool(used[0][:g].any() or used[1][:g].any() or used[2][:g].any()); axis_face_used = bool(used[0][g].any())
            row["axis_inner_ghosts_read"] = inner_used; row["axis_face_Br_read"] = axis_face_used
            if inner_used: fails.append(f"axis g={g}: inner radial ghost entries ARE read although the contract says they never are")
            if not axis_face_used: fails.append(f"axis g={g}: the axis face of Br is NOT read although the contract says it is")
        # procedure B: poison UNUSED padding with NaN / +-Inf / adversarial finite values -> output must be bitwise identical to the clean run
        cleanB = [rng.uniform(-1, 1, s) for s in SHAPES(G)]
        unused_rows = []
        for dt in (F64, F32):
            Bc = [b.astype(dt) for b in cleanB]; Jc = G.run(raw, Bc, dt)
            big = 1e300 if dt is F64 else 1e30
            for vname, v in (("NaN", np.nan), ("+Inf", np.inf), ("-Inf", -np.inf), ("+huge finite", big), ("alternating huge", None)):
                Bp = [b.copy() for b in Bc]
                for comp in range(3):
                    m = ~used[comp]
                    if v is None: Bp[comp][m] = (big*np.where((np.indices(m.shape).sum(0)[m] % 2) == 0, 1, -1)).astype(dt)
                    else: Bp[comp][m] = dt(v)
                Jp = G.run(raw, Bp, dt)
                same = all(np.array_equal(np.asarray(Jp[c][G.sl]), np.asarray(Jc[c][G.sl])) for c in range(3))
                unused_rows.append(dict(dtype=dn(dt), poison=vname, unused_entries=int(sum((~u).sum() for u in used)), output_bitwise_identical_to_clean=same))
                if not same: fails.append(f"{mode} g={g} {dn(dt)}: poisoning UNUSED padding with {vname} changed the valid output")
        row["unused_padding_poison"] = unused_rows
        # procedure C: poison REQUIRED ghost entries -> non-finite output exactly on the union of their footprints (no silent finite result)
        req = []
        for comp in range(3):
            box = core_box(G)[comp]; inside = np.ones(used[comp].shape, bool); Iall = np.indices(used[comp].shape)
            for ax in range(3): inside &= (Iall[ax] >= box[ax][0]) & (Iall[ax] <= box[ax][1])
            req.append(used[comp] & ~inside)                                   # required entries that lie in a ghost layer (outside the physical block along at least one axis)
        union = np.zeros((G.nr, G.nphi, G.nz), bool)
        for comp in range(3):
            for idx in zip(*np.nonzero(req[comp])): union |= foot[(comp, tuple(int(v) for v in idx))]
        row["required_ghost_entries"] = int(sum(m.sum() for m in req)); row["cells_depending_on_required_ghosts"] = int(union.sum())
        req_rows = []
        for dt in (F64, F32):
            Bc = [b.astype(dt) for b in cleanB]; big = 1e30
            for vname, v in (("NaN", np.nan), ("+Inf", np.inf), ("-Inf", -np.inf)):
                Bp = [b.copy() for b in Bc]
                for comp in range(3): Bp[comp][req[comp]] = dt(v)
                Jp = G.run(raw, Bp, dt); nf = nonfinite_mask_any(Jp, G)
                ok = bool(np.array_equal(nf, union)); req_rows.append(dict(dtype=dn(dt), poison=vname, nonfinite_cells=int(nf.sum()), expected_cells=int(union.sum()), mask_matches_footprint=ok))
                if not ok: fails.append(f"{mode} g={g} {dn(dt)}: {vname} in required ghosts gave non-finite mask != expected footprint ({int(nf.sum())} vs {int(union.sum())} cells) - a silent finite result or spurious contamination")
            Bp = [b.copy() for b in Bc]
            for comp in range(3): Bp[comp][req[comp]] = dt(big)
            Jp = G.run(raw, Bp, dt); B64 = [b.astype(F64) for b in Bp]
            with np.errstate(all="ignore"): ref = H.ref_any(G, B64)
            sc = max(nmax(r) for r in ref); d = max(nmax(np.asarray(Jp[c][G.sl], dtype=F64) - ref[c]) for c in range(3))
            Jc = G.run(raw, Bc, dt); changed = bool(any(not np.array_equal(np.asarray(Jp[c][G.sl]), np.asarray(Jc[c][G.sl])) for c in range(3)))
            tol = (TOL4["ref_equiv_fp64"] if dt is F64 else 64*EPS[dt]*big/hmin_of(G)/sc)
            req_rows.append(dict(dtype=dn(dt), poison="+huge finite (adversarial, still finite)", output_changed_vs_clean=changed, rel_diff_vs_reference_on_same_inputs=d/sc, tol=tol,
                                 finite_wrong_current_is_silent=bool(changed and np.isfinite(Jp[0][G.sl]).all())))
            if d/sc > tol: fails.append(f"{mode} g={g} {dn(dt)}: adversarial finite ghost values were not propagated faithfully (rel diff {d/sc:.2e})")
        row["required_ghost_poison"] = req_rows
        res["grids"].append(row)
    # validator behaviour on invalid REQUIRED inputs
    G = C.Grid(6, 6, 4, g=2, r0=0.5, r1=1.5); dt = F64; B = [rng.uniform(-1, 1, s).astype(dt) for s in SHAPES(G)]
    Jz_ = [np.zeros((G.nr + 4, G.nphi + 4, G.nz + 4), dt) for _ in range(3)]
    def chk(label, **kw):
        a = dict(Br=B[0], Bphi=B[1], Bz=B[2], Jr=Jz_[0], Jphi=Jz_[1], Jz=Jz_[2], r_faces=G.rf.astype(dt).copy(), r_centers=G.rc.astype(dt).copy(), dr=G.dr, dphi=G.dphi, dz=G.dz, nr=G.nr, nphi=G.nphi, nz=G.nz, g=2)
        a["Bphi"] = a["Bphi"].copy(); a["Br"] = a["Br"].copy(); a["Bz"] = a["Bz"].copy()
        for k_, v_ in kw.items():
            if k_ == "rf_nan": a["r_faces"][3] = np.nan
            elif k_ == "rc_inf": a["r_centers"][4] = np.inf
            elif k_ == "B_nan": a["Br"][3, 3, 3] = np.nan
            elif k_ == "ghost_nan": a["Bz"][0, 0, 0] = np.nan
            else: a[k_] = v_
        try: K.validate_inputs(*[a[n] for n in ("Br", "Bphi", "Bz", "Jr", "Jphi", "Jz", "r_faces", "r_centers", "dr", "dphi", "dz", "nr", "nphi", "nz", "g")]); return dict(case=label, rejected=False)
        except K.CurlContractError as ex: return dict(case=label, rejected=True, message=str(ex)[:90])
    vr = [chk("NaN in r_faces", rf_nan=1), chk("Inf in r_centers", rc_inf=1), chk("dr = NaN", dr=float("nan")), chk("dz = inf", dz=float("inf")), chk("dphi = 0", dphi=0.0),
          chk("NaN in an interior Br entry", B_nan=1), chk("NaN in a ghost Bz entry", ghost_nan=1)]
    res["validator"] = vr
    must_reject = ("NaN in r_faces", "Inf in r_centers", "dr = NaN", "dz = inf", "dphi = 0")
    for r in vr:
        if r["case"] in must_reject and not r["rejected"]: fails.append(f"validator did not reject: {r['case']}")
    res["B_content_not_inspected"] = bool(not any(r["rejected"] for r in vr if r["case"].startswith("NaN in") and ("Br" in r["case"] or "Bz" in r["case"])))
    res["statement"] = ("Dependency footprint measured entry by entry and matched against an independent implementation of the stencil; unused padding is inert (bitwise); non-finite required "
                        "ghost values propagate to exactly the dependent cells (never silently finite); the launcher validates coordinates/spacings but does NOT inspect B contents, "
                        "so adversarial FINITE ghost values silently produce finite wrong currents - the caller owns ghost correctness.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 036  Cylindrical metric stress
# ============================================================================
def kappa_of(G):
    """metric conditioning factor of the three stencils: max(rf_max/(rc_min dr), 1/dz, 1/(rc_min dphi))"""
    g = G.g; rc = G.rc[g:g + G.nr]; rf = G.rf[g:g + G.nr + 1]
    return max(float(rf.max()/(rc.min()*G.dr)), 1.0/G.dz, 1.0/(float(rc.min())*G.dphi))

def exact_poly_field(beta=0.7, gam=0.4):
    """B = (beta z, gam r, 1.5 + 0.5 z):  the discrete operator reproduces J = (0, beta, 2 gam) EXACTLY (linear data, compact radial difference of r*B_phi = gam r^2)"""
    return C.Field(lambda r, p, z: beta*z + 0*r, lambda r, p, z: gam*r + 0*z, lambda r, p, z: 1.5 + 0.5*z + 0*r, lambda r, p, z: 0*r + 0*z, lambda r, p, z: beta + 0*r + 0*z, lambda r, p, z: 2*gam + 0*r + 0*z, "exact-poly")

METRIC_CASES = [  # name, r0, dr, nr, nphi, dz, nz
    ("tiny radius r0 = 2e-3 dr", 2e-3*0.05, 0.05, 8, 8, 0.1, 4), ("tiny radius r0 = 1e-2 dr", 1e-2*0.05, 0.05, 8, 8, 0.1, 4), ("tiny radius r0 = 0.1 dr", 0.1*0.05, 0.05, 8, 8, 0.1, 4),
    ("r0 = 0.5 dr (first centre dr)", 0.5*0.05, 0.05, 8, 8, 0.1, 4), ("large radius r0 = 1e2", 1e2, 0.05, 8, 64, 0.05, 4), ("large radius r0 = 1e3", 1e3, 0.05, 8, 64, 0.05, 4),
    ("large radius r0 = 1e4", 1e4, 0.05, 8, 64, 0.05, 4), ("large radius r0 = 1e5", 1e5, 0.05, 8, 64, 0.05, 4), ("dr/dz = 1e-3", 0.5, 1e-3, 8, 8, 1.0, 4), ("dr/dz = 1e3", 0.5, 1.0, 8, 8, 1e-3, 4),
    ("rc*dphi << dr (nphi = 256, r0 = 0.5, dr = 1)", 0.5, 1.0, 6, 256, 0.5, 4), ("rc*dphi >> dr (nphi = 4, r0 = 1e3, dr = 1e-3)", 1e3, 1e-3, 6, 4, 0.5, 4)]

def t036(be):
    res = dict(rows=[]); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(TOL4["seeds"]["t036"]); fld = exact_poly_field()
    for name, r0, dr, nr, nphi, dz, nz in METRIC_CASES:
        G = C.Grid(nr, nphi, nz, g=2, r0=r0, r1=r0 + nr*dr, z0=0.0, z1=nz*dz)
        for dt in (F64, F32):
            row = dict(case=name, dtype=dn(dt), r0=r0, dr=dr, dz=dz, nphi=nphi, aspect_rdphi_over_dr=float(G.rc[G.g]*G.dphi/G.dr), aspect_dz_over_dr=dz/dr, r0_over_dr=r0/dr)
            try:
                K.validate_inputs(*[np.zeros(s, dt) for s in SHAPES(G)], *[np.zeros((nr + 4, nphi + 4, nz + 4), dt) for _ in range(3)], G.rf.astype(dt), G.rc.astype(dt), G.dr, G.dphi, G.dz, nr, nphi, nz, 2)
            except K.CurlContractError as ex:
                row["rejected_by_validator"] = str(ex)[:100]; row["ok"] = True; res["rows"].append(row); continue
            kap = kappa_of(G); B = G.sample(fld, dt); J = G.run(raw, B, dt); ref = [np.zeros((nr, nphi, nz)), np.full((nr, nphi, nz), 0.7), np.full((nr, nphi, nz), 0.8)]
            Bmax = bmax_of(B); bound = TOL4["fp_factor"]*EPS[dt]*Bmax*kap
            err = [nmax(np.asarray(J[c][G.sl], dtype=F64) - ref[c]) for c in range(3)]; fin = all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3))
            Bn = G.sample(C.Field(*(lambda r, p, z: 0*r,)*6, "n"), dt)
            Br_ = [(rng.uniform(-1, 1, s)).astype(dt) for s in SHAPES(G)]; Jr_ = G.run(raw, Br_, dt); refr = H.ref_any(G, [b.astype(F64) for b in Br_])
            sc = max(nmax(r) for r in refr); eq = max(nmax(np.asarray(Jr_[c][G.sl], dtype=F64) - refr[c]) for c in range(3))
            eq_bound = TOL4["fp_factor"]*EPS[dt]*1.0*kap
            row.update(kappa=kap, Bmax=Bmax, roundoff_bound=bound, exact_field_abs_err=err, exact_field_rel_err=max(err[1]/0.7, err[2]/0.8), finite=fin,
                       random_vs_reference_abs_diff=eq, random_vs_reference_bound=eq_bound, random_vs_reference_rel=eq/sc)
            row["ok"] = bool(fin and max(err) <= bound and eq <= eq_bound)
            jmax = 0.8; row["signal_max"] = jmax; row["bound_over_signal"] = bound/jmax; row["discriminating"] = bool(bound <= TOL4["disc_fraction"]*jmax)
            if not row["ok"]: fails.append(f"{name} {dn(dt)}: exact-field err {max(err):.2e} (bound {bound:.2e}), random-vs-reference {eq:.2e} (bound {eq_bound:.2e}), finite={fin}")
            res["rows"].append(row)
    # a metric-sensitive non-polynomial case: irrotational vortex Bphi = 1/r (analytic J = 0) at radii comparable to dr -> truncation error scales ~ dr^2/r^3 (reported, no accuracy claim)
    vort = []
    for c_ in (0.6, 1.2, 2.2, 4.4, 8.8, 16.6):
        dr = 0.05; G = C.Grid(8, 8, 4, g=2, r0=c_*dr, r1=c_*dr + 8*dr, z0=0.0, z1=0.4); B = G.sample(C.Field(lambda r, p, z: 0*r, lambda r, p, z: 1/np.abs(r) + 0*z, lambda r, p, z: 0*r, *(lambda r, p, z: 0*r,)*3, "vortex (ghost rings: even continuation 1/|r|)"), F64)
        J = G.run(raw, B, F64); vort.append(dict(r0_over_dr=c_, max_abs_Jz_spurious=nmax(J[2][G.sl])))
    res["vortex_truncation"] = vort
    res["statement"] = ("Fields the discrete operator reproduces exactly (linear Br, Bphi = r, linear Bz) must give the exact current to within the declared conditioning-aware round-off bound "
                        "64*eps*Bmax*kappa (kappa = max(rf/(rc dr), 1/dz, 1/(rc dphi))) on every grid, including tiny positive start radii, r0/dr up to 2e6 and aspect ratios of 1e3; random fields "
                        "must agree with the independent FP64 reference. Rows whose bound exceeds half the true current cannot fail and are labelled NON-DISCRIMINATING: for them the PASS is only a characterisation (observed errors are reported), NOT evidence of usable accuracy. Relative accuracy degrades with eps*Bmax*kappa/|J| (large-radius cancellation in r*Bphi): a conditioning LIMITATION, not a defect.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 037  Kink instability reconstruction: azimuthal phase and amplitude, measured independently
# ============================================================================
def spec_helical(eps, alpha, k=KW, b0=0.5):
    """straight pinch Bphi = b0 r displaced helically: B = Bpinch(x - xi(z)), xi = eps (cos(kz+alpha), sin(kz+alpha));  J = (-b0 eps k sin th, b0 eps k cos th, 2 b0)"""
    th = lambda z: k*z + alpha
    return (lambda x, y, z: -b0*(y - eps*np.sin(th(z))) + 0*x, lambda x, y, z: b0*(x - eps*np.cos(th(z))) + 0*x, Z0,
            lambda x, y, z: -b0*eps*k*np.sin(th(z)) + 0*x, lambda x, y, z: b0*eps*k*np.cos(th(z)) + 0*x, lambda x, y, z: 2*b0 + 0*x)

def harmonic(Q, n):
    """complex azimuthal Fourier coefficient (1/N) sum_j Q_j exp(-i n phi_j) of Q (axis 0 = phi) for every other index; Q complex"""
    N = Q.shape[0]; return np.fft.fft(Q, axis=0)[n % N]/N

def harmonic_metrics(G, J, ref, ring, n1, n2):
    """amplitude / phase error of the dominant harmonics of Q1 = Jr + i Jphi (harmonic n1) and Q2 = Jz (harmonic n2) at one radial ring, per z plane.
    Relative metrics divide by the local analytic amplitude; SCALED metrics divide by the amplitude at the middle ring (a fixed scale that does not vanish as the
    axis ring shrinks).  leakage = largest difference from the ANALYTIC spectrum over all other harmonics."""
    g = G.g; Jc = [np.asarray(j[g + ring, g:g + G.nphi, g:g + G.nz], dtype=F64) for j in J]; Rc = [np.asarray(r[ring], dtype=F64) for r in ref]
    Rm = [np.asarray(r[G.nr//2], dtype=F64) for r in ref]
    out = {}
    for name, (Qk, Qa, Qm, n) in {"Jr+iJphi": (Jc[0] + 1j*Jc[1], Rc[0] + 1j*Rc[1], Rm[0] + 1j*Rm[1], n1), "Jz": (Jc[2] + 0j, Rc[2] + 0j, Rm[2] + 0j, n2)}.items():
        ck = np.fft.fft(Qk, axis=0)/G.nphi; ca = np.fft.fft(Qa, axis=0)/G.nphi; cm = np.fft.fft(Qm, axis=0)/G.nphi
        a = ca[n % G.nphi]; amax = float(np.abs(a).max()); norm = float(np.abs(cm[n % G.nphi]).max())
        if norm < 1e-12: out[name] = dict(dominant_amplitude=amax, skipped="analytic harmonic is zero"); continue
        others = np.ones(G.nphi, bool); others[n % G.nphi] = False
        d = dict(dominant_amplitude=amax, scale_amplitude=norm, leakage_scaled=float(np.max(np.abs(ck[others] - ca[others]))/norm))
        d["amp_err_scaled"] = float(np.max(np.abs(np.abs(ck[n % G.nphi]) - np.abs(a)))/norm)
        sel = np.abs(a) >= 0.2*amax if amax > 0 else np.zeros_like(a, bool)
        ratio = ck[n % G.nphi][sel]/a[sel]
        d["phase_err_scaled"] = float(np.max(np.abs(a[sel])*np.abs(np.angle(ratio)))/norm) if sel.any() else 0.0
        d["amplitude_error"] = float(np.max(np.abs(np.abs(ratio) - 1))) if sel.any() else 0.0; d["phase_error"] = float(np.max(np.abs(np.angle(ratio)))) if sel.any() else 0.0
        d["leakage"] = d["leakage_scaled"]
        out[name] = d
    return out

KINK_CASES = ([(f"helical kink m=1 eps={e:g} alpha={al:g}", spec_helical(e, al), -1, 0) for e in (0.01, 0.3) for al in (0.0, 0.7)]
              + [(f"modulated m={m} cos(2 pi z)", spec_modulated(m), m - 1, m - 1) for m in (1, 2, 3, 4)])

def t037(be):
    res = dict(cases=[]); fails = []; raw = H.backend_for(be)
    for name, spec, n1, n2 in KINK_CASES:
        chk = H.cart_reference_check(spec)
        if chk > 1e-8: fails.append(f"{name}: analytic curl disagrees with numeric curl ({chk:.2e})")
        fld = cart_field(name, spec)
        for mode, r0, rings in (("annulus", 0.5, ("mid",)), ("axis", 0.0, ("ring0", "mid"))):
            for rn in rings:
                lev = []
                for n in H.levels(TOL4["conv_base"], 4):
                    G = C.Grid(*n, r0=r0, r1=r0 + 1.0 if r0 else 1.0); B = G.sample(fld, F64); J = G.run(raw, B, F64); ref = G.ref(fld)
                    ring = 0 if rn == "ring0" else G.nr//2
                    m = harmonic_metrics(G, J, ref, ring, n1, n2); m["h"] = max(G.dr, G.dz); m["grid"] = list(n); m["ring_radius"] = float(G.rc[G.g + ring]); lev.append(m)
                row = dict(case=name, mode=mode, ring=rn, levels=lev, quantities={})
                for q in ("Jr+iJphi", "Jz"):
                    if "skipped" in lev[0].get(q, {}): row["quantities"][q] = dict(skipped=lev[0][q]["skipped"]); continue
                    qd = {}
                    for key, skey in (("amplitude_error", "amp_err_scaled"), ("phase_error", "phase_err_scaled")):
                        errs = [l[q][skey] for l in lev]; rel = [l[q][key] for l in lev]; floor = TOL4["exact_fp64"]; o = orders_of(errs); atf = all(e <= floor for e in errs)
                        ok = bool(o[-1] >= TOL4["kink_amp_order"] or atf); ro = orders_of(rel); rel_atf = all(e <= floor for e in rel)
                        rel_ok = bool(ro[-1] >= TOL4["kink_amp_order"] or rel_atf)
                        qd[key] = dict(errors=errs, orders=o, at_floor=atf, ok=ok, relative_errors=rel, relative_orders=ro, relative_ok=rel_ok,
                                       relative_limitation=bool(rn == "ring0" and not rel_ok))
                        if not ok: fails.append(f"{name} {mode}/{rn} {q} {key} (scaled by mid-ring amplitude): orders {['%.2f' % x for x in o]}")
                    lk = [l[q]["leakage"] for l in lev]
                    scale = [TOL4["leak_factor"]*EPS[F64]/l["h"] for l in lev]
                    lo = orders_of(lk); at_rb = all(a <= b for a, b in zip(lk, scale))
                    qd["leakage"] = dict(values=lk, bounds=scale, orders=lo, within_roundoff=at_rb, ok=bool(at_rb or lo[-1] >= TOL4["kink_amp_order"]))
                    if not qd["leakage"]["ok"]: fails.append(f"{name} {mode}/{rn} {q}: leakage into other azimuthal harmonics {max(lk):.2e} neither at round-off nor converging (orders {['%.2f' % x for x in lo]})")
                    row["quantities"][q] = qd
                res["cases"].append(row)
    # amplitude independence (linearity of the reconstruction): helical kink amplitudes 0.01 vs 0.3 give the same relative amplitude error
    pairs = {}
    for r in res["cases"]:
        if r["case"].startswith("helical kink") and r["mode"] == "annulus" and "alpha=0 " in r["case"] + " ":
            pairs[r["case"]] = r["quantities"]["Jr+iJphi"]["amplitude_error"]["errors"][-1]
    res["amplitude_independence"] = pairs
    vals = [v for v in pairs.values()]
    if len(vals) == 2 and max(vals) > 0 and abs(vals[0] - vals[1]) > 0.05*max(vals) + 1e-12: fails.append(f"relative amplitude error depends on the kink amplitude: {vals}")
    res["ring0_relative_limitations"] = [f"{r['case']} {r['mode']}/{r['ring']} {q} {k}" for r in res["cases"] for q, d in r["quantities"].items() if "skipped" not in d for k in ("amplitude_error", "phase_error") if d[k].get("relative_limitation")]
    res["statement"] = ("Phase and amplitude of the reconstructed azimuthal harmonics (Jr + iJphi at harmonic m-1 and Jz) are measured separately against the analytic curl of helical and "
                        "z-modulated m = 1..4 fields at an interior ring and, on axis grids, at the first physical ring; both converge at second order (or sit at round-off). Because the "
                        "operator is circulant in phi, other harmonics are not excited beyond round-off (leakage).")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 038  Discontinuity and current-sheet stress
# ============================================================================
def prof(x, xs, delta, kind):
    if kind == "sharp": return np.where(x > xs, 1.0, np.where(x < xs, 0.0, 0.5))
    return 0.5*(1 + np.tanh((x - xs)/delta))
def dprof(x, xs, delta):
    return 0.5/(delta*np.cosh((x - xs)/delta)**2)

SHEET_PSI = lambda r: 1 + 0.5*np.sin(3*r)               # smooth test function for weak convergence
SHEET_DPSI = lambda r: 1.5*np.cos(3*r)
def psi_int_r_dpsi(a, b):                               # int_a^b r psi'(r) dr  (closed form)
    F = lambda r: 0.5*r*np.sin(3*r) + np.cos(3*r)/6
    return F(b) - F(a)

def sheet_sample(kind_dir, G, B0, xs, delta, kind, dt):
    g = G.g; shp = SHAPES(G); B = [np.zeros(s, dtype=F64) for s in shp]
    if kind_dir == "Bz(r) -> Jphi":
        B[2][:] = B0*prof(G.rc, xs, delta, kind)[:, None, None]
    elif kind_dir == "Bphi(r) -> Jz":
        B[1][:] = B0*prof(G.rc, xs, delta, kind)[:, None, None]
    else:                                              # Br(z) -> Jphi
        B[0][:] = B0*prof(G.zc, xs, delta, kind)[None, None, :]
    return [b.astype(dt) for b in B]

def sheet_metrics(kind_dir, G, J, B0, xs, delta, kind, dt, B_s):
    """integrated current identity, sign (overshoot), support width, peak, weak (test-function) and pointwise (smooth) errors"""
    g = G.g
    if kind_dir == "Bz(r) -> Jphi":
        Jc = np.asarray(J[1][G.sl], dtype=F64)[:, 0, 0]; x = G.rc[g:g + G.nr]; w = G.dr; weight = np.ones_like(x); jump = -B0                      # Jphi = -dBz/dr
        ana = -B0*dprof(x, xs, delta); sheet_sign = -1.0
        W_ana = -B0*SHEET_PSI(xs)
        Bz = np.asarray(B_s[2][:, 0, 0], dtype=F64); n = G.nr
        I_exact = -0.5*(Bz[g + n] + Bz[g + n - 1] - Bz[g] - Bz[g - 1]); I_kernel = float(np.sum(Jc)*w); cont = jump
    elif kind_dir == "Bphi(r) -> Jz":
        Jc = np.asarray(J[2][G.sl], dtype=F64)[:, 0, 0]; x = G.rc[g:g + G.nr]; w = G.dr
        ana = (B0*prof(x, xs, delta, "smooth") + x*B0*dprof(x, xs, delta))/x if kind == "smooth" else None; sheet_sign = None
        rin, rout = G.rf[g], G.rf[g + G.nr]
        Bp = np.asarray(B_s[1][:, 0, 0], dtype=F64); n = G.nr
        I_exact = rout*0.5*(Bp[g + n - 1] + Bp[g + n]) - rin*0.5*(Bp[g - 1] + Bp[g]); cont = rout*B0
        I_kernel = float(np.sum(x*Jc)*w)
        W_ana = rout*B0*SHEET_PSI(rout) - psi_int_r_dpsi(xs, rout)*B0 if kind == "sharp" else None
    else:
        Jc = np.asarray(J[1][G.sl], dtype=F64)[0, 0, :]; x = G.zc[g:g + G.nz]; w = G.dz; ana = B0*dprof(x, xs, delta); sheet_sign = 1.0
        Br = np.asarray(B_s[0][0, 0, :], dtype=F64); n = G.nz
        I_exact = 0.5*(Br[g + n] + Br[g + n - 1] - Br[g] - Br[g - 1]); cont = B0; I_kernel = float(np.sum(Jc)*w); W_ana = B0*SHEET_PSI(xs)
    out = dict(integral_kernel=I_kernel, integral_exact=I_exact, integral_continuum=cont, continuum_residual=abs(I_exact - cont), integral_err=abs(I_kernel - I_exact), scale=abs(B0)*max(float(x.max()), 1.0))
    if kind_dir != "Bphi(r) -> Jz":
        s = sheet_sign; out["undershoot_over_peak"] = float(max(0.0, np.max(-s*Jc))/max(np.max(np.abs(Jc)), 1e-300))
        out["support_cells"] = int(np.sum(np.abs(Jc) > 1e-12*abs(B0)/w)); out["peak_times_h_over_B0"] = float(np.max(np.abs(Jc))*w/abs(B0))
        if kind == "sharp":
            psi = SHEET_PSI(x) if kind_dir != "Br(z) -> Jphi" else SHEET_PSI(x)
            W_k = float(np.sum(Jc*psi)*w); out["weak_kernel"] = W_k; out["weak_exact"] = W_ana; out["weak_err"] = abs(W_k - W_ana)
        else:
            out["pointwise_err"] = float(np.max(np.abs(Jc - ana)))
    else:
        out["support_cells"] = None
        if kind == "sharp":
            psi = SHEET_PSI(x); W_k = float(np.sum(x*Jc*psi)*w); out["weak_kernel"] = W_k; out["weak_exact"] = W_ana; out["weak_err"] = abs(W_k - W_ana)
        else: out["pointwise_err"] = float(np.max(np.abs(Jc - ana)))
    return out

def t038(be):
    res = dict(rows=[]); fails = []; raw = H.backend_for(be); B0 = 1.7
    cases = [("Bz(r) -> Jphi", 1.0, "face-aligned", "r"), ("Bz(r) -> Jphi", 1.0123, "generic offset", "r"), ("Bphi(r) -> Jz", 1.0, "face-aligned", "r"), ("Bphi(r) -> Jz", 1.0123, "generic offset", "r"),
             ("Br(z) -> Jphi", 0.0, "face-aligned", "z"), ("Br(z) -> Jphi", 0.0123, "generic offset", "z")]
    levels = (16, 32, 64, 128, 256)
    for dt in (F64, F32):
        for kd, xs, align, ax in cases:
            for kind in ("sharp", "smooth"):
                rows = []
                for N in levels:
                    if ax == "r": G = C.Grid(N, 6, 4, g=2, r0=0.5, r1=1.5, z0=-0.5, z1=0.5)
                    else: G = C.Grid(6, 6, N, g=2, r0=0.5, r1=1.5, z0=-0.5, z1=0.5)
                    delta = 0.08; B = sheet_sample(kd, G, B0, xs, delta, kind, dt); J = G.run(raw, B, dt)
                    if not all(bool(np.isfinite(J[c][G.sl]).all()) for c in range(3)): fails.append(f"{kd} {align} {kind} N={N}: non-finite"); continue
                    m = sheet_metrics(kd, G, J, B0, xs, delta, kind, dt, B); m["N"] = N; m["h"] = (G.dr if ax == "r" else G.dz); rows.append(m)
                row = dict(dtype=dn(dt), direction=kd, alignment=align, kind=kind, sheet_position=xs, levels=rows)
                tol = TOL4["sheet_int_factor"]*EPS[dt]*max(r["scale"] for r in rows)*max(1.0, 1/rows[-1]["h"])
                row["integral_identity_ok"] = bool(all(r["integral_err"] <= tol for r in rows)); row["integral_tol"] = tol
                if not row["integral_identity_ok"]: fails.append(f"{dn(dt)} {kd} {align} {kind}: integrated sheet current identity violated (max err {max(r['integral_err'] for r in rows):.2e}, tol {tol:.2e})")
                if kd != "Bphi(r) -> Jz":
                    row["max_undershoot_over_peak"] = max(r["undershoot_over_peak"] for r in rows); row["max_support_cells"] = max(r["support_cells"] for r in rows) if kind == "sharp" else None
                    if row["max_undershoot_over_peak"] > 1e-12 and kind == "sharp": fails.append(f"{dn(dt)} {kd} {align} sharp: opposite-sign current (overshoot) {row['max_undershoot_over_peak']:.2e}")
                    if kind == "sharp" and row["max_support_cells"] > 3: fails.append(f"{dn(dt)} {kd} {align}: sheet current spread over {row['max_support_cells']} cells (>3)")
                if kind == "sharp" and dt is F64:
                    errs = [r["weak_err"] for r in rows]; hs = [r["h"] for r in rows]
                    slope = float(np.polyfit(np.log(hs), np.log(np.maximum(errs, 1e-300)), 1)[0]); floor = 1e-12
                    row["weak_errors"] = errs; row["weak_order_fit"] = slope; row["weak_at_floor"] = bool(max(errs) <= floor)
                    row["weak_ok"] = bool(slope >= TOL4["sheet_weak_order"] or row["weak_at_floor"])
                    if not row["weak_ok"]: fails.append(f"{kd} {align}: weak convergence order {slope:.2f} < {TOL4['sheet_weak_order']}")
                if kind == "smooth" and dt is F64:
                    errs = [r["pointwise_err"] for r in rows]; o = orders_of(errs)
                    row["pointwise_errors"] = errs; row["pointwise_orders"] = o
                    row["resolved_ok"] = bool(o[-1] >= TOL4["sheet_resolved_order"])
                    if not row["resolved_ok"]: fails.append(f"{kd} {align} smoothed sheet: pointwise orders {['%.2f' % x for x in o]} (last < {TOL4['sheet_resolved_order']})")
                if kind == "sharp" and dt is F64:
                    pe = [r.get("peak_times_h_over_B0") for r in rows]; row["peak_times_h_over_B0"] = pe
                res["rows"].append(row)
    res["statement"] = ("For grid-aligned and offset discontinuities of Bz(r), Bphi(r) and Br(z): (i) the integrated sheet current equals the field jump EXACTLY (telescoping, round-off only; "
                        "with the r-weight for Jz); (ii) a monotone step never produces opposite-sign current (no overshoot) and the current is localised on <= 3 cells with peak ~ B0/(2h); "
                        "(iii) pointwise values do NOT converge at the discontinuity (peak ~ 1/h) - only the weak (test-function) integral converges, at the measured order; (iv) a RESOLVED "
                        "smoothed sheet converges pointwise. No pointwise second-order claim is made across a discontinuity.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 039  GPU numerical adversarial suite  (host leg = same suite on the CPU path + AddressSanitizer; ONLY the cupy leg is GPU evidence)
# ============================================================================
AWK_ANNULUS = [(3, 3, 1, 1, 0.5), (5, 7, 3, 2, 0.5), (7, 11, 13, 2, 1.7), (13, 5, 2, 3, 0.3), (2, 4, 5, 1, 0.5), (31, 3, 9, 2, 0.5), (1, 3, 1, 1, 0.5), (17, 13, 11, 3, 0.5)]
AWK_AXIS = [(3, 3, 1, 2, 0.0), (4, 5, 2, 2, 0.0), (11, 13, 7, 3, 0.0), (33, 5, 2, 2, 0.0), (5, 17, 3, 2, 0.0), (9, 8, 4, 3, 0.0)]
_REACH_CACHE = {}
def reach_for(raw, mode, g):
    """size-independent stencil reach (ghost layers read) measured by single-entry NaN poisoning on a small grid"""
    key = (mode, g)
    if key not in _REACH_CACHE:
        G = C.Grid(5, 5, 4, g=g, r0=0.5 if mode == "annulus" else 0.0, r1=1.5 if mode == "annulus" else 1.0); used, _f, mism = footprint_scan(H.backend_for(C.HostBackend()), G, np.random.default_rng(39))
        _REACH_CACHE[key] = (reach_table(G, used), mism)
    return _REACH_CACHE[key]

def unused_mask(G, reach):
    """True where the B entry lies outside the box the stencil reads (padding the kernel is allowed to ignore)"""
    box = core_box(G); out = []
    for comp, cn in enumerate(("Br", "Bphi", "Bz")):
        shp = SHAPES(G)[comp]; m = np.zeros(shp, bool)
        inside = np.ones(shp, bool)
        for ax, an in enumerate(AXES):
            lo, hi = box[comp][ax]; lo2 = lo - reach[cn][an]["below"]; hi2 = hi + reach[cn][an]["above"]
            ix = np.arange(shp[ax]); ok = (ix >= lo2) & (ix <= hi2); sh = [1, 1, 1]; sh[ax] = -1; inside &= ok.reshape(sh)
        out.append(~inside)
    return out

def gpu_error_check():
    """explicit device error state after the launch + synchronisation"""
    try:
        import cupy as cp
        cp.cuda.runtime.deviceSynchronize(); st = "deviceSynchronize OK"
        gl = getattr(cp.cuda.runtime, "getLastError", None)
        if gl is not None:
            st += f"; cudaGetLastError -> {gl()}"
        else: st += "; cudaGetLastError not exposed by this CuPy (errors surface as exceptions at synchronisation)"
        return dict(ok=True, status=st)
    except Exception as ex: return dict(ok=False, status=f"{type(ex).__name__}: {ex}"[:300])

def digest(J, G): return hashlib.sha256(b"".join(np.ascontiguousarray(J[c][G.sl]).tobytes() for c in range(3))).hexdigest()

SAN4 = r"""
import sys, json, importlib.util, numpy as np, cupy as cp
cp.cuda.set_allocator(None)
spec = importlib.util.spec_from_file_location("t", sys.argv[1]); K = importlib.util.module_from_spec(spec); spec.loader.exec_module(K)
launch = getattr(K, [n for n in dir(K) if n.startswith("launch_")][0])
cases = json.load(open(sys.argv[2])); rng = np.random.default_rng(2040)
for (nr, nphi, nz, g, r0, dr, dz, dtn, mode) in cases:
    dt = np.float32 if dtn == "float32" else np.float64; dphi = 2*np.pi/nphi
    rf = (r0 + (np.arange(nr + 1 + 2*g) - g)*dr).astype(dt); rc = (r0 + (np.arange(nr + 2*g) - g + 0.5)*dr).astype(dt)
    sh = [(nr + 1 + 2*g, nphi + 2*g, nz + 2*g), (nr + 2*g, nphi + 1 + 2*g, nz + 2*g), (nr + 2*g, nphi + 2*g, nz + 1 + 2*g)]
    B = [rng.uniform(-1, 1, s).astype(dt) for s in sh]
    if mode == "poison_pad":
        for b in B: b[0, :, :] = np.nan; b[-1, :, :] = np.nan
    if mode == "scaled":
        B = [b*dt(2.0**(30 if dt is np.float32 else 400)) for b in B]
    dB = [cp.asarray(b) for b in B]; J = [cp.full((nr + 2*g, nphi + 2*g, nz + 2*g), np.nan, dt) for _ in range(3)]
    launch(*dB, *J, cp.asarray(rf), cp.asarray(rc), dr, dphi, dz, nr, nphi, nz, g)
    cp.cuda.Device().synchronize()
print("SANITIZER_TARGET_DONE")
"""
def gpu_sanitizer4(cases):
    san = C.find_sanitizer()
    if san is None: return dict(status="BLOCKED", note="compute-sanitizer not found (install the CUDA toolkit or add its bin directory to PATH)")
    script = os.path.join(C.SCRATCH, "gpu_san4_target.py"); open(script, "w").write(SAN4); cj = os.path.join(C.SCRATCH, "gpu_san4_cases.json"); json.dump(cases, open(cj, "w"))
    out = dict(status="RAN", tool=san, seed=2040, cases=len(cases), runs={})
    for tool in ("memcheck", "initcheck", "racecheck", "synccheck"):
        try:
            p = subprocess.run([san, "--tool", tool, "--error-exitcode", "99", sys.executable, script, C.KPATH, cj], capture_output=True, text=True, timeout=1800); text = p.stdout + p.stderr
            m = re.search(r"ERROR SUMMARY: (\d+) error", text)
            out["runs"][tool] = dict(returncode=p.returncode, error_summary=int(m.group(1)) if m else None, target_done="SANITIZER_TARGET_DONE" in text,
                                     clean=bool(p.returncode == 0 and "SANITIZER_TARGET_DONE" in text and (m is None or int(m.group(1)) == 0)),
                                     excerpt=[l for l in text.splitlines() if "Invalid" in l or "Uninitialized" in l or "ERROR" in l or "Error" in l][:6])
        except Exception as ex: out["runs"][tool] = dict(clean=False, error=f"{type(ex).__name__}: {ex}"[:300])
    return out

def t039(be):
    res = dict(grids=[]); fails = []; raw = H.backend_for(be); host = C.HostBackend() if be.name != "host" else be; rng = np.random.default_rng(TOL4["seeds"]["t039"])
    gpu = be.name == "cupy"; cases4 = []
    res["backend_executes_on"] = "NVIDIA GPU (CuPy RawKernel)" if gpu else "HOST CPU path (g++-compiled copy of the CUDA source): NOT GPU evidence"
    if gpu:
        try:
            import cupy as cp
            res["device"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode()
            s0 = cp.cuda.Stream(non_blocking=True)
        except Exception as ex: fails.append(f"cannot query the device: {ex}")
    for mode, lst in (("annulus", AWK_ANNULUS), ("axis", AWK_AXIS)):
        for (nr, nphi, nz, g, r0) in lst:
            reach, rm = reach_for(raw, mode, g)
            if rm: fails.append(f"{mode} g={g}: kernel dependency footprint differs from the independent reference for {len(rm)} entries")
            for dt in (F64, F32):
                dr = 0.1 + 0.013*(nr % 3); dz = 0.07 + 0.01*(nz % 4)
                G = C.Grid(nr, nphi, nz, g=g, r0=r0, r1=r0 + nr*dr, z0=0.0, z1=nz*dz); row = dict(mode=mode, grid=[nr, nphi, nz], g=g, r_min=r0, dtype=dn(dt))
                B = H.random_B(G, dt, rng)
                try: K.validate_inputs(*B, *[np.zeros((nr + 2*g, nphi + 2*g, nz + 2*g), dt) for _ in range(3)], G.rf.astype(dt), G.rc.astype(dt), G.dr, G.dphi, G.dz, nr, nphi, nz, g)
                except K.CurlContractError as ex: row["rejected_by_validator"] = str(ex)[:100]; row["ok"] = True; res["grids"].append(row); continue
                cases4.append([nr, nphi, nz, g, r0, dr, dz, dn(dt), "plain"])
                J, gd = H.guarded_run(be, G, B, dt); row.update(gd)
                ref = H.ref_any(G, [b.astype(F64) for b in B]); sc = max(max(nmax(r) for r in ref), 1e-300)
                tolr = H.TOL2["equiv_fp64"] if dt is F64 else C.fp32_bound(G, 1.0)/sc
                row["rel_diff_vs_reference"] = max(nmax(J[c][G.sl].astype(F64) - ref[c]) for c in range(3))/sc; row["tol"] = tolr; row["finite"] = bool(all(np.isfinite(J[c][G.sl]).all() for c in range(3)))
                # repeated launches: bitwise identical, also with a hostile pre-fill of the output buffers
                d0 = digest(J, G); dig = []
                for k in range(TOL4["repeat_launches"]):
                    Jk = G.run(raw, B, dt); dig.append(digest(Jk, G) == d0)
                shp = (nr + 2*g, nphi + 2*g, nz + 2*g)
                for fill in (np.nan, 1e30, -7.5):
                    Jf = G.run(raw, B, dt, J=[np.full(shp, fill, dtype=dt) for _ in range(3)]); dig.append(digest(Jf, G) == d0)
                row["repeat_bitwise_identical"] = bool(all(dig)); row["launches"] = len(dig) + 1
                # adversarial padding: NaN in every B entry the stencil never reads -> outputs bitwise unchanged
                um = unused_mask(G, reach); Bp = [b.copy() for b in B]
                for c in range(3): Bp[c][um[c]] = np.nan
                Jp = G.run(raw, Bp, dt); row["unused_padding_entries"] = int(sum(m.sum() for m in um)); row["padding_nan_changes_output"] = bool(digest(Jp, G) != d0)
                # required entry poisoned: must NOT silently stay finite
                Bq = [b.copy() for b in B]; ci = (G.g + G.nr//2, G.g + G.nphi//2, G.g + G.nz//2)
                Bq[2][ci] = np.nan; Jq = G.run(raw, Bq, dt); row["required_nan_propagates"] = bool(nonfinite_mask_any(Jq, G).any())
                # power-of-two scaling is exact in IEEE arithmetic: J(2^k B) == 2^k J(B) bitwise
                kk = 40 if dt is F32 else 500; Bs = [(b*dt(2.0**kk)).astype(dt) for b in B]; Js = G.run(raw, Bs, dt)
                row["pow2_scaling_bitwise"] = bool(all(np.array_equal(Js[c][G.sl], (J[c][G.sl]*dt(2.0**kk)).astype(dt)) for c in range(3)))
                cases4.append([nr, nphi, nz, g, r0, dr, dz, dn(dt), "poison_pad"]); cases4.append([nr, nphi, nz, g, r0, dr, dz, dn(dt), "scaled"])
                if gpu:
                    Jh = G.run(host, B, dt); row["gpu_vs_host_rel_diff"] = max(nmax(J[c][G.sl].astype(F64) - Jh[c][G.sl].astype(F64)) for c in range(3))/sc
                    import cupy as cp
                    with s0:
                        Jstream = G.run(raw, B, dt)
                    s0.synchronize(); row["stream_launch_bitwise_identical"] = bool(digest(Jstream, G) == d0)
                    ec = gpu_error_check(); row["device_error_check"] = ec["status"]
                    if not ec["ok"]: fails.append(f"{mode} {row['grid']} {dn(dt)}: explicit CUDA error check failed: {ec['status']}")
                row["ok"] = bool(row["canary_intact"] and row["inputs_unchanged"] and row["ghost_layers_untouched"] and row["all_active_cells_written"] and row["finite"]
                                 and row["rel_diff_vs_reference"] <= tolr and row["repeat_bitwise_identical"] and not row["padding_nan_changes_output"] and row["required_nan_propagates"]
                                 and row["pow2_scaling_bitwise"] and (not gpu or (row["gpu_vs_host_rel_diff"] <= tolr and row["stream_launch_bitwise_identical"])))
                if not row["ok"]: fails.append(f"{mode} {row['grid']} g={g} {dn(dt)}: " + str({k: row[k] for k in row if k not in ('grid', 'g', 'mode', 'dtype', 'r_min') and (row[k] is False or k in ('rel_diff_vs_reference', 'gpu_vs_host_rel_diff'))}))
                res["grids"].append(row)
    res["reach_tables"] = {f"{m}_g{g}": _REACH_CACHE[(m, g)][0] for (m, g) in _REACH_CACHE}
    if not gpu:
        asan = []
        for mode, lst in (("annulus", AWK_ANNULUS), ("axis", AWK_AXIS)):
            for (nr, nphi, nz, g, r0) in lst:
                r = C.asan_run(nr, nphi, nz, g, 2 if mode == "axis" else 0)
                asan.append(dict(grid=[nr, nphi, nz], g=g, mode=mode, clean=bool(r["clean"]), error=r["error"]))
                if not r["clean"]: fails.append(f"AddressSanitizer {mode} {[nr, nphi, nz]} g={g}: {r['error']}")
        res["host_addresssanitizer"] = asan
        res["scope_note"] = "Host leg: the same adversarial suite on the CPU-compiled copy of the kernel + AddressSanitizer. It is NOT a GPU PASS; the real-GPU evidence is the cupy leg."
    else:
        san2 = H.gpu_sanitizer2(); san4 = gpu_sanitizer4(cases4); res["compute_sanitizer_campaign02_cases"] = san2; res["compute_sanitizer_campaign04_cases"] = san4
        for tag, san in (("campaign02 cases", san2), ("campaign04 adversarial cases", san4)):
            if san["status"] == "BLOCKED": res["block_reason"] = san["note"]
            else:
                for tool, r in san["runs"].items():
                    if not r.get("clean"): fails.append(f"compute-sanitizer {tool} ({tag}) reported problems or did not complete")
    res["verdict"] = "FAIL" if fails else ("BLOCKED" if res.get("block_reason") else "PASS"); res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 040  Full pathology regression: randomized hostile families, reproducibility, re-run of the earlier weaknesses
# ============================================================================
def hostile_cases(G, dt, rng):
    """families of hostile inputs on one grid; each entry: name -> (B, optional checker(J) -> list of failure strings)"""
    out = {}
    out["random"] = (H.random_B(G, dt, rng), None)
    out["smooth analytic"] = (G.sample(H.FIELD["SMOOTH"], dt), None)
    uni = cart_field("uniform Bx", (lambda x, y, z: 1.0 + 0*x, Z0, Z0, Z0, Z0, Z0)); out["uniform Cartesian Bx (truncation-limited, no zero claim)"] = (G.sample(uni, dt), None)
    uz = cart_field("uniform Bz", (Z0, Z0, lambda x, y, z: 1.0 + 0*x, Z0, Z0, Z0)); out["uniform axial Bz (exact zero current)"] = (G.sample(uz, dt), "uniform")
    if G.nphi % 2 == 0:
        for k, v in T3.null_mode_fields(G, dt, rng).items(): out["checkerboard: " + k] = (v, "null")
    out["huge amplitude 2^k"] = ([ (b*dt(2.0**(60 if dt is F32 else 600))).astype(dt) for b in H.random_B(G, dt, rng)], None)
    out["tiny amplitude 2^-k"] = ([ (b*dt(2.0**(-60 if dt is F32 else -600))).astype(dt) for b in H.random_B(G, dt, rng)], None)
    B = H.random_B(G, dt, rng); B = [(b*dt(1e-3)).astype(dt) + a for b, a in zip(B, G.sample(uni, dt))]; out["near-uniform + small noise (cancellation)"] = (B, None)
    shp = SHAPES(G); Bz = np.zeros(shp[2]); Bz[:] = (np.arange(shp[2][0]) > shp[2][0]//2).astype(float)[:, None, None]
    out["step in Bz(r) (grid-aligned current sheet)"] = ([np.zeros(shp[0], dt), np.zeros(shp[1], dt), Bz.astype(dt)], "sheet")
    out["helical kink"] = (G.sample(cart_field("kink", spec_helical(0.3, 0.7)), dt), None)
    return out

def regression_pass(be, seed):
    raw = H.backend_for(be); rng = np.random.default_rng(seed); rows = []
    grids = H.random_grids(n=10, seed=2040)
    for sp in grids:
        dt = sp["dtype"]; g = sp["g"]
        G = C.Grid(sp["nr"], sp["nphi"], sp["nz"], g=g, r0=sp["r0"], r1=sp["r0"] + sp["nr"]*sp["dr"], z0=0.0, z1=sp["nz"]*sp["dz"]); axis = sp["r0"] == 0.0
        probe = H.random_B(G, dt, rng)
        try: K.validate_inputs(*probe, *[np.zeros((G.nr + 2*g, G.nphi + 2*g, G.nz + 2*g), dt) for _ in range(3)], G.rf.astype(dt), G.rc.astype(dt), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, g)
        except K.CurlContractError as ex: rows.append(dict(grid=[G.nr, G.nphi, G.nz], g=g, dtype=dn(dt), rejected_by_validator=str(ex)[:90], ok=True)); continue
        for name, (B, kind) in hostile_cases(G, dt, rng).items():
            B = per_fill(B, G) if kind == "null" or kind == "sheet" else B
            row = dict(grid=[G.nr, G.nphi, G.nz], g=g, mode="axis" if axis else "annulus", dtype=dn(dt), family=name)
            with np.errstate(all="ignore"):
                J = G.run(raw, B, dt); ref = H.ref_any(G, [b.astype(F64) for b in B])
            Ji_ = [np.asarray(J[c][G.sl], dtype=F64) for c in range(3)]
            fin_in = all(bool(np.isfinite(b).all()) for b in B); fin_out = all(bool(np.isfinite(j).all()) for j in Ji_); fin_ref = all(bool(np.isfinite(r).all()) for r in ref)
            row.update(inputs_finite=fin_in, output_finite=fin_out, reference_finite=fin_ref, digest=digest(J, G))
            sc = max(max(nmax(r) for r in ref if np.isfinite(r).all()) if fin_ref else 0.0, 1e-300)
            tolr = H.TOL2["equiv_fp64"] if dt is F64 else C.fp32_bound(G, max(bmax_of(B), 1e-300) if np.isfinite(bmax_of(B)) else 1.0)/sc
            if fin_out and fin_ref: row["rel_diff_vs_reference"] = max(nmax(Ji_[c] - ref[c]) for c in range(3))/sc; row["tol"] = tolr; row["agrees"] = bool(row["rel_diff_vs_reference"] <= tolr)
            else: row["agrees"] = bool(fin_out == fin_ref)
            row["silent_nonfinite"] = bool(fin_in and not fin_out and fin_ref)          # kernel overflowed where the reference did not
            row["classification"] = "ok" if (row["agrees"] and not row["silent_nonfinite"]) else "UNCLASSIFIED"
            if kind == "null":
                bm = bmax_of(B); row["null_max_abs_J"] = max(nmax(j) for j in Ji_); inv = bool(row["null_max_abs_J"] <= tol_alg(dt, bm/hmin_of(G)))
                if axis: row["axis_pattern_visible"] = not inv       # invisibility is only claimed (and tested) for annulus grids; axis behaviour is characterised by Test 032
                else: row["null_invisible"] = inv
            if kind == "uniform":
                row["uniform_max_abs_J"] = max(nmax(j) for j in Ji_); tolu = tol_alg(dt, 1.0/hmin_of(G))*(8 if axis else 1); row["uniform_zero"] = bool(row["uniform_max_abs_J"] <= tolu)
            if kind == "sheet":
                Bz_ = np.asarray(B[2][:, 0, 0], dtype=F64); Jp = Ji_[1][:, 0, 0]; ex_ = -0.5*(Bz_[G.g + G.nr] + Bz_[G.g + G.nr - 1] - Bz_[G.g] - Bz_[G.g - 1]); got = float(np.sum(Jp)*G.dr)
                row["sheet_integral_err"] = abs(got - ex_); row["sheet_integral_ok"] = bool(abs(got - ex_) <= tol_alg(dt, max(1.0, G.rf[G.g + G.nr])/G.dr))
                if axis: row["sheet_integral_ok"] = True; row["sheet_integral_err"] = None         # axis mode: Jphi radial identity not claimed (different near-axis stencil)
            rows.append(row)
    return rows

def t040(be):
    res = dict(); fails = []; seed = TOL4["seeds"]["t040"]; host = C.HostBackend() if be.name != "host" else be
    rows1 = regression_pass(be, seed); rows2 = regression_pass(be, seed)
    res["rows"] = rows1; res["families"] = sorted({r["family"] for r in rows1 if "family" in r}); res["cases"] = len([r for r in rows1 if "family" in r])
    rep = [(a.get("digest") == b.get("digest")) for a, b in zip(rows1, rows2)]
    res["reproducible_bitwise"] = bool(all(rep) and len(rows1) == len(rows2)); res["reproducibility_cases"] = len(rep)
    if not res["reproducible_bitwise"]: fails.append("two passes with the same seed produced different output digests")
    for r in rows1:
        if "family" not in r: continue
        tag = f"{r['mode']} {r['grid']} g={r['g']} {r['dtype']} '{r['family']}'"
        if r["classification"] != "ok": fails.append(f"{tag}: UNCLASSIFIED behaviour (agrees={r['agrees']}, silent_nonfinite={r['silent_nonfinite']}, inputs_finite={r['inputs_finite']}, output_finite={r['output_finite']}, reference_finite={r['reference_finite']})")
        if r.get("null_invisible") is False: fails.append(f"{tag}: checkerboard produced visible current {r['null_max_abs_J']:.2e}")
        if r.get("uniform_zero") is False: fails.append(f"{tag}: uniform field produced current {r['uniform_max_abs_J']:.2e}")
        if r.get("sheet_integral_ok") is False: fails.append(f"{tag}: integrated sheet current identity violated ({r['sheet_integral_err']:.2e})")
        if not r["inputs_finite"]: fails.append(f"{tag}: harness produced non-finite inputs")
    if be.name == "cupy":
        rh = regression_pass(host, seed); mism = 0
        for a, b in zip(rows1, rh):
            if "family" not in a: continue
            if a.get("digest") != b.get("digest"): mism += 1
        res["gpu_vs_host_identical_digests"] = len(rows1) - mism; res["gpu_vs_host_differing_digests"] = mism
        # value agreement (digests may differ by FMA contraction): compare against the SAME independent reference was already done per row
    # re-run of the earlier weaknesses (each sub-suite keeps its own verdict and fail reasons; nothing is dropped)
    subs = {}
    for tag, fn in (("Campaign 03 / 025 constant-field nullspace", T3.t025), ("Campaign 03 / 029 extreme cancellation", T3.t029), ("032 odd-even nullspace attack", t032),
                    ("035 ghost-cell poisoning", t035), ("036 cylindrical metric stress", t036), ("031 axis singularity torture", t031)):
        r = H.safe(fn, be); subs[tag] = dict(verdict=r.get("verdict"), fail_reasons=r.get("fail_reasons", [])[:5], error=r.get("error"))
        if r.get("verdict") != "PASS": fails.append(f"re-run of '{tag}': {r.get('verdict')} {r.get('fail_reasons', [])[:2]}")
    res["weakness_reruns"] = subs
    res["unclassified"] = [r for r in rows1 if r.get("classification") == "UNCLASSIFIED"]
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res


# ============================================================================
# findings, development log, numerical pathology register, driver
# ============================================================================
FINDINGS = [
 dict(id="G1", title="Axis reconstruction converges to the analytic Cartesian curl", detail="For Cartesian-regular modes m = 0..3 the current matches the analytic Cartesian curl at second order globally, on the first physical ring (in absolute error) and in the fixed interior region; the phi-averaged ring-0 current converges to the analytic on-axis current."),
 dict(id="G2", title="Odd-even structures are invisible; the kernel is not a grid-scale detector", detail="Many alternating B patterns produce exactly zero current (about a quarter of the unknowns lie in the null space of the operator). Any claim that the kernel detects all grid-scale structure is falsified. The pattern's only effect on the current is round-off at the eps*a/h level."),
 dict(id="G3", title="Dynamic range: wide safe window, silent trouble only outside it", detail="Inside the observed safe binary-exponent window results agree with the exact rational evaluation; outside it overflow / underflow / subnormal results appear. Subnormal-range results are finite but wrong: the kernel does no range checking."),
 dict(id="G4", title="Cancellation is truncation-limited, not round-off-limited", detail="For nearly curl-free fields the recoverable signal is lost when A*c*h^2 reaches |J| (truncation); FP32 round-off becomes the limit only at very large background amplitudes."),
 dict(id="G5", title="Ghost contract measured, not assumed", detail="The dependency footprint (entry-by-entry NaN poisoning) equals the independent stencil reference; padding the kernel never reads is inert (bitwise); non-finite required inputs propagate to exactly the dependent cells; finite but adversarial ghost values give finite wrong currents and the launcher validator does not inspect B."),
 dict(id="G6", title="Metric stress: accuracy follows the conditioning bound", detail="Exact-for-the-operator fields are reproduced to 64*eps*Bmax*kappa on extreme aspect ratios, tiny radii and large radii; FP32 relative accuracy degrades like eps*kappa. A curl-free vortex Bphi = 1/r gives a large spurious Jz in the first cells when r0/dr is small."),
 dict(id="G7", title="Kink / harmonic reconstruction", detail="Amplitude and phase of the reconstructed azimuthal harmonics converge at second order (scaled by a fixed-radius amplitude); other harmonics are excited only by truncation of the multi-harmonic input, converging at second order. At the first axis ring the RELATIVE error of m>=2 harmonics does not converge because the true harmonic vanishes like r^(m-1): absolute error converges."),
 dict(id="G8", title="Current sheets: integral identities exact, pointwise convergence impossible", detail="The integrated sheet current equals the discrete telescoping sum of the stored boundary values to round-off; a monotone step gives no opposite-sign current and a current confined to <= 3 cells with peak ~ B0/(2h); only the weak (test-function) integral converges (order ~2 grid-aligned, ~1 offset)."),
 dict(id="G9", title="Execution hygiene on awkward shapes", detail="Prime / minimal dimensions, g = 1..3, FP32/FP64: no writes outside the outputs (canaries), inputs immutable, ghost layers of J untouched, repeated launches and hostile output pre-fills bitwise identical, IEEE power-of-two scaling bitwise exact."),
]

DEV_LOG = [
 dict(phase="development run 1", item="Test 035 required-ghost mask", observation="the draft counted padding entries that are inside the stencil footprint as unused, so some 'unused padding' poison runs reported contamination", resolution="required entries are now defined by the measured footprint (entry-by-entry NaN scan matched against the independent reference); padding = entries outside the measured reach (harness defect, no kernel change)"),
 dict(phase="development run 1", item="Test 034 amplitude grid", observation="the first sweep (1e-3..1e10 in decades) did not bracket the transition between recoverable and unrecoverable on the coarse grids", resolution="added background amplitudes 3, 10 and 30 (FP32: capped at 1e8 to stay in range); threshold reporting now uses the first unrecoverable amplitude of the declared sweep"),
 dict(phase="development run 1", item="Test 037 leakage bound", observation="draft required leakage into non-dominant azimuthal harmonics to be at round-off. Measured 3.9e-3 -> 6.7e-5 (order ~2) for the helical kink", resolution="wrong expectation: the INPUT field contains harmonics +-1 and the O(h^2) truncation of the m = +-1 content lands in neighbouring harmonics of J. Rule now: leakage within the round-off bound OR converging at the declared order"),
 dict(phase="development run 1", item="Test 037 first-ring relative metric", observation="m = 2, 3, 4 on axis grids: relative amplitude/phase error at the first physical ring did not converge (orders ~0) although the absolute error converged at order 2 (e.g. m = 3: 1.3e-2, 3.4e-3, 8.6e-4, 2.2e-4)", resolution="the true harmonic vanishes like r^(m-1) at the first ring, faster than the O(h^2) truncation, so any relative metric stays O(1). Pass criterion now uses errors scaled by the mid-ring amplitude (fixed scale); the relative first-ring numbers are kept and flagged as a LIMITATION in the register (not hidden)"),
 dict(phase="development run 1", item="Test 038 weak-order sign", observation="reported weak orders of -2.0 and -1.06", resolution="sign error of the log-log fit in the harness (errors fell with h as expected); corrected, measured orders ~2.0 (face aligned) and ~1.06 (offset)"),
 dict(phase="development run 1", item="Test 038 integral identity for smoothed sheets", observation="identity violated at 1.7e-5 for the tanh profile", resolution="the exact discrete identity is the telescoping sum of the STORED boundary values, not the continuum jump (the tanh plateaus are not exactly 0 / B0); the identity now uses the stored values; the continuum residual is recorded separately (informational)"),
 dict(phase="external review", item="Test 036 vacuous bound", observation="reviewer (ChatGPT) noted FP32 rows with 16.8% relative error marked PASS; checking showed the bound 64*eps*Bmax*kappa = 6.1 exceeds the true current (0.8) at r0 = 1e5, so the check could not fail", resolution="added declared criterion disc_fraction = 0.5: a bound demonstrates accuracy only if <= 0.5*|J|; other rows are labelled NON-DISCRIMINATING, reported with observed errors, and moved to a separate INCONCLUSIVE register entry (P19); register P12 now counts discriminating rows only. No kernel change"),
 dict(phase="development run 1", item="Test 040 uniform-field family", observation="a uniform Cartesian Bx field gave currents up to 1.4e-1 on coarse grids", resolution="wrong expectation: its discrete curl is O(h^2) truncation, not zero. The exact-zero claim of Campaign 03 concerns a constant axial Bz; that is now the 'zero current' family and uniform Bx is only compared with the independent reference"),
 dict(phase="development run 1", item="Test 040 checkerboard family on axis grids", observation="'Br alternating on r-faces' on an axis grid produced a visible current of 4.6e1", resolution="the pattern builders of Campaign 03 are documented for annulus mode; on axis grids the axis stencil does not annihilate them (consistent with 12 visible patterns of Test 032). Invisibility is claimed and asserted for annulus grids only; axis visibility is recorded"),
]

def _g(results, tid, be="host"): return results["tests"].get(tid, {}).get(be, {})

def build_register(results):
    """numerical pathology register - every entry is computed from the measured data in `results`"""
    R = []; add = lambda **k: R.append(k)
    def ok(tid): return all(_g(results, tid, b).get("verdict") == "PASS" for b in ("host", "cupy"))
    t31 = _g(results, "031"); 
    if t31.get("fields"):
        oo = [f[k]["orders"][-1] for f in t31["fields"] for k in ("global", "ring0", "region") if not f[k]["at_round_off_floor"]]
        add(id="P01", cls="VERIFIED", test="031", title="Axis reconstruction vs analytic Cartesian curl (m = 0..3)", evidence=f"{len(t31['fields'])} Cartesian-regular fields; smallest last-pair order outside the round-off floor = {min(oo):.2f} (declared >= {TOL4['order_min']}); first physical ring included", restriction="Smooth Cartesian-regular fields on tested grids (axis mode, g >= 2); no claim for non-regular fields")
    t37 = _g(results, "037")
    if t37.get("cases"):
        add(id="P02", cls="VERIFIED", test="037", title="Phase / amplitude of reconstructed azimuthal harmonics", evidence=f"{len(t37['cases'])} case x mode x ring rows; scaled amplitude and phase errors converge at >= {TOL4['kink_amp_order']} (or sit at round-off); leakage into other harmonics at round-off or converging", restriction="Tested helical (m=1, eps 0.01 and 0.3) and modulated m = 1..4 fields")
        lim = t37.get("ring0_relative_limitations", [])
        add(id="P03", cls="LIMITATION", test="037", title="First axis ring: relative error of m >= 2 harmonics does not converge", evidence=f"{len(lim)} (case, quantity) rows: absolute error converges at second order but the true harmonic vanishes like r^(m-1)", restriction="Do not use relative first-ring accuracy of m >= 2 currents as a diagnostic; use absolute (fixed-scale) errors. This PASS characterises the limitation, it does not remove it")
    t32 = _g(results, "032")
    if t32.get("patterns"):
        add(id="P04", cls="LIMITATION", test="032", title="Odd-even (checkerboard) structures are invisible to J = curl B", evidence=f"{t32['n_invisible']} of {t32['n_patterns']} pattern/mode/dtype combinations produce no current; claim 'detects all grid-scale structure' = {t32['claim_all_gridscale_detected']['holds']}; nullity of influencing unknowns up to {max(r['nullity_fraction'] for r in t32['operator_rank'])*100:.0f}%", restriction="The kernel cannot detect or damp grid-scale odd-even B content; the driver (CT update / divergence cleaning / filtering) must control it. The PASS documents the limitation; it is NOT evidence that it is eliminated")
        add(id="P05", cls="VERIFIED", test="032", title="Perturbing a base field with a null pattern only adds round-off", evidence=f"{sum(1 for c in t32['contamination'] if c['within_bound'])}/{len(t32['contamination'])} perturbation rows within eps*a/h; critical amplitude where it would matter: {t32['critical_amplitude']}", restriction="Applies to the tested base fields and amplitudes")
    t33 = _g(results, "033")
    if t33.get("rows"):
        rng = {be: _g(results, "033", be).get("safe_range_observed") for be in ("host", "cupy") if _g(results, "033", be).get("rows")}
        add(id="P06", cls="VERIFIED", test="033", title="Dynamic range inside the declared safe window", evidence=f"observed safe binary-exponent ranges {rng}; rows inside the declared window: {sum(1 for r in t33['rows'] if r['in_declared_safe_range'])}, of which OK against the exact rational evaluation: {sum(1 for r in t33['rows'] if r['in_declared_safe_range'] and r['classification'] == 'OK')}", restriction="Declared windows: FP64 %s, FP32 %s" % (TOL4["safe_k_fp64"], TOL4["safe_k_fp32"]))
        sw = {be: len(_g(results, "033", be).get("silent_wrong_finite_rows", [])) for be in rng}
        add(id="P07", cls="LIMITATION", test="033", title="Outside the safe window: overflow, underflow and SILENT finite-but-wrong (subnormal) currents", evidence=f"classification counts {t33.get('classification_counts')}; silent wrong finite rows per backend {sw}", restriction="The kernel does no range check; the driver must keep |B| inside the observed window (or normalise). Zero input gives exactly zero")
    t34 = _g(results, "034")
    if t34.get("rows"):
        rb = all(r["roundoff_err_vs_exact"] <= r["roundoff_bound"] for r in t34["rows"] if r.get("roundoff_bound") is not None)
        add(id="P08", cls="VERIFIED", test="034", title="Round-off error vs exact rational evaluation within the declared bound", evidence=f"{len(t34['rows'])} rows; all within bound = {rb}", restriction="Tested amplitudes / grids only")
        mr = t34["minimum_recoverable"]
        add(id="P09", cls="LIMITATION", test="034", title="Cancellation: physical signal becomes unrecoverable beyond a background amplitude", evidence="; ".join(f"{k}: recoverable up to A={v['largest_recoverable_background_amplitude']:g}, lost at A={v['first_unrecoverable_amplitude']:g}" + (f", round-off alone would lose it at A={v['first_amplitude_unrecoverable_by_roundoff_alone']:g}" if v['first_amplitude_unrecoverable_by_roundoff_alone'] else "") for k, v in mr.items()), restriction="Limit is set by truncation A*c*h^2 (moves as h^-2); FP32 round-off matters only for the largest amplitudes. A loose tolerance would hide the lost information, so none is used")
    t35 = _g(results, "035")
    if t35.get("grids"):
        add(id="P10", cls="VERIFIED", test="035", title="Ghost dependency footprint and inertness of unused padding", evidence=f"footprint mismatches vs independent reference = {sum(g_['footprint_mismatches_vs_independent_reference'] for g_ in t35['grids'])}; unused padding poison bitwise inert in all {sum(len(g_['unused_padding_poison']) for g_ in t35['grids'])} poison runs; non-finite required ghosts propagate exactly to their dependent cells", restriction="Measured for g = 2, 3, annulus and axis on the tested block sizes")
        add(id="P11", cls="LIMITATION", test="035", title="Finite but adversarial ghost values give silent wrong currents; B content is not validated", evidence=f"validator rejects bad coordinates / spacings ({len(t35['validator'])} cases) but B_content_not_inspected = {t35.get('B_content_not_inspected')}", restriction="The caller owns ghost / boundary correctness; NaN/Inf in required inputs propagate (not silent), finite garbage does not")
    t36 = _g(results, "036")
    if t36.get("rows"):
        nd = [r for r in t36["rows"] if not r.get("discriminating", True)]; dd = [r for r in t36["rows"] if r.get("discriminating", True) and "rejected_by_validator" not in r]
        add(id="P12", cls="VERIFIED", test="036", title="Metric stress: exact fields reproduced within a DISCRIMINATING conditioning-aware bound", evidence=f"{len(dd)} of {len(t36['rows'])} dtype x configuration rows have a bound <= {TOL4['disc_fraction']} x |J| and pass it; configurations (tiny r0, r0/dr up to {max(r['r0_over_dr'] for r in t36['rows']):.1e}, aspect ratios up to {max(max(r['aspect_rdphi_over_dr'], r['aspect_dz_over_dr']) for r in t36['rows']):.0e}); all within 64*eps*Bmax*kappa", restriction="Only the discriminating rows count as demonstrated accuracy; random fields agree with the independent reference")
        add(id="P19", cls="INCONCLUSIVE", test="036", title="Accuracy claim NOT demonstrated where the round-off bound exceeds half the signal", evidence=f"{len(nd)} rows (e.g. " + "; ".join(f"{r['dtype']} '{r['case'][:24]}': bound/|J| = {r['bound_over_signal']:.2g}, observed rel err {r['exact_field_rel_err']:.2e}" for r in sorted(nd, key=lambda r: -r['exact_field_rel_err'])[:4]) + "): the bound cannot fail there", restriction="A PASS on these rows only characterises the observed error. Do not read it as accuracy evidence; FP32 at large radius (r0/dr >~ 1e3) loses 1e-4..1e-1 relative accuracy")
        vt = t36.get("vortex_truncation", [])
        add(id="P13", cls="LIMITATION", test="036", title="FP32 relative accuracy ~ eps*kappa; 1/r vortex gives spurious Jz in the first cells when r0/dr is small", evidence=f"worst FP32 relative error {max((r['exact_field_rel_err'] for r in t36['rows'] if r['dtype'] == 'float32'), default=float('nan')):.2e} (case '{max((r for r in t36['rows'] if r['dtype'] == 'float32'), key=lambda r: r['exact_field_rel_err'])['case']}', kappa {max((r for r in t36['rows'] if r['dtype'] == 'float32'), key=lambda r: r['exact_field_rel_err'])['kappa']:.2e}); vortex spurious Jz {', '.join(f'{v['max_abs_Jz_spurious']:.3g}@r0/dr={v['r0_over_dr']}' for v in vt[:3])}", restriction="Keep kappa*eps below the accuracy needed; FP64 recommended for r0/dr << 1 or extreme aspect ratios; do not initialise curl-free singular profiles at the first cells")
    t38 = _g(results, "038")
    if t38.get("rows"):
        add(id="P14", cls="VERIFIED", test="038", title="Current sheets: integrated current, no overshoot, localisation, weak convergence", evidence=f"{len(t38['rows'])} direction/alignment/kind/dtype rows; integral identity holds to round-off in all; weak order (FP64 sharp) {', '.join((f'{r['weak_order_fit']:.2f}' if abs(r['weak_order_fit']) < 50 else 'round-off') for r in t38['rows'] if r.get('weak_order_fit') is not None)}", restriction="Monotone steps of Bz(r), Bphi(r), Br(z) on the tested grids")
        add(id="P15", cls="LIMITATION", test="038", title="No pointwise convergence across a discontinuity (peak current ~ B0/(2h))", evidence="peak*h/B0 stays O(1) under refinement; only the weak (test-function) integral converges", restriction="Never read point values of J inside a resolved-less sheet as physical; compare integrals")
    t39h = _g(results, "039", "host"); t39g = _g(results, "039", "cupy")
    if t39g.get("verdict") in ("PASS", "FAIL"):
        add(id="P16", cls="VERIFIED" if t39g["verdict"] == "PASS" else "DEFECT", test="039", title="Real-GPU adversarial suite with compute-sanitizer evidence", evidence=f"device {t39g.get('device', '?')}; {len(t39g['grids'])} grid x dtype rows; sanitizer tools clean: " + str({k: v.get('clean') for k, v in t39g.get('compute_sanitizer_campaign04_cases', {}).get('runs', {}).items()}), restriction="Tested awkward shapes, g = 1..3, FP32/FP64 only" if t39g["verdict"] == "PASS" else "unresolved FAIL on the GPU - see fail reasons")
    else:
        add(id="P16", cls="INCONCLUSIVE", test="039", title="GPU adversarial suite NOT executed in this run", evidence=f"cupy leg verdict {t39g.get('verdict', 'absent')}: {t39g.get('note', '')}. Host-side suite: {t39h.get('verdict')} ({len(t39h.get('grids', []))} rows + AddressSanitizer) - NOT a GPU PASS", restriction="Run on a GPU session (Colab) to obtain evidence")
    t40 = _g(results, "040", "cupy") if _g(results, "040", "cupy").get("verdict") in ("PASS", "FAIL") else _g(results, "040")
    if t40.get("rows"):
        add(id="P17", cls="VERIFIED" if t40.get("verdict") == "PASS" else "DEFECT", test="040", title="Randomized hostile-family regression: reproducible, no silent failures", evidence=f"{t40['cases']} cases over families {len(t40['families'])}; bitwise reproducible = {t40['reproducible_bitwise']}; unclassified = {len(t40['unclassified'])}", restriction="Seeded random grids (seed %d); not exhaustive" % TOL4["seeds"]["t040"])
        wr = t40.get("weakness_reruns", {})
        add(id="P18", cls="LIMITATION", test="040", title="Previously identified weaknesses re-exercised (F1-F7, Campaign 03 / 04): still present and still bounded", evidence="; ".join(f"{k}: {v['verdict']}" for k, v in wr.items()), restriction="Carried-over limitations: no exact discrete div(curl) = 0; first-order axis divergence; invisible null modes; cancellation limit; ghost ownership. The re-run characterises them, it does not remove them")
    fails = [(tid, be, v.get("verdict")) for tid, e in results["tests"].items() for be, v in e.items() if isinstance(v, dict) and v.get("verdict") in ("FAIL", "ERROR")]
    for tid, be, vd in fails: add(id=f"D-{tid}-{be}", cls="DEFECT", test=tid, title=f"Unresolved {vd} on {be}", evidence="; ".join(map(str, _g(results, tid, be).get("fail_reasons", [])[:3])) or str(_g(results, tid, be).get("error", ""))[:300], restriction="Open: needs triage (harness defect vs kernel defect); kernel stays frozen, a real defect needs a separately versioned fix and a rerun")
    return R

def _self_sha():
    for p in (globals().get("__file__"), sys.argv[0] if sys.argv else None, os.path.join(HERE, "campaign04.py"), os.path.join(os.getcwd(), "campaign04.py")):
        try:
            if p and os.path.isfile(p) and p.endswith(".py"): return hashlib.sha256(open(p, "rb").read()).hexdigest()
        except Exception: pass
    return "UNKNOWN (this harness file could not be located on disk; run it as `python campaign04.py`)"

def load_report_module():
    path = os.path.join(HERE, "make_report_campaign04.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location("make_report_mod04", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
    import base64, zlib, types
    if not _EMBEDDED_REPORT.strip(): return None
    mod = types.ModuleType("make_report_mod04")
    exec(zlib.decompress(base64.b64decode("".join(_EMBEDDED_REPORT.split()))).decode(), mod.__dict__)
    return mod

class Tee:
    def __init__(self, path, stream): self.f = open(path, "w", encoding="utf-8"); self.s = stream
    def write(self, x): self.s.write(x); self.f.write(x); return len(x)
    def flush(self): self.s.flush(); self.f.flush()
    def isatty(self): return False
    def close(self): self.f.close()

TESTS4 = [("031", "Axis singularity torture", t031), ("032", "Odd-even nullspace attack", t032), ("033", "Extreme magnetic dynamic range", t033), ("034", "Cancellation catastrophe", t034),
          ("035", "Ghost-cell poisoning", t035), ("036", "Cylindrical metric stress", t036), ("037", "Kink instability reconstruction", t037),
          ("038", "Discontinuity and current-sheet stress", t038), ("039", "GPU numerical adversarial suite", t039), ("040", "Full pathology regression", t040)]

def main():
    logpath = os.path.join(OUT, "campaign04_execution.log"); tee = Tee(logpath, sys.stdout); old = sys.stdout, sys.stderr; sys.stdout = tee; sys.stderr = Tee(logpath + ".err", old[1])
    try: return _main()
    finally: sys.stdout, sys.stderr = old; tee.close()

def _main():
    sha = C.SRC_SHA; ver = getattr(K, "VERSION", "?")
    print(f"Kernel file used: {os.path.basename(C.KPATH)} (v{ver})")
    print("=" * 78); print(f"ALADIN v4.0 - Campaign 04 | {C.STEM}.py v{ver} sha256 {sha[:16]}..."); print("=" * 78)
    frozen = bool(EXPECTED_SHA) and (sha == EXPECTED_SHA)
    if not frozen: print(f"!! WARNING: kernel sha256 {sha} (v{ver}) matches no registered version ({', '.join(f'v{k}' for k in KNOWN_SHA)}).\n   Campaign 04 certifies ONLY registered, frozen files; results below are for an UNREGISTERED source.")
    latest = max(KNOWN_SHA, key=lambda v: tuple(int(x) for x in v.split(".")))
    shas = dict(kernel=sha, campaign01=hashlib.sha256(open(C.__file__, "rb").read()).hexdigest(), campaign02=hashlib.sha256(open(H.__file__, "rb").read()).hexdigest(),
                campaign03=hashlib.sha256(open(T3.__file__, "rb").read()).hexdigest(), campaign04=_self_sha())
    print("Package check: uct_curl.py v%s sha %s | campaign01 %s | campaign02 %s | campaign03 %s | campaign04 %s" % (ver, sha[:12], shas["campaign01"][:12], shas["campaign02"][:12], shas["campaign03"][:12], shas["campaign04"][:12]))
    if ver != latest: print("!" * 78 + f"\n!! STALE PACKAGE: this run uses uct_curl.py v{ver} but the latest registered kernel is v{latest}.\n!! Delete the old files in this folder (rm -f *.py), unzip the newest zip again, and re-run.\n" + "!" * 78)
    host = C.HostBackend(); gpu_present = C.CupyBackend.available(); backends = [host] + ([C.CupyBackend()] if gpu_present else [])
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
               gxx=subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0], kernel_file=C.KPATH, kernel_sha256=sha, expected_sha256=EXPECTED_SHA,
               latest_registered_version=latest, source_frozen_and_matches=frozen, kernel_version=ver, campaign_harness_sha256=shas["campaign04"], campaign01_helper_sha256=shas["campaign01"],
               campaign02_helper_sha256=shas["campaign02"], campaign03_helper_sha256=shas["campaign03"], gpu_present=gpu_present, gpu_leg_status="executed" if gpu_present else "BLOCKED: no GPU/CuPy in this session",
               seeds=TOL4["seeds"])
    if gpu_present:
        try:
            import cupy as cp
            props = cp.cuda.runtime.getDeviceProperties(0)
            env.update(gpu=props["name"].decode(), cupy=cp.__version__, cuda_runtime=cp.cuda.runtime.runtimeGetVersion(), compute_capability=f"{props['major']}.{props['minor']}")
        except Exception: pass
        print(f"GPU detected: {env.get('gpu', '?')}  CuPy {env.get('cupy', '?')}")
    else: print("No GPU/CuPy detected: GPU legs will be BLOCKED.")
    results = dict(env=env, tolerances=TOL4, campaign03_tolerances=T3.TOL3, campaign02_tolerances=H.TOL2, campaign01_tolerances=C.TOL, findings=FINDINGS, dev_log=DEV_LOG, tests={})
    print("\n-- Campaign 04 tests --", flush=True)
    for tid, name, fn in TESTS4:
        entry = dict(name=name)
        for be in backends: entry[be.name] = H.safe(fn, be)
        if "cupy" not in entry: entry["cupy"] = dict(verdict="BLOCKED", note="no GPU/CuPy in this session")
        results["tests"][tid] = entry
        print(f"{tid} {name:38s} host={entry['host']['verdict']:8s} gpu={entry['cupy']['verdict']}", flush=True)
        for be_ in ("host", "cupy"):
            for fr in entry[be_].get("fail_reasons", [])[:6]: print(f"      [{be_}] {fr}")
            if entry[be_].get("verdict") == "ERROR": print(entry[be_].get("error"))
    if gpu_present:
        try:
            results["gpu_vs_host"] = H.gpu_only_cross_check(host, backends[1])
            print("\n-- GPU vs host agreement --")
            for q in results["gpu_vs_host"]: print(f"  {q['grid']} r_min={q['r_min']} {q['dtype']}: max diff {q['max_abs_diff']:.3e} (tol {q['tol']:.3e}) -> {'OK' if q['ok'] else 'MISMATCH'}")
        except Exception:
            results["gpu_vs_host_error"] = traceback.format_exc()[-1800:]; print(results["gpu_vs_host_error"])
    results["register"] = build_register(results)
    allpass = all(results["tests"][t]["host"]["verdict"] == "PASS" and results["tests"][t]["cupy"]["verdict"] == "PASS" for t in results["tests"])
    defects = [r for r in results["register"] if r["cls"] == "DEFECT"]
    results["certification"] = dict(rule="10/10 documented PASS on both backends, complete records, no unresolved critical defects; otherwise NOT CERTIFIED", all_pass_both_backends=bool(allpass), unresolved_defects=len(defects),
                                    verdict="CERTIFIED (harness verdict; independent source-level review pending)" if allpass and frozen and not defects else "NOT CERTIFIED")
    json.dump(results, open(os.path.join(OUT, "campaign04_results.json"), "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print("\nresults written:", os.path.join(OUT, "campaign04_results.json"))
    rep = load_report_module()
    if rep is None: print("report builder unavailable (results JSON is complete).")
    else:
        text = rep.build_report(results, OUT, "CAMPAIGN04_REPORT.md")
        print("report written:", os.path.join(OUT, "CAMPAIGN04_REPORT.md")); print("\n" + "=" * 78 + "\nCAMPAIGN 04 REPORT\n" + "=" * 78)
        C.show_markdown(text)
        try:
            from IPython import get_ipython
            if get_ipython() is not None:
                from IPython.display import display, Image
                for pth in getattr(rep, "PLOT_FILES", []): display(Image(filename=pth))
        except Exception: pass
    print("execution log written:", os.path.join(OUT, "campaign04_execution.log"))
    return results

_EMBEDDED_REPORT = """
eNq9fWl320bW5nf/CrzIB5EKSa1eIrVyjqLIabndtkdWes4MoxeGSJBCiwQZgNRiW/99nufeqkIB
BG13v+7J6ZaJQu11t7obfgi6m91gMBum2fggWC5G3RcseRKG4Xkyn+WL4GqZToZJHoxmeXD8+vjX
szfB7X5vOziJp/M4HWfB9n7QWiTFogi293a62/vb7V4QnMyyRR4PFgfaPsqls9Z5J7hO8qQTZPE0
aQfdn4NpnN8MZ3dZsEjuF0ErnhSz4C5PF4sERTOpvSWVe0/Og6MgT4rlBEMN08HC1bt6CAZmNtv7
vflD0CofI9Oi989ilnFmp7dJ/hBky+kVFpVikOsk0NlhG6ZJEYzy2TQ4P5QX83xWJEGxiLHA4O46
XgRJPLgOuNxgMInTaRHE2VDfpItgOEO1N28v9F0Pm/gknUrXs6KDpS6unzwZJqNg1LrvBPOjvfbB
kwD/paPgPkjRcpYlB5jMYplnQZhtxaG8XuQPWs/UTYs0w5SyQcJurmazSdu1KhZ56769vjbel5Xv
/XqcXS8tsjhDB94s4ixsqJZmo0o1PIe6jp+D7SCZYNfCLgv9tvfB0VGwXTbaLt+aolH46f6g92n+
mDxKd634qsA4wV+CnaS7FwAETcHPRyh52taRbKsfdx7Hj9pncj9I5ovgVP5JZ9lBfSSzUXIcMy5l
5SQ4Wqu6e6PJLF605cgr29VuOLWVrV9tXN/E5B4Yo60r+7E7wqp0ppO0WLTuC69RJwh7/5ylWYur
ECy9J1ijjqymMIch85I+FleT1nUSDztBPrsrzMKTYgDsmsTTq2EcDA5kewbtHhBjEmP64WeO88cf
n0OFrdlyger98HMQBj/i/5/tJNAP2sk0BpwGB2prFfbwWap/NpXDbrcbSt2oUvdzeCmj8I3gKCd6
wEF78XyeZMPW1wfO7ahtfz/DPzK7W8uFOf3bFujRVVJuadIbJ4vWFUo/PbbldwiaQYrDJXAj0fLd
7+fv3r4/xS58egJI3tsJD4Lw/XQ2W1yDNOagEGmcdfNkvJzEIJ5pMhkWQWuK+tu93h7AIE9Ib+b4
F/QjRSvSm+M3x6//z8XZSdlFMFjmkw5WNJgsSaSl2ijNQYDm1w9FOognQc5ywpWQrOu0G2O+8Rgd
8013m33kSbYI4nFMiJR6s6wb36ekX/HkYZEObKVe8NtkdhVjTBml6zofpffJEDi9SPIUu5zk+Swv
ZB2zHAwCoxUJlgNSOXk4RO0sXSQ8szlgJZ4QoTBalmBqQTwgWibDXtiRzdvl5ilhng2HXdTJQMOv
k8FNkl/N4hxgMY9B6nE4s1HwS94JfsEy8fdjMJP+JpNAFoMdvUqzmBhfcLg0+2cy4EDBWXYLhLua
JG4zuHZQ7MFyiifM/vXZ388uji/O3r4Be5phzsHL47PXygeEngcb/IkpZckkGCYL9FzI0OM8HXYL
nARZRb4cAIqSjWC6xE5f4bDA01IAACZBrhhPzQTJtmIwInRgFxcPh5gI2F5cHq6AjjvdPM5uuAdy
gnOc8oI0EWcwTeICww4PUTUQQoK6HAZdJLfxZKljmqbDtBgA2r0+7NkVQLZlNuzORiPlhFhQNpDG
9rT2eFoX6AVMdpIulsMk2P1vmVWsQBIUigc6dexzcUdijHVx7GQ4xihmIkIUCaRzICWnnI0Tou/L
d3u7Wy/fPds/kBNGtbtOgHnZn8XyKpvlUwK/8vdOMJkV0m0Bvo/9HpDuKuDGpIAfE/By2So9ukQ3
FSdb6PFUsOOrO2g3zm7KPjflTRLnkwdB2e4oTxKH96ABWNc4j4cpQe8qHtyMZZ9l19w2HoNmxdg9
ApUDAK4nnijFMPPwJrt62nkyAjZi8b3g+KqYTZY4ZkFWEPxkglq37lm77i5mXSnQPhyslfO6oxgm
ZdoCYK2y0jLL8YvUhpjVMm/BrbfBhaRPnbcKWJbSlRAmQzkAc0DoCMNTC2rDhHQfq3oAiZ8t5nmq
GGzBPsC2gnoApfRH6038JgBMQegDdCnXrZJbbFya2W4XQFx0nk4CyGuThBRBZnSIFS4LNJkDNUkI
MaT2arvBOFtn2WgrHmIXijhPsX4eUlIcYtV/LlMOOL6e4ag4szRRGHSdiDhASgFRc45DXVA4FiI5
B2BivydoRoLK3Z/E2CqcBUdIh4K3nFA+uyq37JnQ0vtFjlUEBDhMKC7miQURYAoQ7gEzKFKBBdYB
LRXqq3AaZ5lwLXkjM4wzTHeBGZJPJJNJ0QteKmg3UxOcdz4bLgdYrUAnkEIWCcEH4jM3DjgOQWOW
DVPuMylAfCeQ4mDjir8OSRKGIEMGk6SXeEzcckzTP0YH/IZuO0y8JfzdC98AD97Zyi3oEIZwLgMf
DjPgsaIAmIrd2Ofc2GPLLa+TiWDnTQqCLHx9Bxt7NyuxptDn+XVcJIVC4MfuFLsyEQSWJr3evlkZ
kPVjOl0urtHndZxPsScDRyWJZJmyFrR03JwE4V6uWSgF6P/68uLQw1rFaY4rc7DPHrPwtw5H1MLx
BR8DiHxZ0sbsZ5B9CG2y05MkvomFOIOOz6TczbMTxAtFKCMcOKEhXngCi7BovjKkPNjvTgDqQrLS
TLDObvYLEacwwDxoCXsFwI8tvgA6isSI0spqyDXjDOAAaClSZf+UFD628rYKC61c6/+Stz7iGnhC
4QIypcLPIhkL2QmK6yRZuA0G+oJ1VEEc0g1ETSACFlgsp/aECkA9D4EwGwORLAnIsFdzQbWkS+ro
+m6RahbXmHz7EKwLoJQWhuTcYaf1St0dASRZ2CaqoMGYoO3GlO2RKR8Gwj/v0iKp1swmDyITs/75
6fu3r/9x+mu5Z9LWbvlPAt93N0DDIdaL0yhkH1sgtlNCMwSXdErBMPuo4J7l/BcbPFZY3uuUfLsT
GOlyqORkic0GS45JASnOUipMpwD4+CoFvD50DJGcxA/YF8DHYrYEqeMtxaK04j2hhIXzRE7MkERM
k0OxC1BMK3bO86Q7SkGu2sFVqruTEtaJuR2SbooadQqfJfnCvXQkXGZcOCotQHx2enqKjb9LchCs
LpGdQiA7EaLXwT/AxQEVA8ltOrAYKIItZcysi/tHDOmFYmMST81iOsKploQY0N1FCskFFCaZSrst
ytX6C4if6K/iIRvIL0A2uaXuZCLsSiAFChRAqwjkqvE4efd7l6Ngs8gYoTPh9qWqvfjt3e+QNLhT
ECIUOva3CR3nQotTbheREpteJAlEVoAnhKvC8kR7CiPIuhNyvJYS8Y6BPKJ/Cqi0VL0T+LI+Hq+X
42RLuJRPTUmVu7blj9g/TKQTVKiDxS4B7E6FSAPNeELu/IW/JoUT01cAhMhLPjUG13pgDcuL5eT0
fnMYUOJLSSOBtFkiPba2d592gu3dnzrUiPHPLv+wbO+ZlYe64DZGEIGwhyNJcUuM04lwJMBtkeS3
ytQfn7x7/fYienn2+vQ9L92Xem2dxjdJNJ/MFoXVqpmrfFm7NwDRzlvtBi2SaqXAjtnDJL069H73
gA+t8Hg8DrFnKzWhX+MvyBRgFItvU7b09T4/xPRnRW9O7YdcwlUXGHraOlkQx0U9rnAIxtEaEpOg
+IhmN0cX+TLRBV3w7n1zECT9kAAXXgqhA2LJBeK8H4pSMrzs4ZymRUvUIVqT75NHnRJ2ssB1uSU6
xnLi8/pUh0ZnechV9xbp+HoRgVaB0LRMGbsZpePWvBMM5+nRzt62eTHAzSRhLe9kjB5j3nA2PxBq
DpoI/uKakoyKK4Uj6yp77Hb2DDaVa8DYmBAgqoV/CtCRo9az3rNOsN972sZ0rrfRkpou14Jdjkjr
gou+6DQu+6F2Gl6WEzTaLd6RR0NTAdsMTVe+KAjSrVY43aGuZLorf/dCasiwIKD0Mqn0c10QpCc4
QnN+E47ObkUywLiXlfpyxMkDFZmsiJGgYgHIRSCtHGvWDcGPWuFYdBi2tICeqd2urkC1Xjo6evym
0Z0O9L5Fke5naiV/OpCNnsww5Lh1DTpFWlWA+kyLI7DBSXyVTI6gyEO3G7JXG5f9g51nl4+A3uSh
V5DAtTaijXZ/+/IxtOeCP9Q/XhcoZZf4p6LWvd6ujNvf7u0I1eltbz9/gRb96+3+zmWwiS6CLdRm
+2BzM9iVdV7L5lXatNEovMFGYcp3Rzt24mExgVQf7IbtClzdy9sWjs0A+YMpwN4En18F3eBVZDVL
n0OHNYsJKIuAt0gHwkRAwuWw1iuZMKURgEcgeMdiFdu2SA06uJ6mg+uj8ArkGlXjCcTdI+jYtB7Y
IDHNdfAM5YLx4QITiTiPyMO13jwbm7XWyRpJXnJ/0IDGo7AlNFH5u6zvU3L/2A4b0PvLWFlBxRZu
C1jecAGQnt4ovLfARYcRCgpVdk6lODQyFoGdKwr15TBCPYMnoml5ts8aBkekZE9QVPCjhiBUuhI9
8lIPK1Rhj1SBL4GxAMS8H3KaeIByn7/kHFE6XDzMTfFwYQuVbaLUPEMjIUh6KcpBbCHpURXphLYm
kCRm44dWH21uDKlwqmGCO3HS769D3Nx50V6pOb2pAjgwk7MGNg4Xj2ugnDpFCPUQ5zA7iBdOBVfR
gNVRoaptCW7NXdhTJq0gxt5BMHwAn8EFU1Vh0Jwl8+8K/899+N+LzHCRDPddgH/v+wC/gFIzbB+s
sIThosQQH9Jnq6C+jhesA/f9/wm485C0rE8hkP8H5bdvHfSgCsxmq7zGJ/C1+isIgPeqfosWs0jO
oqEWgb/GltYCf3x/jbtM0toBf+CVZDLLj4B7aFochQehYxC+BhAb9H7rVKxz2xa4HRKVSk9P41lH
GqNC3FJwWkEQ6IOblZatvd17/G/nWfs/hy37UW2Hvwu+7P/b+HJo9CoNUtzAwe9zwu+AOqgGGW4A
0MYNB5DyX0cQ1ACslDoGDsZZKji3RnzjUH8qlr7Kf0xfQdFCHHv1MWzAsD8p/6NvaFXQ1SLljMS8
9qdY2pokrRLkDUgLj8B46ItDD/srNbDaeBEB4fl7zbTXS54DT/Q7VPlwzSBGNPki0lppkHRIEG/P
Q7xBf4PHQmlwd5fS4J8i/dkj1X+/KANKla+IgVLHkwT1+f+TMCg2sWFdJbmC1M8hDq4oP1cUmS0n
MlIVpbbN74vsT31kfx65CXwXNH/+fdhiyZhelIxpBa+r/MhxRMt4oA8xbCkUJaJ5obZuajIiA93W
XUFkK//Fpbv9fJFp1dEr99CrE9T79BDF51B5fwNqgEQUoRtEFBSIwoeqwI3Lx2+Fxs+iWDXa3oke
zOrd5MWBr1jtfFUb+5+7nLyIOPZ3Ab4X3wf41opZq1JW+K3XiWcr8lWjJCWicyT356i8NKxITTWJ
6Qb7Ea+Rlpp7/JrEhMtYI7T5piwo8ga0gunoX74VtGQaXQzbddYzmVN7BTKfHdBxYgm17wMvE/6I
/zmZ51nkj/NdgPFZFRiNjlA8m8rGxjlnvffgUXhy/Pd3x2e/vYHa8Pz03dvzi950aOWOJLvtBBcQ
W0WZf/EakAeNIEpJZUrdoPxmHXEYkCuZeT+b4DCA3pbDi2ISvTSoXQ+D16KXPYT9/ih4bZYtrY5b
4Q8Vr8luxW/S+B22Liruk2Zf0HZz8w28U3Kjrl5cQwYfi/1ELWmzK+iuqXRWM4tngaY9Qb0hPsBm
GNEMCr3th81N+D/Z3kfo/q9xLu2NfxMOhpvR3zDPIK6QEoI/shN/i4J8OYGf4qapyydWhG9lOfOL
67Sw1odrHWQD84Gfp+n6sGp9ny3zQWKsgZXzcI4i+ewjvIIG9sa14ACmZ3ExgcUBm4T+CKbeMsOf
g/cwcCRq6zPeO8bAUkAIekWhFPvT+qWNtbamy20xaolTKSzd3QHN9nSlKm2w9IUJzsT/YHMTAina
se+X8F0YwlSg9eCeAU2WGCTlkJdzGOzpkxG8O37/Hg1gGh1gAbTe5intBjFwYJqq40HV/Um9hCiT
01ZCsJxMpFqnqi6wRjTsM42LKVTRvV6vbSZKrwJM1Vp2dAriVlAOC0MxTB3Y6ISFGU1sh+rzWsAc
R68u6wbhOc4YL1oLoQ8BdbJwqMhpH5LtCp62K2fyww+wFwbv5dQ7RNY0n2Vq2TMHjYnAquda0Gmx
H1KTT+4i1lViah8kXk90RIPTFqGLVkvSw/CTVeBfQcwmyWhhoP6GNojYYOOy/RjcfvKLTQcUK9i/
7f79X4+7u0+fSb8fKg0gLOAF6n9AA8ca+qHdA+yPaWw09mlRmaXpDbolcUqq9od+FDXsthjvUbF4
6gj5Qyg7aGtGWhPa12FkalLY8mZW9ZW2k2sZZGr7s7JVI/NyZXaurx32tQWrF//seb0mE7C15l63
dyJ97XWL5vVau99Ua2+1VvVAaKqkEomurWiqwq4WttuymN8vTuxeLhcDEVH74fwBUJ1hQLiMzx8U
sGRkfUGBdCvQEqnhIAduFAuaKm2X7ln7Hf/4o30zvr+vHREssPpSZzmeL8X1FLf8UKd6snzH7T75
/ddjkGNccaeEfkPWQCLmxqzu5isdbQyWmGAn2IAT60bbTty+GsaR6WpdFe0+KrsvK+qaaTmGOOEW
Nl9GeIzoQL8kGF62HQn4IwMR2O0FvyagJMSSAbz5QQnjoKVOhFcJdoseLslgKVK3IQZwXhEh60iC
AFrifBqBVh2FoEiLLqAhD2ZXaj9V11RBPDU9d9Un0TeuqR9/2JHCiLTiCNJcnBd08m9lcJPLxNk0
+9gmM0rEUWrVcyXsBMYUReZ8FOoinBffHSjn7E5m4qwbOjkTR0AJytlEws7KtUpELpFY58/2j1T9
EIiaQ812/5o7lkiB40gF1SOVhY3pe/FwEPzlyHtNV755gb9ynSdEzV3DmrtWqeRedUeUXl1T1+kv
tBjdizTbvGp0ENEL49asnN4llo/fFs3eX/A4MGI2CU8Rj5LoxjQfWnhjaaCa/a7T7Jtj4hh+w73d
b27I+0/zMkRNGsnGHFk9J8U4T38q/jq4BX3W15+pSVX9Jqxq5sLaEXcGaiciAaCjUOGo4km6ZXy+
tpzflg/yLagjuDF8547SVqwfqb5vXpTckeWaauci1+WK7VomF4uDCB2uAZyqklPqpD1AWp1NgK+2
l9KbqVxbYCvV/JdcJ2jiFrPi02VhO3CS/RcXpv5FkfUuQofOb8R5HIn8VHcfEZ8xTomMBQuBb5BE
CxlGUxFnKJOU4gwt5UraVLK5UVaFlzT/6Ruhw3gRgg1Yd4fbWFQrF6+to0OdyO5B0lpOEWj1UBuf
ExO+YuYhzhH4l9xHpkAXJjNNPEughFZq2ycyFDuXhXG9uKhPBOIDqDW85Vo7UtHUUh85dczw+xa9
FIVk3oCzaPxtbXUmXlt3zfkj++uMetLNzU+YyeMWnJNZY5M3FizVvBh7L4KWMvQq/wJnZwDZMS4F
4ptLF366udOwAQJUSEd6J4JPT8Q6EStEtoJcp9DD75kDZdxxJYzABaKp0Oh1tXSVI1NZu3HiNNXk
nOhtETnvlvNS9yLS9g/i0wVqKdcD50fHDbbAIKYq7KPwUv5QNQyhEgQaYVdA3dGIz8AgUfrcKJD8
ac1cnQA/tbn+NoocMIwWntBNhG4i6eaybUrZGR/wkx1eliaF835lWU52wM1EnU+ciCHuUljNZWXV
P2MPjTxyEPzy+u3J3+D6KPucFqVUAQ4/4+ZsUaJq93D2dKCzUqX1iDs5Pb84e3mGDiggTdRt1FEE
7xpKry5ycpwkXqDf0otMwlHAn8hCrO8O56dRFtZrz4UzUNKnXgDS9E+cNlzXMZr4ZeMGyPVfJerD
Jr6/J/TZmy71Wli/a+33gneWENkIypZzElxmE85eohyHh25efIXlFLXF8gZuRbFGrC8PgVjvvLMO
BRcJirKqT4tHKEM+JZCaQV4oRcNlhTP6RHTe4E+Kn59lKlomwmv78dLT94oW490yh4dt0tsMPpmo
LCGTmNgGqrutsI4z1YgupRin5+dvz2HkwnZ9+PABTeBfSOJrKqvZQshuu9/debq9fXDJ8LI/MtQO
qzrSK2O1tsRU6dKqyXokWsaGWDN6AYIhxogPoFTav2wf6DolHinof7pKHmHY+jTKH6srW8hSJBSt
MprFcHXUwpSMv42wVjGre5FeLfm73a68vZdLvi+1yotKqJkIr6JJqDSlkGPGM85YWmYi0yplvtuP
ozAN3Lnfv3duZ/2DPRrHTGBk36yNOmUzi0sGArZCLMzKNW2NVPXrgtXL6wivre3QBE6S17neOevt
b+vcVf1y303Chzee3Ci+cUBX91tXI75PcmTfNkK1/r+xrhFHtQYgINJl33fUU56wUkM28osVSg9A
1gDvRZ2bS2UoKiUpSprzJpOTw+EP3TTjWmIW11az1711V4rkzidBUJZDSYztdekdedlu13AuVCqC
OkJYhd0aouGhrTAzi7i7K4hLHe2na9BICLcmfpGkEuKwlprAQRUJbBjhFhWFW8J8qwGR5hLIoATj
KH1o+vH6pnuyDZVUk6sJjWLUhIRBbjbFQeq1uDESchNsQJchV92IwpHcclkvstF4sIOD6k+MlERF
rArWLxm952kPvR1+Z1avkvivb90CXZDFAABKHdw9b0YU2eEArhsp6ov2gS8Bic+DL/hQ3yG3O4GP
CccSz3/QuqQwktHnV59VDLq3ThMdAo4TffC77EafvZ4i6enSgLWVkF4BjqtgZs9ZbWRk/qjuQALg
B4/S3UYY3NysBJ1yZyshp5Vb44f4w/oY1OpmuU0SJ/8H2SHnnsRNTCaLOHglQd+vJPa7dq9kkQkE
02e7i/7Wmc4tlZdd8rygLD2QwWTbTMGrSHUVrkAGJ6EyY7Wlex3fllW3fOBvm+zw7v7qDvN2cQLF
lWxTuZEARzG51QJ8N/zo2soAlBfNpTKph34eCJIOzCilWwIQpREtNjffOsUPwoV55IiaWHRvE1G8
MFwQoAcbH/5SnuzKZSoYx/NmfLA3g2V2k8GyIJAPSRZtQBbE9hhqvI284ZByqcS6ed9ueVXb/osR
TR+G+Ba3HL4JkezVAj/d+Pro9RvVXtnp6JPMSH+ascGyIn8FFrTsazc1wkmZYWHUMk63cl+7p8Od
7mAkOxjJEmqYa3Vwkc5iDY6+h0ppvKSlxzELXkUsA7Fvo29mJXs1VjJgeodPjytSaG6mafxIUA++
tgsTltRq5eVZlIb5tgqrXj28s+ag0opKM/Rg0F/Tx2W/oREWBdtbo/C6QpydilfUcTU9nFBvdh4I
BygUssR1WrUqZlfV7TWyfRl/NHpFPm59GkYQsNsdkwvj0rhkG/drcbDDbtVUHVXK8H8Rc26i4JHq
xkbCMhK9zEKQSQCQ2PaUZ0OP8IkyzEcahajwZX2Aa+Q9AcA3dEIf9QA3pNiEF7Qb6QJlifcSwoTE
OTNI31fLhQljspdCkgrD19UqX9g8Dpovx3Ba6PBqIbh1x2bIFRgIu7yhQVORjBgZcYrAJqY3/jB5
JuAw+hVufOMOVQU3vVB8hfdaxB9MSjbrnD1qqLpuqmQ/O9vfR8TbX3M3AzOA8w0XJiHYck8v1cLH
7pJWi7g/9lscBzVXXNEmO4ZT9nHMXAkLag28SHxm6HCKR5Wytd/I6zUqnXijBj4s3UeVKTZVsx2X
XpV+g3QUceKRZdn17stW1YGuyiaRWU2pJLVnLDGsy6k/YBkh1njCp2JoWWiCAxp7sHPqhCjKPx9x
vwLAclg0dwjHU/2/eaJ6DSAJP7PZAvpeH8ArktNKgROlvOh1G/QkI2w53UVlyc3X6kZSzc3PV8Uu
FMla3JPxja6UyXJEpi3vb664xENT7I4PpdT7aT6k1delDKe9uaVLQyWT1gi2Mr/SO77d0QgUb1su
G5ii8UprduVvpvsXXkoLExGsAe+7957FEL5fpQN7m1Kemlm99ZjWajSKdu+jsvWGUPl/nQI9XUOB
nLTHPyZVhYJNLApG5QsqB/oB00JWXEoOBAdb94RV25x215QTQ0g780qYRB/cMY1UnjYKheZf29rI
h5hVVCvKGgrdbKNytgQ3b7aRsyRaGdJMO5Jp1zqUmUdu5iBfUbV+Ub9cqJG3maX85sfBy+5DP4ik
N7DlxVcAVU1sQdP4FfIG3ACKmbbBXTLVFwz39oOaBNAwvlUsfrrvb3B7ef8fH/FpjJ8HmmPr0Im/
8FnPbGnHK43vGUDS35BpouEWH2SudIaQgWMkQBNHoTy31NYk64IPU54beVouQSU9btqdd5I4RRTT
zZcVERVSJYqO9Gq6FYU/SjprgWoVuOceIcRv0xOpYrgSMs5rM2OuMwrb8/6G3kMiUy9y9UiEpB43
vMWaVUBlsfnZDhshR8rmZttMYzPnyE4RhGCd8nRl2een/+v3s3PYNwy8fmHdOPEyAF6zwchiM4ow
IjRJmTrGWLcmqeF8nGyFQ+fLVFIQ3blpXNxY96XIvRRwor2rNpbYvOY2GaBJ/gDnuoyKabrKrp6J
eUu8tydxqIaxwiQpcr4EJmWCJFEwaSDoXgANfAv9kYvRpMWeXBuSANaPtD6FXcDqezi2vrmwIrXI
me4eoJMzi1IR1LyKoJdU0VR83b8ODjVa5cCh+er5ejWnkCQUKg42N30EY6yKIpCmVFN7dYGbQOKw
SepYgmmq8VENG7Y2GrZsBrgDUUZCE6J3IclTpL4+1XW6yYVrWO4v9V7ULMaDc23V0gvlGe4lv0Sm
foSCyLWxttV/na8+WyfZm31ztCjf3hqqQIY8AchGtBXo4/Cj+6mO4/jhxDt1xdgKjC7NOI3LzdIX
FDVX0m1R84QRgVIkInXqtFqbm9rJGTXbfUX242FuR+K7MvR08JpTKsq5hrVvhx9XXxmf/C9o5lCu
EHOl9gX2oNKb3MelWaP3vutT9qGKkagkFVrhQ1KoRUMHqe2LySkavnkLviu7DnPrxkKSc7RD1RuW
lur7FVHRQT4vJCXY2sC1+3Va2i9kqqqkoxLdeD1jVXuVKwuYCS8vT0+YuiitP34mxeFmbTit88eo
mC9hf1sKvQqr+CeTisoR1U4U/luo8jxsDg1ZTfUwsMrYpvhFF4BIlYwJ3qvEFq4YpOvRhcVNCl/9
obCPYfSFYEE7SxvS0B94KPNChAHG8xkZaou/aWIiwe5wfmpyG0aNkYR1w5vY0tTotqZFGeC4YtZj
C3H9+ub+a7Wb+m7cj5plb81UbWwXTXWCng1DNtYx7mh8r84+7n15/XVr8CobnX6pPTDL0F0QNCl3
ymvndukbVhuWuUI1TfGaxVsnxKj0sMd8JDHDyiY01rXEiASn/UX2Ija/3BB2gwVVq4wxy8MnX6Iy
22rBj4vGF2qQR9uqhd4lkiuL7BZSEWU8CK+S6/gWdMSoHUy8k+dkoPRL1AxMQdzEz4/dtMtrWZkJ
x3W6EiRayctHD1MEtO6QI24j3kktKeVB+V2vsaaMwpflvO2wXUOAy6PC7lmNp9qrG45TxcD6rera
WribWpC+vDCIe8hYDgE3HeiLzRie+cIhsJLjf51Qv1gj0zhZxsVlqoXUxGT6VzAXbmkdMK1HmShE
JAHeFlwtRblbLOeah11keoInXmxeb/0ipnrxLBVQNTc630NURHJ1k2ur6VYoORL0oTgd0idzvSuJ
rzAuV2SNtXZRRqGcZkNngNKlRXZpkQpUTnwhZy2XqUxY1kopxqtj1m3uMpRRRIph1Yju+PCA08a/
bBsi6IkvjbXaXtbvNQSN+cJN/K260I/o1uH3XHvX9lO0qJaBudib+vhL8NQkgW/ViLXfteM0ldly
+c5DxZ1yVDIxb+n1t9Vlr/qKaDMHG5GDjXa7SZz7Lhr/nxqdOk7F/5ABChnuWU71ZzxFI3VPxJEi
wISi2I+8dcNfzuQRtNX1UWqUnm1a6PbCYn+NsiGfh8hcK1becdUFgikbHxSR5ebLy6LcnKWuKAvK
ZI1KBSb2wwxK/kdyQ7HOo+pYbd2lV9WJmrlXkjC2K/pCSehrc+QqdZjd7QZGR/yN8mRd/9WYc2KN
AE/h/aAqBa41VY/rpijXKS+l3mUWZ9MPQ2ZneEFz6Tr5898cVS52PED6xss+GcLFo4zKozTNRV2g
iseoPFNLB6HHHwijUXWnPWPfqraiB7GOFsadfkURpno0XlJqOqxVRVhHgYLXFvV/2bB18Q0Go84p
ItXuqNztq0JYx4MeXRMByKnYLUReNgpaRJdGaYV4V6phSBV9r+XI7kpYBTwk4FiFPXMT9Dy1O9XE
oNK9yynqJROtqWqaURnT6t4WXeNlXGJkQx7SFcWmevTUc5g67cGXYNBxw8Zt8Tihjm1CLhpApayp
M1HROdKZrFGL1Xzjq8exchUvaahUBngxitolYQ3FEVfO6FhfvS/zs7JFNaNq+8B4cFR15aWmnb85
UaN1j63W/dOGaiQ5n7hvHsw1Bs+y7FKxblbcPOP6Ck36RHWHtOF8rnrkhVzqjds4wa2ptW9qtRvp
qBnnuvn6TQJ9LYkXD43Ev7nZkPa2niKxy0w5MiqitQ8CDcwIPhVwNLAxGoZbMn/1bIIw0cJY1fAE
TvlBWKWWhSzzGGV7naLAVKfRQYHAxM/MNBLCZDAYGE6qGFKYkBvaZmnvls8LwQnRqE7lVJ293aRe
0Y6kn7YrVDC33ZXl2ms0lKBQV6r9loZvMa0UfZ37ly3dm+9NDnwxwwTClWHQGIrJMdio8umNg81V
89DNGpuRQYOKxeh/bjDCIUTVd1gvCwXs7I5iKZFY7wnN9FtqNi6VuM/s3gm1wolDeCvzlW9WmES4
Rv5j4uQqCsbTb3LFahRNjD+kVSbmX1BZQSV2xMFqflrWo7Kj0bPZEXK7Ia3udsekN+Yv3EmGR7g3
M8MYNRVUWtAxS5/EqxqPDf5bsmS814raoVbmV6rUCD9RnXtmM0GaMTgmO5BkQ2WBhxpN4gXDFHjD
b9aNlK6pjpp5fkuNgaPqOCFOUqWRS26fs1z5puodOJXSQCw4bHaq4zapU9kFq9fSdZUIqqrLQj6P
0eJ5Wfhc41pA1wmlgOoWyl9iRvzRs+CotElVwEraa83YbbNfr3D6A+OqbUOGU3Gt0VrGM7v6Whyp
IzcN+5ENeIv/nnk5IpxOyMtufeC8xJZeVfFfC1ews8LHS0vqMB1LKhdlNbJJngClCp8vtuSk9WfX
C3LicjorjfXUKS1WGptCqAEdVOhXPkRx2dVMHtXvy5T2GTHeY7jD4OXfjwWdjfOppB1XuTZgZDvP
qmj3wkbzwbkmFGd8+kpC8pp0iE/ndCUXvISelh+2Ws0+7kAb8pytyLuMo+7ioe1FK9FJ+lJwUnMV
rLhf2UmhxTcwpGOYO7qUkKr54ZnqXzKCdjVc2nPo12B6o2NrVQSvvBS2+Ftpw8alFS4OAkoXO1wB
0jDbCIgjyTXGyBDjwe1FSoTrfIWUYDW1qupQyo1yYYlETvxZ1C7tGsX3tBespgMqk62UdU8mgtxE
5V9PX56eXBBr8QWxWU7dVu0TN5wEEFM/SmLBD/IELMNOyS1+oXSwli/XJfgjc5CcGGY+Dr9hrUrk
Iu99WgsARX2p+S5HHjiH5kIGOntz8vbNyevf35/941SnWixH4CryrSSbrkZq/uP0XMIwWYvXOVwI
HyCgTDXjjv3AkAmmZbgjQ2xn0zjVzCkuhL9M7wQ6pR8e0+8G6TfE5qKacYGZ7nMpIK6xOuGUqmJs
P5NLWS5lzkLi9qq5a4YV/1Ube20y6ojcaFZq3FTsjmGb3X65G5fetyQ86J5XBI2a0UuvdK23MMkd
Zp2lbPfWQO9GqBgzsQSLjAP1S3h8UlGf5Iynxau+dasl18az7EDpartNEN7xgrBPxBObKaayxSOT
RQmKIsXVzMYSKbAGdzH9QaA1pITvhRqZTDipp4TSnOGS8EZV43YeofYVyjz41Ukj5AMjJIi68jEm
wJHCRxlrvbl5WBl6ET8UNgePCQFGqpKx0YN6X76zuX0SyWXeC/1Y/E2FtBKvjEMXgc7LBDXUL8Mx
FF2/RFfmYuKbFKEBNcrwTD4t51IuyHdxmDg6MJ9TcAcoLiJSWPmi6LzH8HRJ3R9qijflpP/VX82h
NEcEbqv+xYatxnrtikxcJOx0Xs1N8JwfkhIMKKraDd+aUc5/lJrIcIM2ng8bMGGU9jeUwiOymA8C
/jTsUMXKAgSbgV+VOSMpt4dP2Pj1jo39tinCNMhaw9PEZkdrmPs8ofM3UTgZ5im/2cWgtZ72t1vr
T74NC2cXzestDM1+JMm8cq4rwS+H/IINdNPmo2uMcPC+xqapRtKFc9Jv+EReILvlORqpEdV9xKRn
4twnE6bXQOiM96kVmZT6ZxqeQZ5t1rXHdZ14OchM0C+TvZVur5Bkguv/3j3kLKeYXsH0gNf/3d11
zlX2g0/a6z57fedsOmayEGderUkdgk2TLbOpRg7V250CxpazOZXeAKhuRnrKkc6d/dAmVMRQU2Zb
2bUeWcWab1dZDh7bnByj5cR+Qoyfq9UP7tlpgb/osM84LLPDlEOOZpMJNdWwUm6KU8yh5J2xOWGm
U15OTK4AfgtHPDoMlujn3SrfdTMDPa/BnXzm0nqZVZPYKXXxU9eB+mqeujJtgXz67wpSpSS8GKa3
SJRnhnphh7LpAtJCTwFnbZL4kUQXBIK72CZdQJFLC7dX/2ARjqFMemA3mt2TGpphf+KwZ+uyB+bg
c8ndt6YNtAkD+cFrn6K+6AU2N+KQ3c7m4rGN1rhePZjPCebGVFhQ8i/kMy9DL3vjKbUoOTGVR2DE
a+Il3I67PLkyyaGwO4YMIshAUl5y5y/+evbezhWin2OT5k7AHZ3GQxyVfp4xthm00J9hjx1z16B0
Ll9L9KS3rVJ2sx98vINE6eW+4AD6oSI/n4RKM+IIIGYhk5JPQ6hiawsWPrq0dtR+f2ib8FZsEvnp
T7+hlvhtVTARRdC5U/5GkHtVwqqnuvmpB9QWlb8cl1BZ2hKDlp92s7L39sDG/OTPakqRQ4ZnMZEF
Q7Kas9Q05aVpS7txpV09Q01jO5kLFKCwJft53XkBpi1RamtukL4UWJvmUnLTuSQS36S1LcfhJKsK
xFqW3p8kizwHuex/S+eXnsZUp1VdoYWjvDwtUb1oojhfGCb4eJnxkH2HXxfVD84Dqk8kU17499ML
kf/ksKwD30XAYnZryY1mqav3UWZrqXU1tkZs0xc8Aulyb9xWSZZW8smoXxXp1nhem0i7NhNvVS+V
TBkEly/ZGepjEymScsPIPbQz9Pra0VWdSgyeBpItc+OVIqIgU099sYMOUrpX5nPWpBuTi7f5/GX9
+9Rrv5cLbSI0j2mX2rb7sq+2N42Fn/22Og8v+KowRLcUc1W4XVlOESBZ8zPdE0DHFo/JxDf6x+uO
590xcvscvw5arGjOt13pD1n796vzkryLpZnCv7nZ/g1urQGgr4CJ5YHmZOXaYBlIlfd42prVg30h
sSGa90eSx/CDHkV1KV9SKQQtcyXb8i8tW4F/YcejvZW3G6bw1AJng1y/Wvt5dW5/U3zgNsFopuIE
LBLMwWywd26u03bXv5YItbrXEESuYxez1K4hVZ254EMo4C4VvWfJ7CVt0DL7mM5NLtxB+bVUfqN5
Ol+IxDeUrLhg7+C0Xmpm3IWrqVTh6xVUE7X+qLmnNWd0SXE38a79R2bSlFabeP/9UMpY8eQOt9nD
UmobBZJOlN+eFsA2ll75TrHyQUl09Ef2VuPqD4IPHsE3uNX7J4SMD53gQ1Nabpav3BlrhY6EMoH7
ByMXGioo0R+Uot5fHL8+hTB48rfj306ReS2DTwAXUElzbSVHHkSW3Gk0rcvGay7o5ub+v4/P35y9
+Y19QL3qyK2NS+GFrWyqgGVVsHCIpn6EajrVMr62Wjt5Ta1Cq+Fzh/IZQVoUJEsqJFMAwxESzo66
L8J2j24VSYtdV7Kjs+DJ/wOoFLym
"""

if __name__ == "__main__":
    main()
