#!/usr/bin/env python3
"""Campaign 01 report builder: reads campaign01_results*.json, writes CAMPAIGN01_REPORT*.md (no hand-typed numbers).
Each campaign owns its own make_report_campaignNN.py."""
import json, os, math
def build_report(R, here, name="CAMPAIGN01_REPORT.md"):
    """Returns the markdown text and writes CAMPAIGN01_REPORT.md into `here`."""
    T, E, TOL = R["tests"], R["env"], R["tolerances"]
    e = lambda x: f"{x:.2e}"
    H = lambda tid: T[tid]["host"]
    L = []
    w = L.append
    V11 = bool(E.get("is_v11")); V12 = V11 and str(E.get("kernel_version", "1.0")) >= "1.2"; STEM = E.get("target_stem", "uct_curl"); KVER = E.get("kernel_version", "1.0"); KN = E.get("kernel_name", "uct_curl_kernel")

    w("# ALADIN v4.0 — Campaign 01 evidence report")
    w(f"**Target:** `{STEM}.py` v{KVER} (`curl(B) -> J`, kernel `{KN}`), executed unmodified  ")
    w(f"**Source SHA-256:** `{E['kernel_sha256']}`  ")
    w(f"**Run (UTC):** {E['utc']}  ")
    w(f"**Host backend:** CUDA source compiled with `g++` and executed on CPU ({E['gxx']}; Python {E['python']}, NumPy {E['numpy']}).  ")
    w(f"**GPU leg:** {E['gpu_leg_status']}.  ")
    w("**Generated C++ SHA-256:** " + ", ".join(f"{k}: `{v[:16]}…`" for k, v in E["host_generated_cpp_sha256"].items()) + "\n")
    both = sum(1 for tid in T if H(tid)["verdict"] == "PASS" and T[tid]["cupy"]["verdict"] == "PASS")
    if E.get("gpu_present"):
        w(f"> **Status: {both}/10 tests have PASS on both host and GPU** (pending policeman sign-off; any FAIL/BLOCKED/ERROR test cannot be certified). "
          "Host execution of the exact CUDA source tests the mathematics, indexing and stencils; the GPU column tests device compilation and execution.\n")
    else:
        w("> **Status: 0/10 certified.** Host-side evidence only. No GPU was available, so every GPU leg is BLOCKED. "
          "Host execution of the exact CUDA source tests the mathematics, indexing and stencils; it does not test device compilation, launch behaviour or GPU memory safety.\n")

    counts = {}; gcounts = {}
    for tid in T:
        counts[H(tid)["verdict"]] = counts.get(H(tid)["verdict"], 0) + 1
        gv_ = T[tid]["cupy"]["verdict"]; gcounts[gv_] = gcounts.get(gv_, 0) + 1
    w("**Host verdicts:** " + " · ".join(f"{n} {k}" for k, n in sorted(counts.items())) + "  |  **GPU legs:** " + " · ".join(f"{n} {k}" for k, n in sorted(gcounts.items())) + "\n")

    w("## Summary")
    w("| # | Test | Host verdict | GPU leg | Headline |")
    w("|---|------|--------------|---------|----------|")
    head = {
     "001": "Computes J=curl(B); no E, no dt. Role = `current_curl`; sits in driver slot named `uct_curl` (Faraday slot).",
     "002": "All 10 source terms match the independent derivation; smooth-field orders ≈ 2.",
     "003": "All 9 sign/orientation cases pass in FP64 and FP32.",
     "004": "Output is curl(B) with no mu0; homogeneous to round-off. Apply 1/mu0 once, outside.",
     "005": "Three distinct strides verified; kernel ≡ independent-index reference; footprints identical.",
     "006": "All six derivative terms 2nd order. Not CT-compatible (structural + measured).",
     "007": "No input validation; OOB with driver-style r arrays; axis-adjacent Jz only 1st order; guard returns 0 silently.",
     "008": "**Supplied Jz reference is wrong.** Against corrected reference: PASS (2nd order, FP32 within bound).",
     "009": "Writes/ghosts/inputs all clean; aliasing neither rejected nor prohibited.",
     "010": "Trap works: kernel rejected as CT update; correct circulation update keeps div(B) at round-off.",
    }
    if V11:
        head.update({
         "001": "Computes J=curl(B); no E, no dt. Released as `current_curl`; the Faraday `uct_curl` slot stays unfilled.",
         "004": "Output is curl(B), mu0 = 1 documented in the module contract; homogeneous to round-off. Apply 1/mu0 once, outside.",
         "007": "Validator rejects bad grids/shapes/dtypes/radii/units and the guard is gone; axis-adjacent Jz is still only 1st order (D5, open).",
         "009": "Writes/ghosts/inputs clean; overlapping or aliased outputs now raise `CurlContractError`.",
        })
    if V12:
        head.update({
         "007": "Validator rejects bad grids/shapes/dtypes/radii/units; guard gone; axis mode: Jz 2nd order on axis grids (SMOOTH + m=1 KINK), exact axis fields, inner ghosts never read; sanitizer-clean on host.",
         "008": "Judged against the corrected Jz (policeman's ruling R1); 2nd order, FP32 within bound.",
        })
    for tid in sorted(T):
        w(f"| {tid} | {T[tid]['name']} | **{H(tid)['verdict']}** | **{T[tid]['cupy']['verdict']}** | {head[tid]} |")

    ks = R.get("kernel_selftest")
    if ks:
        w(f"\n## Kernel self-test (`{STEM}.py` Z-pinch test, run first)")
        w("| dtype | backend | max abs(Jz−1) | max abs Jr | max abs Jφ | axis-cell max abs(Jz−1) |")
        w("|---|---|---|---|---|---|")
        for dt_, v_ in ks.items():
            if "error" in v_:
                w(f"| {dt_} | **ERROR** | `{v_['error'].strip().splitlines()[-1][:140]}` | | | |")
            else:
                w(f"| {dt_} | {v_['backend']} | {e(v_['max_Jz_minus_1'])} | {e(v_['max_Jr'])} | {e(v_['max_Jphi'])} | {e(v_['axis_cell_Jz_minus_1'])} |")
    w("\n## GPU leg")
    if E.get("gpu_present"):
        w(f"Executed on **{E.get('gpu', 'GPU')}** (CuPy {E.get('cupy', '?')}, CUDA runtime {E.get('cuda_runtime', '?')}).")
        for tid in sorted(T):
            g_ = T[tid]["cupy"]
            line = f"- {tid} {T[tid]['name']}: **{g_['verdict']}**"
            if g_.get("note"): line += f" — {g_['note']}"
            w(line)
            if g_.get("error"): w("```\n" + g_["error"].strip()[-900:] + "\n```")
        g7 = T["007"]["cupy"]
        if g7.get("compute_sanitizer"):
            cs = g7["compute_sanitizer"]
            w("\n**007 GPU leg:** device-array validator cases " + ("all as expected" if all(r_['ok'] for r_ in g7.get('device_validator_cases', [])) else "MISMATCH") +
              (f"; inner-ghost independence on GPU: {g7['inner_ghost_independence_gpu']['bitwise_identical_with_NaN_inner_ghosts']}" if g7.get("inner_ghost_independence_gpu") else "") + ".")
            if cs["status"] == "BLOCKED": w(f"compute-sanitizer: **BLOCKED** — {cs['note']}")
            else:
                for tool_, r_ in cs["runs"].items():
                    w(f"- `compute-sanitizer --tool {tool_}`: returncode {r_.get('returncode')}, errors {r_.get('error_summary')}, target completed {r_.get('target_done')} → **{'clean' if r_.get('clean') else 'PROBLEMS'}**")
                    for l_ in r_.get("excerpt", [])[:4]: w(f"  - `{l_[:160]}`")
        gv = R.get("gpu_vs_host")
        if gv:
            w("\n**GPU vs host agreement** (same random inputs; interior cells; both kernels are the same CUDA source):")
            w("| grid | dtype | max abs diff | tol | finite | ok |")
            w("|---|---|---|---|---|---|")
            for q_ in gv:
                w(f"| {'×'.join(map(str, q_['grid']))} | {q_['dtype']} | {e(q_['max_abs_diff'])} | {e(q_['tol'])} | {q_['finite']} | {'✓' if q_['ok'] else '✗'} |")
        elif R.get("gpu_vs_host_error"):
            w("GPU-vs-host comparison raised an error:\n```\n" + R["gpu_vs_host_error"].strip()[-900:] + "\n```")
    else:
        w("BLOCKED: no GPU/CuPy in this run.")

    for rg in R.get("regression", []):
        w(f"\n## Regression against frozen `{os.path.basename(rg['baseline_file'])}` (v{rg['baseline_version']})")
        w(f"Baseline SHA-256 `{rg['baseline_sha256']}`. Annulus grids (r_min > 0): full output arrays must be identical (host: bitwise; GPU: within {TOL.get('regress_gpu_eps', 8)} machine epsilons).")
        w("| backend | grid | dtype | field | identical |")
        w("|---|---|---|---|---|")
        for q_ in rg["annulus_rows"]:
            w(f"| {q_['backend']} | {'×'.join(map(str, q_['grid']))} | {q_['dtype']} | {q_['field']} | {'✓' if q_['identical'] else '✗'} |")
        w("\nAxis grids (r_min = 0, SMOOTH field): Jr and Jφ for rings ≥ 1 must be identical; ring-0 Jφ and Jz are the intended change (errors vs analytic reference shown).")
        w("| backend | grid | dtype | Jr same | Jφ(ring≥1) same | Jφ ring0 err (baseline → target) | Jz ring0 err (baseline → target) | Jz global err (baseline → target) |")
        w("|---|---|---|---|---|---|---|---|")
        for q_ in rg["axis_rows"]:
            w(f"| {q_['backend']} | {'×'.join(map(str, q_['grid']))} | {q_['dtype']} | {'✓' if q_['Jr_identical'] else '✗'} | {'✓' if q_['Jphi_rings_ge1_identical'] else '✗'} | "
              f"{e(q_['Jphi_ring0_err_baseline'])} → {e(q_['Jphi_ring0_err_target'])} | {e(q_['Jz_ring0_err_baseline'])} → {e(q_['Jz_ring0_err_target'])} | {e(q_['Jz_global_err_baseline'])} → {e(q_['Jz_global_err_target'])} |")
        w(f"\n**All as declared: {rg['all_as_declared']}.**")
    if R.get("regression_error"):
        w("\n## Regression raised an error\n```\n" + R["regression_error"].strip()[-900:] + "\n```")

    w("\n## Items that need the policeman's ruling")
    t8 = H("008"); rc = R["reference_check"]
    w("### 1. Test 008 reference field: the supplied `Jz` is mathematically wrong" + (" — RULED (R1)" if t8.get("R1_ruling") else ""))
    w("Independent check (embedded in `campaign01.py`, also `verify_reference.py`: Cartesian curl by 6th-order central differences, projected back to cylindrical, no cylindrical formulas used):")
    w("| component | max abs difference vs numeric curl |")
    w("|---|---|")
    w(f"| Jr (supplied) | {e(rc['Jr_supplied_vs_numeric'])} |")
    w(f"| Jφ (supplied) | {e(rc['Jphi_supplied_vs_numeric'])} |")
    w(f"| **Jz (supplied: 2z − cosφ/r)** | **{e(rc['Jz_supplied_vs_numeric'])}** |")
    w(f"| Jz (corrected: 2z² + cosφ/r − r·cosφ) | {e(rc['Jz_corrected_vs_numeric'])} |")
    w("\nHand derivation: Jz = (1/r)[∂(rBφ)/∂r − ∂Br/∂φ], with rBφ = r²z² + r·cosφ and ∂Br/∂φ = r²cosφ, so Jz = 2z² + cosφ/r − r·cosφ.  ")
    for k, g in t8["grids"].items():
        w(f"On grid family {k}, the kernel's Jz error against the **supplied** reference at the finest level is {e(g['fp64_Jz_vs_SUPPLIED_reference'][-1])} and does not shrink under refinement ({', '.join(e(x) for x in g['fp64_Jz_vs_SUPPLIED_reference'])}).  ")
    if t8.get("R1_ruling"):
        w("The policeman's Campaign 01 verdict (2026-11-18) directs: *Correct the analytical Jz reference to 2z² + cosφ/r − r cosφ.* The corrected reference is therefore the one Test 008 is judged against; the supplied-reference mismatch above is kept as evidence.\n")
    else:
        w("No correct curl kernel can pass Test 008 as written, so I mark it **BLOCKED pending a reference ruling**, not FAIL. Against the corrected reference the result is PASS (section 008 below). I did not edit the kernel.\n")
    w("### 2. Name/role conflict")
    d = H("001")["driver_slot_lines"] or {}
    w("The driver's locked sequence is `" + d.get("sequence_comment_L8", "…") + "`, so slot 9 `uct_curl` follows `uct_emf`, which in a CT scheme is the Faraday update curl(E)→B on faces. The delivered kernel is a cell-centered current reconstruction. Recommended release label: **`current_curl`**; the slot named `uct_curl` remains unfilled and uncertified.\n")
    w("### 3. Post-hoc changes to my own tests (full disclosure)")
    w("Criteria and tolerances were declared before the first run (`TOL` block in `campaign01.py`). After the first run I changed my own test code in five places. The first-run results are preserved in `campaign01_results_run1_before_test_fixes.json`.")
    w("1. **Test 003:** my expected values for `Bφ = ±z` omitted `Jz = ±z/r`. The kernel was right; my hand-written reference was wrong. Fixed.")
    w("2. **Test 008:** the predeclared rule 'order ≥ 1.8' is meaningless for a component the stencil reproduces exactly (Jφ of the adversarial field is linear, error at round-off). Rule refined: component passes if order ≥ 1.8 **or** error ≤ 1e-12·max|J| at every level.")
    w("3. **Test 006 CT probe:** the first probe used a field whose Bφ is linear in r, so the difference operators cancelled by accident and the divergence sat at round-off; my pre-written conclusion text contradicted the data. Replaced by a data-driven probe on a generic smooth field plus a structural check.")
    w("4. **Test 007:** my axis-cell criterion (order ≥ 1.0) was looser than the declared 1.8. Tightened to the declared value; this exposed the first-order Jz finding.")
    w("5. **Test 010:** divergence was normalised by total flux (depends on dt); changed to normalise by the update flux (dt-independent).")
    if V12:
        w("6. **Round 2 (after the policeman's verdict), Test 007 strengthened — before v1.2 was run:** added global axis-grid convergence on two fields (SMOOTH and the m=1 `KINK` field, whose hand-derived curl is checked against a 6th-order Cartesian difference curl), exact axis fields (Z-pinch Jz=1, Bz=r²/2), NaN-filled inner-ghost independence, FP32 round-off on axis grids, an axis-geometry sanitizer run, and the GPU leg (device-array validator, device ghost independence, compute-sanitizer memcheck/initcheck). Test 008 now applies ruling R1. v1.0 and v1.1 were re-run under the strengthened criteria and fail them, so the new checks discriminate.")
        w("7. **Loose tolerance disclosed:** Test 003's 'uniform x̂ field → J = 0' case uses the declared `uniform_abs = 0.05`. In v1.0/v1.1 that tolerance hid the first-order axis defect (D5) in the same family of fields; Test 007 now measures it directly.")
    w("")

    # ---- per test
    w("## Test details")
    t = H("001")
    w("### 001 — Operator identity: " + t["verdict"])
    w(f"Kernel parameters: `{', '.join(t['params'])}`. Inputs: {t['inputs']}; outputs: {t['outputs']}; E input: {t['has_E_input']}; dt input: {t['has_dt_input']}. "
      f"Relative error vs analytic curl on the adversarial field (16×16×8): Jr {e(t['rel_err_vs_analytic_16x16x8'][0])}, Jφ {e(t['rel_err_vs_analytic_16x16x8'][1])}, Jz {e(t['rel_err_vs_analytic_16x16x8'][2])} (these are discretisation errors, against the corrected reference).  ")
    w(f"**Role:** {t['finding']}\n")

    t = H("002")
    w("### 002 — Cylindrical equations: " + t["verdict"])
    w("| Component | Continuum formula (independently derived) | Source terms found verbatim in CUDA source |")
    w("|---|---|---|")
    for c, f in t["continuum_formulas"].items():
        w(f"| {c} | `{f}` | " + ", ".join(f"`{n}` {'✓' if ok else '✗'}" for n, ok in t["source_terms_found"][c]) + " |")
    w(f"\nSmooth-field convergence (last pair) Jr/Jφ/Jz: {', '.join(f'{x:.3f}' for x in t['smooth_field_orders_last_pair'])}.  \n{t['note']}\n")

    t = H("003")
    w("### 003 — Orientation and signs: " + t["verdict"])
    w("| Case | FP64 max err | FP32 max err | tol (FP64) | sign ok |")
    w("|---|---|---|---|---|")
    c64, c32 = t["cases"]["float64"], t["cases"]["float32"]
    for a, b in zip(c64, c32):
        w(f"| {a['name']} | {e(max(a['errs']))} | {e(max(b['errs']))} | {e(a['tol'])} | {'✓' if a['ok'] and b['ok'] else '✗'} |")
    w("")

    t = H("004")
    w("### 004 — μ₀ normalization: " + t["verdict"])
    w(f"Kernel has a μ₀ parameter: **{t['kernel_has_mu0_parameter']}**. Homogeneity kernel(2.5·B) vs 2.5·kernel(B): {e(t['homogeneity_rel'])} (relative). "
      f"Output vs ∇×B relative error {', '.join(e(x) for x in t['rel_err_output_vs_curlB'])} (O(h²) discretisation, not a factor 1/μ₀). With μ₀ = {t['mu0_used_in_reference']} in the reference, output/μ₀ matches ∇×B/μ₀ to {e(t['rel_err_output_over_mu0_vs_curlB_over_mu0'])}.  ")
    w(f"**Contract:** {t['contract']}\n")

    t = H("005")
    w("### 005 — Yee staggering and strides: " + t["verdict"])
    w("| stride | kernel | expected from array shape |")
    w("|---|---|---|")
    for k in t["expected_strides"]:
        w(f"| `{k}` | {t['kernel_strides'][k]} | {t['expected_strides'][k]} |")
    w(f"\nShapes (16×16×8, g=2): " + "; ".join(f"{k} {tuple(v)}" for k, v in t["shapes"].items()) + ".  ")
    w("Kernel vs independent multi-index reference on random fields:")
    w("| grid | dtype | max abs diff | tol | ok |")
    w("|---|---|---|---|---|")
    for q in t["random_equivalence"]:
        w(f"| {'×'.join(map(str, q['grid']))} | {q['dtype']} | {e(q['max_abs_diff'])} | {e(q['tol'])} | {'✓' if q['ok'] else '✗'} |")
    w("\nSingle-entry probes (unit value in one B entry; footprint = number of J cells responding for Jr/Jφ/Jz; patterns identical to the reference, max diff 0): " +
      "; ".join(f"{'×'.join(map(str, p['grid']))} {p['probe']}→{p['footprint_cells_Jr_Jphi_Jz']}" for p in t["probe_footprints"]) + ".\n")

    t = H("006")
    w("### 006 — Discrete operator order: " + t["verdict"])
    w("Stencils (uniform grid; `BRC/BPC/BZC` = face→center averages, `BPF` = Bφ interpolated to a radial face):")
    w("```\nJr   = (1/r_c)·[BZC(j+1)−BZC(j−1)]/(2dφ) − [BPC(k+1)−BPC(k−1)]/(2dz)\n"
      "Jφ   = [BRC(k+1)−BRC(k−1)]/(2dz) − [BZC(i+1)−BZC(i−1)]/(2dr)\n"
      "Jz   = (1/r_c)·{ [r_f(i+1)·BPF(i+1) − r_f(i)·BPF(i)]/dr − [BRC(j+1)−BRC(j−1)]/(2dφ) }\n```")
    w(t["stencil_accuracy_statement"] + "\n")
    w("Single-term convergence (FP64, 16×16×8 base, 4 levels; criterion: order ≥ " + str(TOL["order_min"]) + "):")
    w("| term | errors (coarse→fine) | last-pair order | ok |")
    w("|---|---|---|---|")
    for k, v in t.items():
        if k.startswith("T"): w(f"| {k} | {', '.join(e(x) for x in v['errs'])} | {v['last_order']:.3f} | {'✓' if v['ok'] else '✗'} |")
    c = t["CT_compat_probe"]
    w("\n**CT-compatibility:** " + c["conclusion"])
    w(f"Generic smooth field, max |div_h J_h| by level: {', '.join(e(r['max_div']) for r in c['SMOOTH']['rows'])}; orders {', '.join(f'{o:.2f}' for o in c['SMOOTH']['orders'])}. "
      f"(Adversarial field: {', '.join(e(r['max_div']) for r in c['ADV']['rows'])} — round-off only, by accidental cancellation; not informative.)  ")
    w("**Verdict meaning:** the stencil order and the CT-incompatibility identification are established. This does **not** make the kernel a CT update.\n")

    t = H("007")
    w("### 007 — Coordinate contract: " + t["verdict"])
    w("Failure reasons:")
    for f in t["fail_reasons"]: w(f"- {f}")
    if not t["fail_reasons"]: w("- (none)")
    w("\n| sanitizer run (exact-size heap buffers, FP64) | result |")
    w("|---|---|")
    for k, lab in (("asan_ghosted_radii_g2", "ghost-extended r arrays, g=2"), ("asan_g1_minimum_ghost", "ghost-extended r arrays, g=1"),
                   ("asan_driver_style_radii_g2", "driver-style r arrays (no ghosts), g=2"), ("asan_g0_invalid_ghost", "g=0")):
        v = t[k]; w(f"| {lab} | {'clean' if v['clean'] else 'ERROR: ' + str(v['error'])} |")
    g = t["guard"]
    if V11:
        w(f"\n**The `1/r` guard.** Removed from the kernel (it was dead code for every supported grid: first centre dr/2). A cell centre at r = 0 is now rejected by the launcher (rejected: **{g.get('pathology_rejected_by_launcher')}**) instead of silently returning 0.  ")
        vm = t.get("validation_matrix") or []
        w("\n**Launcher validation matrix** (`validate_inputs`, pure host check; 'valid' cases must pass, all others must raise `CurlContractError`):")
        w("| group | case | expected | result | ok |")
        w("|---|---|---|---|---|")
        for q_ in vm:
            w(f"| {q_['group']} | {q_['name']} | {'reject' if q_['expect_reject'] else 'accept'} | {'rejected' if q_['rejected'] else ('accepted' if q_['rejected'] is False else 'ERROR')} {('— ' + q_['message']) if q_['message'] else ''} | {'✓' if q_['ok'] else '✗'} |")
    else:
      w(f"\n**The `1/r = 0` guard.** Threshold {g['threshold']:.0e}. For r_min = 0 the first active centre is dr/2 (= {g['supported_geometry_first_center']} at nr=16); the guard can only fire if dr ≤ 2e-8, so it is dead code for every supported grid. "
      f"Where it *would* fire it is wrong, not safe: with a cell centre placed at r = 0, Bφ = r (true Jz = {g['pathology_rc0_Jz_true']}), " + (f"this backend's launcher rejected the grid ({g.get('pathology_exception','')}).  " if g.get('pathology_raised_by_backend') else f"the kernel returns Jz = {g['pathology_rc0_Jz_kernel']} silently. A guard should raise, not zero.  "))
    a = t["axis_cell_with_analytic_ghosts"]; z = t["axis_cell_with_zero_inner_ghosts_(driver_today)"]
    w("\n**Axis-adjacent cell** (smooth Cartesian field with a transverse component on the axis; max error over the cell ring):")
    w("| grid | Jr | Jφ | Jz | (zero inner ghosts) Jr | Jφ | Jz |")
    w("|---|---|---|---|---|---|---|")
    for ra, rz in zip(a["rows"], z["rows"]):
        w(f"| {'×'.join(map(str, ra['n']))} | " + " | ".join(e(x) for x in ra["axis_cell_errs"]) + " | " + " | ".join(e(x) for x in rz["axis_cell_errs"]) + " |")
    w(f"\nLast-pair orders with analytic ghosts: Jr {a['last_orders'][0]:.2f}, Jφ {a['last_orders'][1]:.2f}, **Jz {a['last_orders'][2]:.2f}**. Inner-ghost finding: {t['driver_state_axis_ghost_finding']['statement']} "
      "The axisymmetric Z-pinch has no transverse component on the axis (axis-cell |Jz−1| was 2.2e-16 in the earlier session test, FP64, not re-measured here), so it does not exercise this; an m=1 kink perturbation does have a transverse component on the axis.  ")
    if t.get("asan_axis_grid_g2"):
        w(f"\nAxis-geometry sanitizer run (exact-size heap buffers, r_faces[g] = 0, g=2): {'clean' if t['asan_axis_grid_g2']['clean'] else 'ERROR: ' + str(t['asan_axis_grid_g2']['error'])}.")
    if t.get("axis_grid_global_convergence"):
        w("\n**Axis grids, all cells (FP64, r ∈ [0,1], 4 levels):** max error and last-pair order")
        w("| field | n (finest) | max err Jr / Jφ / Jz | last-pair order Jr / Jφ / Jz | ok |")
        w("|---|---|---|---|---|")
        for nm, v in t["axis_grid_global_convergence"].items():
            w(f"| {nm} | {'×'.join(map(str, v['rows'][-1]['n']))} | {' / '.join(e(x) for x in v['rows'][-1]['errs'])} | {' / '.join(f'{x:.2f}' for x in v['last_orders'])} | {v['component_ok']} |")
        w(f"\nKINK reference (hand derivation) vs 6th-order Cartesian curl: max diff {', '.join(e(x) for x in t['kink_reference_vs_numeric_cartesian'])}.")
        w("\n**Exact axis fields:** " + "; ".join(f"{k}: errs {', '.join(e(x) for x in v['errs'])} (tol {e(v['tol'])}) {'✓' if v['ok'] else '✗'}" for k, v in t["exact_axis_fields"].items()))
        ig = t["inner_ghost_independence"]
        w(f"\n**Inner-ghost independence:** NaN in every inner radial ghost cell → interior bitwise identical: **{ig['bitwise_identical_with_NaN_inner_ghosts']}** (NaNs in interior output: {ig['n_nan_in_interior']}).")
        w("\n**FP32 on axis grids** (KINK; tangential differences divide by ≈ r·dφ, so round-off grows with refinement):")
        w("| n | max abs(FP32 − FP64) | declared bound | ok |")
        w("|---|---|---|---|")
        for q_ in t["axis_grid_fp32_vs_fp64"]:
            w(f"| {'×'.join(map(str, q_['n']))} | {e(q_['fp32_vs_fp64'])} | {e(q_['bound'])} | {'✓' if q_['ok'] else '✗'} |")
    u = t["angular_units"]
    w(f"**Angular units:** dφ must be radians with nφ·dφ = 2π; passing degrees changes the Jr error from {e(u['Jr_err_radians'])} to {e(u['Jr_err_if_dphi_in_degrees'])}; detected by launcher: **{u.get('validator_rejects_degrees', False)}**. Launcher validation tokens found: {t['launcher_validation_tokens_found']}.\n")

    t = H("008")
    w("### 008 — Independent analytic differentiation: " + t["verdict"] + f" (corrected-reference verdict: **{t['corrected_reference_verdict']}**)")
    w(t.get("block_reason", ""))
    w(f"\nField: Br = r² sinφ + z, Bφ = r z² + cosφ, Bz = r² z + sinφ (annulus r∈[0.5,1.5], z∈[−0.5,0.5], full 2π, g=2). Errors vs the corrected reference are discretisation errors; the continuous reference is not the discrete stencil value.")
    for k, g in t["grids"].items():
        w(f"\n**Grid family {k} (×2 refinement, FP64):**")
        w("| level | n | max err Jr | max err Jφ | max err Jz (corrected) |")
        w("|---|---|---|---|---|")
        for i, r in enumerate(g["fp64_vs_corrected"]):
            w(f"| {i} | {'×'.join(map(str, r['n']))} | " + " | ".join(e(x) for x in r["errs"]) + " |")
        w(f"\nLast-pair orders: Jr {g['fp64_last_order'][0]:.2f}, Jφ {g['fp64_last_order'][1]:.2f} (error at round-off: stencil exact for this linear component, order undefined), Jz {g['fp64_last_order'][2]:.2f}. Component pass: {g['component_pass']}.  ")
        w("FP32 vs FP64 kernel output: " + "; ".join(f"{'×'.join(map(str, a['n']))}: {e(a['fp32_vs_fp64'])} ≤ {e(a['bound'])} {'✓' if a['ok'] else '✗'}" for a in g["fp32_vs_fp64"]) + ".")
    w("")

    t = H("009")
    w("### 009 — Output ownership and mutation: " + t["verdict"])
    w("| check | result |")
    w("|---|---|")
    for k in ("all_active_cells_written", "ghost_cells_untouched", "overwrite_not_accumulate", "write_index_injective", "inputs_unchanged"):
        w(f"| {k} | {t[k]} |")
    w(f"| active cells | {t['active_cells']} (write indices unique) |")
    w(f"| aliasing rejected by launcher | {t['launcher_rejects_aliasing']} |")
    w(f"| aliasing prohibited in docs/source | {t['launcher_or_docs_mention_aliasing']} |")
    if "aliased_Jphi_buffer_vs_separate_max_diff" in t["aliasing_demo"]:
        w(f"\nAliasing demonstration (raw kernel, launcher bypassed): Jφ and Jz pointed at one buffer → Jφ silently differs from the separate-buffer result by {e(t['aliasing_demo']['aliased_Jphi_buffer_vs_separate_max_diff'])}. The kernel declares `__restrict__`, so this is undefined behaviour on device.\n")
    for q_ in t.get("aliasing_matrix", []):
        w(f"- aliasing case `{q_['name']}`: {'rejected' if q_['rejected'] else 'ACCEPTED'} {('— ' + q_['message']) if q_['message'] else ''} {'✓' if q_['ok'] else '✗'}")
    w("")

    t = H("010")
    w("### 010 — Operator misidentification trap: " + t["verdict"])
    w(f"{t['meaning_of_PASS']}  ")
    w(f"Interface: no E input ({not t['interface']['has_E_input']}), no dt ({not t['interface']['has_dt_input']}); output at cell centres, whereas CT needs {t['interface']['required_for_CT']}.  ")
    w("Divergence test (annulus 16×16×8; divergence-free B₀ built by circulating an edge potential; update from smooth E):")
    w("| update | max \\|div(ΔΦ)·V\\| / max \\|ΔΦ\\| |")
    w("|---|---|")
    w(f"| correct CT circulation (edge E → face flux, with areas and edge lengths) | {e(t['div_after_correct_CT_faraday_relative_to_update'])} |")
    w(f"| `uct_curl.py` output averaged to faces and used as dB | {e(t['div_after_current_kernel_substitute_relative_to_update'])} |")
    w(f"\nAcceptance threshold {e(t['ct_exact_threshold'])}. Substitute accepted: **{t['current_kernel_accepted_as_CT_replacement']}**. Required future kernel: {t['required_future_kernel']}\n")

    if V11:
        w(f"## Defect register: status in v{KVER}")
        w("| ID | Defect | Status in v1.1 |")
        w("|---|---|---|")
        st12 = {"D5": "closed in v1.2 — axis mode (cubic face→centre interpolation, Cartesian Jz, one-sided radial stencils); Jz 2nd order on axis grids, m=1 KINK field included",
                "D6": "closed at kernel level in v1.2 — inner radial ghosts are never read in axis mode; the driver must still supply the axis face Br(r=0) and ordinary outer/periodic/z ghosts",
                "R1": "closed — policeman's ruling applied (corrected Jz reference)"}
        st = {"D1": "closed — module/kernel/launcher renamed `current_curl`; `uct_curl` slot reserved for the Faraday update (not built)",
              "D2": "closed — `validate_inputs` (see 007 matrix); needs the GPU leg to confirm on cupy arrays",
              "D3": "closed — aliasing rejected by memory-range check and documented (see 009)",
              "D4": "closed — guard removed from the kernel; r_centers ≤ 0 raises",
              "D5": "**OPEN** — axis-adjacent Jz still first order for m=1 field on the axis; Test 007 stays FAIL for this reason",
              "D6": "**OPEN** — driver axis ghost fill; belongs to the driver, not this kernel",
              "D7": "closed — mu0 = 1 contract written in the module docstring and `MU0_CONTRACT`",
              "R1": "**OPEN** — needs the policeman's ruling on the Test 008 reference"}
        names = {"D1": "Slot/label conflict", "D2": "No input validation", "D3": "Aliasing not rejected/documented", "D4": "Silent 1/r → 0 guard",
                 "D5": "Axis-adjacent Jz 1st order", "D6": "Axis ghosts not filled by driver", "D7": "mu0 convention implicit", "R1": "Test 008 reference Jz wrong"}
        if V12: st.update(st12)
        for k_ in ("D1", "D2", "D3", "D4", "D5", "D6", "D7", "R1"):
            w(f"| {k_} | {names[k_]} | {st[k_]} |")
        w("")
    w("## Defect register and proposed fixes (v1.0 findings)" if V11 else "## Defect register and proposed fixes (not applied — kernel is frozen)")
    w("| ID | Defect | Evidence | Proposed fix (as a separate version, `v1.1`) |")
    w("|---|---|---|---|")
    w("| D1 | Slot/label conflict: current-density kernel occupies the `uct_curl` slot | Test 001 | Rename `current_curl`; reserve `uct_curl` for the Faraday update |")
    w("| D2 | No input validation in launcher | Tests 007, 009 | Check shapes (nr+1+2g…), dtype consistency, r-array lengths (nr+1+2g, nr+2g), g ≥ 1, uniform spacing, r_centers[g:g+nr] > 0 (raise), dφ in radians with nφ·dφ ≈ 2π |")
    w("| D3 | Aliasing neither rejected nor documented | Test 009 | Reject overlapping buffers by pointer range; document `__restrict__` contract |")
    w("| D4 | Silent `1/r → 0` guard | Test 007 | Remove from kernel (dead code for supported grids); raise in launcher instead |")
    w("| D5 | Axis-adjacent Jz is 1st order for fields with a transverse component on the axis | Test 007 | Design and test an axis-specific treatment (not yet designed); verify with m=1 perturbations |")
    w("| D6 | Axis ghosts are not filled by the driver (inner radial ghosts stay zero) | Test 007 | Driver-side reflection: even for Bz, odd for Br/Bφ with π shift in φ — separate item for the driver |")
    w("| D7 | μ₀ convention is implicit | Test 004 | Document: output = curl(B); apply 1/μ₀ once outside (ScienceManager already divides) |")
    w("| R1 | Test 008 reference Jz is wrong | Reference check | Replace with Jz = 2z² + cosφ/r − r·cosφ (policeman to confirm) |")

    w("\n## How to run (A100 / L4)")
    w("Put `campaign01.py`, `make_report_campaign01.py`, `uct_curl.py` (target, current version) and the archived baselines `uct_curl_v01.py` (v1.0) and `uct_curl_v02.py` (v1.1) in one folder and run `python3 campaign01.py` (set `UCT_CURL_PATH` to pick another target). "
      "With CuPy and a GPU it adds a `cupy` backend and re-runs all ten tests on the real RawKernel; Test 007's GPU leg additionally runs the device-array validator, device ghost independence and `compute-sanitizer` memcheck/initcheck "
      "(BLOCKED if `compute-sanitizer` is not installed). The environment block (GPU name, CuPy, CUDA runtime, source hash) is written into the results JSON.")
    text = "\n".join(L) + "\n"
    open(os.path.join(here, name), "w").write(text)
    return text

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
    stem = os.environ.get("REPORT_STEM", "uct_curl")
    rn = "campaign01_results.json" if stem == "uct_curl" else f"campaign01_results_{stem}.json"
    R = json.load(open(os.path.join(here, rn)))
    text = build_report(R, here, "CAMPAIGN01_REPORT.md" if stem == "uct_curl" else f"CAMPAIGN01_REPORT_{stem}.md")
    try:
        from IPython import get_ipython
        from IPython.display import display, Markdown
        if get_ipython() is not None: display(Markdown(text))
        else: print(text)
    except Exception:
        print(text)
    print("report written to", os.path.join(here, "CAMPAIGN01_REPORT.md"))
