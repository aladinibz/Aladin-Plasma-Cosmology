#!/usr/bin/env python3
"""
ALADIN v4.0 - Campaign 01: Mathematical identity & operator contract
Target : uct_curl.py (current version; archived versions are uct_curl_v01.py, uct_curl_v02.py)   [executed UNMODIFIED]; select with UCT_CURL_PATH

Backends
  host  : the exact CUDA source string from uct_curl.py is compiled with g++ and run on the CPU.
          This is NOT a GPU and cannot certify CUDA execution or device memory safety.
  cupy  : the real CuPy RawKernel on a GPU. Used automatically when a GPU is present
          (run this same file on the A100); otherwise every GPU leg is reported BLOCKED.

All tolerances / pass criteria below are DECLARED BEFORE EXECUTION.
"""
import os, sys, json, math, hashlib, importlib.util, subprocess, ctypes, re, inspect, tempfile
import datetime, platform, traceback
import numpy as np

# works both as a script and when pasted/exec'd in a notebook cell (no __file__): falls back to the working directory
HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
def _pick_target():
    """Newest kernel file in the folder: uct_curl.py or uct_curl_vNN.py, highest module VERSION wins (ties -> uct_curl.py)."""
    import glob
    best = None
    for p in sorted(glob.glob(os.path.join(HERE, "uct_curl*.py"))):
        try:
            v = re.search(r'^VERSION\s*=\s*"([\d.]+)"', open(p).read(), re.M)
            key = (tuple(int(x) for x in (v.group(1) if v else "1.0").split(".")), os.path.basename(p) == "uct_curl.py")
        except Exception:
            continue
        if best is None or key > best[0]: best = (key, p)
    return best[1] if best else os.path.join(HERE, "uct_curl.py")
KPATH = os.environ.get("UCT_CURL_PATH") or _pick_target()
REGRESS_PATH = os.environ.get("REGRESS_AGAINST", os.path.join(HERE, "uct_curl_v01.py"))   # frozen v1.0 baseline
DRIVER_PATH = os.environ.get("ALADIN_DRIVER_PATH",
    "/mnt/user-data/attachments/743b351a-ac49-5980-a86b-435087f47e14/41860597-Aladin_Driver_v3.1_AIL.py")
OUT = os.environ.get("CAMPAIGN_OUT", HERE)
_sc = "/tmp/claude-0/-home-claude/743b351a-ac49-5980-a86b-435087f47e14/scratchpad"
SCRATCH = os.environ.get("CAMPAIGN_SCRATCH", _sc if os.path.isdir(_sc) else tempfile.mkdtemp())

# ----------------------------------------------------------------------------
# Load the kernel module exactly as submitted (never modified)
# ----------------------------------------------------------------------------
_src_bytes = open(KPATH, "rb").read()
SRC_SHA = hashlib.sha256(_src_bytes).hexdigest()
def load_target(path, tag):
    sp = importlib.util.spec_from_file_location(tag, path)
    m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    kname = re.search(r'void\s+(\w+)\s*\(', m._KERNEL_SRC).group(1)
    launcher = [n for n in dir(m) if n.startswith("launch_") and callable(getattr(m, n))][0]
    return m, kname, launcher
K, KNAME, LAUNCH = load_target(KPATH, "curl_under_test")
KSRC = K._KERNEL_SRC
STEM = os.path.splitext(os.path.basename(KPATH))[0]
IS_V11 = hasattr(K, "validate_inputs")

F64, F32 = np.float64, np.float32
EPS = {F64: 2.220446049250313e-16, F32: 1.1920928955078125e-07}

# ----------------------------------------------------------------------------
# DECLARED CRITERIA (fixed before any result was looked at)
# ----------------------------------------------------------------------------
TOL = dict(
    exact_fp64=1e-12,          # fields the stencil must reproduce exactly (relative to max|J_ref|)
    exact_fp32=2e-5,
    trig_rel=0.05,             # smooth trig fields on 16x16x8: max err <= 5% of max|J_ref|
    uniform_abs=0.05,          # uniform x-hat field must give |J| <= 0.05 on 16x16x8
    order_min=1.8,             # observed convergence order of last refinement pair (fp64)
    equiv_fp64=1e-12,          # kernel vs independent-index reference, relative to max|J|
    fp32_factor=64.0,          # fp32 bound: |err| <= factor * eps32 * Bmax / hmin
    regress_gpu_eps=8.0,       # GPU vs baseline "identical" = within this many machine epsilons of the field scale (host: bitwise)
    homogeneity=1e-12,
    ct_exact=1e-13,            # a CT-compatible update must keep div(B)*V/|flux| below this
)

# ----------------------------------------------------------------------------
# Host backend: compile the exact kernel source with g++
# ----------------------------------------------------------------------------
HOST_PRELUDE = r'''
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#define __global__
struct D3 { int x, y, z; };
static D3 blockIdx, blockDim, threadIdx;
'''
HOST_DRIVER = r'''
extern "C" void host_launch(const real* Br, const real* Bphi, const real* Bz,
    real* Jr, real* Jphi, real* Jz, const real* rf, const real* rc,
    real dr, real dphi, real dz, int nr, int nphi, int nz, int g)
{
  blockDim.x = 8; blockDim.y = 8; blockDim.z = 4;     /* same shape as the module launcher */
  int bx = (nr + 7)/8, by = (nphi + 7)/8, bz = (nz + 3)/4;
  for (int a = 0; a < bx; a++) for (int b = 0; b < by; b++) for (int c = 0; c < bz; c++) {
    blockIdx.x = a; blockIdx.y = b; blockIdx.z = c;
    for (int x = 0; x < 8; x++) for (int y = 0; y < 8; y++) for (int z = 0; z < 4; z++) {
      threadIdx.x = x; threadIdx.y = y; threadIdx.z = z;
      KERNEL_NAME(Br, Bphi, Bz, Jr, Jphi, Jz, rf, rc, dr, dphi, dz, nr, nphi, nz, g);
    }
  }
}
'''
HOST_DRIVER_AX = HOST_DRIVER.replace("real dr, real dphi, real dz, int nr, int nphi, int nz, int g)",
    "real dr, real dphi, real dz, int nr, int nphi, int nz, int g,\n    const real* cph, const real* sph, real sdphi, int axis)").replace(
    "nr, nphi, nz, g);\n    }", "nr, nphi, nz, g, cph, sph, sdphi, axis);\n    }")
ASAN_MAIN = r'''
int main(int argc, char** argv) {
  int nr = atoi(argv[1]), nphi = atoi(argv[2]), nz = atoi(argv[3]), g = atoi(argv[4]), rmode = atoi(argv[5]);
  int nzg = nz + 2*g, npg = nphi + 2*g, nrg = nr + 2*g;
  size_t nBr = (size_t)(nrg+1)*npg*nzg, nBp = (size_t)nrg*(npg+1)*nzg, nBz = (size_t)nrg*npg*(nzg+1), nJ = (size_t)nrg*npg*nzg;
  real *Br = (real*)malloc(nBr*sizeof(real)), *Bp = (real*)malloc(nBp*sizeof(real)), *Bz = (real*)malloc(nBz*sizeof(real));
  real *Jr = (real*)calloc(nJ, sizeof(real)), *Jp = (real*)calloc(nJ, sizeof(real)), *Jz = (real*)calloc(nJ, sizeof(real));
  for (size_t i = 0; i < nBr; i++) Br[i] = 0.5; for (size_t i = 0; i < nBp; i++) Bp[i] = 0.5; for (size_t i = 0; i < nBz; i++) Bz[i] = 0.5;
  size_t nrf = rmode != 1 ? (size_t)(nr+1+2*g) : (size_t)(nr+1);   /* rmode 1 = driver-style, no ghosts; 2 = axis grid */
  size_t nrc = rmode != 1 ? (size_t)(nr+2*g)   : (size_t)nr;
  real *rf = (real*)malloc(nrf*sizeof(real)), *rc = (real*)malloc(nrc*sizeof(real));
  for (size_t i = 0; i < nrf; i++) rf[i] = rmode == 2 ? 0.1*((double)i - g) : 0.5 + 0.1*(double)i;
  for (size_t i = 0; i < nrc; i++) rc[i] = rmode == 2 ? 0.1*((double)i - g + 0.5) : 0.55 + 0.1*(double)i;
  /*XDECL*/
  host_launch(Br, Bp, Bz, Jr, Jp, Jz, rf, rc, 0.1, 0.1, 0.1, nr, nphi, nz, g/*XARGS*/);
  printf("completed without sanitizer error\n");
  return 0;
}
'''

XDECL_AX = r'''
  real *cph = (real*)malloc((nphi+2*g)*sizeof(real)), *sph = (real*)malloc((nphi+2*g)*sizeof(real));
  for (int i = 0; i < nphi+2*g; i++) { cph[i] = (real)cos(0.1*(i-g+0.5)); sph[i] = (real)sin(0.1*(i-g+0.5)); }
  int axis = (rmode == 2) ? 1 : 0;
'''
XARGS_AX = ", cph, sph, (real)sin(0.1), axis"
HAS_AX = "cos_pc" in KSRC

class HostBackend:
    name = "host"
    label = "CUDA source compiled with g++, executed on CPU (not a GPU)"
    def __init__(self, ksrc=None, kname=None, tag=""):
        self.libs = {}; self.ksrc = ksrc or KSRC; self.kname = kname or KNAME; self.tag = tag
        self.has_axis = "cos_pc" in self.ksrc
    def _lib(self, dtype):
        key = np.dtype(dtype).name
        if key not in self.libs:
            real = {"float32": "float", "float64": "double"}[key]
            code = HOST_PRELUDE + self.ksrc.replace("REAL_T", real) + (HOST_DRIVER_AX if self.has_axis else HOST_DRIVER).replace("KERNEL_NAME", self.kname)
            cpp = os.path.join(SCRATCH, f"host_{self.tag}{key}.cpp"); so = os.path.join(SCRATCH, f"host_{self.tag}{key}.so")
            open(cpp, "w").write(code)
            subprocess.check_call(["g++", "-O2", "-shared", "-fPIC", "-o", so, cpp])
            lib = ctypes.CDLL(so); f = lib.host_launch
            ct = ctypes.c_float if key == "float32" else ctypes.c_double
            f.argtypes = [ctypes.c_void_p]*8 + [ct]*3 + [ctypes.c_int]*4 + ([ctypes.c_void_p]*2 + [ct, ctypes.c_int] if self.has_axis else [])
            f.restype = None
            self.libs[key] = (lib, f, ct, hashlib.sha256(code.encode()).hexdigest())
        return self.libs[key]
    def gen_sha(self, dtype):
        return self._lib(dtype)[3]
    def run(self, Br, Bp, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g, J=None, ptr_override=None):
        dt = Br.dtype.type
        _, f, ct, _ = self._lib(dt)
        shp = (nr + 2*g, nphi + 2*g, nz + 2*g)
        if J is None:
            J = [np.full(shp, np.nan, dtype=dt) for _ in range(3)]
        arrs = [np.ascontiguousarray(a) for a in (Br, Bp, Bz)]
        rf = np.ascontiguousarray(rf.astype(dt)); rc = np.ascontiguousarray(rc.astype(dt))
        outs = ptr_override if ptr_override is not None else J
        extra = []
        if self.has_axis:
            phi_c = (np.arange(nphi + 2*g) - g + 0.5)*dphi
            cph = np.ascontiguousarray(np.cos(phi_c).astype(dt)); sph = np.ascontiguousarray(np.sin(phi_c).astype(dt))
            extra = [cph.ctypes.data, sph.ctypes.data, ct(math.sin(dphi)), int(rf[g] == 0.0)]
        f(*[a.ctypes.data for a in arrs], *[o.ctypes.data for o in outs], rf.ctypes.data, rc.ctypes.data,
          ct(dr), ct(dphi), ct(dz), nr, nphi, nz, g, *extra)
        return J

class CupyBackend:
    name = "cupy"
    label = "CuPy RawKernel on GPU"
    def __init__(self, mod=None, launcher=None):
        self.mod = mod or K; self.launcher = launcher or LAUNCH
    @staticmethod
    def available():
        try:
            import cupy as cp
            return cp.cuda.runtime.getDeviceCount() > 0
        except Exception:
            return False
    def run(self, Br, Bp, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g, J=None, ptr_override=None):
        import cupy as cp
        dt = Br.dtype.type
        shp = (nr + 2*g, nphi + 2*g, nz + 2*g)
        d = [cp.asarray(a) for a in (Br, Bp, Bz)]
        dJ = [cp.asarray(x) for x in J] if J is not None else [cp.full(shp, np.nan, dtype=dt) for _ in range(3)]
        getattr(self.mod, self.launcher)(*d, *dJ, cp.asarray(rf.astype(dt)), cp.asarray(rc.astype(dt)), dr, dphi, dz, nr, nphi, nz, g)
        cp.cuda.Device().synchronize()
        return [cp.asnumpy(x) for x in dJ]

# ----------------------------------------------------------------------------
# Grid + analytic fields (harness-owned; independent of the kernel module)
# ----------------------------------------------------------------------------
class Grid:
    def __init__(s, nr, nphi, nz, g=2, r0=0.5, r1=1.5, z0=-0.5, z1=0.5):
        s.nr, s.nphi, s.nz, s.g, s.r0, s.z0 = nr, nphi, nz, g, r0, z0
        s.dr = (r1 - r0)/nr; s.dphi = 2*math.pi/nphi; s.dz = (z1 - z0)/nz
        a = np.arange
        s.rf = r0 + (a(nr + 1 + 2*g) - g)*s.dr
        s.rc = r0 + (a(nr + 2*g) - g + 0.5)*s.dr
        s.pc = (a(nphi + 2*g) - g + 0.5)*s.dphi
        s.pf = (a(nphi + 1 + 2*g) - g)*s.dphi
        s.zc = z0 + (a(nz + 2*g) - g + 0.5)*s.dz
        s.zf = z0 + (a(nz + 1 + 2*g) - g)*s.dz
        s.sl = (slice(g, g + nr), slice(g, g + nphi), slice(g, g + nz))
    @staticmethod
    def mesh(a, b, c):
        return np.meshgrid(a, b, c, indexing="ij")
    def sample(s, fld, dtype):
        Br = fld.Br(*s.mesh(s.rf, s.pc, s.zc)); Bp = fld.Bp(*s.mesh(s.rc, s.pf, s.zc)); Bz = fld.Bz(*s.mesh(s.rc, s.pc, s.zf))
        return [np.ascontiguousarray(x.astype(dtype)) for x in (Br, Bp, Bz)]
    def ref(s, fld):
        g = s.g
        R, P, Z = s.mesh(s.rc[g:g + s.nr], s.pc[g:g + s.nphi], s.zc[g:g + s.nz])
        return [fld.Jr(R, P, Z), fld.Jp(R, P, Z), fld.Jz(R, P, Z)]
    def run(s, be, B, dtype, J=None):
        return be.run(*B, s.rf.astype(dtype), s.rc.astype(dtype), s.dr, s.dphi, s.dz, s.nr, s.nphi, s.nz, s.g, J=J)

class Field:
    def __init__(s, Br, Bp, Bz, Jr, Jp, Jz, name=""):
        s.Br, s.Bp, s.Bz, s.Jr, s.Jp, s.Jz, s.name = Br, Bp, Bz, Jr, Jp, Jz, name

zero = lambda r, p, z: np.zeros_like(r)
const = lambda c: (lambda r, p, z: np.full_like(r, c))

# policeman's adversarial field. Jr, Jp as supplied; Jz CORRECTED (supplied Jz is wrong, see verify_reference.py)
ADV = Field(lambda r, p, z: r**2*np.sin(p) + z, lambda r, p, z: r*z**2 + np.cos(p), lambda r, p, z: r**2*z + np.sin(p),
            lambda r, p, z: np.cos(p)/r - 2*r*z, lambda r, p, z: 1 - 2*r*z,
            lambda r, p, z: 2*z**2 + np.cos(p)/r - r*np.cos(p), "ADV(corrected Jz)")
ADV_SUPPLIED_JZ = lambda r, p, z: 2*z - np.cos(p)/r

def _smooth_parts(r, p, z):
    x, y = r*np.cos(p), r*np.sin(p)
    return x, y, z
def _smooth_B(r, p, z):
    x, y, z = _smooth_parts(r, p, z)
    Bx, By, Bzc = np.sin(y) + z**2, z*np.cos(x), x*y*z + np.sin(z)
    return Bx, By, Bzc
def _smooth_J(r, p, z):
    x, y, z = _smooth_parts(r, p, z)
    return x*z - np.cos(x), 2*z - y*z, -z*np.sin(x) - np.cos(y)
# smooth Cartesian field, valid across the axis (negative r = analytic continuation)
SMOOTH = Field(
    lambda r, p, z: _smooth_B(r, p, z)[0]*np.cos(p) + _smooth_B(r, p, z)[1]*np.sin(p),
    lambda r, p, z: -_smooth_B(r, p, z)[0]*np.sin(p) + _smooth_B(r, p, z)[1]*np.cos(p),
    lambda r, p, z: _smooth_B(r, p, z)[2],
    lambda r, p, z: _smooth_J(r, p, z)[0]*np.cos(p) + _smooth_J(r, p, z)[1]*np.sin(p),
    lambda r, p, z: -_smooth_J(r, p, z)[0]*np.sin(p) + _smooth_J(r, p, z)[1]*np.cos(p),
    lambda r, p, z: _smooth_J(r, p, z)[2], "SMOOTH(Cartesian)")

def _cart_field(Bx, By, Bz, Jx, Jy, Jz, name):
    """Cylindrical Field from Cartesian component functions of (x, y, z) (valid across the axis)."""
    def comp(fx, fy, which):
        def f(r, p, z):
            x, y = r*np.cos(p), r*np.sin(p)
            a, b = fx(x, y, z), fy(x, y, z)
            return a*np.cos(p) + b*np.sin(p) if which == "r" else -a*np.sin(p) + b*np.cos(p)
        return f
    return Field(comp(Bx, By, "r"), comp(Bx, By, "p"), lambda r, p, z: Bz(r*np.cos(p), r*np.sin(p), z),
                 comp(Jx, Jy, "r"), comp(Jx, Jy, "p"), lambda r, p, z: Jz(r*np.cos(p), r*np.sin(p), z), name)
# m=1 'kink-like' field: uniform transverse component 0.5/-0.3 on the axis plus x*y, x^2, x^3, x*y^2 terms.
#   Bx = 0.5 + x*y + sin z + x*y^2        By = -0.3 + x^2 + z*y + x^3        Bz = 0.2*x*z + y^3
#   Jx = dBz/dy - dBy/dz = 3y^2 - y       Jy = dBx/dz - dBz/dx = cos z - 0.2 z
#   Jz = dBy/dx - dBx/dy = (2x + 3x^2) - (x + 2xy) = x + 3x^2 - 2xy
KINK = _cart_field(lambda x, y, z: 0.5 + x*y + np.sin(z) + x*y**2, lambda x, y, z: -0.3 + x**2 + z*y + x**3, lambda x, y, z: 0.2*x*z + y**3,
                   lambda x, y, z: 3*y**2 - y, lambda x, y, z: np.cos(z) - 0.2*z, lambda x, y, z: x + 3*x**2 - 2*x*y, "KINK(m=1, Cartesian)")

def kink_reference_check():
    """KINK's hand-derived curl vs a 6th-order Cartesian finite-difference curl (no cylindrical formulas)."""
    f = [lambda x, y, z: 0.5 + x*y + np.sin(z) + x*y**2, lambda x, y, z: -0.3 + x**2 + z*y + x**3, lambda x, y, z: 0.2*x*z + y**3]
    def dd(fn, axis, pt, h=1e-3):
        c = np.array([-1/60, 3/20, -3/4, 0, 3/4, -3/20, 1/60]); out = 0.0
        for k, ck in zip(range(-3, 4), c):
            if ck == 0: continue
            q = list(pt); q[axis] = q[axis] + k*h; out = out + ck*fn(*q)
        return out/h
    rng = np.random.default_rng(5); pt = (rng.uniform(-1, 1, 200), rng.uniform(-1, 1, 200), rng.uniform(-1, 1, 200))
    x, y, z = pt
    num = (dd(f[2], 1, pt) - dd(f[1], 2, pt), dd(f[0], 2, pt) - dd(f[2], 0, pt), dd(f[1], 0, pt) - dd(f[0], 1, pt))
    ref = (3*y**2 - y, np.cos(z) - 0.2*z, x + 3*x**2 - 2*x*y)
    return [float(np.max(np.abs(a - b))) for a, b in zip(num, ref)]

def err_vs_ref(G, J, ref):
    return [float(np.max(np.abs(J[c][G.sl].astype(np.float64) - ref[c]))) for c in range(3)]

def conv(be, fld, base, levels, dtype, r0=0.5, r1=1.5, jz_ref=None):
    rows = []
    for L in range(levels):
        n = tuple(b*2**L for b in base)
        G = Grid(*n, g=2, r0=r0, r1=r1)
        J = G.run(be, G.sample(fld, dtype), dtype)
        ref = G.ref(fld)
        if jz_ref is not None:
            R, P, Z = G.mesh(G.rc[2:2 + G.nr], G.pc[2:2 + G.nphi], G.zc[2:2 + G.nz]); ref[2] = jz_ref(R, P, Z)
        rows.append(dict(n=list(n), errs=err_vs_ref(G, J, ref), finite=bool(np.isfinite(J[0][G.sl]).all()), Jmax=[float(np.max(np.abs(x))) for x in ref]))
    return rows

def orders(rows):
    out = []
    for c in range(3):
        o = []
        for a, b in zip(rows[:-1], rows[1:]):
            o.append(math.inf if b["errs"][c] == 0 else (math.nan if a["errs"][c] == 0 else math.log2(a["errs"][c]/b["errs"][c])))
        out.append(o)
    return out

# ----------------------------------------------------------------------------
# Independent-index reference operator (multi-dimensional slicing, no flat strides)
# ----------------------------------------------------------------------------
def ref_curl(Br, Bp, Bz, rf, rc, dr, dphi, dz, nr, nphi, nz, g):
    Br, Bp, Bz, rf, rc = [np.asarray(x, dtype=np.float64) for x in (Br, Bp, Bz, rf, rc)]
    sh = lambda A, i, j, k: A[g + i:g + i + nr, g + j:g + j + nphi, g + k:g + k + nz]
    BRC = lambda i, j, k: 0.5*(sh(Br, i, j, k) + sh(Br, i + 1, j, k))
    BPC = lambda i, j, k: 0.5*(sh(Bp, i, j, k) + sh(Bp, i, j + 1, k))
    BZC = lambda i, j, k: 0.5*(sh(Bz, i, j, k) + sh(Bz, i, j, k + 1))
    BPF = lambda i: 0.5*(BPC(i - 1, 0, 0) + BPC(i, 0, 0))
    r_c = rc[g:g + nr][:, None, None]
    inv = np.where(r_c > 1e-8, 1.0/np.where(r_c > 1e-8, r_c, 1.0), 0.0)
    rfp = rf[g + 1:g + 1 + nr][:, None, None]; rfm = rf[g:g + nr][:, None, None]
    Jr = inv*(BZC(0, 1, 0) - BZC(0, -1, 0))/(2*dphi) - (BPC(0, 0, 1) - BPC(0, 0, -1))/(2*dz)
    Jp = (BRC(0, 0, 1) - BRC(0, 0, -1))/(2*dz) - (BZC(1, 0, 0) - BZC(-1, 0, 0))/(2*dr)
    Jz = inv*((rfp*BPF(1) - rfm*BPF(0))/dr - (BRC(0, 1, 0) - BRC(0, -1, 0))/(2*dphi))
    return [Jr, Jp, Jz]

# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
GRIDS = [(16, 16, 8), (17, 11, 9)]
DTYPES = [F64, F32]
def dn(d): return np.dtype(d).name

def fp32_bound(G, Bmax, dtype=F32):
    hmin = min(G.dr, G.dz, G.rc[G.g]*G.dphi)
    return TOL["fp32_factor"]*EPS[dtype]*Bmax/hmin

def asan_run(nr, nphi, nz, g, rmode):
    am = ASAN_MAIN.replace("/*XDECL*/", XDECL_AX if HAS_AX else "").replace("/*XARGS*/", XARGS_AX if HAS_AX else "")
    code = HOST_PRELUDE + KSRC.replace("REAL_T", "double") + (HOST_DRIVER_AX if HAS_AX else HOST_DRIVER).replace("KERNEL_NAME", KNAME) + am
    cpp = os.path.join(SCRATCH, "asan_target.cpp"); exe = os.path.join(SCRATCH, "asan_target")
    open(cpp, "w").write(code)
    subprocess.check_call(["g++", "-g", "-O0", "-fsanitize=address", "-o", exe, cpp])
    p = subprocess.run([exe, str(nr), str(nphi), str(nz), str(g), str(rmode)], capture_output=True, text=True,
                       env=dict(os.environ, ASAN_OPTIONS="detect_leaks=0"))
    text = (p.stdout + p.stderr)
    m = re.search(r"ERROR: AddressSanitizer: ([\w-]+)", text)
    lines = [l for l in text.splitlines() if l.startswith("    #") or "ERROR" in l or "READ of" in l or "WRITE of" in l]
    return dict(rc=p.returncode, error=m.group(1) if m else None, clean="completed without sanitizer error" in text, excerpt=lines[:5])

def launcher_source():
    src = inspect.getsource(getattr(K, LAUNCH))
    if IS_V11: src += inspect.getsource(K.validate_inputs)
    return src


# ----------------------------------------------------------------------------
# Launcher-validation matrix (v1.1 only): every case is run through the module's pure host validator
# ----------------------------------------------------------------------------
def validation_matrix():
    if not IS_V11:
        return None
    def base(dtype=F64, grid=None):
        grid = grid or Grid(16, 16, 8); g = grid.g
        B = grid.sample(ADV, dtype); shp = (grid.nr + 2*g, grid.nphi + 2*g, grid.nz + 2*g)
        return dict(Br=B[0], Bphi=B[1], Bz=B[2], Jr=np.zeros(shp, dtype), Jphi=np.zeros(shp, dtype), Jz=np.zeros(shp, dtype),
                    r_faces=grid.rf.astype(dtype), r_centers=grid.rc.astype(dtype), dr=grid.dr, dphi=grid.dphi, dz=grid.dz,
                    nr=grid.nr, nphi=grid.nphi, nz=grid.nz, g=g, full_circle=True)
    def call(a):
        K.validate_inputs(a["Br"], a["Bphi"], a["Bz"], a["Jr"], a["Jphi"], a["Jz"], a["r_faces"], a["r_centers"],
                          a["dr"], a["dphi"], a["dz"], a["nr"], a["nphi"], a["nz"], a["g"], a["full_circle"])
    def mut(f, dtype=F64, grid=None):
        a = base(dtype, grid); f(a); return a
    shp = lambda a: a["Jr"].shape; N = lambda a: a["Jr"].size
    def big_overlap(a):
        big = np.zeros(int(N(a)*1.5)); a["Jr"] = big[:N(a)].reshape(shp(a)); a["Jphi"] = big[N(a)//2:N(a)//2 + N(a)].reshape(shp(a))
    cases = [
      # name, group, expect_reject, args
      ("valid FP64 16x16x8 annulus", "valid", False, base(F64)),
      ("valid FP32 16x16x8 annulus", "valid", False, base(F32)),
      ("valid FP64 17x11x9 annulus", "valid", False, base(F64, Grid(17, 11, 9))),
      ("valid FP32 17x11x9 annulus", "valid", False, base(F32, Grid(17, 11, 9))),
      ("valid FP64 with axis (r_min=0)", "valid", False, base(F64, Grid(16, 16, 8, r0=0.0, r1=1.0))),
      ("valid wedge (full_circle=False, quarter turn)", "valid", False, mut(lambda a: a.update(dphi=a["dphi"]/4, full_circle=False))),
      ("valid FP64 g=1 annulus", "valid", False, base(F64, Grid(16, 16, 8, g=1))),
      ("axis grid with g=1", "grid", True, base(F64, Grid(16, 16, 8, g=1, r0=0.0, r1=1.0))),
      ("axis grid with nr=2", "grid", True, base(F64, Grid(2, 16, 8, r0=0.0, r1=0.2))),
      ("g=0", "grid", True, mut(lambda a: a.update(g=0))),
      ("g=-1", "grid", True, mut(lambda a: a.update(g=-1))),
      ("nr=0", "grid", True, mut(lambda a: a.update(nr=0))),
      ("non-integer nr (16.0)", "grid", True, mut(lambda a: a.update(nr=16.0))),
      ("dr=0", "grid", True, mut(lambda a: a.update(dr=0.0))),
      ("dr<0", "grid", True, mut(lambda a: a.update(dr=-0.1))),
      ("dr=NaN", "grid", True, mut(lambda a: a.update(dr=float("nan")))),
      ("dphi in degrees", "angle", True, mut(lambda a: a.update(dphi=math.degrees(a["dphi"])))),
      ("dphi wrong span (full circle)", "angle", True, mut(lambda a: a.update(dphi=0.5*a["dphi"]))),
      ("wedge span > 2pi", "angle", True, mut(lambda a: a.update(dphi=2*a["dphi"], full_circle=False))),
      ("Br missing a plane (shape)", "shape", True, mut(lambda a: a.update(Br=np.ascontiguousarray(a["Br"][:-1])))),
      ("Bphi wrong phi size", "shape", True, mut(lambda a: a.update(Bphi=np.ascontiguousarray(a["Bphi"][:, :-1])))),
      ("Jz wrong shape", "shape", True, mut(lambda a: a.update(Jz=np.zeros((3, 3, 3))))),
      ("driver-style r arrays (no ghosts)", "shape", True, mut(lambda a: a.update(r_faces=a["r_faces"][a["g"]:a["g"] + a["nr"] + 1].copy(), r_centers=a["r_centers"][a["g"]:a["g"] + a["nr"]].copy()))),
      ("mixed dtype (Jr float32)", "dtype", True, mut(lambda a: a.update(Jr=a["Jr"].astype(np.float32)))),
      ("integer B arrays", "dtype", True, mut(lambda a: a.update(Br=a["Br"].astype(np.int32)))),
      ("Fortran-ordered Br", "layout", True, mut(lambda a: a.update(Br=np.asfortranarray(a["Br"])))),
      ("r_center of first active cell = 0", "radial", True, base(F64, Grid(16, 16, 8, r0=-0.5/16, r1=1 - 0.5/16))),
      ("negative active radii", "radial", True, base(F64, Grid(16, 16, 8, r0=-0.3, r1=0.7))),
    ] + ([
      # start-radius / axis-closure contract added in v1.3 (Campaign 02 findings D8, D9; D10 = grid straddling the axis)
      ("ambiguous start radius 1e-9*dr", "radial", True, base(F64, Grid(16, 16, 8, r0=1e-9/16, r1=1e-9/16 + 1.0))),
      ("round-off start radius 1e-17", "radial", True, base(F64, Grid(16, 16, 8, r0=1e-17, r1=1.0))),
      ("grid straddles the axis (r_faces[g] = -0.25 dr)", "radial", True, base(F64, Grid(16, 16, 8, r0=-0.25/16, r1=1 - 0.25/16))),
      ("axis grid with nphi=2", "grid", True, base(F64, Grid(8, 2, 4, r0=0.0, r1=1.0))),
      ("axis grid with nphi=1", "grid", True, base(F64, Grid(8, 1, 4, r0=0.0, r1=1.0))),
      ("valid annulus r_faces[g] = 1.5e-3 dr (just above the ambiguity band)", "valid", False, base(F64, Grid(16, 16, 8, r0=1.5e-3/16, r1=1.5e-3/16 + 1.0))),
      ("valid axis grid with nphi=3", "valid", False, base(F64, Grid(8, 3, 4, r0=0.0, r1=1.0))),
    ] if hasattr(K, "AXIS_AMBIGUITY_FRACTION") else []) + [
      ("non-uniform r_faces", "radial", True, mut(lambda a: a["r_faces"].__setitem__(5, a["r_faces"][5] + 0.3*a["dr"]))),
      ("r_centers not midpoints", "radial", True, mut(lambda a: a["r_centers"].__setitem__(5, a["r_centers"][5] + 0.3*a["dr"]))),
      ("NaN in r_faces", "radial", True, mut(lambda a: a["r_faces"].__setitem__(5, np.nan))),
      ("alias: Jphi is Jz", "alias", True, mut(lambda a: a.update(Jphi=a["Jz"]))),
      ("alias: Jr is Jr-of-Jphi (same buffer)", "alias", True, mut(lambda a: a.update(Jr=a["Jphi"]))),
      ("alias: Jr/Jphi partially overlapping views", "alias", True, mut(big_overlap)),
      ("alias: Jz is a view into Bz", "alias", True, mut(lambda a: a.update(Jz=a["Bz"].ravel()[:a["Jz"].size].reshape(a["Jz"].shape)))),
      ("alias: Jphi is a view into Br", "alias", True, mut(lambda a: a.update(Jphi=a["Br"].ravel()[:a["Jphi"].size].reshape(a["Jphi"].shape)))),
    ]
    rows = []
    for name, group, expect, a in cases:
        try:
            call(a); rejected = False; msg = ""
        except K.CurlContractError as ex:
            rejected = True; msg = str(ex)[:110]
        except Exception as ex:
            rejected = None; msg = f"UNEXPECTED {type(ex).__name__}: {ex}"[:110]
        rows.append(dict(name=name, group=group, expect_reject=expect, rejected=rejected, ok=bool(rejected is expect), message=msg))
    return rows

def vm_ok(rows, groups):
    sel = [r for r in rows if r["group"] in groups]
    return all(r["ok"] for r in sel), [r["name"] for r in sel if not r["ok"]]

# ============================================================================
# TESTS
# ============================================================================
def pre_reference_check():
    """Gate before Test 008: the supplied reference currents vs an independent Cartesian derivation.
    Self-contained (no helper file): Cartesian vector field -> 6th-order central-difference curl in x,y,z -> project to (r,phi,z).
    No cylindrical curl formula is used."""
    def Bcyl(r, ph, z):
        return (r**2*np.sin(ph) + z, r*z**2 + np.cos(ph), r**2*z + np.sin(ph))
    def Bcart(x, y, z):
        r = np.hypot(x, y); ph = np.arctan2(y, x)
        br, bp, bz = Bcyl(r, ph, z)
        return (br*np.cos(ph) - bp*np.sin(ph), br*np.sin(ph) + bp*np.cos(ph), bz)
    def dd(f, axis, pt, h=1e-3):
        c = np.array([-1/60, 3/20, -3/4, 0, 3/4, -3/20, 1/60]); out = 0.0
        for k, ck in zip(range(-3, 4), c):
            if ck == 0: continue
            q = list(pt); q[axis] = q[axis] + k*h
            out = out + ck*f(*q)
        return out/h
    rng = np.random.default_rng(1)
    rs = rng.uniform(0.5, 1.5, 200); phs = rng.uniform(0, 2*np.pi, 200); zs = rng.uniform(-0.5, 0.5, 200)
    x, y = rs*np.cos(phs), rs*np.sin(phs); pt = (x, y, zs)
    comp = lambda i: (lambda *q: Bcart(*q)[i])
    Jx = dd(comp(2), 1, pt) - dd(comp(1), 2, pt)
    Jy = dd(comp(0), 2, pt) - dd(comp(2), 0, pt)
    Jzn = dd(comp(1), 0, pt) - dd(comp(0), 1, pt)
    Jrn = Jx*np.cos(phs) + Jy*np.sin(phs); Jpn = -Jx*np.sin(phs) + Jy*np.cos(phs)
    sup_r = np.cos(phs)/rs - 2*rs*zs; sup_p = 1 - 2*rs*zs; sup_z = 2*zs - np.cos(phs)/rs
    cor_z = 2*zs**2 + np.cos(phs)/rs - rs*np.cos(phs)
    out = dict(Jr_supplied_vs_numeric=float(np.abs(Jrn - sup_r).max()), Jphi_supplied_vs_numeric=float(np.abs(Jpn - sup_p).max()),
               Jz_supplied_vs_numeric=float(np.abs(Jzn - sup_z).max()), Jz_corrected_vs_numeric=float(np.abs(Jzn - cor_z).max()))
    out["raw"] = "\n".join(f"{k}: {v:.3e}" for k, v in out.items())
    return out

def t001(be):
    sig = re.search(re.escape(KNAME) + r'\((.*?)\)\s*\{', KSRC, re.S).group(1)
    params = [p.strip().split()[-1].lstrip("*") for p in sig.split(",")]
    has_E = any(p in ("E", "Er", "Ephi", "Ez", "emf", "emf_r", "emf_phi", "emf_z") for p in params)
    has_dt = "dt" in params
    inputs = [p for p in params if p in ("Br", "Bphi", "Bz")]
    outputs = [p for p in params if p in ("Jr", "Jphi", "Jz")]
    # numerical: output equals curl(B) of the field (not a time update)
    G = Grid(16, 16, 8); J = G.run(be, G.sample(ADV, F64), F64); ref = G.ref(ADV)
    rel = [e/np.max(np.abs(r)) for e, r in zip(err_vs_ref(G, J, ref), ref)]
    drv = None
    if os.path.exists(DRIVER_PATH):
        lines = open(DRIVER_PATH).read().splitlines()
        drv = {k: lines[i].strip() for i, k in [(7, "sequence_comment_L8"), (383, "L384"), (384, "L385")] if i < len(lines)}
    ok = (not has_E) and (not has_dt) and inputs == ["Br", "Bphi", "Bz"] and outputs == ["Jr", "Jphi", "Jz"] and max(rel) < 0.05
    return dict(verdict="PASS" if ok else "FAIL", params=params, has_E_input=has_E, has_dt_input=has_dt,
                inputs=inputs, outputs=outputs, rel_err_vs_analytic_16x16x8=rel,
                driver_slot_lines=drv,
                finding="Kernel is current-density reconstruction J=curl(B), cell-centered. It sits in the driver slot named 'uct_curl' "
                        "(slot 9, after uct_emf), which in a CT pair is the Faraday curl(E)->B update. Role in ALADIN = 'current_curl' "
                        "(J for Hall/resistive terms and J x B); it is NOT the CT magnetic update.")

SRC_TERMS = {
    "Jr":   [("dBz_dphi", "(BZC(gi,gj+1,gk) - BZC(gi,gj-1,gk))*i2dphi"), ("dBp_dz", "(BPC(gi,gj,gk+1) - BPC(gi,gj,gk-1))*i2dz"),
             ("Jr", "Jr  [c] = inv*dBz_dphi - dBp_dz;")],
    "Jphi": [("dBr_dz", "(BRC(gi,gj,gk+1) - BRC(gi,gj,gk-1))*i2dz"), ("dBz_dr", "(BZC(gi+1,gj,gk) - BZC(gi-1,gj,gk))*i2dr"),
             ("Jphi", "Jphi[c] = dBr_dz - dBz_dr;")],
    "Jz":   [("rBp_hi", "r_faces[gi+1]*BPF(gi+1,gj,gk)"), ("rBp_lo", "r_faces[gi  ]*BPF(gi  ,gj,gk)"),
             ("dBr_dphi", "(BRC(gi,gj+1,gk) - BRC(gi,gj-1,gk))*i2dphi"), ("Jz", "Jz  [c] = inv*((rBp_hi - rBp_lo)/dr - dBr_dphi);")],
}
CONT = {"Jr": "(1/r) dBz/dphi - dBphi/dz", "Jphi": "dBr/dz - dBz/dr", "Jz": "(1/r) d(r Bphi)/dr - (1/r) dBr/dphi"}

def t002(be):
    found = {c: [(n, s in KSRC) for n, s in terms] for c, terms in SRC_TERMS.items()}
    all_found = all(f for v in found.values() for _, f in v)
    # numeric confirmation on smooth field incl. all three components, last-pair order
    rows = conv(be, SMOOTH, (16, 16, 8), 4, F64, r0=0.5, r1=1.5)
    o = orders(rows)
    ok = all_found and all(x[-1] >= TOL["order_min"] for x in o)
    return dict(verdict="PASS" if ok else "FAIL", continuum_formulas=CONT, source_terms_found=found,
                smooth_field_orders_last_pair=[x[-1] for x in o], smooth_field_errs=[r["errs"] for r in rows],
                note="Independent derivation: Cartesian curl by 6th-order differences (verify_reference.py) agrees with hand-derived cylindrical formulas to ~1e-12.")

def exact_case(be, name, fld, expect, dtype, G):
    J = G.run(be, G.sample(fld, dtype), dtype); ref = G.ref(fld)
    scale = max(1e-30, max(float(np.max(np.abs(r))) for r in ref))
    errs = err_vs_ref(G, J, ref)
    return dict(name=name, errs=errs, scale=scale, ref_sign_ok=_sign_ok(J, ref, G))

def _sign_ok(J, ref, G):
    ok = True
    for c in range(3):
        m = np.abs(ref[c]) > 0.2*max(1e-30, np.max(np.abs(ref[c])))
        if m.any():
            ok &= bool(np.all(np.sign(J[c][G.sl][m]) == np.sign(ref[c][m])))
    return ok

def t003(be):
    cases = [  # name, field, exact?
        ("Z-pinch +  Bphi=+0.5r -> Jz=+1", Field(zero, lambda r, p, z: 0.5*r, zero, zero, zero, const(1.0)), True),
        ("Z-pinch -  Bphi=-0.5r -> Jz=-1", Field(zero, lambda r, p, z: -0.5*r, zero, zero, zero, const(-1.0)), True),
        ("rigid rotation Bphi=r -> Jz=+2", Field(zero, lambda r, p, z: r, zero, zero, zero, const(2.0)), True),
        ("Bz=r^2/2 -> Jphi=-r (negative)", Field(zero, zero, lambda r, p, z: 0.5*r**2, zero, lambda r, p, z: -r, zero), True),
        ("Br=z -> Jphi=+1", Field(lambda r, p, z: z, zero, zero, zero, const(1.0), zero), True),
        ("Bphi=+z -> Jr=-1, Jz=+z/r", Field(zero, lambda r, p, z: z, zero, const(-1.0), zero, lambda r, p, z: z/r), True),
        ("Bphi=-z -> Jr=+1, Jz=-z/r", Field(zero, lambda r, p, z: -z, zero, const(1.0), zero, lambda r, p, z: -z/r), True),
        ("Bz=x=r cos(phi) -> Jr=-sin(phi), Jphi=-cos(phi)", Field(zero, zero, lambda r, p, z: r*np.cos(p), lambda r, p, z: -np.sin(p), lambda r, p, z: -np.cos(p), zero), False),
        ("uniform x-hat B -> J=0", Field(lambda r, p, z: np.cos(p), lambda r, p, z: -np.sin(p), zero, zero, zero, zero), "zero"),
    ]
    res = {}; allok = True
    for dtype in DTYPES:
        G = Grid(16, 16, 8); rows = []
        for name, fld, kind in cases:
            r = exact_case(be, name, fld, None, dtype, G)
            if kind is True:
                tol = (TOL["exact_fp64"] if dtype is F64 else TOL["exact_fp32"])*r["scale"]
                ok = max(r["errs"]) <= tol and r["ref_sign_ok"]
            elif kind == "zero":
                tol = TOL["uniform_abs"]; ok = max(r["errs"]) <= tol
            else:
                tol = TOL["trig_rel"]*r["scale"]; ok = max(r["errs"]) <= tol and r["ref_sign_ok"]
            r.update(tol=tol, ok=bool(ok)); rows.append(r); allok &= ok
        res[dn(dtype)] = rows
    return dict(verdict="PASS" if allok else "FAIL", cases=res)

def t004(be):
    G = Grid(16, 16, 8); B = G.sample(ADV, F64); J1 = G.run(be, B, F64)
    alpha = 2.5
    J2 = G.run(be, [alpha*b for b in B], F64)
    hom = max(float(np.max(np.abs(J2[c][G.sl] - alpha*J1[c][G.sl])))/float(np.max(np.abs(J1[c][G.sl]))) for c in range(3))
    ref = G.ref(ADV); mu0 = 2.5
    ratio = [float(np.median(J1[c][G.sl]/ref[c])) if c != 99 else 0 for c in range(3)]
    rel = [e/np.max(np.abs(r)) for e, r in zip(err_vs_ref(G, J1, ref), ref)]
    Jphys_err = max(float(np.max(np.abs(J1[c][G.sl]/mu0 - ref[c]/mu0)))/float(np.max(np.abs(ref[c]/mu0))) for c in range(3))
    has_mu0 = any("mu0" in l for l in re.search(re.escape(KNAME) + r'\((.*?)\)\s*\{', KSRC, re.S).group(1).split(","))
    ok = (not has_mu0) and hom <= TOL["homogeneity"] and max(rel) < 0.05
    return dict(verdict="PASS" if ok else "FAIL", kernel_has_mu0_parameter=has_mu0, homogeneity_rel=hom,
                rel_err_output_vs_curlB=rel, rel_err_output_over_mu0_vs_curlB_over_mu0=Jphys_err, mu0_used_in_reference=mu0,
                contract="Output = curl(B) in units of [B]/[length] with mu0 NOT applied. Physical J = output/mu0, to be applied exactly once by the caller. "
                         "ScienceManager.jz already divides by mu0 (default 1.0): the future integration must not divide twice.")

def t005(be):
    # static stride evidence
    ns = {}
    out = {}
    for dtype in DTYPES:
        pass
    G = Grid(16, 16, 8); g = 2
    shapes = dict(Br=(16 + 1 + 2*g, 16 + 2*g, 8 + 2*g), Bphi=(16 + 2*g, 16 + 1 + 2*g, 8 + 2*g), Bz=(16 + 2*g, 16 + 2*g, 8 + 1 + 2*g), J=(16 + 2*g, 16 + 2*g, 8 + 2*g))
    nz_g, nphi_g = 8 + 2*g, 16 + 2*g
    env = dict(nz_g=nz_g, nphi_g=nphi_g)
    kstr = {}
    for line in KSRC.splitlines():
        s = line.strip()
        if s.startswith("const int sB") or s.startswith("const int sr"):
            for m in re.finditer(r"\b(s\w*)\s*=\s*([^,;]+)", s):
                kstr[m.group(1)] = int(eval(m.group(2), {}, env))
    expect = dict(sBr_r=shapes["Br"][1]*shapes["Br"][2], sBr_p=shapes["Br"][2], sBp_r=shapes["Bphi"][1]*shapes["Bphi"][2], sBp_p=shapes["Bphi"][2],
                  sBz_r=shapes["Bz"][1]*shapes["Bz"][2], sBz_p=shapes["Bz"][2], sr=shapes["J"][1]*shapes["J"][2], sphi=shapes["J"][2])
    strides_ok = all(kstr.get(k) == v for k, v in expect.items())
    distinct = len({kstr["sBr_r"], kstr["sBp_r"], kstr["sBz_r"]}) == 3
    res = dict(kernel_strides=kstr, expected_strides=expect, strides_ok=strides_ok, three_distinct_radial_strides=distinct, shapes=shapes)
    # random equivalence + probe footprints, both grids, both dtypes
    rng = np.random.default_rng(7); eq = []; probes = []; ok = strides_ok and distinct
    for base in GRIDS:
        G = Grid(*base)
        for dtype in DTYPES:
            B = [rng.uniform(-1, 1, s).astype(dtype) for s in (shapes_of(G)["Br"], shapes_of(G)["Bphi"], shapes_of(G)["Bz"])]
            J = G.run(be, B, dtype)
            R = ref_curl(*B, G.rf.astype(dtype), G.rc.astype(dtype), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
            err = max(float(np.max(np.abs(J[c][G.sl].astype(np.float64) - R[c]))) for c in range(3))
            scale = max(float(np.max(np.abs(r))) for r in R)
            tol = TOL["equiv_fp64"]*scale if dtype is F64 else fp32_bound(G, 1.0)
            eq.append(dict(grid=list(base), dtype=dn(dtype), max_abs_diff=err, tol=tol, ok=bool(err <= tol))); ok &= err <= tol
        for which, shp in (("Br", shapes_of(G)["Br"]), ("Bphi", shapes_of(G)["Bphi"]), ("Bz", shapes_of(G)["Bz"])):
            idx = (G.g + 3, G.g + 2, G.g + 1)
            B = [np.zeros(shapes_of(G)[k], F64) for k in ("Br", "Bphi", "Bz")]
            B["Br Bphi Bz".split().index(which)][idx] = 1.0
            J = G.run(be, B, F64)
            R = ref_curl(*B, G.rf, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
            same_mask = all(np.array_equal(np.abs(J[c][G.sl]) > 0, np.abs(R[c]) > 0) for c in range(3))
            d = max(float(np.max(np.abs(J[c][G.sl] - R[c]))) for c in range(3))
            foot = [int(np.sum(np.abs(R[c]) > 0)) for c in range(3)]
            probes.append(dict(grid=list(base), probe=which, index=list(idx), footprint_cells_Jr_Jphi_Jz=foot, same_nonzero_pattern=bool(same_mask), max_abs_diff=d))
            ok &= same_mask and d <= 1e-14
    res.update(random_equivalence=eq, probe_footprints=probes)
    res["verdict"] = "PASS" if ok else "FAIL"
    return res

def shapes_of(G):
    g, nr, nphi, nz = G.g, G.nr, G.nphi, G.nz
    return dict(Br=(nr + 1 + 2*g, nphi + 2*g, nz + 2*g), Bphi=(nr + 2*g, nphi + 1 + 2*g, nz + 2*g), Bz=(nr + 2*g, nphi + 2*g, nz + 1 + 2*g))

def t006(be):
    terms = {
        "T1 Jr  <- (1/r)dBz/dphi : Bz=sin(phi)":      (Field(zero, zero, lambda r, p, z: np.sin(p), lambda r, p, z: np.cos(p)/r, zero, zero), 0),
        "T2 Jr  <- -dBphi/dz     : Bphi=sin(z)":      (Field(zero, lambda r, p, z: np.sin(z), zero, lambda r, p, z: -np.cos(z), zero, zero), 0),
        "T3 Jphi<- dBr/dz        : Br=sin(z)":        (Field(lambda r, p, z: np.sin(z), zero, zero, zero, lambda r, p, z: np.cos(z), zero), 1),
        "T4 Jphi<- -dBz/dr       : Bz=sin(r)":        (Field(zero, zero, lambda r, p, z: np.sin(r), zero, lambda r, p, z: -np.cos(r), zero), 1),
        "T5 Jz  <- (1/r)d(rBphi)/dr : Bphi=sin(r)":   (Field(zero, lambda r, p, z: np.sin(r), zero, zero, zero, lambda r, p, z: np.sin(r)/r + np.cos(r)), 2),
        "T6 Jz  <- -(1/r)dBr/dphi: Br=sin(phi)":      (Field(lambda r, p, z: np.sin(p), zero, zero, zero, zero, lambda r, p, z: -np.cos(p)/r), 2),
    }
    res = {}; ok = True
    for name, (fld, comp) in terms.items():
        rows = conv(be, fld, (16, 16, 8), 4, F64); o = orders(rows)[comp]
        res[name] = dict(errs=[r["errs"][comp] for r in rows], orders=o, last_order=o[-1], ok=bool(o[-1] >= TOL["order_min"]))
        ok &= res[name]["ok"]
    def divJ_probe(fld):
        rows = []
        for L in range(4):
            n = tuple(bb*2**L for bb in (16, 16, 8)); G = Grid(*n); J = G.run(be, G.sample(fld, F64), F64); g = G.g
            Ai, Bi, Ci = [x[g:g + G.nr, g:g + G.nphi, g:g + G.nz] for x in J]
            rcc = G.rc[g:g + G.nr][:, None, None]
            d_r = (rcc[2:]*Ai[2:] - rcc[:-2]*Ai[:-2])/(2*G.dr)/rcc[1:-1]
            d_p = (np.roll(Bi, -1, 1) - np.roll(Bi, 1, 1))[1:-1]/(2*G.dphi)/rcc[1:-1]
            d_z = (Ci[:, :, 2:] - Ci[:, :, :-2])/(2*G.dz)
            div = d_r[:, :, 1:-1] + d_p[:, :, 1:-1] + d_z[1:-1]
            rows.append(dict(n=list(n), max_div=float(np.max(np.abs(div))),
                             Jmax=float(max(np.max(np.abs(Ai)), np.max(np.abs(Bi)), np.max(np.abs(Ci))))))
        o = [math.log2(x["max_div"]/y["max_div"]) if y["max_div"] > 0 else math.inf for x, y in zip(rows[:-1], rows[1:])]
        return rows, o
    pr_adv, o_adv = divJ_probe(ADV); pr_s, o_s = divJ_probe(SMOOTH)
    smooth_trunc = bool(o_s[-1] > 1.5 and pr_s[-1]["max_div"] > 1e-9)
    structural = dict(output_location="cell centers", uses_face_areas=("area" in KSRC.lower()), uses_edge_lengths=("edge" in KSRC.lower()),
                      reads_E_or_writes_face_fluxes=False)
    res["CT_compat_probe"] = dict(
        ADV=dict(rows=pr_adv, orders=o_adv, note="div_h(J_h) is at round-off for ADV because ADV's Bphi is linear in r (difference operators cancel by accident). Not informative."),
        SMOOTH=dict(rows=pr_s, orders=o_s, truncation_level_only=smooth_trunc),
        structural=structural,
        conclusion=("Structural: output is cell-centered, uses no face areas or edge lengths, writes no face fluxes, so no discrete div(curl)=0 identity in the CT (face-flux) sense exists. "
                    + ("Probe on a generic smooth field: div_h(J_h) decays only as O(h^2) truncation error and does not sit at round-off. " if smooth_trunc else
                       "Probe on the generic smooth field did NOT show clean O(h^2) truncation-level behaviour (see numbers); structural evidence stands alone. ")
                    + "Test 010 quantifies the practical consequence."))
    ct_noncompat = (not structural["uses_face_areas"]) and (not structural["uses_edge_lengths"])
    res["stencil_accuracy_statement"] = ("Averaging 0.5(f(x-h/2)+f(x+h/2)) = f + h^2/8 f'' + O(h^4); central difference over +-h = g' + h^2/6 g''' + O(h^4); "
                                         "flux difference over h = F' + h^2/24 F''' + O(h^4). Every term of Jr, Jphi, Jz is a composition of these on a uniform grid: formally 2nd order.")
    res["verdict"] = "PASS" if (ok and ct_noncompat) else "FAIL"
    res["note_on_pass"] = "PASS certifies the stencil order and the (negative) CT-compatibility identification; it does not make the kernel a CT update."
    return res

def t007(be):
    res = {}; fails = []
    # 7a kernel contract on ghost-extended radii vs driver-style radii (ASAN, exact-size buffers)
    asan_ok = asan_run(16, 16, 8, 2, 0)
    asan_driver = asan_run(16, 16, 8, 2, 1)
    asan_g1 = asan_run(16, 16, 8, 1, 0)
    asan_g0 = asan_run(16, 16, 8, 0, 0)
    asan_axis = asan_run(16, 16, 8, 2, 2) if HAS_AX else None
    vm = validation_matrix()
    if vm is not None: res["validation_matrix"] = vm
    def rej(name):
        return bool(vm) and any(r["name"] == name and r["rejected"] for r in vm)
    res["asan_ghosted_radii_g2"] = asan_ok; res["asan_driver_style_radii_g2"] = asan_driver
    res["asan_g1_minimum_ghost"] = asan_g1; res["asan_g0_invalid_ghost"] = asan_g0
    if asan_axis is not None:
        res["asan_axis_grid_g2"] = asan_axis
        if not asan_axis["clean"]: fails.append("axis-mode run is not sanitizer-clean")
    if not asan_ok["clean"]: fails.append("ghost-extended contract run is not sanitizer-clean")
    if not asan_driver["clean"] and not rej("driver-style r arrays (no ghosts)"):
        fails.append("driver-style (no-ghost) r arrays cause out-of-bounds reads: no validation")
    if asan_g0["error"] and not rej("g=0"):
        fails.append("g=0 accepted without error and reads out of bounds")
    if vm is not None:
        ok_vm, bad = vm_ok(vm, {"valid", "grid", "angle", "shape", "dtype", "layout", "radial"})
        if not ok_vm: fails.append(f"launcher validation matrix mismatches: {bad}")
    # 7b the 1/r guard
    n = 16; dr = 1.0/n
    res["guard"] = dict(threshold=1e-8, supported_geometry_first_center=dr/2, guard_reachable_for_r_min_0=bool(dr/2 <= 1e-8),
                        min_dr_for_guard_to_fire=2e-8,
                        statement="For r_min=0 the first active center is dr/2, so the guard fires only if dr<=2e-8 (nr>=5e7 for r_max=1): inactive in all supported grids.")
    G = Grid(16, 16, 8, r0=-0.5/16, r1=1 - 0.5/16)   # first active center exactly at r=0 (unsupported pathology)
    pr = Field(zero, lambda r, p, z: r, zero, zero, zero, const(2.0))
    # The GPU backend goes through the validating launcher, which REJECTS this unsupported grid (raises); the host backend calls the raw kernel.
    try:
        J = G.run(be, G.sample(pr, F64), F64)
        res["guard"]["pathology_rc0_Jz_kernel"] = float(J[2][G.sl][0, 0, 0]); res["guard"]["pathology_raised_by_backend"] = False
    except Exception as ex:
        res["guard"]["pathology_rc0_Jz_kernel"] = float("nan"); res["guard"]["pathology_raised_by_backend"] = True
        res["guard"]["pathology_exception"] = f"{type(ex).__name__}: {str(ex)[:200]}"
    res["guard"]["pathology_rc0_Jz_true"] = 2.0
    if IS_V11:
        res["guard"]["pathology_rejected_by_launcher"] = rej("r_center of first active cell = 0")
        if "1e-8" in KSRC: fails.append("1/r guard still present in kernel source")
        if not res["guard"]["pathology_rejected_by_launcher"]: fails.append("r_center = 0 not rejected by launcher")
    elif not res["guard"]["pathology_raised_by_backend"] and abs(res["guard"]["pathology_rc0_Jz_kernel"] - 2.0) > 1e-6:
        fails.append("1/r->0 guard returns 0 silently where the true limit is finite (Jz=2)")
    # 7c angular units
    G = Grid(16, 16, 8); fld = Field(zero, zero, lambda r, p, z: np.sin(p), lambda r, p, z: np.cos(p)/r, zero, zero)
    B = G.sample(fld, F64)
    Jrad = be.run(*B, G.rf, G.rc, G.dr, G.dphi, G.dz, 16, 16, 8, 2)
    Jdeg = be.run(*B, G.rf, G.rc, G.dr, math.degrees(G.dphi), G.dz, 16, 16, 8, 2)
    res["angular_units"] = dict(Jr_err_radians=err_vs_ref(G, Jrad, G.ref(fld))[0], Jr_err_if_dphi_in_degrees=err_vs_ref(G, Jdeg, G.ref(fld))[0],
                                validator_rejects_degrees=rej("dphi in degrees"),
                                note="dphi must be in radians with nphi*dphi=2*pi; " + ("the v1.1 launcher validator rejects degrees." if IS_V11 else "nothing in the kernel or launcher checks it."))
    # 7d launcher validation
    src = launcher_source()
    res["launcher_validation_tokens_found"] = [t for t in ("raise", "assert", ".shape", ".dtype", "ValueError", "CurlContractError") if t in src]
    if not res["launcher_validation_tokens_found"]: fails.append("launcher performs no shape/dtype/grid validation")
    # 7e axis-adjacent cell
    rows_a = []; rows_z = []
    for L in range(4):
        n = tuple(b*2**L for b in (16, 16, 8)); G = Grid(*n, r0=0.0, r1=1.0)
        B = G.sample(SMOOTH, F64); J = G.run(be, B, F64); ref = G.ref(SMOOTH)
        ax = [float(np.max(np.abs(J[c][G.g, G.g:G.g + G.nphi, G.g:G.g + G.nz] - ref[c][0]))) for c in range(3)]
        rows_a.append(dict(n=list(n), axis_cell_errs=ax))
        Bz_ = [b.copy() for b in B]
        for b in Bz_: b[:G.g, ...] = 0.0                    # inner radial ghosts left zero (what BoundaryManager does today)
        J2 = G.run(be, Bz_, F64)
        ax2 = [float(np.max(np.abs(J2[c][G.g, G.g:G.g + G.nphi, G.g:G.g + G.nz] - ref[c][0]))) for c in range(3)]
        rows_z.append(dict(n=list(n), axis_cell_errs=ax2))
    oa = [math.log2(a["axis_cell_errs"][c]/b["axis_cell_errs"][c]) for c in range(3) for a, b in [(rows_a[-2], rows_a[-1])]]
    res["axis_cell_with_analytic_ghosts"] = dict(rows=rows_a, last_orders=oa)
    res["axis_cell_with_zero_inner_ghosts_(driver_today)"] = dict(rows=rows_z)
    if min(oa) < TOL["order_min"]:
        fails.append(f"axis-adjacent cell below 2nd order even with analytic ghosts: last-pair orders Jr/Jphi/Jz = {[round(x, 2) for x in oa]} "
                     "(first-order Jz for fields with a transverse component on the axis, e.g. m=1 kink perturbations)")
    ez = [r["axis_cell_errs"][1] for r in rows_z]
    ghost_dep = max(abs(a["axis_cell_errs"][c] - b["axis_cell_errs"][c]) for a, b in zip(rows_a, rows_z) for c in range(3))
    res["driver_state_axis_ghost_finding"] = dict(Jphi_axis_cell_errs=ez, growth_per_refinement=[ez[i + 1]/ez[i] for i in range(3)],
        max_difference_zero_vs_analytic_inner_ghosts=ghost_dep,
        statement=("Inner radial ghosts (index < g) do not influence the axis ring: zero-filled and analytic ghosts give the same errors." if ghost_dep == 0.0 else
                   "With inner radial ghosts left at zero (current BoundaryManager), Jphi in the axis-adjacent cell has an O(Bz/dr) error that GROWS under refinement. Needs even reflection of Bz (odd for Br/Bphi) across the axis."))
    # 7f global convergence on axis grids (every cell, all rings), SMOOTH and KINK, FP64
    glob = {}
    for nm, fld in (("SMOOTH", SMOOTH), ("KINK", KINK)):
        rws = []
        for L in range(4):
            n = tuple(b*2**L for b in (16, 16, 8)); G = Grid(*n, r0=0.0, r1=1.0)
            J = G.run(be, G.sample(fld, F64), F64); ref = G.ref(fld)
            rws.append(dict(n=list(n), errs=err_vs_ref(G, J, ref), Jmax=[float(np.max(np.abs(x))) for x in ref]))
        od = orders(rws)
        comp_ok = [bool(od[c][-1] >= TOL["order_min"] or max(r["errs"][c] for r in rws) <= TOL["exact_fp64"]*max(r["Jmax"][c] for r in rws)) for c in range(3)]
        glob[nm] = dict(rows=rws, last_orders=[o[-1] for o in od], component_ok=comp_ok)
        if not all(comp_ok): fails.append(f"axis-grid global convergence below {TOL['order_min']} for {nm}: last-pair orders {[round(o[-1], 2) for o in od]}")
    res["axis_grid_global_convergence"] = glob
    res["kink_reference_vs_numeric_cartesian"] = kink_reference_check()
    # 7f' FP32 on axis grids: the tangential difference divides by ~ r*dphi, so round-off is amplified; check against the declared bound
    f32 = []
    for L in range(3):
        n = tuple(b*2**L for b in (16, 16, 8)); Gn = Grid(*n, r0=0.0, r1=1.0)
        B64 = Gn.sample(KINK, F64); J64 = Gn.run(be, B64, F64); J32 = Gn.run(be, Gn.sample(KINK, F32), F32)
        d = max(float(np.max(np.abs(J32[c][Gn.sl].astype(np.float64) - J64[c][Gn.sl]))) for c in range(3))
        bnd = fp32_bound(Gn, max(float(np.max(np.abs(b))) for b in B64)); f32.append(dict(n=list(n), fp32_vs_fp64=d, bound=bnd, ok=bool(d <= bnd)))
    res["axis_grid_fp32_vs_fp64"] = f32
    if not all(r["ok"] for r in f32): fails.append("FP32 on axis grids exceeds the declared round-off bound")
    # 7g exact analytic axis fields on an axis grid (Z-pinch and Bz = r^2/2)
    G = Grid(16, 16, 8, r0=0.0, r1=1.0)
    ex = {}
    for nm, fld in (("zpinch Bphi=0.5r -> Jz=1", Field(zero, lambda r, p, z: 0.5*r, zero, zero, zero, const(1.0))),
                    ("Bz=r^2/2 -> Jphi=-r", Field(zero, zero, lambda r, p, z: 0.5*r**2, zero, lambda r, p, z: -r, zero))):
        J = G.run(be, G.sample(fld, F64), F64); er = err_vs_ref(G, J, G.ref(fld)); sc = max(float(np.max(np.abs(x))) for x in G.ref(fld))
        ex[nm] = dict(errs=er, tol=TOL["exact_fp64"]*sc, ok=bool(max(er) <= TOL["exact_fp64"]*sc))
        if not ex[nm]["ok"]: fails.append(f"exact axis field '{nm}' not reproduced: {er}")
    res["exact_axis_fields"] = ex
    # 7h inner-ghost independence: NaN in every inner radial ghost vs analytic ghosts -> interior must be bitwise identical
    B = G.sample(SMOOTH, F64); Bn = [b.copy() for b in B]
    for b in Bn: b[:G.g, ...] = np.nan
    Ja = G.run(be, B, F64); Jn = G.run(be, Bn, F64)
    same = all(np.array_equal(Ja[c][G.sl], Jn[c][G.sl]) for c in range(3))
    res["inner_ghost_independence"] = dict(bitwise_identical_with_NaN_inner_ghosts=bool(same),
        n_nan_in_interior=int(sum(int(np.isnan(Jn[c][G.sl]).sum()) for c in range(3))))
    if not same: fails.append("axis ring reads inner radial ghost cells (NaN inner ghosts change the interior result): the driver must fill them")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    res["positive_findings"] = ["With ghost-extended radii and analytic axis ghosts, Jr and Jphi converge at 2nd order in the axis-adjacent cell, and 1/r_c is finite there -> the 1/r guard is dead code for supported axis geometry.",
                                "g=1 is sufficient (all reads are within +-1 cell)."]
    return res

def t008(be):
    res = {"reference_check": REFCHECK, "grids": {}}; ok_corr = True; ok_f32 = True
    sup_fail = True
    for base in GRIDS:
        key = "x".join(map(str, base))
        rows64 = conv(be, ADV, base, 4, F64)
        rows64_sup = conv(be, ADV, base, 4, F64, jz_ref=ADV_SUPPLIED_JZ)
        rows32 = conv(be, ADV, base, 4, F32)
        o = orders(rows64)
        # fp32 vs fp64 kernel agreement per level
        agree = []
        for L in range(4):
            n = tuple(b*2**L for b in base); G = Grid(*n)
            J64 = G.run(be, G.sample(ADV, F64), F64); J32 = G.run(be, G.sample(ADV, F32), F32)
            B64 = G.sample(ADV, F64); Bmax = max(float(np.max(np.abs(b))) for b in B64)
            d = max(float(np.max(np.abs(J32[c][G.sl].astype(np.float64) - J64[c][G.sl]))) for c in range(3))
            bound = fp32_bound(G, Bmax)
            agree.append(dict(n=list(n), fp32_vs_fp64=d, bound=bound, ok=bool(d <= bound))); ok_f32 &= d <= bound
        res["grids"][key] = dict(fp64_vs_corrected=rows64, fp64_orders=o, fp64_last_order=[x[-1] for x in o],
                                  fp64_Jz_vs_SUPPLIED_reference=[r["errs"][2] for r in rows64_sup], fp32_vs_corrected=[r["errs"] for r in rows32], fp32_vs_fp64=agree)
        # criterion refinement (disclosed in report): a component passes if its order >= order_min OR its error is
        # at round-off at every level (stencil exact for that field, so an order is undefined)
        comp_ok = []
        for c in range(3):
            exact_c = max(r["errs"][c] for r in rows64) <= TOL["exact_fp64"]*max(r["Jmax"][c] for r in rows64)
            comp_ok.append(bool(o[c][-1] >= TOL["order_min"] or exact_c))
        res["grids"][key]["component_pass"] = comp_ok
        ok_corr &= all(comp_ok)
        sup_fail &= rows64_sup[-1]["errs"][2] > 100*rows64[-1]["errs"][2] and rows64_sup[-1]["errs"][2] > 1e-2
    res["corrected_reference_verdict"] = "PASS" if (ok_corr and ok_f32) else "FAIL"
    res["supplied_reference_Jz_mismatch_persists_under_refinement"] = bool(sup_fail)
    # R1 RULING: the policeman's Campaign 01 verdict (2026-11-18) directs "Correct the analytical Jz reference to
    # 2z^2 + cos(phi)/r - r cos(phi)". The supplied Jz is therefore superseded; the verdict is the one against the corrected reference.
    res["R1_ruling"] = dict(status="RULED", text="policeman verdict 2026-11-18: use Jz = 2z^2 + cos(phi)/r - r cos(phi)",
                            supplied_Jz_mismatch_persists_under_refinement=bool(sup_fail))
    res["verdict"] = res["corrected_reference_verdict"]
    return res

def t009(be):
    G = Grid(16, 16, 8); g = G.g; res = {}; fails = []
    B = G.sample(ADV, F64); h0 = hashlib.sha256(b"".join(b.tobytes() for b in B)).hexdigest()
    shp = (G.nr + 2*g,)*0 + (G.nr + 2*g, G.nphi + 2*g, G.nz + 2*g)
    outs = []
    for sentinel in (np.nan, 123456.0):
        J = [np.full(shp, sentinel) for _ in range(3)]
        J = be.run(*B, G.rf, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, g, J=J); outs.append(J)
    h1 = hashlib.sha256(b"".join(b.tobytes() for b in B)).hexdigest()
    mask = np.zeros(shp, bool); mask[G.sl] = True
    cover = all(np.isfinite(outs[0][c][mask]).all() for c in range(3))
    ghosts_untouched = all(np.isnan(outs[0][c][~mask]).all() and np.all(outs[1][c][~mask] == 123456.0) for c in range(3))
    no_accum = all(np.array_equal(outs[0][c][mask], outs[1][c][mask]) for c in range(3))
    idx = set(); sr, sphi = (G.nphi + 2*g)*(G.nz + 2*g), G.nz + 2*g
    for i in range(G.nr):
        for j in range(G.nphi):
            for k in range(G.nz): idx.add((i + g)*sr + (j + g)*sphi + (k + g))
    injective = len(idx) == G.nr*G.nphi*G.nz
    res.update(all_active_cells_written=bool(cover), ghost_cells_untouched=bool(ghosts_untouched), overwrite_not_accumulate=bool(no_accum),
               write_index_injective=bool(injective), active_cells=G.nr*G.nphi*G.nz, inputs_unchanged=bool(h0 == h1), input_sha_before=h0[:16], input_sha_after=h1[:16])
    for k_, v in (("cover", cover), ("ghost untouched", ghosts_untouched), ("overwrite", no_accum), ("injective", injective), ("inputs unchanged", h0 == h1)):
        if not v: fails.append(k_)
    # aliasing: Jphi and Jz given the same buffer
    shared = np.full(shp, np.nan); Jr_ = np.full(shp, np.nan)
    if be.name == "host":
        J_al = be.run(*B, G.rf, G.rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, g, J=[Jr_, shared, shared], ptr_override=[Jr_, shared, shared])
        sep = outs[0]
        differs = float(np.max(np.abs(shared[G.sl] - sep[1][G.sl])))
        res["aliasing_demo"] = dict(aliased_Jphi_buffer_vs_separate_max_diff=differs,
                                     note="Jphi and Jz pointed at one buffer: the Jphi result is silently overwritten by Jz.")
    else:
        res["aliasing_demo"] = dict(note="live aliasing demo is host-only (pointer override); verdict below rests on the static contract check")
    lsrc = launcher_source()
    src = lsrc + KSRC + (K.__doc__ or "")
    prohibits = bool(re.search(r"alias", src, re.I))
    rejects = bool(re.search(r"overlap|\.data\.ptr|may_share_memory", lsrc))
    vm = validation_matrix()
    if vm is not None:
        ok_al, bad_al = vm_ok(vm, {"alias"}); rejects = bool(rejects and ok_al)
        res["aliasing_matrix"] = [r for r in vm if r["group"] == "alias"]
        if not ok_al: fails.append(f"aliasing cases not all rejected: {bad_al}")
    res["launcher_or_docs_mention_aliasing"] = prohibits
    res["launcher_rejects_aliasing"] = rejects
    if not prohibits and not rejects:
        fails.append("aliasing neither rejected nor documented as prohibited (kernel uses __restrict__, aliasing is undefined behaviour)")
    if IS_V11 and be.name == "cupy":
        dv = gpu_validator_cases(); res["device_validator_cases"] = dv
        if not all(r["ok"] for r in dv): fails.append("device-array validator/aliasing mismatches: " + str([r["name"] for r in dv if not r["ok"]]))
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ---- Test 010: CT trap ------------------------------------------------------
def ct_flux(Ar, Ap, Az, rf, dr, dphi, dz):
    """Circulation of edge values around each face. Ar (nr,nphi+1,nz+1), Ap (nr+1,nphi,nz+1), Az (nr+1,nphi+1,nz)."""
    nr = Ar.shape[0]
    L = (rf[:nr + 1]*dphi)[:, None, None]
    Phi_r = L*(Ap[:, :, :-1] - Ap[:, :, 1:]) + dz*(Az[:, 1:, :] - Az[:, :-1, :])                 # (nr+1,nphi,nz)
    Phi_p = dz*(Az[:-1, :, :] - Az[1:, :, :]) + dr*(Ar[:, :, 1:] - Ar[:, :, :-1])                 # (nr,nphi+1,nz)
    Phi_z = dr*(Ar[:, :-1, :] - Ar[:, 1:, :]) + dphi*(rf[1:nr + 1][:, None, None]*Ap[1:, :, :] - rf[:nr][:, None, None]*Ap[:-1, :, :])  # (nr,nphi,nz+1)
    return Phi_r, Phi_p, Phi_z

def div_times_vol(Pr, Pp, Pz):
    return (Pr[1:] - Pr[:-1]) + (Pp[:, 1:, :] - Pp[:, :-1, :]) + (Pz[:, :, 1:] - Pz[:, :, :-1])

def t010(be):
    res = {}
    # interface-level rejection
    params = re.search(re.escape(KNAME) + r'\((.*?)\)\s*\{', KSRC, re.S).group(1)
    pnames = [q.strip().split()[-1].lstrip("*") for q in params.split(",")]
    res["interface"] = dict(parameters=pnames, has_E_input=any(q[0] == "E" for q in pnames), has_dt_input="dt" in pnames,
                            output_location="cell centers (shape nr+2g,nphi+2g,nz+2g)",
                            required_for_CT="face fluxes on face_r/face_phi/face_z shapes, from edge E (edge_r/edge_phi/edge_z), using face areas and edge lengths",
                            mismatch=True)
    G = Grid(16, 16, 8); g = G.g; nr, nphi, nz = G.nr, G.nphi, G.nz
    # divergence-free B0 from edge potential A (SMOOTH), then a Faraday update with E (ADV components)
    def edges(fld):
        a = lambda arr, s: arr[g:g + s]
        Er = fld.Br(*G.mesh(G.rc[g:g + nr], G.pf[g:g + nphi + 1], G.zf[g:g + nz + 1]))
        Ep = fld.Bp(*G.mesh(G.rf[g:g + nr + 1], G.pc[g:g + nphi], G.zf[g:g + nz + 1]))
        Ez = fld.Bz(*G.mesh(G.rf[g:g + nr + 1], G.pf[g:g + nphi + 1], G.zc[g:g + nz]))
        return Er, Ep, Ez
    rf = G.rf[g:g + nr + 1]
    A = edges(SMOOTH); Phi0 = ct_flux(*A, rf, G.dr, G.dphi, G.dz)
    E = edges(ADV); dt = 1e-3
    dPhi_ct = [-dt*x for x in ct_flux(*E, rf, G.dr, G.dphi, G.dz)]
    Phi_ct = [a + b for a, b in zip(Phi0, dPhi_ct)]
    scale = max(float(np.max(np.abs(x))) for x in dPhi_ct)
    nrm = lambda P: max(float(np.max(np.abs(x))) for x in P)
    sl_i = (slice(1, nr - 1), slice(None), slice(1, nz - 1))
    div0 = float(np.max(np.abs(div_times_vol(*Phi0))))/nrm(Phi0)
    div_ct = float(np.max(np.abs(div_times_vol(*dPhi_ct)[sl_i])))/nrm(dPhi_ct)        # relative to the UPDATE flux (dt-independent)
    # misuse: feed E (sampled at B-face locations) to the current-density kernel, average cell->face, treat as dB
    Bf = G.sample(ADV, F64)
    J = G.run(be, Bf, F64)
    Jr_, Jp_, Jz_ = [x[g:g + nr, g:g + nphi, g:g + nz] for x in J]
    dB_r = np.zeros((nr + 1, nphi, nz)); dB_r[1:nr] = 0.5*(Jr_[:-1] + Jr_[1:])
    dB_p = np.zeros((nr, nphi + 1, nz)); dB_p[:, 1:nphi] = 0.5*(Jp_[:, :-1] + Jp_[:, 1:]); dB_p[:, 0] = dB_p[:, nphi] = 0.5*(Jp_[:, 0] + Jp_[:, -1])
    dB_z = np.zeros((nr, nphi, nz + 1)); dB_z[:, :, 1:nz] = 0.5*(Jz_[:, :, :-1] + Jz_[:, :, 1:])
    area_r = (rf*G.dphi*G.dz)[:, None, None]
    area_p = np.full((nr, 1, 1), G.dr*G.dz)
    area_z = (0.5*(rf[1:]**2 - rf[:-1]**2)*G.dphi)[:, None, None]
    dPhi_mis = [-dt*dB_r*area_r, -dt*dB_p*area_p, -dt*dB_z*area_z]
    Phi_mis = [a + b for a, b in zip(Phi0, dPhi_mis)]
    # interior cells only (boundary faces were not filled)
    div_mis = float(np.max(np.abs(div_times_vol(*dPhi_mis)[sl_i])))/nrm(dPhi_mis)
    res.update(div_B0_relative_to_flux=div0, div_after_correct_CT_faraday_relative_to_update=div_ct,
               div_after_current_kernel_substitute_relative_to_update=div_mis, ct_exact_threshold=TOL["ct_exact"],
               normalisation="max|div(dPhi)*V| / max|dPhi| over cells 1..nr-2, all phi, 1..nz-2 (dt-independent)")
    accepted = (div_mis <= TOL["ct_exact"])
    ok = (div_ct <= TOL["ct_exact"]) and (not accepted) and res["interface"]["mismatch"]
    res["current_kernel_accepted_as_CT_replacement"] = bool(accepted)
    res["verdict"] = "PASS" if ok else "FAIL"
    res["meaning_of_PASS"] = "PASS = the trap works: the kernel is rejected as a CT update, by interface and by div(B) violation, while a correct CT circulation update keeps div(B) at round-off."
    res["required_future_kernel"] = "uct_curl (Faraday): edge E -> face flux using face areas and edge lengths; must be certified separately."
    return res

TESTS = [("001", "Operator identity", t001), ("002", "Cylindrical equations", t002), ("003", "Orientation and signs", t003),
         ("004", "mu0 normalization", t004), ("005", "Yee staggering", t005), ("006", "Discrete operator order", t006),
         ("007", "Coordinate contract", t007), ("008", "Independent analytic differentiation", t008),
         ("009", "Output ownership and mutation", t009), ("010", "Operator misidentification trap", t010)]
STATIC_ONLY = {"007"}   # contains ASAN/static legs that no GPU backend can replace

REFCHECK = None

def safe(fn, be):
    """A GPU-side exception becomes a recorded ERROR result instead of aborting the whole campaign."""
    try:
        return fn(be)
    except Exception:
        return dict(verdict="ERROR", error=traceback.format_exc()[-1800:])

def gpu_vs_host(host, gpu):
    rng = np.random.default_rng(11); rows = []
    for base in GRIDS:
        G = Grid(*base); sh = shapes_of(G)
        for dtype in DTYPES:
            B = [rng.uniform(-1, 1, sh[k]).astype(dtype) for k in ("Br", "Bphi", "Bz")]
            Jh = G.run(host, B, dtype); Jg = G.run(gpu, B, dtype)
            finite = all(bool(np.isfinite(Jg[c][G.sl]).all()) for c in range(3))
            d = max(float(np.max(np.abs(Jg[c][G.sl].astype(np.float64) - Jh[c][G.sl].astype(np.float64)))) for c in range(3))
            scale = max(float(np.max(np.abs(Jh[c][G.sl]))) for c in range(3))
            tol = TOL["equiv_fp64"]*scale if dtype is F64 else fp32_bound(G, 1.0)
            rows.append(dict(grid=list(base), dtype=dn(dtype), max_abs_diff=d, tol=tol, finite=finite, ok=bool(finite and d <= tol)))
    return rows



_EMBEDDED_BASELINES = {
 "uct_curl_v01.py": """
eNq1Wltv48YVftevGCgvpEzKKzlJAxlKUbmbdJ1gaygJglp1iRE5omhTJDGkvDbX+997LsOrJO8GTY3ES87MOXPu55uhh8PhYO8Xnr/X8Th7
Fq4rfBXHrq+SQmkViGsxFzhpLWyRJkKKRBbRoxL+cxwlgY58GYt/KSVCHQXC2u3fwPqJPR4MfilkGCodJaGwwm2aF+JDFBRbETqidDcyLxQM
xfI53ReO2MSyEMBPPQG5HOWeFmdiDf9m2wiefHs2EPCz0PBrJrQMIthWbKSvciGsRJ9NzqbAOIHl9CBEUsKDEDbTIZuZkGW024MILTqzGOkM
iw5dSfvJJ9ruBF29HzJguusR0aElBVsSyE7S8X6DhfLlPlei2OL/Gmy6EFJr+ZyLrQSLB9FmAy5JCpFvZaZyRyjpb2EuF1GRi3/+/l7kBXhB
5QMLeainQkuSWcTgMViF7mu4BNFOJXkETt2kmnmliULXLdm+fprqIAJ/A63USmQyzyEifn/36z8EeTQXeSrCiB0Hi2DXHbDVyi/iZ/aY9sho
qzC6g7c5hEIkXBHagn9GItD8ZOVRqYTxpG1oje2IuqaFeHgz/sY+RouUvyUR6ANyaEcEYGf4XQqQfL9TAYalD0KqGdvlUcZ7oxxYWMsQ1CvS
rt/O+ZV9L5OgtqCvgsGHCMKpzhWI6cSP4nwslkoGudBk1DN3Qiwcspb4HvJDRLlQSboPt6AUaDYV6QMY/kdKE1ybi90eHtdKbKI4BtbrZ4oL
yLZYaWFBRKJkGeRXGkQ+PEIawcTiKgc+Q0jqaJeluhDJfgdZDSGSZINBoY1XzKS/5zk/G6gnX2WFeEcTb7VO9UyIr0SSih9vfgPFpP8wIwne
73c3z0Lt9pCxGDtrFacfUJ89xkaUgA1kQJv4GWj2HkJqMPB+ert8//Zn75flFYxplK94zlSgNmL59m8/e7+iqeLLweArGIoSiPylJZ2149sm
6VeWtEf5QkNdAPdba37J6MW37xq6mxYdON/QZW267BjdbYuurPcr23Rli25wPuIIcr9v18sqinIxOm/pclUztyxU1Ib4HVmgI+ziAHMHeNrA
mkfOJvWYbbc0O8Hl5oBLPYKcelxuT3C5PeDSGTmbIBdQmipphLpmKUQA54upx2QQCdZSxQelEs4bCdGPWSPtjk1ufjihzRVu6066Cl11pANJ
IF5BhEQMr4bC88I4XcvY8waPKTShqp15D7BCxRYHYwqRSVE2AgKtsFLCOg+iy/nMAqwhn1lS8oIjU9f69FTN+Nhk+Zk9TWH97CpTxvrrqDy2
X6lStgc6AoDHob467bcWAb2X7Teowx+50sBLBDm/jlP/4V3wNH4a0ePfo934CXyLjU4GNHFZE9y3CZ4bgucOwXND8NAmKBuCskNQGoKNsCIs
w4kWLy+wGT5iWMPLA72UNtig2OsEKlLXBiHqgogEeneIYt6bZ5TgAZ8v+1YrPazwCYoyHRmMwkOMbWDQbAPpBQXdpZ5ftXJhlcKAJUqgLnOu
iHPDc4R7Oaazcn2c0/6XB2QZkVlMB8ldk3J5PEVWtnezcA3QMllZk4FOkwPSE1IiKZrBbMgjYIdrpwdDQfV+BGsfAUUHJFz210TJI+oJS78X
XGYmyv3OFn+t3sZvzmFyJqoa9OaSBaAGG+6lPrp1NA1Y6rp0nXMCwUTZHS5pUHcHdePxa5qanGtbBIuS2ADICbDqAHHX5ZyYYOpqdyznYeSE
91DpwwcbCOsRl0bsEYt6ecgl84KSIRnWV6IBCvAncmmNuBPmUrZk5u2DhUYRXRZcH5VVN7ssD3ZZHt3lmL7a8CDtUNn7jr5uNUI82tYtG+ta
mmq5jaK6tck1m/xQdg0WggmOsQrEnk3uRti7WkJcHiOM0x6hEBWhEKcIyVqVZ5cHnl2e8Gwv1XwgD6NRjieo8H6Uc5UJH3i7awRTPqJpSI1R
HUuuCQizCJETLTIOdI0XzHTZ5gHtmy3lGs2NgSttQM9PhEgHpiHnQPjx02AwQPi33kdxUHXqAEGhOeoBxVW6y6JYCSsFrI2lUfACwqFXe4Ch
S/nhJyIdi/dKAeImRHsGIARQ6xg3RVaJ3CkqP2OiN9uMcbhqCLQkSdGCohKT5aj6Mwo93MSpLC6mw5ngx6FjHr79GseCdL+O1fDTCtnd1eQV
Qx7G83Q2riW3Wth4rFUWQ8BYQ0bFwJ5qhjMQX/Qz7EGfoTlHUS/riWHsv5MPysOzu4XtHUFBOJ86bOg5WMxo1ziFziguwi849AVt6JefV0cm
iw+EQX0WxONLGNm1R0xeYKBDDxpLLZNQgQTYOrgl2nxKxDOePYb+1/itezQ8xqIibx8UjzJhu1RIqmFqbBPLfeJvvcqoFkBFRoMI+BDZMYSr
sVr/55Cx0zmVHqdCPzC4QkgF3jC2DwrQdaE5hmmEUE83f1gxLAFBMa4XMgQiW33nCPjva15HOMmYEA33F/v8HGYtg0zqV8QuF/BiyB4sJnQq
xpUir1nomDUq/X0LHOTgP1gv6KG00QpjKGgXUxCu88aLmveySZB6MKRTArmREoLOwR5eM/35bjzpMgj3d5gJLlxIuHy71Ryc0w3VMXYdXq3R
HZi58LFyLEgVBoTzE/HbSV+ncMAXv+XmomKr/AdiQ9zhru28uoMQH7ZwBDPnd8Ay8lFGsYTy1JRFwmENHO0gVH4eGCTZYEWD3vC3bWYzk4PE
BxLYPrKmbHGwKpBoOzVeNOvAjhUc7O9GCzbou80iw18lp4OGI3ds2ezS1ltZPXN/hM4J3dAAdYiSncq3XPZatcNmMN8awlCjwdcrcIuiNEwq
h8yH0f3QCLFYwuax3K0DKaQj1hDpM9RpJfE6Y/Xmji894XGCjz63kMXNUaqMqLKGKutS3R6lKomqbKjKLhVd0PTJqusKM2CuKiQ6zoyY69Kb
09Q3HWp+YwY19e1p6tsOdf1GoVPt/cPpveHSAxrCpC3AVc3ROEf7/dOEOV4+csRAPmnFJwk8QzgCzw7HxrVPcxCEcJyo+05Vuc1u97qCTwax
43GSzNHB8TjqmlF7ZFUHDVv8uw5ItwbwVYCjURoQX426aCrDomSb3WctqNmnXr5C3dueZDXS33c1MNLfdzTQZvuygZANUAY2NVTusWxdJpsV
DWvg2stRt61ax7bLV21rPHQKRxsYXZUXBsL3ugbOvYnMQObecGmak94nx8DF/9RzloRroIm0e5uNF718ecs9xsGeQ81hw2Ca7nA7HSLfUoBU
oKrdGZy6X7Av4fbXC7M9gVvkhFia7n4NwDbzDaau76KrHwDF/j6QY7BIAV8mxqEq/q4eI19dpTBi2fVic1X9lv6BTtpl0wjyg4zz0/s/ZSRr
/S7hdQUyyJzMYz3Z9FnkCU8En3WO3YD9a8OnVNCqLbCgU4M25ughR24WFy26PtiUUKIdIaE64+8p/B5d49MFvX999yVQ8gictFuHGkK/rDPB
o47O17DDsHvIEhaEi82hQWomf0zN14EYqvenIOYOuAemQ4563PIAhFkMkEApTkdvE6k4yK0ey37ytQ+qCcxm+FGTQNSrqdIWzKqNZyUhVyfm
Ylfsu8q2l+NSJvni5SQfYy5eXqFjvFn0yiyC4LP6pz6sMvPJt6wMP5Tz7zqHEk2f1+bQ6ibY7yY8yhhuOgJWWXSO1Kz6xuE2e+TUWcllvvM2
kQHL/5BXuHLhed3KYygfFl7Pgup0iOiO8EGiO1YaPAHf08w9Bb59hU3x1iUzzfgjCOr8jYDrFEvhZ0T6FkJYgKfpk6v5BIyH5Kj5Er0aj8f0
PRPRifbt1cyhWsm/OVdM7abKDTgFPr/BeRsByol+sWHc8WqPqBVbDdnhwzuG5WO5zq3rcpXHd9Toxzv5ZPERi2Y0zhyMZq1RZk2Xpn27T/6o
2VdD4kOWe7ku3ckLydmIidNtQSsXTW0OF/LLf6b4bc7cVLr6wPhvzAf+njNGo+kX+MP78zyxKOcg6/kUVMU/CtBdZcnGYB/tr8IZR/FdT7ye
ES7sKjxLMgDiTHfSU5aVL/3K/dXZ5fDyZBSUB6Yr/VWzvyNm/28LYfEpwT7wtwFd62hjnToQWvWV/qzE5A2UOoAAnocXX/BRbD4XQ8/bySjx
vCHXMexYAd3+WZ3yZ54vqnrHG+TtjOwW0BZMATUUKKUQaABNk3T1kgz+OqawNsPVx9bdJF9MfrqrtpiJj+bp09DukQ7xTuAJswTT4UXMh/in
NCCwpaqEOrJYv9Boa7E+vRiM/9JdnB1bjDnpUsqeEIgscJjYx3jRH65Ala0yoxYEE+GA55EEeo0pB1NtCoyern7MtBtztj34LxfRia4=
""",
 "uct_curl_v02.py": """
eNrNXHt328ax/5+fYsuc0wtQJCVSTm4jVblHVJREamrryE7aWFVRCAAp2CSAC4CyCFnf/f5m9oEFCdJ2H+dcNaXB3Z3HzszOzs4O2O12O8ug
9IJlPh9mKyGch9Fw7AoxGAgRRPP5IIiSMsqjUIgzcSJonDNBf5oIXyR+GT9EIljN4yTM48Cfi9+iSMzyOBx2Otevfj4XFy/F6c+n31+87Aj8
vbmPC4H/yvtI9IArB/JBGCVFXK5EHgVpUpQ5+InTpCfSLMr9Ms2F01VDmc2ueyTEZc3L/mJ5wMinGPqTP5+LfaAq4oJ5A++LQvhJCJBHMRkK
cVESBy9fvWEuJEk/TqJwgH+TIkvzUvzg537or8QyC/0yYuxM7dwVg+9EONkPS4lpWUTFmpz8B7A9i4q+SFIx9YNI+Hnky69ROIvEPEpm5T0a
ilTExAzjJ4bO3gyCdJFBqnfziJleLItSJBFQirsI05phWkwlTph9SB19/1UAVPxDK/IfopinJTTwy8uLN6/F2auXb65PMcCBpFylh0i8j/Ik
mgNnucyTwmg2evSDcr7qi3gYDSE0EFomcVmID/cgDIYOIPrRkNFc3a8K1rrSj9CqPBHpssyWJVQBgKEkiIFzzCP9kJAB+BgdP8QFVC0cRRRW
FUQuGP/x+uJ7i+8ogW4DzPpuJR78eUxK8eIEBIpj8RCnc58sphDQYxGJM8zkLE2gzaA8z/M0l3P+8T6FLD/EYXkvZuI7TEI4M3A6FsUyI61H
4X4ZQbyhC4aTHArL7mN8VjxYzviXJAYrC8i9L0LuDtEtDlhZ0xiCgtC4hwR3DcM/ffn6WEyXMMsgzoM5KfF/lzEMlNH3eOgJuOhlMVNwMr8o
GMCTACc/+HPMiqzbFx/Igvqk+sSC/6OEdyWPr0t/NovyOJlB/MW9n4GWcwbLSsp4tkyXsLwKhlnQZN0jBqG/SU7Uk3xvtDeeycnzA2RR4UEI
rHpIOIyhb7brogYlJghUjSdQhaUG9at4sYTs10ArRdUCNVQJB4M+MtE10MveDlBNldamkGsTUkgTGFlMX2KIk/oKWp3iQx6XZZRIQ8k9pmNk
4fbRZFAwPTTB40WPMMm/XLz5SczItmCLS2UeReYHJP8wPzbsGhw38S3M7mD4dc9RpNCyZx73RrfusTWczYu0T15gjfuhwe6cPsKrYVFpPDMm
ImbwDzCnOIftS4Rgan9MSI/Zg6TzUIz2czFb+nmofHMegR78eJpEQymTU0jRz3N/VZBFoQ9dIixXWSSc6Tz1y8OxAE/8+M0LZYivfnlz9csb
8eovL8+vX/90cXUkLrFsLnnZXFbSt8Grlfc5No2QHHYSoGU5ndK02UWkmPPcz+ACY+JLRH5wb+acclNCCyMhwcAfYPGdb4qJpqVULGxXc6wU
xzawTMp0GdxH4dByF9JE0qmYGHanMdwYu6KydmqOT+LfFxkRDeMAj/CA6JicFeTQTv968Vr8+dX35zCg6AP5BmufBUO0VcXTaUN7pD7NrUO0
aF+lDavEdiX3UKaak6KlmoD0YB8fI/atIdh85dz/HXRYHJlylCIir1jQFHLehaCMDz6mSavjh4vr12+gy5BEG/l5TWeqBD2No3nI5D5AKXBK
vG9C6vBSzoJ2B1fQNgYTSXibTCT8Ig0jVjyeqR/ygc/M0wWTOPPhgYvYT2pYudSdyWNfTFau1IJf1ks6p012WdBCezHIUsxROMHyLg5c9hSD
7+Sgtck7PHsWzAsXC9knWx4UJC2md6hQKVcHOcQPMs5JE0voRJWcvqQRWuMKEcFh83aJ2WO+JyInW34UoQeDEHsCK0A3lGLCVO8hfwQItBL9
RTaPp9hXiV3CQN51gzZHHhbvhu/QmVTufphLM8ZGWGDDiWDthfb1PbMOhUO4Ct7gXF4Fd3H5gTZRoMR2QXt7mZJZjY5pJhxHAY7BYHQiuPeT
WTQ0iC+SBHajRDezlpDD/lL8UcwknZfnv55fYy/0OZSx7APmWAc2Ikxpo0wpBsIUwQqtPhqwqGm+0XL54fTsnK0k1+SwG8jVIbD8mJgJqu7J
8RGlebyIS5oOIotlBGDnoC/YR1VuTeRa79ocOowZT5LT86HyF1ichVwRubfAnMhtO36SLOfLwiV1mcVMVHmR+vBJ94sIchbOhuBBvIvoPF5w
RJosFwjPyUiyTqfMV1KXqjNYyr4g60SPQZSV4oI7OPpBtPwVmdaPV7+IovSD90fMwMvl4molosVSLYu7aJ5+oKUJTkknCA98uSCCDCJ8CUPr
dKCz1xevXuJ7F+6r2/nzLweeCdPQqKK++pzA8lAx4zGkquLFy7UIEetW+lHptgoZCHY7nU4wp3BoI6RzfiVlyehOigKyuqbwL6RANZG7QaGC
w0i6ausQwW6UsA1Jxp2O96fz65fnP3uvr+mUk1MjbW5hNBXX56c/e2/IeubHnc5XaMJhQUyuHb9/1w9cFTndOL7bKyY5VjgWuHMnv2T8JXBv
a7grCw5WpuAyGy5rg3trwVWGXmXDVRZcZ78nDx84r1jnE3M6Eb19ay5nBrnj0ERdjk4wR1DpA3kfOF2gli17I9PmutbMtmC52sBiWgjTGpa3
W7C83cDSaNkbERZMeiJjb+3xpddQDkmexiCtqPwQwUh4J/EHI17NvtuQydUPW2ZzRmQHo+aEzhrcgRNixXi1o9bdrW1DQxzXn3j9M8+VO+P6
vtbYytjxXPPU4FX0RuSAt2/xv8HI3R99QxuHDGdPB6Ph8HRvfLy2kTinJydwynFh7SXO1/3R1/0BPtdwEIZDIgs3DZ8Ss7uXfp7wwWVgwzqV
kX6DK4Ni4hEfE29vPLTlfXZ6/UbPvT/566/9yW+/uuJJ/E26IDql8xIUd3ngYYk6zqlLIRI4/5sJCP9Hq8qhOGj0zfDAdXuq6eseGe8pFDTx
8AEJk+Zk30h3kj3W3QPRBN0bN4FV66HVanNz1MrNQEINRm2MfLuDyW+38NjCG84Pm3LLlNzaWLoyRImvdbJXO1iq+/ZGNUtW63iNJegWbJAW
e0FaeFlwQ8NuAUUc9hDNmTYD8psBsbvBBoPYaI7Fcwd7IBZJIrpnXeF5s3l65889r/OQUvRs7QGezIA4a5LqAQgbfYl8Vul5cO79TwygWOET
Qyo5oKXrMt/eZRC3dVafoKlOEp8cpU6Z6+M4w2F/5YjIbmgwQD4qMRD8zQLg75X9bfYJvqRO+9sHSEOgwz4cLUbvo4EcKnn/5gGhiKtIJwfI
46zNkxCFa7ySc3TFJ/+0i8eqWju38VbyJEM04IvJfOdp8P4ifBw+9vjx+3gxfIQJ0+nXD7nj2AC8swFWNcCqAbCqAd7bAFUNUDUAKgUwRXxM
oSsC2I8fQYweSXD48p6/VK7KCyLiaSp5RnOJgRWh9YzYfKeeiYP39Hy8bhaVR2m2hFgZ91RmSTYRTW5UZCBQHKAHnGgQpGoKBZ06WdVUHyGX
EdeJwtkjWn2lHRl/nTD94w2wjMEcCYfgwYDK8GsbWGVTc2gMYCVYZcAwp9EG6BYuCZRTgJKgMazL/lpaGVPXMtKx65GVU5ohqaQTRZQDX0ty
OUhsBO/rtAXv2HN/maA9d1uWhdxlG/iP18fEyQPbPm+h2E8A07AXOWgsU5zCBFH7crmho2o2V9yYNxvz2jYuuQtHZBcp+IrRYNsIyQEDuGUS
GOVp6hRYzuL+7B32qdl73qV0y4Bb3J5k9XgTS+aFlKYkLFcKBhDQPO91dQtCLsZSWTxL8uEkJxYHkvG8lde8pnK9QeW6lUrbfHOJgz3T73/P
C5bCpM0gaXDYMyJgkeht/YVqJ0m9awgLu7lsYQbyphukaPKoDiL7HA5yVkMGiGrOKjTaRmIwapDYcEABJjeLe1hP8DXveoX0IbP3UhiXdBQL
KPUJ4+wZ/Q+UEtUgOnfxICX0gZKcIkb+UW4BTx3L15tMjqcyOSsA8veV/P5oUjueSu3QCNWyki2PnLNuSfS4tnxYm9NHJCKmK3yEj3TdsMJH
+TjCx4o+Hsf0NK4TzBxCQ5sQC/njvkFQ655mpg3CmpxFckQQ9EHopzZ6iwS0ZhGRIG7rwLE9UGJsDsTU6qgUFgmeLTsEckgQkNoYGqCrNdBV
A3TFoKsN0GdOz7XPPiMO6eNxQU+Lz5i9BGmd/aAxUGJsnT2w8DQXO6YJIjyfjTHPbQbAPL6v7cVtGzQwg6Qp1YOaTt4rG25eSXw8POjpkJwW
mXvcBh4+MnDJiixZkYSQzFl2sJrKle5oRRJklEBScf7s3S2COm5RpwG01GCXlVzagOmR6AY0tkeCVk+gO5C9j4rahkXoxa72GifnIJ+SqnQm
VBtQLjcga9Xa2yfcDToF76EqNKSbnR7lFSy3d7wNeJ6uAQuhgYXYBcwuTe951xt73vWOPU+Kz3agULWcyEAxpWSgiSgWnjvPnKvsqCMVhcRP
OIh1KH92t4znoT5r8ZVRnbE7QzIkxp2oQ/k+iv3knZIrbwSWSFBe+x/+xKBD8RIp4ELmOveQxUE+k5N3hCrxFxHHV0OGV2SG1Kw9Og+hTDLO
CZrNo6bDBdNddZnVPRLysdtXD9+8oLYwXeJqvvt8Q+huDbhGKJvZ+oaGc8dKLg7zKJtDo05XphW7vEvO3X5HfNZft+UA21XXlhywr7GidLDw
30ceXR85dEijo93sBGuexXQCqel7O6MYvv0a0EE6oXyQlT8r9s1VqL4CDZEY58Q2gssZbqFF+12k0Za+YCXnDeKotcAdAjijuFmeB8hU8dED
q+4QwX+t007jKrUNhQbHIwLIHUikvPQ5uUYKmX2Fe7l/258uWcAmz8rwSLZIFx7ZbPjDWVQ6Lu/QSLjH8taDsu6cnESdBFa4j1WCrCRZVxLy
KQnpFvZdJIOCW4BYKd1j9dWUIH4HOHI4X2jVhbaQGPfDEKdkukvC4RnpScaBepJFtEhxjerIewc6R2DduUaFYPNLuKwXWsaeBUwNIRF/mJWq
OoNm0TbK8xiDx+cZ0pTn3XQJtHt7c3Db0CR24gxKl3AJza7QolgrGnGQ1JF5G0rNNG6l+y0G0b447RKQfqNeRK0uu4bjTb6M1i4qNi819CWf
uq1XXXWBy1BcLXN1duPz3DEF16qORx7mjILOIcENAsZX8sLpTnLybiQH/reiz0tuu1Rtl9ymJCIflUyU04FyGNeXCdTtmIKtpC8eyCU7Tjch
0kmO4zSeJQP0j/xOjCAtQc8zPM5cy6ZgjJblPfTFXZrOXTJa9veNLjitkvAOyaBQJWPjYVti1Zw70+5T8mzu/P1EqPEgDZxP7EweXJgnidPz
npU8wMoMl5wja2cxCGeNAiSNWhUiEdLZs1ujgS8DHp4El/io52ob9kbBUgvyJH/uP9EA+qdiSm1KCEkJoVRCKJUQaiWEpISwWhM9385CnoUs
f4JUiNEHKko6+BzZSjD2H3xlytw+bDDoE4NVnDlsv322vE1GcI3ul2VO7qfLvr5r7MDu4qqo7k7VK9+mXaJSTEhB6ySXYYZRVR12uDrEcEyj
3l4Px25fbLRi03Xb1Clra4yMNkpslJzC0tjMZ8vJlyyI3+H8W+4SgRz2pMbjeywrc/hmapLrfvCgdZUgr5Xh/xWn93I742eeVR5QFpD4Sclh
F1wRcgIJp840Clc7J+6hVtmreqq6nQmiby2MImfWGONq17bZWq23NTFpF1gz6Ta8oQR2n79ME+Uym2OrHLI5uqQQEshNcrtLKzwYHqgB+0zA
qrIwFE8KjfZK1gLxYXb+rBgGXl0P+Dmr1K4f1Nr+CqtjhvqBXFWI7gsZcXRkVhNL56QuUuTG8kPqZXQ0GfewAFTFIziztsqmqd4VDiMaKFAX
PmIUDb7tya/bOF/fencUXaqFRFR+lz8fy9pNPWsokEPfpNCrLELGRs7tO8VSz6GglZhqXcgWQUNFUJUGHWYkAztIKjmr+DtIUZcVo+paVUHm
UyCV4aQyUBPoWv5FDg2soXob3jZY2QpH1vO5Y3v3fIqQk4tfWvro6ntTBnrxUF22CdxVGRvoJAO1A3D9jQ4sypTOY9+8IDtB/zR1bC/rDqOs
6C38R7rH7EufyNzCXsDhkHqotqvZEegO1/Lc1KIGEAW4OMJAZ1zEBqTkdL5jSmqXUHWfOAJR5adMs2Mn3UIHuhio+s/pzdFgRDeZeBod3bo7
SWrZKaIUKi7iUBYIpKZ2sNvQoVJTjizJETmuJOd7AncnARM+bK88VQlmq7zWQFF9aZ+JH1gmbIohNi/Ljri6y5RWyVoH3P+gaC2eF65da0WZ
Al2koBaFGmdmDUkqxMODhjOhwGzc7jG6zN2MS7g27/KU81D8rflUCtMO/xWsama1pFRhFOrkoYv7OMO6wfHFLzi9fqnLcOWbAWldIkulsaok
1q6IlV6Ls3BPyZF1KNy5TcmNLKUSKjopbJwK6pAjVhginBTpfY3IISjLvmjQHY1g/E1JQYB3JA6fWHZ4FNNkjdPwIecYUFdD4aTd4q8H7ioN
hkq+ZdTocArEDBHd0jkF7DJCNewJCeTGRx6R/r27XeepGEGpkSzyK8b0PNokVrt4pbAn/1kroxBPd880G32M1gqktZvl6X2Mcj+8aNDVB1Sy
FH04NeclebqUQf1MZWvqQ+RPlKGhlUCTyH1Zn1uaFzuOdt2KQxTWrbhLl+SJo+J8WeuLIMGcJenWMpC3pSbTYiI6O9dSb/T5lPKz0v02Nygs
gMapHTjBqMM01tI0HC4TZzs7Fdt07GeqvPC1XOWp2LOzZrvOqluzcC1JgWYCYCtkS2JAZyM4NNmaJ4jrtEVtfP+JRMYnkxkNFredg7gCoZnq
lUPJcvC6lBkYZPeUv6cPSVHVUHzeEnAbOGSmVWe+0Or27QaMUNHEvbyLhA3/oS/wnwp0uE5CZRHptPLf7v4+erV5m690ZjnEFwX23pGAfY1Y
C/af1Ufg8JE70MaMh8rVaYrDscNZkfqbHFR/r+rjimmcsSi0qAOnCNeg+IaTKhWR7ZTV1gN6bUzuNfKFA1WErV87Q+RRyhfFBul0MKlf0Fsm
9LZASS/3kY92O2rZ6RfSIOCWhaiWKGeyOc3oweuUX7w8P7k0W5ZgK6LPW5Zwihe0Aw3gbgeyyrwuooarrT0w1zyiQ+/YTkFXELqshQvR/SBP
i0ZW9f/vkpdVK3XxTrV5uu+oupu6skbVutCnq3ozlbRnPHRobxlTWRgcXVLj9k11jRqX903xzDo1GZ+QrKYTuqJllHBYOQqg544rRWh9q/Sz
jMLqa3R5rYTA417en1iXDa4sfWruirJx93WOBVEpJGxJCBBOuvE7HQpOrnnhLO5CXyBrdYdlfERzuvGpuBzpb6qA5Ec+QgQyjplctUJlDJXV
UFkT6m0rVMVQVQ1VNaG4XH4dTBePqwZVKuvL7A23uIrT7dBXDWj5TSIw0G+3Q79tQJtvbDqa9g/baaMEHVHNyGbgzGBUylHFT1z3ZFdJmTBF
747uv7zr1ZgY1btc386q8h0qxGPRNOqaqHWgWlHkqwuv7ArlgSlo0sZOAqqLmnTrgMSmUFQqALjjUiNTWKUYeNdkQjHwrsFEbo5qNHnrIArz
p6jR2ShZSnmLruuVDJ09oWuVttCHW9pGvzELrEh+YYtfbEJGISUtcKcc/C6z7tPXhXW9Q1iUSGA89qG8Oe93VX3bXl/3A7m58F+bWz1Kj6jn
uK8oNf8GNu8NW7neaSttd3O8Z+MWUS8Ib+0g5k+Vy0RWZ7Fc0DCdCQaNw7a62q+M/JFqQBaIEly4xME9yR3cJK66iiPsqVHGm+sy4TeU6M4R
h5u7FMFH0WBAXp9BXVy37081mzRv1VS7Io+kULeOrcG67VC30bsQzakGu6a6VukEH8FWTGiD2r0wKa7t94PNljVGddt4K0t3eWCbs88rqS9l
QiWlSZMpFNBLppSHZbYMB1e1ju0G5Yc9VeqvmsbtDKljHvjqwQfisC0r/alwD1/63CGfZT2/GlWnD1QRG4X6ZHWWsXdq+6mzQvvmlZPNFzgd
Y2ZkTYVtTtLQ1GXUoPCneGkHe3JMST7cHq5qW6vJ+iOuReRyX+GP9Re8YeMvlGFgpZNhaE9oleLpujk9L79e4semVs50jhudspTMdC42JSIL
y4wZKI/aZycqS+waxXXaMfapFm2ka9F0q4V2tQPtSqGtC+9stKq1Fa2uUmvq2PipY1OhtjZAu6w6IaeK1bhMjQvU7K25J89AlpCsOrSNArWN
0rS62goWWbBBwlRVORo/NF16YArQTP2ZKT/j6rOOOR+3FbSqelYdl8qirHe5qWBd68hkR7XWXKlTVr5M2rIf//rh6bNPTdfqh0Yc+8ji0mur
8lVUfUpSr4729WujeMJBit5exe7JNWH8kqqPOixzcCrueX/efeMoFY/V7s2yJWvPLmDR+7Pqr/c087KtUT8yVsvQH0KkZbyIqHDn++gBnuIM
/gE1PGawehf3nP/B8bCJpmaEf+BjK324cFTk1UmNR5m5feRb5k9p061t8lLhqSKcOR1IzAosGaMn757oWHJowbWl0HwcCBDC4ixAn2N89i7p
6ZC/v7j93ORYS4KsTo+1nEGtDUWKhPMGDZFcgni3WTooHFiPKy2FpZB8mRR2Zyho5v9cevBLZq5mDVpduVyIk438gyPf8+Y3p7kEjH+roXA2
KDXXuJ1Z/tIrfMWYY2S6eYuvEradtSOwGb52tf85w+sbfzVcJ3zpPSGvyvBLIvfOenkjObOT0TdyMvKhOvkDOzU1eRZLxcWKtFsPR7JV5hjU
nfV+Uie5+/JetaW8UvMlD5uWwdA17JdoRfo3SqE5xRxOxqGXrfgij9L2jRaZ4Gu2VWqbTfm1fCrKlQETTi5vByymI/nKNP8iDX4tAb+PoULw
UP3kE3fP6YctjuQlAgVWahvlV9iHwyHtNbSvoyLcvTnqs0eVn3IJKafPLh8xH36FACWIVN+8ZVtiyX5iKzITu+lKhXdv9SUFLllRB17Mb/k0
Jm99ZaKGenLq2WjNrFZV3KZe7mtIdPSlYr/p1jelHy+rwegj81mzSd02o1pFuKiaVFovfx/Tm/zqbaJBviF8+RNoSM80ldHrjT9DH96/TxOT
6gS84geGPhKve3lzsixjuu22rqPX2FsTAs6LyjwrFgDFn4PR2mTl5Kv1O6qq7Yaq2hBdFdzU9Pvi6D8tIXI+FeSDX5dqSidX0jGGYPlXgJp1
A1eHQEGXHlII3vW8BaopPK8r/ViW03XYtFEtLh6e1M93PB+JJ/uXO56t69zQVK/VTrMuYLML5gt7HTfdrhUCYfJUNBlRfAaYeqnWtb6K15sn
u8KDa/efbzUJcKye7JomCdoVcMCPtLZoEX0UJ11d+BFV7tbB+UdutQbn2wdDZR+bg7O2wbSSB7zQtzDEEth0B224+FIXvlmvJ8MILZ8NnC3L
bhdSaYJGFGRzzflJpE1Ldd3O/wHbj41a
""",
}   # frozen v1.0 / v1.2 sources, embedded so the Colab package needs only ONE uct_curl.py; verified by SHA-256 below
_BASELINE_SHA = {"uct_curl_v01.py": "757f95f4e1a222d33278d9bd36a1dc2388be5505ee1249d0b2f74b2b80c7797c",
                 "uct_curl_v02.py": "820fedf812877c819c77b68511e854fa853242758f9bfa331b363a1915e542a8"}

def _baseline_paths():
    """Baselines for the regression leg: REGRESS_AGAINST if set, else files next to the harness, else the embedded frozen copies (SHA-checked)."""
    import base64, zlib
    env = os.environ.get("REGRESS_AGAINST")
    cand = [p for p in env.split(",") if p] if env else []
    if not env:
        d = os.path.join(SCRATCH, "baselines"); os.makedirs(d, exist_ok=True)
        for fn, blob in _EMBEDDED_BASELINES.items():
            local = os.path.join(HERE, fn)
            if os.path.exists(local): cand.append(local); continue
            data = zlib.decompress(base64.b64decode("".join(blob.split())))
            if hashlib.sha256(data).hexdigest() != _BASELINE_SHA[fn]: continue
            p = os.path.join(d, fn); open(p, "wb").write(data); cand.append(p)
    return [p for p in cand if os.path.exists(p) and os.path.abspath(p) != os.path.abspath(KPATH)
            and hashlib.sha256(open(p, "rb").read()).hexdigest() != SRC_SHA]   # a baseline identical to the target is not a baseline

def regression_vs_baselines(host, gpu):
    """Compare this target with each frozen baseline. Annulus grids: output must be identical (host: bitwise; GPU: within
    TOL['regress_gpu_eps'] machine epsilons of the field scale). Axis grids: Jr everywhere and Jphi for rings >= 1 must be identical;
    ring-0 Jphi and Jz are EXPECTED to differ (that is the v1.2 change) and their errors vs the analytic field are tabulated."""
    paths = _baseline_paths()
    out = []
    for path in paths:
        K0, kn0, l0 = load_target(path, "curl_baseline_" + os.path.splitext(os.path.basename(path))[0])
        sha0 = hashlib.sha256(open(path, "rb").read()).hexdigest()
        host0 = HostBackend(K0._KERNEL_SRC, kn0, tag="baseline_" + os.path.splitext(os.path.basename(path))[0] + "_")
        legs = [("host", host, host0)] + ([("cupy", gpu, CupyBackend(K0, l0))] if gpu is not None else [])
        rng = np.random.default_rng(23); rows = []; arows = []
        def same(a, b, leg, scale):
            if leg == "host": return bool(np.array_equal(a, b, equal_nan=True))
            if not np.array_equal(np.isnan(a), np.isnan(b)): return False
            d = np.abs(a.astype(np.float64) - b.astype(np.float64)); d = d[~np.isnan(d)]
            return bool(d.size == 0 or float(d.max()) <= TOL["regress_gpu_eps"]*EPS[a.dtype.type]*max(scale, 1e-30))
        for base in GRIDS:
            G = Grid(*base); sh = shapes_of(G)
            for dtype in DTYPES:
                for label, B in (("random", [rng.uniform(-1, 1, sh[k]).astype(dtype) for k in ("Br", "Bphi", "Bz")]), ("ADV", G.sample(ADV, dtype))):
                    for leg, a, b in legs:
                        Ja = G.run(a, B, dtype); Jb = G.run(b, B, dtype)
                        sc = max(float(np.nanmax(np.abs(x))) for x in Jb)
                        rows.append(dict(backend=leg, grid=list(base), dtype=dn(dtype), field=label, identical=all(same(x, y, leg, sc) for x, y in zip(Ja, Jb))))
        for base in GRIDS:
            G = Grid(*base, r0=0.0, r1=1.0); ref = G.ref(SMOOTH)
            for dtype in DTYPES:
                B = G.sample(SMOOTH, dtype)
                for leg, a, b in legs:
                    Ja = G.run(a, B, dtype); Jb = G.run(b, B, dtype); sl = G.sl
                    sc = max(float(np.nanmax(np.abs(x))) for x in Jb)
                    jr_same = same(Ja[0][sl], Jb[0][sl], leg, sc); jp_same = same(Ja[1][sl][1:], Jb[1][sl][1:], leg, sc)
                    e = lambda J, c, ring0: float(np.max(np.abs(J[c][sl][0 if ring0 else slice(None)].astype(np.float64) - (ref[c][0] if ring0 else ref[c]))))
                    arows.append(dict(backend=leg, grid=list(base), dtype=dn(dtype), Jr_identical=jr_same, Jphi_rings_ge1_identical=jp_same,
                                      Jphi_ring0_err_target=e(Ja, 1, True), Jphi_ring0_err_baseline=e(Jb, 1, True),
                                      Jz_ring0_err_target=e(Ja, 2, True), Jz_ring0_err_baseline=e(Jb, 2, True),
                                      Jz_global_err_target=e(Ja, 2, False), Jz_global_err_baseline=e(Jb, 2, False)))
        ok = all(r["identical"] for r in rows) and all(r["Jr_identical"] and r["Jphi_rings_ge1_identical"] for r in arows)
        out.append(dict(baseline_file=path, baseline_sha256=sha0, baseline_version=getattr(K0, "VERSION", "1.0"), annulus_rows=rows, axis_rows=arows, all_as_declared=bool(ok)))
    return out

# ----------------------------------------------------------------------------
# GPU legs for Tests 007 / 009: validator on device arrays, ghost independence, compute-sanitizer
# ----------------------------------------------------------------------------
def gpu_validator_cases():
    """The module's validator applied to CuPy arrays (pointer-range aliasing detection needs the device pointers)."""
    import cupy as cp
    G = Grid(16, 16, 8); g = G.g; shp = (G.nr + 2*g, G.nphi + 2*g, G.nz + 2*g); N = int(np.prod(shp))
    def base(dt=F64):
        B = [cp.asarray(x) for x in G.sample(ADV, dt)]
        return dict(Br=B[0], Bphi=B[1], Bz=B[2], Jr=cp.zeros(shp, dt), Jphi=cp.zeros(shp, dt), Jz=cp.zeros(shp, dt),
                    r_faces=cp.asarray(G.rf.astype(dt)), r_centers=cp.asarray(G.rc.astype(dt)))
    def check(a):
        K.validate_inputs(a["Br"], a["Bphi"], a["Bz"], a["Jr"], a["Jphi"], a["Jz"], a["r_faces"], a["r_centers"],
                          G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, g, True)
    rows = []
    def case(name, expect, a):
        try: check(a); rej = False; msg = ""
        except K.CurlContractError as ex: rej = True; msg = str(ex)[:100]
        rows.append(dict(name=name, expect_reject=expect, rejected=rej, message=msg, ok=bool(rej == expect)))
    case("device valid FP64", False, base(F64)); case("device valid FP32", False, base(F32))
    a = base(); a["Jphi"] = a["Jz"]; case("device alias: Jphi is Jz", True, a)
    a = base(); big = cp.zeros(int(N*1.5)); a["Jr"] = big[:N].reshape(shp); a["Jphi"] = big[N//2:N//2 + N].reshape(shp); case("device alias: overlapping views of one buffer", True, a)
    a = base(); a["Jz"] = a["Bz"].ravel()[:N].reshape(shp); case("device alias: Jz is a view into Bz", True, a)
    a = base(); a["Jr"] = a["Jr"].astype(cp.float32); case("device mixed dtype", True, a)
    a = base(); a["r_faces"] = a["r_faces"][2:-2].copy(); case("device driver-style r array", True, a)
    return rows

SAN_SCRIPT = r"""
import sys, importlib.util, numpy as np, cupy as cp
cp.cuda.set_allocator(None)   # raw cudaMalloc per array (no pool) so the sanitizer sees exact allocation bounds
spec = importlib.util.spec_from_file_location("t", sys.argv[1]); K = importlib.util.module_from_spec(spec); spec.loader.exec_module(K)
launch = getattr(K, [n for n in dir(K) if n.startswith("launch_")][0])
rng = np.random.default_rng(3)
for (nr, nphi, nz, r0) in [(16, 16, 8, 0.5), (17, 11, 9, 0.5), (16, 16, 8, 0.0), (17, 11, 9, 0.0)]:
    for dt in (np.float32, np.float64):
        g = 2; dr = dz = 0.1; dphi = 2*np.pi/nphi
        rf = (r0 + (np.arange(nr + 1 + 2*g) - g)*dr).astype(dt); rc = (r0 + (np.arange(nr + 2*g) - g + 0.5)*dr).astype(dt)
        mk = lambda s: cp.asarray(rng.uniform(-1, 1, s).astype(dt))
        Br, Bp, Bz = mk((nr + 1 + 2*g, nphi + 2*g, nz + 2*g)), mk((nr + 2*g, nphi + 1 + 2*g, nz + 2*g)), mk((nr + 2*g, nphi + 2*g, nz + 1 + 2*g))
        J = [cp.zeros((nr + 2*g, nphi + 2*g, nz + 2*g), dt) for _ in range(3)]
        launch(Br, Bp, Bz, *J, cp.asarray(rf), cp.asarray(rc), dr, dphi, dz, nr, nphi, nz, g)
        cp.cuda.Device().synchronize()
print("SANITIZER_TARGET_DONE")
"""

def find_sanitizer():
    import shutil, glob
    p = shutil.which("compute-sanitizer")
    if p: return p
    c = sorted(glob.glob("/usr/local/cuda*/bin/compute-sanitizer")) + sorted(glob.glob("/opt/nvidia/**/compute-sanitizer", recursive=True))
    return c[-1] if c else None

def gpu_sanitizer():
    san = find_sanitizer()
    if san is None:
        return dict(status="BLOCKED", note="compute-sanitizer not found (install the CUDA toolkit or add its bin directory to PATH)")
    script = os.path.join(SCRATCH, "gpu_san_target.py"); open(script, "w").write(SAN_SCRIPT)
    out = dict(status="RAN", tool=san, runs={})
    for tool in ("memcheck", "initcheck"):
        try:
            p = subprocess.run([san, "--tool", tool, "--error-exitcode", "99", sys.executable, script, KPATH], capture_output=True, text=True, timeout=1500)
            text = p.stdout + p.stderr
            m = re.search(r"ERROR SUMMARY: (\d+) error", text)
            out["runs"][tool] = dict(returncode=p.returncode, error_summary=int(m.group(1)) if m else None, target_done="SANITIZER_TARGET_DONE" in text,
                                     clean=bool(p.returncode == 0 and "SANITIZER_TARGET_DONE" in text and (m is None or int(m.group(1)) == 0)),
                                     excerpt=[l for l in text.splitlines() if "Invalid" in l or "Uninitialized" in l or "ERROR" in l or "Error" in l][:6])
        except Exception as ex:
            out["runs"][tool] = dict(clean=False, error=f"{type(ex).__name__}: {ex}"[:300])
    return out

def t007_gpu(be):
    """GPU leg of Test 007: launcher validation on device arrays, inner-ghost independence on the device, compute-sanitizer."""
    if not IS_V11:
        return dict(verdict="BLOCKED", note="v1.0 has no launcher validation; GPU coordinate-contract evidence needs v1.1+")
    res = {}; fails = []
    rows = gpu_validator_cases(); res["device_validator_cases"] = rows
    if not all(r["ok"] for r in rows): fails.append("validator mismatches on device arrays: " + str([r["name"] for r in rows if not r["ok"]]))
    if HAS_AX:
        G = Grid(16, 16, 8, r0=0.0, r1=1.0); B = G.sample(SMOOTH, F64); Bn = [b.copy() for b in B]
        for b in Bn: b[:G.g, ...] = np.nan
        Ja = G.run(be, B, F64); Jn = G.run(be, Bn, F64)
        same = all(np.array_equal(Ja[c][G.sl], Jn[c][G.sl]) for c in range(3))
        res["inner_ghost_independence_gpu"] = dict(bitwise_identical_with_NaN_inner_ghosts=bool(same))
        if not same: fails.append("axis ring reads inner radial ghost cells on the GPU")
        # accuracy on the device (axis grid)
        rws = []
        for L in range(4):
            n = tuple(b*2**L for b in (16, 16, 8)); Gn = Grid(*n, r0=0.0, r1=1.0)
            Jx = Gn.run(be, Gn.sample(SMOOTH, F64), F64); rws.append(dict(n=list(n), errs=err_vs_ref(Gn, Jx, Gn.ref(SMOOTH))))
        od = orders(rws); res["axis_grid_smooth_gpu"] = dict(rows=rws, last_orders=[o[-1] for o in od])
        if min(o[-1] for o in od) < TOL["order_min"]: fails.append(f"GPU axis-grid convergence below {TOL['order_min']}: {[round(o[-1], 2) for o in od]}")
    san = gpu_sanitizer(); res["compute_sanitizer"] = san
    if san["status"] == "BLOCKED":
        res["verdict"] = "BLOCKED"; res["block_reason"] = san["note"]; res["fail_reasons"] = fails
        if fails: res["verdict"] = "FAIL"
        return res
    for tool, r in san["runs"].items():
        if not r.get("clean"): fails.append(f"compute-sanitizer {tool} reported problems")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

def load_report_module():
    path = os.path.join(HERE, "make_report_campaign01.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location("make_report_mod", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        return mod
    import base64, zlib, types   # fallback: the report builder embedded at the end of this file
    mod = types.ModuleType("make_report_mod")
    exec(zlib.decompress(base64.b64decode("".join(_EMBEDDED_REPORT.split()))).decode(), mod.__dict__)
    return mod

def show_markdown(text):
    try:
        from IPython import get_ipython
        from IPython.display import display, Markdown
        if get_ipython() is not None:
            display(Markdown(text)); return
    except Exception:
        pass
    print(text)

def main():
    global REFCHECK
    print(f"Kernel file used: {os.path.basename(KPATH)} (v{getattr(K, 'VERSION', '1.0')})")
    if getattr(K, "VERSION", "1.0") == "1.0":
        print("!! WARNING: this uct_curl.py is the OLD v1.0 (sha 757f95f4...). Replace it with the latest uct_curl.py (v1.2) from the zip.")
    print("=" * 78); print(f"ALADIN v4.0 - Campaign 01 | {STEM}.py v{getattr(K, 'VERSION', '1.0')} sha256 {SRC_SHA[:16]}..."); print("=" * 78, flush=True)
    REFCHECK = pre_reference_check()
    host = HostBackend()
    gpu_present = CupyBackend.available()
    backends = [host] + ([CupyBackend()] if gpu_present else [])
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
               gxx=subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0],
               kernel_file=KPATH, kernel_sha256=SRC_SHA, target_stem=STEM, kernel_name=KNAME, launcher=LAUNCH, is_v11=IS_V11, kernel_version=getattr(K, 'VERSION', '1.0'), host_generated_cpp_sha256={dn(d): host.gen_sha(d) for d in DTYPES},
               gpu_present=gpu_present, gpu_leg_status="executed" if gpu_present else "BLOCKED: no GPU/CuPy in this session")
    if gpu_present:
        try:
            import cupy as cp
            props = cp.cuda.runtime.getDeviceProperties(0)
            env.update(gpu=props["name"].decode(), cupy=cp.__version__, cuda_runtime=cp.cuda.runtime.runtimeGetVersion())
        except Exception:
            pass
        print(f"GPU detected: {env.get('gpu', '?')}  CuPy {env.get('cupy', '?')}")
    else:
        print("No GPU/CuPy detected: GPU legs will be BLOCKED (host-compiled CUDA source only).")

    # ---- 1. the kernel's own Z-pinch self-test, first ----
    print(f"\n-- Kernel self-test ({STEM}.py's own Z-pinch test) --", flush=True)
    ks = {}
    for dt in DTYPES:
        try:
            out, backend = K.test_zpinch(dt)
            ez, er, ep = out["zpinch"]
            ks[dn(dt)] = dict(backend=backend, max_Jz_minus_1=float(ez), max_Jr=float(er), max_Jphi=float(ep),
                              axis_cell_Jz_minus_1=float(out["axis cell |Jz-1|"]),
                              Bz_quadratic_Jphi_err=float(out["Bz=r^2/2 |Jphi+r|"]), Bphi_z_Jr_err=float(out["Bphi=z |Jr+1|"]))
            print(f"[{dn(dt)}] backend: {backend}\n  max|Jz-1|={ez:.3e}  max|Jr|={er:.3e}  max|Jphi|={ep:.3e}  axis-cell max|Jz-1|={float(out['axis cell |Jz-1|']):.3e}")
        except Exception:
            ks[dn(dt)] = dict(error=traceback.format_exc()[-1800:])
            print(f"[{dn(dt)}] ERROR running the kernel self-test:\n{ks[dn(dt)]['error']}")

    # ---- 2. the ten campaign tests ----
    print("\n-- Campaign 01 tests --", flush=True)
    results = dict(env=env, tolerances=TOL, reference_check=REFCHECK, kernel_selftest=ks, tests={})
    for tid, name, fn in TESTS:
        entry = dict(name=name)
        for be in backends:
            if be.name == "cupy" and tid in STATIC_ONLY:
                entry["cupy"] = safe(t007_gpu, be)
                continue
            entry[be.name] = safe(fn, be)
        if "cupy" not in entry:
            entry["cupy"] = dict(verdict="BLOCKED", note="no GPU/CuPy in this session")
        results["tests"][tid] = entry
        print(f"{tid} {name:42s} host={entry['host']['verdict']:8s} gpu={entry['cupy']['verdict']}", flush=True)

    # ---- 3. GPU vs host agreement ----
    if gpu_present:
        try:
            results["gpu_vs_host"] = gpu_vs_host(host, backends[1])
            print("\n-- GPU vs host agreement --")
            for q in results["gpu_vs_host"]:
                print(f"  {q['grid']} {q['dtype']}: max diff {q['max_abs_diff']:.3e} (tol {q['tol']:.3e}) finite={q['finite']} -> {'OK' if q['ok'] else 'MISMATCH'}")
        except Exception:
            results["gpu_vs_host_error"] = traceback.format_exc()[-1800:]
            print("GPU-vs-host comparison raised an error:\n" + results["gpu_vs_host_error"])

    # ---- 3b. regression against the frozen baselines ----
    try:
        reg = regression_vs_baselines(host, backends[1] if gpu_present else None)
        if reg:
            results["regression"] = reg
            for r_ in reg:
                print(f"\n-- Regression vs {os.path.basename(r_['baseline_file'])} v{r_['baseline_version']} (sha {r_['baseline_sha256'][:16]}...) --")
                print(f"  annulus comparisons identical: {sum(x['identical'] for x in r_['annulus_rows'])}/{len(r_['annulus_rows'])}; "
                      f"axis Jr/Jphi(rings>=1) identical: {sum(x['Jr_identical'] and x['Jphi_rings_ge1_identical'] for x in r_['axis_rows'])}/{len(r_['axis_rows'])}; as declared: {r_['all_as_declared']}")
    except Exception:
        results["regression_error"] = traceback.format_exc()[-1800:]
        print("Regression comparison raised an error:\n" + results["regression_error"])

    _ver = getattr(K, "VERSION", "1.0")
    RES_NAME = "campaign01_results.json" if _ver == "1.0" else f"campaign01_results_{STEM}_v{_ver}.json"
    REP_NAME = "CAMPAIGN01_REPORT.md" if _ver == "1.0" else f"CAMPAIGN01_REPORT_{STEM}_v{_ver}.md"
    json.dump(results, open(os.path.join(OUT, RES_NAME), "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print("\nresults written:", os.path.join(OUT, RES_NAME))

    # ---- 4. the report, shown right here ----
    rep = load_report_module()
    if rep is None:
        print("report builder unavailable (results JSON is complete).")
    else:
        text = rep.build_report(results, OUT, REP_NAME)
        print("report written:", os.path.join(OUT, REP_NAME))
        print("\n" + "=" * 78 + "\nCAMPAIGN 01 REPORT\n" + "=" * 78)
        show_markdown(text)
    return results

_EMBEDDED_REPORT = """
eJy9fUtv41bW4D6/4gyzEOmSZMn1jAz3wHY5qXIqVYbLlca0yqCuySuJbYpU7qXkNxD0oia9zTTQm28zwHy9n95kM6vq7eCr/1C/
ZHDOuZe8lGSXuwczCYJY5H3f837x6/+0PtNq/STJ1mU2h+lFMc6zh195nrcrJlORjDLodEHJaa4KOJklaSxVD5QUsYbItOh0QyX1
LC30WvuPOs+acKaSQmrY3f7hYPvld6873fBw7+DN4dFaexKDn+UwFlncKi6mMoZsNjmRSgftr/ZENC4Hhfws05AUGv+AiTiVIa8i
tC1ev25PL9qe532VTGh5PHeumzARxfirWA55xaajf9iEsVSyCZmYyC1vaXXtSewFva8AADzPO5TFTGUairGEiVCnMa6jkOcFiCy+
dYe4wSQrchjgVANaHg541IS9Jhy9eQVbcNj3CqkL7R038W+Zzc1fRZ5KJbJIau+YeknYglRMTmIB5z0YelfnvfaGvOEhX1QviyTu
wVG/SOLjvjfOdWH642x9/vMMtuBVW0ynMovpwY/dLmzBSZ6n/l57JAvfS3Q473a9INiEH7sbsEVNcLO6ULbNqVSZTMO5VDrJM68J
Xrfd8YIAfreFf254m/D2aO8H2ALToRBqJItQF3KCrWdREUYzlXrBJnz/495h1fCWkTfh+9dLjfAC3dFCfu4FX/Fefe9r2H61/fzl
a5g/anfg889/ARee5TyJZRZJA9heYLoNvbW1I1pwb20NBle4lZv29GIA8ytc7Q34A5zP3wmg9TvYHzSBZ4bB1fevbwZBE+S5jGaF
jGGWTfI4GSYyBqhN8DafqUjC2xfbrY3HT3iivX7DbE2PxcbjJ43jm8FCt8NZBv67o90Ae2CHWRE1jm8WWr3IdQEnIjqVWYwNd989
3wbNM0b5ZJqkMoazpBjDYPTgwYCut1xynsHuwTvwcfTR+Xnj+GYTDogi0IRMHBrHN014PZscXNDDbDaZXjSOb4L2wkq+O3gHqRzZ
1Y6mszCVo1AXopjpxvGN2x6by0wqgavYffDAPRwPHgDedfuPeZL5Q+/q9KYHg6t5v9d9cnzz+ee/DTwY5gpOmzCHJIM9xoBwZAcM
o+nUHKt33E4KOdF+EOCo7zOzgpO8GMMW6NnE79JgRYJoDEeQDOGFXyRx0PfmUsVJVHjHsLUF3sH227ceHZ/Fu2g2vfCOV7bjWZKh
BWM8jKmSWmaFpTj24H4Ha2tv6Yx6cIXrulnvdoDoBYzFXAIOiDdFa8ad0iK+O3i3tgY+YneSjWCap0kkJyIDnYyyVj4cboLILuDb
7Zev1ndevdn9fu/5+t7h4ZtDGhoikWV5AScSIqkKgtqgDV65MgCPIItBJckzyIdEGeW5iIoalPFSmWoWYzkRRRLpJiRZLM9xaUxQ
ZBYlqd6kdggpUZ7OJpnpHMt5UsKroOkqOE3yrF1enEy1dM+vdnwdPLlyP+21NcA9tHQSy4oC5Fl60YbXOa3iTGgQc5Gk4iSVTdA5
yLlUF2BgGRIN5vD+vxxOUkCcSw14NXRNywfThFTMsmgMJ3Is5kk+U5ArWu9ETnJ1AVoMZXHBJ0YrjvJZVmjYgqubTRg5v+itC/zV
wXKr/hImHMOWeUdwvfS+CR1EtG450GgewtbtGFMuqD+ahzj4yBl9NA9r4xHZoIM3/XVJLuDjbw7ByG7g6vSmpBIZbk7nqpCxb4a3
RIGoAsA1QEm//oVBR6tGrS4AudPX8HY2mQh1UZHAa/garuEIr/ka3G3BdQl/1/BCijhNMgnXTs9Wq4X/Vf+z/1yv+Ktle46liPHi
+XK8Tqfr9cDbzSfTGYo2+1uG021ClqPwkuUQF204zFMUS5APKpkx/x1sgkZRLckgVslcKtBpXpCcFcPAcukB+N8KJWJxQa+Dttcs
597AubfTFLqdClfURCOeRGPCGEQSpG8yQ0RQyZwQYBP0JM+LcWuYyDSGXMVSafj8519gwx3/oR3/G6KI67lKZFYwbYmElhqmQtMG
vj148ojw8NuDh7UhHuEQb2bFdFYgIbByADHTLIfJrLMJ43ySI+PJZxqKHFQ+y2Kkvm3Ynk7TC+iuT2YdyLNINiGfFUiK3Cke4xRH
YyUlxIkukiwqUPhKYqkRGoiObVqR4/Of/7t7Ji0iIqDkUCqkbJswzPNiqhLEbyR2RRKJ1J3tiT0TnZyXJzq3B7+RmdNE6ljA7lEL
yY4okpNUgq8LNYuKmRIpPICJFHqmkGU4oz/F0V/nkGR4YHORJrG5sDdvdvjUGFZaurhIJSgQSokLvQniPNEtEf9RRHjV+5dEo6Gr
C17PJoxmQsWgjIDeAZ2kMivSC3f6Zzj92trb2XSaogy2f1kdDV7fmcqzEfKE7ZFIMmSBuVIyQgGkbNdjZuuXR9EkoKDFJ8iBZ1l9
z9/gpL8n1WB9hLxZr9P2NYg0hSiVItsEkSZCI7HPZFKMpQIl/8gTZ7mCqcrHyUlSyNgZuNshwFBiCme5OtU9CwNlV6Fh9whm01gU
ctPuBaJERTPDQfkdnEo51RAnc4RdUTggaqa7sbLKj91uxQGQWLR5CP+q4nz3pxoylULzQhdJByK3JQwOsSASogtxoWGWDZM0dY7k
TpRsIi7CFnQhzqPZRGZ4QEnGbDePZyly0KxQIir+7zDWhfQfGcBze50aTkQMI5XEel2PxVTq9RgVXr2uRJwk67MMCSbSGVwWQ3Si
YZRncgUGJBp0kaTpAiqA//xxE/KpzILFRd0OigYM87lUqZhOERJzxVCJOgCdJsocZ6BEoiUMdmcq3TUHtqdUrgbuZDdBBTAb9wGY
f/24LOZXh4T3KXt4QiWOomxMr2gw8N/+8ObN0QukUltd+P7l6+9JSUPBjFoR2yARLJMK+KQgQ7GPrByboEWWFMmlVC06OBweGy2e
N9Gb/Vk8Qhg3JAVvtiIr+5fgl3J5Q4OapXj2h91gE+6iMCsO25HSjMxxtKBGXMNVkcQ3cA1XRtpqIDdGhfEa1taujKjWMDJG4/hm
bY3f2OYonDWOl1pc4cVSkxuSQWjWU5QgD2squpbpEGXWSvc51fUlvs++/hq+ZzqGrVsk4vqu1v2H1jRB4RbfNEHNMhgmSheBGbSU
nAhU4NoqvnANE3EO4kT7+5eff/m1G1RPYF+5Pz59gGtGt0im6XK3hZmMJLX0n9MM7yYuwibMQ7yf01IOrHZvDsSTiEwetpqH9bfO
NcZFyHdG6hrdweBqHvYb1Ltx3EYBYeoHbT1NkwJlQ+0H/Vb3uN/rPuqgHeGa/3XWCEuq0+pJaR5zqAw6V9LHZxNxHu5fhpMkm+mw
2zgOFt+pFc+m46T+FM89xHNfGqsSbglKjPz7z+jRe45RY23tijugFaLRhMZ3B+8aAcKzvzsjOwa/JZBvQuM/N4KbJuttapYVyUQ6
TWIRmoe2adBeuP7bURP/GS2rQLX3JN5vwdBrGRxexOAebmgU1lHTW4SuUchnlOWF9IIeD/sAxyVzGA2A7xrHN/W+Zz42DW4bj4E2
6OHlDAaD9xkqR6Owb16U8NhvfdPp9I5Z9xkMBs4ZjZ7SCRAvWD4DnOspzxWxWBGWNNhbOMsICc/oaX9Fy+OFTXnvs7W1TucpOIYp
1qdbJHhaETVXRiHAffkeCm5CgzyfEhX3cHkiTX0V9hv5aeOYLlwRqptVN3jUsBwvpPEaTegfBwHhHXg/vHz7w/bR7gsvgAcLSOgP
vU1mRy1iR46QT/YK3EAPrkZP+w1qFVKr0G0VIpwf9xsnSXGWaBmW4n+IjCV8LV6HTle0xnnusd81rGd34JFa2/aWACXSfY+tfMYE
ZkwmXo8Q09xUq7wpBGfTZG2NYTPSFWzeh2oR0uV5GjbNVeAa1CzTlcFvuRMYStGCwdKaoNXC8eCKRr0Z9Iy2EeWxhCvFqNConhHB
IATQ1Wv6HWpW9KkFG8PJfpNKJE5lW2Mmj/MMx4LPH35FJG+QyNHAU7UN+Ym5hMbB4ZudV3s/vG0gBQhWbhHPJqVDURaDzyOppoVH
ANnvPTrmiwFoweAqDdGwinzDRdh5xd+R5s51SF6GoIa0894qlEN0m2tjqRwpKVEgR9KrxUSCElmcT1hJRItXVkiVIArKFC1gZORk
iUKDUJJEKuroWNWC3sLWSSZA8Q8q0cBy/DgZDuEaijyFaxgmWVLg2/x0iT/ek93bI/6JScD8Vpba+MdfG2w9mogp6s9N+CnsN3CZ
jeOA2SI+oAWXzPYnwzzFiQ5x6RUDxTdFntoH+JO3Y/o2Pv/bfyPI+clSKgaZz//218ZNbbcyTYYrbje0lH7xWL47eNea6xbdKNkE
VKLzjLWFGETGiNAjqs/s4bC/YuAvcYol264hEj3UKb87eLdOvJv0ugSl6axtxVEiySN8ZXal5EhJbfxK/eNghSB6WDYpxfehyi9l
BoOrXLenohi3T4SWyIN9NUKxSEtklOEwSSXewgD8+VXtjfFloXekJkcOvR3TxDo6YFDvWXmB2rCdZbN0VuozCiUl+B10gh4MZ6gS
sv7L1hOYzDTZ8UuSDz6eeQ8ML9hk9mEUjKujN68sLaP9I4kP5RS51bPgBiYiGuMy5VQnaZ7pmqhDaFaJ3AsIx/a4a2ch9xGmFyQp
xio16nuCTyFU+Zn2jhdhkjDspyVh9V/BOUYkmcar8KjczB3oRHRv29FA+ca2oNMEo4zS+EEPdRG0AKAWQjCbZCO0Xf47dJfvcZNe
tzrUmnpdlhQRyWYWyxiischGEnzDiuZoYRDpRZFEjvVLj/Oz7J+4yX3FJPcap/ZxFZ///O/dwHlIS+sg3oNvYZh4GLM1VL/Q/naf
RqM0PxHpXa3uqZJ9GaJQ+/h/Dk418NlX4a0QtNh0Ok5CAohwJLt3dPMWGM7QM8yhHKGDBDe0h0kMAw90dTM+5jqb2b+8zziXXx6F
L/dLwzit3HEWSCjKFtssnMcySoWScQ+Iioo0DYUO7VP0NZfSUcXpKp6wzOis3ukwhQXuVmduS2Pdxdtqmu1LlE6hGIsCMinZGLhs
JDKLL57BFrzwydoUbIKKOJikxOwwGsvo1Gg+5Gb6Grpt9il1Os8cEkAEqMfSlLWQD/YvB2horDyTIk0v2FDOuhAJ54fvXu09B/+w
G5DOUDzj4zzshnatpYJQKvEvHdcNrRF8OTmRccyG2UEVSYRmnyaIVOcwII/HRViuGt/1YFeoQupEZGTuhZMLeFKMW2z6Q3MpuiRQ
UuI+uokWdWMkR2xGI290kSZZrHCDZKB2fiONmMxSoWGmZVxKlkQgUdbJM9xDXZw0ZzrXGMskVRLxylZ46KpHSGH2Ffj29APGExUR
kbBPUWIyYy7YRaj/pw+rB0CMvt8Qa2tolbRte7BxCZ9/+RWiXH/6sK4CaxM0417eNiq2qy/tEvzS8onDfvw7PLDD0hTq42/00133
ZVj2uX3Z3vvsBbK/ygVI9t8t8LvrKuh//uVPvtr59CFY//zLn3iqz7/8aUfhz08fjpvsecIWsAXq4995ZXY1xFid9tyGXlE4AE10
x26qoBbjFyYptHjW90gWWKWO4oG9yZjnDsUkSS/Qsdwk3GTNp6FxXiIsNdPy2pq9jrU1B7cFvx2iJbCAVM5limh9Jf1RvzGcPnmE
1ra5Dt++Ozh49XLveYVgjWO0GwY3dApl5IEeqyQ7hVkWk00cx0UVDvwrNIAxP5T+eUBbPict6IvzBG680GoqUqPGRwtk0Q3msm5y
f6Oz8aTV7ba6zwKIE4Qj3YO1XeMLwzOxwpBI6/7AIl95qfyrvQZHNUN+zY+IHjw5zI0glmeyIreJhj/WHAKbNYLbqsaZJJr93OIk
n9Owp3JakN3JxKncEfLyOq/8fUh3jGswEhn7tMv1CE1hi4XMCJZfUlgjBpmU9hew8UPC2SRfyNpak6ABI4japdO0uOVg8DnHhOJm
2IuqZUSOSFzKiUzzs6ANLyFOYhpXxknhwHy1X8PHNtrwWkzkusrZfTdMMWKEm8SWLXa9oO+xVzlE92FI5nDvGB1cJsDFABM3amhI
8+hUxqDlTzN7pQPkdjEDpH0eRvkEoT589QyD0T7//De2fw3oKMlV+Y3rvBzmaZqfaX4kJ8NBE87GSTRG9BDoqtXRWE4sBJXuT+Ok
JUfmXvD5w687aPAbikjqNkFhLFNcuIztNScaBFlLWsj86I1xr4KSUZ6xox6DpuBQ8iZiuiryx0IqTmSKFri6U3ZtzcDqyjAOJSd4
/aVblujFLKtCrRYv72EbDjD0apxHRkUhZ+vkAjioFn1uPimzcaKjNMdogqAaYhfdmCoR7C4tg2ThTCpZCn9wUqEheYnIX+QPjt68
GsAJXvMKUSNow/awkGqh10uzythdIpDxL0Ef1FzCNK0uhTq2sKOJgybFjBwTar4k4thgaXQjdENedYgThMPkXGoKoR60q91327C2
ZpD4IVqtJxelORqN1jOpifQOmKd9/J+XA8gniOck0/GjdTXgtRqwwUg3lYzGxSYOR+HYhjY4WHwmbJwEfJuco/u9XNSGs6hnuCgS
XJUsb0Ohm73BYhlptO1nDZIupciSbJRKzasWjlhFEMfRbxiZq/J4htdM3tr0AnwUeExonYjRuCJUgiIbWRoSTS4OoZqWVTrBDUEb
DnFBzL7injMp0kipkQnVFgtra7laWzNjff7z/4CubHU3Pv42EefX+9c4OscGEoN1TuahczJPENOnKj+R9ogYxugRSZggzPLPxrmW
gFdYboQUVaIv2NORNPMpRraigh8hIhAKnlyAiCJSE8uoghhJxYh1flHUDoSufapkeetRnkXpjFQdCnLnCAlkrEYriUUhkIYQ4PN8
9KxFpDQze0LzGVDobRKZyCyzwSnasAQ4gUOkCTgn98g5uacG0CvXbMREIM/Ady+qExCYpnmuCY0Fx3mUcNhtP2vDEUK6zHAnef01
4c8mmxDl+TTXZreM0jzR/iUKU8gXncU+rhbb7ZAvqTpsXFCWq4lISWc8uYAiLxBQ09k5+KwKaTyquAg2S1JT5FUn6jOWlh+Yjhzj
ZRSp0oCzGHlx5ntPcHGHeNewAb4oKZwrQhmxKWhaAeEp3o3MRsWYTgp1PUNS5932BlOMWYZbFaS4GUsN3RBJr1GelUeAYHSWm+iK
MgjDAiaGYgwwFmPALZoG/IkOkWDPbIzYG4GJE1UhHIWvUgYd9MCOq4I8wLfxBPuXW90m7FxuqY9/X98ImvBavG4ZXnab581EZpQY
VI8zaaJlgI9C5hNZUOStdSapWdYs925jOf3VzsemDfJdtYJlP9VETuh81tH0T38FjsKPQTyCpE0n3KSN99mh9cy77S5zUSWJf7GQ
z3TYgYXIZcBDkaTYZFKSpkye8S1p4t8qmSSZKOSChfEpAuUrxNOKh1t+LylZwTK5hobGLEtQFYfz//0nQ0DQSLSPZtQGOWiRfOo6
Mg9MJ/SWYMN25/GgDS8z2vA6bZYsLdX042QZ3elSYzlEgdp//jiwoWNk7jQaWj40MLVZYQ8etomE1BS6TSoIRiWWRMNaf74GDMSF
KZ611IUTFnzEYd6FSFJtrT6OdOsKVZ1Ol5D0jeEGxlRcXPTIdV04cdWVam7ibaZCiYkspNKYS1HpcUW/Qa80OTTw7NAv14OrAp3N
+DclhZggMX5uftCLPfbk8Yux0OFeSA/oZVwsvo2L8nUVUD/0DmXKkajMfF0rNhGFPLtFBvC7T/7xV/zvGRvXryTuSEk2Js51aMcJ
u0/Ou0/OnzWO+51j9MyiaHGf1l1ufXmvxhuoS/vFWGpJEiEhhywSzRGZbKRv3hIuVophS5k1GIFNaTUFufyQMTWOb6oA8xJgNhYB
ZoMzoRxzl/xpRovRtwONdw27juULIwGTbDabWFMZ+A5XSi/A0G807Lx1I7mHxI/mUp2IIkGXby0zYpW1zLGYoagYNWFIyIjhHmYR
obXX3WZauYar6IZipoYUCrWYTjS4ym4Gju09P3Xt6xzfj1mFp2ZmXm5IWwppS95xPzrmzAHXCPY+e+sGprvM0U8FCoEiUQHsq/X9
Tx/W9y974ODhsIGpfg+HN43KqlL0GyxQhTRiyKHuIY4V4liIsm2A9xnChYmeWAEUDxeB4iFTEScgnrJQktGXgAKJ8DXHy6M5FF02
18wkq5/oZ/exCYKDprzO01vveuHOoyePmhA9xExEvHIMosFwoWGai+LJI8wuWXr8cMNYv0m1aMIJHtxlMvXtWMvQIdzIyCvpT8S5
Lyi6TpdOHX56svRU1FzwJQwJ43DHczy5w/nucITyeh4tXs8jup7/+F+f//SzlQ8vjdnzi2R+jPlMpm9J8il8rCgTDpEOT2adsHxP
4WRteGECo5PiwiiN/kb78cffdgIkyPSnebwT9Aw5HFd9QiX5YHxlqHngkngTtD3X8PmX//qPv+6AqtP8W22LDtFlxoO0F7nCDs/2
xh9//HuwQGrZdCXQkIKMsrtORxK04fdoDObz2SJ6iieBelmYZK698sYKAeWzpmGCPBSnqUi7G/OwyBfYhFkxhl7Tmdull08MDtfI
vQ29tiTfxq6vRu/Hi/DzmODnv0gU6cRoJFWVZ0aJJXfiOLeBa2s2uK4sD0OVTzjoAChg+z4U3BJRO0ho1uB6YBktB1enRK4dQDVt
G8f9U8bVot9YHMi+rNNhiid3hIMmjLY2At64t1lLLYWrYjZNpT8PbupppUj6aZyFHNJaGqtBu7muJStNZmmRLKbnAPkUKfiJJcma
q+k+wUv3J6Tk9zab4DlD+dMsmYsUV7J8+Csd3Yt+7qVIpVsDlVYTyZ/uJozvs7dkJmqhS++CrQsafMwDYKUd94Pm9h2gFk66E2yZ
ogIopu9zKBla5qY5G7fxOEq2uwlTURQSE4mqSBVjJXCQHW+ATr/DcGNOrAY9K05t6p7a1bTfoH00jm8+f/gVf5ZrpjBoHe4rCpMO
9y8pJhNXOjUXRz3DKqfLY5mjvYIGPFmkAU+IBjxnmljZj9jidQcBeGtSUencSR3D3WzCYOdwd33nYHd95w+7A4xVFpH8/OFXtkCD
mEslRuh6HewcfIvvyayF76Z5SjneRY4uBhGT6C6cED4bVLyvAIxPL4yCj7/1d/6w6//xQTf4/Muv9CfF5x+v+xsx+hDRXdPfOdj1
T00T/LNqchm8zyzv8VDUx7H7O4dV+8OF9mbEP+z6STVpUrVQtREv64u9gr4Kh9Tz4287B9/SX+xSwsf2YXC8Hisz0WG1u8Ol3d24
YXFnPpIivphQRNFMieiC0urJLecd1zLb8RIZj1BirUuhKJY1oaSKgCEZTXjEFk29WVnceo5pFGEF60EcvXnV9+gxRjcZYKz7y2nG
axsW60e5UBrBBE2wKA6i5NpCydUM/0WSVnetMllelvox1aStC6EKjb5e3zviaHWibKdMhG4RLualhMfZD/0GSde0vMYxCeQ1Gja/
g4ZFLLbuHoWcNxkSAlfBGRi/4iRVJilq7ibXOCINx9hjXbnuuxWWVSZO13EyD8ewH46v0XhId9ir71QxhY6TeeOYN00m5qjfYPMc
RoxjPBRuf9Nm0taVkrzX3rBKSb7UmbuwDFOJev72op5+73VtP//RXRRRMdcAl140XcO3SK1B3GSaotSXZEi4SLZsB/WaEz8az7Hx
SVgbvXVBGHOQsdvtHrWSrHZbhmEMk8ioTUqC1IU4SRM9ljH6W9CShH70tbUsx6BnrGPjeDnZFchG3lWE/OkiIX/KCnyeq5hMbGUi
4x1E/FuRpDMy8QmNir6DRVadRpNeaN57Jhy8BVdDG32fDLkGwaqWXgsr+mSuv+59dl23foJPxtiWTi4lZgZO4WSG5lrdBKsbGm/x
HUEzBu1TQUqd73tCi4yzFGQcUppgONpA3Z6eteS5CYq0mcUk9nlBE2zXLpKuZDKb8Chf6Nr1Aiflr/rHjGbdzpjMXFvNyixnqoLE
2RfB0ro6YZKRQdhZ1xZW2amI3Jyoy+nxpiVsqThh2lSlDMz75oclUJRB1oOGIeHzMofMCbAZMdmiREtDrBZzgW30HboTB911NeC0
TEymPpSTfG6VAwfO/aQgB0KMNQfIj4q3yQ40jIegTCkSLnrGRUahXOinX99AJy2wD4gfoiML7bvoHaA8VZsFbbwmXBID02PtG06Z
4khnDOXO03yEKiq/DU8uQtuH8sLQ5qsLXGs+LLPLTQoISpCdSuqny5jgoXHAQJXoHk5EoZJzL8Dog/6xc3x0eq/sIqsewD0wOWJg
nko2kOpBE6aIxBx0j7b2TWhQm4ZJV6KAYXRmNinZPMfAFPP01jzeWuaEUTzy2RSu2cLuaHsVgi7mSvxTkdzzya2htjSzE4PtGGUa
fFFlbCyvylxfCd0iiuS0aLg9ZFz2KR+Y5r5pv7pJouFbgc0cxMG8nCu/gQQYMYgyM6TWYoTxTHaM8onpuSKy91aJwY3sWcQxBHcH
z7BGhB7naQxXo36jsL9QRunImzZ8S0lpJuzccTyLiGwsBo+QO6n1DfC3aJgSEUPrwwqpV8hyPV4Ghqmqre6TYNNJW48oKzq9wDkk
7jJmh/mGbD0jH1FCUUBfxn1Xavg9xlVRcNJZPkvjNTN4UdZuYJsOlrfhbAYTBmP3ZtzUllQ0wUT8gV+omeRAPty0Qw2iDkas4WvM
2HAj8MpaE7d3M6F6xzdVNQrYNgekx7gFRkNe9qVUeUVDBNPcKh2WsvRKhwKzCayOc7myIQ5Wy+cLfcOMijwWF0Fd5tyu1RbAUSgZ
iwXKyp9qohL4YAslMo1CnHQCJ6wX5jzRm9bii2Lh3HgQ6TbQ2hSsMm1QGjanX+9fwjX4uItaFn6w2OYLxo4V4oISTVCX1gYs+h6H
+zfh0v65bA9eocUrtBFbywfXArq2en9dgVDCvR3UJTzrGvhCx8tbO9ZsWa/qOpM2N2TdY3xy7PsSrvaiydNF0rtxdi297trXFBS8
/H6D36Nt+KXjIzceKHbqlUIQci7aD2eRlm6qfqPUVBFXShX6yEDSxQQJTxKVqf9jiqX4IgSCX0WKXHP2/jVJHBvtDdnqPrH2WylU
mmB9IhPWz5UFWBNGxFSyZavZULHIwBKwMhxWnksVIT/FmBGsqkbRDKcYIjuVqpiRewtjO7ADVWz7Mv7UY2FZkCBRkI9QoSS4sZjh
zklGt8Qb3CFxq5DiCfujYyaMbAt1Bcei31iaHa/uTmnytk6liNle3mLVlFM+HPPEUjoGU64y2oIoPRr2jBkDDSm/QL/T7B5XNgyq
lViRJlTlFowOi/KPzVrLwOcAals6At1Z+wrWCXnWmWYtGjAW3/9rklI2qUzOd57QLbnNho5lk9tyluZWo6YqERVlu2rA+q12EbeH
ayNx+rDTcqPmtJwvUJHSsFLiQYjy0Kr0HowPcuzl/rge9U9uqFWRQOhR6VUG27s8SYi1lZvHyTkIIzucC7kOLO4tBheVZeI2F0pV
4mHdz+Lko10fS2OUBvPgblvTkoeCcJ4xkFflOCucXG2j492W5u8dL6l6L28JisJdvxavcXoW6JiBG8sutyeajME7ZXK3SUWtDO6k
niWjf6ZgAQotr8VrKtlWDsz+tR7QWFmYiQz9ePY1VSldvkryWNeCuXBshL5NKDA0LyuSek4RxvqhW+zkggrNqY+/xSY/pDJOjRBh
TLJJmTOxrG9lTq0aWgiag61NpAptptCJexGUlWpXjZIMpw83ENQxReOW1MdbEh0zx/VNabLOSPVcP1rwssvnLu1nZmTbbDRLhQqp
4FMpuaIfdJvfAL2hiMtPH8o0WYK4zBx49ukDXQnm6nz6eZO0YlTbY0zTk7oKQR9LpNnMHMhkcSX9GWVgobfWjEnbYFdu9S4ZhjE6
apIsNKOy1TSWRWmKsCYFgu4ZGx+qoiCm7lXZvckaZ0AC1irjQJGfysyE0bC0ZScIHaMDt+LIFAyrWmFVfLZoVXxGVkU3Sa8UKC3U
F8ktMQfwACvKVMleTlaLaWPjDarcLofiOhVsKgOiEQ8oaN8YG9EGViUUIlH6li3JO4pztEAn2acP8AAuK1XPSenBaE/T8BIFFmrs
m6RyUJ9/+aXfaT9udtuPUTvAn59/+RWfdOgJ5SZsfPqZpaU27JX51bdlwNwa77VpulAAE1adq6UTkZl1XHatjNHk82zXTaEjg9t3
5pZRDY56chn4//jrhkOWjBW2V6shQuSJs8cqMmWkIOcHaWflLzft736p2gv0Kmmy8V8SI8bicaO+R8lkGCthh67pbQ7dSm4TedS9
FTiqY7SkfMGtChjrWjbjzXUXLehbK5sYncsk7Nci9Hvl1XMgM9W4GVfJAaUA1TTSJ8buUnZDwAGKKyc0SlzbCelD6tij5pVMhs9q
NbrNFRKLmmsO+jK2Ect0l6SfFfdQKtI9Ez61xELQcMSvKh6yHFm1JAQJzjv06sytVqJoVbTVN4uk8BsOhuPopPwsk0qPkylpDpNZ
8YW4K8wRpuzme7szyJPhUcI6WeZMGIBJyigdEubxLCvyWTSWMb5AOwt9hSDM8oIcwRgHWVBdfH5OESdhkiGfSeb0go3JIbINSjpY
1ClLD2mxFEdzXRkPUe3i+Bt31SjF+zQziogJykmzLPlpJoPFcWwBVNduX9rsr+uszbJJ26mxvCw7XFU6lQoR55Fet8Gl9TFzFeLb
EGkf8sxVY2N9PlMTk0MyWH9G2NISY+UKGbLXcjj0rIxlxgljOckXw2reZ9t2ofgaE/OYLfhKnBlcalbHcHJBiUlUJaQq+DHNE6pm
KgqKfeE1cWT8pw+Vp4K5tq7cMHbJLdPDgOfJhQlQq60ctfb7bp2dvU5imZFZNQxCTHRDW04RhgOTK5BoZHIlpXKrlmcm8aFKHnTk
V2MvsKs0npUVtXxaFTiQC2Pg+hIGvft4Bhrbu7t7B0d7zxv/mr3/bnn3dmLU7SwQo26nHt8/SfSCx7lQYnpXGChFNLJzO8yHIebh
Ln4y4iUqR2gQorJKJn4f/Cv29zYS+xqBoh7QH5jivnc0duL7g82yUFHhGuo15v5IFPLQFY41MLTJNnDGUhiupmSM0d7h7tHi1yOe
V6lXXEPUynVlbMumk57VGmJ97R0M0MTPwxAWlIWSKTYSZDzCZKmCVb/NMg0L0clYyvfqVm3TgkWh9+8xGsP/j7/8x9+Cj7/9+P79
NazbF/gQH3yxOoTN6d49qpVx9mlte4TzeDyUG2aqGgg6RvpUAjZKKYFHmwoLaJ1N5iElg1lJKtw9CoecehzaANywyEPezYp6EWUS
MJVntRfK8V4U1UWmRc4HNtWe451V85tkYxvaOTvRRVJgAcd7LON9tk2uO8GZ5qUnjObAdGuygjhOMSRRb8spwDr+SsWkvhj7GmvI
7B7hx4PQlWQs1qicHRpohOGsQJ8s92OVrIJUele5hSo9bJU7/euv4TlnHCk5SjRFaXMNRTIS8cdnFoXzl8/h2na7hrdVc0x0ukv2
dl7pgr70c+U9p9rznItlBuFskbLMMvjR7CSJ3GA/JZ2wPoqzrsxw+5dN5FH0uY3YWoTsty2CzTtqNjfLUs02tRdDoWIUe5biL7zn
T5x1i8KyIVP2wtnHsmWK07SrWs+Um293y2qa+ZoBWRm4ADdVb7io/A6EgzvKV1udgOCeQ3PUBWKHVOtTND3FSbR+aSZdtYnDrrMJ
XOyKOtHClOnxaxWlqywh78a5VL7SxVG5+Pk6H9F6KWooaTL8F+qyL9ZiL/PZWRVZqlrg0ydkkKQGS5v0nm8sLGYpwgErREiKcWL2
jiXkiR24WZNYvSfPhomaIMxg5VgTULNixocLM66UO/kzKS1FddNYeufqJ2XleLOsb1Zt6tHCFPbLBCujYDZBGVe6JjWnwx7hVUt/
zF8veHOw99rURF0qCc/gyG59RiK8FsQc8yUM1z3rpPhi8BEW8agUSmthWVrFk6VVGHxgXDXuvzTdpHoeWLvOpldTs6axZlA5E/o+
1/IUTxdB1FTut3FttmLJQv1+FN+LMpNh8MO7Trj75vXR4fbu0WB5Fkav2kYqyFqBaubolutmOTiGKKMdNHub5sU6VdOoqpM0Ldiv
+AwGvTRfJbHfgyAcY9BcrwCQWhKgvSX5HjAcBNl/h8FtBUGxELS9CDTllwNo0Ce2TVn3PucLZdTgW6SWdE14N+R/Iq0Jksk0TaKE
tsknvKLQ2P6lKSBWnZzJVwdd2O8DIBOqm4FOQ9aMn3fNIfJp8Uk0aXu8AV4cr2C1TeiUK5nTffVPQ44o0oX5s84lXQF8kSETpE1V
zjUCqFQH+JRJbZzbmgui4UfzuADaPceg1CRD3BE0q8IuXIA0cOXMOs/fs1+xuoYDZ1TwKe/LKmtg6pA2YYCiwSC4T5A1zfa8i4LF
MmT3bI2ZViwzXWWIQR5Fs2liTOuL/OPaYhSOekhMZ4nnGB5TL6WzktvUF7oB17ACyxCKHMvCEVWa6XSeNsnUcw27RPC1SRDK1IPu
g43R55//FjRN7g1W0ElIarlogjLJ+kawLjs0IVMPNkYYyMlVKZpg8yX0VEQJBiuVpL8/6o0eZOoYS7ii7p9oDDKIKUPiFjcGfc3o
088LW34I17B957dkHCZWnv03dPbYqPYFEBMdgGjPNgYUlbKR3CwHWVDoKwpdX9UjhBimU4OSUJnItWoVT2kVyCWZSdow0XqMWD06
DIVGjmR0L9UGatZX8RjPZsVHVLo1ZmnKQtwzyKm++ueSslkpOlzSR/iYReupjFBBh0JJUXChNMTwC4l5/dhHxsEmf83pgqdGnu2G
juiFzTwxm6lJrTVK7Yiq/io5F7k+xZwFC5swocnozFRymHKFrh76cjM6oR0U4mOW+HbUOjpWaMmffgY9ToboDAYE0J//UlEb9EKU
SGtWVd8QTs0Zki470SVHqRaJ0PTcAGDP6ptbUH5jSJhv9PBoOeXV8Ud6wH8bJUgbfxCZGCHpTVHGvzC+W10ngnDYrSZd4F824JBA
tqwxYuy8ph4On8qXqgM6339xBNmg+o6KrQr6Ij+jjxFhHM92t9OBdXj1yOEDB7NiuWjmYNVHcsuXNcXd57qqzbJUmOEQQZntIFQ0
piostk6rroYI5zwqsz/u477cKF92A5ulN8xTm0yBuxqYDw1DfZ0oaxcweLd7FO6+O3wVHmwfvRjgSUwTksspqNlWAq6iRT1K46Vy
4DiBIG0hKbBODfLBAaoJg7K+Ma2Byp3wZ7lQuuQSZLnN8RUpHIqz743UbhGmoUs1RMRxglBLFVJpJC5E8k9WdOGjW6rqMlhR1qXa
rG+L9SXDlX2NFxEJo0ACEbB9VmbzROUZUSQuh+bjbpALN+ns6l88adrCDGOhxwEjgZXEy/RILna2//bNa+tkodpRW5SAxq6fV/br
h/QaP1Xl23Lq9L76InOAjgsvaJMLwceBeEiOvaWRv/oqGUJIn/8NQ/q2RBhiKbow9Fj2o6DhLbAzxImieu32tzjR+H8/pKLtYRiQ
HdezP8mOz4FW2jdlbHP6+GR0Fvu8GvyQMc9gDtQUrqSvP4f46aL6Z455CxiH7S2XgKNabyQ18rBbTk+efriiV3iFrW+4M42Pn1HG
X+00F7F/2yGrzEYBmVta/XXs1R/GvnuRS13sGvGT2jyluqjEc+L5L82nhc3Xu/HzFwmThZXt2nGip6m4sO3Nzyb8YD7O7SoYzmB+
YDHidZ7Jnu3n224MaZUaQFH4QDm2DhDiNzOmBezR/5BHlu0XW/Jvz3wy3SJNkXtNWHEnt3yFPPjq/wCxRY5y
"""

if __name__ == "__main__":
    main()
