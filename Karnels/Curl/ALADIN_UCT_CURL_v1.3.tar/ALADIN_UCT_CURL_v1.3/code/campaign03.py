#!/usr/bin/env python3
"""
ALADIN v4.0 - Campaign 03: Discrete operator identities, conservation compatibility & algebraic consistency   (tests 021-030)
Target : uct_curl.py v1.3 (executed UNMODIFIED; its SHA-256 is checked against KNOWN_SHA below)
         J = curl(B), mu0 = 1, cell-centred current reconstruction.  This is NOT the Faraday constrained-transport update.

Needs campaign01.py and campaign02.py (shared grid/backend/reference helpers) in the same folder. Run:  python campaign03.py
Deliverables written next to this file: campaign03_results.json, CAMPAIGN03_REPORT.md, campaign03_plots/*.png, campaign03_execution.log

SCIENTIFIC STANCE (stated before any result was seen)
  The kernel is NOT an exact discrete de Rham complex.  Its stencils are (annulus mode):
      Jr  = (1/rc) D_phi[Bz_c] - D_z[Bphi_c]                      wide (2h) centred differences of cell-centred face averages
      Jphi= D_z[Br_c]          - D_r[Bz_c]                        wide centred
      Jz  = (1/rc) { [rf_{i+1} Bphi_f(i+1) - rf_i Bphi_f(i)]/dr  - D_phi[Br_c] }     COMPACT face-weighted radial difference
  Jz therefore differs from the wide "ideal" stencil by the closed-form term  -(1/(4 rc)) delta_r^2 Bphi_c  (derived by hand,
  see report section 3).  Consequences, which the tests ESTABLISH BEFORE demanding any identity:
      * no 3-point radial divergence exists with div(curl B) = 0 exactly (021);  the exact statement is div_w(C B) = D_z[-(1/4rc) d_r^2 Bphi_c];
      * curl of the compatible discrete gradient is NOT zero in Jz; it equals the same closed-form term exactly (028);
      * a discrete Stokes theorem holds EXACTLY in terms of interface-averaged cell-centred circulation (022);
      * the integration-by-parts relation holds exactly only with an explicit O(dr^2) mismatch term (027).
  Exact algebraic identities are tested to round-off; approximate consistency is tested by measured convergence. They are never mixed.
  In axis mode (cubic Cartesian reconstruction of Jz, one-sided stencils on ring 0) NO exact identity is claimed: only convergence.

All tolerances are DECLARED BEFORE EXECUTION (TOL3). They are not changed after seeing results; any change would be documented with a fresh run.
"""
import os, sys, json, math, hashlib, re, subprocess, datetime, platform, traceback, importlib.util, random, io
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
sys.path.insert(0, HERE)
import campaign01 as C
import campaign02 as H

K = C.K
F64, F32 = np.float64, np.float32
EPS = C.EPS
KNOWN_SHA = {"1.3": "e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e"}
EXPECTED_SHA = KNOWN_SHA.get(getattr(C.K, "VERSION", ""), "")
OUT = os.environ.get("CAMPAIGN_OUT", HERE)

# ----------------------------------------------------------------------------
# DECLARED CRITERIA (fixed before any Campaign 03 result was looked at)
# ----------------------------------------------------------------------------
TOL3 = dict(
    alg_factor=128.0,        # EXACT algebraic identity: |lhs-rhs| <= alg_factor * eps(dtype) * gross_scale (scale stated per test; ~30-60 flops are involved)
    order_min=C.TOL["order_min"],   # 1.8: last-pair observed order for every "second-order" claim (4 refinement levels)
    ref_check=1e-9,          # analytic reference self-consistency (circulation vs surface integral, flux vs volume integral)
    lin_factor=128.0,        # superposition: |C(aB1+bB2) - aC(B1) - bC(B2)| <= lin_factor*eps*(|a|B1max+|b|B2max)/hmin
    exact_fp64=C.TOL["exact_fp64"],
    rot_axis_rel=1e-12,      # axis grids: rotation / mirror covariance FP64, relative to max|J| (annulus must be BITWISE identical)
    cond_trunc=20.0,         # truncation allowance 20*(dr^2+dz^2+(rc dphi)^2)*Bscale for the cancellation sweep and the net-flux bound
    fp_factor=64.0,          # round-off allowance 64*eps*Bscale/hmin in the cancellation sweep
    sensitivity_min=10.0,    # a "nonzero-residual" claim must have signal >= sensitivity_min * tolerance, otherwise the check is labelled non-discriminating
    axis_div_order_min=0.8,  # axis mode, ALL cells: div(curl) must converge at >= first order (ring-0 stencil error O(h^2) is divided by h) ...
    region_annulus=(0.6, 1.4),   # ... while in a FIXED PHYSICAL interior region (away from the annulus edges) every order claim is second order
    region_axis=(0.25, 0.9),     # axis grids: second order for 0.25 <= r <= 0.9 (the first-order effect is confined to the first ring beyond ring 0, O(h^2/r_c))
    conv_base=(12, 24, 8),       # base grid of every 4-level refinement (12*2^l, 24*2^l, 8*2^l); 24 azimuthal cells resolve the m=3 content of M2
    incompatible_order_max=1.5,   # an INCOMPATIBLE staggering must NOT show second-order convergence (test sensitivity)
)

def dn(d): return np.dtype(d).name
nmax = H.nmax
orders_of = H.orders_of
comp_rule = H.comp_rule

# ----------------------------------------------------------------------------
# generic helpers (independent of the kernel's flat-index arithmetic)
# ----------------------------------------------------------------------------
def per_fill(B, G):
    """Re-impose phi periodicity: every phi entry (centre or face) is copied from its periodic image among the nphi core entries."""
    g, n = G.g, G.nphi; out = []
    for A in B:
        idx = np.array([g + ((j - g) % n) for j in range(A.shape[1])])
        out.append(np.ascontiguousarray(A[:, idx, :]))
    return out

def cc(B):
    """cell-centred face averages (the same averages the kernel uses), FP64, full ghosted extent"""
    Br, Bp, Bz = [np.asarray(b, dtype=F64) for b in B]
    return [0.5*(Br[:-1] + Br[1:]), 0.5*(Bp[:, :-1] + Bp[:, 1:]), 0.5*(Bz[:, :, :-1] + Bz[:, :, 1:])]

def Iv(X, G):                     # interior view of a cell-centred full array
    g = G.g; return X[g:g + G.nr, g:g + G.nphi, g:g + G.nz]

def Ji(J, G):                     # interior kernel output as FP64
    return [np.asarray(j[G.sl], dtype=F64) for j in J]

def hmin_of(G): return min(G.dr, G.dz, G.rc[G.g]*G.dphi)
def bmax_of(B): return max(float(np.max(np.abs(b))) for b in B)
def tol_alg(dtype, scale): return TOL3["alg_factor"]*EPS[dtype]*scale

def rand_periodic(G, dtype, rng):
    return per_fill(H.random_B(G, dtype, rng), G)

def rotate_B(B, G, s):
    """rotate the field by s whole azimuthal cells (core entries rolled, ghosts re-imposed periodically)."""
    g, n = G.g, G.nphi; out = []
    for A in B:
        core = np.roll(A[:, g:g + n, :], s, axis=1)
        idx = np.array([((j - g) % n) for j in range(A.shape[1])])
        out.append(np.ascontiguousarray(core[:, idx, :]))
    return out

def mirror_B(B, G):
    """reflect phi -> -phi:  Br'(phi)=Br(-phi), Bphi'(phi)=-Bphi(-phi), Bz'(phi)=Bz(-phi);  centres j -> n-1-j, faces f -> n-f"""
    g, n = G.g, G.nphi; Br, Bp, Bz = B
    def cen(A):
        core = A[:, g:g + n, :][:, ::-1, :]; idx = np.array([((j - g) % n) for j in range(A.shape[1])]); return np.ascontiguousarray(core[:, idx, :])
    core = Bp[:, g:g + n, :]; face = np.concatenate([core[:, :1, :], core[:, 1:, :][:, ::-1, :]], axis=1)      # face f' = (n-f) mod n
    idx = np.array([((j - g) % n) for j in range(Bp.shape[1])])
    return [cen(Br), np.ascontiguousarray(-face[:, idx, :]), cen(Bz)]

def mirror_J(J, G):
    """expected current of the mirrored field: J'_r(phi)=-J_r(-phi), J'_phi(phi)=+J_phi(-phi), J'_z(phi)=-J_z(-phi)  (curl is an axial vector); interior cells, phi reversed"""
    Jr, Jp, Jz = Ji(J, G)
    return [-Jr[:, ::-1, :], Jp[:, ::-1, :], -Jz[:, ::-1, :]]

def conv_rows(levels_fn, errfn):
    """errfn(G) -> list of abs errors (one per tracked quantity); returns rows with h and orders."""
    rows = []
    for G in levels_fn: rows.append(dict(h=max(G.dr, G.dz), errs=errfn(G), grid=[G.nr, G.nphi, G.nz]))
    return rows

def ann_levels(base=None, L=4):
    base = base or TOL3["conv_base"]
    return [C.Grid(*n, r0=0.5, r1=1.5) for n in H.levels(base, L)]
def axis_levels(base=None, L=4):
    base = base or TOL3["conv_base"]
    return [C.Grid(*n, r0=0.0, r1=1.0) for n in H.levels(base, L)]

def reg_max(d, G, i0, mode):
    """max |d| over cells whose centre radius lies in the declared fixed physical region (d is indexed from interior cell ring i0)"""
    lo, hi = TOL3["region_annulus"] if mode == "annulus" else TOL3["region_axis"]
    rcs = G.rc[G.g + i0:G.g + i0 + d.shape[0]]; m = (rcs >= lo) & (rcs <= hi)
    return nmax(d[m]) if m.any() else 0.0

def order_pass(errs_by_level, floors=None, order_min=None):
    """errs_by_level: list over levels. Pass if the last-pair order >= order_min (default 1.8) or the error is at/below the declared round-off floor at EVERY level.
    floors: per-level round-off floors (e.g. alg_factor*eps*Bmax/hmin^2 for a divergence, which differentiates J once more); default 1e-12."""
    o = orders_of(errs_by_level); last = o[-1]; om = TOL3["order_min"] if order_min is None else order_min
    if floors is None: floors = [TOL3["exact_fp64"]]*len(errs_by_level)
    at_floor = all(e <= f for e, f in zip(errs_by_level, floors))
    return bool(last >= om or at_floor), o

def gl(a, b, n=20):
    x, w = np.polynomial.legendre.leggauss(n); return 0.5*(b - a)*x + 0.5*(b + a), 0.5*(b - a)*w

def ring(fn, *args):               # evaluate analytic callable on equally shaped 1-D arrays
    return fn(*args)

# ============================================================================
# TEST 021  Discrete divergence of curl
# ============================================================================
def div_wide(J, G):
    """independent compatible-candidate divergence of the cell-centred current: (1/rc)D_r(rc Jr) + (1/rc)D_phi Jphi + D_z Jz, wide (2h) centred,
    r-weights at cell centres, phi periodic.  Defined on cells i=1..nr-2, k=1..nz-2 (all phi)."""
    g = G.g; Jr, Jp, Jz = Ji(J, G); rc = G.rc[g:g + G.nr][:, None, None]; X = rc*Jr
    t_r = (X[2:] - X[:-2])/(2*G.dr)/rc[1:-1]
    t_p = (np.roll(Jp, -1, 1) - np.roll(Jp, 1, 1))[1:-1]/(2*G.dphi)/rc[1:-1]
    t_z = (Jz[:, :, 2:] - Jz[:, :, :-2])[1:-1]/(2*G.dz)
    return t_r[:, :, 1:-1] + t_p[:, :, 1:-1] + t_z

def jz_residual_term(B, G):
    """closed-form difference between the kernel's compact Jz and the wide ideal Jz:  -(1/(4 rc)) delta_r^2 Bphi_c   (all k incl. ghosts)"""
    g = G.g; Bpc = cc(B)[1]
    d2 = Bpc[g + 1:g + G.nr + 1, g:g + G.nphi, :] - 2*Bpc[g:g + G.nr, g:g + G.nphi, :] + Bpc[g - 1:g + G.nr - 1, g:g + G.nphi, :]
    return -d2/(4*G.rc[g:g + G.nr][:, None, None])

def div_predicted(B, G):
    """exact prediction  div_w(C B) = D_z[ -(1/(4 rc)) delta_r^2 Bphi_c ]  on the same cells as div_wide"""
    g = G.g; Q = jz_residual_term(B, G)
    return ((Q[:, :, g + 2:g + G.nz] - Q[:, :, g:g + G.nz - 2])/(2*G.dz))[1:-1]

def compat_analysis(G):
    """Why no exact compatible divergence exists in the family  A_r[Jr] + (1/rc)D_phi Jphi + D_z Jz.
    Bz-terms force A_r[x]_i = (rc_{i+1}x_{i+1} - rc_{i-1}x_{i-1})/(2 dr rc_i);  Bphi-terms force
    A_r[y]_i = (rf_{i+1}(y_i+y_{i+1}) - rf_i(y_{i-1}+y_i))/(2 dr rc_i).  Compare the two coefficient triples (i-1, i, i+1)."""
    g = G.g; rc, rf, dr = G.rc, G.rf, G.dr; rows = []
    for i in range(g + 1, g + G.nr - 1):
        a = np.array([-rc[i - 1], 0.0, rc[i + 1]])/(2*dr*rc[i])
        b = np.array([-rf[i], rf[i + 1] - rf[i], rf[i + 1]])/(2*dr*rc[i])
        rows.append(float(np.max(np.abs(a - b))*dr))
    return dict(min_dr_times_coeff_gap=min(rows), max_dr_times_coeff_gap=max(rows), n_rings=len(rows),
                expected="(dr/2)/(2 dr rc) * dr -> dr/(4 rc)")

def t021(be):
    res = dict(); fails = []; raw = H.backend_for(be); host = be
    res["compatibility_analysis"] = compat_analysis(C.Grid(16, 16, 8, r0=0.5, r1=1.5))
    if res["compatibility_analysis"]["min_dr_times_coeff_gap"] < 1e-3: fails.append("compatibility analysis: the two coefficient families coincide (expected a gap)")
    # (a) exact identity  div_w(C B) = predicted closed form, random periodic fields, annulus, FP64 and FP32, several grids
    rng = np.random.default_rng(21); rows = []
    for dt in (F64, F32):
        for n in [(9, 12, 7), (16, 16, 8), (6, 5, 4), (13, 7, 11)]:
            G = C.Grid(*n, r0=0.5, r1=1.5); B = rand_periodic(G, dt, rng)
            J = G.run(raw, B, dt); d = div_wide(J, G); p = div_predicted(B, G)
            scale = bmax_of(B)/hmin_of(G)**2; tol = tol_alg(dt, scale); err = nmax(d - p)
            r = dict(dtype=dn(dt), grid=list(n), max_abs_div=nmax(d), max_abs_prediction=nmax(p), err_vs_prediction=err, tol=tol, sensitivity=nmax(p)/tol, ok=bool(err <= tol))
            # contrast: how large is the divergence if the closed-form term were ignored (i.e. div would be 'zero' for an exact complex)
            r["fraction_of_div_explained"] = 1.0 - err/max(nmax(d), 1e-300)
            if not r["ok"]: fails.append(f"exact div identity {dn(dt)} {n}: err {err:.3e} > tol {tol:.3e}")
            if r["sensitivity"] < TOL3["sensitivity_min"]: r["non_discriminating"] = True; fails.append(f"exact div identity {dn(dt)} {n}: signal/tol = {r['sensitivity']:.2f} < {TOL3['sensitivity_min']}")
            rows.append(r)
    res["exact_identity_rows"] = rows
    # (b) sub-cases where the staggering DOES give an exact zero:  Bphi == 0   and   Bphi_c linear in the radial index (delta_r^2 Bphi_c == 0)
    sub = []
    for dt in (F64, F32):
        G = C.Grid(10, 12, 8, r0=0.5, r1=1.5); B = rand_periodic(G, dt, rng); g = G.g
        B0 = [B[0], np.zeros_like(B[1]), B[2]]
        J = G.run(raw, B0, dt); d = div_wide(J, G); tol = tol_alg(dt, bmax_of(B0)/hmin_of(G)**2)
        sub.append(dict(case="Bphi = 0", dtype=dn(dt), max_abs_div=nmax(d), tol=tol, ok=bool(nmax(d) <= tol)))
        ir = np.arange(B[1].shape[0], dtype=np.float64)[:, None, None]
        Bl = [B[0], ((0.3 + 0.2*ir)*np.ones(B[1].shape)).astype(dt), B[2]]      # Bphi linear in the radial index, phi/z-uniform
        J = G.run(raw, Bl, dt); d = div_wide(J, G); tol = tol_alg(dt, bmax_of(Bl)/hmin_of(G)**2)
        sub.append(dict(case="Bphi_c linear in radial index (phi,z-uniform)", dtype=dn(dt), max_abs_div=nmax(d), tol=tol, ok=bool(nmax(d) <= tol)))
    for s_ in sub:
        if not s_["ok"]: fails.append(f"exact-zero sub-case '{s_['case']}' {s_['dtype']}: max|div| {s_['max_abs_div']:.3e} > tol {s_['tol']:.3e}")
    res["exact_zero_subcases"] = sub
    # (c) approximate consistency: div -> 0 at second order for smooth analytic fields (annulus and axis); axis: exact formula NOT claimed
    conv = []
    sets = [("annulus", ann_levels, [H.M1, H.M2, H.M3, C.ADV, H.FIELD["SMOOTH"]]),
            ("axis", axis_levels, [H.FIELD["QUAD"], H.FIELD["SMOOTH"], H.FIELD["KINK-poly"], H.FIELD["HELICAL KINK (m=1)"]])]
    for mode, lv, fields in sets:
        for fld in fields:
            rows_ = []; devs = []; far = []; floors = []; where = []
            for G in lv():
                B = G.sample(fld, F64); J = G.run(raw, B, F64); d = div_wide(J, G)
                rows_.append(nmax(d)); devs.append(nmax(d - div_predicted(B, G))); floors.append(tol_alg(F64, bmax_of(B)/hmin_of(G)**2))
                far.append(reg_max(d, G, 1, mode)); where.append(int(np.unravel_index(np.argmax(np.abs(d)), d.shape)[0]) + 1)
            o = orders_of(rows_); ok_far, o_far = order_pass(far, floors)
            ok = True if mode == "annulus" else order_pass(rows_, floors, order_min=TOL3["axis_div_order_min"])[0]
            conv.append(dict(mode=mode, field=fld.name, max_abs_div_all_cells=rows_, orders_all_cells=o, ok=bool(ok and ok_far), max_abs_div_region=far, orders_region=o_far, cell_ring_of_max=where,
                             deviation_from_annulus_formula=devs, roundoff_floor=floors,
                             exact_formula_holds_to_roundoff=bool(all(dv <= 4*fl for dv, fl in zip(devs, floors)))))
            if not ok: fails.append(f"div(curl) convergence (all cells, first-order requirement) {mode} {fld.name}: orders {['%.2f' % x for x in o]}")
            if not ok_far: fails.append(f"div(curl) convergence in the declared interior region {mode} {fld.name}: orders {['%.2f' % x for x in o_far]}")
    res["convergence"] = conv
    # axis-mode deviation from the annulus formula (documented: no exact identity claimed there)
    G = C.Grid(16, 16, 8, r0=0.0, r1=1.0); B = rand_periodic(G, F64, rng); J = G.run(raw, B, F64)
    res["axis_mode_random_field"] = dict(max_abs_div=nmax(div_wide(J, G)), max_dev_from_annulus_formula=nmax(div_wide(J, G) - div_predicted(B, G)),
                                         note="axis mode uses a cubic Cartesian Jz: the annulus closed form is NOT valid there, no exactness is claimed")
    res["statement"] = ("No exact discrete div(curl)=0 exists for this staggering; the exact statement is div_w(C B) = D_z[-(1/4rc) delta_r^2 Bphi_c] (verified to round-off), "
                        "which is O(dr^2) and vanishes for Bphi=0 or Bphi_c linear in the radial index.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 022  Cylindrical Stokes theorem
# ============================================================================
def itf(X, ax, lo, hi, G, sl_other):
    """interface-averaged values at the lower interface (between cell lo-1 and lo) and upper interface (between cell hi and hi+1) along axis ax (interior indices)"""
    g = G.g
    def at(m):
        idx = list(sl_other); idx[ax] = g + m; return X[tuple(idx)]
    return 0.5*(at(hi) + at(hi + 1)), 0.5*(at(lo - 1) + at(lo))

def stokes_exact(B, J, G, blocks):
    """EXACT discrete Stokes: sum of kernel curl x cell area over a block == circulation of interface-averaged cell-centred field around the block boundary."""
    g = G.g; Brc, Bpc, Bzc = cc(B); Jr, Jp, Jz = Ji(J, G); out = []
    S = slice(None)
    for (o, (ia, ib), (ja, jb), (ka, kb), fix) in blocks:
        if o == "r":                     # surface at ring ir=fix, block j in [ja,jb], k in [ka,kb]
            ir = fix; rc = G.rc[g + ir]
            lhs = rc*G.dphi*G.dz*float(np.sum(Jr[ir, ja:jb + 1, ka:kb + 1]))
            kk = np.arange(ka, kb + 1) + g; jj = np.arange(ja, jb + 1) + g
            hi, lo = 0.5*(Bzc[g + ir, jb + 1 + g, kk] + Bzc[g + ir, jb + g, kk]), 0.5*(Bzc[g + ir, ja + g, kk] + Bzc[g + ir, ja - 1 + g, kk])
            t1 = G.dz*float(np.sum(hi - lo))
            hi2, lo2 = 0.5*(Bpc[g + ir, jj, kb + 1 + g] + Bpc[g + ir, jj, kb + g]), 0.5*(Bpc[g + ir, jj, ka + g] + Bpc[g + ir, jj, ka - 1 + g])
            t2 = rc*G.dphi*float(np.sum(hi2 - lo2)); rhs = t1 - t2
            area = rc*G.dphi*G.dz*(jb - ja + 1)*(kb - ka + 1); gross = abs(t1) + abs(t2)
        elif o == "phi":                 # surface at phi cell jp=fix, i in [ia,ib], k in [ka,kb]
            jp = fix
            lhs = G.dr*G.dz*float(np.sum(Jp[ia:ib + 1, jp, ka:kb + 1]))
            ii = np.arange(ia, ib + 1) + g; kk = np.arange(ka, kb + 1) + g
            hi, lo = 0.5*(Brc[ii, jp + g, kb + 1 + g] + Brc[ii, jp + g, kb + g]), 0.5*(Brc[ii, jp + g, ka + g] + Brc[ii, jp + g, ka - 1 + g])
            t1 = G.dr*float(np.sum(hi - lo))
            hi2, lo2 = 0.5*(Bzc[ib + 1 + g, jp + g, kk] + Bzc[ib + g, jp + g, kk]), 0.5*(Bzc[ia + g, jp + g, kk] + Bzc[ia - 1 + g, jp + g, kk])
            t2 = G.dz*float(np.sum(hi2 - lo2)); rhs = t1 - t2
            area = G.dr*G.dz*(ib - ia + 1)*(kb - ka + 1); gross = abs(t1) + abs(t2)
        else:                            # "z": surface at z cell kz=fix, i in [ia,ib], j in [ja,jb]
            kz = fix; ii = np.arange(ia, ib + 1)
            lhs = G.dr*G.dphi*float(np.sum(G.rc[g + ii][:, None]*Jz[ia:ib + 1, ja:jb + 1, kz]))
            jj = np.arange(ja, jb + 1) + g
            bpf = lambda a: 0.5*(Bpc[g + a - 1, jj, kz + g] + Bpc[g + a, jj, kz + g])
            t1 = G.dphi*float(np.sum(G.rf[g + ib + 1]*bpf(ib + 1) - G.rf[g + ia]*bpf(ia)))
            hi, lo = 0.5*(Brc[ii + g, jb + 1 + g, kz + g] + Brc[ii + g, jb + g, kz + g]), 0.5*(Brc[ii + g, ja + g, kz + g] + Brc[ii + g, ja - 1 + g, kz + g])
            t2 = G.dr*float(np.sum(hi - lo)); rhs = t1 - t2
            area = float(np.sum(G.rc[g + ii]))*G.dr*G.dphi*(jb - ja + 1); gross = abs(t1) + abs(t2)
        out.append(dict(orient=o, block=[ia, ib, ja, jb, ka, kb, fix], lhs=lhs, rhs=rhs, diff=abs(lhs - rhs), area=area, gross=gross))
    return out

def analytic_circulation(fld, G, blk):
    """circulation of the ANALYTIC field around the physical boundary of a cell block (Gauss-Legendre line integrals; phi,z,r edges at cell interfaces)
    and, as an independent cross-check, the 2-D Gauss-Legendre surface integral of the analytic curl."""
    g = G.g; o, (ia, ib), (ja, jb), (ka, kb), fix = blk
    r1, r2 = G.rf[g + ia], G.rf[g + ib + 1]; p1, p2 = ja*G.dphi, (jb + 1)*G.dphi; z1, z2 = G.z0 + ka*G.dz, G.z0 + (kb + 1)*G.dz
    full = lambda x, n: np.full(n, x)
    def line(fn, axis_vals, const_a, const_b, which):      # integral of fn along one coordinate with the other two fixed
        t, w = gl(*axis_vals)
        if which == "phi": return float(np.sum(w*fn(full(const_a, t.size), t, full(const_b, t.size))))
        if which == "z":   return float(np.sum(w*fn(full(const_a[0], t.size), full(const_a[1], t.size), t)))
        return float(np.sum(w*fn(t, full(const_a, t.size), full(const_b, t.size))))      # radial
    if o == "r":
        r = G.rc[g + fix]; pc = ((ja + jb + 1)/2.0)
        Ph = lambda rr, pp, zz: rr*fld.Bp(rr, pp, zz)
        C_ = line(Ph, (p1, p2), r, z1, "phi") - line(Ph, (p1, p2), r, z2, "phi") + line(fld.Bz, (z1, z2), (r, p2), None, "z") - line(fld.Bz, (z1, z2), (r, p1), None, "z")
        t1, w1 = gl(p1, p2); t2, w2 = gl(z1, z2); P, Z = np.meshgrid(t1, t2, indexing="ij"); W = np.outer(w1, w2)
        S_ = float(np.sum(W*fld.Jr(np.full_like(P, r), P, Z)*r))
    elif o == "phi":
        pp = (fix + 0.5)*G.dphi
        C_ = line(fld.Br, (r1, r2), pp, z2, "r") - line(fld.Br, (r1, r2), pp, z1, "r") - line(fld.Bz, (z1, z2), (r2, pp), None, "z") + line(fld.Bz, (z1, z2), (r1, pp), None, "z")
        t1, w1 = gl(r1, r2); t2, w2 = gl(z1, z2); Rm, Z = np.meshgrid(t1, t2, indexing="ij"); W = np.outer(w1, w2)
        S_ = float(np.sum(W*fld.Jp(Rm, np.full_like(Rm, pp), Z)))
    else:
        zc = G.z0 + (fix + 0.5)*G.dz
        Ph = lambda rr, pp, zz: rr*fld.Bp(rr, pp, zz)
        C_ = line(Ph, (p1, p2), r2, zc, "phi") - line(Ph, (p1, p2), r1, zc, "phi") - (line(fld.Br, (r1, r2), p2, zc, "r") - line(fld.Br, (r1, r2), p1, zc, "r"))
        t1, w1 = gl(r1, r2); t2, w2 = gl(p1, p2); Rm, P = np.meshgrid(t1, t2, indexing="ij"); W = np.outer(w1, w2)
        S_ = float(np.sum(W*fld.Jz(Rm, P, np.full_like(Rm, zc))*Rm))
    gross = abs(C_)
    return C_, S_

def midpoint_surface_sum(J, G, blk):
    g = G.g; Jr, Jp, Jz = Ji(J, G); o, (ia, ib), (ja, jb), (ka, kb), fix = blk
    if o == "r":   return G.rc[g + fix]*G.dphi*G.dz*float(np.sum(Jr[fix, ja:jb + 1, ka:kb + 1]))
    if o == "phi": return G.dr*G.dz*float(np.sum(Jp[ia:ib + 1, fix, ka:kb + 1]))
    ii = np.arange(ia, ib + 1); return G.dr*G.dphi*float(np.sum(G.rc[g + ii][:, None]*Jz[ia:ib + 1, ja:jb + 1, fix]))

def stokes_blocks(G):
    nr, nphi, nz = G.nr, G.nphi, G.nz; blocks = []
    ia, ib = max(1, nr//4), max(1, nr//4) + max(1, nr//2) - 1; ib = min(ib, nr - 2); ia = min(ia, ib)
    ja, jb = 1, max(1, nphi//2); jb = min(jb, nphi - 2); ja = min(ja, jb)
    ka, kb = max(1, nz//6), max(1, nz - nz//6 - 1); kb = min(kb, nz - 2); ka = min(ka, kb)
    blocks.append(("r", (ia, ib), (ja, jb), (ka, kb), (ia + ib)//2)); blocks.append(("phi", (ia, ib), (ja, jb), (ka, kb), (ja + jb)//2)); blocks.append(("z", (ia, ib), (ja, jb), (ka, kb), (ka + kb)//2))
    blocks.append(("r", (1, 1), (1, 1), (1, 1), 1)); blocks.append(("phi", (1, 1), (1, 1), (1, 1), 1)); blocks.append(("z", (1, 1), (1, 1), (1, 1), 1))     # single-cell surfaces
    return blocks

def t022(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(22)
    # (a) EXACT discrete Stokes, annulus, random periodic fields
    rows = []
    for dt in (F64, F32):
        for n in [(9, 12, 7), (16, 16, 8), (7, 6, 5)]:
            G = C.Grid(*n, r0=0.5, r1=1.5); B = rand_periodic(G, dt, rng); J = G.run(raw, B, dt)
            for r_ in stokes_exact(B, J, G, stokes_blocks(G)):
                tol = tol_alg(dt, bmax_of(B)*r_["area"]/hmin_of(G)); r_.update(dtype=dn(dt), grid=list(n), tol=tol, ok=bool(r_["diff"] <= tol), sensitivity=r_["gross"]/tol)
                if not r_["ok"]: fails.append(f"exact Stokes {r_['orient']} {dn(dt)} {n} block {r_['block']}: diff {r_['diff']:.3e} > tol {tol:.3e}")
                rows.append(r_)
    res["exact_rows"] = [dict(orient=r["orient"], dtype=r["dtype"], grid=r["grid"], block=r["block"], lhs=r["lhs"], rhs=r["rhs"], diff=r["diff"], tol=r["tol"], ok=r["ok"]) for r in rows]
    res["exact_summary"] = dict(n=len(rows), worst_diff_over_tol=max(r["diff"]/r["tol"] for r in rows), min_gross_over_tol=min(r["gross"]/r["tol"] for r in rows))
    if res["exact_summary"]["min_gross_over_tol"] < TOL3["sensitivity_min"]: fails.append("exact Stokes: a block has circulation below sensitivity_min*tol (non-discriminating)")
    # (b) approximate: kernel surface sum vs analytic circulation (quadrature) with measured convergence; annulus and axis, three orientations
    conv = []; refchk = []
    cases = [("annulus", ann_levels, [H.M1, H.M2, H.M3, C.ADV, H.FIELD["SMOOTH"]]), ("axis", axis_levels, [H.FIELD["QUAD"], H.FIELD["SMOOTH"], H.FIELD["KINK-poly"], H.FIELD["HELICAL KINK (m=1)"]])]
    for mode, lv, fields in cases:
        for fld in fields:
            per_orient = {}
            for G in lv():
                B = G.sample(fld, F64); J = G.run(raw, B, F64); n_ = G.nr
                ia = 0 if mode == "axis" else n_//4; ib = n_//4 + n_//2 - 1
                ja, jb = 0, G.nphi//2 - 1; ka, kb = G.nz//6, G.nz - G.nz//6 - 1
                bl = {"r": ("r", (ia, ib), (ja, jb), (ka, kb), (ia + ib)//2 if mode == "annulus" else 0), "phi": ("phi", (ia, ib), (ja, jb), (ka, kb), (G.nphi//4)),
                      "z": ("z", (ia, ib), (0, G.nphi - 1) if mode == "axis" else (ja, jb), (ka, kb), (ka + kb)//2)}
                for o_, blk in bl.items():
                    Cc, Sc = analytic_circulation(fld, G, blk); k = midpoint_surface_sum(J, G, blk)
                    refchk.append(abs(Cc - Sc)/max(abs(Cc), 1.0))
                    per_orient.setdefault(o_, []).append(dict(h=max(G.dr, G.dz), grid=[G.nr, G.nphi, G.nz], kernel=k, analytic=Cc, err=abs(k - Cc)))
            for o_, rws in per_orient.items():
                errs = [r["err"] for r in rws]; scl = max(max(abs(r["analytic"]) for r in rws), 1.0)
                ok = bool(comp_rule(errs, [scl], orders_of(errs)[-1])); ords = orders_of(errs)
                conv.append(dict(mode=mode, field=fld.name, orient=o_, rows=rws, orders=ords, ok=ok, circulation_scale=max(abs(r["analytic"]) for r in rws)))
                if not ok: fails.append(f"Stokes convergence {mode} {fld.name} {o_}: orders {['%.2f' % x for x in ords]}")
    res["convergence"] = conv; res["analytic_reference_check_max_rel"] = max(refchk)
    if max(refchk) > TOL3["ref_check"]: fails.append(f"analytic circulation vs 2-D quadrature of the analytic curl disagree: {max(refchk):.3e}")
    # (c) axis disc: full-circle z-circulation around r=R equals the integral of Jz over the disc (includes the axis cell ring)
    disc = []
    for fld in (H.FIELD["QUAD"], H.FIELD["KINK-poly"], H.FIELD["HELICAL KINK (m=1)"]):
        errs = []
        for G in axis_levels():
            B = G.sample(fld, F64); J = G.run(raw, B, F64); kz = G.nz//2; blk = ("z", (0, G.nr - 1), (0, G.nphi - 1), (kz, kz), kz)
            Cc, Sc = analytic_circulation(fld, G, blk); errs.append(abs(midpoint_surface_sum(J, G, blk) - Cc))
        ok = bool(comp_rule(errs, [1.0], orders_of(errs)[-1])); disc.append(dict(field=fld.name, errs=errs, orders=orders_of(errs), ok=ok))
        if not ok: fails.append(f"axis disc circulation {fld.name}: orders {['%.2f' % x for x in orders_of(errs)]}")
    res["axis_disc"] = disc
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 023  Current conservation (finite-volume divergence vs boundary flux)
# ============================================================================
def fv_box(J, G, axis_mode):
    """finite-volume divergence of the cell-centred J (face values = 2-point averages) on the box i in [ia,ib], k in [1,nz-2], phi periodic, and its boundary flux."""
    g = G.g; Jr, Jp, Jz = Ji(J, G); nr, nphi, nz = G.nr, G.nphi, G.nz
    ia = 0 if axis_mode else 1; ib = nr - 2
    rf = G.rf[g:g + nr + 1]; rc = G.rc[g:g + nr]
    Jrf = np.zeros((nr + 1, nphi, nz)); Jrf[1:nr] = 0.5*(Jr[:-1] + Jr[1:])               # Jrf[0] (axis / outside) not defined: flux through the axis is 0 by r=0
    flux_r = rf[:, None, None]*Jrf                                                       # r*J at radial faces
    Jzf = np.zeros((nr, nphi, nz + 1)); Jzf[:, :, 1:nz] = 0.5*(Jz[:, :, :-1] + Jz[:, :, 1:])
    Jpf = 0.5*(np.roll(Jp, 1, 1) + Jp)                                                  # face j between cell j-1 and j
    Jpf_next = np.roll(Jpf, -1, 1)
    sl_i = slice(ia, ib + 1); sl_k = slice(1, nz - 1)
    div = ((flux_r[ia + 1:ib + 2] - flux_r[ia:ib + 1])/(rc[sl_i, None, None]*G.dr))[:, :, sl_k] if not axis_mode else None
    if axis_mode:
        fr_lo = np.zeros_like(flux_r[0:1]); fr = np.concatenate([fr_lo, flux_r[1:]], axis=0)         # exact zero flux through the axis face (rf = 0)
        div = ((fr[ia + 1:ib + 2] - fr[ia:ib + 1])/(rc[sl_i, None, None]*G.dr))[:, :, sl_k]
    div = div + ((Jpf_next - Jpf)[sl_i]/(rc[sl_i, None, None]*G.dphi))[:, :, sl_k] + ((Jzf[sl_i, :, 2:nz] - Jzf[sl_i, :, 1:nz - 1])/G.dz)[:, :, :]*1.0
    vol = (rc[sl_i, None, None]*G.dr*G.dphi*G.dz)*np.ones((1, nphi, nz))[:, :, sl_k]
    lhs = float(np.sum(vol*div))
    # explicit boundary-face flux sum (independent bookkeeping)
    outer = G.dphi*G.dz*float(np.sum(flux_r[ib + 1][:, sl_k]))
    inner = 0.0 if axis_mode else G.dphi*G.dz*float(np.sum(flux_r[ia][:, sl_k]))
    top = G.dr*G.dphi*float(np.sum(rc[sl_i, None]*Jzf[sl_i, :, nz - 1])); bot = G.dr*G.dphi*float(np.sum(rc[sl_i, None]*Jzf[sl_i, :, 1]))
    rhs = outer - inner + top - bot
    gross = abs(outer) + abs(inner) + abs(top) + abs(bot)
    gross_abs = G.dphi*G.dz*float(np.sum(np.abs(flux_r[ib + 1][:, sl_k]))) + (0.0 if axis_mode else G.dphi*G.dz*float(np.sum(np.abs(flux_r[ia][:, sl_k])))) \
        + G.dr*G.dphi*float(np.sum(rc[sl_i, None]*np.abs(Jzf[sl_i, :, nz - 1]))) + G.dr*G.dphi*float(np.sum(rc[sl_i, None]*np.abs(Jzf[sl_i, :, 1])))
    return dict(div=div, lhs=lhs, rhs=rhs, gross=gross_abs, outer=outer, inner=inner, top=top, bot=bot)

def div_fv_predicted(B, G):
    """exact prediction for the finite-volume divergence of the kernel current (annulus):  div_fv(C B) = -(1/(4 rc)) delta_r^2 [ (1/rc) D_phi Bz_c ]
    (the Bphi contribution cancels identically: the FV radial operator is exactly the Bphi-compatible one).  Cells i=1..nr-2, k=1..nz-2."""
    g = G.g; Bzc = cc(B)[2]; x = (1/G.rc[:, None, None])*(np.roll(Bzc, -1, 1) - np.roll(Bzc, 1, 1))/(2*G.dphi)
    d2 = x[g + 1:g + G.nr + 1, g:g + G.nphi, :] - 2*x[g:g + G.nr, g:g + G.nphi, :] + x[g - 1:g + G.nr - 1, g:g + G.nphi, :]
    R = -d2/(4*G.rc[g:g + G.nr][:, None, None])
    return R[1:G.nr - 1][:, :, g + 1:g + G.nz - 1]

def t023(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(23)
    # (a) exact discrete Gauss identity for ANY cell-centred J (random kernel output; plus a deliberately NON-solenoidal analytic J to show the check is not vacuous)
    rows = []
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        for dt in (F64, F32):
            for n in [(9, 12, 7), (16, 16, 8)]:
                G = C.Grid(*n, r0=r0, r1=r0 + 1.0); B = rand_periodic(G, dt, rng); J = G.run(raw, B, dt)
                b = fv_box(J, G, mode == "axis"); tol = tol_alg(dt, bmax_of(B)*(2*math.pi*(r0 + 1.0)*1.0 + 1.0)/hmin_of(G))
                r_ = dict(mode=mode, dtype=dn(dt), grid=list(n), volume_integral_div=b["lhs"], boundary_flux=b["rhs"], diff=abs(b["lhs"] - b["rhs"]), tol=tol, ok=bool(abs(b["lhs"] - b["rhs"]) <= tol))
                if not r_["ok"]: fails.append(f"Gauss identity {mode} {dn(dt)} {n}: diff {r_['diff']:.3e} > tol {tol:.3e}")
                rows.append(r_)
    res["gauss_identity_rows"] = rows
    nv = []
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        G = C.Grid(16, 16, 8, r0=r0, r1=r0 + 1.0); g = G.g
        R_, P_, Z_ = G.mesh(G.rc, G.pc, G.zc)
        Jn = [np.ascontiguousarray(R_**2*(1 + 0.3*np.cos(P_))), np.ascontiguousarray(0.5*R_*np.sin(P_)*Z_), np.ascontiguousarray(1.0 + Z_**2 + R_*np.cos(P_))]
        Jfull = [j.copy() for j in Jn]
        b = fv_box(Jfull, G, mode == "axis"); sc = abs(b["lhs"])
        ok = bool(abs(b["lhs"] - b["rhs"]) <= 1e-12*max(b["gross"], 1.0) and sc > 1e-3*b["gross"])
        nv.append(dict(mode=mode, volume_integral_div=b["lhs"], boundary_flux=b["rhs"], gross=b["gross"], nonzero_fraction=sc/b["gross"], ok=ok))
        if not ok: fails.append(f"non-solenoidal control {mode}: {b['lhs']:.4e} vs {b['rhs']:.4e}")
    res["nonsolenoidal_control"] = nv
    # (a2) the finite-volume divergence of the kernel current has its OWN closed-form residual (annulus): -(1/4rc) delta_r^2 [(1/rc) D_phi Bz_c]
    fvrows = []
    for dt in (F64, F32):
        for n in [(9, 12, 7), (16, 16, 8), (6, 5, 4)]:
            G = C.Grid(*n, r0=0.5, r1=1.5); B = rand_periodic(G, dt, rng); J = G.run(raw, B, dt)
            d = fv_box(J, G, False)["div"]; p = div_fv_predicted(B, G); tol = tol_alg(dt, bmax_of(B)/hmin_of(G)**2); err = nmax(d - p)
            r_ = dict(dtype=dn(dt), grid=list(n), max_abs_div=nmax(d), max_abs_prediction=nmax(p), err_vs_prediction=err, tol=tol, sensitivity=nmax(p)/tol, ok=bool(err <= tol))
            if not r_["ok"]: fails.append(f"FV divergence closed form {dn(dt)} {n}: err {err:.3e} > tol {tol:.3e}")
            if r_["sensitivity"] < TOL3["sensitivity_min"]: fails.append(f"FV divergence closed form {dn(dt)} {n}: signal/tol {r_['sensitivity']:.2f} (non-discriminating)")
            fvrows.append(r_)
    res["fv_closed_form_rows"] = fvrows
    # (b) physical consistency: J = C(B) from an analytic B is divergence-free -> net boundary flux and cell divergence converge to 0 (second order)
    conv = []
    for mode, lv, fields in (("annulus", ann_levels, [H.M1, H.M2, H.M3, C.ADV, H.FIELD["SMOOTH"]]),
                             ("axis", axis_levels, [H.FIELD["QUAD"], H.FIELD["SMOOTH"], H.FIELD["KINK-poly"], H.FIELD["HELICAL KINK (m=1)"]])):
        for fld in fields:
            rws = []; floors = []; far = []
            for G in lv():
                B = G.sample(fld, F64); J = G.run(raw, B, F64); b = fv_box(J, G, mode == "axis")
                bound = TOL3["cond_trunc"]*(G.dr**2 + G.dz**2 + (G.rc[G.g]*G.dphi)**2)
                floors.append(tol_alg(F64, bmax_of(B)/hmin_of(G)**2)); far.append(reg_max(b["div"], G, 0 if mode == "axis" else 1, mode))
                rws.append(dict(h=max(G.dr, G.dz), grid=[G.nr, G.nphi, G.nz], net_flux=b["rhs"], gross_flux=b["gross"], net_over_gross=abs(b["rhs"])/max(b["gross"], 1e-300),
                                net_vs_volume_diff=abs(b["rhs"] - b["lhs"]), max_abs_div=nmax(b["div"]), bound=bound))
            errs = [r["max_abs_div"] for r in rws]
            o_ = orders_of(errs); ok_far, o_far = order_pass(far, floors)
            ok_o = True if mode == "annulus" else order_pass(errs, floors, order_min=TOL3["axis_div_order_min"])[0]
            ok_n = all(r["net_over_gross"] <= r["bound"] for r in rws)
            conv.append(dict(mode=mode, field=fld.name, rows=rws, orders_div_all_cells=o_, max_abs_div_region=far, orders_region=o_far, ok=bool(ok_o and ok_far and ok_n), ok_order=bool(ok_o), ok_far=bool(ok_far), ok_net_bound=ok_n))
            if not ok_o: fails.append(f"max|div_fv J| all-cells first-order requirement {mode} {fld.name}: {['%.2f' % x for x in o_]}")
            if not ok_far: fails.append(f"max|div_fv J| in the declared interior region {mode} {fld.name}: {['%.2f' % x for x in o_far]}")
            if not ok_n: fails.append(f"net boundary flux above the declared truncation bound {mode} {fld.name}")
    res["convergence"] = conv
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res


# ============================================================================
# TEST 024  Linear superposition
# ============================================================================
def t024(be):
    res = dict(rows=[], exact=[]); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(24)
    grids = [("annulus", (16, 16, 8), 0.5, 1.5), ("axis", (16, 16, 8), 0.0, 1.0), ("annulus", (17, 11, 9), 0.5, 1.5), ("axis", (17, 11, 9), 0.0, 1.0), ("near-axis", (48, 16, 8), 0.0, 0.1)]
    scal = [(1.0, 1.0), (2.0, -3.0), (0.5, 0.5), (1e3, 1e-3), (-1.0, 1.0), (1.0, 0.0), (0.0, 1.0), (1e-8, 1.0)]
    F = H.FIELD
    for gname, n, r0, r1 in grids:
        G = C.Grid(*n, r0=r0, r1=r1); G.grid_name = gname
        pairs = [("random", "random"), ("SMOOTH", "KINK-poly"), ("HELICAL KINK (m=1)", "QUAD")] + ([("M1", "M2")] if r0 > 0 else [])
        for dt in (F64, F32):
            for fa, fb in pairs:
                def mk(nm):
                    if nm == "random": return H.random_B(G, dt, rng)
                    fld = {"M1": H.M1, "M2": H.M2}.get(nm) or F[nm]; return G.sample(fld, dt)
                B1, B2 = mk(fa), mk(fb); J1 = Ji(G.run(raw, B1, dt), G); J2 = Ji(G.run(raw, B2, dt), G)
                for a_, b_ in scal:
                    Bc = [(dt(a_)*x + dt(b_)*y).astype(dt) for x, y in zip(B1, B2)]; Jc = Ji(G.run(raw, Bc, dt), G)
                    comb = [a_*x + b_*y for x, y in zip(J1, J2)]; err = max(nmax(c - k) for c, k in zip(Jc, comb))
                    bound = TOL3["lin_factor"]*EPS[dt]*(abs(a_)*bmax_of(B1) + abs(b_)*bmax_of(B2))/hmin_of(G)
                    jsc = max(nmax(c) for c in comb)
                    row = dict(grid_type=gname, grid=list(n), dtype=dn(dt), fields=f"{fa}+{fb}", a=a_, b=b_, err=err, bound=bound, J_scale=jsc, ratio=err/bound, ok=bool(err <= bound))
                    # sensitivity: a deliberate relative perturbation of the combined result must exceed the bound (the check is not vacuous)
                    pert = 1e-6 if dt is F64 else 1e-1
                    row["discriminating"] = bool(jsc > 0 and bound <= 0.5*pert*jsc)       # declared: a case is discriminating iff a relative perturbation `pert` of the result exceeds the bound
                    row["perturbation_detected"] = (bool(max(nmax(c*(1 + pert) - k) for c, k in zip(Jc, comb)) > bound) if row["discriminating"] else None)
                    if not row["ok"]: fails.append(f"superposition {gname} {dn(dt)} {fa}+{fb} a={a_} b={b_}: err {err:.3e} > bound {bound:.3e}")
                    if row["perturbation_detected"] is False: fails.append(f"superposition sensitivity {gname} {dn(dt)} {fa}+{fb} a={a_} b={b_}: a {pert:g} perturbation was NOT detected")
                    res["rows"].append(row)
    # exact identities: C(0) = 0, C(-B) = -C(B), C(2^p B) = 2^p C(B)   (all BITWISE: the kernel arithmetic is homogeneous with exactly-representable scaling)
    for gname, n, r0, r1 in grids[:4]:
        G = C.Grid(*n, r0=r0, r1=r1)
        for dt in (F64, F32):
            B = H.random_B(G, dt, rng); J = Ji(G.run(raw, B, dt), G)
            Z = [np.zeros_like(b) for b in B]; Jz0 = Ji(G.run(raw, Z, dt), G)
            Jn = Ji(G.run(raw, [-b for b in B], dt), G)
            r_ = dict(grid_type=gname, grid=list(n), dtype=dn(dt), zero_field_max_abs=max(nmax(j) for j in Jz0), negation_max_abs_diff=max(nmax(a + b) for a, b in zip(Jn, J)))
            sc = {}
            for p in (-6, -1, 1, 5):
                Jp_ = Ji(G.run(raw, [b*dt(2.0**p) for b in B], dt), G); sc[p] = max(nmax(a - b*2.0**p) for a, b in zip(Jp_, J))
            r_["pow2_max_abs_diff"] = sc
            r_["ok"] = bool(r_["zero_field_max_abs"] == 0 and r_["negation_max_abs_diff"] == 0 and all(v == 0 for v in sc.values()))
            if not r_["ok"]: fails.append(f"exact homogeneity {gname} {dn(dt)}: zero {r_['zero_field_max_abs']}, neg {r_['negation_max_abs_diff']}, pow2 {sc}")
            res["exact"].append(r_)
    rr = res["rows"]
    res["summary"] = dict(n_cases=len(rr), max_ratio_err_over_bound=max(r["ratio"] for r in rr), cases_discriminating=sum(1 for r in rr if r["discriminating"]), cases_perturbation_detected=sum(1 for r in rr if r["perturbation_detected"]),
                          cases_non_discriminating=sum(1 for r in rr if not r["discriminating"]),
                          non_discriminating_note="round-off bound (128 eps B/hmin) exceeds half the test perturbation times |J| (FP32 near the axis on a very fine grid, or zero signal); the bound check is still enforced")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 025  Constant-field nullspace
# ============================================================================
CONST_BZ = C._cart_field(H.Z0, H.Z0, lambda x, y, z: 0.7 + 0*x, H.Z0, H.Z0, H.Z0, "Bz = 0.7 (constant axial)")
UNIFORM = C._cart_field(lambda x, y, z: 0.7 + 0*x, lambda x, y, z: -0.4 + 0*x, lambda x, y, z: 0.3 + 0*x, H.Z0, H.Z0, H.Z0, "uniform Cartesian (0.7,-0.4,0.3)")
GRAD1 = C._cart_field(lambda x, y, z: y*z + 0.6*x, lambda x, y, z: x*z - 0.6*y, lambda x, y, z: x*y + 0.6*z**2, H.Z0, H.Z0, H.Z0, "grad psi, psi = xyz + 0.3(x^2-y^2) + 0.2 z^3")
GRAD2 = C._cart_field(lambda x, y, z: np.cos(x + 0.5*z)*np.cos(y), lambda x, y, z: -np.sin(x + 0.5*z)*np.sin(y), lambda x, y, z: 0.5*np.cos(x + 0.5*z)*np.cos(y), H.Z0, H.Z0, H.Z0, "grad psi, psi = sin(x+z/2) cos(y)")
VORTEX = C.Field(lambda r, p, z: 0*r, lambda r, p, z: 1.0/r, lambda r, p, z: 0.3 + 0*r, lambda r, p, z: 0*r, lambda r, p, z: 0*r, lambda r, p, z: 0*r, "irrotational vortex Bphi = 1/r (+ Bz = 0.3), r > 0")

def null_mode_fields(G, dt, rng):
    """grid-scale modes the kernel's averaging / centred stencils annihilate EXACTLY (annulus mode, nphi even); each returns staggered arrays"""
    g, n = G.g, G.nphi; shp = lambda a, b, c: (G.nr + a + 2*g, G.nphi + b + 2*g, G.nz + c + 2*g)
    sg = lambda m, off: np.where(((np.arange(m) - off) % 2) == 0, 1.0, -1.0)
    out = {}
    q = rng.uniform(-1, 1, (1,) + shp(0, 0, 1)[1:2] + (1,))                                       # placeholder for shape clarity
    # (1) Bz alternating between z-faces, arbitrary in (r,phi), z-uniform magnitude
    Bz = sg(G.nz + 1 + 2*g, g)[None, None, :]*rng.uniform(-1, 1, shp(0, 0, 1)[0:2] + (1,)); Br = rng.uniform(0, 0, shp(1, 0, 0)); Bp = np.zeros(shp(0, 1, 0))
    out["Bz alternating on z-faces"] = per_fill([Br, Bp, Bz], G)
    # (2) Br alternating between r-faces, radially uniform magnitude
    Br = sg(G.nr + 1 + 2*g, g)[:, None, None]*rng.uniform(-1, 1, (1,) + shp(1, 0, 0)[1:]); out["Br alternating on r-faces"] = per_fill([Br, np.zeros(shp(0, 1, 0)), np.zeros(shp(0, 0, 1))], G)
    # (3) Bphi alternating between phi-faces (phi-uniform magnitude per (r,z))
    Bp = sg(G.nphi + 1 + 2*g, g)[None, :, None]*rng.uniform(-1, 1, (shp(0, 1, 0)[0], 1, shp(0, 1, 0)[2])); out["Bphi alternating on phi-faces"] = per_fill([np.zeros(shp(1, 0, 0)), Bp, np.zeros(shp(0, 0, 1))], G)
    # (4) Bz alternating between phi-cells, radially uniform (arbitrary in z)
    Bz = sg(G.nphi + 2*g, g)[None, :, None]*rng.uniform(-1, 1, (1, 1, shp(0, 0, 1)[2])); Bz = np.broadcast_to(Bz, shp(0, 0, 1)).copy(); out["Bz alternating on phi-cells (r-uniform)"] = per_fill([np.zeros(shp(1, 0, 0)), np.zeros(shp(0, 1, 0)), Bz], G)
    return {k: [np.ascontiguousarray(x.astype(dt)) for x in v] for k, v in out.items()}

def t025(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(25)
    # (a) constant axial field: exact zero (bitwise on annulus; one-sided axis-ring stencil costs a few ulp of |c|/dr)
    rows = []
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        for dt in (F64, F32):
            G = C.Grid(16, 16, 8, r0=r0, r1=r0 + 1.0); B = G.sample(CONST_BZ, dt); J = Ji(G.run(raw, B, dt), G)
            tol = 0.0 if mode == "annulus" else tol_alg(dt, 0.7/G.dr); err = max(nmax(j) for j in J)
            rows.append(dict(mode=mode, dtype=dn(dt), max_abs_J=err, tol=tol, bitwise_zero=bool(err == 0), ok=bool(err <= tol)))
            if err > tol: fails.append(f"constant Bz {mode} {dn(dt)}: max|J| = {err:.3e} > {tol:.3e}")
    res["constant_axial"] = rows
    # (b) truncation error and convergence for fields with J_ref = 0: uniform Cartesian, curl-free gradients, irrotational vortex
    conv = []
    sets = [("annulus", ann_levels, [UNIFORM, GRAD1, GRAD2, VORTEX]), ("axis", axis_levels, [UNIFORM, GRAD1, GRAD2])]
    for mode, lv, fields in sets:
        for fld in fields:
            rows_ = []
            for G in lv():
                B = G.sample(fld, F64); J = Ji(G.run(raw, B, F64), G); floor = tol_alg(F64, bmax_of(B)/hmin_of(G))
                comps = [reg_max(J[c], G, 0, mode) for c in range(3)]; allc = [nmax(J[c]) for c in range(3)]
                rows_.append(dict(h=max(G.dr, G.dz), grid=[G.nr, G.nphi, G.nz], region_comp_err=comps, all_cells_comp_err=allc, floor=floor))
            ok_c = []; ords = []
            for c in range(3):
                e = [r["region_comp_err"][c] for r in rows_]; ok, o = order_pass(e, [r["floor"] for r in rows_]); ok_c.append(ok); ords.append(o)
            if mode == "axis":
                allmax = [max(r["all_cells_comp_err"]) for r in rows_]; ok_all, o_all = order_pass(allmax, [r["floor"] for r in rows_], order_min=TOL3["axis_div_order_min"])
            else: ok_all, o_all = True, orders_of([max(r["all_cells_comp_err"]) for r in rows_])
            conv.append(dict(mode=mode, field=fld.name, rows=rows_, orders_region=ords, orders_all_cells_max=o_all, ok=bool(all(ok_c) and ok_all)))
            if not all(ok_c): fails.append(f"nullspace truncation convergence {mode} {fld.name}: region orders {[['%.2f' % x for x in o] for o in ords]}")
            if not ok_all: fails.append(f"nullspace {mode} {fld.name}: all-cells error does not converge at first order: {['%.2f' % x for x in o_all]}")
    res["convergence"] = conv
    # (c) documented spurious null modes: exact zero current from grid-scale fields (annulus, nphi even) -- a LIMITATION the driver must know about
    nm = []
    for dt in (F64, F32):
        G = C.Grid(12, 16, 8, r0=0.5, r1=1.5)
        for name, B in null_mode_fields(G, dt, rng).items():
            J = Ji(G.run(raw, B, dt), G); amp = bmax_of(B); jm = max(nmax(j) for j in J)
            nm.append(dict(mode=name, dtype=dn(dt), max_abs_B=amp, max_abs_J=jm, ok=bool(jm == 0 and amp > 0)))
            if not nm[-1]["ok"]: fails.append(f"null mode '{name}' {dn(dt)}: |B|max {amp:.3g}, |J|max {jm:.3e} (expected exactly 0)")
        Bc = H.random_B(G, dt, rng); Jc = Ji(G.run(raw, per_fill(Bc, G), dt), G)
        nm.append(dict(mode="control: random field (must NOT be null)", dtype=dn(dt), max_abs_B=bmax_of(Bc), max_abs_J=max(nmax(j) for j in Jc), ok=bool(max(nmax(j) for j in Jc) > 1.0)))
        if not nm[-1]["ok"]: fails.append("null-mode control: a random field produced a (near) zero current")
    res["spurious_null_modes"] = nm
    res["limitation"] = ("The cell-centred averages and 2h centred differences annihilate grid-scale (odd-even) patterns exactly: such Br/Bphi/Bz content is INVISIBLE to J = curl B. "
                         "This is a property of the operator, not an error; a driver that needs these modes controlled must do so elsewhere (e.g. through the CT update / divergence control).")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 026  Cylindrical symmetry covariance
# ============================================================================
def t026(be):
    res = dict(rotation=[], mirror=[], z_shift=[]); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(26)
    F = H.FIELD
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        for dt in (F64, F32):
            G = C.Grid(10, 12, 7, r0=r0, r1=r0 + 1.0)
            fields = [("random periodic", rand_periodic(G, dt, rng))] + [(f.name, G.sample(f, dt)) for m in (1, 2, 3) for f in H.fourier_fields(m)] + [("HELICAL KINK (m=1)", G.sample(F["HELICAL KINK (m=1)"], dt))]
            for nm, B in fields:
                B = per_fill(B, G)                                  # impose EXACT periodic ghosts (analytic samples are periodic only to ~1 ulp: cos(phi+2pi) != cos(phi))
                J0 = Ji(G.run(raw, B, dt), G); scale = max(max(nmax(j) for j in J0), 1e-300)
                tol = 0.0 if mode == "annulus" else (max(TOL3["rot_axis_rel"]*scale, tol_alg(dt, bmax_of(B)/hmin_of(G))) if dt is F64 else C.fp32_bound(G, bmax_of(B), dt))   # relative to |J|, floored at the round-off scale (some fields have J = 0 exactly)
                worst = 0.0
                for s in range(G.nphi):
                    Js = Ji(G.run(raw, rotate_B(B, G, s), dt), G); worst = max(worst, max(nmax(a - np.roll(b, s, axis=1)) for a, b in zip(Js, J0)))
                row = dict(mode=mode, dtype=dn(dt), field=nm, shifts_tested=G.nphi, max_abs_diff=worst, tol=tol, bitwise=bool(worst == 0), J_scale=scale, ok=bool(worst <= tol))
                if not row["ok"]: fails.append(f"rotation covariance {mode} {dn(dt)} {nm}: max diff {worst:.3e} > tol {tol:.3e}")
                res["rotation"].append(row)
                Jm = Ji(G.run(raw, mirror_B(B, G), dt), G); ex = mirror_J(G.run(raw, B, dt), G); dm = max(nmax(a - b) for a, b in zip(Jm, ex))
                rowm = dict(mode=mode, dtype=dn(dt), field=nm, max_abs_diff=dm, tol=tol, bitwise=bool(dm == 0), ok=bool(dm <= tol))
                if not rowm["ok"]: fails.append(f"mirror covariance {mode} {dn(dt)} {nm}: max diff {dm:.3e} > tol {tol:.3e}")
                res["mirror"].append(rowm)
            # z-translation covariance (uniform z spacing): J(shifted B) == shifted J on cells whose stencil does not touch the wrapped layers (random field)
            Br_, Bp_, Bz_ = rand_periodic(G, dt, rng); scale = max(nmax(j) for j in Ji(G.run(raw, [Br_, Bp_, Bz_], dt), G))
            for sz in (1, 2, 3):
                Bs = [np.roll(x, sz, axis=2) for x in (Br_, Bp_, Bz_)]
                J1 = G.run(raw, [Br_, Bp_, Bz_], dt); J2 = G.run(raw, Bs, dt); g = G.g
                lo = sz + 2 - g; lo = max(lo, 0)                                  # interior k whose stencil (k-1..k+2 in array index) avoids wrapped layers
                d = max(nmax(J2[c][g:g + G.nr, g:g + G.nphi, g + lo:g + G.nz] - np.roll(J1[c], sz, axis=2)[g:g + G.nr, g:g + G.nphi, g + lo:g + G.nz]) for c in range(3))
                tol = 0.0 if mode == "annulus" else (max(TOL3["rot_axis_rel"]*scale, tol_alg(dt, 1.0/hmin_of(G))) if dt is F64 else C.fp32_bound(G, 1.0, dt))
                ok = bool(d <= tol)
                if not ok: fails.append(f"z-shift covariance {mode} {dn(dt)} shift {sz}: {d:.3e} > {tol:.3e}")
                res["z_shift"].append(dict(mode=mode, dtype=dn(dt), shift=sz, max_abs_diff=d, tol=tol, bitwise=bool(d == 0), ok=ok))
    res["summary"] = dict(annulus_all_bitwise=bool(all(r["bitwise"] for r in res["rotation"] + res["mirror"] + res["z_shift"] if r["mode"] == "annulus")),
                          axis_worst_diff_over_tol=max(r["max_abs_diff"]/r["tol"] for r in res["rotation"] + res["mirror"] if r["mode"] == "axis"))
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 027  Magnetic-energy / current consistency (discrete integration by parts of the curl)
# ============================================================================
def _hb(f, g_, ax, a, b, G, other):
    """(f_b g_{b+1} + g_b f_{b+1}) - (f_{a-1} g_a + g_{a-1} f_a) along axis ax (interior indices a..b); `other` = slices of the other two axes (full-array indices)"""
    g = G.g
    def at(X, m):
        idx = list(other); idx[ax] = g + m; return X[tuple(idx)]
    return (at(f, b)*at(g_, b + 1) + at(g_, b)*at(f, b + 1)) - (at(f, a - 1)*at(g_, a) + at(g_, a - 1)*at(f, a))

def ibp_direct(A, B, JA, JB, G, box):
    ia, ib, ka, kb = box; Ac, Bc = cc(A), cc(B); g = G.g
    sl = (slice(g + ia, g + ib + 1), slice(g, g + G.nphi), slice(g + ka, g + kb + 1)); J = lambda JJ: [np.asarray(x[sl], dtype=F64) for x in JJ]
    JAi, JBi = J(JA), J(JB); rc = G.rc[g + ia:g + ib + 1][:, None, None]; vol = rc*G.dr*G.dphi*G.dz
    return float(np.sum(vol*(sum(Ac[c][sl]*JBi[c] for c in range(3)) - sum(Bc[c][sl]*JAi[c] for c in range(3)))))

def ibp_predicted(A, B, G, box):
    """boundary terms (r and z interfaces; phi closes periodically) + the O(dr^2) mismatch term from the compact Jz radial difference"""
    ia, ib, ka, kb = box; Ac, Bc = cc(A), cc(B); g = G.g; rcf = G.rc[:, None, None]
    ph = slice(g, g + G.nphi); kk = slice(g + ka, g + kb + 1); ii = slice(g + ia, g + ib + 1)
    # r interfaces: -1/2 h_r(rc Aphi_c, Bz_c) + 1/2 h_r(rc Bphi_c, Az_c)
    o_r = (None, ph, kk)
    def hr(f, g_):
        idx_other = (slice(None), ph, kk)
        gg = G.g
        def at(X, m): return X[gg + m, ph, kk]
        return (at(f, ib)*at(g_, ib + 1) + at(g_, ib)*at(f, ib + 1)) - (at(f, ia - 1)*at(g_, ia) + at(g_, ia - 1)*at(f, ia))
    Br_t = G.dphi*G.dz*float(np.sum(-0.5*hr(rcf*Ac[1], Bc[2]) + 0.5*hr(rcf*Bc[1], Ac[2])))
    def hz(f, g_):
        def at(X, m): return X[ii, ph, g + m]
        return (at(f, kb)*at(g_, kb + 1) + at(g_, kb)*at(f, kb + 1)) - (at(f, ka - 1)*at(g_, ka) + at(g_, ka - 1)*at(f, ka))
    rc2 = G.rc[g + ia:g + ib + 1][:, None]
    Bz_t = G.dr*G.dphi*float(np.sum(rc2*(-0.5*hz(Ac[0], Bc[1]) + 0.5*hz(Ac[1], Bc[0]))))
    d2 = lambda X: X[g + ia + 1:g + ib + 2, ph, kk] - 2*X[ii, ph, kk] + X[g + ia - 1:g + ib, ph, kk]
    M = 0.25*G.dr*G.dphi*G.dz*float(np.sum(Bc[2][ii, ph, kk]*d2(Ac[1]) - Ac[2][ii, ph, kk]*d2(Bc[1])))
    return Br_t + Bz_t + M, dict(r_boundary=Br_t, z_boundary=Bz_t, mismatch=M)

def poynting_analytic(Af, Bf, r0, r1, z0, z1, n=16, nphi=128):
    """continuous identity  integral (A.curl B - B.curl A) dV = surface integral of (B x A).dS  :  returns (surface flux, volume integral) from analytic fields"""
    tr, wr = gl(r0, r1, n); tz, wz = gl(z0, z1, n); ph = (np.arange(nphi) + 0.5)*2*math.pi/nphi; wp = np.full(nphi, 2*math.pi/nphi)
    def cr(X, Y):                                # (X x Y) components helpers
        return None
    # outer / inner radial surfaces: (B x A)_r = Bphi Az - Bz Aphi, area r dphi dz
    P, Z = np.meshgrid(ph, tz, indexing="ij"); W = np.outer(wp, wz); fl = 0.0
    for r, sg in ((r1, 1.0), (r0, -1.0)):
        if r == 0.0: continue
        R = np.full_like(P, r); fl += sg*r*float(np.sum(W*(Bf.Bp(R, P, Z)*Af.Bz(R, P, Z) - Bf.Bz(R, P, Z)*Af.Bp(R, P, Z))))
    Rm, P2 = np.meshgrid(tr, ph, indexing="ij"); W2 = np.outer(wr, wp)
    for z, sg in ((z1, 1.0), (z0, -1.0)):
        Zc = np.full_like(Rm, z); fl += sg*float(np.sum(W2*Rm*(Bf.Br(Rm, P2, Zc)*Af.Bp(Rm, P2, Zc) - Bf.Bp(Rm, P2, Zc)*Af.Br(Rm, P2, Zc))))
    R3, P3, Z3 = np.meshgrid(tr, ph, tz, indexing="ij"); W3 = wr[:, None, None]*wp[None, :, None]*wz[None, None, :]
    integ = (Af.Br(R3, P3, Z3)*Bf.Jr(R3, P3, Z3) + Af.Bp(R3, P3, Z3)*Bf.Jp(R3, P3, Z3) + Af.Bz(R3, P3, Z3)*Bf.Jz(R3, P3, Z3)
             - Bf.Br(R3, P3, Z3)*Af.Jr(R3, P3, Z3) - Bf.Bp(R3, P3, Z3)*Af.Jp(R3, P3, Z3) - Bf.Bz(R3, P3, Z3)*Af.Jz(R3, P3, Z3))
    vol = float(np.sum(W3*R3*integ))
    return fl, vol

def t027(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(27)
    # (a) EXACT: S = sum vol (A.CB - B.CA) equals the discrete boundary terms + the explicit O(dr^2) mismatch term (annulus; full phi ring; full domain and sub-boxes)
    rows = []
    for dt in (F64, F32):
        for n in [(9, 12, 7), (16, 16, 8), (6, 8, 5)]:
            G = C.Grid(*n, r0=0.5, r1=1.5); A = rand_periodic(G, dt, rng); B = rand_periodic(G, dt, rng)
            JA = G.run(raw, A, dt); JB = G.run(raw, B, dt)
            boxes = [(0, G.nr - 1, 0, G.nz - 1), (1, G.nr - 2, 1, G.nz - 2), (2, max(2, G.nr - 3), 1, max(1, G.nz - 3))]
            for bx in boxes:
                if bx[1] < bx[0] or bx[3] < bx[2]: continue
                Sd = ibp_direct(A, B, JA, JB, G, bx); Sp, parts = ibp_predicted(A, B, G, bx)
                scale = bmax_of(A)*bmax_of(B)*(2*math.pi*1.0*1.0)/hmin_of(G); tol = tol_alg(dt, scale)
                row = dict(dtype=dn(dt), grid=list(n), box=list(bx), S_direct=Sd, S_predicted=Sp, diff=abs(Sd - Sp), tol=tol, boundary_r=parts["r_boundary"], boundary_z=parts["z_boundary"], mismatch=parts["mismatch"],
                           mismatch_over_S=abs(parts["mismatch"])/max(abs(Sd), 1e-300), ok=bool(abs(Sd - Sp) <= tol), S_over_tol=abs(Sd)/tol,
                           largest_term_over_tol=max(abs(parts["r_boundary"]), abs(parts["z_boundary"]), abs(parts["mismatch"]))/tol, mismatch_over_tol=abs(parts["mismatch"])/tol)
                if not row["ok"]: fails.append(f"integration by parts {dn(dt)} {n} box {bx}: |S_direct - S_predicted| = {row['diff']:.3e} > tol {tol:.3e}")
                if row["largest_term_over_tol"] < TOL3["sensitivity_min"]: fails.append(f"integration by parts {dn(dt)} {n} box {bx}: largest identity term / tol = {row['largest_term_over_tol']:.2f} (non-discriminating)")
                if dt is F64 and row["mismatch_over_tol"] < TOL3["sensitivity_min"]: fails.append(f"integration by parts {dn(dt)} {n} box {bx}: the mismatch term is not resolved above the tolerance (mismatch/tol = {row['mismatch_over_tol']:.2f})")
                rows.append(row)
    res["exact_rows"] = rows
    res["mismatch_is_needed"] = bool(max(r["mismatch_over_S"] for r in rows) > 1e-3)
    # (b) approximate: discrete S -> continuous boundary flux of (B x A), second order; annulus and axis
    conv = []; refchk = []
    ann = [(H.M1, H.M2), (H.M2, H.M3), (C.ADV, H.M1), (H.M3, C.ADV)]
    axf = H.FIELD
    axp = [(axf["QUAD"], axf["SMOOTH"]), (axf["HELICAL KINK (m=1)"], axf["KINK-poly"]), (axf["SMOOTH"], axf["HELICAL KINK (m=1)"])]
    for mode, lv, pairs in (("annulus", ann_levels, ann), ("axis", axis_levels, axp)):
        for Af, Bf in pairs:
            rws = []
            for G in lv():
                A = G.sample(Af, F64); B = G.sample(Bf, F64); JA = G.run(raw, A, F64); JB = G.run(raw, B, F64)
                Sd = ibp_direct(A, B, JA, JB, G, (0, G.nr - 1, 0, G.nz - 1))
                fl, vol = poynting_analytic(Af, Bf, G.rf[G.g], G.rf[G.g + G.nr], G.z0, G.z0 + G.nz*G.dz)
                refchk.append(abs(fl - vol)/max(abs(fl), abs(vol), 1.0))
                rws.append(dict(h=max(G.dr, G.dz), grid=[G.nr, G.nphi, G.nz], S_discrete=Sd, flux_analytic=fl, volume_analytic=vol, err=abs(Sd - fl)))
            errs = [r["err"] for r in rws]; ok, o = order_pass(errs, [TOL3["exact_fp64"]]*len(errs))
            conv.append(dict(mode=mode, pair=f"A={Af.name} | B={Bf.name}", rows=rws, orders=o, ok=ok))
            if not ok: fails.append(f"integration-by-parts convergence {mode} {Af.name}|{Bf.name}: orders {['%.2f' % x for x in o]}")
    res["convergence"] = conv; res["analytic_reference_check_max_rel"] = max(refchk)
    if max(refchk) > TOL3["ref_check"]: fails.append(f"analytic flux vs analytic volume integral disagree: {max(refchk):.3e}")
    res["no_energy_claim"] = ("This test establishes an identity of the CURL OPERATOR ALONE (integral of A.curlB - B.curlA = boundary flux of BxA, plus an explicit O(dr^2) mismatch). "
                              "It does NOT claim magnetic-energy conservation: dE/dt requires the Faraday/CT update, Ohm's law and J x B, none of which is part of this kernel.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res


# ============================================================================
# TEST 028  Discrete vector identities  (curl of a gradient)
# ============================================================================
PSI = {"psi1 = xyz + 0.3(x^2-y^2) + 0.2z^3": lambda x, y, z: x*y*z + 0.3*(x**2 - y**2) + 0.2*z**3,
       "psi2 = sin(x + z/2) cos(y)": lambda x, y, z: np.sin(x + 0.5*z)*np.cos(y)}
PSI_FIELD = {"psi1 = xyz + 0.3(x^2-y^2) + 0.2z^3": GRAD1, "psi2 = sin(x + z/2) cos(y)": GRAD2}

def cell_psi(G, psi):
    R, P, Z = G.mesh(G.rc, G.pc, G.zc); return psi(R*np.cos(P), R*np.sin(P), Z)

def ext_grid(G):
    """same geometry, one more ghost layer: a potential sampled here defines EVERY face of G's staggered arrays (the axis-mode cubic stencil reaches the outermost phi face)"""
    return C.Grid(G.nr, G.nphi, G.nz, g=G.g + 1, r0=G.r0, r1=G.r0 + G.nr*G.dr, z0=G.z0, z1=G.z0 + G.nz*G.dz)

def compat_grad(PsiExt, G, dt):
    """compatible discrete gradient of a cell-centred potential PsiExt (sampled on ext_grid(G)):  Br=(psi_i-psi_{i-1})/dr at r-faces,
    Bphi=(psi_j-psi_{j-1})/(rc dphi) at phi-faces (rc = radius of the face's ring), Bz=(psi_k-psi_{k-1})/dz at z-faces.  Output has exactly G's staggered shapes."""
    Br = (PsiExt[1:, 1:-1, 1:-1] - PsiExt[:-1, 1:-1, 1:-1])/G.dr
    Bp = (PsiExt[1:-1, 1:, 1:-1] - PsiExt[1:-1, :-1, 1:-1])/(G.rc[:, None, None]*G.dphi)
    Bz = (PsiExt[1:-1, 1:-1, 1:] - PsiExt[1:-1, 1:-1, :-1])/G.dz
    return [np.ascontiguousarray(b.astype(dt)) for b in (Br, Bp, Bz)]

def finite_bmax(B): return max(float(np.max(np.abs(b[np.isfinite(b)]))) for b in B)

def collocated_gradient_field(fld, G, dt):
    """INCOMPATIBLE staggering on purpose: every component of the analytic gradient is sampled half a cell away from where the Yee grid expects it"""
    Br = fld.Br(*G.mesh(G.rf + 0.5*G.dr, G.pc, G.zc)); Bp = fld.Bp(*G.mesh(G.rc, G.pf + 0.5*G.dphi, G.zc)); Bz = fld.Bz(*G.mesh(G.rc, G.pc, G.zf + 0.5*G.dz))
    return [np.ascontiguousarray(x.astype(dt)) for x in (Br, Bp, Bz)]

def t028(be):
    res = dict(); fails = []; raw = H.backend_for(be); rng = np.random.default_rng(28)
    # (a) EXACT (annulus): C(grad_h psi) = (0, 0, -(1/(4 rc)) delta_r^2 Bphi_c) for ARBITRARY cell data psi (random), FP64 and FP32, g = 2, 3
    rows = []
    for dt in (F64, F32):
        for g in (2, 3):
            for n in [(9, 12, 7), (16, 16, 8), (5, 4, 3)]:
                G = C.Grid(*n, g=g, r0=1.0, r1=2.0); G3 = ext_grid(G)      # r0 = 1: with g = 3 and the coarsest grid the inner ghost ring must not reach r = 0
                Psi = per_fill([rng.uniform(-1, 1, (G3.nr + 2*G3.g, G3.nphi + 2*G3.g, G3.nz + 2*G3.g))], G3)[0]
                B = compat_grad(Psi, G, dt); J = Ji(G.run(raw, B, dt), G); fin = all(bool(np.isfinite(j).all()) for j in J)
                Q = jz_residual_term(B, G)[:, :, g:g + G.nz]; tol = tol_alg(dt, finite_bmax(B)/hmin_of(G))
                e_r, e_p, e_z = nmax(J[0]), nmax(J[1]), nmax(J[2] - Q)
                r_ = dict(dtype=dn(dt), g=g, grid=list(n), finite=fin, err_Jr=e_r, err_Jphi=e_p, err_Jz_vs_closed_form=e_z, tol=tol, max_abs_Jz=nmax(J[2]), sensitivity=nmax(J[2])/tol,
                          ok=bool(fin and max(e_r, e_p, e_z) <= tol))
                if not r_["ok"]: fails.append(f"curl(grad) exact identity {dn(dt)} g={g} {n}: finite={fin}, errs ({e_r:.2e},{e_p:.2e},{e_z:.2e}) tol {tol:.2e}")
                if r_["sensitivity"] < TOL3["sensitivity_min"]: fails.append(f"curl(grad) exact identity {dn(dt)} g={g} {n}: |Jz|/tol {r_['sensitivity']:.2f} (non-discriminating)")
                rows.append(r_)
    res["exact_rows"] = rows
    # (b) approximate: analytic psi; compatible gradient -> residual Jz only (second order); point-sampled analytic gradient -> second order; INCOMPATIBLE staggering -> first order
    conv = []
    for mode, lv in (("annulus", ann_levels), ("axis", axis_levels)):
        for pname, psi in PSI.items():
            fld = PSI_FIELD[pname]; rc_, rp_, rs_ = [], [], []; fl = []; ex = []
            for G in lv():
                Psi = cell_psi(ext_grid(G), psi); B1 = compat_grad(Psi, G, F64); J1 = Ji(G.run(raw, B1, F64), G); B2 = G.sample(fld, F64); J2 = Ji(G.run(raw, B2, F64), G)
                B3 = collocated_gradient_field(fld, G, F64); J3 = Ji(G.run(raw, B3, F64), G)
                reg = lambda J: max(reg_max(J[c], G, 0, mode) for c in range(3))
                rc_.append(reg(J1)); rp_.append(reg(J2)); rs_.append(reg(J3)); fl.append(tol_alg(F64, finite_bmax(B1)/hmin_of(G)))
                if mode == "annulus": ex.append(nmax(J1[2] - jz_residual_term(B1, G)[:, :, G.g:G.g + G.nz]))
            ok1, o1 = order_pass(rc_, fl); ok2, o2 = order_pass(rp_, fl)
            o3 = orders_of(rs_); ok3 = bool(o3[-1] <= TOL3["incompatible_order_max"] and rs_[-1] > 100*fl[-1])
            row = dict(mode=mode, psi=pname, compatible_region_max=rc_, compatible_orders=o1, pointsampled_region_max=rp_, pointsampled_orders=o2, incompatible_region_max=rs_, incompatible_orders=o3,
                       ok_compatible=ok1, ok_pointsampled=ok2, ok_incompatible_detected=ok3, closed_form_err_by_level=ex)
            row["ok"] = bool(ok1 and ok2 and ok3)
            if not ok1: fails.append(f"curl(grad_h psi) {mode} {pname}: orders {['%.2f' % x for x in o1]}")
            if not ok2: fails.append(f"curl(point-sampled grad) {mode} {pname}: orders {['%.2f' % x for x in o2]}")
            if not ok3: fails.append(f"incompatible staggering NOT detected as non-second-order {mode} {pname}: orders {['%.2f' % x for x in o3]}")
            conv.append(row)
    res["convergence"] = conv
    res["statement"] = ("curl of the COMPATIBLE discrete gradient is not zero: C(grad_h psi) = (0, 0, -(1/(4 rc)) delta_r^2 Bphi_c) exactly (annulus). The residual is purely axial, O(dr^2), "
                        "and comes from the compact face-weighted radial difference in Jz. Jr and Jphi vanish identically. An incompatible staggering produces a FIRST-order residual in all components.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 029  Extreme cancellation and conditioning
# ============================================================================
def mix_field(A, eps):
    G1, S = GRAD1, H.FIELD["SMOOTH"]
    L = lambda f1, f2: (lambda r, p, z: A*f1(r, p, z) + eps*f2(r, p, z))
    return C.Field(L(G1.Br, S.Br), L(G1.Bp, S.Bp), L(G1.Bz, S.Bz), lambda r, p, z: eps*S.Jr(r, p, z), lambda r, p, z: eps*S.Jp(r, p, z), lambda r, p, z: eps*S.Jz(r, p, z), f"{A:g}*grad(psi) + {eps:g}*SMOOTH")

def t029(be):
    res = dict(); fails = []; raw = H.backend_for(be)
    eps_sig = 1.0; rows = []
    for mode, r0 in (("annulus", 0.5), ("axis", 0.0)):
        for dt in (F64, F32):
            G = C.Grid(24, 24, 12, r0=r0, r1=r0 + 1.0); prev = None
            for A in (1.0, 1e2, 1e4, 1e6, 1e8):
                fld = mix_field(A, eps_sig); B = G.sample(fld, dt); J = Ji(G.run(raw, B, dt), G); ref = G.ref(fld)
                err = max(nmax(J[c] - ref[c]) for c in range(3)); jt = max(nmax(r) for r in ref); bm = bmax_of(B)
                trunc = TOL3["cond_trunc"]*(G.dr**2 + G.dz**2 + (G.rc[G.g]*G.dphi)**2)*bm; fp = TOL3["fp_factor"]*EPS[dt]*bm/hmin_of(G)
                row = dict(mode=mode, dtype=dn(dt), A_over_eps=A/eps_sig, B_max=bm, J_true_max=jt, abs_err=err, rel_err=err/jt, trunc_bound=trunc, roundoff_bound=fp, bound=trunc + fp, ok=bool(err <= trunc + fp),
                           signal_lost=bool(err >= jt), err_over_A=err/A)
                if not row["ok"]: fails.append(f"cancellation {mode} {dn(dt)} A={A:g}: err {err:.3e} > bound {trunc + fp:.3e}")
                rows.append(row)
    res["sweep"] = rows
    res["information_loss"] = {f"{m}/{d}": next((r["A_over_eps"] for r in rows if r["mode"] == m and r["dtype"] == d and r["signal_lost"]), None) for m in ("annulus", "axis") for d in ("float64", "float32")}
    # refinement at fixed huge amplitude (FP64): the error is the TRUNCATION of the irrotational part, A*O(h^2): second order, round-off far below
    conv = []
    for mode, lv in (("annulus", ann_levels), ("axis", axis_levels)):
        errs = []; fl = []; rws = []
        for G in lv():
            fld = mix_field(1e6, eps_sig); B = G.sample(fld, F64); J = Ji(G.run(raw, B, F64), G); ref = G.ref(fld)
            e = max(reg_max(J[c] - ref[c], G, 0, mode) for c in range(3)); errs.append(e/1e6); fl.append(tol_alg(F64, bmax_of(B)/hmin_of(G))/1e6)
            rws.append(dict(h=max(G.dr, G.dz), grid=[G.nr, G.nphi, G.nz], err_over_A=e/1e6, rel_err_of_signal=e/max(nmax(r) for r in ref)))
        ok, o = order_pass(errs, fl); conv.append(dict(mode=mode, rows=rws, orders=o, ok=ok))
        if not ok: fails.append(f"cancellation refinement {mode} A=1e6: orders {['%.2f' % x for x in o]}")
    res["refinement"] = conv
    # exact scaling: the error of a pure A*grad(psi) field is linear in A (FP64, relative to its own value)
    sc = []
    G = C.Grid(24, 24, 12, r0=0.5, r1=1.5)
    base = None
    for A in (1.0, 1e3, 1e6):
        fld = C.Field(lambda r, p, z, A=A: A*GRAD1.Br(r, p, z), lambda r, p, z, A=A: A*GRAD1.Bp(r, p, z), lambda r, p, z, A=A: A*GRAD1.Bz(r, p, z), GRAD1.Jr, GRAD1.Jp, GRAD1.Jz, "A*grad psi")
        J = Ji(G.run(raw, G.sample(fld, F64), F64), G); e = max(nmax(j) for j in J)/A; base = base or e; sc.append(dict(A=A, err_over_A=e, ratio_to_A1=e/base))
        if abs(e/base - 1.0) > 1e-6: fails.append(f"truncation error of an irrotational field is not linear in A (A={A:g}: ratio {e/base:.8f})")
    res["linear_scaling"] = sc
    res["statement"] = ("A nearly curl-free field with a huge component amplitude A has a discrete current error of order A*h^2 (truncation) + eps*A/h (round-off). The sought current is eps_sig*J: it is lost "
                        "when the error reaches it (reported as information_loss). This is a property of any difference scheme, not a defect; the driver should keep irrotational background fields small relative to the signal (or refine); on these grids truncation, not precision, sets the loss threshold, so FP64 alone does not help.")
    res["verdict"] = "FAIL" if fails else "PASS"; res["fail_reasons"] = fails
    return res

# ============================================================================
# TEST 030  Adversarial algebraic regression
# ============================================================================
def alg_grids():
    gs = H.random_grids(n=14, seed=2030)
    extra = [dict(nr=8, nphi=12, nz=6, g=2, r0=0.5, dr=0.1, dz=0.1, dtype=F64), dict(nr=8, nphi=12, nz=6, g=3, r0=0.3, dr=0.1, dz=0.1, dtype=F32), dict(nr=9, nphi=8, nz=5, g=2, r0=0.0, dr=0.1, dz=0.1, dtype=F64),
             dict(nr=12, nphi=10, nz=7, g=1, r0=1.7, dr=0.07, dz=0.05, dtype=F64), dict(nr=11, nphi=6, nz=4, g=3, r0=0.0, dr=0.05, dz=0.2, dtype=F32), dict(nr=5, nphi=4, nz=3, g=2, r0=0.5, dr=0.1, dz=0.1, dtype=F64)]
    return gs + extra

def t030(be):
    res = dict(grids=[]); fails = []; raw = H.backend_for(be); host = C.HostBackend() if be.name != "host" else be; rng = np.random.default_rng(30)
    cover = {k: 0 for k in ("reference", "div_wide", "div_fv", "gauss", "stokes", "ibp", "curl_grad", "rotation", "linearity", "mirror", "analytic_vs_reference")}
    for sp in alg_grids():
        dt = sp["dtype"]; g = sp["g"]
        G = C.Grid(sp["nr"], sp["nphi"], sp["nz"], g=g, r0=sp["r0"], r1=sp["r0"] + sp["nr"]*sp["dr"], z0=0.0, z1=sp["nz"]*sp["dz"]); axis = sp["r0"] == 0.0
        row = dict(grid=[G.nr, G.nphi, G.nz], g=g, r_min=sp["r0"], mode="axis" if axis else "annulus", dtype=dn(dt), checks={})
        try:
            B0 = H.random_B(G, dt, rng)
            K.validate_inputs(*B0, *[np.zeros((G.nr + 2*g, G.nphi + 2*g, G.nz + 2*g), dt) for _ in range(3)], G.rf.astype(dt), G.rc.astype(dt), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, g)
        except K.CurlContractError as ex:
            row["rejected_by_validator"] = str(ex)[:90]; row["ok"] = True; res["grids"].append(row); continue
        B = per_fill(B0, G); J, gd = H.guarded_run(be, G, B, dt); row.update(gd); ck = row["checks"]
        Jf = Ji(J, G); ref = H.ref_any(G, [b.astype(F64) for b in B]); sc = max(max(nmax(r) for r in ref), 1e-300)
        tolr = H.TOL2["equiv_fp64"] if dt is F64 else C.fp32_bound(G, 1.0)/sc
        d = max(nmax(Jf[c] - ref[c]) for c in range(3))/sc; ck["reference"] = dict(rel_diff=d, tol=tolr, ok=bool(d <= tolr)); cover["reference"] += 1
        # manufactured analytic field vs the independent reference of the SAME operator
        fld = H.FIELD["SMOOTH"]; Ba = per_fill(G.sample(fld, dt), G); Ja = Ji(G.run(raw, Ba, dt), G); refa = H.ref_any(G, [b.astype(F64) for b in Ba]); sca = max(max(nmax(r) for r in refa), 1e-300)
        da = max(nmax(Ja[c] - refa[c]) for c in range(3))/sca; ck["analytic_vs_reference"] = dict(rel_diff=da, tol=tolr, ok=bool(da <= (H.TOL2["equiv_fp64"] if dt is F64 else C.fp32_bound(G, 1.0)/sca))); cover["analytic_vs_reference"] += 1
        if be.name == "cupy":
            Jh = Ji(G.run(host, B, dt), G); dh = max(nmax(Jf[c] - Jh[c]) for c in range(3))/sc; ck["gpu_vs_host"] = dict(rel_diff=dh, tol=tolr, ok=bool(dh <= tolr))
        # linearity
        a_, b_ = 1.7, -0.6; B2 = per_fill(H.random_B(G, dt, rng), G); J2 = Ji(G.run(raw, B2, dt), G); Bc = [(dt(a_)*x + dt(b_)*y).astype(dt) for x, y in zip(B, B2)]; Jc = Ji(G.run(raw, Bc, dt), G)
        el = max(nmax(c - (a_*x + b_*y)) for c, x, y in zip(Jc, Jf, J2)); bl = TOL3["lin_factor"]*EPS[dt]*(abs(a_)*bmax_of(B) + abs(b_)*bmax_of(B2))/hmin_of(G); ck["linearity"] = dict(err=el, bound=bl, ok=bool(el <= bl)); cover["linearity"] += 1
        # rotation / mirror covariance (every shift)
        w = 0.0
        for s_ in range(G.nphi): w = max(w, max(nmax(a - np.roll(b, s_, axis=1)) for a, b in zip(Ji(G.run(raw, rotate_B(B, G, s_), dt), G), Jf)))
        tolc = 0.0 if not axis else (max(TOL3["rot_axis_rel"]*sc, tol_alg(dt, bmax_of(B)/hmin_of(G))) if dt is F64 else C.fp32_bound(G, bmax_of(B), dt))
        ck["rotation"] = dict(max_abs_diff=w, tol=tolc, bitwise=bool(w == 0), ok=bool(w <= tolc)); cover["rotation"] += 1
        dm = max(nmax(a - b) for a, b in zip(Ji(G.run(raw, mirror_B(B, G), dt), G), mirror_J(J, G))); ck["mirror"] = dict(max_abs_diff=dm, tol=tolc, ok=bool(dm <= tolc)); cover["mirror"] += 1
        if not axis:
            if G.nr >= 3 and G.nz >= 3:
                dv = div_wide(J, G); pv = div_predicted(B, G); tol = tol_alg(dt, bmax_of(B)/hmin_of(G)**2)
                ck["div_wide"] = dict(err=nmax(dv - pv), tol=tol, ok=bool(nmax(dv - pv) <= tol)); cover["div_wide"] += 1
                fb = fv_box(J, G, False); pf = div_fv_predicted(B, G); ck["div_fv"] = dict(err=nmax(fb["div"] - pf), tol=tol, ok=bool(nmax(fb["div"] - pf) <= tol)); cover["div_fv"] += 1
                tg = tol_alg(dt, bmax_of(B)*(2*math.pi*(sp["r0"] + G.nr*sp["dr"])*G.nz*sp["dz"] + 1.0)/hmin_of(G)); ck["gauss"] = dict(diff=abs(fb["lhs"] - fb["rhs"]), tol=tg, ok=bool(abs(fb["lhs"] - fb["rhs"]) <= tg)); cover["gauss"] += 1
            if G.nr >= 3 and G.nphi >= 4 and G.nz >= 3:
                st = stokes_exact(B, J, G, stokes_blocks(G)); okst = True; wd = 0.0
                for r_ in st:
                    t_ = tol_alg(dt, bmax_of(B)*r_["area"]/hmin_of(G)); okst &= bool(r_["diff"] <= t_); wd = max(wd, r_["diff"]/t_)
                ck["stokes"] = dict(blocks=len(st), worst_diff_over_tol=wd, ok=bool(okst)); cover["stokes"] += 1
            bx = (0, G.nr - 1, 0, G.nz - 1); Sd = ibp_direct(B, B2, J, G.run(raw, B2, dt), G, bx); Sp, _p = ibp_predicted(B, B2, G, bx)
            ti = tol_alg(dt, bmax_of(B)*bmax_of(B2)*(2*math.pi*(sp["r0"] + G.nr*sp["dr"])*max(G.nz*sp["dz"], 1.0))/hmin_of(G)); ck["ibp"] = dict(diff=abs(Sd - Sp), tol=ti, ok=bool(abs(Sd - Sp) <= ti)); cover["ibp"] += 1
            if g >= 2:
                G3 = ext_grid(G); Psi = per_fill([rng.uniform(-1, 1, (G3.nr + 2*G3.g, G3.nphi + 2*G3.g, G3.nz + 2*G3.g))], G3)[0]; Bg = compat_grad(Psi, G, dt); Jg = Ji(G.run(raw, Bg, dt), G)
                Q = jz_residual_term(Bg, G)[:, :, g:g + G.nz]; tg2 = tol_alg(dt, finite_bmax(Bg)/hmin_of(G)); eg = max(nmax(Jg[0]), nmax(Jg[1]), nmax(Jg[2] - Q))
                ck["curl_grad"] = dict(err=eg, tol=tg2, finite=bool(all(np.isfinite(j).all() for j in Jg)), ok=bool(eg <= tg2)); cover["curl_grad"] += 1
        row["ok"] = bool(all(row[k] for k in ("canary_intact", "inputs_unchanged", "ghost_layers_untouched", "all_active_cells_written")) and all(v["ok"] for v in ck.values()))
        for k, v in ck.items():
            if not v["ok"]: fails.append(f"grid {row['grid']} g={g} {row['mode']} {dn(dt)}: check '{k}' failed: {({a: b for a, b in v.items() if a != 'ok'})}")
        for k in ("canary_intact", "inputs_unchanged", "ghost_layers_untouched", "all_active_cells_written"):
            if not row[k]: fails.append(f"grid {row['grid']} g={g} {row['mode']} {dn(dt)}: {k} = False")
        res["grids"].append(row)
    res["coverage"] = cover
    for k, v in cover.items():
        if v < 6: fails.append(f"coverage: identity '{k}' executed on only {v} grids (< 6)")
    if be.name == "host":
        asan = []
        for sp in alg_grids():
            r = C.asan_run(sp["nr"], sp["nphi"], sp["nz"], sp["g"], 2 if sp["r0"] == 0.0 else 0)
            asan.append(dict(grid=[sp["nr"], sp["nphi"], sp["nz"]], g=sp["g"], mode="axis" if sp["r0"] == 0.0 else "annulus", clean=bool(r["clean"]), error=r["error"]))
        res["host_addresssanitizer"] = asan
        for a in asan:
            if not a["clean"]: fails.append(f"AddressSanitizer {a['grid']} g={a['g']} {a['mode']}: {a['error']}")
        res["scope_note"] = "Host leg: g++-compiled copy of the CUDA source with guarded buffers + AddressSanitizer. It does NOT certify device memory safety; see the cupy leg."
    else:
        san = H.gpu_sanitizer2(); res["compute_sanitizer"] = san
        if san["status"] == "BLOCKED": res["block_reason"] = san["note"]
        else:
            for tool, r in san["runs"].items():
                if not r.get("clean"): fails.append(f"compute-sanitizer {tool} reported problems or did not complete")
    res["verdict"] = "FAIL" if fails else ("BLOCKED" if res.get("block_reason") else "PASS")
    res["fail_reasons"] = fails
    return res


# ============================================================================
# findings, development log, driver
# ============================================================================
FINDINGS = [
 dict(id="F1", title="No exact discrete div(curl) = 0", detail="Neither natural divergence is compatible with the kernel. Wide (2h) r-weighted divergence: div_w(C B) = D_z[-(1/(4 rc)) delta_r^2 Bphi_c]. "
      "Finite-volume divergence (face averages, rf weights): div_fv(C B) = -(1/(4 rc)) delta_r^2 [(1/rc) D_phi Bz_c]. Both verified to round-off, both O(dr^2), both vanish for fields whose respective radial profile is linear in the cell index."),
 dict(id="F2", title="curl(grad) is not zero in Jz", detail="C(grad_h psi) = (0, 0, -(1/(4 rc)) delta_r^2 Bphi_c) exactly; same term as F1. Incompatible staggering gives a first-order residual in every component."),
 dict(id="F3", title="Exact discrete Stokes and Gauss theorems", detail="Annulus mode: the block sum of curl x area equals the circulation of interface-averaged cell-centred B EXACTLY; the finite-volume divergence satisfies the discrete Gauss theorem exactly (also with the axis face flux = 0)."),
 dict(id="F4", title="Integration by parts needs an explicit mismatch term", detail="S = sum vol (A.CB - B.CA) = discrete boundary terms + (dr dphi dz/4) sum (Bz_c delta_r^2 Aphi_c - Az_c delta_r^2 Bphi_c). The mismatch is O(dr^2); no energy-conservation claim is made."),
 dict(id="F5", title="Axis-mode divergence is first order next to the axis", detail="The O(h^2) ring-0 stencil error is divided by h in any divergence, so max|div J| converges at first order and sits on the first ring beyond ring 0; at fixed physical radius r >= 0.25 it is second order."),
 dict(id="F6", title="Spurious grid-scale null modes", detail="Odd-even patterns (Bz alternating on z-faces, Br on r-faces, Bphi on phi-faces, Bz on phi-cells at constant radius) are annihilated exactly: the current is blind to them."),
 dict(id="F7", title="Cancellation limit", detail="For a nearly curl-free field of amplitude A the discrete current error is A*O(h^2) truncation (+ eps*A/h round-off). On the tested grids truncation dominates in BOTH precisions (identical errors in FP32 and FP64); the true current is lost once A*c*h^2 >~ |J|, and err/A falls at second order under refinement, so the information-loss threshold moves as h^-2. At every swept amplitude the declared round-off bound is far below the truncation bound (Test 029 tables), so precision is not what limits recovery of the signal here."),
]

DEV_LOG = [
 dict(phase="derivation", item="closed-form residual of div_w(C B)", observation="hand derivation checked numerically in a prototype before any criterion was written: 1.8e-14 against a signal of 4.1", resolution="adopted as the exact statement of Test 021"),
 dict(phase="derivation", item="integration-by-parts mismatch term", observation="prototype: |S - (boundary + mismatch)| = 2.8e-16, S = -3.2e-2", resolution="adopted as the exact statement of Test 027"),
 dict(phase="development run 1", item="finite-volume divergence", observation="Test 023 draft: div_fv(C B) was zero to round-off for M1 and SMOOTH but 1e-3 for M2 and ADV (the mirror image of the wide divergence)", resolution="second closed form derived and verified (1.6e-14): div_fv(C B) = -(1/4rc) delta_r^2[(1/rc) D_phi Bz_c]; added as an exact check"),
 dict(phase="development run 1", item="round-off floor of the order rule", observation="Tests 021/023 draft: fields whose divergence is exactly zero (e.g. M2 wide) showed NEGATIVE orders because round-off grows as eps*B/h^2 (1.7e-12 at 64 cells) and the floor was an absolute 1e-12", resolution="order rule now uses the per-level declared floor alg_factor*eps*Bmax/hmin^2 (harness defect, no kernel change)"),
 dict(phase="development run 1", item="axis-mode divergence", observation="draft required second order over all cells: orders 0.8-1.0 on every axis field; the maximum sat on the first ring beyond ring 0", resolution="analysed: the ring-0 stencil error O(h^2)/h; at fixed ring index it stays O(h) (error ~ h^2/r_c), at fixed physical radius it is O(h^2). Declared: first order over all cells + second order in the physical region 0.25 <= r <= 0.9. Recorded as finding F5, not as a kernel defect"),
 dict(phase="development run 1", item="annulus pre-asymptotic orders (M2, ADV)", observation="last-pair orders 1.61 / 1.75 on an 8x12x6 base: the maximum was attained in the innermost cell, which moves toward the annulus edge r = 0.5 under refinement where the 1/r derivatives are largest; nphi = 12 under-resolved the m = 3 content of M2", resolution="declared base 12x24x8 and a fixed physical interior region 0.6 <= r <= 1.4 (all measured orders 1.84-2.0)"),
 dict(phase="development run 1", item="Stokes block extents", observation="axis phi-surface orders 0.24, 1.46, 1.77: the z-extent of the block (cells 1..nz-2) shifted with refinement", resolution="block extents fixed in physical coordinates (cells nz/6 .. nz-nz/6-1)"),
 dict(phase="development run 1", item="rotation covariance of analytic fields", observation="annulus FP64 differences 4e-16..5e-15 for the Fourier fields (random fields were bitwise identical)", resolution="analytic samples are periodic only to ~1 ulp (cos(phi+2pi) != cos phi); exact periodic ghosts are now imposed on the reference field too, after which every annulus case is bitwise identical"),
 dict(phase="development run 1", item="axis covariance tolerance", observation="field B=(Re,Im) w^1 has J = 0 exactly; its discrete J is round-off noise (1e-15) and a purely relative tolerance rejected it", resolution="tolerance = max(relative, alg_factor*eps*Bmax/hmin)"),
 dict(phase="development run 1", item="superposition sensitivity rule", observation="FP32 on a very fine near-axis grid (r_max = 0.1, h = 2e-3): the declared round-off bound 128*eps*B/h exceeds 3% of |J|, so a 3% perturbation cannot be detected", resolution="a case is labelled discriminating only if the bound <= half the test perturbation x |J| (FP64: 1e-6, FP32: 0.1); non-discriminating cases still have to satisfy the bound and are counted in the report"),
 dict(phase="development run 1", item="integration-by-parts sensitivity measure", observation="a small FP32 sub-box had |S| < 10 tol by chance (S can cancel)", resolution="sensitivity is measured on the largest individual term of the identity (and on the mismatch term in FP64), not on S"),
 dict(phase="development run 1", item="curl(grad) construction", observation="NaN-filled unreachable faces polluted the axis-mode Jz: the cubic phi interpolation at a neighbouring cell reads the outermost phi face (g = 2), which exists in the driver's ghost array", resolution="the potential is sampled on a grid with one more ghost layer so every face is defined; the 'kernel never reads outside' claim is carried by the sanitizer legs (Tests 020/030), not by NaN poisoning"),
 dict(phase="development run 1", item="g = 3 grid with an inner ghost ring at r = 0", observation="Test 028 exact rows: division by zero in a ghost ring (annulus r0 = 0.5, g = 3, dr = 0.2)", resolution="exact rows use r0 = 1.0"),
]

def _self_sha():
    for p in (globals().get("__file__"), sys.argv[0] if sys.argv else None, os.path.join(HERE, "campaign03.py"), os.path.join(os.getcwd(), "campaign03.py")):
        try:
            if p and os.path.isfile(p) and p.endswith(".py"): return hashlib.sha256(open(p, "rb").read()).hexdigest()
        except Exception: pass
    return "UNKNOWN (this harness file could not be located on disk; run it as `python campaign03.py`)"

def load_report_module():
    path = os.path.join(HERE, "make_report_campaign03.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location("make_report_mod03", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
    import base64, zlib, types
    if not _EMBEDDED_REPORT.strip(): return None
    mod = types.ModuleType("make_report_mod03")
    exec(zlib.decompress(base64.b64decode("".join(_EMBEDDED_REPORT.split()))).decode(), mod.__dict__)
    return mod

class Tee:
    def __init__(self, path, stream): self.f = open(path, "w", encoding="utf-8"); self.s = stream
    def write(self, x): self.s.write(x); self.f.write(x); return len(x)
    def flush(self): self.s.flush(); self.f.flush()
    def isatty(self): return False
    def close(self): self.f.close()

TESTS3 = [("021", "Discrete divergence of curl", t021), ("022", "Cylindrical Stokes theorem", t022), ("023", "Current conservation", t023), ("024", "Linear superposition", t024),
          ("025", "Constant-field nullspace", t025), ("026", "Cylindrical symmetry covariance", t026), ("027", "Magnetic-energy/current consistency", t027),
          ("028", "Discrete vector identities", t028), ("029", "Extreme cancellation and conditioning", t029), ("030", "Adversarial algebraic regression", t030)]

def main():
    logpath = os.path.join(OUT, "campaign03_execution.log"); tee = Tee(logpath, sys.stdout); old = sys.stdout, sys.stderr; sys.stdout = tee; sys.stderr = Tee(logpath + ".err", old[1])
    try:
        return _main()
    finally:
        sys.stdout, sys.stderr = old; tee.close()

def _main():
    sha = C.SRC_SHA; ver = getattr(K, "VERSION", "?")
    print(f"Kernel file used: {os.path.basename(C.KPATH)} (v{ver})")
    print("=" * 78); print(f"ALADIN v4.0 - Campaign 03 | {C.STEM}.py v{ver} sha256 {sha[:16]}..."); print("=" * 78)
    frozen = bool(EXPECTED_SHA) and (sha == EXPECTED_SHA)
    if not frozen:
        print(f"!! WARNING: kernel sha256 {sha} (v{ver}) matches no registered version ({', '.join(f'v{k}' for k in KNOWN_SHA)}).\n   Campaign 03 certifies ONLY registered, frozen files; results below are for an UNREGISTERED source.")
    latest = max(KNOWN_SHA, key=lambda v: tuple(int(x) for x in v.split(".")))
    shas = dict(kernel=sha, campaign01=hashlib.sha256(open(C.__file__, "rb").read()).hexdigest(), campaign02=hashlib.sha256(open(H.__file__, "rb").read()).hexdigest(), campaign03=_self_sha())
    print("Package check: uct_curl.py v%s sha %s | campaign01.py sha %s | campaign02.py sha %s | campaign03.py sha %s" % (ver, sha[:12], shas["campaign01"][:12], shas["campaign02"][:12], shas["campaign03"][:12]))
    if ver != latest:
        print("!" * 78 + f"\n!! STALE PACKAGE: this run uses uct_curl.py v{ver} but the latest registered kernel is v{latest}.\n!! Delete the old files in this folder (rm -f *.py), unzip the newest zip again, and re-run.\n" + "!" * 78)
    host = C.HostBackend(); gpu_present = C.CupyBackend.available(); backends = [host] + ([C.CupyBackend()] if gpu_present else [])
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
               gxx=subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0], kernel_file=C.KPATH, kernel_sha256=sha, expected_sha256=EXPECTED_SHA,
               latest_registered_version=latest, source_frozen_and_matches=frozen, kernel_version=ver, campaign_harness_sha256=shas["campaign03"], campaign01_helper_sha256=shas["campaign01"],
               campaign02_helper_sha256=shas["campaign02"], gpu_present=gpu_present, gpu_leg_status="executed" if gpu_present else "BLOCKED: no GPU/CuPy in this session")
    if gpu_present:
        try:
            import cupy as cp
            props = cp.cuda.runtime.getDeviceProperties(0)
            env.update(gpu=props["name"].decode(), cupy=cp.__version__, cuda_runtime=cp.cuda.runtime.runtimeGetVersion(), compute_capability=f"{props['major']}.{props['minor']}")
        except Exception: pass
        print(f"GPU detected: {env.get('gpu', '?')}  CuPy {env.get('cupy', '?')}")
    else: print("No GPU/CuPy detected: GPU legs will be BLOCKED.")
    results = dict(env=env, tolerances=TOL3, campaign02_tolerances=H.TOL2, campaign01_tolerances=C.TOL, findings=FINDINGS, dev_log=DEV_LOG, tests={})
    print("\n-- Campaign 03 tests --", flush=True)
    for tid, name, fn in TESTS3:
        entry = dict(name=name)
        for be in backends: entry[be.name] = H.safe(fn, be)
        if "cupy" not in entry: entry["cupy"] = dict(verdict="BLOCKED", note="no GPU/CuPy in this session")
        results["tests"][tid] = entry
        print(f"{tid} {name:38s} host={entry['host']['verdict']:8s} gpu={entry['cupy']['verdict']}", flush=True)
        for be_ in ("host", "cupy"):
            for fr in entry[be_].get("fail_reasons", [])[:6]: print(f"      [{be_}] {fr}")
            if entry[be_].get("verdict") == "ERROR": print(entry[be_].get("error"))
    if gpu_present:
        try:
            results["gpu_vs_host"] = H.gpu_only_cross_check(host, backends[1])
            print("\n-- GPU vs host agreement --")
            for q in results["gpu_vs_host"]: print(f"  {q['grid']} r_min={q['r_min']} {q['dtype']}: max diff {q['max_abs_diff']:.3e} (tol {q['tol']:.3e}) -> {'OK' if q['ok'] else 'MISMATCH'}")
        except Exception:
            results["gpu_vs_host_error"] = traceback.format_exc()[-1800:]; print(results["gpu_vs_host_error"])
    allpass = all(results["tests"][t]["host"]["verdict"] == "PASS" and results["tests"][t]["cupy"]["verdict"] == "PASS" for t in results["tests"])
    results["certification"] = dict(rule="10/10 documented PASS on both backends, all claimed identities independently justified; otherwise NOT CERTIFIED", all_pass_both_backends=bool(allpass),
                                    verdict="CERTIFIED (harness verdict; independent source-level review pending)" if allpass and frozen else "NOT CERTIFIED")
    json.dump(results, open(os.path.join(OUT, "campaign03_results.json"), "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print("\nresults written:", os.path.join(OUT, "campaign03_results.json"))
    rep = load_report_module()
    if rep is None: print("report builder unavailable (results JSON is complete).")
    else:
        text = rep.build_report(results, OUT, "CAMPAIGN03_REPORT.md")
        print("report written:", os.path.join(OUT, "CAMPAIGN03_REPORT.md")); print("\n" + "=" * 78 + "\nCAMPAIGN 03 REPORT\n" + "=" * 78)
        C.show_markdown(text)
        try:
            from IPython import get_ipython
            if get_ipython() is not None:
                from IPython.display import display, Image
                for pth in getattr(rep, "PLOT_FILES", []): display(Image(filename=pth))
        except Exception: pass
    print("execution log written:", os.path.join(OUT, "campaign03_execution.log"))
    return results

_EMBEDDED_REPORT = """
eNrlfWt32ziS9vf8CrzqD6bcknyLk7Q97nNkt9MTbzrJcdy7e47jYWiJkriWSDVJ+RZnf/s+VQWAAEXZ7p7Z/fLO6YlFEgQKhapC
3VD8QXXXu2qQDZN0vKcW5aj7hu68aLVap/E8y0t1uUimwzhXoyxX/ff9X959UNcve5vqKJrNo2Scqs0dFZRxURZqc3uru7mz2e4p
dZSlZR4Nyj15P8y5s+C0oyZxHndUGs3itur+rGZRfjXMblJVxrelCqJpkambPCnLGLcybr3BjXsvTtWByuNiMcVQw2RQ2naXd2qg
odnc6c3vVFBdhvqN3n8VWUqQHV/H+Z1KF7NLTCrBIJNYCXRAwywu1CjPZup0X6VZOQFWVFKo8m4eD6kxRppE6fBFQG/N86yIFXCT
XEdlkqWFivJYFWVUxrM4BZDZSCVD/ErKJC46Ko4GE7p3M0nwA90OJvHgCh0DGHQyiKbTOxqB+iaEMpLwlBADVCRlu4dleZHMGNgM
Pc6icvLixTAeqVFw21Hzg5323guF/yUjdUsjfMjSeA/TKxd5qlrpRtTix2V+J+1026RIUsCdDmLq5jLLpm37VlHmwW17dWs8rxrf
uu0Iul5SpFGKDhwoorTV0CxJR14zXLdkHj+rTRVPgepWl266796qgwO1Wb20WT3Vt0atb7d7vW/z7/F37i6ILguMo/6mtuLujgJR
6xs/H+DObltGMm/9uPV9/F36jG8H8bxUx/wHq71XH0kjipcjo6ksrQSNFvjYG02zqGwr0JQKPHy12w3rtoR85/UVaIxvwYXytoeR
7RHmJbBOk6IMbgsNsHmxo1q9/8qSNKC5MPffEgegHc+p0EvCsEk/fwRxnoMqsxw8UTBwWa57BeFml0WcX4Og5bmag//yeJSkzC0K
/Jrvq4j/gkWItcqbTKHLLBfOugRDqqjcuIyn2Q1zyTAeTPFkqPJskQ672Wgkg6pikt0Uao0v1rDmqQxK3JdmCbrGisziKAV/T+Oi
gHAhILn5nirAiVFOiwUQu9P4Op4qwhFzn7SDJJKB/BXhex0VUOuOKhfzadzWFHXOzy7UuprGKSOqbZYUfB/E6m8H6g9GM6TjH4Tp
+2SuETqautQQlUvTDdJMTxD4SCA02gJotigB6fmFQI2GVx1ZxZhFDgRVIIvRrqgZ7/Si+TxOh0GLexe2IUjOry4IzNGUfhDNyU31
o9qyD/hCz5kop72CqBalZhUI3XnIUBBBDzQk1DOBnp+38ngMdgu5HW63Ls4HFzwZFt+3aIC1bl1c+OgkuSDo5PkSvmtMAWG76TGG
JeDzuRlirocQLIUCCsbqMGSCnkZg9OTKy2kwiaNhR9F9M7digKlNo9nlMFKDPRYcg3YPm9A0AhG1HghNX748tNruIrYeVAvIbakH
g0P0g/d49AGNTgO1pQn18MDNH3TjVrfbbXHb0Gv70Kqog+dAgO55VPDkwLkZ1V/sL+nSYl8HoO7L2Bc1cW8cl8Elnnz73ubfLezR
tMPTNEjA4O1Pv59++vj5GJj49gJyfnurtadav8QDbLBYMeJAzIj4OyqKxQx83YEQiSEkcugK18FgkU/VYVsRVUyy6bBg6LHBF7Rh
j8fYf9NxT/WZHLGbXybTpLwDkUfTu4IasUABm+1055gSWDAaJtGU+o7zcQzmhwqSon2aTJIpGIvl01Wcp/F0DTs9ht/nW8f/2T86
IzUmGS7wPrpmBULUi8EUYm9IoM2Yv4yCgN3fsnyHn1BXH4PJP7bbqkjuY5q4KDJVv5BvxYKEI1SKSs72Wh3G3zbh74gmi3f43UGS
DxZT1mRMd5honI9AlN0I04zG6GwQT6fdATqinkdJPB1CNhNsGiMA7z6ZLcoJgCBAo1tC0+U0G1xBgKNdlEMZUjcJZHmFIkaQKhPS
v2gEkveRwkKSApRhbG7LveyhW8UMDOQXA9BQrD6X2ZXMIsvjmQosstpQiqYLmR/IOc9ukxktjlXS1JoGYDRdQJmQBS+TgYuNNYHW
4nOQpWbRDTZ3CJu/Roui2DBAddGMNjxBKOlzewzGdTaF7GXUjnOgRqMa65PgJf3UISs8P1HxH1hUmUYalwaRdwK1kWZaeTaYBeZB
5Vg8ICEC6abdIsPekyVDjDog/Tybkg57bdafiI2peBQl04rMhCi7TJSPQckbslkRXk+MjwYJqGRoEPWSyS6IDrcgMi4Pt4kjo6Pg
cItEyCV+4A7QlWPwbAblcpZh0++oqyS9YoDSOMq7MjOivYK45u2nne2Nt59evVTROCJJgOk2aAaMtI7gR+inWFx2B1GB+Qf3cZ5J
l7BN4jEvGmgnu4EGkI26pImQWgAhIdpWRLoBpNelLG8RpwW0/GuSGeNFlNv57gqbsYJQGpjHwJtdNR4Z6MpBjftqkSaM6KMoB8kk
LFKGjM3uKI9jaHnpAmtaLiz76e4iBRKBqUHI7hgSJfOlzBfpQKBkXaqnzrBQ4zwZdmlGIKgF+G2WDQkN2XDYhb6TQguDZZWnmjIE
OqINGEWYLEw3UsjQbTTNxguAEhWE9GywIKbC9TSZJSWPajDxijBxmtFNQCUESQt5Bx4vYf1oYQJhBeUPYFVihAQCxNmiIMWHGBcM
IXaVmEzBZVLesFLHAnhBDE/zAd1Pk6uYH80nSXeW0PwZoffdYpKMMBUZ/W5fuIXekoGiMWHblbtmHq954zF0rtmY0QvQIU1Ls7Vo
JsjmpGixXrmYBeAcFfR7IHRYv+oQP/pQ9cEElnMsbwP/swJcweJuPk0GSQmRP8xJ5gvKMKMC4gzGJLXtWGbz4cZ6Y2r4Dx1pc/TO
8OvR76fv1cdPx6f9s4+nMO8/fjgmwxf6IajnzhdhrFryxhINreB7Q9igeQbAAjQKK33MPjp1hAI1SQDA3tJeRa0X5fImGMxB6Fhi
3kU6ZvrtfcWbcLeAmT9FW9NxYWUz7ATQKa60ucGrnqQWqjuz7ePtIchYNuIyHpSGmEdJXpRdedmAamb9E836A0QR+ql4U7MjowDC
h4AAeEm5GMIGh5UJoVnGG5gPICABQNTYcaSXK0QIXMc4uown0XWSLXItvyKXrX90hBx3ynSst1+HeGAaAqf8Thc4Jt7GxEgb0vPa
2WQeZdmb0BpEN1c3EGYsLSAdiEc2NId11Bg2GnwwybCcFGqru+NMRdNBzK6WaDqOL/OI9lTeYfK4C9hJypNDhHS3YUyKJs0TU8aS
0IbCDEhz75DYAT9syHjCcECRbFD94RBzKD7DlCuhB+XULREXtw00WYFOao9//fQ77LBxmyb+/cWn9x/Pwrfv3h9/FmuJVdVZdBWH
82lWFsZrpbXWqnVvMAUNBO0Gn4r4aIBs6mGaXO47v3uLAlp+fzxugZCXWsJ/Rb+ICOfT8nmuB23hDQF+VvTm5AlgxVt8bS3HG8YT
onHRjmY4BJUH2DBiLG0ZZlcHZ/kilgmdka4NdSs+bxE2tZ0DC5IF7el5i51+rYseNIJZEbBbQFqyxfVdQAImJ0WYjYK0sr/ON3tb
27tqQ22r9XV1Jf2yIRGl4xgtL+y7o2QckBsM1nRSTvEH8oidacUUgvVgu7fZUXfTCC6Bg9YsuhX6h9mAfSo+IJ+LY9nKq3pWt549
LI/cmdwyeZGtfnu+CYMW9qRckHXLnMVm5s+ulVk9BCi66c/kZ/rpO4b/wQAA0cTyr2bED6KcHJOZq1+6POv6vWQbpt4MUu1TEE0P
WIPcDPCHjIOD4FXvVUe97O2S5GS5BiQQcuxLNAVgEa6LCTkqycdTR0qFRzMKtn78p98AmWVdIH56c7DVewnXZHGAf2Vl8K8zsPwl
r4Uey3Y8wWLGm6YJ0I7/Ovpiiy721WRCLAr7LqD/y9JY35QG+DqaLmJA3O7wOshaPNrw4kXTvCCbzgHOOgAFrU4220StTHfc04Tt
6AkgbF11zdTNlEctafiN/+zBidj2xrjlZkFrQkIqyou4SzJWFfNowLYr9B6yCclHxg6oNvEsvSjEHsgffY9ZI9AMMoJmz6u+takf
U88B8XVHXM8HLfKkAeBoOp9EB70dHzTIRTL7bT+v2zXKw26miYx89sFmbxPTxr+bu8J3DgyvnK7rwmmoowBmDuNJGU6jOzgLAn2v
gNVJAmDeUcN5crC1Y2bEKgK1cmSx9lbMG6QxuVvOztlpcHHectirVS08jdMq0SSEVRPqTa43T8fkg8DtPaIl9UAPb4w34YE8i3o3
FNcQ0PDqbwf534gH2njzGzxCrBZg4L3t7Ys9InqShi9BnHiGPkNoBjymcS45dDpgSYRm2M8hfyGDWnrA1veO2gZkFVDq5MGhsdp0
IN29uVhtt1M3NYkqjMp9XZhpsWcIYnt7t7PZ++mCZra+7k1u6+UFO4HwduuxWeJ5yL0/OVGASLNcMY7G1r8AoTwOBtpy0Okj09LP
9tP0sx0W7Iyo0L29px5cJ0O30cng0tJvW4Z2spzU2hbRDTkcJ83ORvFGsm+00Rf5LILifavCdA/6MWwZ0uOC1m9brbYmOCBXK5mg
FnHr0KyasLXzNLZ2wtE10F0ha8fhsxEtA3k1ND2uYKgnEePQxD+DoDrHjVZRye7T894NyeomaR9Xc9/dc4yJDesKELMCsjujfZNU
Wuzc0JUDoW+DFYH4fG+H+WOPfbZ/Flm0VTZ53NvPwZrZa5/bgdWNHLyegDtOQnaNNKL2zWrUYk8n1e67p9MIdL7qMkOzJXwZdM2L
hG7uXnivoO/zGTfz7E4ikJr84ef6sRZAIWaG2e47vbz7cPTxt0/9s3eH748bOnHs1NjvxINK4/yWMNLcXGN4zxm6atow8JPDGvp9
ExKlktldke8byDnrCVBAZPthz3UDYDfxrfbrwrXIY8cR32I936WLh4rcG8jiJyKLylxuYLifQscFbkEGZkSWbcDzD23cj0gGaaOF
7zPcMyVzSE7ssP+0/PG4IZwQPzwQeM60ixtv3sVNHM9bF/tPaP4eX7CjC8MFVrp19E5Y0/Op8bCUphxsfvWSmvLPne16azZJKVBC
kbtqpgAYtJq7UpUBYCfHeWtI6RVye1heLHXoqOSEzL6gMp4XLjJpVEeCkbhnwdPhMP9me6klWSsEFSZHQt7MTUe1C1boXRsGUXOC
+bv6NixXKfOVbLaOH1o4T3H3V7blafAuRYI5qk5MOCZn/ye4gEIq0eBqzDZk668p/ftPaftNGrvwkoWMWel/R4OvOz3IIRLfVvS2
/OKoFbDnhBG4p77Ft9/bfkiSMx2qF3VQcnWG0kHrqA85/e7XD3CdnB5/+nh61psNDdXH6XVHncE/hUgAUAWPCO4QyVW+Ef5Nz+GX
FW8dMerZe2lews+dU+JAoSUWe2fwrMH3tK/es3NqH5LqQL3Xc+a3+kHrBy81q+slZ+nkpuDMy9HSiMG76+vWm2181V7aku8EroVH
h657Dw2BYOzL7F/+uhiUvE3Ao/V1fR3RYDPkCGP+PYJGXHCAiCK9WC5C0/mavl67+A5jW31Jj1zkqXwxhfW5rtvSFTVEVlc1HePt
Zi+gDIIALGWY6a73PY9jAacq4puS5eGtFPajBKpnjthbQjFSaCXwOXDwgp2zCJ0NFwMOsVD8Ls/uY8KPlmt66J4z7dbP6vOAvAFe
4FNclAXsnBMsLG+gh23MPZgtyBWCwBilt7lR15z82kgaAH4pvqLelTTf9XXY3niP+n4bYQuO7pS0Q0wM8Tv8TQumhMUcHu/YSXBL
JRCuCYUiBU6ANLqkBISjM7YUKWwxBzIsPZDri2MFHpl4s/7hB7XVU58Zzx1imiTPUvHsaqRNomICHjBvUNIElCCMT1sNO2mIk87P
W8aMSqakIGM9C+KoDqU0GUF1iXgesW6Agc51cDekF9Yu2t/V9Tf3tu4AJMT9m+4//73f3d59xf1+9V4oJhEeoP1XvGAlkei7IHxa
HP1ylV7gQql7g0eeAw1+f+hHiNGgRWd1wWsudjiW8q7FGDQtQ2kJd8Uw1C1J6XAg8/MiDXCBps62C5VpGuqHS9DZvrb8vuIpxEZj
V5tboTxdiTnbcvvZfW439om+fj87MuhZlAPRvlrzu3ICOt2gJMv5ndAK9ycP8DaeyR1uIcTgQIiknJLsMNO1vZb+xz/+aJ6Mb2/1
TYQX5KZks4znC85kgW7QanODo8WnO4x79Psvfci0lBIfcKllATzB80gkrIWXO1obLABgR60hJ2atbQA3j4ZRqLta1US6D6vuq4b+
nHV4xE5svghxGZJQWBCFXbQtd39Jwd/bPfWLCbgPEJyBEh8pKKG3lH0SA1sU7o4Hi9JR4A2fE7NWfE6qr+Tl8Zo6MGGfCSnyze79
UXD23rt1AQNG0rq6NsZpt1fKMbBNoWdDdwxY6WzjIuBQHSxriqFykJ8Cx1Xm3w1tvyxVJVw+ZgUXysjWxoTEH/78Y9tHHwcNQ2wW
FtLqDgNK+8hsMVN+SiTLDAladp1svoJALMp6riR5t01GCgW+laB7PkG+EgA1DrIlOZWlxrsJ4jA3SPNnUgOwa34rzSHuA7QmNsFE
qtEQgF1Q7BOxQ6BnoSO4yp9HShFBlcumg70Yzn8fQOqafXfLKGx4xLik+102J+pJMxC+WQr7zQQcOAGUAOi/f689nAFyGdTb3RoU
nv2th4MdbCBZ8ZiheSzEzIkFlEiGxbLBb2Q48Jb74eOZH7AOJBzNHONB54SJPQTV7wtLcAhW0l04p9wFooA4BQiU+bwJ6xPaoWUZ
BAgpd07SKmzmB0fykdmRUhIGbU+UKVT44I3mhtE2oG+nDs+2vjGga7YFb8mgLbldNab7RF0UT5Z8CAnGJWSQE2fLPWlcG56cQyEp
AS1OTWfMVPcYJxJwofhwCh9DitQQ/HvfJqIRdL3UrO/6AiYmJMNZ/DomsyQId3rqN2ghMUXsiC1GOaQbHHcURqU16LhZaBwtMRm7
lb7UF74TmmZ1OiFK9RPvIgqRS05eoQ7DAbwGE8VPOSlxpMPohfqlIzo71p8T+W5iMtPiYZXAaNqSFDm5b+9VkHz9+vVLepLjAo6i
rY0cOZ+/hEDX+eF9iATZLq7uzw9xA1doiB9oyPdy8zyXtnh673bzDf6BUfgtQX694g5GAX5TSgxuJ/ZW+2JjmHM/PCr3+v1LCrgq
IP8O0uiaHEpWQv9YyNQDXipWjW1mjHPUArqye9iCTnfgxMpVXBakGqecI87JpEindpCCHPB1i1KwAks9rNQyPg9UF9NFMgSSMUps
zv/YVodkzdEzaPv3aHByH/LLXUJM8FIBN15zxi0ZAzDbEGPbfoNM9XW8zFmk+j7i6tQHQlDV4jqi8KuErI4k+5VWh8FaNZi6+NpD
bPiJPNcC9F2M7iQln1B4eN9lHqVOur6RSDIt4fMx+zozKB7BxqLAhhpHc868yTU8ciiAUnHr08TJltXZh4GXowpMjCwqXPv1GtkA
go/RtUFIMy7OPXpXRMOMGDG1vNQ96AdpQ2s0E3nFPqcqm5KX2wGdjFUIXp2bBrkwjpfm/obAPmK/KvxG5FklTkKwHP89tpbtr/vq
RFKfmDmvoVgVEzd3bn8pE8tNuOI3dc7VElDbAKqWgCuGbUGKzchL7L11knp5B4506MjJa21IP3734ez49G3/6Ljb/3ekqP16/Msj
6cc2Qdhm0HXE6fdIWrKE1+TwViPF2Qlybu+eSd7VUzRRIKzGclZuYPNvTW7x5jISX9PKUtYR9diYG0hn3rq25x+RubiUIIgFgncN
6zu8J2mDrs6FBit66Atvd1Xfv295HmlYvbhXTz7k3OnG/EOdeCgT6n/6dPrxP9/91j87pmk58RnZ4maQw+AF5hdMmAJ6eoXhXLiu
6K/QKjaUa8lt31du4JRcog2R032dZzlalRS4L34QZMdumJhalT0nMyDt6+h9/91vx7+sr1OGudGZrDFBKrZNEUUCwCWAqJJ0T+5x
7ClFohnaD1mAdTft3t3e81J6SCftqeMGr4nx22zghAC0BMowpjQV1V9KeAcMp5NoxvvQNAaxcfI1KZms2mGlhllcMPI5s6vptAOo
EZuZ66Z5CTcNUu6x/sZtqn351RGRUqd/ndm0IG5kXLDn9FzbdLDf+LiH5IS1zRXZsLCCfSOQdmA2kbUxyK/gLxnSF/rwjLwB94Sw
S7BVJV6d2VQecum7o7Jz/1P/82fyUqfh+HnvCozOu9Zx+SX9e0aZ/MhKACTfN7Y2FbVYJx8kgNUPxs4DFYh3wTeiYT/RYdQ+pNkc
SgblJfJeSl59ILLgjsTLSRkT1CakBqFpwA7Sys9GuXc0wnUR2hS808pZzuv7A6c9gos4OdImWBJmzDpQ1IDwbkwvHZvRASmK/ZN+
Q9ewFOhPdiWuuT/0u7jAT22e8W8d3SEr5Q83Fo9uSBvnu9QZXeAndShxnT90mqE7Latwx1OdBWcdFOyW5FwJd9Y/A4/am7GnDt9/
PPo3bCLG4Wl9EnyADs02yC/T7mHRPukjJ4Ml97PcNv51bbkdHZ+evXv7Dn2TB2Yq0RqzzRpfMDXWma9kAOIBhiRly54zRrYfghfa
dDZ5qnwe2ea0muPMNQ/rbo9A7rIma85IB/wCZr7v5rwSCEUNQOu1JgHBEoDTfzlTjk1Q9dK4bZqFQJXCBwazCaP7zDJEeBR7UN/K
79iBvsXwtIHNya+gzhnEb8R1a/STXFYPDKncY4dX+/uFE3Dj8MGnRT5HAKm3rr7pg2Hs4gJga2hucaM5Y+IfKhPGPj49/XiKPAlj
51ACABmMurFJJIWEbJ93t3Y3N9UeZwq45odByIi1PP0m2cSIJkU4b05OlfOL9p4Ard72371HoGOUf/fhkxAkn2nzop+DCNicVGF5
1qdDcybN4Hd9/ajxzBqR8UdStr4NIqA8JJnP3hz+0aiKywEsqBNTylOllC/Y5vQ22Dkc5iE/D/mtEO3JTu8o0wSc3dzkApaY9ngL
LOaKhKDojNoOgNlFOgIs94wSYbXtYUwRR2uuztkV9VNkPW/1bYzr2NvOgZplu4itNVLj6/rRxVc30Y/T43VWDhmG+yqXZeI9OjRD
hBLcr0EiYtZKVSNvgTzKKXowvyHMiFQpL4yPclJKWlfV7moRLF6cjZpAvnUk720lnEfBbS0hql27WQ1SPaMEhuvmR0Z084XjguKb
t6485/yG/KK9tDhfUr0807sum1T2XBbtnpWkAm0X0R1tQdd8jpMtL7ZfyNRzMqPEzon16hikD8Qp5G1pFunL2OPmgjxnC1uFPYOG
5RlbwqCphZgaz6zayWqI6Ff+oT3vaKfmDZcL6hkrhC7j213OR9VnnKr0Tglj6mbbu9wO2Z3W2VGnWs7eoOQPTikjbMlBfj9Dz96t
0tNapHNDWzd+SOd0Ug3pkiDS8RLXdl7iBs5mr04k7ThHtOu3eSQMFOrD2u2mvqyvvOGs96peglu9UfDi6hmGfLY4LLPQvNFqP5Jy
aUsosALCPbGioH2CntHRbq0iLy8frk5W0a0IJ3afUz+hCLBQ43dfq7X9KiPYlXBVOuYDZdeNYNWKqNeoky1gGF8noiFZZcXQoVl6
51W0psDlzEQYDPKor576Rs0ojRy7Aywi2l31uSquCeG7TvRRipV1IPBcXLri0GVnX8S5Znyem645Lcc7QK6LRazYSN5S5AIOKjAb
qQxArY2Vt7SC4LzGeqrZ37dr+3vh7huFtrzsrn7cdMaZWNz3rCydlDa+FSj6NZ9Kw3FuyWiDUlIA6aQc6POwO55vBMPIEbBb57ja
rXLPg0HQSoLqA6n2D7QdCcGgY37AKr/kbuEZrTUyImdgV1INEVQriq4Drvc+aR/cwnsdWgUvLUFMKQRVQGMU5dqz4MU02itW1BO5
GrlVZvMqtwOthBZ1kk1izpZprxQHciwKsXvj2R0fm71ByIcDYRSg0hFAqnzCExEqlxwwIfCKpn1q1i4b79i1nAevnGoWcH4AwWtc
MdjKB0nBh5zJU0k8QD4T6F0OJxCTkGXCJVP+zLbASet2K3iOjN80slfy3VlIP5rU7ohqneW3tf2XBKSIv3dOSpBBmkuPMISmo64c
YAyA3yHypOApZSarzqu2RVzCg8p2MpHvBAa87i+0pxtD7oiihrjHxNxrNWgDh0yEZbYYTEyaEW8H4lqkRceMq3TBBiI1AnKEdBGh
mmLVMtrl0xV39LkkIhrSL9reepq11AvYcSq7jIK47R6Jo/4KZ9+Vy8bl81dNB3yLAWfIPipYd2qC1dH4fQ+uKRGxt77uqoaGhK1q
2OznZQ9V3dHL7zU7RXxi97VIGSE0ZSB8bdIMEPIA9rbjNHlK5RzTbOu2yAqV80jXgghqNSJ4cfed2hAcO74kr+1U6AKWbnsFKmtl
LujWEtpYpuvMGCnAQCXjJFmqCYl/GXEykL3Uw4V2uJVoRMsKIaEumrESkUJx7vn1ZxT3WCqbYWxTP0blG6bnSwGni6+esfP/r4WJ
VRtdh7IIrFk+SfzuamjEn3AGZuQslRwAsDL2hKtucNEL65OvltUkdegKPSQMnZDhPpKu4nKDiXLNpKoayu3yTj0gfWUqMvx/wR4T
Tc0C8SeMsGedp3LNqCVTjQ6k/AUjTL82MkeMALxog5q3mw4Y/UV9AHSx1l8qssYrRRpRKo4H54ga1xL8qW5sBI9yvvFReJVMxO1L
CqDYPPu+dVMlpYl1gzy29UPggzLQCLr/pm10s9JDU1Gtk2FN8/X2zpfNRsmSOfLeZN9A4Iu5ELKt4BgNz67as1+ZEfvGUtyg59aK
YCVkQ/J8rBlA6hKxRGgP1HADsSUIJIYjdLKUoDYRfP6djtPWreITmgIg/Ar/5kpCKMrAtfK8kj9uJym9uzQo7ab+3Uddk57T6/nl
iOymrIvg+D4vPlRe3wqqzkWhke45nS+72bYdk7ZRFw3URbhK6MueSv2Gmq+dLVePEjYEgPQhNhq89rg6of+oa20FE7NHn/fw2uqE
5F54yljfbdIpbSUnyR+oTD0TYS6e0ixp7z3hzdVULSK0PVdrNOg5MZuf7oSdi0Z0Nsk7Bi5kqFduhWe1SlG0Hy7Xo9p4vBoVm8V+
Wivl9FTOWVvNrSmpFf71WgIrG8b2ZbOxukKTydnK5qhKz9n88zvn0h4J6KKpTQcca9w8d8Ns7RurKJ1Vp3LrFS+lkCIYfeaX5gxa
ueTYJsy1LeYCyy6yxyE0ddF03vavb33r65+RA4RaQ8WqImGNZb7qdoAuILZE+4cPPhf8Gao/XNYlT1ZrgYWeBh+1Ztdn8YigwAvV
ZJ6SDa/qe+ascdPsU86T8cfrk3sbkum1YSqQydZpK5gZuub4fzEj54H4SEmH0q049G82Su0KsEmHwl7G5bXHWyd1Q8b0Cj9c07a0
QnpZhmHgi6bEAA3kM9bWO53+Rm5IvyHFseMmc0JvGpXkWyn0DMJXeXx+k4w7xj/QRMV9JuRqpLvi1eY8pStSP6jWD7zS2dWaN4bT
el95C1p1eB/y7ef26DRHKrGAyFkHh2t5AEnQPjjMgy796OAW/h50KUZZ3bo/OLyXK22hnKzlB90T+9IJv/TjifPSCV7qnui3HtEU
X6/2sjhxVcpme06K2p/KULtYJcmX7NzPIET4Nkv5re3JeKhtXHimHbvWZLFtfPau/oSd+znUo1nB9DmsxnzCcSOkrUcVjvy86sEz
4ourzFwidir56BUL5Gh7jCzpgpYpoDIfdMwvKZUXb+X8fkqT1htkRiUHximf/W2zjGIu0JBCxKRxPGQFmjKi+sZadpyn/0r/aM11
X4VKbCFQzwfu52durKrESl4epHXTBuiQdSAq0bI/tVM7xVNURcypBt5n9d8IVQODptQkghTlqhpgTyos3G/QB/CHbaFwM7vnem5X
CGXqmOTw601D2q5+QQgL7Uh8iMLx9xo3fWORj/9TT361l6cwEjnDMuRY6lMb+punRZt6JAG7MWtE0BHl2KhyojpOgeYcTXTA2tIT
Es0Va8AeUrntL60T8u/7WhDCEXAPJ/cPT4mzJrFG9vVJ7nvneEz/zj257BxP2z/js3tchi0zu81ZB9c69Uf5CB27H2Atl7RyCIU5
obrGjw6sWTbssg4IAcZfByiWsuP92vvkgqkcPkvMS7UF8ox0/Kv4rqlShq6TvjR6qyrtgjcv2sbBJEX15XMN9KQqGe+Wa8Fah5qd
nKLyfgPz/OIJcWNQ2OJjU7ZSi0mtljZNSdf0xK1y4+Qd08l2iGZKm4TbYtsceGtbIl1ClFoWV1Kmh8OGj+JvdWmcJpy26gf7tAQz
j73qPk0Nlo8GFqtJ/jm22D+RbfBTk0zr25oiXDaGOOMQsqzPCxewZPtRwvLKiQRRWeN9SpqPuRQPQUI7tyk9Q5UaWychPTfYBWRP
bmZW0vV941CXGOM8ZGgKJOToPCc34sK2l7rqiQ5MqKnOFn+OLemWjzEC6tCe3+RLWzzG3AAU/g0BQC+sABEyEKuMEY2oxkV+Vy/L
6xSPwfLYHAn0gXoofedAsqgkOR1z03mQAktb/AyV9wFHL6++sy0IhxrOVprap9ck1RhAp84ozcQp68pruUL9OvVSzwDORt8edPLr
HFcfKBgQ/inVQIPa5C2rtE3uU2911Hmpta4Vy20Z0eG9ZVXFFmNaobE025NOeanGdRQHuXWf6gnL7FkV7OtlqeBp9Q++EUGt9UnH
3ZPZKvZxK3kg/m7kk/W3+FSsB5IcMAv1iJrt/uVpS1QV2k9LNlnJkkQk3g52jsoNFUiyUJbqT13xOUxR/2/YPxfnA0owJ5/REkqE
UkGZS2Q68ElypdfC6ExjIzE8YVOVmDZmCN21Z4u5iXEdsFVoEsGlDDV3TKnqBaX6U2qGGJf9z/0PiupBp0/uY0bVcrSvleKKsVbo
8mYCt1xMPWdI1ayayMW55hC/G+sWaXysp+s95HlTwJ1d7QI3YYBqPVGQrsLDBRUQluz/MJLK3Lb0NvpMqHgfo+iCP5yEPVi8JKve
aDsfmarzZbL0KaOJoJZ4+DHToKAaPE0hADlJ8aqn3JiwLphtzz7wF4H4pvcFtXmPDuVItUwpiiVJ///vfLkyzRwp8UG9JvdGY7u2
x5NFTJ3O/SPnr5EkKbxd6FPyxotJBRfo0D4IZyBfo+NTL2ZkVEXSB1P2ndNmRm6ZUlDuuY9Roo/kjPSAVP5OjjbAEzBKztcSjp3h
kAddcFEzyuKkgCHdQEwN/gQqHeGfpkZwcYsafcieOOe2Z7/l07bfxdCKPyXW6dOJcuhQDhLY7xHE9dyMQlIE6Zs/Qzo8nktwgRwY
nGKOHICDTS9XmYwIikbY8AdCdlzCsy1BOBp1QXY3Ydl++udER3XR91yfWpEpb9OU+9VnJ6IrPrFnIYXZut9U08ItZ2G+DVilhqGY
he5/h/r/tdmF//aVYCxBNaYi0ek8JzrcLNiwU+LzwJDlJ9RGh0Xtd0L019RSHFeVUV/SqGfVkYzE/4SIX7uq01i1Cqcf6yWqWOW5
hGDjXaWhEJUefZdG5+xUrmcFsplRUp9EoB0sVfXRtiWL1Umy1Mdn2vs+u2DUoRRsmFCVel5RPeorM2dzxMpUHokKc4BMvioB95re
AAf0tQuqyxlXR6x0b6+pt3erSpTlSLWOb2xiUa3qGEPsHDeTEmbUEZ+pr533fENle0Yc5iYr7LIq62UKWlXNwZt6RUWe8ERGHJ+H
c8v/GGi1+rqgVUKbpeBNwqUCd1u+ReMMDF8jf9yPaHNZJmmxkBQ6Hk4LnNPqGi5PyCAnhw0iH/VyYhLnq4aiSyQoiHdFv1SvOfRx
S7L77EEhgt3NzSI4TfKalj5sEwvodyKAI40yfmSr8FE5h50GseSXM/m4zaqHkXPG+yTpzt5ZfXM027grXDjMwFRBQumQuTfKTqte
SWdZ1khyuUktWtH9FkugWu8vjSdrSRJ5yNpw9i6ny91ab7strrPT8N0dkd2IUdePqbPLewXEr5eruPzUU6Y84ZCYLpuzswi8hQ3x
Tsf781z4lgKioEteQaeq4jHpvDmdxeaPyWDfo3RhKr0KJBc4/1adKhUugqoM1HAtSpJ4Z39/99lwcscU0dJpPRQcX6RcpsOcBRCZ
RDzJX+dR/8ESMzLVuEgVJ2EkLNjRphgdUeSaDzrkvmGro1TlKvhbTFYGUify/Rb3AKqO+E70AStTua/GbCBM+gKOzuc6Px+aV3A1
1PX+5Kf7otxx3xX1jw/HnMoRHDpQgvKwctiyvphbmz11KjUceRVZ1yUzEVVDzGEVV3x5a2MWdEy1UJePGu8TP0y4vNg0aD523nTQ
vM3vjb336kfOG9/z8J1Xk2JfiBRne0SaUTga6WHyrWas/BFXqWv9dnzW0t/NnGh9m3xzdJu6NbuT1Nir91EdZK51NZauAtMXvtJF
2ey06clZ6+VT2O2W+bQJ0O0D0q5B4szq7WJq9xmn8KatJWg2CQOf09OWzMnda2du9SZrclFOZUN2fbFBgRGukep8I89Ws/A/bYQT
TmXSpTu3VcdaV6V8Llglequj2kO6doQDtPeJbR8FfWTgRFP9qdyOV2yCDCPcqirNdqwsqury6MqfjTja7VgFZVvQ5YVFCOQihviN
KB2EGcr9zqJbElZK4i6PsMPLNten1/2Z/Z4Wi7nA5o5YZaCYAiNVHpIzgjFT1Nut7tvX1URe64mw796gw5fqRrlsxMlPPpDyoXTE
0T9//NDRNXz567i2vACEkxpTPCrykdxUXbijVny83HsgNqN3yw5H1bJ9CD2lY5v+ed0RXaCg43BUFMgjfL+Ak958hnjM+DSHiOSw
riX3pqXdX/U91YRU763lrXdri6S1Lq2ra2D69cgWKT6MzFIbptcVuZugC2RcpWY2p5B1xp+rDwr+trNyihBT6pVXwtQvPuqXSuUS
zMIXoX2yjiftL6muKeq/4PzvB2UqL0AS3uDI8n5lGYwU1/7EZ/2k+icdnSTJxQovbytcYOBL+nFRolonMkm+rqAH1Oz52kRAdH+J
Umo3PVr5Kmq4EZzznIIcgO/zWR+Bm0/9o39D6SVUJknTmD947RV2lmP7pf406Y3Un7DVcHXxW/3JzP/on3549+FX9v2UlYQ2NW7p
xH/1qoh043imLw1hv6y+KfzeHAmSbyRDygYNnz7jDwxRMh+XMoWZBKI4QHXYUfcNgmM3pBwF1LVXJZxuvPgfMow2cw==
"""

if __name__ == "__main__":
    main()
