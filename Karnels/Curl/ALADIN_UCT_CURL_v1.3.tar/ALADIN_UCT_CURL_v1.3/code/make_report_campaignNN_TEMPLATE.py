#!/usr/bin/env python3
"""Template for a campaign report builder. Copy to make_report_campaignNN.py when that campaign is authorized.
Contract (same as Campaign 01):
  build_report(R, here, name) -> markdown text, also written to <here>/<name>
  R = results dict written by campaignNN.py: {"env", "tolerances", "tests": {id: {"name", "host": {...}, "cupy": {...}}}, ...}
Every number in the report must come from R. Nothing hand-typed."""
import json, os

CAMPAIGN = "NN"

def build_report(R, here, name=f"CAMPAIGN{CAMPAIGN}_REPORT.md"):
    T, E = R["tests"], R["env"]
    e = lambda x: f"{x:.2e}"
    L = []; w = L.append
    w(f"# ALADIN v4.0 — Campaign {CAMPAIGN} evidence report")
    w(f"**Source SHA-256:** `{E['kernel_sha256']}`  \n**Run (UTC):** {E['utc']}  \n**GPU leg:** {E['gpu_leg_status']}\n")
    w("| # | Test | Host | GPU |"); w("|---|---|---|---|")
    for tid in sorted(T):
        w(f"| {tid} | {T[tid]['name']} | **{T[tid]['host']['verdict']}** | **{T[tid]['cupy']['verdict']}** |")
    # per-test sections go here: evidence tables, tolerances, failure reasons, defect register
    text = "\n".join(L) + "\n"
    open(os.path.join(here, name), "w").write(text)
    return text

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
    R = json.load(open(os.path.join(here, f"campaign{CAMPAIGN}_results.json")))
    print(build_report(R, here))
