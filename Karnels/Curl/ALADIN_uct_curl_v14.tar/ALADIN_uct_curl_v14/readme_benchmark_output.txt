kernel hashes: UCT_CURL file 6d87e9af0da2 | UCT-EMF 341ebaf6c267 | EGLM d4753fd84a07 | HLLD 7e32b8643a73

grid 16x8x4 (axis grid, r in [0,1]):
  B_phi = 0.5 r          : set on the CT faces
  J_z = 1                : max |J_z - 1| = 4.4e-16   (J_r, J_phi max 0.0e+00)
  f_r = -0.5 r           : max |f_r + 0.5 r| = 2.2e-16   (f_phi, f_z max 0.0e+00)
  div B = 0              : max |div B| = 0.0e+00
  P = P0 - r^2/4         : max |P_face - exact| = 0.0e+00   (HLLD mass flux 0.0e+00, energy flux 0.0e+00: static)
  dP/dr = -0.5 r         : max |dP/dr + 0.5 r| = 0.0e+00
  force balance dP/dr - f_r = 2.2e-16

grid 64x32x8 (axis grid, r in [0,1]):
  B_phi = 0.5 r          : set on the CT faces
  J_z = 1                : max |J_z - 1| = 2.0e-15   (J_r, J_phi max 0.0e+00)
  f_r = -0.5 r           : max |f_r + 0.5 r| = 1.0e-15   (f_phi, f_z max 0.0e+00)
  div B = 0              : max |div B| = 0.0e+00
  P = P0 - r^2/4         : max |P_face - exact| = 0.0e+00   (HLLD mass flux 0.0e+00, energy flux 0.0e+00: static)
  dP/dr = -0.5 r         : max |dP/dr + 0.5 r| = 0.0e+00
  force balance dP/dr - f_r = 1.0e-15
