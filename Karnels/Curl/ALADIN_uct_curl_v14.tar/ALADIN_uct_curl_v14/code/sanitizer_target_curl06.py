# -*- coding: utf-8 -*-
"""CURL-06 sanitizer target: UCT_CURL v1.4 GPU kernel (NVRTC direct) on every CURL-06 grid and field, FP64 + FP32,
plus the frozen Driver S7 states.  Run under compute-sanitizer memcheck / racecheck / initcheck."""
import os, sys, numpy as np, cupy as cp
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
sys.argv = [sys.argv[0], "gpu"]
import campaign06_curl as C
rng = np.random.default_rng(620)
for dt in (np.float64, np.float32):
    for gk, fk in C.CASES + [("axis", "subnormal")]:
        G = C.grid(gk, dt); B = C.fields(G, fk, dt, rng); C.gpu14(G, B)
C.G05()
cp.cuda.Device().synchronize()
print("CURL-06 sanitizer workload done")
