# -*- coding: utf-8 -*-
"""MakeResults for UCT_CURL v1.4 (campaign CURL-06 = new tests + the unchanged v1.3 suite as regression).
Reads the CPU leg (cpu_leg/) and the GPU leg (gpu_leg/, as returned by the author's Colab run), checks hashes, writes
CURL06_RESULTS.json and CURL06_RESULTS.md.  Classes are taken from the legs; nothing is re-decided here."""
import os, json, hashlib
HERE = os.path.dirname(os.path.abspath(__file__)); P = lambda *a: os.path.join(HERE, *a)
sha = lambda p: hashlib.sha256(open(P(p), "rb").read()).hexdigest()
load = lambda p: json.load(open(P(p)))
c06 = dict(cpu=load("cpu_leg/curl06_cpu_results.json"), gpu=load("gpu_leg/curl06_gpu_results.json"))
c05 = dict(cpu=load("cpu_leg/campaign05_results.json"), gpu=load("gpu_leg/c05/campaign05_results.json"))
fsha = {k: v["file_sha256"] for k, v in c06.items()}
frozen = all(v["file_sha256"] == v["frozen_file_sha256"] == sha("uct_curl.py") for v in c06.values())
build_same = c06["cpu"]["build_sha256"] == c06["gpu"]["build_sha256"]
final = {}
for t in c06["cpu"]["tests"]: final[t["id"]] = t["cls"]
for t in c06["gpu"]["tests"]:
    final[t["id"]] = "VERIFIED" if t["cls"] == "VERIFIED" and final.get(t["id"], "VERIFIED") == "VERIFIED" else "BLOCKER"
reg = {}
for leg, d in c05.items():
    T = d["tests"]; BK = ("host",) if leg == "cpu" else ("host", "cupy")       # the CPU leg has no GPU (its cupy side is BLOCKED)
    reg[leg] = dict(t041_049={k: {b: T[k][b]["verdict"] for b in BK} for k in sorted(T) if k != "050"},
                    t050={b: dict(verdict=T["050"][b]["verdict"], fail_reasons=T["050"][b]["fail_reasons"], regression_count=T["050"][b]["regression_count"],
                                  regression_all_pass=T["050"][b]["regression_all_pass"], sources_unchanged=T["050"][b]["sources_unchanged_during_test"]) for b in BK},
                    open_register=[dict(id=x["id"], cls=x["cls"], kind=x.get("kind"), title=x.get("title")) for x in d["register"] if x["cls"] == "BLOCKER"])
for leg, b, name in (("cpu", "host", "R-host (CPU leg)"), ("gpu", "host", "R-host (GPU leg machine)"), ("gpu", "cupy", "R-gpu")):
    t = reg[leg]["t050"][b]; n9 = reg[leg]["t041_049"]
    ok = all(v[b] == "PASS" for v in n9.values()) and t["regression_all_pass"] and t["regression_count"] == 40 \
        and all("source hash mismatch" in r for r in t["fail_reasons"])
    final[name] = "VERIFIED" if ok else "BLOCKER"
san = {}
for tool in ("memcheck", "racecheck", "initcheck"):
    txt = open(P(f"gpu_leg/curl06_{tool}.log")).read(); last = [l for l in txt.splitlines() if "SUMMARY" in l][-1]
    san[tool] = dict(summary=last.replace("=========", "").strip(), workload_done="CURL-06 sanitizer workload done" in txt,
                     clean=("0 errors" in last) and ("workload done" in txt))
    final["M-" + tool] = "VERIFIED" if san[tool]["clean"] else "BLOCKER"
drv = dict(smk00=open(P("gpu_leg/smk00_gpu.out")).read(), kw00=open(P("gpu_leg/kw00_gpu.out")).read())
counts = {}
for v in final.values(): counts[v] = counts.get(v, 0) + 1
R = dict(campaign="CURL-06", kernel="ALADIN UCT_CURL v1.4", file_sha256=sha("uct_curl.py"), kernel_src_sha256=c06["cpu"]["kernel_src_sha256"],
         build_sha256=c06["cpu"]["build_sha256"], frozen_and_consistent=frozen and build_same, final_class=final, final_counts=counts,
         regression_v13_suite=reg, sanitizer=san, driver_confirmation=drv,
         regression_note=("The v1.3 suite (campaign05.py, unmodified) was run against v1.4 on both legs. 041-049 PASS on host and GPU; "
                          "050's 01-04 regression 40/40 PASS on host and GPU. 050 reports FAIL on both legs for exactly one reason: its "
                          "source-hash guard, which registers the v1.3 file (e7b25907...), refuses any other file. R-host / R-gpu record this "
                          "as VERIFIED only if that guard is the ONLY failure reason. The open BLOCKER entries (Q11, Q15-*) are the Driver "
                          "v3.1 stub inventory, identical to the certified v1.3 run; Driver v4.0 integration is covered by SMK-00 / KW-00."),
         legs=dict(curl06=c06), files={f: sha(f) for f in ("uct_curl.py", "uct_curl_v13_reference.py", "campaign06_curl.py", "campaign05.py", "campaign01.py",
                                                            "sanitizer_target_curl06.py", "s7_states.npz")})
json.dump(R, open(P("CURL06_RESULTS.json"), "w"), indent=1, default=float)
L = [f"# CURL-06 results: ALADIN UCT_CURL v1.4", "", f"file sha256 `{R['file_sha256']}`  ", f"kernel source (stencil) sha256 `{R['kernel_src_sha256']}` (= v1.3)  ",
     f"build sha256 `{R['build_sha256']}`  ", f"frozen and identical on both legs: **{R['frozen_and_consistent']}**", "",
     f"**Final: {counts}**", "", "| ID | final |", "|---|---|"] + [f"| {k} | {v} |" for k, v in final.items()] + ["", R["regression_note"]]
open(P("CURL06_RESULTS.md"), "w").write("\n".join(L) + "\n")
print(counts, "frozen+consistent:", R["frozen_and_consistent"])
