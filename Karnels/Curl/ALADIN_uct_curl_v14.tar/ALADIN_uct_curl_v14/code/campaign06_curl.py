# -*- coding: utf-8 -*-
"""
ALADIN UCT_CURL v1.4 -- certification campaign CURL-06 (new tests for the v1.4 build / dispatch change).
    python campaign06_curl.py cpu | gpu
The full v1.3 suite (campaign05.py: 041-049 + the 01-04 regression inside 050) is re-run UNCHANGED against v1.4 as the
regression part of CURL-06.  This file adds the tests for what v1.4 changes.  Thresholds are declared below, 2026-11-21,
before any v1.4 result was looked at.

Why v1.4: ALADIN Driver v4.0 KW-00 (2026-11-20) found UCT-CURL GPU vs CPU differing by up to 4.2e-15 (FMA contraction in
cupy.RawKernel's default build; with -fmad=false still 2.7e-20, because the CPU path was a NumPy re-implementation with
its own operation order), and found run_curl running on the GPU whenever CuPy was installed, whatever backend the Driver
asked for.  v1.4 keeps the stencil source byte-identical and changes only the build and the dispatch.
"""
import os, sys, json, time, hashlib, platform, datetime, importlib.util, subprocess, traceback
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
def load(path, name):
    sp = importlib.util.spec_from_file_location(name, os.path.join(HERE, path)); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m
U = load("uct_curl.py", "uct_curl_v14")
V = load("uct_curl_v13_reference.py", "uct_curl_v13")
FROZEN_FILE = "6d87e9af0da2334e50a0dbf6ab29ea53d239aa7cac2e25e84d1f65a10e40443d"          # sha256 of uct_curl.py v1.4
V13_FILE = "e7b25907f2d4488dcb8c2d088bf1c739668c40814d56396952fd670da451f58e"
S7_SHA = "ab9ea008d4a3149278cd5ed03ea7a3d17bd69e4f9c411147c7f9b59f65ccc6f0"
sha = lambda p: hashlib.sha256(open(os.path.join(HERE, p), "rb").read()).hexdigest()
if LEG == "gpu": import cupy as cp

TH = dict(
    C01_stencil_chars_differing=0.0,
    C02_v14cpu_vs_v13host_values=0.0,
    C03_vs_numpy_fp64_rel=1e-12, C03_vs_numpy_fp32_rel=1e-4,
    C04_backend_rules=1.0,
    C05_zpinch_fp64=1e-14, C05_zpinch_fp32=1e-6,
    G01_gpu_cpu_values=0.0,
    G02_ptx_ftz=0.0, G02_ieee_selftest=1.0,
    G03_repeat_values=0.0,
    G04_fma_effect_eps=8.0,
    G05_s7_gpu_cpu_values=0.0,
    G06_cpu_on_gpu_machine=1.0,
)

# --------------------------------------------------------------------------------------------- test fields (harness-owned)
def grid(kind, dtype):
    if kind == "axis":      nr, nphi, nz, r0, dr, dz = 16, 16, 8, 0.0, 1 / 16, 0.1
    elif kind == "annulus": nr, nphi, nz, r0, dr, dz = 12, 10, 6, 0.5, 0.08, 0.13
    elif kind == "awkward": nr, nphi, nz, r0, dr, dz = 7, 5, 3, 0.0, 0.11, 0.07
    else:                   nr, nphi, nz, r0, dr, dz = 9, 24, 40, 0.0, 0.2, 0.001          # anisotropic
    g = 2; dphi = 2 * np.pi / nphi
    rf = (r0 + (np.arange(nr + 1 + 2 * g) - g) * dr).astype(dtype); rc = (r0 + (np.arange(nr + 2 * g) - g + 0.5) * dr).astype(dtype)
    if r0 == 0.0: rf[g] = 0.0
    return dict(nr=nr, nphi=nphi, nz=nz, g=g, dr=dr, dphi=dphi, dz=dz, rf=rf, rc=rc)

def fields(G, kind, dtype, rng):
    nr, nphi, nz, g = G["nr"], G["nphi"], G["nz"], G["g"]
    sh = [(nr + 1 + 2 * g, nphi + 2 * g, nz + 2 * g), (nr + 2 * g, nphi + 1 + 2 * g, nz + 2 * g), (nr + 2 * g, nphi + 2 * g, nz + 1 + 2 * g)]
    if kind == "random": B = [rng.normal(0, 1, s) for s in sh]
    elif kind == "zpinch":
        B = [np.zeros(s) for s in sh]; B[1][:] = 0.5 * G["rc"].astype(np.float64)[:, None, None]
    elif kind == "smooth":
        B = []
        for k, s in enumerate(sh):
            i, j, l = np.meshgrid(*[np.arange(n) for n in s], indexing="ij")
            B.append(np.sin(0.3 * i + k) * np.cos(0.7 * j) + 0.2 * np.sin(0.5 * l + 0.1 * k))
    else:                                                                       # subnormal scale (FP32 only meaningful)
        B = [rng.normal(0, 1, s) * 1e-39 for s in sh]
    B = [np.ascontiguousarray(b.astype(dtype)) for b in B]
    if G["rf"][G["g"]] == 0: B[0][G["g"]] = B[0][G["g"]]                        # axis face holds whatever value (limiting Br)
    return B

def cpu14(G, B):
    J, lab = U.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"], backend="cpu"); return J

def gpu14(G, B):
    J, lab = U.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"], backend="cupy"); return J

def v13host(G, B):
    """v1.3's stencil source compiled the way the v1.3 campaigns compiled it (g++ -O2, no contraction flag)"""
    import campaign01 as C1
    hb = C1.HostBackend(ksrc=V._KERNEL_SRC, kname="current_curl_kernel", tag="v13ref_")
    return hb.run(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"])

def interior(G, a):
    g = G["g"]; return a[g:g + G["nr"], g:g + G["nphi"], g:g + G["nz"]]

def ndiff(a, b):
    return int(((a != b) & ~(np.isnan(a) & np.isnan(b))).sum())

CASES = [(gk, fk) for gk in ("axis", "annulus", "awkward", "aniso") for fk in ("random", "zpinch", "smooth")]

# --------------------------------------------------------------------------------------------- CPU tests
def C01():
    a, b = U._KERNEL_SRC, V._KERNEL_SRC; n = sum(x != y for x, y in zip(a, b)) + abs(len(a) - len(b))
    return dict(v13_file_sha=sha("uct_curl_v13_reference.py"), v13_certified=sha("uct_curl_v13_reference.py") == V13_FILE, kernel_src_sha=U.KERNEL_SRC_SHA256), \
        [("characters differing (v1.4 vs certified v1.3 _KERNEL_SRC)", float(n), "<=", TH["C01_stencil_chars_differing"]),
         ("v1.3 reference is the certified file", float(sha("uct_curl_v13_reference.py") == V13_FILE), "==", 1.0)]

def C02():
    rng = np.random.default_rng(600); n = 0; tot = 0
    for dt in (np.float64, np.float32):
        for gk, fk in CASES:
            G = grid(gk, dt); B = fields(G, fk, dt, rng)
            a, b = cpu14(G, B), v13host(G, B)
            for x, y in zip(a, b): n += ndiff(interior(G, x), interior(G, y)); tot += interior(G, x).size
    return dict(conditions="4 grids (axis, annulus, awkward 7x5x3, anisotropic 200:1) x 3 fields x FP64/FP32", values=tot), \
        [("values differing, v1.4 CPU vs v1.3 source compiled as in the v1.3 campaigns", float(n), "<=", TH["C02_v14cpu_vs_v13host_values"])]

def C03():
    rng = np.random.default_rng(601); w = {np.float64: 0.0, np.float32: 0.0}; nd = 0
    for dt in (np.float64, np.float32):
        for gk, fk in CASES:
            G = grid(gk, dt); B = fields(G, fk, dt, rng); a = cpu14(G, B)
            shp = a[0].shape; b = [np.zeros(shp, dt) for _ in range(3)]
            U.curl_numpy_flat(*B, *b, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"])
            sc = max(float(np.abs(interior(G, x)).max()) for x in a) or 1.0
            for x, y in zip(a, b): w[dt] = max(w[dt], float(np.abs(interior(G, x) - interior(G, y)).max()) / sc); nd += ndiff(interior(G, x), interior(G, y))
    return dict(conditions="the CASES set; NumPy emulation = the v1.3 CPU runtime path", values_differing=nd), \
        [("FP64 max |v1.4 CPU - NumPy path| / max|J|", w[np.float64], "<=", TH["C03_vs_numpy_fp64_rel"]),
         ("FP32 max |v1.4 CPU - NumPy path| / max|J|", w[np.float32], "<=", TH["C03_vs_numpy_fp32_rel"])]

def C04():
    G = grid("axis", np.float64); B = fields(G, "random", np.float64, np.random.default_rng(602)); ok = []
    J, lab = U.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"], backend="cpu")
    ref = [np.zeros_like(J[0]) for _ in range(3)]; U.cpu_current_curl(*B, *ref, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"])
    ok.append(lab.startswith("CPU") and all(isinstance(x, np.ndarray) for x in J) and all(ndiff(x, y) == 0 for x, y in zip(J, ref)))
    try: U.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"], backend="gpu?"); ok.append(False)
    except U.CurlContractError: ok.append(True)
    if U.cp is None:
        try: U.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"], backend="cupy"); ok.append(False)
        except U.CurlContractError: ok.append(True)
    return dict(rules_checked=len(ok), rules=ok), [("every backend rule holds", float(all(ok)), "==", TH["C04_backend_rules"])]

def C05():
    out = {}
    for dt in (np.float64, np.float32):
        G = grid("axis", dt); B = fields(G, "zpinch", dt, None); J = cpu14(G, B)
        out[np.dtype(dt).name] = float(np.abs(interior(G, J[2]) - 1).max())
    return dict(field="README Z-pinch B_phi = r/2 (mu0 = 1), axis grid 16x16x8, run_curl(backend='cpu')", **out), \
        [("FP64 max |J_z - 1|", out["float64"], "<=", TH["C05_zpinch_fp64"]), ("FP32 max |J_z - 1|", out["float32"], "<=", TH["C05_zpinch_fp32"])]

# --------------------------------------------------------------------------------------------- GPU tests
def G01():
    rng = np.random.default_rng(610); n = 0; tot = 0; nsub = 0
    for dt in (np.float64, np.float32):
        for gk, fk in CASES + [(gk, "subnormal") for gk in ("axis", "annulus")]:
            G = grid(gk, dt); B = fields(G, fk, dt, rng); a, b = gpu14(G, B), cpu14(G, B)
            for x, y in zip(a, b): n += ndiff(interior(G, x), interior(G, y)); tot += interior(G, x).size
            if fk == "subnormal" and dt == np.float32: nsub += sum(int(((interior(G, y) != 0) & (np.abs(interior(G, y)) < np.finfo(np.float32).tiny)).sum()) for y in b)
    return dict(conditions="CASES + subnormal-scale fields, FP64 + FP32", values=tot, fp32_subnormal_J_values=nsub), \
        [("values differing GPU vs CPU", float(n), "<=", TH["G01_gpu_cpu_values"])]

def G02():
    k64, k32 = U.build_kernel(np.float64), U.build_kernel(np.float32)
    m64 = U._NvrtcModule(U._KERNEL_SRC.replace("REAL_T", "double"), U.GPU_OPTIONS); m32 = U._NvrtcModule(U._KERNEL_SRC.replace("REAL_T", "float"), U.GPU_OPTIONS)
    ok = U.gpu_ieee_selftest()
    return dict(options=list(m64.options), ptx_ftz=m64.ptx_ftz_count + m32.ptx_ftz_count, selftest=ok), \
        [("'.ftz' instructions in the PTX", float(m64.ptx_ftz_count + m32.ptx_ftz_count), "<=", TH["G02_ptx_ftz"]), ("FP32 subnormal self-test", float(ok), ">=", TH["G02_ieee_selftest"])]

def G03():
    rng = np.random.default_rng(611); n = 0
    for dt in (np.float64, np.float32):
        G = grid("axis", dt); B = fields(G, "random", dt, rng); r0 = gpu14(G, B)
        for _ in range(2): n += sum(ndiff(x, y) for x, y in zip(gpu14(G, B), r0))
    return dict(conditions="3 launches, axis grid, FP64 + FP32"), [("values differing between launches", float(n), "<=", TH["G03_repeat_values"])]

def G04():
    rng = np.random.default_rng(612); worst = 0.0; nd = 0; tot = 0
    for dt in (np.float64, np.float32):
        eps = np.finfo(dt).eps
        for gk, fk in CASES:
            G = grid(gk, dt); B = fields(G, fk, dt, rng); a = gpu14(G, B)
            k13 = cp.RawKernel(V._KERNEL_SRC.replace("REAL_T", "double" if dt == np.float64 else "float"), "current_curl_kernel")
            V._kernels.clear(); V._kernels[np.dtype(dt).name] = k13
            (b, _) = V.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"])
            sc = max(float(np.abs(interior(G, x)).max()) for x in a) or 1.0
            for x, y in zip(a, b):
                worst = max(worst, float(np.abs(interior(G, x) - interior(G, y)).max()) / (eps * sc)); nd += ndiff(interior(G, x), interior(G, y)); tot += interior(G, x).size
    return dict(conditions="the CASES set; v1.3 GPU build = cupy.RawKernel defaults (FMA on)", values_differing=nd, values=tot), \
        [("max |v1.4 GPU - v1.3 GPU| in eps x max|J|", worst, "<=", TH["G04_fma_effect_eps"])]

def G05():
    p = os.path.join(HERE, "s7_states.npz"); assert sha("s7_states.npz") == S7_SHA, "s7_states.npz changed"
    z = np.load(p); dr, dphi, dz = z["d"]; G = dict(nr=32, nphi=16, nz=16, g=2, dr=float(dr), dphi=float(dphi), dz=float(dz), rf=z["r_faces"], rc=z["r_centers"])
    n = 0; tot = 0
    for dt in (np.float64, np.float32):
        Gd = dict(G, rf=G["rf"].astype(dt), rc=G["rc"].astype(dt))
        for s in range(11):
            B = [np.ascontiguousarray(z[f"s{s}_{k}"].astype(dt)) for k in ("Br", "Bphi", "Bz")]
            for x, y in zip(gpu14(Gd, B), cpu14(Gd, B)): n += ndiff(interior(Gd, x), interior(Gd, y)); tot += interior(Gd, x).size
    return dict(conditions="11 frozen states of the Driver SMK-00 S7 trajectory (eta = 0.01, Hall = 0.02), FP64 + FP32", values=tot), \
        [("values differing GPU vs CPU", float(n), "<=", TH["G05_s7_gpu_cpu_values"])]

def G06():
    G = grid("axis", np.float64); B = fields(G, "random", np.float64, np.random.default_rng(613))
    pool = cp.get_default_memory_pool(); cp.cuda.Device().synchronize(); u0 = pool.used_bytes()
    J, lab = U.run_curl(*B, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"], backend="cpu")
    u1 = pool.used_bytes()
    ref = [np.zeros_like(J[0]) for _ in range(3)]; U.cpu_current_curl(*B, *ref, G["rf"], G["rc"], G["dr"], G["dphi"], G["dz"], G["nr"], G["nphi"], G["nz"], G["g"])
    ok = lab.startswith("CPU") and all(isinstance(x, np.ndarray) for x in J) and all(ndiff(x, y) == 0 for x, y in zip(J, ref)) and u1 == u0
    return dict(label=lab, gpu_pool_used_before=u0, after=u1), [("backend='cpu' stays on the CPU on a GPU machine", float(ok), "==", TH["G06_cpu_on_gpu_machine"])]

CPU_TESTS = [C01, C02, C03, C04, C05]; GPU_TESTS = [G01, G02, G03, G04, G05, G06]
OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}

if __name__ == "__main__":
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, platform=platform.platform(), python=platform.python_version(),
               numpy=np.__version__, gxx=subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0])
    if LEG == "gpu": env.update(cupy=cp.__version__, gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode())
    fsha = sha("uct_curl.py")
    print(f"CURL-06 leg={LEG} uct_curl.py v{U.VERSION} file sha {fsha} (frozen {FROZEN_FILE == fsha}) kernel-src sha {U.KERNEL_SRC_SHA256} build sha {U.BUILD_SHA256}")
    tests = []
    for f in (CPU_TESTS + GPU_TESTS if LEG == "gpu" else CPU_TESTS):
        t0 = time.time(); rec = dict(id=f.__name__, doc=f.__doc__)
        try:
            data, checks = f(); rec["data"] = data
            rec["checks"] = [dict(name=n, measured=m, op=o, threshold=t, passed=bool(OPS[o](m, t))) for n, m, o, t in checks]
            rec["cls"] = "VERIFIED" if all(c["passed"] for c in rec["checks"]) else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["exception"] = traceback.format_exc(); rec["checks"] = []
        rec["seconds"] = round(time.time() - t0, 1); tests.append(rec)
        print(f"{rec['id']:4s} {rec['cls']:9s} {rec['seconds']:7.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec["checks"]))
        if "exception" in rec: print(rec["exception"])
    counts = {}
    for t in tests: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    print("SUMMARY", counts)
    json.dump(dict(campaign="CURL-06", kernel=f"ALADIN UCT_CURL v{U.VERSION}", file_sha256=fsha, frozen_file_sha256=FROZEN_FILE, kernel_src_sha256=U.KERNEL_SRC_SHA256,
                   build_sha256=U.BUILD_SHA256, thresholds=TH, env=env, tests=tests,
                   files={p: sha(p) for p in ("uct_curl.py", "uct_curl_v13_reference.py", "campaign06_curl.py", "campaign01.py", "s7_states.npz")}),
              open(os.path.join(HERE, f"curl06_{LEG}_results.json"), "w"), indent=1, default=float)
