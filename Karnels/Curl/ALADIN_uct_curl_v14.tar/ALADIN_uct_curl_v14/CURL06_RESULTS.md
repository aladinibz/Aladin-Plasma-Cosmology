# CURL-06 results: ALADIN UCT_CURL v1.4

file sha256 `6d87e9af0da2334e50a0dbf6ab29ea53d239aa7cac2e25e84d1f65a10e40443d`  
kernel source (stencil) sha256 `de3af259cfaa156c8a9911fd46178371f60521dfae8e25eda4e7af32d82ccb0b` (= v1.3)  
build sha256 `082b9ad913ccc9086af7ebadd154c6cfddb514bc03cf917a6d1ad6d79dea4b1f`  
frozen and identical on both legs: **True**

**Final: {'VERIFIED': 17}**

| ID | final |
|---|---|
| C01 | VERIFIED |
| C02 | VERIFIED |
| C03 | VERIFIED |
| C04 | VERIFIED |
| C05 | VERIFIED |
| G01 | VERIFIED |
| G02 | VERIFIED |
| G03 | VERIFIED |
| G04 | VERIFIED |
| G05 | VERIFIED |
| G06 | VERIFIED |
| R-host (CPU leg) | VERIFIED |
| R-host (GPU leg machine) | VERIFIED |
| R-gpu | VERIFIED |
| M-memcheck | VERIFIED |
| M-racecheck | VERIFIED |
| M-initcheck | VERIFIED |

The v1.3 suite (campaign05.py, unmodified) was run against v1.4 on both legs. 041-049 PASS on host and GPU; 050's 01-04 regression 40/40 PASS on host and GPU. 050 reports FAIL on both legs for exactly one reason: its source-hash guard, which registers the v1.3 file (e7b25907...), refuses any other file. R-host / R-gpu record this as VERIFIED only if that guard is the ONLY failure reason. The open BLOCKER entries (Q11, Q15-*) are the Driver v3.1 stub inventory, identical to the certified v1.3 run; Driver v4.0 integration is covered by SMK-00 / KW-00.
