# -*- coding: utf-8 -*-
"""Independent oracle for PRIM v01, written from the physics, not from the kernel source.
  exact_*   : 80-bit long-double evaluation from the STORED inputs (reference values, error ~1e-19 relative)
  rule_*    : the refusal / admissibility rules restated
The campaign also checks the kernel bit for bit against `same_order`, a NumPy transcription of the documented operation
order (that is a determinism / reproducibility check, not an accuracy reference)."""
import numpy as np
LD = np.longdouble


def cellB(Br, Bp, Bz):
    return 0.5 * (Br[:-1] + Br[1:]), 0.5 * (Bp[:, :-1] + Bp[:, 1:]), 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])


def exact_prim(rho, mr, mp, mz, E, Br, Bp, Bz, gamma_stored):
    """long-double primitives from the stored inputs; gamma_stored is the value of gamma AS STORED in the working precision"""
    d, a, b, c, e = (np.asarray(x, LD) for x in (rho, mr, mp, mz, E))
    br, bp, bz = cellB(*(np.asarray(x, LD) for x in (Br, Bp, Bz)))
    K = (a * a + b * b + c * c) / (2 * d); M = (br * br + bp * bp + bz * bz) / 2; ei = e - K - M
    g = LD(gamma_stored)
    return dict(rho=d, vr=a / d, vphi=b / d, vz=c / d, p=(g - 1) * ei, K=K, M=M, e=ei, E=e)


def exact_cons(rho, vr, vp, vz, p, Br, Bp, Bz, gamma_stored):
    d, a, b, c, pp = (np.asarray(x, LD) for x in (rho, vr, vp, vz, p))
    br, bp, bz = cellB(*(np.asarray(x, LD) for x in (Br, Bp, Bz)))
    g = LD(gamma_stored)
    return dict(rho=d, m_r=d * a, m_phi=d * b, m_z=d * c, E=pp / (g - 1) + d * (a * a + b * b + c * c) / 2 + (br * br + bp * bp + bz * bz) / 2)


def rule_prim_refused(rho, mr, mp, mz, E, Br, Bp, Bz):
    """flag-1 rule: rho <= 0 or any of the 11 inputs of a cell not finite"""
    fb = [np.isfinite(x) for x in (Br, Bp, Bz)]
    finB = fb[0][:-1] & fb[0][1:] & fb[1][:, :-1] & fb[1][:, 1:] & fb[2][:, :, :-1] & fb[2][:, :, 1:]
    fin = np.isfinite(rho) & np.isfinite(mr) & np.isfinite(mp) & np.isfinite(mz) & np.isfinite(E) & finB
    return ~(fin & (rho > 0))


def same_order(rho, mr, mp, mz, E, Br, Bp, Bz, gamma, dtype):
    """NumPy transcription of the documented operation order (for the bitwise determinism check)"""
    T = lambda x: np.asarray(x, dtype); d, a, b, c, en = (T(x) for x in (rho, mr, mp, mz, E)); h = T(0.5)
    with np.errstate(all="ignore"):
        vr, vp, vz = a / d, b / d, c / d
        K = h * (((a * a) + (b * b)) + (c * c)) / d
        Br, Bp, Bz = T(Br), T(Bp), T(Bz)
        bcr, bcp, bcz = h * (Br[:-1] + Br[1:]), h * (Bp[:, :-1] + Bp[:, 1:]), h * (Bz[:, :, :-1] + Bz[:, :, 1:])
        M = h * (((bcr * bcr) + (bcp * bcp)) + (bcz * bcz))
        ei = (en - K) - M; gm1 = T(gamma) - T(1); p = gm1 * ei
    return dict(rho=d, vr=vr, vphi=vp, vz=vz, p=p, e=ei)
