import numpy as np, prim_v01 as P, prim_driver_adapter as A
rng = np.random.default_rng(3); G = P.Grid(12, 10, 8, 0.0, 1.0); sh = G.shape("cell")
f = dict(rho=rng.uniform(.5, 2, sh), rho_vr=rng.normal(size=sh), rho_vphi=rng.normal(size=sh), rho_vz=rng.normal(size=sh), E=rng.uniform(20, 30, sh),
         Br=rng.normal(size=G.shape("Br")), Bphi=rng.normal(size=G.shape("Bphi")), Bz=rng.normal(size=G.shape("Bz")))
a = A.prim_slot(G, f, diag=True); b = P.primitives(G, f["rho"], f["rho_vr"], f["rho_vphi"], f["rho_vz"], f["E"], f["Br"], f["Bphi"], f["Bz"], diag=True)
d = max(float(np.abs(a[k] - b[k]).max()) for k in a)
print("ADAPTER EQUIVALENCE max |slot - certified| =", d, "-> PASS" if d == 0 else "-> FAIL")
