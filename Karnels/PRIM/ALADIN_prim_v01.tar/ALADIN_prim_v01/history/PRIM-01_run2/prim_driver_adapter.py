# -*- coding: utf-8 -*-
"""Driver slot 01 PRIM: maps the Driver's StateRegistry field names onto the certified PRIM v01 kernel (prim_v01.py, unchanged).
fields: dict with 'rho', 'rho_vr', 'rho_vphi', 'rho_vz', 'E', 'Br', 'Bphi', 'Bz' (ghost-extended, ghosts filled).
Returns dict(rho, vr, vphi, vz, p, flags[, p_err_bound]).
Flag policy for the Driver:
  1 / 2 / 8 REFUSED (NaN outputs): stop, roll back, or hand the flagged cells to the recovery loop (with HLLD flag 32).
  4 UNRESOLVED: accept and use the values; count the cells; a growing fraction means the state needs FP64 (Driver v3.1 stores
    float32: in FP32, p keeps 3 digits only down to beta ~ 1e-4).  p = 0 (b = Inf) is a valid cold state."""
import prim_v01 as P
CERTIFIED_SHA256 = "1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535"
CERTIFIED_BUILD_SHA256 = "d916b4a7b46e3565c4cfa9a1aeff54b850a62d58924df84c202b542d87d9471d"
assert P.SOURCE_SHA256 == CERTIFIED_SHA256, "prim_v01.py is not the certified kernel"
assert P.BUILD_SHA256 == CERTIFIED_BUILD_SHA256, "prim_v01.py build options are not the certified ones"


def prim_slot(G, fields, gamma=5 / 3, backend="cpu", diag=False):
    f = fields
    return P.primitives(G, f["rho"], f["rho_vr"], f["rho_vphi"], f["rho_vz"], f["E"], f["Br"], f["Bphi"], f["Bz"], gamma=gamma, backend=backend, diag=diag)
