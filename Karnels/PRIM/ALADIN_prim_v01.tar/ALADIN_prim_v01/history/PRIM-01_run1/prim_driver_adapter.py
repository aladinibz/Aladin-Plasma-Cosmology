# -*- coding: utf-8 -*-
"""Driver slot 01 PRIM: maps the Driver's StateRegistry field names onto the certified PRIM v01 kernel (prim_v01.py, unchanged).
fields: dict with 'rho', 'rho_vr', 'rho_vphi', 'rho_vz', 'E', 'Br', 'Bphi', 'Bz' (ghost-extended, ghosts filled).
Returns dict(rho, vr, vphi, vz, p, flags[, p_err_bound]).  Flags: 1 / 2 REFUSED (NaN outputs: the Driver must stop or roll back,
or hand the flagged cells to its recovery loop), 4 UNRESOLVED (p has < 3 significant digits; a warning)."""
import prim_v01 as P
CERTIFIED_SHA256 = "3eece99e9f8d61e1bf9edc8eb717ef440b4f1c04016bfd4786629661bee06412"
CERTIFIED_BUILD_SHA256 = "a94c182593132140be3d0e4c725feafc45b90d57e1153b7c5799729321f9aae3"
assert P.SOURCE_SHA256 == CERTIFIED_SHA256, "prim_v01.py is not the certified kernel"
assert P.BUILD_SHA256 == CERTIFIED_BUILD_SHA256, "prim_v01.py build options are not the certified ones"


def prim_slot(G, fields, gamma=5 / 3, backend="cpu", diag=False):
    f = fields
    return P.primitives(G, f["rho"], f["rho_vr"], f["rho_vphi"], f["rho_vz"], f["E"], f["Br"], f["Bphi"], f["Bz"], gamma=gamma, backend=backend, diag=diag)
