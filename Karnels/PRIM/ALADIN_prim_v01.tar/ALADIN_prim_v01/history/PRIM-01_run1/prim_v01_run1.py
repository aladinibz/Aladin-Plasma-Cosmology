# -*- coding: utf-8 -*-
"""
ALADIN PRIM v01 -- kernel 01 of the ALADIN native-cylindrical GPU MHD Driver: conserved -> primitive (and the inverse).

    primitives(G, rho, m_r, m_phi, m_z, E, Br, Bphi, Bz)  ->  dict(rho, vr, vphi, vz, p, flags[, p_err_bound])
    conserved(G, rho, vr, vphi, vz, p, Br, Bphi, Bz)       ->  dict(rho, m_r, m_phi, m_z, E, flags)

Contract (same grid contract as UCT_CURL v1.3 / UCT-EMF v02 / HLLD v05.1):
  * cell arrays (nr+2g, nphi+2g, nz+2g), z fastest; CT faces Br (nr+1+2g, ...), Bphi (.., nphi+1+2g, ..), Bz (..., nz+1+2g);
    every cell INCLUDING ghosts is converted (the caller fills ghosts of U and B first).
  * cell-centred B = average of the two CT faces (identical to hlld_v05.cell_B and uct_emf_v02 brc/bpc/bzc), so the
    magnetic energy removed here is the one the flux kernels see.
  * total energy E = p/(gamma-1) + |m|^2/(2 rho) + |B_c|^2/2   (normalised units, mu0 = 1, as the README benchmark).
  * one CUDA/C++ source: NVRTC on the GPU, g++/OpenMP on the CPU, REAL = double | float.  Floating-point contraction is OFF on
    both backends (-fmad=false / -ffp-contract=off) and the operation order is fixed, so GPU and CPU are bit-identical.

Per-cell flags (bits), primitives():
  1  REFUSED   rho <= 0, or any input (rho, m, E, the six B faces) not finite            -> rho, v, p all NaN
  2  REFUSED   internal energy E - K - M < 0 (E below kinetic + magnetic energy)          -> rho, v, p all NaN
  4  UNRESOLVED p carries fewer than 3 significant digits: the proven bound on its relative rounding error exceeds 1e-3.
               A WARNING, not a refusal: the values are returned (p >= 0).  Typical at very low beta.
  Refused cells are not repaired: PRIM never floors.  Floors / recovery are the Driver's decision (first_order_cells, dt
  rejection); the refused cells are exactly the cells the recovery loop must act on.

Pressure error bound b (returned as p_err_bound when diag=True; the flag-4 test uses it):
  with K = |m|^2/(2 rho), M = |B_c|^2/2, e = (E - K) - M (as computed) and u = unit roundoff,
      b = 8 u (E + K + M) / e        and the GUARANTEE is the absolute form   |p - p_exact| <= b * p
  (p_exact from the STORED inputs in exact arithmetic).  A first-order rounding analysis gives ~7u (E + K + M) on e plus u on
  the final product; the factor 8 is the bound used and is tested against an 80-bit oracle on every cell of PRIM-01.
  Relative to the exact pressure this means |p - p_exact| / p_exact <= b / (1 - b) whenever b < 1 (~b for small b).
  When b > 1e-3 (flag 4) p is reported but its relative accuracy is poor; when b >= 1 not even its magnitude is resolved.
  e = 0 gives b = +Inf (p = 0 has no relative accuracy).

conserved() flags: 1 REFUSED (rho <= 0, p < 0 or any input not finite) -> all outputs NaN.
"""
import os, ctypes, hashlib, subprocess, tempfile, numpy as np

VERSION = "prim v01 2026-11-20"

SRC = r"""
#ifdef PRIM_GPU
#define DEV __device__ __forceinline__
#define KERNEL extern "C" __global__
#define TID (blockIdx.x * blockDim.x + threadIdx.x)
#else
#define DEV static inline
#define KERNEL extern "C"
#endif
typedef REAL R;

// header-free IEEE helpers (NVRTC has no standard headers): x - x is 0 for finite x and NaN for +-Inf / NaN
DEV int fin(R x) { R y = x - x; return y == y; }
DEV R qnan() { R z = R(0); return z / z; }

// indices on the ghost-extended arrays, z fastest.  cell (i,j,k): NR x NP x NZ  (NR = nr+2g, ...)
DEV long long ic(int i, int j, int k, int NP, int NZ) { return ((long long)i * NP + j) * NZ + k; }

DEV void prim_one(long long t, int NR, int NP, int NZ,
                  const R* rho, const R* mr, const R* mp, const R* mz, const R* E,
                  const R* Br, const R* Bp, const R* Bz, R gm1, R u8,
                  R* o_rho, R* o_vr, R* o_vp, R* o_vz, R* o_p, R* o_bnd, int* flags, int want_bnd)
{
    int k = (int)(t % NZ); long long q = t / NZ; int j = (int)(q % NP); int i = (int)(q / NP);
    long long c = t;
    long long br0 = ((long long)i * NP + j) * NZ + k,       br1 = br0 + (long long)NP * NZ;        // Br  (NR+1, NP, NZ)
    long long bp0 = ((long long)i * (NP + 1) + j) * NZ + k, bp1 = bp0 + NZ;                        // Bphi (NR, NP+1, NZ)
    long long bz0 = ((long long)i * NP + j) * (NZ + 1) + k, bz1 = bz0 + 1;                         // Bz  (NR, NP, NZ+1)
    R d = rho[c], a = mr[c], b = mp[c], e = mz[c], en = E[c];
    R f0 = Br[br0], f1 = Br[br1], f2 = Bp[bp0], f3 = Bp[bp1], f4 = Bz[bz0], f5 = Bz[bz1];
    int ok = fin(d) && fin(a) && fin(b) && fin(e) && fin(en) && fin(f0) && fin(f1) && fin(f2) && fin(f3) && fin(f4) && fin(f5) && (d > R(0));
    if (!ok) {
        o_rho[c] = qnan(); o_vr[c] = qnan(); o_vp[c] = qnan(); o_vz[c] = qnan(); o_p[c] = qnan();
        if (want_bnd) o_bnd[c] = qnan();
        flags[c] = 1; return;
    }
    R vr = a / d, vp = b / d, vz = e / d;
    R K = R(0.5) * (((a * a) + (b * b)) + (e * e)) / d;
    R bcr = R(0.5) * (f0 + f1), bcp = R(0.5) * (f2 + f3), bcz = R(0.5) * (f4 + f5);
    R M = R(0.5) * (((bcr * bcr) + (bcp * bcp)) + (bcz * bcz));
    R ei = (en - K) - M;
    if (!(ei >= R(0)) || !fin(ei)) {
        o_rho[c] = qnan(); o_vr[c] = qnan(); o_vp[c] = qnan(); o_vz[c] = qnan(); o_p[c] = qnan();
        if (want_bnd) o_bnd[c] = qnan();
        flags[c] = 2; return;
    }
    R p = gm1 * ei;
    R scale = (en + K) + M;
    R bnd = (ei > R(0)) ? (u8 * scale) / ei : R(1) / R(0);
    int fl = (bnd > R(1e-3)) ? 4 : 0;
    o_rho[c] = d; o_vr[c] = vr; o_vp[c] = vp; o_vz[c] = vz; o_p[c] = p;
    if (want_bnd) o_bnd[c] = bnd;
    flags[c] = fl;
}

DEV void cons_one(long long t, int NR, int NP, int NZ,
                  const R* rho, const R* vr, const R* vp, const R* vz, const R* p,
                  const R* Br, const R* Bp, const R* Bz, R gm1,
                  R* o_rho, R* o_mr, R* o_mp, R* o_mz, R* o_E, int* flags)
{
    int k = (int)(t % NZ); long long q = t / NZ; int j = (int)(q % NP); int i = (int)(q / NP);
    long long c = t;
    long long br0 = ((long long)i * NP + j) * NZ + k,       br1 = br0 + (long long)NP * NZ;
    long long bp0 = ((long long)i * (NP + 1) + j) * NZ + k, bp1 = bp0 + NZ;
    long long bz0 = ((long long)i * NP + j) * (NZ + 1) + k, bz1 = bz0 + 1;
    R d = rho[c], a = vr[c], b = vp[c], e = vz[c], pp = p[c];
    R f0 = Br[br0], f1 = Br[br1], f2 = Bp[bp0], f3 = Bp[bp1], f4 = Bz[bz0], f5 = Bz[bz1];
    int ok = fin(d) && fin(a) && fin(b) && fin(e) && fin(pp) && fin(f0) && fin(f1) && fin(f2) && fin(f3) && fin(f4) && fin(f5) && (d > R(0)) && (pp >= R(0));
    if (!ok) { o_rho[c] = qnan(); o_mr[c] = qnan(); o_mp[c] = qnan(); o_mz[c] = qnan(); o_E[c] = qnan(); flags[c] = 1; return; }
    R ma = d * a, mb = d * b, me = d * e;
    R K = R(0.5) * (((ma * a) + (mb * b)) + (me * e));
    R bcr = R(0.5) * (f0 + f1), bcp = R(0.5) * (f2 + f3), bcz = R(0.5) * (f4 + f5);
    R M = R(0.5) * (((bcr * bcr) + (bcp * bcp)) + (bcz * bcz));
    o_rho[c] = d; o_mr[c] = ma; o_mp[c] = mb; o_mz[c] = me; o_E[c] = ((pp / gm1) + K) + M; flags[c] = 0;
}

#ifdef PRIM_GPU
KERNEL void prim_kernel(const R* rho, const R* mr, const R* mp, const R* mz, const R* E, const R* Br, const R* Bp, const R* Bz,
                        R* o_rho, R* o_vr, R* o_vp, R* o_vz, R* o_p, R* o_bnd, int* flags,
                        int NR, int NP, int NZ, R gm1, R u8, int want_bnd, long long ntot)
{ long long t = TID; if (t < ntot) prim_one(t, NR, NP, NZ, rho, mr, mp, mz, E, Br, Bp, Bz, gm1, u8, o_rho, o_vr, o_vp, o_vz, o_p, o_bnd, flags, want_bnd); }
KERNEL void cons_kernel(const R* rho, const R* vr, const R* vp, const R* vz, const R* p, const R* Br, const R* Bp, const R* Bz,
                        R* o_rho, R* o_mr, R* o_mp, R* o_mz, R* o_E, int* flags, int NR, int NP, int NZ, R gm1, long long ntot)
{ long long t = TID; if (t < ntot) cons_one(t, NR, NP, NZ, rho, vr, vp, vz, p, Br, Bp, Bz, gm1, o_rho, o_mr, o_mp, o_mz, o_E, flags); }
#else
KERNEL void prim_cpu(const R* rho, const R* mr, const R* mp, const R* mz, const R* E, const R* Br, const R* Bp, const R* Bz,
                     R* o_rho, R* o_vr, R* o_vp, R* o_vz, R* o_p, R* o_bnd, int* flags,
                     int NR, int NP, int NZ, R gm1, R u8, int want_bnd, long long ntot)
{
    #pragma omp parallel for schedule(static)
    for (long long t = 0; t < ntot; ++t) prim_one(t, NR, NP, NZ, rho, mr, mp, mz, E, Br, Bp, Bz, gm1, u8, o_rho, o_vr, o_vp, o_vz, o_p, o_bnd, flags, want_bnd);
}
KERNEL void cons_cpu(const R* rho, const R* vr, const R* vp, const R* vz, const R* p, const R* Br, const R* Bp, const R* Bz,
                     R* o_rho, R* o_mr, R* o_mp, R* o_mz, R* o_E, int* flags, int NR, int NP, int NZ, R gm1, long long ntot)
{
    #pragma omp parallel for schedule(static)
    for (long long t = 0; t < ntot; ++t) cons_one(t, NR, NP, NZ, rho, vr, vp, vz, p, Br, Bp, Bz, gm1, o_rho, o_mr, o_mp, o_mz, o_E, flags);
}
#endif
"""

SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()
GPU_OPTIONS = ("-DPRIM_GPU", "-std=c++14", "-fmad=false")
CPU_FLAGS = ("-O2", "-ffp-contract=off", "-shared", "-fPIC")
BUILD_SHA256 = hashlib.sha256((SRC + "|" + " ".join(GPU_OPTIONS) + "|" + " ".join(CPU_FLAGS)).encode()).hexdigest()
BOUND_FACTOR = 8            # bound = BOUND_FACTOR * u * (E + K + M) / e,  u = unit roundoff of REAL
UNRESOLVED_THRESHOLD = 1e-3
_cache = {}


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


def _cpu_lib(dtype):
    real = "double" if dtype == np.float64 else "float"
    if ("cpu", real) in _cache: return _cache[("cpu", real)]
    d = os.path.join(tempfile.gettempdir(), "prim_v01_" + hashlib.sha256((BUILD_SHA256 + real).encode()).hexdigest()[:16])
    os.makedirs(d, exist_ok=True); so = os.path.join(d, "prim1.so")
    if not os.path.exists(so):
        open(os.path.join(d, "prim.cpp"), "w").write(SRC)
        cmd = ["g++", *CPU_FLAGS, "-fopenmp", f"-DREAL={real}", "-o", so, os.path.join(d, "prim.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError(r.stderr)
    lib = ctypes.CDLL(so); _cache[("cpu", real)] = lib; return lib


def _gpu_mod(dtype):
    import cupy as cp
    real = "double" if dtype == np.float64 else "float"
    if ("gpu", real) not in _cache:
        _cache[("gpu", real)] = cp.RawModule(code=SRC, options=(*GPU_OPTIONS, f"-DREAL={real}"))
    return _cache[("gpu", real)]


class Grid:
    """Identical to uct_emf_v02.Grid / hlld_v05.Grid (ghost-extended radii; axis grid iff r_faces[g] == 0)."""

    def __init__(self, nr, nphi, nz, rmin, rmax, zlen=1.0, g=2, dtype=np.float64, xp=np):
        self.nr, self.nphi, self.nz, self.g, self.dtype, self.xp = nr, nphi, nz, g, dtype, xp
        self.dr = (rmax - rmin) / nr; self.dphi = 2 * np.pi / nphi; self.dz = zlen / nz; self.rmin = rmin
        rf = rmin + (np.arange(nr + 1 + 2 * g) - g) * self.dr
        if rmin == 0: rf[g] = 0.0
        self.r_faces = rf; self.r_centers = 0.5 * (rf[:-1] + rf[1:])
        self.phi_c = (np.arange(nphi + 2 * g) - g + 0.5) * self.dphi; self.phi_f = (np.arange(nphi + 1 + 2 * g) - g) * self.dphi
        self.z_c = (np.arange(nz + 2 * g) - g + 0.5) * self.dz; self.z_f = (np.arange(nz + 1 + 2 * g) - g) * self.dz
        self.axis = rmin == 0

    def shape(self, kind):
        n, p, z, g = self.nr, self.nphi, self.nz, self.g
        return dict(cell=(n + 2 * g, p + 2 * g, z + 2 * g), Br=(n + 1 + 2 * g, p + 2 * g, z + 2 * g), Bphi=(n + 2 * g, p + 1 + 2 * g, z + 2 * g),
                    Bz=(n + 2 * g, p + 2 * g, z + 1 + 2 * g))[kind]

    def zeros(self, kind):
        return self.xp.zeros(self.shape(kind), dtype=self.dtype)


def cell_B(G, Br, Bphi, Bz):
    """cell-centred B as the average of the two CT faces (identical to hlld_v05.cell_B)"""
    return 0.5 * (Br[:-1] + Br[1:]), 0.5 * (Bphi[:, :-1] + Bphi[:, 1:]), 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])


def _check(G, arrs, kinds):
    for a, k in zip(arrs, kinds):
        if tuple(a.shape) != tuple(G.shape(k)): raise ValueError(f"array of shape {a.shape} does not match {k} {G.shape(k)}")


def _launch(G, backend, name, ins, nout, scalars, want_bnd=None):
    xp = G.xp; dt = G.dtype; sc = np.float64 if dt == np.float64 else np.float32
    NR, NP, NZ = G.shape("cell"); ntot = NR * NP * NZ
    ins = [xp.ascontiguousarray(a.astype(dt)) for a in ins]
    outs = [xp.empty((NR, NP, NZ), dtype=dt) for _ in range(nout)]; fl = xp.empty((NR, NP, NZ), dtype=np.int32)
    tail = [np.int32(NR), np.int32(NP), np.int32(NZ)] + [sc(s) for s in scalars] + ([] if want_bnd is None else [np.int32(want_bnd)]) + [np.int64(ntot)]
    if backend == "cupy":
        k = _gpu_mod(dt).get_function(name + "_kernel")
        k(((ntot + 127) // 128,), (128,), (*ins, *outs, fl, *tail))
    else:
        lib = _cpu_lib(dt); f = getattr(lib, name + "_cpu")
        cr = ctypes.c_double if dt == np.float64 else ctypes.c_float
        args = [a.ctypes.data_as(ctypes.c_void_p) for a in ins + outs + [fl]]
        cargs = [ctypes.c_int(int(x)) for x in tail[:3]] + [cr(float(s)) for s in tail[3:3 + len(scalars)]]
        if want_bnd is not None: cargs.append(ctypes.c_int(int(want_bnd)))
        cargs.append(ctypes.c_longlong(int(ntot)))
        f.restype = None; f(*args, *cargs)
    return outs, fl


def primitives(G, rho, m_r, m_phi, m_z, E, Br, Bphi, Bz, gamma=5 / 3, backend="cpu", diag=False):
    """conserved -> primitive on every cell (ghosts included).  Returns dict(rho, vr, vphi, vz, p, flags[, p_err_bound])."""
    _check(G, (rho, m_r, m_phi, m_z, E, Br, Bphi, Bz), ("cell",) * 5 + ("Br", "Bphi", "Bz"))
    dt = G.dtype; u = float(np.finfo(dt).eps) / 2
    gm1 = (np.asarray(gamma, dtype=dt) - np.asarray(1, dtype=dt))
    outs, fl = _launch(G, backend, "prim", (rho, m_r, m_phi, m_z, E, Br, Bphi, Bz), 6, (gm1, BOUND_FACTOR * u), want_bnd=1 if diag else 0)
    r = dict(rho=outs[0], vr=outs[1], vphi=outs[2], vz=outs[3], p=outs[4], flags=fl)
    if diag: r["p_err_bound"] = outs[5]
    return r


def conserved(G, rho, vr, vphi, vz, p, Br, Bphi, Bz, gamma=5 / 3, backend="cpu"):
    """primitive -> conserved on every cell.  Returns dict(rho, m_r, m_phi, m_z, E, flags)."""
    _check(G, (rho, vr, vphi, vz, p, Br, Bphi, Bz), ("cell",) * 5 + ("Br", "Bphi", "Bz"))
    dt = G.dtype; gm1 = (np.asarray(gamma, dtype=dt) - np.asarray(1, dtype=dt))
    outs, fl = _launch(G, backend, "cons", (rho, vr, vphi, vz, p, Br, Bphi, Bz), 5, (gm1,))
    return dict(rho=outs[0], m_r=outs[1], m_phi=outs[2], m_z=outs[3], E=outs[4], flags=fl)
