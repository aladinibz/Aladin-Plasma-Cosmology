# -*- coding: utf-8 -*-
"""PRIM-01 sanitizer target: primitives() (diag on/off) and conserved() on 6 grids incl. partial blocks and a 1-cell-wide
grid, FP64 + FP32, every path: admitted, unresolved (flag 4), refused (flags 1 and 2: rho <= 0, NaN / Inf in cells and faces,
E below K + M), and e = 0.   python sanitizer_target_prim01.py [cpu]"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prim_v01 as P
BK = "cpu" if (len(sys.argv) > 1 and sys.argv[1] == "cpu") else "cupy"
if BK == "cupy": import cupy as cp
T = (lambda x: cp.asarray(x)) if BK == "cupy" else (lambda x: x)
H = lambda x: x.get() if hasattr(x, "get") else x
rng = np.random.default_rng(7); seen = {}
for dt in (np.float64, np.float32):
    for rmin, s in ((0.4, (7, 10, 5)), (0.0, (13, 18, 11)), (0.0, (1, 4, 2)), (0.4, (31, 6, 9)), (0.4, (40, 33, 17)), (0.0, (1, 1, 1))):
        G = P.Grid(*s, rmin, 1.3, dtype=dt, xp=cp) if BK == "cupy" else P.Grid(*s, rmin, 1.3, dtype=dt); sh = G.shape("cell")
        rho = rng.uniform(0.5, 2, sh); m = [rng.normal(size=sh) for _ in range(3)]; B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]
        K = sum(x ** 2 for x in m) / (2 * rho); bc = P.cell_B(G, *B); M = sum(x ** 2 for x in bc) / 2
        e = rng.uniform(0.1, 1, sh); e[rng.uniform(size=sh) < 0.1] = 1e-9; e[rng.uniform(size=sh) < 0.05] = -0.1; E = K + M + e
        bad = rng.uniform(size=sh); rho[bad < 0.02] = -1; m[1][(bad > 0.02) & (bad < 0.03)] = np.nan; E[(bad > 0.03) & (bad < 0.035)] = np.inf
        B[2][rng.uniform(size=G.shape("Bz")) < 0.01] = np.nan
        args = [T(x.astype(dt)) for x in [rho, *m, E, *B]]
        for diag in (False, True):
            r = P.primitives(G, *args, backend=BK, diag=diag); f = H(r["flags"])
            for v in np.unique(f): seen[int(v)] = seen.get(int(v), 0) + int((f == v).sum())
        pr = [T(x.astype(dt)) for x in [rng.uniform(.5, 2, sh), *[rng.normal(size=sh) for _ in range(3)], rng.uniform(-0.1, 1, sh)]]
        c = P.conserved(G, *pr, *args[5:], backend=BK)
        if BK == "cupy": cp.cuda.Device().synchronize()
print("flag counts seen:", seen); assert all(k in seen for k in (0, 1, 2, 4)), "a path was not exercised"
print("SANITIZER TARGET DONE")
