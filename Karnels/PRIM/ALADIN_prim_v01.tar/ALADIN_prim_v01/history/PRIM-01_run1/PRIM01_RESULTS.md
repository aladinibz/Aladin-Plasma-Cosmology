# PRIM-01 results: ALADIN PRIM v01

Made 2026-11-20 16:28 UTC.  Source hash frozen and identical on all legs: **True**

- cpu leg kernel sha256 `3eece99e9f8d61e1bf9edc8eb717ef440b4f1c04016bfd4786629661bee06412`, build sha256 `a94c182593132140be3d0e4c725feafc45b90d57e1153b7c5799729321f9aae3` (source of record: leg JSON)
- gpu leg kernel sha256 `3eece99e9f8d61e1bf9edc8eb717ef440b4f1c04016bfd4786629661bee06412`, build sha256 `a94c182593132140be3d0e4c725feafc45b90d57e1153b7c5799729321f9aae3` (source of record: leg JSON)

| Test | Final | cpu | gpu |
|---|---|---|---|
| P01 | VERIFIED | VERIFIED | VERIFIED |
| P02 | VERIFIED | VERIFIED | VERIFIED |
| P03 | VERIFIED | VERIFIED | VERIFIED |
| P04 | VERIFIED | VERIFIED | VERIFIED |
| P05 | VERIFIED | VERIFIED | VERIFIED |
| P06 | VERIFIED | VERIFIED | VERIFIED |
| P07 | VERIFIED | VERIFIED | VERIFIED |
| P08 | VERIFIED | VERIFIED | VERIFIED |
| P09 | VERIFIED | VERIFIED | VERIFIED |
| G1 | VERIFIED | — | VERIFIED |
| G2 | VERIFIED | — | VERIFIED |
| G3 | VERIFIED | — | VERIFIED |
| G4 | VERIFIED | — | VERIFIED |
| M1_memcheck | VERIFIED |  |  |
| M2_racecheck | VERIFIED |  |  |

Counts: {'VERIFIED': 15}

## Checks (measured vs predeclared threshold)

- P01 [cpu] velocity values not correctly rounded: 0.0000e+00 <= 0.0e+00 -> pass
- P01 [gpu] velocity values not correctly rounded: 0.0000e+00 <= 0.0e+00 -> pass
- P02 [cpu] density values changed: 0.0000e+00 <= 0.0e+00 -> pass
- P02 [gpu] density values changed: 0.0000e+00 <= 0.0e+00 -> pass
- P03 [cpu] max |p - p_exact| / (b p): 3.1906e-01 <= 1.0e+00 -> pass
- P03 [cpu] flag-2 sign disagreements outside the bound zone: 0.0000e+00 <= 0.0e+00 -> pass
- P03 [gpu] max |p - p_exact| / (b p): 3.1906e-01 <= 1.0e+00 -> pass
- P03 [gpu] flag-2 sign disagreements outside the bound zone: 0.0000e+00 <= 0.0e+00 -> pass
- P04 [cpu] flag-4 cells inconsistent with the returned bound: 0.0000e+00 <= 0.0e+00 -> pass
- P04 [cpu] max measured rel error of p in unflagged cells: 2.1586e-04 <= 1.0e-03 -> pass
- P04 [gpu] flag-4 cells inconsistent with the returned bound: 0.0000e+00 <= 0.0e+00 -> pass
- P04 [gpu] max measured rel error of p in unflagged cells: 2.1586e-04 <= 1.0e-03 -> pass
- P05 [cpu] cells whose flag-1 status differs from the rule: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [cpu] non-NaN outputs on refused cells: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [cpu] changes outside the refused cells (+ bad faces not refusing exactly 2 cells): 0.0000e+00 <= 0.0e+00 -> pass
- P05 [gpu] cells whose flag-1 status differs from the rule: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [gpu] non-NaN outputs on refused cells: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [gpu] changes outside the refused cells (+ bad faces not refusing exactly 2 cells): 0.0000e+00 <= 0.0e+00 -> pass
- P06 [cpu] cells mis-classified around e = 0: 0.0000e+00 <= 0.0e+00 -> pass
- P06 [cpu] e = 0 admitted (p = 0, flag 4, bound = Inf): 1.0000e+00 == 1.0e+00 -> pass
- P06 [gpu] cells mis-classified around e = 0: 0.0000e+00 <= 0.0e+00 -> pass
- P06 [gpu] e = 0 admitted (p = 0, flag 4, bound = Inf): 1.0000e+00 == 1.0e+00 -> pass
- P07 [cpu] conserved(): max rel error of m in units of u: 9.9548e-01 <= 1.0e+00 -> pass
- P07 [cpu] conserved(): max rel error of E in units of u: 3.7804e+00 <= 8.0e+00 -> pass
- P07 [cpu] round trip: max |p' - p| / (b p'): 3.5347e-01 <= 2.0e+00 -> pass
- P07 [gpu] conserved(): max rel error of m in units of u: 9.9548e-01 <= 1.0e+00 -> pass
- P07 [gpu] conserved(): max rel error of E in units of u: 3.7804e+00 <= 8.0e+00 -> pass
- P07 [gpu] round trip: max |p' - p| / (b p'): 3.5347e-01 <= 2.0e+00 -> pass
- P08 [cpu] max |p - (P0 - r^2/4)|: 1.1102e-16 <= 1.0e-14 -> pass
- P08 [cpu] max |v|: 0.0000e+00 <= 0.0e+00 -> pass
- P08 [cpu] HLLD radial mass + energy flux from PRIM output: 0.0000e+00 <= 1.0e-14 -> pass
- P08 [gpu] max |p - (P0 - r^2/4)|: 1.1102e-16 <= 1.0e-14 -> pass
- P08 [gpu] max |v|: 0.0000e+00 <= 0.0e+00 -> pass
- P08 [gpu] HLLD radial mass + energy flux from PRIM output: 0.0000e+00 <= 1.0e-14 -> pass
- P09 [cpu] flag 4 reached in FP64 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P09 [cpu] flag 4 reached in FP32 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P09 [gpu] flag 4 reached in FP64 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P09 [gpu] flag 4 reached in FP32 sweep: 1.0000e+00 == 1.0e+00 -> pass
- G1 [gpu] GPU values differing from CPU: 0.0000e+00 <= 0.0e+00 -> pass
- G2 [gpu] differing values: 0.0000e+00 <= 0.0e+00 -> pass
- G3 [gpu] max |p - p_exact| / (b p) (GPU): 3.0202e-01 <= 1.0e+00 -> pass
- G4 [gpu] timings finite: 1.0000e+00 == 1.0e+00 -> pass
- M1_memcheck: VERIFIED ========= ERROR SUMMARY: 0 errors
- M2_racecheck: VERIFIED ========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)
