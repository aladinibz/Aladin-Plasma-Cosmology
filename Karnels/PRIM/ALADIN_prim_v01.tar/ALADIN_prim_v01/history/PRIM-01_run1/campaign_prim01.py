# -*- coding: utf-8 -*-
"""
ALADIN PRIM v01 -- certification campaign PRIM-01.   python campaign_prim01.py cpu | gpu
Frozen kernel (source + build hashes checked).  Thresholds PREDECLARED in THRESHOLDS.  Classes VERIFIED / LIMITATION /
INCONCLUSIVE / BLOCKER.  Writes prim01_<leg>_results.json and prim01_<leg>.log.
"""
import sys, os, time, json, copy, hashlib, platform, datetime, traceback, subprocess, warnings
from fractions import Fraction
import numpy as np
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import prim_v01 as P
import numpy_oracle_prim as O

FROZEN_SHA = "3eece99e9f8d61e1bf9edc8eb717ef440b4f1c04016bfd4786629661bee06412"
FROZEN_BUILD = "a94c182593132140be3d0e4c725feafc45b90d57e1153b7c5799729321f9aae3"
GAM = 5 / 3
LD = np.longdouble

THRESHOLDS = dict(
    P01_velocity_misrounded=0.0, P02_density_changed=0.0,
    P03_bound_ratio=1.0, P03_sign_disagreements_outside_bound=0.0,
    P04_flag4_inconsistent=0.0, P04_unflagged_err=1e-3,
    P05_refusal_mismatch=0.0, P05_refused_not_nan=0.0, P05_locality=0.0,
    P06_negative_e_mismatch=0.0, P06_zero_e_admitted=1.0,
    P07_cons_m_rel=1.0, P07_cons_E_rel=8.0, P07_roundtrip_ratio=2.0,
    P08_pinch_p_fp64=1e-14, P08_pinch_v=0.0, P08_pinch_hlld_flux=1e-14,
    P09_flag4_present_fp64=1.0, P09_flag4_present_fp32=1.0,
    G1_gpu_cpu_bitwise=0.0, G2_determinism=0.0, G3_gpu_bound_ratio=1.0,
)

LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
BACKEND = "cupy" if LEG == "gpu" else "cpu"
LOG = None
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True)
    if LOG: LOG.write(s + "\n"); LOG.flush()
if BACKEND == "cupy": import cupy as cp
def dev(G):
    if BACKEND != "cupy": return G
    X = copy.copy(G); X.xp = cp; return X
to = (lambda x: cp.asarray(x)) if BACKEND == "cupy" else (lambda x: x)
host = lambda x: x.get() if hasattr(x, "get") else x

def prim(G, U, B, dt=None, diag=True, backend=None):
    r = P.primitives(dev(G) if (backend or BACKEND) == "cupy" else G, *[to(x) if (backend or BACKEND) == "cupy" else x for x in U + B], gamma=GAM,
                     backend=backend or BACKEND, diag=diag)
    return {k: host(v) for k, v in r.items()}

# ------------------------------------------------------------------ state generator: wide regimes
def regime_state(G, rng, dt, beta_lo=-12, beta_hi=6, cancel=0.3):
    """conserved state + CT faces on G: log-uniform rho in [1e-8, 1e8], beta in [10^beta_lo, 10^beta_hi], Mach in [1e-3, 1e3];
    a fraction `cancel` of face pairs have opposite signs (cancellation inside the cell average).  E rounded from long double."""
    sh = G.shape("cell")
    B = []
    for k in ("Br", "Bphi", "Bz"):
        s = G.shape(k); mag = 10 ** rng.uniform(-3, 3, s); sg = np.where(rng.uniform(size=s) < 0.5, -1, 1); B.append((mag * sg).astype(dt))
    for ax, k in enumerate(("Br", "Bphi", "Bz")):                                    # cancelling pairs
        b = B[ax]; m = rng.uniform(size=b.shape) < cancel; sl = [slice(None)] * 3; sl[ax] = slice(1, None); sl2 = [slice(None)] * 3; sl2[ax] = slice(None, -1)
        nb = b.copy(); nb[tuple(sl)] = np.where(m[tuple(sl2)], -b[tuple(sl2)] * rng.uniform(0.9, 1.1, b[tuple(sl2)].shape), b[tuple(sl)]); B[ax] = nb.astype(dt)
    bc = O.cellB(*(x.astype(LD) for x in B)); M = (bc[0] ** 2 + bc[1] ** 2 + bc[2] ** 2) / 2
    rho = (10 ** rng.uniform(-8, 8, sh)).astype(dt)
    beta = 10 ** rng.uniform(beta_lo, beta_hi, sh); p = LD(1) * beta * np.maximum(M, LD(1e-30)); p = np.maximum(p, LD(1e-30))
    cs = np.sqrt(np.asarray(GAM * p / rho.astype(LD), np.float64)); mach = 10 ** rng.uniform(-3, 3, sh)
    v = [(cs * mach * rng.normal(size=sh) / np.sqrt(3)) for _ in range(3)]
    m = [(rho.astype(LD) * x).astype(dt) for x in v]
    K = (m[0].astype(LD) ** 2 + m[1].astype(LD) ** 2 + m[2].astype(LD) ** 2) / (2 * rho.astype(LD))
    E = (p / LD(GAM - 1) + K + M).astype(dt)
    return [rho, *m, E], B

def gst(dt): return np.asarray(GAM, dt)

# ------------------------------------------------------------------ tests
def P01():
    """velocity = correctly rounded m / rho (adjudicated in exact rational arithmetic where the long-double oracle disagrees)"""
    rng = np.random.default_rng(101); bad = 0; tot = 0; adjud = 0
    for dt in (np.float64, np.float32):
        for _ in range(4):
            G = P.Grid(40, 32, 40, rng.choice([0.0, 0.3]), 1.2, dtype=dt); U, B = regime_state(G, rng, dt); r = prim(G, U, B)
            ok = (r["flags"] == 0) | (r["flags"] == 4)
            for comp, m in (("vr", U[1]), ("vphi", U[2]), ("vz", U[3])):
                ex = (m.astype(LD) / U[0].astype(LD)).astype(dt); diff = ok & (r[comp] != ex); tot += int(ok.sum())
                for idx in zip(*np.nonzero(diff)):                         # adjudicate exactly
                    adjud += 1; q = Fraction(float(m[idx])) / Fraction(float(U[0][idx])); v = r[comp][idx]
                    lo, hi = np.nextafter(v, dt(-np.inf)), np.nextafter(v, dt(np.inf))
                    dv = abs(Fraction(float(v)) - q)
                    if dv > abs(Fraction(float(lo)) - q) or dv > abs(Fraction(float(hi)) - q): bad += 1
    return dict(conditions="8 grids (annulus + axis), FP64 + FP32, regimes rho 1e-8..1e8, beta 1e-12..1e6, Mach 1e-3..1e3", values=tot,
                ld_disagreements_adjudicated=adjud), [("velocity values not correctly rounded", float(bad), "<=", THRESHOLDS["P01_velocity_misrounded"])]

def P02():
    rng = np.random.default_rng(102); ch = 0
    for dt in (np.float64, np.float32):
        G = P.Grid(12, 10, 14, 0.0, 1.0, dtype=dt); U, B = regime_state(G, rng, dt); r = prim(G, U, B); ok = (r["flags"] == 0) | (r["flags"] == 4)
        ch += int((r["rho"][ok] != U[0][ok]).sum())
    return dict(conditions="admissible cells: rho returned bit for bit"), [("density values changed", float(ch), "<=", THRESHOLDS["P02_density_changed"])]

def bound_check(backend, seed):
    rng = np.random.default_rng(seed); worst = 0.0; rows = []; sign_out = 0; sign_in = 0; nvals = 0
    for dt in (np.float64, np.float32):
        u = float(np.finfo(dt).eps) / 2; ratios = []
        for rep in range(6):
            G = P.Grid(40, 32, 40, [0.0, 0.25][rep % 2], 1.1, dtype=dt); U, B = regime_state(G, rng, dt); r = prim(G, U, B, backend=backend)
            ex = O.exact_prim(*U, *B, gst(dt)); e_ex = ex["e"]; scale = ex["E"] + ex["K"] + ex["M"]
            adm = r["flags"] != 1
            f2 = r["flags"] == 2; neg = e_ex < 0
            mism = adm & (f2 != neg); zone = np.abs(e_ex) <= 8 * u * scale
            sign_out += int((mism & ~zone).sum()); sign_in += int((mism & zone).sum())
            ok = adm & ~f2 & (r["p"] > 0)                                   # every admitted cell, whatever the sign of the exact e
            err = np.abs(r["p"][ok].astype(LD) - ex["p"][ok]); bnd = r["p_err_bound"][ok].astype(LD) * r["p"][ok].astype(LD)
            rat = np.asarray(err / bnd, np.float64); ratios.append(rat); nvals += int(ok.sum())
        R_ = np.concatenate(ratios); worst = max(worst, float(R_.max()))
        rows.append(dict(dtype=np.dtype(dt).name, cells=int(R_.size), worst_ratio=float(R_.max()), median_ratio=float(np.median(R_)), q999_ratio=float(np.quantile(R_, 0.999))))
    return worst, sign_out, sign_in, rows, nvals

def P03():
    worst, so, si, rows, n = bound_check(BACKEND, 103)
    return dict(conditions="12 grids, FP64 + FP32, rho 1e-8..1e8, beta 1e-12..1e6, Mach 1e-3..1e3, 30 % cancelling face pairs; exact p from the stored inputs in 80-bit; guarantee tested: |p - p_exact| <= b p on every admitted cell with p > 0",
                rows=rows, admissible_cells=n, sign_disagreements_inside_bound_zone=si,
                note="a cell whose exact internal energy lies within the rounding bound (|e| <= 8u(E+K+M)) may be refused (flag 2) or admitted: its sign is not resolvable in the working precision"), \
        [("max |p - p_exact| / (b p)", worst, "<=", THRESHOLDS["P03_bound_ratio"]), ("flag-2 sign disagreements outside the bound zone", float(so), "<=", THRESHOLDS["P03_sign_disagreements_outside_bound"])]

def P04():
    rng = np.random.default_rng(104); inc = 0; worst_unflagged = 0.0; nflag = {}
    for dt in (np.float64, np.float32):
        for rep in range(4):
            G = P.Grid(40, 32, 40, 0.0, 1.0, dtype=dt); U, B = regime_state(G, rng, dt); r = prim(G, U, B)
            adm = (r["flags"] == 0) | (r["flags"] == 4)
            inc += int(((r["flags"] == 4) != (r["p_err_bound"] > dt(1e-3)))[adm].sum())
            ex = O.exact_prim(*U, *B, gst(dt)); un = (r["flags"] == 0) & (ex["e"] > 0)
            if un.any(): worst_unflagged = max(worst_unflagged, float(np.max(np.abs(r["p"][un].astype(LD) - ex["p"][un]) / ex["p"][un])))
            nflag[np.dtype(dt).name] = nflag.get(np.dtype(dt).name, 0) + int((r["flags"] == 4).sum())
    return dict(conditions="flag 4 set iff the returned bound exceeds 1e-3; every unflagged cell has < 1e-3 measured relative error", flag4_cells=nflag), \
        [("flag-4 cells inconsistent with the returned bound", float(inc), "<=", THRESHOLDS["P04_flag4_inconsistent"]),
         ("max measured rel error of p in unflagged cells", worst_unflagged, "<=", THRESHOLDS["P04_unflagged_err"])]

def P05():
    rng = np.random.default_rng(105); mism = notnan = 0; loc = 0; cases = 0
    names = ["rho", "m_r", "m_phi", "m_z", "E", "Br", "Bphi", "Bz"]
    for dt in (np.float64, np.float32):
        G = P.Grid(8, 8, 8, 0.4, 1.2, dtype=dt); U0, B0 = regime_state(G, rng, dt, beta_lo=-1, beta_hi=2, cancel=0.0)
        r0 = prim(G, U0, B0)
        for vi, nm in enumerate(names):
            for val in ([np.nan, np.inf, -np.inf] + ([-1.0, 0.0, -1e-30] if nm == "rho" else [])):
                U = [x.copy() for x in U0]; B = [x.copy() for x in B0]
                arr = (U + B)[vi]; idx = tuple(int(rng.integers(2, s - 2)) for s in arr.shape); arr[idx] = dt(val); cases += 1
                r = prim(G, U, B); exp = O.rule_prim_refused(*U, *B)
                mism += int(((r["flags"] == 1) != exp).sum())
                notnan += int(sum((~np.isnan(r[k][exp])).sum() for k in ("rho", "vr", "vphi", "vz", "p")))
                other = ~exp
                loc += int(sum((r[k][other] != r0[k][other]).sum() for k in ("rho", "vr", "vphi", "vz", "p", "flags")))
                if vi >= 5:                                                      # a bad face must refuse exactly its two cells
                    if int(exp.sum()) != 2: loc += 1
    return dict(conditions="NaN / +Inf / -Inf in each of the 8 inputs (each of the 3 face arrays), rho = -1, 0, -1e-30; FP64 + FP32; expected set from the oracle rule",
                cases=cases), \
        [("cells whose flag-1 status differs from the rule", float(mism), "<=", THRESHOLDS["P05_refusal_mismatch"]),
         ("non-NaN outputs on refused cells", float(notnan), "<=", THRESHOLDS["P05_refused_not_nan"]),
         ("changes outside the refused cells (+ bad faces not refusing exactly 2 cells)", float(loc), "<=", THRESHOLDS["P05_locality"])]

def P06():
    mism = 0; zero_ok = True; rows = []
    for dt in (np.float64, np.float32):
        G = P.Grid(4, 4, 4, 0.5, 1.0, dtype=dt); sh = G.shape("cell")
        rho = np.full(sh, 2.0, dt); m = [np.zeros(sh, dt) for _ in range(3)]; m[0][:] = 2.0                 # K = 0.5*4/2 = 1 exactly
        B = [np.zeros(G.shape(k), dt) for k in ("Br", "Bphi", "Bz")]; B[2][:] = 1.0                          # B_c = (0,0,1): M = 0.5 exactly
        for E_val, expect in ((1.5, "zero"), (1.25, "neg"), (1.5 + 2 ** -10, "pos"), (np.nextafter(dt(1.5), dt(0)), "neg")):
            E = np.full(sh, E_val, dt); r = prim(G, [rho, *m, E], B)
            f = int(np.unique(r["flags"])[0]) if np.unique(r["flags"]).size == 1 else -1
            if expect == "neg": mism += int((r["flags"] != 2).sum()) + int((~np.isnan(r["p"])).sum())
            if expect == "zero": zero_ok &= bool((r["flags"] == 4).all() and (r["p"] == 0).all() and np.isinf(r["p_err_bound"]).all())
            if expect == "pos": mism += int((r["flags"] == 2).sum())
            rows.append(dict(dtype=np.dtype(dt).name, E=float(E_val), expect=expect, flag=f))
    return dict(conditions="exactly representable K = 1, M = 0.5: E = 1.5 (e = 0), E = 1.25 and E one ulp below 1.5 (e < 0), E = 1.5 + 2^-10 (e > 0)", rows=rows), \
        [("cells mis-classified around e = 0", float(mism), "<=", THRESHOLDS["P06_negative_e_mismatch"]),
         ("e = 0 admitted (p = 0, flag 4, bound = Inf)", float(zero_ok), "==", THRESHOLDS["P06_zero_e_admitted"])]

def P07():
    rng = np.random.default_rng(107); wm = wE = wr = 0.0; rows = []
    for dt in (np.float64, np.float32):
        u = float(np.finfo(dt).eps) / 2
        G = P.Grid(16, 12, 16, 0.0, 1.0, dtype=dt); sh = G.shape("cell")
        rho = (10 ** rng.uniform(-6, 6, sh)).astype(dt); v = [(rng.normal(size=sh) * 10 ** rng.uniform(-3, 3, sh)).astype(dt) for _ in range(3)]
        B = [(rng.normal(size=G.shape(k)) * 10 ** rng.uniform(-3, 3, G.shape(k))).astype(dt) for k in ("Br", "Bphi", "Bz")]
        p = (10 ** rng.uniform(-6, 6, sh)).astype(dt)
        c = P.conserved(dev(G), *[to(x) for x in [rho, *v, p, *B]], gamma=GAM, backend=BACKEND); c = {k: host(x) for k, x in c.items()}
        ex = O.exact_cons(rho, *v, p, *B, gst(dt))
        for k in ("m_r", "m_phi", "m_z"):
            nz = ex[k] != 0; wm = max(wm, float(np.max(np.abs(c[k][nz].astype(LD) - ex[k][nz]) / np.abs(ex[k][nz])) / u))
        wE = max(wE, float(np.max(np.abs(c["E"].astype(LD) - ex["E"]) / ex["E"]) / u))
        r = prim(G, [c["rho"], c["m_r"], c["m_phi"], c["m_z"], c["E"]], B); ok = (r["flags"] != 2) & (r["p"] > 0)
        ratio = np.abs(r["p"][ok].astype(LD) - p[ok].astype(LD)) / (r["p"][ok].astype(LD) * r["p_err_bound"][ok].astype(LD))
        wr = max(wr, float(np.max(ratio))); rows.append(dict(dtype=np.dtype(dt).name, refused_in_roundtrip=int((~ok).sum()), worst_roundtrip_over_bound=float(np.max(ratio))))
    return dict(conditions="primitive -> conserved vs 80-bit oracle (in units of u), and primitive -> conserved -> primitive p error over the returned bound; FP64 + FP32", rows=rows), \
        [("conserved(): max rel error of m in units of u", wm, "<=", THRESHOLDS["P07_cons_m_rel"]), ("conserved(): max rel error of E in units of u", wE, "<=", THRESHOLDS["P07_cons_E_rel"]),
         ("round trip: max |p' - p| / (b p')", wr, "<=", THRESHOLDS["P07_roundtrip_ratio"])]

def readme_pinch(dt, nr=32, nphi=16, nz=8, P0=1.0):
    G = P.Grid(nr, nphi, nz, 0.0, 1.0, dtype=dt); sh = G.shape("cell"); rc = G.r_centers[:, None, None] * np.ones(sh)
    Bp = np.zeros(G.shape("Bphi")); Bp[:] = (0.5 * G.r_centers)[:, None, None]; Bp = Bp.astype(dt)
    B = [np.zeros(G.shape("Br"), dt), Bp, np.zeros(G.shape("Bz"), dt)]
    p_ex = P0 - rc ** 2 / 4; rho = np.ones(sh, dt); m = [np.zeros(sh, dt) for _ in range(3)]
    E = (p_ex.astype(LD) / LD(gst(dt) - 1) + (0.5 * rc.astype(LD) / 1) ** 2 / 2 * 1).astype(dt)    # B_c = B_phi(r_c) = r_c / 2
    return G, [rho, *m, E], B, p_ex

def P08():
    out = {}
    G, U, B, p_ex = readme_pinch(np.float64); r = prim(G, U, B); g = G.g
    I = (slice(g, g + G.nr), slice(None), slice(None))
    perr = float(np.max(np.abs(r["p"][I] - p_ex[I]))); verr = float(max(np.abs(r[k]).max() for k in ("vr", "vphi", "vz")))
    hl = 0.0
    try:
        sys.path.insert(0, os.path.join(HERE, "benchmark")); import hlld_v05 as H
        Gh = H.Grid(G.nr, G.nphi, G.nz, 0.0, 1.0); prims = [r[k] for k in ("rho", "vr", "vphi", "vz", "p")]
        Weq = H.pack(Gh, np.ones_like(p_ex), *(np.zeros_like(p_ex),) * 3, p_ex, *B)
        F, fl = H.fluxes(Gh, *prims, *B, W_eq=Weq, backend="cpu", directions=(0,))
        hl = float(max(np.abs(F[0][0]).max(), np.abs(F[0][4]).max())); out["hlld_sha"] = H.SOURCE_SHA256
    except Exception as x:
        out["hlld_error"] = repr(x); hl = float("inf")
    out.update(p_max_abs_err=perr, v_max=verr, hlld_mass_energy_flux=hl)
    return dict(conditions="README normalised Z-pinch (mu0 = 1): B_phi = r/2 on the phi faces, rho = 1, v = 0, P = 1 - r^2/4, axis grid 32x16x8, FP64; "
                           "PRIM output fed to HLLD v05.1 (radial faces, well-balanced with the exact equilibrium)", **out), \
        [("max |p - (P0 - r^2/4)|", perr, "<=", THRESHOLDS["P08_pinch_p_fp64"]), ("max |v|", verr, "<=", THRESHOLDS["P08_pinch_v"]),
         ("HLLD radial mass + energy flux from PRIM output", hl, "<=", THRESHOLDS["P08_pinch_hlld_flux"])]

def P09():
    """low-beta honesty: a uniform cold plasma in a strong field, beta swept down; where does p lose its digits?"""
    rows = []; present = {}
    for dt in (np.float64, np.float32):
        u = float(np.finfo(dt).eps) / 2
        for lb in range(0, -17, -2):
            G = P.Grid(4, 4, 4, 0.5, 1.0, dtype=dt); sh = G.shape("cell"); rng = np.random.default_rng(900 + lb)
            Bz = np.full(G.shape("Bz"), 1.0, dt); B = [np.zeros(G.shape("Br"), dt), np.zeros(G.shape("Bphi"), dt), Bz]
            p = 0.5 * 10.0 ** lb * (1 + 0.01 * rng.normal(size=sh)); rho = np.ones(sh, dt); m = [(0.1 * rng.normal(size=sh)).astype(dt) for _ in range(3)]
            K = sum(x.astype(LD) ** 2 for x in m) / 2; E = (p.astype(LD) / LD(gst(dt) - 1) + K + LD(0.5)).astype(dt)
            r = prim(G, [rho, *m, E], B); ex = O.exact_prim(rho, *m, E, *B, gst(dt)); ok = (r["flags"] != 2) & (ex["e"] > 0)
            err = float(np.median(np.abs(r["p"][ok].astype(LD) - ex["p"][ok]) / ex["p"][ok])) if ok.any() else float("nan")
            rows.append(dict(dtype=np.dtype(dt).name, beta=10.0 ** lb, flag4_fraction=float((r["flags"] == 4).mean()), flag2_fraction=float((r["flags"] == 2).mean()),
                             median_measured_rel_err=err, median_bound=float(np.median(r["p_err_bound"][r["flags"] != 2])) if (r["flags"] != 2).any() else float("nan")))
            if (r["flags"] == 4).any(): present[np.dtype(dt).name] = True
    return dict(conditions="uniform plasma, |B| = 1, small random flow, beta = 1 ... 1e-16 (measurement)", rows=rows), \
        [("flag 4 reached in FP64 sweep", float(present.get("float64", False)), "==", THRESHOLDS["P09_flag4_present_fp64"]),
         ("flag 4 reached in FP32 sweep", float(present.get("float32", False)), "==", THRESHOLDS["P09_flag4_present_fp32"])]

def G1():
    rng = np.random.default_rng(201); diff = 0; tot = 0
    for dt in (np.float64, np.float32):
        for rep in range(4):
            G = P.Grid(*[(9, 7, 5), (17, 12, 30), (1, 3, 2), (40, 20, 33)][rep], [0.0, 0.3][rep % 2], 1.1, dtype=dt); U, B = regime_state(G, rng, dt)
            if rep == 2:
                U[0][0, 0, 0] = -1; B[1][1, 1, 1] = np.nan; U[4][1, 2, 1] = dt(0)                                  # refusal paths
            a = prim(G, U, B, backend="cupy"); c = prim(G, U, B, backend="cpu")
            for k in a:
                x, y = a[k], c[k]; d = (x != y) & ~(np.isnan(x) & np.isnan(y)) if x.dtype.kind == "f" else (x != y); diff += int(d.sum()); tot += x.size
            Gd = dev(G); args = [rng.uniform(.5, 2, G.shape("cell")).astype(dt)] + [rng.normal(size=G.shape("cell")).astype(dt) for _ in range(3)] + [rng.uniform(.1, 1, G.shape("cell")).astype(dt)]
            ca = P.conserved(Gd, *[cp.asarray(x) for x in args + B], gamma=GAM, backend="cupy"); cc = P.conserved(G, *args, *B, gamma=GAM, backend="cpu")
            for k in ca:
                x, y = host(ca[k]), cc[k]; d = (x != y) & ~(np.isnan(x) & np.isnan(y)) if x.dtype.kind == "f" else (x != y); diff += int(d.sum()); tot += x.size
    return dict(conditions="primitives (all outputs incl. flags and bound) and conserved, 4 grids incl. partial blocks and refusal paths, FP64 + FP32; exact comparison (NaN == NaN)",
                values=tot, differing=diff), [("GPU values differing from CPU", float(diff), "<=", THRESHOLDS["G1_gpu_cpu_bitwise"])]

def G2():
    rng = np.random.default_rng(202); G = P.Grid(30, 24, 40, 0.0, 1.0); U, B = regime_state(G, rng, np.float64); r0 = prim(G, U, B, backend="cupy"); d = 0
    for _ in range(3):
        r = prim(G, U, B, backend="cupy"); d += sum(int(((r[k] != r0[k]) & ~(np.isnan(r[k]) & np.isnan(r0[k]))).sum()) if r[k].dtype.kind == "f" else int((r[k] != r0[k]).sum()) for k in r)
    return dict(conditions="3 repeated launches vs the first"), [("differing values", float(d), "<=", THRESHOLDS["G2_determinism"])]

def G3():
    worst, so, si, rows, n = bound_check("cupy", 303)
    return dict(conditions="P03 through the CUDA backend (new seed)", rows=rows), [("max |p - p_exact| / (b p) (GPU)", worst, "<=", THRESHOLDS["G3_gpu_bound_ratio"])]

def G4():
    """speed (measurement only)"""
    out = {}
    for dt in (np.float64, np.float32):
        G = P.Grid(128, 64, 128, 0.0, 1.0, dtype=dt); rng = np.random.default_rng(1); U, B = regime_state(G, rng, dt, beta_lo=-2, beta_hi=2)
        A = [cp.asarray(x) for x in U + B]; Gd = dev(G); P.primitives(Gd, *A, gamma=GAM, backend="cupy"); cp.cuda.Device().synchronize(); ts = []
        for _ in range(20):
            t = time.perf_counter(); P.primitives(Gd, *A, gamma=GAM, backend="cupy"); cp.cuda.Device().synchronize(); ts.append(time.perf_counter() - t)
        out[np.dtype(dt).name + "_ms"] = float(np.median(ts) * 1e3)
    return dict(conditions="primitives() on 132x68x132 cells incl. ghosts, median of 20 (measurement, no verdict)", **out), [("timings finite", float(all(np.isfinite(list(out.values())))), "==", 1.0)]

CPU_TESTS = [P01, P02, P03, P04, P05, P06, P07, P08, P09]
GPU_TESTS = [G1, G2, G3, G4]
OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def env():
    e = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, backend=BACKEND, platform=platform.platform(),
             python=sys.version.split()[0], numpy=np.__version__, cpu_count=os.cpu_count(), longdouble=str(np.finfo(np.longdouble).eps))
    try: e["gxx"] = subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    except Exception as x: e["gxx"] = repr(x)
    if BACKEND == "cupy":
        e["cupy"] = cp.__version__; e["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); e["cuda_runtime"] = cp.cuda.runtime.runtimeGetVersion()
    return e

if __name__ == "__main__":
    LOG = open(os.path.join(HERE, f"prim01_{LEG}.log"), "w")
    files = ["prim_v01.py", "numpy_oracle_prim.py", "campaign_prim01.py", "benchmark/hlld_v05.py"]
    R = dict(campaign="PRIM-01", kernel="ALADIN PRIM v01", env=env(), kernel_source_sha256=P.SOURCE_SHA256, frozen_sha256=FROZEN_SHA, build_sha256=P.BUILD_SHA256,
             frozen_build_sha256=FROZEN_BUILD, gpu_options=list(P.GPU_OPTIONS), cpu_flags=list(P.CPU_FLAGS),
             file_sha256={f: sha(os.path.join(HERE, f)) for f in files if os.path.exists(os.path.join(HERE, f))}, thresholds=THRESHOLDS, tests=[])
    log(f"PRIM-01 leg={LEG} backend={BACKEND} kernel sha {P.SOURCE_SHA256} build sha {P.BUILD_SHA256}")
    if np.finfo(np.longdouble).eps > 1e-18: log("NOTE: long double is not 80-bit on this platform; extended-precision oracle tests are weaker")
    if P.SOURCE_SHA256 != FROZEN_SHA or P.BUILD_SHA256 != FROZEN_BUILD:
        log("BLOCKER: kernel source or build does not match the frozen hashes"); R["tests"].append(dict(id="FREEZE", cls="BLOCKER", passed=False, detail="hash mismatch"))
    tests = CPU_TESTS + (GPU_TESTS if LEG == "gpu" and P.has_gpu() else [])
    for f in tests:
        t0 = time.time(); rec = dict(id=f.__name__)
        try:
            data, checks = f(); rec["data"] = data
            rec["checks"] = [dict(name=n, measured=float(v), op=op, threshold=float(th), passed=bool(OPS[op](float(v), float(th)))) for n, v, op, th in checks]
            rec["passed"] = all(c["passed"] for c in rec["checks"]); rec["cls"] = "VERIFIED" if rec["passed"] else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["passed"] = False; rec["exception"] = traceback.format_exc()
        rec["seconds"] = round(time.time() - t0, 2); R["tests"].append(rec)
        log(f"{rec['id']:4s} {rec['cls']:10s} {rec['seconds']:8.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec.get("checks", [])))
        if "exception" in rec: log(rec["exception"])
    if LEG == "gpu" and not P.has_gpu():
        for f in GPU_TESTS: R["tests"].append(dict(id=f.__name__, cls="INCONCLUSIVE", passed=None, detail="no GPU on this leg"))
    counts = {}
    for t in R["tests"]: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    R["summary"] = counts; log("SUMMARY", counts)
    json.dump(R, open(os.path.join(HERE, f"prim01_{LEG}_results.json"), "w"), indent=1, default=float)
