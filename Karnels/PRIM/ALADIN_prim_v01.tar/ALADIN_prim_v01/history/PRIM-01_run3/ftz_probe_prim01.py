# -*- coding: utf-8 -*-
"""PRIM-01 run 2 diagnosis (measurement + predeclared hypothesis test).
Run 2 GPU: P11 failed in FP32 only (ratio = Inf, 73 441 vs 181 161 admitted cells on CPU); FP64 passed; G1 (normal-range data) bitwise.
HYPOTHESIS (stated before running): the FP32 GPU build flushes subnormal results to zero (FTZ), so b = 8u T / e underflows to 0
and subnormal p / e become 0.  CPU (x86-64 SSE, no fast-math) keeps gradual underflow.
TEST: compile the FROZEN run-2 source (sha checked) with (a) the run-2 options, (b) + -ftz=false, (c) + -ftz=true and compare
each with the CPU on the P11 workload, FP32 and FP64, bit for bit.  Confirmed iff (a) and (c) differ from the CPU in FP32,
and (b) is bit-identical to the CPU in both precisions.     python ftz_probe_prim01.py"""
import sys, os, ast, numpy as np, cupy as cp
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import prim_v01 as P, numpy_oracle_prim as O
RUN2 = "1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535"
assert P.SOURCE_SHA256 == RUN2, "not the frozen run-2 source"
src = open(os.path.join(HERE, "campaign_prim01.py")).read(); ns = dict(np=np, O=O, LD=np.longdouble, P=P)
LD = np.longdouble
def workload(dt, seed):
    rng = np.random.default_rng(seed); lam = float(np.finfo(dt).tiny); G = P.Grid(30, 24, 30, 0.0, 1.0, dtype=dt); sh = G.shape("cell")
    Sg = lam * 10 ** rng.uniform(-6, 4, sh); rho = (10 ** rng.uniform(-3, 3, sh)).astype(dt)
    vs = np.sqrt(Sg / rho.astype(np.float64)) * 10 ** rng.uniform(-2, 1, sh); m = [(rho.astype(np.float64) * vs * rng.normal(size=sh)).astype(dt) for _ in range(3)]
    B = [(np.sqrt(lam * 10 ** rng.uniform(-6, 4, G.shape(k))) * rng.normal(size=G.shape(k))).astype(dt) for k in ("Br", "Bphi", "Bz")]
    bc = O.cellB(*(x.astype(LD) for x in B)); M = (bc[0] ** 2 + bc[1] ** 2 + bc[2] ** 2) / 2
    K = (m[0].astype(LD) ** 2 + m[1].astype(LD) ** 2 + m[2].astype(LD) ** 2) / (2 * rho.astype(LD))
    p = Sg.astype(LD) * 10 ** rng.uniform(-2, 1, sh).astype(LD); E = (p / LD(np.asarray(5 / 3, dt) - 1) + K + M).astype(dt)
    return G, [rho, *m, E], B
def run(G, U, B, backend):
    import copy
    Gk = G
    if backend == "cupy": Gk = copy.copy(G); Gk.xp = cp; A = [cp.asarray(x) for x in U + B]
    else: A = U + B
    r = P.primitives(Gk, *A, backend=backend, diag=True); return {k: (v.get() if hasattr(v, "get") else v) for k, v in r.items()}
res = {}
for label, extra in (("a run-2 options", ()), ("b + -ftz=false", ("-ftz=false",)), ("c + -ftz=true", ("-ftz=true",))):
    for real in ("double", "float"):
        P._cache[("gpu", real)] = cp.RawModule(code=P.SRC, options=(*P.GPU_OPTIONS, *extra, f"-DREAL={real}"))
    for dt in (np.float32, np.float64):
        nd = 0; tot = 0; subn_cpu = 0
        for seed in (1, 2):
            G, U, B = workload(dt, seed); a = run(G, U, B, "cupy"); c = run(G, U, B, "cpu")
            for k in a:
                x, y = a[k], c[k]; d = (x != y) & ~(np.isnan(x) & np.isnan(y)) if x.dtype.kind == "f" else (x != y); nd += int(d.sum()); tot += x.size
            subn_cpu += int(((np.abs(c["p"]) > 0) & (np.abs(c["p"]) < np.finfo(dt).tiny)).sum())
        res[(label, np.dtype(dt).name)] = nd
        print(f"{label:18s} {np.dtype(dt).name:8s} GPU values differing from CPU: {nd} / {tot}   (subnormal p on CPU: {subn_cpu})", flush=True)
ok = res[("a run-2 options", "float32")] > 0 and res[("c + -ftz=true", "float32")] > 0 and res[("b + -ftz=false", "float32")] == 0 and res[("b + -ftz=false", "float64")] == 0
print("HYPOTHESIS (FP32 GPU flushes subnormals; explicit -ftz=false restores bit-identity):", "CONFIRMED" if ok else "NOT CONFIRMED")
