# -*- coding: utf-8 -*-
"""PRIM-01 run 3 diagnosis, step 2 (measurement only, no verdict on the kernel).
Run 3 showed: FP32 GPU differs from the CPU in the underflow range by the SAME count with the run-2 options, + -ftz=false and
+ -ftz=true (135 434 values each); FP64 is bit-identical.  So the -ftz option did not change the result.  This probe finds out why:
  R1  which options CuPy actually hands to NVRTC, and whether the generated PTX contains '.ftz' instructions, per option set;
  R2  a micro kernel: x * y with a subnormal product, x + y and x / y with subnormal inputs, per option set;
  R3  PRIM compiled by us to PTX (options fully controlled, cache bypassed), loaded from that PTX, vs the CPU, FP32;
  R4  the first differing PRIM cells: inputs and outputs in hex, GPU vs CPU vs a NumPy same-order transcription.
python ftz_probe2_prim01.py     (writes prim01_ftz_probe2.log)"""
import sys, os, re, copy, struct, traceback, numpy as np, cupy as cp
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import prim_v01 as P, numpy_oracle_prim as O
LOG = open(os.path.join(HERE, "prim01_ftz_probe2.log"), "w")
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.write(s + "\n"); LOG.flush()
log("cupy", cp.__version__, "| GPU", cp.cuda.runtime.getDeviceProperties(0)["name"].decode(), "| CUDA runtime", cp.cuda.runtime.runtimeGetVersion(),
    "| driver", cp.cuda.runtime.driverGetVersion())
try: log("NVRTC version", cp.cuda.nvrtc.getVersion())
except Exception as x: log("NVRTC version: n/a", repr(x))
log("PRIM source sha", P.SOURCE_SHA256, "| GPU_OPTIONS", P.GPU_OPTIONS)
VARIANTS = [("none", ()), ("-ftz=false", ("-ftz=false",)), ("-ftz=true", ("-ftz=true",)), ("--ftz=false", ("--ftz=false",)),
            ("PRIM run-3 options", tuple(o for o in P.GPU_OPTIONS if o != "-DPRIM_GPU")), ("-use_fast_math", ("-use_fast_math",))]

def ptx_of(src, opts):
    from cupy.cuda import compiler
    out = compiler.compile_using_nvrtc(src, options=tuple(opts))
    out = out[0] if isinstance(out, tuple) else out
    return out.decode() if isinstance(out, (bytes, bytearray)) else out

# R1: what CuPy passes + PTX ftz content
log("\n== R1: PTX of the PRIM kernel (REAL=float) per option set: count of .ftz instructions ==")
try:
    import inspect
    from cupy.cuda import compiler
    sig = inspect.signature(compiler.compile_using_nvrtc); log("compile_using_nvrtc signature:", sig)
    src_lines = inspect.getsource(compiler.compile_using_nvrtc).splitlines()
    msrc = inspect.getsource(compiler).splitlines()
    log("cupy/cuda/compiler.py lines mentioning ftz / fast_math / fmad / prec / denormal:")
    for n_, l in enumerate(msrc):
        if any(w in l.lower() for w in ("ftz", "fast_math", "fast-math", "fmad", "prec-div", "prec_div", "denorm")): log(f"   {n_ + 1:5d}: {l.rstrip()}")
    try:
        from cupy import _core
        for mod in (_core,):
            pass
    except Exception: pass
    import cupy._environment as _e
    log("env CUPY_*:", {k: v for k, v in os.environ.items() if k.startswith("CUPY") or k.startswith("CUDA")})
except Exception: log(traceback.format_exc())
PTX = {}
for name, opts in VARIANTS:
    try:
        ptx = ptx_of(P.SRC, ("-DPRIM_GPU", "-DREAL=float", "-std=c++14") + tuple(o for o in opts if o not in ("-DPRIM_GPU", "-std=c++14")))
        PTX[name] = ptx; n_ftz = len(re.findall(r"\.ftz", ptx)); n_mul = len(re.findall(r"\bmul(\.\w+)*\.f32", ptx))
        log(f"  {name:22s} PTX bytes {len(ptx):7d}   '.ftz' occurrences {n_ftz:4d}   f32 mul instructions {n_mul}")
        ex = [l.strip() for l in ptx.splitlines() if ".f32" in l and ("mul" in l or "div" in l)][:4]
        for l in ex: log("        e.g.", l)
    except Exception: log(f"  {name}: compile failed\n" + traceback.format_exc())

# R2: micro kernel
log("\n== R2: micro kernel, FP32: a*b with a subnormal product; a+b and a/b with subnormal inputs ==")
MICRO = r'''extern "C" __global__ void k(const float* a, const float* b, float* m, float* s, float* d, int n)
{ int i = blockIdx.x * blockDim.x + threadIdx.x; if (i < n) { m[i] = a[i] * b[i]; s[i] = a[i] + b[i]; d[i] = a[i] / b[i]; } }'''
a = np.array([1e-20, 3e-40, 1e-44, 1e-30], np.float32); b = np.array([1e-20, 1e-40, 1.0, 1e-10], np.float32)
hx = lambda x: " ".join(f"{struct.unpack('<I', struct.pack('<f', float(v)))[0]:08x}" for v in x)
log("   inputs a:", a, " b:", b)
log("   CPU (numpy) a*b:", hx(a * b), " a+b:", hx(a + b), " a/b:", hx(a / b))
for name, opts in VARIANTS[:4]:
    for route in ("RawModule(code)", "own PTX"):
        try:
            if route == "RawModule(code)": mod = cp.RawModule(code=MICRO, options=tuple(opts))
            else:
                ptx = ptx_of(MICRO, tuple(opts)); fn = os.path.join(HERE, "micro_%d.ptx" % abs(hash(name))); open(fn, "w").write(ptx); mod = cp.RawModule(path=fn)
            k = mod.get_function("k"); A, Bd = cp.asarray(a), cp.asarray(b); M, S, D = cp.empty(4, np.float32), cp.empty(4, np.float32), cp.empty(4, np.float32)
            k((1,), (32,), (A, Bd, M, S, D, np.int32(4))); cp.cuda.Device().synchronize()
            log(f"   {name:12s} {route:16s} a*b: {hx(M.get())}  a+b: {hx(S.get())}  a/b: {hx(D.get())}")
        except Exception: log(f"   {name} {route}: failed\n" + traceback.format_exc())

# R3 / R4: PRIM from our own PTX
def workload(dt, seed):
    LD = np.longdouble; rng = np.random.default_rng(seed); lam = float(np.finfo(dt).tiny); G = P.Grid(30, 24, 30, 0.0, 1.0, dtype=dt); sh = G.shape("cell")
    Sg = lam * 10 ** rng.uniform(-6, 4, sh); rho = (10 ** rng.uniform(-3, 3, sh)).astype(dt)
    vs = np.sqrt(Sg / rho.astype(np.float64)) * 10 ** rng.uniform(-2, 1, sh); m = [(rho.astype(np.float64) * vs * rng.normal(size=sh)).astype(dt) for _ in range(3)]
    B = [(np.sqrt(lam * 10 ** rng.uniform(-6, 4, G.shape(k))) * rng.normal(size=G.shape(k))).astype(dt) for k in ("Br", "Bphi", "Bz")]
    bc = O.cellB(*(x.astype(LD) for x in B)); M = (bc[0] ** 2 + bc[1] ** 2 + bc[2] ** 2) / 2
    K = (m[0].astype(LD) ** 2 + m[1].astype(LD) ** 2 + m[2].astype(LD) ** 2) / (2 * rho.astype(LD))
    p = Sg.astype(LD) * 10 ** rng.uniform(-2, 1, sh).astype(LD); E = (p / LD(np.asarray(5 / 3, dt) - 1) + K + M).astype(dt)
    return G, [rho, *m, E], B
def run(G, U, B, backend):
    Gk = G; A = U + B
    if backend == "cupy": Gk = copy.copy(G); Gk.xp = cp; A = [cp.asarray(x) for x in A]
    r = P.primitives(Gk, *A, backend=backend, diag=True); return {k: (v.get() if hasattr(v, "get") else v) for k, v in r.items()}
log("\n== R3: PRIM (FP32) loaded from PTX we compiled ourselves, vs the CPU, P11 workload seed 1 ==")
G, U, B = workload(np.float32, 1); c = run(G, U, B, "cpu")
for name in PTX:
    try:
        fn = os.path.join(HERE, "prim_float_%d.ptx" % abs(hash(name))); open(fn, "w").write(PTX[name]); P._cache[("gpu", "float")] = cp.RawModule(path=fn)
        a_ = run(G, U, B, "cupy"); per = {k: int(((a_[k] != c[k]) & ~(np.isnan(a_[k]) & np.isnan(c[k]))).sum()) if a_[k].dtype.kind == "f" else int((a_[k] != c[k]).sum()) for k in a_}
        log(f"  {name:22s} differing per output: {per}")
    except Exception: log(f"  {name}: failed\n" + traceback.format_exc())
log("\n== R4: first differing cells (FP32, PRIM built with the frozen run-3 options through the normal path) ==")
P._cache.pop(("gpu", "float"), None); a_ = run(G, U, B, "cupy")
so = O.same_order(*U, *B, 5 / 3, np.float32)
dif = np.argwhere((a_["p"] != c["p"]) & ~(np.isnan(a_["p"]) & np.isnan(c["p"])))[:6]
for idx in map(tuple, dif):
    i, j, k = idx
    ins = [U[0][idx], U[1][idx], U[2][idx], U[3][idx], U[4][idx], B[0][i, j, k], B[0][i + 1, j, k], B[1][i, j, k], B[1][i, j + 1, k], B[2][i, j, k], B[2][i, j, k + 1]]
    log(f"  cell {idx}: inputs (rho, m_r, m_phi, m_z, E, Br0, Br1, Bp0, Bp1, Bz0, Bz1) = {hx(np.array(ins, np.float32))}")
    log(f"     GPU  p={a_['p'][idx]!r} b={a_['p_err_bound'][idx]!r} flag={a_['flags'][idx]}   CPU p={c['p'][idx]!r} b={c['p_err_bound'][idx]!r} flag={c['flags'][idx]}   numpy-same-order p={so['p'][idx]!r} e={so['e'][idx]!r}")
log("DONE")
