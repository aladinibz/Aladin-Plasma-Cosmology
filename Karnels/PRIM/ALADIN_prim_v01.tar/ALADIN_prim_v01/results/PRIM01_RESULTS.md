# PRIM-01 results: ALADIN PRIM v01

Made 2026-11-20 17:07 UTC.  Source hash frozen and identical on all legs: **True**

- cpu leg kernel sha256 `1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535`, build sha256 `8363891cb25a2ee9f05111c4dbf6b968afc2aaecfc305c3f3e4f92da033316e0` (source of record: leg JSON)
- gpu leg kernel sha256 `1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535`, build sha256 `8363891cb25a2ee9f05111c4dbf6b968afc2aaecfc305c3f3e4f92da033316e0` (source of record: RECONSTRUCTED from the GPU console transcript (prim01_run4_gpu_TRANSCRIPT.txt, sha256 2b0bbfb8bb8c5e1320909372785f6475fd115c85da39260b7dbc8f55d99c77d7); the GPU leg JSON was not supplied)

| Test | Final | cpu | gpu |
|---|---|---|---|
| P01 | VERIFIED | VERIFIED | VERIFIED |
| P02 | VERIFIED | VERIFIED | VERIFIED |
| P03 | VERIFIED | VERIFIED | VERIFIED |
| P04 | VERIFIED | VERIFIED | VERIFIED |
| P05 | VERIFIED | VERIFIED | VERIFIED |
| P06 | VERIFIED | VERIFIED | VERIFIED |
| P07 | VERIFIED | VERIFIED | VERIFIED |
| P08 | VERIFIED | VERIFIED | VERIFIED |
| P09 | VERIFIED | VERIFIED | VERIFIED |
| P10 | VERIFIED | VERIFIED | VERIFIED |
| P11 | VERIFIED | VERIFIED | VERIFIED |
| G6 | VERIFIED | — | VERIFIED |
| G1 | VERIFIED | — | VERIFIED |
| G2 | VERIFIED | — | VERIFIED |
| G3 | VERIFIED | — | VERIFIED |
| G4 | VERIFIED | — | VERIFIED |
| G5 | VERIFIED | — | VERIFIED |
| M1_memcheck | VERIFIED |  |  |
| M2_racecheck | VERIFIED |  |  |

Counts: {'VERIFIED': 19}

## Checks (measured vs predeclared threshold)

- P01 [cpu] velocity values not correctly rounded: 0.0000e+00 <= 0.0e+00 -> pass
- P01 [gpu] velocity values not correctly rounded: 0.0000e+00 <= 0.0e+00 -> pass
- P02 [cpu] density values changed: 0.0000e+00 <= 0.0e+00 -> pass
- P02 [gpu] density values changed: 0.0000e+00 <= 0.0e+00 -> pass
- P03 [cpu] max |p - p_exact| / (b p): 3.1906e-01 <= 1.0e+00 -> pass
- P03 [cpu] flag-2 sign disagreements outside the bound zone: 0.0000e+00 <= 0.0e+00 -> pass
- P03 [gpu] max |p - p_exact| / (b p): 3.1910e-01 <= 1.0e+00 -> pass
- P03 [gpu] flag-2 sign disagreements outside the bound zone: 0.0000e+00 <= 0.0e+00 -> pass
- P04 [cpu] flag-4 cells inconsistent with the returned bound: 0.0000e+00 <= 0.0e+00 -> pass
- P04 [cpu] max measured rel error of p in unflagged cells: 2.1586e-04 <= 1.0e-03 -> pass
- P04 [gpu] flag-4 cells inconsistent with the returned bound: 0.0000e+00 <= 0.0e+00 -> pass
- P04 [gpu] max measured rel error of p in unflagged cells: 2.1590e-04 <= 1.0e-03 -> pass
- P05 [cpu] cells whose flag-1 status differs from the rule: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [cpu] non-NaN outputs on refused cells: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [cpu] changes outside the refused cells (+ bad faces not refusing exactly 2 cells): 0.0000e+00 <= 0.0e+00 -> pass
- P05 [gpu] cells whose flag-1 status differs from the rule: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [gpu] non-NaN outputs on refused cells: 0.0000e+00 <= 0.0e+00 -> pass
- P05 [gpu] changes outside the refused cells (+ bad faces not refusing exactly 2 cells): 0.0000e+00 <= 0.0e+00 -> pass
- P06 [cpu] cells mis-classified around e = 0: 0.0000e+00 <= 0.0e+00 -> pass
- P06 [cpu] e = 0 admitted (p = 0, flag 4, bound = Inf): 1.0000e+00 == 1.0e+00 -> pass
- P06 [gpu] cells mis-classified around e = 0: 0.0000e+00 <= 0.0e+00 -> pass
- P06 [gpu] e = 0 admitted (p = 0, flag 4, bound = Inf): 1.0000e+00 == 1.0e+00 -> pass
- P07 [cpu] conserved(): max rel error of m in units of u: 9.9548e-01 <= 1.0e+00 -> pass
- P07 [cpu] conserved(): max rel error of E in units of u: 3.7804e+00 <= 8.0e+00 -> pass
- P07 [cpu] round trip: max |p' - p| / (b p'): 3.5347e-01 <= 2.0e+00 -> pass
- P07 [gpu] conserved(): max rel error of m in units of u: 9.9550e-01 <= 1.0e+00 -> pass
- P07 [gpu] conserved(): max rel error of E in units of u: 3.7800e+00 <= 8.0e+00 -> pass
- P07 [gpu] round trip: max |p' - p| / (b p'): 3.5350e-01 <= 2.0e+00 -> pass
- P08 [cpu] max |p - (P0 - r^2/4)|: 1.1102e-16 <= 1.0e-14 -> pass
- P08 [cpu] max |v|: 0.0000e+00 <= 0.0e+00 -> pass
- P08 [cpu] HLLD radial mass + energy flux from PRIM output: 0.0000e+00 <= 1.0e-14 -> pass
- P08 [gpu] max |p - (P0 - r^2/4)|: 1.1100e-16 <= 1.0e-14 -> pass
- P08 [gpu] max |v|: 0.0000e+00 <= 0.0e+00 -> pass
- P08 [gpu] HLLD radial mass + energy flux from PRIM output: 0.0000e+00 <= 1.0e-14 -> pass
- P09 [cpu] flag 4 reached in FP64 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P09 [cpu] flag 4 reached in FP32 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P09 [gpu] flag 4 reached in FP64 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P09 [gpu] flag 4 reached in FP32 sweep: 1.0000e+00 == 1.0e+00 -> pass
- P10 [cpu] cells whose flag-8 status differs from the range check: 0.0000e+00 <= 0.0e+00 -> pass
- P10 [cpu] non-NaN outputs on flag-8 cells + changes elsewhere: 0.0000e+00 <= 0.0e+00 -> pass
- P10 [cpu] gamma accepted exactly when 1 < gamma <= 2: 1.0000e+00 == 1.0e+00 -> pass
- P10 [gpu] cells whose flag-8 status differs from the range check: 0.0000e+00 <= 0.0e+00 -> pass
- P10 [gpu] non-NaN outputs on flag-8 cells + changes elsewhere: 0.0000e+00 <= 0.0e+00 -> pass
- P10 [gpu] gamma accepted exactly when 1 < gamma <= 2: 1.0000e+00 == 1.0e+00 -> pass
- P11 [cpu] max |p - p_exact| / (b p) in the underflow range: 2.8877e-01 <= 1.0e+00 -> pass
- P11 [cpu] squares that underflow (the range is exercised): 1.4496e+06 >= 1.0e+03 -> pass
- P11 [gpu] max |p - p_exact| / (b p) in the underflow range: 2.8880e-01 <= 1.0e+00 -> pass
- P11 [gpu] squares that underflow (the range is exercised): 1.4500e+06 >= 1.0e+03 -> pass
- G6 [gpu] FP32 subnormal arithmetic bit-identical to IEEE: 1.0000e+00 == 1.0e+00 -> pass
- G6 [gpu] '.ftz' in PRIM PTX (FP32 + FP64): 0.0000e+00 <= 0.0e+00 -> pass
- G1 [gpu] GPU values differing from CPU: 0.0000e+00 <= 0.0e+00 -> pass
- G2 [gpu] differing values: 0.0000e+00 <= 0.0e+00 -> pass
- G3 [gpu] max |p - p_exact| / (b p) (GPU): 3.0200e-01 <= 1.0e+00 -> pass
- G4 [gpu] timings finite: 1.0000e+00 == 1.0e+00 -> pass
- G5 [gpu] GPU values differing from CPU in the underflow range: 0.0000e+00 <= 0.0e+00 -> pass
- M1_memcheck: VERIFIED ========= ERROR SUMMARY: 0 errors
- M2_racecheck: VERIFIED ========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)
