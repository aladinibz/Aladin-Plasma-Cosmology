# ALADIN PRIM v01 — kernel 01 (conserved → primitive)

PRIM converts the conserved state (ρ, m, E) plus the CT face field into primitives (ρ, v, p) for the ALADIN native-cylindrical GPU MHD Driver.

- **A derived and numerically verified pressure error bound in every cell.** PRIM returns b with |p − p_exact| ≤ b·p. The derivation is in Appendix A of the report, with its assumptions stated. A cell is flagged UNRESOLVED (flag 4) when p has fewer than 3 significant digits, as happens at low β.
- **Refusal, not floors.** The following cells are refused with NaN outputs, consistent with HLLD v05.1:
  - ρ ≤ 0 or any non-finite input (flag 1);
  - E below kinetic + magnetic energy (flag 2);
  - finite inputs whose intermediates overflow (flag 8).

  γ must satisfy 1 < γ ≤ 2, otherwise the call raises an error.
- **Consistent cell field.** Cell-centred B is the CT face average used by HLLD v05.1 and UCT-EMF v02.
- **Bit-reproducible.** GPU = CPU bit for bit in FP64 and FP32, subnormal range included. The GPU kernel is compiled by NVRTC directly: `cupy.RawModule` appends `-ftz=true`, which flushes FP32 subnormals. The loaded PTX is checked to contain no `.ftz` instruction.
- **Inverse included.** `conserved()` converts primitives back to conserved variables.

## Campaign PRIM-01, run 4

- **CPU leg:** 11 / 11 VERIFIED.
- **GPU leg (NVIDIA L4):** 17 / 17 VERIFIED.
- **compute-sanitizer:** memcheck 0 errors, racecheck 0 hazards.
- **Pressure bound:** never exceeded. Worst case 0.32 of the bound in the normal range (758 733 cells) and 0.29 in the underflow range (375 k cells).

Runs 1–3, the review that triggered run 2 and both diagnosis probes are kept in `history/`.

**Driver notes:**
- **Precision:** in FP32, p keeps 3 digits only down to β ≈ 1e-4; in FP64, down to β ≈ 1e-12. Use FP64 state for low-β pinches.
- **Flags:** the flag policy is in the report (section 5) and in `prim_driver_adapter.py`.

## Reproduce

```
sha256sum -c SHA256SUMS.txt
cd code && python campaign_prim01.py cpu && python campaign_prim01.py gpu
compute-sanitizer --tool memcheck  python sanitizer_target_prim01.py
compute-sanitizer --tool racecheck python sanitizer_target_prim01.py
python make_results_prim01.py ; python test_adapter_prim.py ; cd ../benchmark && python readme_benchmark.py
```

## Hashes

- Kernel source SHA-256: `1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535`
- Build SHA-256 (source + GPU options + CPU flags + GPU loader): `8363891cb25a2ee9f05111c4dbf6b968afc2aaecfc305c3f3e4f92da033316e0`

Author: Mihai Alexandru Bucurenciu (ALADIN), ORCID 0009-0006-4457-557X.

AI assistant Team: SuperGrok, Claude, ChatGPT
