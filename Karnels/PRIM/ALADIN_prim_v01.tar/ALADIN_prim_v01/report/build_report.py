# -*- coding: utf-8 -*-
"""Builds report.html for ALADIN PRIM v01 from PRIM01_RESULTS.json (every number in the tables comes from the JSON)."""
import json, html
R = json.load(open("/home/claude/prim/PRIM01_RESULTS.json"))
LEG = R["legs_verbatim"]; CPU = {t["id"]: t for t in LEG["cpu"]["tests"]}; GPU = {t["id"]: t for t in LEG["gpu"]["tests"]}
SAN = R["sanitizer_verbatim"]; SHA = R["hashes"]["cpu"]["kernel"]; BSHA = R["hashes"]["cpu"]["build"]; FILES = R["hashes"]["cpu"]["files"]
css = open("/home/claude/gyropdf/report.html").read().split("<style>")[1].split("</style>")[0]
e = html.escape
def f(x, d=2):
    if x == 0: return "0"
    return f"{x:.{d}e}".replace("e-0", "e-").replace("e+0", "e+").replace("e+", "e")
def pill(c): return f'<span class="pill {dict(VERIFIED="", LIMITATION="gold", BLOCKER="red", INCONCLUSIVE="navy")[c]}">{c}</span>'
def checks_txt(t): return "<br>".join(f"{e(c['name'])}: <b>{f(c['measured'])}</b> {e(c['op'])} {f(c['threshold'],0)}" for c in t["checks"])
TITLES = dict(
    P01=("Velocity correctly rounded", "1.6 M values: v = m / ρ exactly rounded; oracle disagreements adjudicated in exact rational arithmetic"),
    P02=("Density passed through", "admitted cells return ρ bit for bit"),
    P03=("Pressure error bound holds", "758 733 cells: ρ 1e-8..1e8, β 1e-12..1e6, Mach 1e-3..1e3, cancelling faces; 80-bit oracle"),
    P04=("UNRESOLVED flag consistent", "flag 4 iff b > 1e-3; unflagged cells measured < 1e-3"),
    P05=("Refusal: rule, NaN, locality", "NaN / ±Inf in each of the 8 inputs, ρ = −1, 0, −1e-30; FP64 + FP32"),
    P06=("Refusal at e = 0 exactly", "exactly representable K, M: e = 0 admitted (p = 0), e one ulp below refused"),
    P07=("Inverse conserved() and round trip", "vs 80-bit oracle in units of u; prim → cons → prim within 2 b"),
    P08=("README Z-pinch through PRIM and HLLD", "B_φ = r/2, P = 1 − r²/4: p, v, and the HLLD radial flux of PRIM's output"),
    P09=("Low-β digits (measurement)", "uniform plasma, β = 1 … 1e-16, FP64 + FP32"),
    G1=("GPU = CPU bit for bit", "1.35 M values: all outputs incl. flags and bound, refusal paths, FP64 + FP32"),
    G2=("GPU determinism", "three launches identical"),
    G3=("Bound holds on the GPU", "P03 through CUDA, new seed"),
    G4=("Speed (measurement)", "132 × 68 × 132 cells incl. ghosts, L4"),
    P10=("Out of range refused; γ validated (run 2)", "m², B², m/ρ, E + K overflowing (80-bit range check); γ inside / outside (1, 2]"),
    P11=("Bound holds in the underflow range (run 2)", "375 k cells, energies 1e-6 … 1e4 × the smallest normal; 1.45 M underflowing squares"),
    G5=("GPU = CPU bit for bit in the underflow range (run 3)", "P11-type states, FP32 + FP64, all outputs"),
    G6=("GPU compile path is IEEE (run 4)", "subnormal ×, +, ÷ bit-identical to IEEE; no .ftz in the PRIM PTX"))
rows = []
for i in R["final_class"]:
    if i.startswith("M"): continue
    ti, cond = TITLES[i]; c = CPU.get(i); g = GPU.get(i)
    rows.append(f"<tr><td>{i}</td><td><b>{e(ti)}</b><br><span class='note'>{e(cond)}</span></td><td class='mono'>{checks_txt(c) if c else '— (GPU only)'}</td><td class='mono'>{checks_txt(g)}</td><td>{pill(R['final_class'][i])}</td></tr>")
for k, nm in (("M1_memcheck", "compute-sanitizer memcheck"), ("M2_racecheck", "compute-sanitizer racecheck")):
    s = SAN[k]; line = [l for l in s["summary_lines"] if "SUMMARY" in l][-1].replace("=========", "").strip()
    rows.append(f"<tr><td>{k.split('_')[0]}</td><td><b>{nm}</b><br><span class='note'>6 grids incl. 1-cell and partial blocks, FP64 + FP32, diag on/off, conserved(); every path exercised (flags 0, 1, 2, 4)</span></td><td class='mono'>—</td><td class='mono'>{e(line)}</td><td>{pill(R['final_class'][k])}</td></tr>")
TABLE = "\n".join(rows)
genv, cenv = dict(gpu='NVIDIA L4', cuda_runtime=13000, cupy='14.0.1', utc='2026-11-20 (run 4)'), LEG["cpu"]["env"]
filerows = "".join(f"<tr><td class='mono'>{k}</td><td class='hash'>{v}</td></tr>" for k, v in FILES.items())
P03 = {r["dtype"]: r for r in CPU["P03"]["data"]["rows"]}; R1 = json.load(open("/home/claude/prim/history_run1/PRIM01_RESULTS.json")); G4 = {t["id"]: t for t in R1["legs_verbatim"]["gpu"]["tests"]}["G4"]["data"]
p9 = CPU["P09"]["data"]["rows"]
def p9row(dt):
    return "".join(f"<td class='num'>{f(r['median_measured_rel_err'],1) if r['median_measured_rel_err'] < 0.999 else '<b>no digit</b>'}{' ⚑' if r['flag4_fraction'] > 0 else ''}</td>" for r in p9 if r["dtype"] == dt)
betas = "".join(f"<th>{f(r['beta'],0)}</th>" for r in p9 if r["dtype"] == "float64")
bench = open("/home/claude/prim/benchmark/readme_benchmark_output.txt").read()
body = f"""
<section class="cover">
  <div class="kicker">ALADIN Plasma Cosmology · Kernel 01 · PRIM</div>
  <h1>ALADIN PRIM v01</h1>
  <div class="subtitle">Conserved to primitive variables for the native-cylindrical ALADIN Driver, with an analytically derived and numerically verified error bound on the pressure in every cell. PRIM reports how many digits of p survive the cancellation at low β, refuses invalid and out-of-range states visibly instead of flooring them, and gives bit-identical results on GPU and CPU, subnormal range included</div>
  <div class="rule"></div>
  <div class="meta">
    <b>Author:</b> Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X<br>
    <b>System:</b> ALADIN native-cylindrical GPU MHD Driver: Z-pinch and J × B research<br>
    <b>Release:</b> PRIM v01 · campaign PRIM-01, run 4 (runs 1–3 in history/) · 20 November 2026<br>
    <b>Kernel source SHA-256:</b> <span class="hash">{SHA}</span><br>
    <b>Build SHA-256</b> (source + GPU options + CPU flags): <span class="hash">{BSHA}</span><br>
    <b>Legs:</b> CPU (g++ / OpenMP) and GPU ({e(genv['gpu'])}, CUDA runtime {genv['cuda_runtime']}, CuPy {genv['cupy']}); one CUDA/C++ source, FP64 + FP32
  </div>
  <div class="hero">
    <div class="lbl">What PRIM returns for every cell</div>
    <div class="eq">ρ, v = m/ρ, p = (γ − 1)(E − K − M) &nbsp;and&nbsp; b with |p − p<sub>exact</sub>| ≤ b·p</div>
    <div class="cap">K = |m|²/2ρ, M = |B<sub>c</sub>|²/2 with B<sub>c</sub> the CT face average (as HLLD and UCT-EMF use), b = 8u T/e with T = E + K + M + λ(4/ρ + 10 + 1/(γ−1)), λ the smallest normal number. Flags: 1 / 2 / 8 REFUSED (NaN), 4 UNRESOLVED (b &gt; 1e-3: fewer than 3 digits of p)</div>
  </div>
  <div class="cards">
    <div class="card"><div class="big">17 / 17</div><div class="t">PRIM-01 run 4 on GPU, all VERIFIED (11 / 11 on CPU); sanitizer 0 errors, 0 hazards</div></div>
    <div class="card"><div class="big">{P03['float32']['worst_ratio']:.2f}</div><div class="t">worst measured pressure error as a fraction of the guaranteed bound, over 758 733 cells (bound never exceeded)</div></div>
    <div class="card"><div class="big">0</div><div class="t">GPU values differing from the CPU's, FP64 + FP32, normal and subnormal range (G1, G5)</div></div>
    <div class="card gold"><div class="big">β ≈ 1e-4</div><div class="t">where FP32 loses 3 digits of p. FP64 keeps them down to β ≈ 1e-12</div></div>
  </div>
  <div class="cover-foot">Every number is generated from PRIM01_RESULTS.json. The run-4 GPU leg is recorded from its console transcript; runs 1–3 and both diagnosis probes are kept in history/.</div>
</section>

<h2 class="pb">1. What PRIM v01 is</h2>
<p>In Driver v3.1 the PRIM slot was a placeholder: it computed max(ρ, floor), discarded it and returned. PRIM v01 is the kernel, built on the contract of the certified kernels:</p>
<ul>
<li><b>Grid.</b> Ghost-extended cells with z fastest; CT faces Br, Bφ, Bz. Every cell, ghosts included, is converted (the caller fills ghosts first).</li>
<li><b>Source and builds.</b> One CUDA/C++ source, NVRTC and g++/OpenMP, FP64 and FP32. Floating-point contraction is off and the operation order is fixed, so the GPU and the CPU are bit-identical (G1).</li>
<li><b>Energy split.</b> The cell field is the average of the two CT faces, identical to <code>hlld_v05.cell_B</code> and the UCT-EMF device functions. The magnetic energy PRIM removes is therefore the one the flux kernels see.</li>
<li><b>Refusal, consistent with HLLD v05.1.</b> ρ ≤ 0 or any non-finite input among the 11 a cell reads (ρ, m, E, six faces) gives flag 1. E below K + M gives flag 2. Finite inputs whose intermediates overflow (v, K, M or T) give flag 8. In all three cases every output is NaN. PRIM never floors: floors and recovery are the Driver's decision. e = 0 (p = 0, the cold limit) is admitted.</li>
<li><b>Parameter check.</b> γ must satisfy 1 &lt; γ ≤ 2 as stored in the working precision; otherwise the call raises an error. That also makes γ − 1 exact, which the derivation uses.</li>
<li><b>The pressure bound.</b> At low β, p is a small difference of large numbers. PRIM returns b with |p − p<sub>exact</sub>| ≤ b·p, where p<sub>exact</sub> is the exact pressure of the stored inputs. The bound is derived by rounding-error analysis (Appendix A, assumptions stated there) and verified numerically against an 80-bit oracle in the normal and the subnormal range. It is not a machine-checked proof. When b &gt; 1e-3 the cell is flagged UNRESOLVED.</li>
<li><b>Inverse.</b> <code>conserved()</code> converts primitives back to conserved variables, for initial conditions and the round-trip test (P07).</li>
</ul>

<h2>2. The README benchmark: normalised Z-pinch, μ<sub>0</sub> = 1</h2>
<p>The benchmark now starts from the conserved state. PRIM recovers P = P<sub>0</sub> − r²/4 and v = 0, and HLLD runs on PRIM's output. UCT_CURL v1.3, UCT-EMF v02, EGLM v02, HLLD v05.1 and PRIM v01 are used unmodified:</p>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:7.4pt;text-align:left;white-space:pre-wrap">{e(bench)}</div>
<p class="note">With PRIM's pressure (1.1e-16 from exact) feeding well-balanced HLLD, the face pressure is exact to 1.1e-16 and dP/dr to ~1e-14: the round-off of one pressure, differenced over dr. Mass and energy fluxes stay exactly 0.</p>

<h2 class="pb">3. How many digits of p survive</h2>
<figure><img src="prim_fig.png"><figcaption>Figure 1. Left: median measured relative error of p (solid) and the bound b PRIM returns (dashed) as β falls, FP64 and FP32 (P09). Right: measured error as a fraction of the guaranteed bound over the P03 sample.</figcaption></figure>
<table><tr><th>β</th>{betas}</tr><tr><td>FP64</td>{p9row('float64')}</tr><tr><td>FP32</td>{p9row('float32')}</tr></table>
<p class="note">Median measured relative error of p (P09). ⚑ marks cells flagged UNRESOLVED; "no digit" means p came out 0 or was refused (flag 2), because the internal energy is below the rounding of E.</p>
<ul>
<li><b>The guarantee holds everywhere tested.</b> Over 758 733 admitted cells the worst measured error is {P03['float64']['worst_ratio']:.2f} (FP64) and {P03['float32']['worst_ratio']:.2f} (FP32) of the bound, the 99.9 % quantile {P03['float64']['q999_ratio']:.2f}, the median {P03['float64']['median_ratio']:.3f}. The bound is safe and about 3× conservative at worst.</li>
<li><b>Cells where the sign of e cannot be resolved.</b> Here the exact internal energy is smaller than the rounding bound. They may be admitted or refused ({CPU['P03']['data']['sign_disagreements_inside_bound_zone']:,} such disagreements, all inside that zone, none outside).</li>
<li><b>What this means for the Driver.</b> Driver v3.1 stores its fields in float32. In FP32, p keeps 3 digits only down to β ≈ 1e-4 and carries no digit at all from β ≈ 1e-8. A low-β pinch, or the force-free outer regions of a Z-pinch, needs FP64 state. PRIM's flag 4 tells the Driver, cell by cell, where FP32 is not enough.</li>
</ul>

<h2 class="pb">4. Results: PRIM-01, all tests, both legs</h2>
<table class="camp"><tr><th>ID</th><th>Test and conditions</th><th>CPU leg</th><th>GPU leg</th><th>Final</th></tr>
{TABLE}
</table>
<p class="note">The run-4 GPU leg is recorded from its console transcript (prim01_run4_gpu_TRANSCRIPT.txt; classes and check values parsed from it). Speed measured in run 1 (G4, L4, CuPy loader): {G4['float64_ms']:.2f} ms in FP64 and {G4['float32_ms']:.2f} ms in FP32 for primitives() on 1.18 M cells including ghosts.</p>
<p class="note"><b>A correction made before freezing.</b> The first dry run stated the bound as a relative error with respect to the exact pressure. That form fails exactly where p is already noise: the computed e can then differ from the exact e by a large factor (ratio up to 1.4e3 in the dry run). The guarantee the rounding analysis actually gives is the absolute form |p − p<sub>exact</sub>| ≤ b·p, which implies a relative error ≤ b/(1 − b) whenever b &lt; 1. The definition and the test were corrected before the source was frozen.</p>

<h2 class="pb">5. Flag policy for the Driver</h2>
<table><tr><th>flag</th><th>meaning</th><th>outputs</th><th>Driver action</th></tr>
<tr><td>1</td><td>ρ ≤ 0 or a non-finite input</td><td>NaN</td><td>stop / roll back, or recovery loop (with HLLD flag 32)</td></tr>
<tr><td>2</td><td>E below kinetic + magnetic energy</td><td>NaN</td><td>as flag 1</td></tr>
<tr><td>8</td><td>finite inputs, an intermediate overflows</td><td>NaN</td><td>as flag 1; the state has left the representable range</td></tr>
<tr><td>4</td><td>valid cell, fewer than 3 digits of p (b &gt; 1e-3)</td><td>values returned</td><td>accept and use; count the cells; a growing fraction means the state needs FP64</td></tr>
<tr><td>4 with p = 0</td><td>e = 0 exactly: the cold limit, b = ∞</td><td>p = 0</td><td>accept: a valid cold state (HLLD v05.1 admits p = 0)</td></tr></table>
<p class="note">UNRESOLVED is a precision warning, not physical invalidity. In low β, p enters the fluxes and the sound speed where the magnetic terms dominate, so a poorly resolved p is usually harmless there. A growing UNRESOLVED fraction is the signal to raise the working precision.</p>

<h2>6. Runs 1 → 4: review, a toolchain defect, and the fix</h2>
<ul>
<li><b>Run 1</b> (13 / 13 GPU, 9 / 9 CPU). Publication review (ChatGPT) asked for three things: qualify "proven", handle overflow and invalid parameters inside the kernel, and give UNRESOLVED an explicit policy.</li>
<li><b>Run 2</b> answered all three: flag 8, the γ check, underflow terms in the bound, the derivation (Appendix A), the policy table, and the new tests P10 and P11. On the GPU, P11 failed in FP32 only: the bound came out as 0 in many cells.</li>
<li><b>Run 3.</b> Hypothesis: the FP32 build flushes subnormals, so pin <code>-ftz=false</code>. The predeclared probe showed identical results with <code>-ftz=false</code>, <code>-ftz=true</code> and the defaults, so the hypothesis was <b>not confirmed</b>, and P11 and G5 failed again.</li>
<li><b>Diagnosis.</b> A micro kernel showed that kernels compiled through <code>cupy.RawModule</code> flush FP32 subnormal results and treat subnormal inputs as zero: 3e-40 / 1e-40 = NaN. CuPy's own source (<code>cupy/cuda/compiler.py</code>, line 585) appends <code>-ftz=true</code> after the user's options, so the user's choice is silently overridden.</li>
<li><b>Run 4.</b> The kernel source is unchanged; PRIM now compiles through NVRTC directly with exactly its options. The generated PTX is checked to contain no <code>.ftz</code> instruction before loading, and G6 checks subnormal arithmetic against IEEE. Result: 17 / 17 on GPU, with P11 and G5 passing; 11 / 11 on CPU.</li>
</ul>
<p class="note"><b>Consequence beyond PRIM.</b> Every ALADIN kernel built through <code>cupy.RawModule</code> flushes subnormals in FP32 on the GPU. FP64 and normal-range values are unaffected, so the published physics results stand. But FP32 GPU = CPU bitwise claims (HLLD v05.1 G5) hold only for normal-range values until those kernels adopt the same direct-NVRTC loader.</p>

<h2>7. Limitations and open regimes</h2>
<ul>
<li><b>No floors.</b> PRIM returns NaN for refused cells by design (section 5).</li>
<li><b>Bound scope.</b> The bound covers the rounding error of this conversion from the stored inputs. It says nothing about errors already in E, m or B from the evolution. It holds under the assumptions of Appendix A, which the kernel enforces (γ check, flags 1, 2, 8) or which the build guarantees (IEEE round-to-nearest, gradual underflow, no contraction).</li>
<li><b>Toolchain.</b> The GPU build depends on CuPy exposing NVRTC (tested: CuPy 14.0.1, CUDA 13.0, NVIDIA L4). G6 fails loudly if a future stack changes this.</li>
<li><b>Scope.</b> These are kernel-level tests. Use inside the coupled evolution belongs to the Driver campaign.</li>
</ul>

<h2 class="pb">8. Integrity and reproduction</h2>
<table><tr><th>File</th><th>SHA-256 (identical on both legs)</th></tr>{filerows}</table>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:9pt;text-align:left">sha256sum -c SHA256SUMS.txt<br>cd code &amp;&amp; python campaign_prim01.py cpu &amp;&amp; python campaign_prim01.py gpu<br>compute-sanitizer --tool memcheck  python sanitizer_target_prim01.py<br>compute-sanitizer --tool racecheck python sanitizer_target_prim01.py<br>python make_results_prim01.py &nbsp;·&nbsp; python test_adapter_prim.py &nbsp;·&nbsp; cd benchmark &amp;&amp; python readme_benchmark.py</div>
<p class="note">CPU leg {e(cenv['utc'])}, NumPy {cenv['numpy']}; GPU leg run 4, {e(genv['gpu'])}, CuPy 14.0.1, CUDA 13.0. Oracle: 80-bit long double, with exact rational adjudication for the correctly rounded velocity.</p>

<h2>9. Plugging into the Driver</h2>
<p>Slot 01 is <code>prim_slot(G, fields)</code> in prim_driver_adapter.py. It takes the Driver's own field names (rho, rho_vr, rho_vphi, rho_vz, E, Br, Bphi, Bz), asserts the certified source and build hashes, and is identical to the certified call (difference 0). Pass <code>diag=True</code> to receive b per cell. Its flags feed the Driver's recovery loop together with HLLD's flag 32.</p>

<h2 class="pb">Appendix A. Derivation of the pressure bound</h2>
<p><b>Assumptions.</b></p>
<ul>
<li>(A1) IEEE-754 binary64 or binary32 with round-to-nearest. Every +, −, ×, ÷ is correctly rounded, contraction is off (both builds), and underflow is gradual (CPU always; GPU from run 4, checked by G6).</li>
<li>(A2) 1 &lt; γ ≤ 2 as stored, so γ − 1 is computed exactly (Sterbenz).</li>
<li>(A3) The cell is not refused: flags 1, 2 and 8 are clear, so all intermediates are finite.</li>
</ul>
<p><b>Rounding model.</b> Write u for the unit roundoff and λ for the smallest positive normal number; η = uλ is half the smallest subnormal spacing. Under (A1), fl(x ∘ y) = (x ∘ y)(1 + δ) + ε with |δ| ≤ u and |ε| ≤ η, where ε = 0 for + and −.</p>
<p><b>Kinetic energy.</b> s = (a² + b²) + c² is a sum of three non-negative rounded squares, so s<sub>c</sub> = s(1 + θ<sub>3</sub>) + 3η(1 + O(u)). The halving is exact unless the result is subnormal (error ≤ η), and the division adds a factor (1 + δ) and an ε:</p>
<p style="text-align:center">|K<sub>c</sub> − K| ≤ γ<sub>4</sub>K + 4η/ρ + η, &nbsp; γ<sub>n</sub> = nu/(1 − nu).</p>
<p><b>Magnetic energy.</b> Each face sum is one rounding and the halving is exact or ≤ η; each square adds a rounding and ≤ η. So</p>
<p style="text-align:center">|M<sub>c</sub> − M| ≤ γ<sub>5</sub>M + 7η.</p>
<p><b>Internal energy.</b> e<sub>c</sub> = fl(fl(E − K<sub>c</sub>) − M<sub>c</sub>) is two subtractions with no ε terms, each with relative error ≤ u. With S = E + K + M:</p>
<p style="text-align:center">|e<sub>c</sub> − e| ≤ |K<sub>c</sub> − K| + |M<sub>c</sub> − M| + u|E − K<sub>c</sub>| + u|e<sub>c</sub>| ≤ (4u K + 5u M + 2u E + uK) + 4η/ρ + 8η + O(u²)S ≤ 5u S + 4η/ρ + 8η + O(u²)S.</p>
<p><b>Pressure.</b> p<sub>c</sub> = fl((γ − 1)e<sub>c</sub>) adds u p and ≤ η. Hence</p>
<p style="text-align:center">|p<sub>c</sub> − p| ≤ (γ − 1)[5u S + 4η/ρ + 9η + O(u²)S] + η ≤ (γ − 1)·8u·[S + λ(4/ρ + 10 + 1/(γ − 1))] = b·p<sub>c</sub>,</p>
<p>using η = uλ and b = 8u T/e<sub>c</sub>, with p<sub>c</sub> = (γ − 1)e<sub>c</sub>(1 + δ). The margin from 5 to 8 absorbs the O(u²) terms and the few roundings in evaluating T and b, for u ≤ 2<sup>−24</sup>.</p>
<p><b>Measured.</b> The worst case over 758 733 normal-range cells is 0.32 b (≈ 2.6u relative to T); over 375 k underflow-range cells it is 0.29 b. Both are consistent with the constant 5.</p>
<p class="note">This derivation is careful but written by hand. It has not been machine-checked: a formal proof assistant, or a tool such as Gappa or FPTaylor, would close that gap.</p>
<p class="note">Credits: Mihai Alexandru Bucurenciu (ALADIN): the ALADIN Driver and its kernel architecture, the README Z-pinch benchmark, the refusal-over-healing principle carried over from HLLD, and all GPU campaign runs. Kernel, oracle, campaign and evidence tooling developed with AI assistance (Claude, Anthropic). Independent review by a human third party is pending.</p>
<p class="note"><b>AI assistant Team:</b> SuperGrok, Claude, ChatGPT</p>
"""
css += "\n.hero .eq{font-size:12pt} .pill.red{background:#a33b3b} .camp td{font-size:8pt} .camp td.mono{font-size:7.4pt;line-height:1.35}"
open("/home/claude/primpdf/report.html", "w").write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>ALADIN PRIM v01</title><style>{css}</style></head><body>{body}</body></html>')
print("ok")
