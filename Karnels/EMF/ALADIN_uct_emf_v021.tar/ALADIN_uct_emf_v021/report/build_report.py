# -*- coding: utf-8 -*-
"""Builds report.html for ALADIN UCT-EMF v02.1 (slots 08 + 11) from EMF02_RESULTS.json and the CHAIN-01 legs."""
import json, html
R = json.load(open("/home/claude/emf2/EMF02_RESULTS.json"))
LEG = R["legs_verbatim"]; CPU = {t["id"]: t for t in LEG["cpu"]["tests"]}; GPU = {t["id"]: t for t in LEG["gpu"]["tests"]}
SAN = R["sanitizer_verbatim"]; SHA = R["hashes"]["gpu"]["kernel"]; BSHA = R["hashes"]["gpu"]["build"]; FILES = R["hashes"]["gpu"]["files"]
CH = {k: json.load(open(f"/home/claude/chain/chain01_{k}_results.json")) for k in ("cpu", "gpu")}
css = open("/home/claude/gyropdf/report.html").read().split("<style>")[1].split("</style>")[0]
e = html.escape
def f(x, d=2):
    if x == 0: return "0"
    return f"{x:.{d}e}".replace("e-0", "e-").replace("e+0", "e+").replace("e+", "e")
def pill(c): return f'<span class="pill {dict(VERIFIED="", LIMITATION="gold", BLOCKER="red", INCONCLUSIVE="navy")[c]}">{c}</span>'
def checks_txt(t): return "<br>".join(f"{e(c['name'])}: <b>{f(c['measured'])}</b> {e(c['op'])} {f(c['threshold'],0)}" for c in t["checks"])
exec(open("/home/claude/emfpdf/build_report.py").read().split("TITLES = dict(")[0].split("import")[0])  # noop
src = open("/home/claude/emfpdf/build_report.py").read(); i = src.index("TITLES = dict("); j = src.index("def pill")
exec(src[i:j])
TITLES.update(A01=("Axis closure accuracy (new)", "Cartesian-linear and quadratic fields; axis face overwritten, then closed; nr 16–128"),
              A02=("Axis face stays current (new)", "shear flow v = (s y, 0, 0) changing B_x at the axis; nr = nphi 16–64"),
              A03=("The v02 defect it repairs (new)", "v02 behaviour (axis face never updated) vs v02.1 at nr = 64"),
              R00=("v02.1 = certified v02 (new)", "every EMF, CT face (except the axis face) and force, all sizes, FP64 + FP32"),
              G5=("GPU = CPU bit for bit (new)", "EMF, CT with closure, force; 4 grids incl. a subnormal-scale case; FP64 + FP32"),
              G6=("GPU compile path is IEEE (new)", "direct NVRTC; subnormal ×, +, ÷ bit-identical; no .ftz in the PTX"))
rows = []
for i_ in R["final_class"]:
    if i_.startswith("M"): continue
    ti, cond = TITLES[i_]; c = CPU.get(i_); g = GPU.get(i_)
    rows.append(f"<tr><td>{i_}</td><td><b>{e(ti)}</b><br><span class='note'>{e(cond)}</span></td><td class='mono'>{checks_txt(c) if c else '— (GPU only)'}</td><td class='mono'>{checks_txt(g)}</td><td>{pill(R['final_class'][i_])}</td></tr>")
for k, nm in (("M1_memcheck", "compute-sanitizer memcheck"), ("M2_racecheck", "compute-sanitizer racecheck")):
    s = SAN[k]; line = [l for l in s["summary_lines"] if "SUMMARY" in l][-1].replace("=========", "").strip()
    rows.append(f"<tr><td>{k.split('_')[0]}</td><td><b>{nm}</b><br><span class='note'>EMF, CT + closure, close_axis, force; 6 grids incl. nz = 200 (several axis blocks) and a subnormal-scale case; FP64 + FP32</span></td><td class='mono'>—</td><td class='mono'>{e(line)}</td><td>{pill(R['final_class'][k])}</td></tr>")
TABLE = "\n".join(rows)
chrows = ""
ZT = dict(Z1="static pinch, well-balanced: one-step residual and 300 steps", Z2="static pinch without well-balancing: the one-step residual converges", Z3="perturbed pinch (m = 0, 1): conservation, div B",
          Z5="pinch + B_x crossing the axis: closure every step, div B", Z4="perturbed run, GPU vs CPU trajectory")
for tid in ("Z1", "Z2", "Z3", "Z5", "Z4"):
    c = next((t for t in CH["cpu"]["tests"] if t["id"] == tid), None); g = next((t for t in CH["gpu"]["tests"] if t["id"] == tid), None)
    chrows += f"<tr><td>{tid}</td><td>{e(ZT[tid])}</td><td class='mono'>{checks_txt(c) if c else '—'}</td><td class='mono'>{checks_txt(g)}</td><td>{pill(g['cls'])}</td></tr>"
z4 = next(t for t in CH["gpu"]["tests"] if t["id"] == "Z4")["data"]
genv, cenv = LEG["gpu"]["env"], LEG["cpu"]["env"]
filerows = "".join(f"<tr><td class='mono'>{k}</td><td class='hash'>{v}</td></tr>" for k, v in FILES.items())
A3 = CPU["A03"]["data"]; R0 = CPU["R00"]["data"]
bench = open("/home/claude/bench2/readme_benchmark_output.txt").read()
body = f"""
<section class="cover">
  <div class="kicker">ALADIN Plasma Cosmology · Kernels 08 and 11 · UCT-EMF and UCT-ASSEMBLY</div>
  <h1>ALADIN UCT-EMF v02.1</h1>
  <div class="subtitle">The upwind constrained-transport field update of the native-cylindrical ALADIN Driver, now complete at the axis and bit-identical on GPU and CPU. With it the eleven Driver slots are all filled by certified kernels, and the chained-kernel Z-pinch test runs on the real slot-11 closure</div>
  <div class="rule"></div>
  <div class="meta">
    <b>Author:</b> Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X<br>
    <b>System:</b> ALADIN native-cylindrical GPU MHD Driver: Z-pinch and J × B research<br>
    <b>Release:</b> UCT-EMF v02.1 (in-place update of v02, Zenodo 24394846) · campaign EMF-02 + chained-kernel test CHAIN-01 · 20 November 2026<br>
    <b>Kernel source SHA-256:</b> <span class="hash">{SHA}</span><br>
    <b>Build SHA-256</b> (source + GPU options + CPU flags + loader): <span class="hash">{BSHA}</span><br>
    <b>Legs:</b> CPU (g++ / OpenMP) and GPU ({e(genv['gpu'])}, CUDA runtime {genv['cuda_runtime']}, CuPy {genv['cupy']}, NVRTC called directly); FP64 + FP32
  </div>
  <div class="hero">
    <div class="lbl">Slot 11, UCT-ASSEMBLY, is provided by this kernel</div>
    <div class="eq">upwinded edge EMF (UCT-HLL) → CT Faraday update → axis closure Br(0, φ) = B_x cos φ + B_y sin φ</div>
    <div class="cap">UCT-HLL builds the upwinded EMF directly on each edge from the reconstructed corner states, so no face-to-edge assembly of the Riemann fluxes is needed. The axis Br face, which CT never updates (zero area), is set to its regular limit after every step</div>
  </div>
  <div class="cards">
    <div class="card"><div class="big">25 + 1</div><div class="t">EMF-02 on GPU: 25 VERIFIED, 1 LIMITATION (the documented C12 drift, unchanged); sanitizer 0 errors, 0 hazards</div></div>
    <div class="card"><div class="big">{A3['improvement']:.0f}×</div><div class="t">axis-face accuracy gain over v02 under a field changing at the axis (nr = 64)</div></div>
    <div class="card"><div class="big">0</div><div class="t">FP64 difference from the certified v02 everywhere except the axis face; GPU = CPU bit for bit</div></div>
    <div class="card gold"><div class="big">11 / 11</div><div class="t">Driver slots filled by certified kernels; the chained Z-pinch test passes on both legs</div></div>
  </div>
  <div class="cover-foot">Every number is generated from EMF02_RESULTS.json and the CHAIN-01 leg JSONs.</div>
</section>

<h2 class="pb">1. Why slot 11 is provided by this kernel</h2>
<p>The README describes slot 11 as "constrained-transport assembly and the staggered magnetic-field update". In the classic constrained-transport recipe, the Riemann solver gives fluxes on the faces, and an assembly step averages their magnetic components onto the edges with an upwind correction (Gardiner &amp; Stone style). UCT-EMF uses the UCT-HLL construction (Londrillo &amp; Del Zanna 2004). It builds the upwinded EMF directly on each edge, from the four reconstructed corner states and the upwind wave speeds, so the face-to-edge assembly does not exist as a separate step. It reduces exactly to the upstream (donor) corner for supersonic flow (C01). The staggered update itself (CT Faraday, integral form) was already part of v02.</p>
<p>A review before building kernel 11 found one real gap. The axis Br face (r = 0) has zero area, so CT never updates it. v02 left its value "to the caller", and no caller set it, so it kept its initial value forever. That face enters the axis cell's centred field (PRIM's magnetic energy, HLLD's states) and the axis EMF. v02.1 closes it. Re-certifying the existing CT update as a separate kernel would have counted the same code twice, so slot 11 is filled by this kernel, and the README records the reason.</p>
<p>A possible future upgrade, not a gap: an EMF built from the HLLD wave fan ("UCT-HLLD", reported by Mignone &amp; Del Zanna) would match the field dissipation to the plasma's five-wave solver at strong discontinuities.</p>

<h2>2. What v02.1 changes (in place, same file)</h2>
<ul>
<li><b>Axis closure.</b> After every CT step, the axis Br face is set to its regular limit, Br(0, φ) = B_x cos φ + B_y sin φ. (B_x, B_y) is the m = 1 Fourier mode of Br on the first interior ring of r-faces. This is second order, because the O(r) part of a regular field has no m = 1 component, and it is exact for fields linear in x and y (A01). <code>close_axis()</code> is also public, for initial conditions. The face has zero area, so the cell divergence is untouched (A02).</li>
<li><b>No device trigonometry.</b> cos and sin of the cell angles come from the host, computed in double.</li>
<li><b>Bit-identical build.</b> Contraction is off on both backends and NVRTC is called directly. <code>cupy.RawModule</code> appends <code>-ftz=true</code> (PRIM-01 finding), so the PTX is checked free of <code>.ftz</code>. GPU = CPU bit for bit (G1 now 0.0; G5; G6).</li>
<li><b>Everything else identical.</b> In FP64, every EMF, CT face (except the axis face) and force value is bit-identical to the certified v02 (R00). In FP32 the only differences are at the axis-edge EMFs, at most {R0['fp32_axis_edge_ulps']:.1f} ulp, from the host trigonometry. All seventeen EMF-01 tests are re-run and reproduce their numbers.</li>
</ul>

<h2 class="pb">3. The axis closure</h2>
<figure><img src="emf2_fig.png"><figcaption>Figure 1. Left: closure accuracy, exact for Cartesian-linear fields and second order otherwise. Right: a shear flow v = (s y, 0, 0) drives B_x at the axis (exact solution B = (s B_y t, B_y, 0)). The v02.1 axis face converges at order 2.3; the v02 face stays at its initial value.</figcaption></figure>
<p>At nr = nφ = 64, the v02 axis face is off by {f(A3['v02']['axis_err'])} (the full B_x(t) it never received), against {f(A3['v021']['axis_err'])} for v02.1: a factor of {A3['improvement']:.0f}. The axis cell's magnetic energy improves by {A3['v02_energy_over_v021_energy']:.1f}×.</p>

<h2>4. The README benchmark</h2>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:7.0pt;text-align:left;white-space:pre-wrap">{e(bench)}</div>
<p class="note">The output is identical to the benchmark with v02: the pinch has B_r = 0, so the closure leaves it unchanged.</p>

<h2 class="pb">5. Results: EMF-02, all tests, both legs</h2>
<table class="camp"><tr><th>ID</th><th>Test and conditions</th><th>CPU leg</th><th>GPU leg</th><th>Final</th></tr>
{TABLE}
</table>
<p class="note"><b>Corrected in the CPU dry run before the freeze:</b></p>
<ol class="note">
<li>The first A02 design assumed the shear test is exact on a grid with fixed nφ. It isn't: the azimuthal discretisation error does not shrink when only nr is refined. A02 now refines nφ with nr, and the solution converges.</li>
<li>R00 first demanded FP32 bit-identity at the axis edges, which the change to host trigonometry cannot give. That case is now bounded in ulps, and the bound is reported.</li>
</ol>

<h2 class="pb">6. Chained-kernel Z-pinch test (CHAIN-01)</h2>
<p>Four certified kernels advance the README Z-pinch together: PRIM v01, HLLD v05.1 (three directions), RESIDUAL v01, and UCT-EMF v02.1 (EMF, CT, axis closure). Time stepping is SSP-RK3, with periodic φ and z, reflection at the axis, and the equilibrium held at r = 1. This is a test of the kernels working together; the harness is not a kernel. Run 1 (before v02.1, with the v02 CT) is recorded in history/.</p>
<table class="camp"><tr><th>ID</th><th>Test</th><th>CPU leg</th><th>GPU leg</th><th>Final</th></tr>{chrows}</table>
<ul>
<li><b>Z1, the README pinch in well-balanced mode.</b> It is exactly static, plasma and field: the one-step residual is 0.0, and the state after 300 steps equals the equilibrium, axis cells included.</li>
<li><b>Z2, without well-balancing.</b> The drift is truncation error and converges at order 1.95.</li>
<li><b>Z3, perturbed pinch.</b> Mass and energy are conserved to round-off, and div B stays at round-off.</li>
<li><b>Z5, a field crossing the axis.</b> The slot-11 closure holds at every step, and div B is unchanged.</li>
<li><b>Z4, GPU vs CPU.</b> The trajectories are identical (max |ΔU| = {f(z4['max_dU'])}, max |ΔB| = {f(z4['max_dB'])} over {z4['steps']} SSP-RK3 steps).</li>
</ul>

<h2>7. Limitations and open regimes</h2>
<ul>
<li><b>C12 (unchanged from v02).</b> A static curved field drifts slowly by numerical diffusion. The bound is met, and the class stays LIMITATION.</li>
<li><b>Closure accuracy.</b> The closure is second order, and it uses Br on the first ring only. It requires an even nφ ≥ 4 on axis grids, like the ghost reflection.</li>
<li><b>CHAIN-01 is test scaffolding.</b> The production time integrator, boundary manager and recovery loop belong to the Driver campaign.</li>
</ul>

<h2>8. Integrity and reproduction</h2>
<table><tr><th>File</th><th>SHA-256 (identical on both legs)</th></tr>{filerows}</table>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:9pt;text-align:left">sha256sum -c SHA256SUMS.txt<br>cd code &amp;&amp; python campaign_emf02.py cpu &amp;&amp; python campaign_emf02.py gpu<br>compute-sanitizer --tool memcheck  python sanitizer_target_emf.py<br>compute-sanitizer --tool racecheck python sanitizer_target_emf.py<br>python make_results_emf02.py<br>cd ../chain &amp;&amp; python campaign_chain01.py cpu &amp;&amp; python campaign_chain01.py gpu</div>
<p class="note">CPU leg {e(cenv['utc'])}; GPU leg {e(genv['utc'])}, {e(genv['gpu'])}.</p>
<p class="note">Credits: Mihai Alexandru Bucurenciu (ALADIN): the ALADIN Driver and its eleven-slot architecture, the original upwind donor-corner EMF (aladin_uct_emf_production.py), the README Z-pinch benchmark, the question that settled slot 11, and all GPU campaign runs. v02 / v02.1, oracle, campaigns and evidence tooling developed with AI assistance (Claude, Anthropic). Review of the residual and chained tests by SuperGrok. Independent review by a human third party is pending.</p>
<p class="note"><b>AI assistant Team:</b> SuperGrok, Claude, ChatGPT</p>
"""
css += "\n.hero .eq{font-size:11.5pt} .pill.red{background:#a33b3b} .camp td{font-size:8pt} .camp td.mono{font-size:7.4pt;line-height:1.35}"
open("/home/claude/emf2pdf/report.html", "w").write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>ALADIN UCT-EMF v02.1</title><style>{css}</style></head><body>{body}</body></html>')
print("ok")
