# ALADIN UCT-EMF v02.1 — kernels 08 (UCT-EMF) and 11 (UCT-ASSEMBLY)

The upwind constrained-transport (UCT) field update of the ALADIN native-cylindrical GPU MHD Driver. This is an in-place update of UCT-EMF v02 (Zenodo 24394846).

- **Slot 11, UCT-ASSEMBLY, is provided by this kernel.** UCT-HLL (Londrillo & Del Zanna) builds the upwinded EMF directly on each edge from the reconstructed corner states, so no face-to-edge assembly of the Riemann fluxes is needed. The CT Faraday update was already part of v02.
- **New in v02.1: the axis closure.** The axis Br face (r = 0, zero area) is never updated by CT, and in v02 it stayed at its initial value. It is now set after every step to its regular limit Br(0, φ) = B_x cos φ + B_y sin φ, fitted from the first ring. It is exact for Cartesian-linear fields and second order otherwise; it is 78× more accurate than v02 under a field changing at the axis.
- **Bit-identical GPU and CPU.** Contraction is off, NVRTC is called directly (no CuPy `-ftz=true`), the PTX is checked free of `.ftz`, and cos/sin come from the host.
- **Unchanged elsewhere.** In FP64, v02.1 is bit-identical to the certified v02 everywhere except the axis face. All seventeen EMF-01 tests reproduce.

## Campaign EMF-02

- **GPU leg (NVIDIA L4):** 25 VERIFIED + 1 LIMITATION. The LIMITATION is C12, the documented static-field drift, unchanged from v02.
- **CPU leg:** 20 VERIFIED + 1 LIMITATION.
- **compute-sanitizer:** memcheck 0 errors, racecheck 0 hazards.

## Chained-kernel Z-pinch test, CHAIN-01 (`chain/`)

PRIM v01, HLLD v05.1, RESIDUAL v01 and UCT-EMF v02.1 together advance the README Z-pinch with SSP-RK3.

- **Results:** CPU 4 / 4, GPU 5 / 5.
- **Static pinch:** exactly static (well-balanced) for 300 steps.
- **Perturbed runs:** conserve mass and energy to round-off, with div B at round-off.
- **Field crossing the axis:** the closure holds at every step.
- **GPU vs CPU:** the trajectories are bit-identical.

Run 1 (with the v02 CT) is in `history/`.

## Reproduce

```
sha256sum -c SHA256SUMS.txt
cd code && python campaign_emf02.py cpu && python campaign_emf02.py gpu
compute-sanitizer --tool memcheck  python sanitizer_target_emf.py
compute-sanitizer --tool racecheck python sanitizer_target_emf.py
python make_results_emf02.py
cd ../chain && python campaign_chain01.py cpu && python campaign_chain01.py gpu
cd ../benchmark && python readme_benchmark.py
```

## Hashes

- Kernel source SHA-256: `341ebaf6c26706fe8679579a58af8382cbfc96c94386f2c509dd31c3ba958aa0`
- Build SHA-256: `6ae7dcc19697351ffa01bc7d7cf8699799dbf12aa1bdb8f97229f33220b06ab4`

Author: Mihai Alexandru Bucurenciu (ALADIN), ORCID 0009-0006-4457-557X.

AI assistant Team: SuperGrok, Claude, ChatGPT
