# -*- coding: utf-8 -*-
"""
CHAIN-01 (chained-kernel Z-pinch test, run 2 of ZP-STEP-01): the one-step (and multi-step) residual of the README Z-pinch,
advanced by the certified kernels PRIM v01 -> HLLD v05.1 -> RESIDUAL v01 + UCT-EMF v02.1 (EMF + CT + axis closure; slot 11),
SSP-RK3, in the test harness zp_step.py.  Not a kernel: a test of the kernels working together.
A Driver-precursor check (requested after review by SuperGrok): it certifies no new kernel; it tests that the certified
kernels, chained, keep the equilibrium and conserve what they must.   python campaign_zps01.py cpu | gpu
One-step residual: R_U = (U^{n+1} - U^n) / dt (interior), R_B = (B^{n+1} - B^n) / dt (all faces).  Thresholds PREDECLARED.
"""
import sys, os, time, json, hashlib, platform, datetime, traceback, subprocess, warnings
import numpy as np
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import zp_step as Z

CERTIFIED = {"prim_v01.py": ("source", "1557231bd1c46802139c499db9d55e40f22524cd279e72eac21b4c8ebe430535"),
             "hlld_v05.py": ("source", "16f555aea33100e9159e950da8afc2d5c182461965d67dc50f3d34a6b9775fe4"),
             "residual_v01.py": ("source", "51a243e9038ee77542557f11e4302f902c84a08cceb2c4e0fbbcf019149cd6c4"),
             "uct_emf_v02.py": ("source", "341ebaf6c26706fe8679579a58af8382cbfc96c94386f2c509dd31c3ba958aa0")}
THRESHOLDS = dict(Z1_one_step_wb=0.0, Z1_multi_step_wb=0.0, Z2_l1_order=1.8, Z3_refused=0.0, Z3_conservation=1e-13, Z3_divB=1e-12, Z4_refused=0.0)

LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
BACKEND = "cupy" if LEG == "gpu" else "cpu"
LOG = None
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True)
    if LOG: LOG.write(s + "\n"); LOG.flush()
host = lambda x: x.get() if hasattr(x, "get") else x

def one_step(P, U, B):
    dt = P.dt_cfl(U, B); U1, B1, _ = P.step(U, B, dt)
    rU = [float(abs(host(P.interior(a)) - host(P.interior(b))).max()) / dt for a, b in zip(U1, U)]
    rB = [float(abs(host(a) - host(b)).max()) / dt for a, b in zip(B1, B)]
    return U1, B1, dt, rU, rB

# ------------------------------------------------------------------ tests
def Z1():
    """static README pinch, well-balanced: one-step residual and a 300-step run"""
    P = Z.Pinch(32, 16, 8, backend=BACKEND, wb=True); U, B = P.initial()
    U1, B1, dt, rU, rB = one_step(P, U, B)
    U0 = [host(x).copy() for x in U]; B0 = [host(x).copy() for x in B]; Ui, Bi = U1, B1; t = dt
    for n in range(299):
        d = P.dt_cfl(Ui, Bi); Ui, Bi, _ = P.step(Ui, Bi, d); t += d
    drift = max(max(float(abs(host(P.interior(a)) - P.interior(b)).max()) for a, b in zip(Ui, U0)), max(float(abs(host(a) - b).max()) for a, b in zip(Bi, B0)))
    return dict(conditions="nr x nphi x nz = 32 x 16 x 8 axis grid, CFL 0.4, SSP-RK3, well-balanced (HLLD W_eq + exact faces, RESIDUAL R_eq)",
                one_step_R_U=rU, one_step_R_B=rB, dt=dt, steps=300, t_end=t, drift_after_300=drift, refused=P.refused), \
        [("one-step max |R_U|, |R_B| (axis cells included)", max(rU + rB), "<=", THRESHOLDS["Z1_one_step_wb"]),
         ("max |state - equilibrium| after 300 steps", drift, "<=", THRESHOLDS["Z1_multi_step_wb"])]

def Z2():
    """static README pinch WITHOUT well-balancing: the one-step residual is the truncation error; it must converge"""
    rows = []; l1 = []
    for nr in (16, 32, 64, 128):
        P = Z.Pinch(nr, 8, 4, backend=BACKEND, wb=False); U, B = P.initial(); dt = P.dt_cfl(U, B); U1, B1, _ = P.step(U, B, dt)
        RU = [np.abs(host(P.interior(a)) - host(P.interior(b))) / dt for a, b in zip(U1, U)]
        RB = [np.abs(host(a) - host(b)) / dt for a, b in zip(B1, B)]
        L1 = float(sum(r.mean() for r in RU)); l1.append(L1)
        rows.append(dict(nr=nr, dt=dt, L1_R_U=L1, max_R_U=[float(r.max()) for r in RU], max_R_B=[float(r.max()) for r in RB], axis_cell_max=float(max(r[0].max() for r in RU))))
    o = [float(np.log2(l1[i] / l1[i + 1])) for i in range(3)]
    return dict(conditions="nphi x nz = 8 x 4, nr = 16..128, one SSP-RK3 step, no W_eq / R_eq; L1 = mean over interior cells, summed over the 5 components", rows=rows, l1_orders=o), \
        [("final L1 convergence order of the one-step residual", o[-1], ">=", THRESHOLDS["Z2_l1_order"])]

def perturbed(m_mode, amp=1e-6, t_end=0.2, nr=32, nphi=16, nz=16, backend=None):
    P = Z.Pinch(nr, nphi, nz, backend=backend or BACKEND, wb=True); U, B = P.initial(); g = P.g
    G = P.GE; rc = G.r_centers[:, None, None]; ph = G.phi_c[None, :, None]; zc = G.z_c[None, None, :]
    dp = amp * np.exp(-((rc - 0.5) / 0.08) ** 2) * np.cos(2 * np.pi * zc) * (np.cos(m_mode * ph) if m_mode else 1.0)
    dE = dp / (Z.GAM - 1); U[4] = U[4] + P.to(dE * np.ones(P.sh)); P.fill(U, B)
    Ueq = [host(x).copy() for x in P.U_eq]
    dev = lambda U_: max(float(abs(host(P.interior(a)) - P.interior(b)).max()) for a, b in zip(U_, Ueq))
    tot0 = P.totals(U, B); t = 0.0; series = [(0.0, dev(U), 0.0)]; n = 0
    while t < t_end - 1e-12:
        dt = min(P.dt_cfl(U, B), t_end - t); Un, Bn, _ = P.step(U, B, dt)
        rstep = max(float(abs(host(P.interior(a)) - host(P.interior(b))).max()) for a, b in zip(Un, U)) / dt
        U, B = Un, Bn; t += dt; n += 1
        if n % 10 == 0 or t >= t_end - 1e-12: series.append((t, dev(U), rstep))
    tot1 = P.totals(U, B)
    cons = {k: abs(tot1[k] - tot0[k]) / max(abs(tot0[k]), 1e-300) if k in ("mass", "energy") else abs(tot1[k] - tot0[k]) for k in ("mass", "energy", "pz", "L")}
    return P, U, B, dict(steps=n, t_end=t, series=series, conservation=cons, divB_norm=tot1["divB_norm"], refused=P.refused, totals0=tot0, totals1=tot1)

def Z3():
    """perturbed pinch (well-balanced): watch the residual grow / decay; conservation and div B to round-off"""
    out = {}; worst_c = 0.0; worst_d = 0.0; ref = 0
    for m in (0, 1):
        P, U, B, d = perturbed(m); out[f"m={m}"] = d
        worst_c = max(worst_c, d["conservation"]["mass"], d["conservation"]["energy"]); worst_d = max(worst_d, d["divB_norm"]); ref += d["refused"]
        d["growth_factor"] = d["series"][-1][1] / d["series"][0][1]
    return dict(conditions="32 x 16 x 16 axis grid; pressure perturbation 1e-6 exp(-((r-0.5)/0.08)^2) cos(2 pi z) [x cos(phi) for m = 1]; well-balanced; t = 0.2 "
                           "(waves stay inside r < 1, so the totals must be exactly conserved); series = (t, max |U - U_eq|, one-step residual)", **out), \
        [("refused cells", float(ref), "<=", THRESHOLDS["Z3_refused"]), ("relative change of total mass and energy", worst_c, "<=", THRESHOLDS["Z3_conservation"]),
         ("max normalised div B", worst_d, "<=", THRESHOLDS["Z3_divB"])]

def Z4():
    """GPU leg only: the perturbed run on GPU vs the same run on CPU (measurement: UCT-EMF v02 was certified to tolerance, not bitwise)"""
    Pg, Ug, Bg, dg = perturbed(0, t_end=0.05, backend="cupy"); Pc, Uc, Bc, dc = perturbed(0, t_end=0.05, backend="cpu")
    dU = max(float(abs(host(a) - b).max()) for a, b in zip(Ug, Uc)); dB = max(float(abs(host(a) - b).max()) for a, b in zip(Bg, Bc))
    pert = dc["series"][-1][1]
    return dict(conditions="m = 0 perturbed run to t = 0.05, GPU vs CPU", max_dU=dU, max_dB=dB, perturbation_size=pert, rel_to_perturbation=dU / pert, steps=dc["steps"]), \
        [("refused cells (GPU run)", float(dg["refused"]), "<=", THRESHOLDS["Z4_refused"])]


def Z5():
    """the pinch with a small uniform transverse field B_x = 1e-3 added (it crosses the axis and exercises the slot-11 axis
    closure).  B_x is built as curl A with A_z = B_x y on the edges (discretely divergence-free), the outer ghosts carry the same
    field.  Not an equilibrium (J_z B_x pushes the plasma), so this is a dynamics check: 100 SSP-RK3 steps, no refusal,
    the cell divergence unchanged to round-off, and the axis face always equal to the closure of its ring."""
    import uct_emf_v02 as Em, prim_v01 as PRm
    P = Z.Pinch(32, 16, 8, backend="cpu", wb=True); G = P.GE; g = P.g
    bx = 1e-3; Az = np.zeros(G.shape("Ez")); Az[:] = (bx * G.r_faces[:, None, None] * np.sin(G.phi_f)[None, :, None])
    B = [np.ascontiguousarray(x.copy()) for x in P.B_eq]
    Em.ct_update(G, *B, np.zeros(G.shape("Er")), np.zeros(G.shape("Ephi")), Az, -1.0)       # B += curl A (interior faces) + axis closure
    for a, a_ex in zip(B, (bx * np.cos(G.phi_c)[None, :, None], -bx * np.sin(G.phi_f)[None, :, None], 0.0)):  # ghosts: the same field
        m = np.ones(a.shape, bool); m[g:-g, g:-g, g:-g] = False; full = P.B_eq[[0, 1, 2][[id(x) for x in B].index(id(a))]] + a_ex
        a[m] = (full * np.ones(a.shape))[m]
    pr0 = PRm.primitives(P.GP, *P.U_eq, *P.B_eq); Un = PRm.conserved(P.GP, pr0["rho"], pr0["vr"], pr0["vphi"], pr0["vz"], pr0["p"], *B)
    U = [x.copy() for x in P.U_eq]; U[4] = Un["E"]
    P.B_eq = [x.copy() for x in B]; P.U_eq = [x.copy() for x in U]                         # outer ghosts held at this state
    if BACKEND == "cupy":
        import cupy as cpm
        P2 = Z.Pinch(32, 16, 8, backend="cupy", wb=True); P2.B_eq = [cpm.asarray(x) for x in P.B_eq]; P2.U_eq = [cpm.asarray(x) for x in P.U_eq]; P = P2
        U = [cpm.asarray(x) for x in U]; B = [cpm.asarray(x) for x in B]
    P.fill(U, B); div0 = host(Em.divergence(P.GE, *B)[0]); ax0 = None
    worst_cons = 0.0
    for n in range(100):
        dt = P.dt_cfl(U, B); U, B, _ = P.step(U, B, dt)
        Brh = host(B[0]); ring = Brh[g + 1, g:g + G.nphi, g:g + G.nz]; ph = (np.arange(G.nphi) + 0.5) * G.dphi
        bxf = 2 * (ring * np.cos(ph)[:, None]).sum(0) / G.nphi; byf = 2 * (ring * np.sin(ph)[:, None]).sum(0) / G.nphi
        worst_cons = max(worst_cons, float(np.abs(Brh[g, g:g + G.nphi, g:g + G.nz] - (bxf[None, :] * np.cos(ph)[:, None] + byf[None, :] * np.sin(ph)[:, None])).max()))
    div1 = host(Em.divergence(P.GE, *B)[0]); ddiv = float(np.abs(div1 - div0).max()) / float(np.abs(host(B[1])).max() * G.dr * G.dz)
    return dict(conditions="32 x 16 x 8, pinch + B_x = 1e-3 (curl A), 100 SSP-RK3 steps, well-balanced about the pinch; outer ghosts held at the initial state",
                refused=P.refused, div_change_norm=ddiv, axis_closure_consistency=worst_cons, axis_Bx_final=float(bxf.mean()), axis_By_final=float(byf.mean())), \
        [("refused cells", float(P.refused), "<=", 0.0), ("max change of the cell divergence (normalised)", ddiv, "<=", THRESHOLDS["Z3_divB"]),
         ("axis face = closure of its ring, every step", worst_cons, "<=", 1e-15)]

CPU_TESTS = [Z1, Z2, Z3, Z5]
GPU_TESTS = [Z4]
OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def env():
    e = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, backend=BACKEND, platform=platform.platform(),
             python=sys.version.split()[0], numpy=np.__version__)
    if BACKEND == "cupy":
        import cupy as cp; e["cupy"] = cp.__version__; e["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode()
    return e

if __name__ == "__main__":
    LOG = open(os.path.join(HERE, f"chain01_{LEG}.log"), "w")
    srcs = {"prim_v01.py": Z.PR.SOURCE_SHA256, "hlld_v05.py": Z.H.SOURCE_SHA256, "residual_v01.py": Z.RS.SOURCE_SHA256, "uct_emf_v02.py": Z.E.SOURCE_SHA256}
    files = ["zp_step.py", "campaign_chain01.py"] + [f"kernels/{k}" for k in srcs]
    R = dict(campaign="CHAIN-01", what="Driver-precursor: certified kernels chained on the README Z-pinch", env=env(), kernel_source_sha256=srcs,
             file_sha256={f: sha(os.path.join(HERE, f)) for f in files}, thresholds=THRESHOLDS, tests=[])
    log(f"CHAIN-01 leg={LEG} backend={BACKEND} kernels " + " | ".join(f"{k} {v[:12]}" for k, v in srcs.items()))
    ok_hash = all(srcs[k].startswith(v[1]) for k, v in CERTIFIED.items())
    if not ok_hash: log("BLOCKER: a kernel is not the certified source"); R["tests"].append(dict(id="HASH", cls="BLOCKER", passed=False))
    tests = CPU_TESTS + (GPU_TESTS if LEG == "gpu" else [])
    for f in tests:
        t0 = time.time(); rec = dict(id=f.__name__)
        try:
            data, checks = f(); rec["data"] = data
            rec["checks"] = [dict(name=n, measured=float(v), op=op, threshold=float(th), passed=bool(OPS[op](float(v), float(th)))) for n, v, op, th in checks]
            rec["passed"] = all(c["passed"] for c in rec["checks"]); rec["cls"] = "VERIFIED" if rec["passed"] else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["passed"] = False; rec["exception"] = traceback.format_exc()
        rec["seconds"] = round(time.time() - t0, 2); R["tests"].append(rec)
        log(f"{rec['id']:4s} {rec['cls']:10s} {rec['seconds']:8.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec.get("checks", [])))
        if "exception" in rec: log(rec["exception"])
        if rec["id"] == "Z3" and "data" in rec:
            for k in ("m=0", "m=1"):
                d = rec["data"][k]; log(f"     {k}: steps {d['steps']}, growth max|U-U_eq| x{d['growth_factor']:.3f}, conservation {d['conservation']}, divB {d['divB_norm']:.1e}")
                for t_, dv, rs in d["series"][::3]: log(f"        t={t_:.3f}  max|U-U_eq|={dv:.3e}  one-step residual={rs:.3e}")
        if rec["id"] == "Z4" and "data" in rec: log("     ", {k: v for k, v in rec["data"].items() if k != "conditions"})
    counts = {}
    for t in R["tests"]: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    R["summary"] = counts; log("SUMMARY", counts)
    json.dump(R, open(os.path.join(HERE, f"chain01_{LEG}_results.json"), "w"), indent=1, default=float)
