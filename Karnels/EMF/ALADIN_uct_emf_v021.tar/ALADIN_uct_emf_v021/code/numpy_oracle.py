# -*- coding: utf-8 -*-
"""
Independent NumPy oracle for uct_emf_v02: the edge EMFs, the CT Faraday update and the Lorentz force written directly from
the equations (vectorised array algebra over whole edge sets; no shared code with the CUDA/C++ source).

Equations (mu0 = 1).  For an edge along direction 3 with transverse directions (1, 2), corner states (a, b), a = side in 1,
b = side in 2 (0 = low / left, 1 = high / right):
    E^ab = -(v1^ab B2^a - v2^ab B1^b)
    a1+ = max(0, max_ab(v1^ab + c^ab)), a1- = max(0, max_ab(c^ab - v1^ab)), same for direction 2
    E = [a1+ a2+ E^00 + a1+ a2- E^01 + a1- a2+ E^10 + a1- a2- E^11] / ((a1+ + a1-)(a2+ + a2-))
        + a1+ a1- (B2^1 - B2^0) / (a1+ + a1-) - a2+ a2- (B1^1 - B1^0) / (a2+ + a2-)
    plus eta * J3_edge + hall * (J x B)_3,edge / rho_edge  (four-cell averages around the edge)
Reconstruction: limited linear (MC or minmod), cell value + 1/2 slope toward the edge in each transverse direction.
E_z: (1, 2) = (r, phi), B2 = B_phi (phi-faces), B1 = B_r (r-faces).  E_r: (1, 2) = (phi, z), B2 = B_z, B1 = B_phi.
E_phi: (1, 2) = (z, r), B2 = B_r, B1 = B_z.
Axis z-edge: E from phi-averaged Cartesian components of the first ring; axis E_phi = azimuthal projection of the
Cartesian axis E at the z-face (mean of the two neighbouring z centres).
CT: Br -= dt [dEz/(r dphi) - dEphi/dz];  Bphi -= dt [dEr/dz - dEz/dr];  Bz -= dt [d(r Ephi) dphi - dEr dr] / area.
"""
import numpy as np


def mc(dl, dr):
    s = np.sign(dl)
    out = s * np.minimum(np.minimum(2 * np.abs(dl), 2 * np.abs(dr)), 0.5 * np.abs(dl + dr))
    return np.where(dl * dr > 0, out, 0.0)


def minmod(dl, dr):
    return np.where(dl * dr > 0, np.sign(dl) * np.minimum(np.abs(dl), np.abs(dr)), 0.0)


LIMITER = {"mc": mc, "minmod": minmod}
_lim = [mc]


def slope(q, axis):
    """limited slope of q along axis, defined for indices 1..n-2 (edges padded with 0)"""
    qm = np.roll(q, 1, axis); qp = np.roll(q, -1, axis)
    s = _lim[0](q - qm, qp - q)
    idx = [slice(None)] * q.ndim; idx[axis] = 0; s[tuple(idx)] = 0; idx[axis] = -1; s[tuple(idx)] = 0
    return s


def cart_axis(G, F, k):
    """Cartesian averages over the first ring at z-centre index k (absolute)."""
    g, P = G.g, G.nphi
    ph = (np.arange(P) + 0.5) * G.dphi; c, s = np.cos(ph), np.sin(ph)
    ring = lambda a: a[g, g:g + P, k]
    br = 0.5 * (F["Br"][g, g:g + P, k] + F["Br"][g + 1, g:g + P, k]); bp = 0.5 * (F["Bphi"][g, g:g + P, k] + F["Bphi"][g, g + 1:g + P + 1, k])
    bz = 0.5 * (F["Bz"][g, g:g + P, k] + F["Bz"][g, g:g + P, k + 1])
    vx = np.mean(ring(F["vr"]) * c - ring(F["vp"]) * s); vy = np.mean(ring(F["vr"]) * s + ring(F["vp"]) * c); vz = np.mean(ring(F["vz"]))
    bx = np.mean(br * c - bp * s); by = np.mean(br * s + bp * c); bzz = np.mean(bz); rho = np.mean(ring(F["rho"]))
    Ex, Ey, Ez = -(vy * bzz - vz * by), -(vz * bx - vx * bzz), -(vx * by - vy * bx)
    if F.get("J") is not None:
        Jr, Jp, Jz = F["J"]
        jx = np.mean(ring(Jr) * c - ring(Jp) * s); jy = np.mean(ring(Jr) * s + ring(Jp) * c); jz = np.mean(ring(Jz))
        Ex += F["eta"] * jx; Ey += F["eta"] * jy; Ez += F["eta"] * jz
        h = F["hall"]
        Ex += h * (jy * bzz - jz * by) / rho; Ey += h * (jz * bx - jx * bzz) / rho; Ez += h * (jx * by - jy * bx) / rho
    return Ex, Ey, Ez


def oracle(G, Br, Bphi, Bz, vr, vp, vz, rho, p, J=None, gamma=5 / 3, eta=0.0, hall=0.0, limiter="mc"):
    _lim[0] = LIMITER[limiter]
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz
    F = dict(Br=Br, Bphi=Bphi, Bz=Bz, vr=vr, vp=vp, vz=vz, rho=rho, J=J, eta=eta, hall=hall)
    brc = 0.5 * (Br[:-1] + Br[1:]); bpc = 0.5 * (Bphi[:, :-1] + Bphi[:, 1:]); bzc = 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])
    cf = np.sqrt(gamma * p / rho + (brc ** 2 + bpc ** 2 + bzc ** 2) / rho)
    # limited slopes of cell fields in every direction
    sl = {name: [slope(q, ax) for ax in range(3)] for name, q in (("vr", vr), ("vp", vp), ("vz", vz))}
    if J is not None:
        Jr, Jp, Jz = J
    def corner(name, q, I, Jx, K, si, sj, sk):
        v = q[I, Jx, K]
        if si: v = v + 0.5 * si * sl[name][0][I, Jx, K]
        if sj: v = v + 0.5 * sj * sl[name][1][I, Jx, K]
        if sk: v = v + 0.5 * sk * sl[name][2][I, Jx, K]
        return v
    def combine(v1, v2, c, B2, B1):
        a1p = np.maximum(0, np.max([v1[a][b] + c[a][b] for a in (0, 1) for b in (0, 1)], axis=0))
        a1m = np.maximum(0, np.max([c[a][b] - v1[a][b] for a in (0, 1) for b in (0, 1)], axis=0))
        a2p = np.maximum(0, np.max([v2[a][b] + c[a][b] for a in (0, 1) for b in (0, 1)], axis=0))
        a2m = np.maximum(0, np.max([c[a][b] - v2[a][b] for a in (0, 1) for b in (0, 1)], axis=0))
        w1, w2 = (a1p, a1m), (a2p, a2m)
        Ecorner = lambda a, b: -(v1[a][b] * B2[a] - v2[a][b] * B1[b])
        num = sum(w1[a] * w2[b] * Ecorner(a, b) for a in (0, 1) for b in (0, 1))
        return num / ((a1p + a1m) * (a2p + a2m)) + a1p * a1m / (a1p + a1m) * (B2[1] - B2[0]) - a2p * a2m / (a2p + a2m) * (B1[1] - B1[0])
    def avg4(q, cells): return 0.25 * sum(q[c] for c in cells)

    Ez = np.zeros(G.shape("Ez")); Er = np.zeros(G.shape("Er")); Ep = np.zeros(G.shape("Ephi"))
    # ---- E_z, edges I in [g, g+n], Jf in [g, g+P], K in [g, g+Z-1]
    I = np.arange(g, g + n + 1)[:, None, None]; Jf = np.arange(g, g + P + 1)[None, :, None]; K = np.arange(g, g + Z)[None, None, :]
    v1 = [[corner("vr", vr, I - 1 + a, Jf - 1 + b, K, 1 - 2 * a, 1 - 2 * b, 0) for b in (0, 1)] for a in (0, 1)]
    v2 = [[corner("vp", vp, I - 1 + a, Jf - 1 + b, K, 1 - 2 * a, 1 - 2 * b, 0) for b in (0, 1)] for a in (0, 1)]
    c = [[cf[I - 1 + a, Jf - 1 + b, K] for b in (0, 1)] for a in (0, 1)]
    spr = slope(Bphi, 0); sbp = slope(Br, 1)
    B2 = [Bphi[I - 1 + a, Jf, K] + 0.5 * (1 - 2 * a) * spr[I - 1 + a, Jf, K] for a in (0, 1)]
    B1 = [Br[I, Jf - 1 + b, K] + 0.5 * (1 - 2 * b) * sbp[I, Jf - 1 + b, K] for b in (0, 1)]
    ez = combine(v1, v2, c, B2, B1)
    if J is not None:
        cells = [(I - 1, Jf - 1, K), (I, Jf - 1, K), (I - 1, Jf, K), (I, Jf, K)]
        ez = ez + eta * avg4(Jz, cells)
        if hall:
            ez = ez + hall * (avg4(Jr, cells) * avg4(bpc, cells) - avg4(Jp, cells) * avg4(brc, cells)) / avg4(rho, cells)
    Ez[g:g + n + 1, g:g + P + 1, g:g + Z] = ez
    if G.axis:
        for k in range(g, g + Z): Ez[g, g:g + P + 1, k] = cart_axis(G, F, k)[2]
    # ---- E_r, edges I in [g, g+n-1], Jf in [g, g+P], Kf in [g, g+Z]
    I = np.arange(g, g + n)[:, None, None]; Kf = np.arange(g, g + Z + 1)[None, None, :]
    v1 = [[corner("vp", vp, I, Jf - 1 + a, Kf - 1 + b, 0, 1 - 2 * a, 1 - 2 * b) for b in (0, 1)] for a in (0, 1)]
    v2 = [[corner("vz", vz, I, Jf - 1 + a, Kf - 1 + b, 0, 1 - 2 * a, 1 - 2 * b) for b in (0, 1)] for a in (0, 1)]
    c = [[cf[I, Jf - 1 + a, Kf - 1 + b] for b in (0, 1)] for a in (0, 1)]
    szp = slope(Bz, 1); spz = slope(Bphi, 2)
    B2 = [Bz[I, Jf - 1 + a, Kf] + 0.5 * (1 - 2 * a) * szp[I, Jf - 1 + a, Kf] for a in (0, 1)]
    B1 = [Bphi[I, Jf, Kf - 1 + b] + 0.5 * (1 - 2 * b) * spz[I, Jf, Kf - 1 + b] for b in (0, 1)]
    er = combine(v1, v2, c, B2, B1)
    if J is not None:
        cells = [(I, Jf - 1, Kf - 1), (I, Jf, Kf - 1), (I, Jf - 1, Kf), (I, Jf, Kf)]
        er = er + eta * avg4(Jr, cells)
        if hall:
            er = er + hall * (avg4(Jp, cells) * avg4(bzc, cells) - avg4(Jz, cells) * avg4(bpc, cells)) / avg4(rho, cells)
    Er[g:g + n, g:g + P + 1, g:g + Z + 1] = er
    # ---- E_phi, edges I in [g, g+n], Jc in [g, g+P-1], Kf in [g, g+Z]
    I = np.arange(g, g + n + 1)[:, None, None]; Jc = np.arange(g, g + P)[None, :, None]
    v1 = [[corner("vz", vz, I - 1 + b, Jc, Kf - 1 + a, 1 - 2 * b, 0, 1 - 2 * a) for b in (0, 1)] for a in (0, 1)]
    v2 = [[corner("vr", vr, I - 1 + b, Jc, Kf - 1 + a, 1 - 2 * b, 0, 1 - 2 * a) for b in (0, 1)] for a in (0, 1)]
    c = [[cf[I - 1 + b, Jc, Kf - 1 + a] for b in (0, 1)] for a in (0, 1)]
    srz = slope(Br, 2); szr = slope(Bz, 0)
    B2 = [Br[I, Jc, Kf - 1 + a] + 0.5 * (1 - 2 * a) * srz[I, Jc, Kf - 1 + a] for a in (0, 1)]
    B1 = [Bz[I - 1 + b, Jc, Kf] + 0.5 * (1 - 2 * b) * szr[I - 1 + b, Jc, Kf] for b in (0, 1)]
    ep = combine(v1, v2, c, B2, B1)
    if J is not None:
        cells = [(I - 1, Jc, Kf - 1), (I, Jc, Kf - 1), (I - 1, Jc, Kf), (I, Jc, Kf)]
        ep = ep + eta * avg4(Jp, cells)
        if hall:
            ep = ep + hall * (avg4(Jz, cells) * avg4(brc, cells) - avg4(Jr, cells) * avg4(bzc, cells)) / avg4(rho, cells)
    Ep[g:g + n + 1, g:g + P, g:g + Z + 1] = ep
    if G.axis:
        ph = (np.arange(P) + 0.5) * G.dphi
        for kf in range(g, g + Z + 1):
            a0, a1 = cart_axis(G, F, kf - 1), cart_axis(G, F, kf)
            Ep[g, g:g + P, kf] = 0.5 * (-(a0[0] + a1[0]) * np.sin(ph) + (a0[1] + a1[1]) * np.cos(ph))
    return Er, Ep, Ez


def ct_oracle(G, Br, Bphi, Bz, Er, Ep, Ez, dt):
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz
    Br, Bphi, Bz = Br.copy(), Bphi.copy(), Bz.copy(); rf = G.r_faces
    I = slice(g, g + n + 1); J = slice(g, g + P); K = slice(g, g + Z)
    r = rf[g:g + n + 1][:, None, None]
    with np.errstate(divide="ignore", invalid="ignore"):
        dBr = -dt * ((Ez[I, g + 1:g + P + 1, K] - Ez[I, J, K]) / (r * G.dphi) - (Ep[I, J, g + 1:g + Z + 1] - Ep[I, J, K]) / G.dz)
    dBr = np.where(r == 0, 0.0, dBr); Br[I, J, K] += dBr
    Ic = slice(g, g + n); Jf = slice(g, g + P + 1)
    Bphi[Ic, Jf, K] -= dt * ((Er[Ic, Jf, g + 1:g + Z + 1] - Er[Ic, Jf, K]) / G.dz - (Ez[g + 1:g + n + 1, Jf, K] - Ez[Ic, Jf, K]) / G.dr)
    Kf = slice(g, g + Z + 1); r0 = rf[g:g + n][:, None, None]; r1 = rf[g + 1:g + n + 1][:, None, None]
    area = 0.5 * (r1 ** 2 - r0 ** 2) * G.dphi
    circ = (r1 * Ep[g + 1:g + n + 1, J, Kf] - r0 * Ep[Ic, J, Kf]) * G.dphi - (Er[Ic, g + 1:g + P + 1, Kf] - Er[Ic, J, Kf]) * G.dr
    Bz[Ic, J, Kf] -= dt * circ / area
    if G.axis:
        axis_closure_oracle(G, Br)
    return Br, Bphi, Bz


def axis_closure_oracle(G, Br):
    """v02.1 axis closure, restated: a regular field has Br(0, phi) = Bx cos(phi) + By sin(phi); (Bx, By) from the m = 1
    least-squares (discrete Fourier) fit of Br on the first interior r-face ring, interior phi and z."""
    g, P, Z = G.g, G.nphi, G.nz
    ph = (np.arange(P) + 0.5) * G.dphi; c, s = np.cos(ph)[:, None], np.sin(ph)[:, None]
    ring = Br[g + 1, g:g + P, g:g + Z]
    bx = 2.0 * (ring * c).sum(0) / P; by = 2.0 * (ring * s).sum(0) / P
    Br[g, g:g + P, g:g + Z] = bx[None, :] * c + by[None, :] * s


def force_oracle(G, Br, Bphi, Bz, J):
    Jr, Jp, Jz = J
    br = 0.5 * (Br[:-1] + Br[1:]); bp = 0.5 * (Bphi[:, :-1] + Bphi[:, 1:]); bz = 0.5 * (Bz[:, :, :-1] + Bz[:, :, 1:])
    return Jp * bz - Jz * bp, Jz * br - Jr * bz, Jr * bp - Jp * br
