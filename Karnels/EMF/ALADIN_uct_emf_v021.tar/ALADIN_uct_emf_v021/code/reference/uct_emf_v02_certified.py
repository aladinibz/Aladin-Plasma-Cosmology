# -*- coding: utf-8 -*-
"""
uct_emf_v02.py — ALADIN UCT-EMF v02: upwind constrained-transport electric field and Faraday update on the native
cylindrical Yee grid (kernel 08 of the ALADIN Driver).

Successor of aladin_uct_emf_production.py (author: Mihai Alexandru Bucurenciu), which established the sign convention
E_z = v_phi B_r - v_r B_phi and the upstream (donor) choice of corners; that file computed E_z only and left the current
and force blocks as placeholders.  v02 is a complete rewrite (new numbered file):

  * all three edge EMFs, E_r, E_phi, E_z, on their own edges, including the axis
  * UCT-HLL upwinding (Londrillo & Del Zanna 2004; Del Zanna et al. 2007): for an edge along direction 3 with transverse
    directions 1, 2 and corner states (a, b) in {L, R}^2,
        E3 = sum_ab a1^(+/-) a2^(+/-) E^ab / ((a1+ + a1-)(a2+ + a2-))
             + a1+ a1- / (a1+ + a1-) (B2^R - B2^L)  -  a2+ a2- / (a2+ + a2-) (B1^R - B1^L),
        E^ab = -(v1^ab B2^a - v2^ab B1^b)          (E = -v x B for the ideal part)
    with second-order limited (MC or minmod) reconstruction of v to the corners and of the face-normal B along the edge's
    transverse direction, and a1+/- = max(0, +/-(v1 -/+ c_f)) over the corner states, c_f = sqrt(gamma p/rho + |B|^2/rho)
    (an upper bound of the fast speed).  For supersonic flow this reduces exactly to the upstream (donor) corner.
  * Ohm's law  E = -v x B + eta J + hall (J x B) / rho, with J taken from the verified UCT_CURL kernel (cell centres,
    averaged to the edge); mu0 = 1 as in UCT_CURL.
  * CT Faraday update in integral form with true cylindrical lengths and areas:  dPhi_face/dt = -circulation(E), so the
    discrete divergence (net flux out of every cell) is preserved to round-off for ANY edge EMF.
  * Lorentz force f = J x B at cell centres.

GRID CONTRACT (as UCT_CURL v1.3; z fastest, C order, one dtype)
    Br   (nr+1+2g, nphi+2g,   nz+2g  )   Bphi (nr+2g, nphi+1+2g, nz+2g)   Bz (nr+2g, nphi+2g, nz+1+2g)
    cells: vr, vphi, vz, rho, p, Jr, Jphi, Jz  (nr+2g, nphi+2g, nz+2g)
    Ez  (nr+1+2g, nphi+1+2g, nz+2g  )  at (r_face, phi_face, z_centre)
    Er  (nr+2g,   nphi+1+2g, nz+1+2g)  at (r_centre, phi_face, z_face)
    Ephi(nr+1+2g, nphi+2g,   nz+1+2g)  at (r_face, phi_centre, z_face)
    r_faces (nr+1+2g), r_centers (nr+2g) with ghosts; uniform dr, dphi (radians), dz; g >= 2.
    Ghost cells/faces of every input must be filled by the caller (periodic phi, z and outer r BCs; on an axis grid the
    inner radial ghosts by reflection through the axis: fill_axis_ghosts() does it, nphi even).
    Axis mode iff r_faces[g] == 0: the axis z-edge EMF is the single-valued Cartesian value from the first ring, and
    E_phi on axis edges is its azimuthal projection (it carries zero length in every circulation).
    Edges computed: every edge that bounds an interior face.  Faces updated: every interior face except the axis Br face
    (zero area; its limiting value belongs to the caller, as in UCT_CURL).
"""
import os, hashlib, ctypes, subprocess, tempfile
import numpy as np

VERSION = "uct_emf v02 2026-11-20"

SRC = r"""
#ifdef EMF_GPU
  #define DEV __device__ __forceinline__
#else
  #include <cmath>
  using namespace std;
  #define DEV static inline
#endif
typedef REAL R;

struct Grid {
    int nr, nphi, nz, g;
    R dr, dphi, dz, gamma, eta, hall;
    int limiter;     // 0 = minmod, 1 = MC
    int axis;        // 1 iff r_faces[g] == 0
};

// strides (z fastest)
#define S_C(a,b,c)   (((a)*(G.nphi+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BR(a,b,c)  (((a)*(G.nphi+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BP(a,b,c)  (((a)*(G.nphi+1+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BZ(a,b,c)  (((a)*(G.nphi+2*G.g) + (b))*(G.nz+1+2*G.g) + (c))
#define S_EZ(a,b,c)  (((a)*(G.nphi+1+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_ER(a,b,c)  (((a)*(G.nphi+1+2*G.g) + (b))*(G.nz+1+2*G.g) + (c))
#define S_EP(a,b,c)  (((a)*(G.nphi+2*G.g) + (b))*(G.nz+1+2*G.g) + (c))

DEV R lim(R dl, R dr_, int kind) {
    if (dl*dr_ <= R(0)) return R(0);
    R s = dl > R(0) ? R(1) : R(-1);
    R a = fabs(dl), b = fabs(dr_);
    if (kind == 0) return s*fmin(a, b);
    return s*fmin(fmin(R(2)*a, R(2)*b), R(0.5)*(a + b));
}

struct Fields {
    const R *Br, *Bp, *Bz, *vr, *vp, *vz, *rho, *p, *Jr, *Jp, *Jz;
};

// cell-centred B (face averages)
DEV R brc(const Fields& F, const Grid& G, int i, int j, int k) { return R(0.5)*(F.Br[S_BR(i,j,k)] + F.Br[S_BR(i+1,j,k)]); }
DEV R bpc(const Fields& F, const Grid& G, int i, int j, int k) { return R(0.5)*(F.Bp[S_BP(i,j,k)] + F.Bp[S_BP(i,j+1,k)]); }
DEV R bzc(const Fields& F, const Grid& G, int i, int j, int k) { return R(0.5)*(F.Bz[S_BZ(i,j,k)] + F.Bz[S_BZ(i,j,k+1)]); }

DEV R cfast(const Fields& F, const Grid& G, int i, int j, int k) {
    R rho = F.rho[S_C(i,j,k)];
    R b2 = brc(F,G,i,j,k)*brc(F,G,i,j,k) + bpc(F,G,i,j,k)*bpc(F,G,i,j,k) + bzc(F,G,i,j,k)*bzc(F,G,i,j,k);
    return sqrt(fmax(G.gamma*F.p[S_C(i,j,k)]/rho + b2/rho, R(0)));
}

// value of a cell field at the corner of cell (i,j,k) displaced by (si, sj, sk) half-cells (each in {-1,0,+1})
DEV R corner(const R* q, const Grid& G, int i, int j, int k, int si, int sj, int sk) {
    R c = q[S_C(i,j,k)], v = c;
    if (si) v += R(0.5)*si*lim(c - q[S_C(i-1,j,k)], q[S_C(i+1,j,k)] - c, G.limiter);
    if (sj) v += R(0.5)*sj*lim(c - q[S_C(i,j-1,k)], q[S_C(i,j+1,k)] - c, G.limiter);
    if (sk) v += R(0.5)*sk*lim(c - q[S_C(i,j,k-1)], q[S_C(i,j,k+1)] - c, G.limiter);
    return v;
}
DEV R avg4(const R* q, const Grid& G, int i0, int j0, int k0, int i1, int j1, int k1, int i2, int j2, int k2, int i3, int j3, int k3) {
    return R(0.25)*(q[S_C(i0,j0,k0)] + q[S_C(i1,j1,k1)] + q[S_C(i2,j2,k2)] + q[S_C(i3,j3,k3)]);
}

// generic UCT-HLL combination.  v1[a][b], v2[a][b]: corner velocities (a = side in dir 1, b = side in dir 2);
// B2[a]: dir-2-normal field left/right in dir 1;  B1[b]: dir-1-normal field left/right in dir 2;  c[a][b] fast speeds
DEV R uct(const R v1[2][2], const R v2[2][2], const R B2[2], const R B1[2], const R c[2][2]) {
    R a1p = R(0), a1m = R(0), a2p = R(0), a2m = R(0);
    for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) {
        a1p = fmax(a1p, v1[a][b] + c[a][b]); a1m = fmax(a1m, -(v1[a][b] - c[a][b]));
        a2p = fmax(a2p, v2[a][b] + c[a][b]); a2m = fmax(a2m, -(v2[a][b] - c[a][b]));
    }
    R w1[2] = {a1p, a1m}, w2[2] = {a2p, a2m};
    R s1 = a1p + a1m, s2 = a2p + a2m, E = R(0);
    for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b)
        E += w1[a]*w2[b]*(-(v1[a][b]*B2[a] - v2[a][b]*B1[b]));
    E /= s1*s2;
    E += a1p*a1m/s1*(B2[1] - B2[0]) - a2p*a2m/s2*(B1[1] - B1[0]);
    return E;
}

// ---------------- E_z on z-edge (I, J, K): r_face I, phi_face J, z centre K; dirs (1,2) = (r, phi) ----------------
DEV R ez_axis(const Fields& F, const Grid& G, const R* rc, int K, R* Ex_out, R* Ey_out) {
    // single-valued axis value from the first ring: Cartesian averages over phi (smooth through the axis)
    int i = G.g; R vx = 0, vy = 0, vzz = 0, bx = 0, by = 0, bz = 0, jx = 0, jy = 0, jz = 0, rho = 0;
    for (int j = G.g; j < G.g + G.nphi; ++j) {
        R ph = (R(j - G.g) + R(0.5))*G.dphi, cs = cos(ph), sn = sin(ph);
        R vr = F.vr[S_C(i,j,K)], vp = F.vp[S_C(i,j,K)];
        R br = brc(F,G,i,j,K), bp = bpc(F,G,i,j,K);
        vx += vr*cs - vp*sn; vy += vr*sn + vp*cs; vzz += F.vz[S_C(i,j,K)];
        bx += br*cs - bp*sn; by += br*sn + bp*cs; bz += bzc(F,G,i,j,K);
        if (F.Jr) { R Jr = F.Jr[S_C(i,j,K)], Jp = F.Jp[S_C(i,j,K)]; jx += Jr*cs - Jp*sn; jy += Jr*sn + Jp*cs; jz += F.Jz[S_C(i,j,K)]; }
        rho += F.rho[S_C(i,j,K)];
    }
    R n = R(G.nphi); vx /= n; vy /= n; vzz /= n; bx /= n; by /= n; bz /= n; jx /= n; jy /= n; jz /= n; rho /= n;
    R Ex = -(vy*bz - vzz*by), Ey = -(vzz*bx - vx*bz), Ez = -(vx*by - vy*bx);
    if (F.Jr) {
        Ex += G.eta*jx; Ey += G.eta*jy; Ez += G.eta*jz;
        if (G.hall != R(0)) { Ex += G.hall*(jy*bz - jz*by)/rho; Ey += G.hall*(jz*bx - jx*bz)/rho; Ez += G.hall*(jx*by - jy*bx)/rho; }
    }
    if (Ex_out) { *Ex_out = Ex; *Ey_out = Ey; }
    return Ez;
}

DEV R ez_edge(const Fields& F, const Grid& G, const R* rf, const R* rc, int I, int J, int K) {
    if (G.axis && I == G.g) return ez_axis(F, G, rc, K, (R*)0, (R*)0);
    R v1[2][2], v2[2][2], c[2][2], B2[2], B1[2];
    for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) {
        int i = I - 1 + a, j = J - 1 + b, si = a ? -1 : 1, sj = b ? -1 : 1;
        v1[a][b] = corner(F.vr, G, i, j, K, si, sj, 0);
        v2[a][b] = corner(F.vp, G, i, j, K, si, sj, 0);
        c[a][b] = cfast(F, G, i, j, K);
    }
    // B2 = B_phi on phi-faces (I-1, J) and (I, J), reconstructed in r toward the edge
    for (int a = 0; a < 2; ++a) {
        int i = I - 1 + a, s = a ? -1 : 1; R q = F.Bp[S_BP(i,J,K)];
        B2[a] = q + R(0.5)*s*lim(q - F.Bp[S_BP(i-1,J,K)], F.Bp[S_BP(i+1,J,K)] - q, G.limiter);
    }
    // B1 = B_r on r-faces (I, J-1) and (I, J), reconstructed in phi toward the edge
    for (int b = 0; b < 2; ++b) {
        int j = J - 1 + b, s = b ? -1 : 1; R q = F.Br[S_BR(I,j,K)];
        B1[b] = q + R(0.5)*s*lim(q - F.Br[S_BR(I,j-1,K)], F.Br[S_BR(I,j+1,K)] - q, G.limiter);
    }
    R E = uct(v1, v2, B2, B1, c);
    if (F.Jr) {
        R jz = avg4(F.Jz, G, I-1,J-1,K, I,J-1,K, I-1,J,K, I,J,K);
        E += G.eta*jz;
        if (G.hall != R(0)) {
            R jr = avg4(F.Jr, G, I-1,J-1,K, I,J-1,K, I-1,J,K, I,J,K), jp = avg4(F.Jp, G, I-1,J-1,K, I,J-1,K, I-1,J,K, I,J,K);
            R br = R(0.25)*(brc(F,G,I-1,J-1,K) + brc(F,G,I,J-1,K) + brc(F,G,I-1,J,K) + brc(F,G,I,J,K));
            R bp = R(0.25)*(bpc(F,G,I-1,J-1,K) + bpc(F,G,I,J-1,K) + bpc(F,G,I-1,J,K) + bpc(F,G,I,J,K));
            R rho = avg4(F.rho, G, I-1,J-1,K, I,J-1,K, I-1,J,K, I,J,K);
            E += G.hall*(jr*bp - jp*br)/rho;
        }
    }
    return E;
}

// ---------------- E_r on r-edge (I, J, K): r centre I, phi_face J, z_face K; dirs (1,2) = (phi, z) ----------------
DEV R er_edge(const Fields& F, const Grid& G, int I, int J, int K) {
    R v1[2][2], v2[2][2], c[2][2], B2[2], B1[2];
    for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) {
        int j = J - 1 + a, k = K - 1 + b, sj = a ? -1 : 1, sk = b ? -1 : 1;
        v1[a][b] = corner(F.vp, G, I, j, k, 0, sj, sk);
        v2[a][b] = corner(F.vz, G, I, j, k, 0, sj, sk);
        c[a][b] = cfast(F, G, I, j, k);
    }
    // B2 = B_z on z-faces (I, J-1, K), (I, J, K), reconstructed in phi
    for (int a = 0; a < 2; ++a) {
        int j = J - 1 + a, s = a ? -1 : 1; R q = F.Bz[S_BZ(I,j,K)];
        B2[a] = q + R(0.5)*s*lim(q - F.Bz[S_BZ(I,j-1,K)], F.Bz[S_BZ(I,j+1,K)] - q, G.limiter);
    }
    // B1 = B_phi on phi-faces (I, J, K-1), (I, J, K), reconstructed in z
    for (int b = 0; b < 2; ++b) {
        int k = K - 1 + b, s = b ? -1 : 1; R q = F.Bp[S_BP(I,J,k)];
        B1[b] = q + R(0.5)*s*lim(q - F.Bp[S_BP(I,J,k-1)], F.Bp[S_BP(I,J,k+1)] - q, G.limiter);
    }
    R E = uct(v1, v2, B2, B1, c);
    if (F.Jr) {
        R jr = avg4(F.Jr, G, I,J-1,K-1, I,J,K-1, I,J-1,K, I,J,K);
        E += G.eta*jr;
        if (G.hall != R(0)) {
            R jp = avg4(F.Jp, G, I,J-1,K-1, I,J,K-1, I,J-1,K, I,J,K), jz = avg4(F.Jz, G, I,J-1,K-1, I,J,K-1, I,J-1,K, I,J,K);
            R bp = R(0.25)*(bpc(F,G,I,J-1,K-1) + bpc(F,G,I,J,K-1) + bpc(F,G,I,J-1,K) + bpc(F,G,I,J,K));
            R bz = R(0.25)*(bzc(F,G,I,J-1,K-1) + bzc(F,G,I,J,K-1) + bzc(F,G,I,J-1,K) + bzc(F,G,I,J,K));
            R rho = avg4(F.rho, G, I,J-1,K-1, I,J,K-1, I,J-1,K, I,J,K);
            E += G.hall*(jp*bz - jz*bp)/rho;
        }
    }
    return E;
}

// ---------------- E_phi on phi-edge (I, J, K): r_face I, phi centre J, z_face K; dirs (1,2) = (z, r) ----------------
DEV R ep_edge(const Fields& F, const Grid& G, const R* rc, int I, int J, int K) {
    if (G.axis && I == G.g) {
        // azimuthal projection of the single-valued axis field, at the z-face: average of the two z centres
        R ex0, ey0, ex1, ey1; ez_axis(F, G, rc, K-1, &ex0, &ey0); ez_axis(F, G, rc, K, &ex1, &ey1);
        R ph = (R(J - G.g) + R(0.5))*G.dphi;
        return R(0.5)*(-(ex0 + ex1)*sin(ph) + (ey0 + ey1)*cos(ph));
    }
    R v1[2][2], v2[2][2], c[2][2], B2[2], B1[2];
    for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) {
        int k = K - 1 + a, i = I - 1 + b, sk = a ? -1 : 1, si = b ? -1 : 1;
        v1[a][b] = corner(F.vz, G, i, J, k, si, 0, sk);
        v2[a][b] = corner(F.vr, G, i, J, k, si, 0, sk);
        c[a][b] = cfast(F, G, i, J, k);
    }
    // B2 = B_r on r-faces (I, J, K-1), (I, J, K), reconstructed in z
    for (int a = 0; a < 2; ++a) {
        int k = K - 1 + a, s = a ? -1 : 1; R q = F.Br[S_BR(I,J,k)];
        B2[a] = q + R(0.5)*s*lim(q - F.Br[S_BR(I,J,k-1)], F.Br[S_BR(I,J,k+1)] - q, G.limiter);
    }
    // B1 = B_z on z-faces (I-1, J, K), (I, J, K), reconstructed in r
    for (int b = 0; b < 2; ++b) {
        int i = I - 1 + b, s = b ? -1 : 1; R q = F.Bz[S_BZ(i,J,K)];
        B1[b] = q + R(0.5)*s*lim(q - F.Bz[S_BZ(i-1,J,K)], F.Bz[S_BZ(i+1,J,K)] - q, G.limiter);
    }
    R E = uct(v1, v2, B2, B1, c);
    if (F.Jr) {
        R jp = avg4(F.Jp, G, I-1,J,K-1, I,J,K-1, I-1,J,K, I,J,K);
        E += G.eta*jp;
        if (G.hall != R(0)) {
            R jz = avg4(F.Jz, G, I-1,J,K-1, I,J,K-1, I-1,J,K, I,J,K), jr = avg4(F.Jr, G, I-1,J,K-1, I,J,K-1, I-1,J,K, I,J,K);
            R bz = R(0.25)*(bzc(F,G,I-1,J,K-1) + bzc(F,G,I,J,K-1) + bzc(F,G,I-1,J,K) + bzc(F,G,I,J,K));
            R br = R(0.25)*(brc(F,G,I-1,J,K-1) + brc(F,G,I,J,K-1) + brc(F,G,I-1,J,K) + brc(F,G,I,J,K));
            R rho = avg4(F.rho, G, I-1,J,K-1, I,J,K-1, I-1,J,K, I,J,K);
            E += G.hall*(jz*br - jr*bz)/rho;
        }
    }
    return E;
}

// ---------------- CT Faraday update of one face (integral form) ----------------
DEV void ct_br(R* Br, const R* Ez, const R* Ep, const R* rf, const Grid& G, R dt, int I, int J, int K) {
    R r = rf[I]; if (r == R(0)) return;      // axis face: zero area, limiting value owned by the caller
    Br[S_BR(I,J,K)] -= dt*((Ez[S_EZ(I,J+1,K)] - Ez[S_EZ(I,J,K)])/(r*G.dphi) - (Ep[S_EP(I,J,K+1)] - Ep[S_EP(I,J,K)])/G.dz);
}
DEV void ct_bp(R* Bp, const R* Er, const R* Ez, const Grid& G, R dt, int I, int J, int K) {
    Bp[S_BP(I,J,K)] -= dt*((Er[S_ER(I,J,K+1)] - Er[S_ER(I,J,K)])/G.dz - (Ez[S_EZ(I+1,J,K)] - Ez[S_EZ(I,J,K)])/G.dr);
}
DEV void ct_bz(R* Bz, const R* Er, const R* Ep, const R* rf, const Grid& G, R dt, int I, int J, int K) {
    R r0 = rf[I], r1 = rf[I+1], area = R(0.5)*(r1*r1 - r0*r0)*G.dphi;
    R circ = (r1*Ep[S_EP(I+1,J,K)] - r0*Ep[S_EP(I,J,K)])*G.dphi - (Er[S_ER(I,J+1,K)] - Er[S_ER(I,J,K)])*G.dr;
    Bz[S_BZ(I,J,K)] -= dt*circ/area;
}

// ---------------- Lorentz force f = J x B (cell centres) ----------------
DEV void lorentz(const Fields& F, const Grid& G, R* fr, R* fp, R* fz, int i, int j, int k) {
    R br = brc(F,G,i,j,k), bp = bpc(F,G,i,j,k), bz = bzc(F,G,i,j,k);
    R Jr = F.Jr[S_C(i,j,k)], Jp = F.Jp[S_C(i,j,k)], Jz = F.Jz[S_C(i,j,k)];
    fr[S_C(i,j,k)] = Jp*bz - Jz*bp; fp[S_C(i,j,k)] = Jz*br - Jr*bz; fz[S_C(i,j,k)] = Jr*bp - Jp*br;
}

DEV void decode(long t, int n0, int n1, int n2, int* a, int* b, int* c) { *c = int(t % n2); t /= n2; *b = int(t % n1); *a = int(t / n1); }

#define ARGS_F const R* Br, const R* Bp, const R* Bz, const R* vr, const R* vp, const R* vz, const R* rho, const R* p, \
               const R* Jr, const R* Jp, const R* Jz, const R* rf, const R* rc, \
               int nr, int nphi, int nz, int g, R dr, R dphi, R dz, R gamma, R eta, R hall, int limiter, int use_j
#define MAKE_GF Grid G; G.nr = nr; G.nphi = nphi; G.nz = nz; G.g = g; G.dr = dr; G.dphi = dphi; G.dz = dz; G.gamma = gamma; \
    G.eta = eta; G.hall = hall; G.limiter = limiter; G.axis = (rf[g] == R(0)); \
    Fields F; F.Br = Br; F.Bp = Bp; F.Bz = Bz; F.vr = vr; F.vp = vp; F.vz = vz; F.rho = rho; F.p = p; \
    F.Jr = use_j ? Jr : (const R*)0; F.Jp = Jp; F.Jz = Jz;

// edge ranges: Ez I in [g, g+nr], J in [g, g+nphi], K in [g, g+nz-1]; Er I in [g, g+nr-1], J in [g, g+nphi], K in [g, g+nz];
//              Ephi I in [g, g+nr], J in [g, g+nphi-1], K in [g, g+nz]
DEV void emf_one(long t, ARGS_F, R* Er, R* Ep, R* Ez) {
    MAKE_GF
    long nEz = long(nr+1)*(nphi+1)*nz, nEr = long(nr)*(nphi+1)*(nz+1), nEp = long(nr+1)*nphi*(nz+1);
    int a, b, c;
    if (t < nEz) { decode(t, nr+1, nphi+1, nz, &a, &b, &c); Ez[S_EZ(a+g,b+g,c+g)] = ez_edge(F, G, rf, rc, a+g, b+g, c+g); return; }
    t -= nEz;
    if (t < nEr) { decode(t, nr, nphi+1, nz+1, &a, &b, &c); Er[S_ER(a+g,b+g,c+g)] = er_edge(F, G, a+g, b+g, c+g); return; }
    t -= nEr;
    if (t < nEp) { decode(t, nr+1, nphi, nz+1, &a, &b, &c); Ep[S_EP(a+g,b+g,c+g)] = ep_edge(F, G, rc, a+g, b+g, c+g); }
}
DEV void ct_one(long t, R* Br, R* Bp, R* Bz, const R* Er, const R* Ep, const R* Ez, const R* rf,
                int nr, int nphi, int nz, int g, R dr, R dphi, R dz, R dt) {
    Grid G; G.nr = nr; G.nphi = nphi; G.nz = nz; G.g = g; G.dr = dr; G.dphi = dphi; G.dz = dz;
    long nBr = long(nr+1)*nphi*nz, nBp = long(nr)*(nphi+1)*nz, nBz = long(nr)*nphi*(nz+1);
    int a, b, c;
    if (t < nBr) { decode(t, nr+1, nphi, nz, &a, &b, &c); ct_br(Br, Ez, Ep, rf, G, dt, a+g, b+g, c+g); return; }
    t -= nBr;
    if (t < nBp) { decode(t, nr, nphi+1, nz, &a, &b, &c); ct_bp(Bp, Er, Ez, G, dt, a+g, b+g, c+g); return; }
    t -= nBp;
    if (t < nBz) { decode(t, nr, nphi, nz+1, &a, &b, &c); ct_bz(Bz, Er, Ep, rf, G, dt, a+g, b+g, c+g); }
}

#ifdef EMF_GPU
extern "C" __global__ void emf_kernel(ARGS_F, R* Er, R* Ep, R* Ez, long ntot) {
    long t = long(blockIdx.x)*blockDim.x + threadIdx.x;
    if (t < ntot) emf_one(t, Br, Bp, Bz, vr, vp, vz, rho, p, Jr, Jp, Jz, rf, rc, nr, nphi, nz, g, dr, dphi, dz, gamma, eta, hall, limiter, use_j, Er, Ep, Ez);
}
extern "C" __global__ void ct_kernel(R* Br, R* Bp, R* Bz, const R* Er, const R* Ep, const R* Ez, const R* rf,
                                     int nr, int nphi, int nz, int g, R dr, R dphi, R dz, R dt, long ntot) {
    long t = long(blockIdx.x)*blockDim.x + threadIdx.x;
    if (t < ntot) ct_one(t, Br, Bp, Bz, Er, Ep, Ez, rf, nr, nphi, nz, g, dr, dphi, dz, dt);
}
extern "C" __global__ void force_kernel(ARGS_F, R* fr, R* fp, R* fz) {
    long t = long(blockIdx.x)*blockDim.x + threadIdx.x; long n = long(nr)*nphi*nz;
    if (t >= n) return;
    MAKE_GF
    int a, b, c; decode(t, nr, nphi, nz, &a, &b, &c); lorentz(F, G, fr, fp, fz, a+g, b+g, c+g);
}
#else
extern "C" void emf_cpu(ARGS_F, R* Er, R* Ep, R* Ez, long ntot) {
    #pragma omp parallel for schedule(static)
    for (long t = 0; t < ntot; ++t)
        emf_one(t, Br, Bp, Bz, vr, vp, vz, rho, p, Jr, Jp, Jz, rf, rc, nr, nphi, nz, g, dr, dphi, dz, gamma, eta, hall, limiter, use_j, Er, Ep, Ez);
}
extern "C" void ct_cpu(R* Br, R* Bp, R* Bz, const R* Er, const R* Ep, const R* Ez, const R* rf,
                       int nr, int nphi, int nz, int g, R dr, R dphi, R dz, R dt, long ntot) {
    #pragma omp parallel for schedule(static)
    for (long t = 0; t < ntot; ++t) ct_one(t, Br, Bp, Bz, Er, Ep, Ez, rf, nr, nphi, nz, g, dr, dphi, dz, dt);
}
extern "C" void force_cpu(ARGS_F, R* fr, R* fp, R* fz) {
    long n = long(nr)*nphi*nz;
    #pragma omp parallel for schedule(static)
    for (long t = 0; t < n; ++t) { MAKE_GF int a, b, c; decode(t, nr, nphi, nz, &a, &b, &c); lorentz(F, G, fr, fp, fz, a+g, b+g, c+g); }
}
#endif
"""

SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()
_cache = {}


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


def _cpu_lib(dtype, extra=()):
    real = "double" if dtype == np.float64 else "float"
    key = ("cpu", real, tuple(extra))
    if key in _cache: return _cache[key]
    d = os.path.join(tempfile.gettempdir(), "uct_emf_v02_" + hashlib.sha256((SRC + real + str(extra)).encode()).hexdigest()[:16])
    os.makedirs(d, exist_ok=True); so = os.path.join(d, "emf.so")
    if not os.path.exists(so):
        open(os.path.join(d, "emf.cpp"), "w").write(SRC)
        cmd = ["g++", "-O2", "-shared", "-fPIC", "-fopenmp", f"-DREAL={real}", *extra, "-o", so, os.path.join(d, "emf.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError(r.stderr)
    lib = ctypes.CDLL(so); _cache[key] = lib; return lib


def _gpu_mod(dtype):
    import cupy as cp
    real = "double" if dtype == np.float64 else "float"
    key = ("gpu", real)
    if key not in _cache:
        _cache[key] = cp.RawModule(code=SRC, options=("-DEMF_GPU", f"-DREAL={real}", "-std=c++14"))
    return _cache[key]


class Grid:
    """Grid description + array allocation helpers.  r_faces / r_centers with ghosts (axis grid: r_faces[g] == 0)."""

    def __init__(self, nr, nphi, nz, rmin, rmax, zlen=1.0, g=2, dtype=np.float64, xp=np):
        self.nr, self.nphi, self.nz, self.g, self.dtype, self.xp = nr, nphi, nz, g, dtype, xp
        self.dr = (rmax - rmin) / nr; self.dphi = 2 * np.pi / nphi; self.dz = zlen / nz; self.rmin = rmin
        rf = rmin + (np.arange(nr + 1 + 2 * g) - g) * self.dr
        if rmin == 0: rf[g] = 0.0
        self.r_faces = rf; self.r_centers = 0.5 * (rf[:-1] + rf[1:])
        self.phi_c = (np.arange(nphi + 2 * g) - g + 0.5) * self.dphi; self.phi_f = (np.arange(nphi + 1 + 2 * g) - g) * self.dphi
        self.z_c = (np.arange(nz + 2 * g) - g + 0.5) * self.dz; self.z_f = (np.arange(nz + 1 + 2 * g) - g) * self.dz
        self.axis = rmin == 0

    def shape(self, kind):
        n, p, z, g = self.nr, self.nphi, self.nz, self.g
        return dict(cell=(n + 2 * g, p + 2 * g, z + 2 * g), Br=(n + 1 + 2 * g, p + 2 * g, z + 2 * g), Bphi=(n + 2 * g, p + 1 + 2 * g, z + 2 * g),
                    Bz=(n + 2 * g, p + 2 * g, z + 1 + 2 * g), Ez=(n + 1 + 2 * g, p + 1 + 2 * g, z + 2 * g),
                    Er=(n + 2 * g, p + 1 + 2 * g, z + 1 + 2 * g), Ephi=(n + 1 + 2 * g, p + 2 * g, z + 1 + 2 * g))[kind]

    def zeros(self, kind):
        return self.xp.zeros(self.shape(kind), dtype=self.dtype)


def _args_common(G, xp, dt):
    sc = np.float64 if dt == np.float64 else np.float32
    return sc


def compute_emf(G, Br, Bphi, Bz, vr, vphi, vz, rho, p, J=None, gamma=5 / 3, eta=0.0, hall=0.0, limiter="mc", backend="cpu", cpu_extra=()):
    """Edge EMFs (Er, Ephi, Ez).  J = (Jr, Jphi, Jz) at cell centres (from UCT_CURL), required if eta or hall != 0."""
    dt = G.dtype; xp = G.xp
    if (eta or hall) and J is None: raise ValueError("eta / hall need J from UCT_CURL")
    Er, Ep, Ez = G.zeros("Er"), G.zeros("Ephi"), G.zeros("Ez")
    Jr, Jp, Jz = J if J is not None else (vr, vr, vr)
    rf = xp.asarray(G.r_faces, dtype=dt); rc = xp.asarray(G.r_centers, dtype=dt)
    ntot = (G.nr + 1) * (G.nphi + 1) * G.nz + G.nr * (G.nphi + 1) * (G.nz + 1) + (G.nr + 1) * G.nphi * (G.nz + 1)
    sc = np.float64 if dt == np.float64 else np.float32
    lim = 1 if limiter == "mc" else 0
    arrs = [Br, Bphi, Bz, vr, vphi, vz, rho, p, Jr, Jp, Jz, rf, rc]
    scal = [np.int32(G.nr), np.int32(G.nphi), np.int32(G.nz), np.int32(G.g), sc(G.dr), sc(G.dphi), sc(G.dz), sc(gamma), sc(eta), sc(hall), np.int32(lim), np.int32(J is not None)]
    if backend == "cupy":
        k = _gpu_mod(dt).get_function("emf_kernel")
        k(((ntot + 127) // 128,), (128,), tuple(arrs) + tuple(scal) + (Er, Ep, Ez, np.int64(ntot)))
    else:
        lib = _cpu_lib(dt, cpu_extra); ct = ctypes.c_double if dt == np.float64 else ctypes.c_float
        P = lambda a: np.ascontiguousarray(a).ctypes.data_as(ctypes.c_void_p)
        lib.emf_cpu(*[P(a) for a in arrs], ctypes.c_int(G.nr), ctypes.c_int(G.nphi), ctypes.c_int(G.nz), ctypes.c_int(G.g),
                    ct(G.dr), ct(G.dphi), ct(G.dz), ct(gamma), ct(eta), ct(hall), ctypes.c_int(lim), ctypes.c_int(int(J is not None)),
                    P(Er), P(Ep), P(Ez), ctypes.c_long(ntot))
    return Er, Ep, Ez


def ct_update(G, Br, Bphi, Bz, Er, Ephi, Ez, dt_step, backend="cpu", cpu_extra=()):
    """In-place CT Faraday update of every interior face: dB/dt = -curl E (integral form)."""
    dt = G.dtype; xp = G.xp; sc = np.float64 if dt == np.float64 else np.float32
    rf = xp.asarray(G.r_faces, dtype=dt)
    ntot = (G.nr + 1) * G.nphi * G.nz + G.nr * (G.nphi + 1) * G.nz + G.nr * G.nphi * (G.nz + 1)
    if backend == "cupy":
        k = _gpu_mod(dt).get_function("ct_kernel")
        k(((ntot + 127) // 128,), (128,), (Br, Bphi, Bz, Er, Ephi, Ez, rf, np.int32(G.nr), np.int32(G.nphi), np.int32(G.nz), np.int32(G.g),
                                           sc(G.dr), sc(G.dphi), sc(G.dz), sc(dt_step), np.int64(ntot)))
    else:
        lib = _cpu_lib(dt, cpu_extra); ct = ctypes.c_double if dt == np.float64 else ctypes.c_float
        P = lambda a: a.ctypes.data_as(ctypes.c_void_p)
        for a in (Br, Bphi, Bz): assert a.flags.c_contiguous
        lib.ct_cpu(P(Br), P(Bphi), P(Bz), P(np.ascontiguousarray(Er)), P(np.ascontiguousarray(Ephi)), P(np.ascontiguousarray(Ez)), P(rf),
                   ctypes.c_int(G.nr), ctypes.c_int(G.nphi), ctypes.c_int(G.nz), ctypes.c_int(G.g), ct(G.dr), ct(G.dphi), ct(G.dz), ct(dt_step), ctypes.c_long(ntot))


def lorentz_force(G, Br, Bphi, Bz, J, backend="cpu"):
    """f = J x B at interior cell centres (J from UCT_CURL)."""
    dt = G.dtype; xp = G.xp; sc = np.float64 if dt == np.float64 else np.float32
    fr, fp, fz = G.zeros("cell"), G.zeros("cell"), G.zeros("cell")
    Jr, Jp, Jz = J; dummy = Jr; rf = xp.asarray(G.r_faces, dtype=dt); rc = xp.asarray(G.r_centers, dtype=dt)
    arrs = [Br, Bphi, Bz, dummy, dummy, dummy, dummy, dummy, Jr, Jp, Jz, rf, rc]
    scal_np = [np.int32(G.nr), np.int32(G.nphi), np.int32(G.nz), np.int32(G.g), sc(G.dr), sc(G.dphi), sc(G.dz), sc(1), sc(0), sc(0), np.int32(1), np.int32(1)]
    n = G.nr * G.nphi * G.nz
    if backend == "cupy":
        _gpu_mod(dt).get_function("force_kernel")(((n + 127) // 128,), (128,), tuple(arrs) + tuple(scal_np) + (fr, fp, fz))
    else:
        lib = _cpu_lib(dt); ct = ctypes.c_double if dt == np.float64 else ctypes.c_float
        P = lambda a: np.ascontiguousarray(a).ctypes.data_as(ctypes.c_void_p)
        lib.force_cpu(*[P(a) for a in arrs], ctypes.c_int(G.nr), ctypes.c_int(G.nphi), ctypes.c_int(G.nz), ctypes.c_int(G.g),
                      ct(G.dr), ct(G.dphi), ct(G.dz), ct(1), ct(0), ct(0), ctypes.c_int(1), ctypes.c_int(1), P(fr), P(fp), P(fz))
    return fr, fp, fz


def divergence(G, Br, Bphi, Bz):
    """Net magnetic flux out of every interior cell (integral form), and the same normalised by the largest face flux."""
    g, n, p, z = G.g, G.nr, G.nphi, G.nz; xp = G.xp
    rf = xp.asarray(G.r_faces); I = slice(g, g + n); Jc = slice(g, g + p); K = slice(g, g + z)
    fr1 = Br[g + 1:g + n + 1, Jc, K] * rf[g + 1:g + n + 1, None, None] * G.dphi * G.dz
    fr0 = Br[g:g + n, Jc, K] * rf[g:g + n, None, None] * G.dphi * G.dz
    fp1 = Bphi[I, g + 1:g + p + 1, K] * G.dr * G.dz; fp0 = Bphi[I, g:g + p, K] * G.dr * G.dz
    area = (0.5 * (rf[g + 1:g + n + 1] ** 2 - rf[g:g + n] ** 2) * G.dphi)[:, None, None]
    fz1 = Bz[I, Jc, g + 1:g + z + 1] * area; fz0 = Bz[I, Jc, g:g + z] * area
    d = fr1 - fr0 + fp1 - fp0 + fz1 - fz0
    scale = max(float(xp.abs(a).max()) for a in (fr1, fr0, fp1, fp0, fz1, fz0))
    return d, d / max(scale, 1e-300)      # net flux per cell, and normalised by the largest face flux on the grid


# ------------------------------------------------------------------ ghost filling (for tests; the Driver's BoundaryManager owns this)
def fill_periodic(G, *arrays, kinds):
    """periodic ghosts in phi and z (kinds: 'cell', 'Br', 'Bphi', 'Bz'); the face that closes the period is set equal to
    the first face.  Test helper: the Driver's BoundaryManager owns boundary conditions."""
    g, P, Z = G.g, G.nphi, G.nz
    for a, kd in zip(arrays, kinds):
        if kd == "Bphi":
            a[:, g + P, :] = a[:, g, :]; a[:, :g, :] = a[:, P:P + g, :]; a[:, g + P + 1:, :] = a[:, g + 1:g + 1 + g, :]
        else:
            a[:, :g, :] = a[:, P:P + g, :]; a[:, g + P:, :] = a[:, g:g + g, :]
        if kd == "Bz":
            a[:, :, g + Z] = a[:, :, g]; a[:, :, :g] = a[:, :, Z:Z + g]; a[:, :, g + Z + 1:] = a[:, :, g + 1:g + 1 + g]
        else:
            a[:, :, :g] = a[:, :, Z:Z + g]; a[:, :, g + Z:] = a[:, :, g:g + g]


def fill_axis_ghosts(G, cells_scalar=(), cells_vector=(), Br=None, Bphi=None, Bz=None):
    """Axis grid (r_faces[g] == 0): inner radial ghosts by reflection through r = 0.  Ghost cell g-1-m at phi holds the
    value of interior cell g+m at phi + pi; r and phi vector components change sign.  Ghost r-face g-m holds minus the
    r-face g+m at phi + pi.  Requires nphi even.  Call AFTER the periodic phi fill (it reads interior phi only and then
    re-wraps).  cells_vector: list of (r_comp, phi_comp, z_comp) cell arrays.  Test helper for the Driver's BoundaryManager."""
    assert G.axis and G.nphi % 2 == 0
    g, P, h = G.g, G.nphi, G.nphi // 2
    xp = G.xp
    def opposite(a, nphi_extra=0):
        inner = a[:, g:g + P]
        return xp.concatenate([inner[:, h:], inner[:, :h]], axis=1)
    def set_cells(a, sign):
        op = opposite(a)
        for m in range(g):
            a[g - 1 - m, g:g + P] = sign * op[g + m]
    for a in cells_scalar: set_cells(a, 1)
    for (ar, ap, az) in cells_vector: set_cells(ar, -1); set_cells(ap, -1); set_cells(az, 1)
    if Bz is not None: set_cells(Bz, 1)
    if Bphi is not None:
        op = opposite(Bphi)
        for m in range(g): Bphi[g - 1 - m, g:g + P] = -op[g + m]
    if Br is not None:
        op = opposite(Br)
        for m in range(1, g + 1): Br[g - m, g:g + P] = -op[g + m]


if __name__ == "__main__":
    # smoke test: uniform v and B -> every edge EMF = -v x B exactly, and B unchanged by the CT update
    for be in (["cupy"] if has_gpu() else []) + ["cpu"]:
        for dt in (np.float32, np.float64):
            xp = __import__("cupy") if be == "cupy" else np
            G = Grid(9, 12, 7, 0.5, 1.5, dtype=dt, xp=xp)
            vr = xp.zeros(G.shape("cell"), dt); vp = xp.zeros(G.shape("cell"), dt); vz = xp.full(G.shape("cell"), 0.3, dt)
            rho = xp.ones(G.shape("cell"), dt); p = xp.ones(G.shape("cell"), dt)
            Br = G.zeros("Br"); Bp = G.zeros("Bphi"); Bz = xp.full(G.shape("Bz"), 0.7, dt)
            Bp[...] = 0.2; vp[...] = 0.1
            Er, Ep, Ez = compute_emf(G, Br, Bp, Bz, vr, vp, vz, rho, p, backend=be)
            g = G.g; ex = dict(Er=-(0.1 * 0.7 - 0.3 * 0.2), Ephi=-(0.3 * 0.0 - 0.0 * 0.7), Ez=-(0.0 * 0.2 - 0.1 * 0.0))
            got = dict(Er=float(abs(Er[g:g + G.nr, g:g + G.nphi + 1, g:g + G.nz + 1] - ex["Er"]).max()),
                       Ephi=float(abs(Ep[g:g + G.nr + 1, g:g + G.nphi, g:g + G.nz + 1] - ex["Ephi"]).max()),
                       Ez=float(abs(Ez[g:g + G.nr + 1, g:g + G.nphi + 1, g:g + G.nz] - ex["Ez"]).max()))
            print(f"{be:5s} {np.dtype(dt).name}: uniform state, max |E - (-v x B)| = {max(got.values()):.1e}  {got}")
    print("source sha256", SOURCE_SHA256)
