# -*- coding: utf-8 -*-
"""Pre-freeze additions to the dev study: D2b (smooth, genuinely evolving 3-D field: div B under CT) and
D7 (whistler: exact nonlinear helical Hall-MHD wave, J from UCT_CURL every stage)."""
import sys, os, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import uct_emf_v02 as E
import dev_emf as D


def edge_coords(G, kind):
    if kind == "Er":   return G.r_centers[:, None, None], G.phi_f[None, :, None], G.z_f[None, None, :]
    if kind == "Ephi": return G.r_faces[:, None, None], G.phi_c[None, :, None], G.z_f[None, None, :]
    if kind == "Ez":   return G.r_faces[:, None, None], G.phi_f[None, :, None], G.z_c[None, None, :]


def curl_of_edges(G, Ar, Ap, Az, dt_):
    """exact discrete curl (integral form) of edge point values -> divergence-free face fluxes"""
    B = [G.zeros(k) for k in ("Br", "Bphi", "Bz")]
    E.ct_update(G, *B, *(np.ascontiguousarray(a, dt_) for a in (Ar, Ap, Az)), -1.0)
    return B


def t_divergence_smooth(dt_=np.float64, T=2.0):
    """D2b: smooth resolved 3-D field (all three components, from a smooth edge potential) advected and sheared by a smooth
    3-D flow (|v| ~ 0.5, compressive) for T = 2 at CFL 0.4.  Measures how much B actually changes and the worst div B."""
    G = E.Grid(16, 24, 12, 0.5, 1.5, zlen=1.0, dtype=dt_)
    tz = 2 * np.pi
    r, p, z = edge_coords(G, "Er"); Ar = 0.05 * np.sin(2 * p) * np.cos(tz * z) * np.ones_like(r)
    r, p, z = edge_coords(G, "Ephi"); Ap = 0.05 * (r - 1.0) * np.cos(p) * np.sin(tz * z) + 0.5 * r * 0.5   # + uniform Bz = 0.5
    r, p, z = edge_coords(G, "Ez"); Az = 0.05 * np.exp(-((r - 1.0) / 0.25) ** 2) * (1 + 0.5 * np.sin(p)) * np.ones_like(z)
    B = curl_of_edges(G, Ar, Ap, Az, dt_)
    sh = G.shape("cell"); r = G.r_centers[:, None, None]; p = G.phi_c[None, :, None]; z = G.z_c[None, None, :]
    vr = (0.3 * np.sin(np.pi * (r - 0.5)) * np.cos(p) * np.cos(tz * z)) * np.ones(sh)
    vp = (0.5 * r * (1.5 - r) + 0.2 * np.sin(tz * z)) * np.ones(sh)
    vz = (0.3 * np.sin(2 * p) * np.sin(np.pi * (r - 0.5))) * np.ones(sh)
    rho = (1 + 0.3 * np.cos(p) * np.cos(tz * z)) * np.ones(sh); pr = np.ones(sh)
    v = [np.ascontiguousarray(a, dt_) for a in (vr, vp, vz)]; rho = rho.astype(dt_); pr = pr.astype(dt_)
    B0 = [a.copy() for a in B]
    cf = 0.8 + np.sqrt(5 / 3 / 0.7 + 1.0); dx = min(G.dr, 0.5 * G.dphi, G.dz)
    nsteps = int(np.ceil(T / (0.4 * dx / cf))); dt = T / nsteps
    def fill(Br, Bp, Bz, t): E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))   # radial ghosts frozen
    worst = float(np.abs(E.divergence(G, *B)[1]).max()); d0 = worst; hist = []
    Br, Bp, Bz = B
    for n in range(nsteps):
        D.rk2(G, (Br, Bp, Bz), v, rho, pr, dt, 1, fill)
        if n % max(1, nsteps // 10) == 0 or n == nsteps - 1:
            d = float(np.abs(E.divergence(G, Br, Bp, Bz)[1]).max()); worst = max(worst, d); hist.append(d)
    g = G.g; s = lambda a: a[g:-g, g:-g, g:-g]
    change = float(np.sqrt(sum(((s(a) - s(b)).astype(float) ** 2).sum() for a, b in zip(B, B0)) / sum((s(b).astype(float) ** 2).sum() for b in B0)))
    perp0 = float(np.sqrt(sum((s(b).astype(float) ** 2).sum() for b in B0[:2])))
    perp1 = float(np.sqrt(sum((s(b).astype(float) ** 2).sum() for b in B[:2])))
    return dict(grid="16x24x12 annulus", steps=nsteps, dt=dt, initial_div=d0, worst_normalised_div=worst, div_history=hist,
                rel_L2_change_of_B=change, transverse_energy_ratio=(perp1 / perp0) ** 2,
                finite=bool(all(np.isfinite(a).all() for a in B)))


def t_whistler(nz, dt_=np.float64, h=0.1, B0=1.0, eps=0.1, turn=0.25):
    """D7: exact nonlinear circularly polarised whistler.  dB = eps (cos th, sin th, 0), th = k z - w t, uniform B0 z, v = 0,
    eta = 0, rho = 1: curl dB = -k dB, so J x dB = 0 and the Hall term alone rotates dB with w = -h k^2 B0 / rho.
    Faces = discrete curl of A = -dB/k at edges (exact discrete projection); J from UCT_CURL v1.3 each stage; radial ghosts
    of B and J exact.  Error: L1 over Br, Bphi faces against the projected exact solution at T, relative to |dB|."""
    import uct_curl as UC
    nr = max(4, nz // 4); nphi = max(8, nz // 2); nphi += nphi % 2
    G = E.Grid(nr, nphi, nz, 0.5, 1.5, zlen=1.0, dtype=dt_)
    k = 2 * np.pi; w = -h * k * k * B0; g = G.g
    def Aedges(t):
        out = []
        for kind in ("Er", "Ephi", "Ez"):
            r, p, z = edge_coords(G, kind); th = k * z - w * t
            Ax, Ay = -eps * np.cos(th) / k, -eps * np.sin(th) / k
            if kind == "Er":   out.append((Ax * np.cos(p) + Ay * np.sin(p)) * np.ones_like(r))
            if kind == "Ephi": out.append((-Ax * np.sin(p) + Ay * np.cos(p)) * np.ones_like(r) + 0.5 * B0 * r)
            if kind == "Ez":   out.append(np.zeros(np.broadcast(r, p, z).shape))
        return out
    def exactB(t):
        B = curl_of_edges(G, *Aedges(t), dt_)          # interior faces: exact discrete projection
        for kind, a in zip(("Br", "Bphi"), B[:2]):      # radial ghost faces: analytic point values
            r = (G.r_faces if kind == "Br" else G.r_centers)[:, None, None]
            p = (G.phi_c if kind == "Br" else G.phi_f)[None, :, None]; th = k * G.z_c[None, None, :] - w * t
            bx, by = eps * np.cos(th), eps * np.sin(th)
            val = ((bx * np.cos(p) + by * np.sin(p)) if kind == "Br" else (-bx * np.sin(p) + by * np.cos(p))) * np.ones(a.shape)
            for sl in ((slice(0, g), slice(g + nr + 1, None)) if kind == "Br" else (slice(0, g), slice(g + nr, None))): a[sl] = val[sl]
        for sl in (slice(0, g), slice(g + nr, None)): B[2][sl] = B0   # interior Bz stays the discrete curl (div-free)
        return B
    B = exactB(0.0)
    sh = G.shape("cell"); z0 = np.zeros(sh, dt_); rho = np.ones(sh, dt_); pr = np.ones(sh, dt_)
    rf = np.ascontiguousarray(G.r_faces, dt_); rc = np.ascontiguousarray(G.r_centers, dt_)
    g = G.g; rg = [slice(0, g), slice(g + nr, None)]; rgf = [slice(0, g), slice(g + nr + 1, None)]   # boundary faces g, g+nr evolve
    def exactJ(t):
        r = G.r_centers[:, None, None]; p = G.phi_c[None, :, None]; z = G.z_c[None, None, :]; th = k * z - w * t
        jx, jy = -k * eps * np.cos(th), -k * eps * np.sin(th)
        return (jx * np.cos(p) + jy * np.sin(p)) * np.ones(sh), (-jx * np.sin(p) + jy * np.cos(p)) * np.ones(sh)
    def fill(Br, Bp, Bz, t):
        ex = exactB(t)
        for s in rgf: Br[s] = ex[0][s]
        for s in rg: Bp[s] = ex[1][s]; Bz[s] = ex[2][s]
        E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
    def currents(B, t):
        J, _ = UC.run_curl(*B, rf, rc, G.dr, G.dphi, G.dz, nr, nphi, nz, g)
        Jr, Jp, Jz = [np.ascontiguousarray(a, dt_) for a in J]; jr, jp = exactJ(t)
        for s in rg: Jr[s] = jr[s]; Jp[s] = jp[s]; Jz[s] = 0
        E.fill_periodic(G, Jr, Jp, Jz, kinds=("cell",) * 3)
        return Jr, Jp, Jz
    T = turn * 2 * np.pi / abs(w)
    cf = np.sqrt(5 / 3 + B0 ** 2 + eps ** 2); dx = min(G.dr, 0.5 * G.dphi, G.dz)
    dt = min(0.4 * dx / cf, 0.25 * G.dz ** 2 / (h * B0 * np.pi)); nsteps = int(np.ceil(T / dt)); dt = T / nsteps
    hall_peak = 0.0
    for n in range(nsteps):
        t = n * dt; fill(*B, t); J = currents(B, t)
        Er, Ep, Ez = E.compute_emf(G, *B, z0, z0, z0, rho, pr, J=J, hall=h)
        hall_peak = max(hall_peak, float(np.abs(Er[g:g + nr, g:g + nphi + 1, g:g + nz + 1]).max()))
        B1 = [a.copy() for a in B]; E.ct_update(G, *B1, Er, Ep, Ez, dt); fill(*B1, t + dt); J1 = currents(B1, t + dt)
        Er, Ep, Ez = E.compute_emf(G, *B1, z0, z0, z0, rho, pr, J=J1, hall=h)
        B2 = [a.copy() for a in B1]; E.ct_update(G, *B2, Er, Ep, Ez, dt)
        for a, a2 in zip(B, B2): a[...] = 0.5 * (a + a2)
    fill(*B, T); Bex = exactB(T); Bst = exactB(0.0)
    I = slice(g + 1, g + nr); Ic = slice(g, g + nr); P = slice(g, g + nphi); Pf = slice(g, g + nphi + 1); K = slice(g, g + nz)
    num = float(np.abs(B[0][I, P, K] - Bex[0][I, P, K]).sum() + np.abs(B[1][Ic, Pf, K] - Bex[1][Ic, Pf, K]).sum())
    den = float(np.abs(Bex[0][I, P, K]).sum() + np.abs(Bex[1][Ic, Pf, K]).sum())
    stat = float(np.abs(Bst[0][I, P, K] - Bex[0][I, P, K]).sum() + np.abs(Bst[1][Ic, Pf, K] - Bex[1][Ic, Pf, K]).sum()) / den
    # phase: project dBx + i dBy on exp(i k z) at the mean radius
    return dict(nz=nz, grid=f"{nr}x{nphi}x{nz}", steps=nsteps, T=T, omega_exact=w, rel_l1=num / den, rel_l1_if_static=stat,
                peak_hall_Er=hall_peak, div=float(np.abs(E.divergence(G, *B)[1]).max()), finite=bool(all(np.isfinite(a).all() for a in B)))


if __name__ == "__main__":
    import time
    for f in (np.float64, np.float32):
        t = time.time(); print("D2b", np.dtype(f).name, t_divergence_smooth(f), round(time.time() - t, 1), flush=True)
    for nz in (16, 32):
        t = time.time(); print("D7", t_whistler(nz), round(time.time() - t, 1), flush=True)
