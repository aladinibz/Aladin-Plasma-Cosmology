# -*- coding: utf-8 -*-
"""
ALADIN UCT-EMF v02.1 -- certification campaign EMF-02 (re-runs every EMF-01 test on v02.1 and adds A01-A03, R00, G5, G6).

Frozen kernel: uct_emf_v02.py (SOURCE_SHA256 checked below).  Thresholds are PREDECLARED in THRESHOLDS and are not
changed after a run.  Every test records its conditions, measured values, thresholds, pass/fail and class:
  VERIFIED     all thresholds met
  LIMITATION   test quantifies a known, documented limit of the method; its bound is met
  INCONCLUSIVE test could not be evaluated on this leg (e.g. no GPU)
  BLOCKER      a threshold failed or the test raised
Usage:
  python campaign_emf02.py cpu          # CPU leg (C++/OpenMP backend)
  python campaign_emf02.py gpu          # GPU leg: all C-tests through the CUDA backend + G-tests
  add --deep for the extra refinement levels (D3 nr=128, D4 nr=96, whistler nz=64)
Writes emf02_<leg>_results.json and emf01_<leg>.log next to this file.
"""
import sys, os, time, json, copy, hashlib, platform, datetime, traceback, subprocess
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import uct_emf_v02 as E
import numpy_oracle as N

FROZEN_SHA = "341ebaf6c26706fe8679579a58af8382cbfc96c94386f2c509dd31c3ba958aa0"
FROZEN_BUILD = "6ae7dcc19697351ffa01bc7d7cf8699799dbf12aa1bdb8f97229f33220b06ab4"
V02_CERTIFIED = "707c4d9ab723109bfca9b543a0956f69f7534367f905eda2cae8adad8b1b296d"

THRESHOLDS = dict(
    C01_donor_abs=1e-12,
    C02_oracle_emf_rel_fp64=1e-13,
    C03_oracle_ct_rel_fp64=1e-14,
    C04_oracle_force_abs=1e-14,
    C05_fp32_vs_oracle_rel=2e-5,
    C06_div_random_fp64=1e-12, C06_div_random_fp32=5e-5,
    C07_div_smooth_fp64=1e-12, C07_div_smooth_fp32=1e-5, C07_min_rel_change=0.5,
    C08_rotation_final_order=1.6, C08_div=1e-12,
    C09_translation_final_order=1.8, C09_div=1e-12,
    C10_resistive_mc_final_order=1.5, C10_resistive_minmod_final_order=1.9, C10_decay_rel_err=5e-3, C10_div=1e-12,
    C11_whistler_final_order=1.7, C11_whistler_err_nz32=0.1, C11_static_err_min=1.0, C11_hall_peak_rel=0.1, C11_div=1e-12,
    C12_zpinch_final_order=1.5, C12_zpinch_mc_drift_nr64=1e-3,
    C13_force_abs=1e-12, C13_hall_abs=1e-14,
    C14_axis_single_valued_abs=0.0,
    C15_shift_covariance_rel=1e-14,
    C16_extreme_oracle_rel=1e-12,
    C17_null_abs=0.0,
    G1_gpu_cpu_rel_fp64=1e-12, G1_gpu_cpu_rel_fp32=1e-5,
    G2_gpu_oracle_rel_fp64=1e-13,
    G3_determinism_abs=0.0,
    A01_linear_exact=1e-14, A01_quadratic_order=1.9, A02_axis_current=1e-14, A02_div=1e-12, A03_energy_improvement=5.0,
    R00_regression_v02=0.0, R00_fp32_axis_edge_ulps=4.0, G5_gpu_cpu_bitwise=0.0, G6_ieee_selftest=1.0,
)

LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
DEEP = "--deep" in sys.argv
BACKEND = "cupy" if LEG == "gpu" else "cpu"

# ------------------------------------------------------------------ backend shim (GPU leg: same NumPy test drivers, kernel on GPU)
_emf, _ct, _force = E.compute_emf, E.ct_update, E.lorentz_force
if BACKEND == "cupy":
    import cupy as cp
    def _gG(G):
        H = copy.copy(G); H.xp = cp; return H
    def _to(a): return None if a is None else cp.asarray(np.ascontiguousarray(a))
    def emf_gpu(G, Br, Bphi, Bz, vr, vphi, vz, rho, p, J=None, **kw):
        kw.pop("backend", None)
        out = _emf(_gG(G), *[_to(a) for a in (Br, Bphi, Bz, vr, vphi, vz, rho, p)], J=None if J is None else [_to(a) for a in J], backend="cupy", **kw)
        return tuple(x.get() for x in out)
    def ct_gpu(G, Br, Bphi, Bz, Er, Ephi, Ez, dt_step, **kw):
        B = [_to(a) for a in (Br, Bphi, Bz)]
        _ct(_gG(G), *B, *[_to(a) for a in (Er, Ephi, Ez)], dt_step, backend="cupy")
        for a, b in zip((Br, Bphi, Bz), B): a[...] = b.get()
    def force_gpu(G, Br, Bphi, Bz, J, **kw):
        return tuple(x.get() for x in _force(_gG(G), *[_to(a) for a in (Br, Bphi, Bz)], [_to(a) for a in J], backend="cupy"))
    E.compute_emf, E.ct_update, E.lorentz_force = emf_gpu, ct_gpu, force_gpu
import dev_emf as D      # noqa: E402  (test drivers, use E.* through the module -> shim applies)
import dev_emf2 as D2    # noqa: E402

LOG = open(os.path.join(HERE, f"emf02_{LEG}.log"), "w")
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.write(s + "\n"); LOG.flush()

def orders(errs):
    return [float(np.log2(errs[i] / errs[i + 1])) for i in range(len(errs) - 1)]

def rel(a, b):
    return float(np.abs(a - b).max() / max(float(np.abs(b).max()), 1e-300))

def interior(G, x):
    g = G.g; return x[g:-g, g:-g, g:-g]

def rand_inputs(G, rng, dt_=np.float64, scale=1.0, pscale=1.0, rscale=1.0):
    a = {k: (scale * rng.normal(size=G.shape(s))).astype(dt_) for k, s in (("Br", "Br"), ("Bphi", "Bphi"), ("Bz", "Bz"))}
    for k in ("vr", "vp", "vz", "Jr", "Jp", "Jz"): a[k] = rng.normal(size=G.shape("cell")).astype(dt_)
    a["rho"] = (rscale * rng.uniform(0.5, 2, G.shape("cell"))).astype(dt_); a["p"] = (pscale * rng.uniform(0.5, 2, G.shape("cell"))).astype(dt_)
    return a

def call_emf(G, a, **kw):
    return E.compute_emf(G, a["Br"], a["Bphi"], a["Bz"], a["vr"], a["vp"], a["vz"], a["rho"], a["p"], J=(a["Jr"], a["Jp"], a["Jz"]), **kw)

def call_oracle(G, a, **kw):
    f = lambda x: np.asarray(x, np.float64)
    return N.oracle(G, *[f(a[k]) for k in ("Br", "Bphi", "Bz", "vr", "vp", "vz", "rho", "p")], J=tuple(f(a[k]) for k in ("Jr", "Jp", "Jz")), **kw)

def emf_rel(G, k, o):
    return max(rel(interior(G, x), interior(G, y)) for x, y in zip(k, o))

SIZES = [(7, 10, 5), (13, 18, 11), (16, 8, 3), (3, 6, 1), (1, 4, 2), (31, 6, 9), (17, 34, 7)]

# ------------------------------------------------------------------ tests
def C01():
    r = D.t_donor(); worst = max(x["err"] for x in r)
    return dict(conditions="supersonic quadrant states around one z-edge, minmod, 4 flow-sign combinations", cases=r, worst=worst), \
        [("worst |Ez - upstream corner|", worst, "<=", THRESHOLDS["C01_donor_abs"])]

def C02():
    rng = np.random.default_rng(101); rows = []
    for rmin in (0.4, 0.0):
        for (nr, nphi, nz) in SIZES:
            if rmin == 0 and nphi % 2: continue
            for lim in ("mc", "minmod"):
                G = E.Grid(nr, nphi, nz, rmin, 1.3); a = rand_inputs(G, rng)
                kw = dict(eta=0.03, hall=0.2, limiter=lim)
                rows.append(dict(geom="axis" if rmin == 0 else "annulus", size=[nr, nphi, nz], limiter=lim, rel=emf_rel(G, call_emf(G, a, **kw), call_oracle(G, a, **kw))))
    worst = max(x["rel"] for x in rows)
    return dict(conditions="random N(0,1) B, v, J; rho, p ~ U(0.5,2); eta=0.03, hall=0.2; FP64; interior edges", rows=rows, worst=worst), \
        [("worst rel |EMF - oracle|", worst, "<=", THRESHOLDS["C02_oracle_emf_rel_fp64"])]

def C03():
    rng = np.random.default_rng(102); rows = []
    for rmin in (0.4, 0.0):
        for (nr, nphi, nz) in SIZES:
            if rmin == 0 and nphi % 2: continue
            G = E.Grid(nr, nphi, nz, rmin, 1.3)
            B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]; Em = [rng.normal(size=G.shape(k)) for k in ("Er", "Ephi", "Ez")]
            Bk = [b.copy() for b in B]; E.ct_update(G, *Bk, *Em, 0.013); Bo = N.ct_oracle(G, *B, *Em, 0.013)
            rows.append(dict(geom="axis" if rmin == 0 else "annulus", size=[nr, nphi, nz], rel=max(rel(x, y) for x, y in zip(Bk, Bo))))
    worst = max(x["rel"] for x in rows)
    return dict(conditions="random faces and edge EMFs, dt=0.013, FP64, all faces incl. ghosts compared", rows=rows, worst=worst), \
        [("worst rel |CT - oracle|", worst, "<=", THRESHOLDS["C03_oracle_ct_rel_fp64"])]

def C04():
    rng = np.random.default_rng(103); worst = 0.0
    for rmin in (0.4, 0.0):
        for (nr, nphi, nz) in SIZES:
            G = E.Grid(nr, nphi, nz, rmin, 1.3); a = rand_inputs(G, rng); J = (a["Jr"], a["Jp"], a["Jz"])
            f = E.lorentz_force(G, a["Br"], a["Bphi"], a["Bz"], J); fo = N.force_oracle(G, a["Br"], a["Bphi"], a["Bz"], J)
            worst = max(worst, max(float(np.abs(interior(G, x) - interior(G, y)).max()) for x, y in zip(f, fo)))
    return dict(conditions="random B, J; FP64; interior cells", worst=worst), [("worst |JxB - oracle|", worst, "<=", THRESHOLDS["C04_oracle_force_abs"])]

def C05():
    rng = np.random.default_rng(104); rows = []
    for rmin in (0.4, 0.0):
        for (nr, nphi, nz) in SIZES[:3]:
            G = E.Grid(nr, nphi, nz, rmin, 1.3, dtype=np.float32); a = rand_inputs(G, rng, np.float32)
            kw = dict(eta=0.03, hall=0.2); rows.append(dict(geom="axis" if rmin == 0 else "annulus", size=[nr, nphi, nz], rel=emf_rel(G, call_emf(G, a, **kw), call_oracle(G, a, **kw))))
    worst = max(x["rel"] for x in rows)
    return dict(conditions="FP32 kernel vs FP64 oracle on the same (FP32-rounded) inputs", rows=rows, worst=worst), [("worst rel", worst, "<=", THRESHOLDS["C05_fp32_vs_oracle_rel"])]

def C06():
    r64 = D.t_divergence(np.float64, 2000); r32 = D.t_divergence(np.float32, 2000)
    return dict(conditions="grid-scale random div-free B (curl of random edge potential), random v, 2000 steps dt=1e-3, annulus 12x16x10. "
                           "Robustness only: the field is not resolved and decays strongly (see C07 for the evolving-field test)", fp64=r64, fp32=r32), \
        [("FP64 worst normalised div", r64["worst_normalised_div"], "<=", THRESHOLDS["C06_div_random_fp64"]),
         ("FP32 worst normalised div", r32["worst_normalised_div"], "<=", THRESHOLDS["C06_div_random_fp32"]),
         ("finite", float(r64["finite"] and r32["finite"]), "==", 1.0)]

def C07():
    r64 = D2.t_divergence_smooth(np.float64); r32 = D2.t_divergence_smooth(np.float32)
    return dict(conditions="smooth resolved 3-D B (all components) under smooth compressive 3-D flow, T=2 at CFL 0.4, RK2", fp64=r64, fp32=r32), \
        [("FP64 worst normalised div", r64["worst_normalised_div"], "<=", THRESHOLDS["C07_div_smooth_fp64"]),
         ("FP32 worst normalised div", r32["worst_normalised_div"], "<=", THRESHOLDS["C07_div_smooth_fp32"]),
         ("relative L2 change of B", r64["rel_L2_change_of_B"], ">=", THRESHOLDS["C07_min_rel_change"])]

def C08():
    lv = (16, 32, 64, 128) if DEEP else (16, 32, 64); rows = [D.t_rotation(n) for n in lv]; o = orders([x["l1"] for x in rows])
    return dict(conditions="Gaussian field loop w=0.12, rigid rotation Om=1, quarter turn, annulus [0.5,1.5], MC, RK2 CFL 0.4", rows=rows, orders=o), \
        [("final observed order", o[-1], ">=", THRESHOLDS["C08_rotation_final_order"]), ("worst div", max(x["div"] for x in rows), "<=", THRESHOLDS["C08_div"])]

def C09():
    lv = (12, 24, 48, 96) if DEEP else (12, 24, 48); rows = [D.t_axis_translation(n) for n in lv]; o = orders([x["l1"] for x in rows])
    return dict(conditions="Gaussian loop w=0.15 translated across the axis, V=(0.6,0.25), T=1, disk r<1, nphi=4 nr, MC, RK2 CFL 0.4", rows=rows, orders=o), \
        [("final observed order", o[-1], ">=", THRESHOLDS["C09_translation_final_order"]), ("worst div", max(x["div"] for x in rows), "<=", THRESHOLDS["C09_div"])]

def C10():
    res = {}
    for lim in ("mc", "minmod"):
        rows = [D.t_resistive(n, nphi=8, limiter=lim) for n in (16, 32, 64)]; res[lim] = dict(rows=rows, orders=orders([x["rel_l1"] for x in rows]))
    d = res["mc"]["rows"][1]; derr = abs(d["decay_measured"] - d["decay_exact"]) / d["decay_exact"]
    return dict(conditions="Bphi=J1(kr), k=j11, eta=0.05, T=1, disk, nphi=8, J from UCT_CURL v1.3 at every RK2 stage", results=res, decay_rel_err_nr32=derr), \
        [("MC final order", res["mc"]["orders"][-1], ">=", THRESHOLDS["C10_resistive_mc_final_order"]),
         ("minmod final order", res["minmod"]["orders"][-1], ">=", THRESHOLDS["C10_resistive_minmod_final_order"]),
         ("decay-rate rel err (MC, nr=32)", derr, "<=", THRESHOLDS["C10_decay_rel_err"]),
         ("worst div", max(x["div"] for r in res.values() for x in r["rows"]), "<=", THRESHOLDS["C10_div"])]

def C11():
    lv = (16, 32, 64) if DEEP else (16, 32); rows = [D2.t_whistler(n) for n in lv]; o = orders([x["rel_l1"] for x in rows])
    h, k, eps, B0 = 0.1, 2 * np.pi, 0.1, 1.0; peak = h * k * eps * B0
    e32 = [x for x in rows if x["nz"] == 32][0]
    return dict(conditions="exact nonlinear circularly polarised whistler, hall=0.1, B0=1, eps=0.1, k=2pi, rho=1, v=0, eta=0, quarter period; "
                           "J from UCT_CURL v1.3 each stage; annulus [0.5,1.5], grid nr=nz/4, nphi=nz/2", rows=rows, orders=o, analytic_hall_Er_amplitude=peak), \
        [("final observed order", o[-1], ">=", THRESHOLDS["C11_whistler_final_order"]),
         ("rel L1 error nz=32", e32["rel_l1"], "<=", THRESHOLDS["C11_whistler_err_nz32"]),
         ("error a static field would have", e32["rel_l1_if_static"], ">=", THRESHOLDS["C11_static_err_min"]),
         ("peak Hall Er vs h k eps B0 (rel)", abs(e32["peak_hall_Er"] - peak) / peak, "<=", THRESHOLDS["C11_hall_peak_rel"]),
         ("worst div", max(x["div"] for x in rows), "<=", THRESHOLDS["C11_div"])]

def zpinch(nr, lim, T=10.0):
    nphi = 8; G = E.Grid(nr, nphi, 1, 0.0, 1.0); rc = G.r_centers
    Bp = (rc / (1 + rc ** 2))[:, None, None] * np.ones(G.shape("Bphi")); Br = G.zeros("Br"); Bz = G.zeros("Bz")
    sh = G.shape("cell"); z = np.zeros(sh); rho = np.ones(sh); p = (0.1 + 0.5 / (1 + rc ** 2) ** 2)[:, None, None] * np.ones(sh)
    B0 = Bp.copy(); go = slice(G.g + nr, None)
    def fill(Br, Bp, Bz):
        Bp[go] = B0[go]; E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz")); E.fill_axis_ghosts(G, Br=Br, Bphi=Bp, Bz=Bz); E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
    dt = 0.4 * 0.5 * G.dr * G.dphi / 1.5; n = int(np.ceil(T / dt)); dt = T / n; B = [Br, Bp, Bz]
    for s in range(n):
        fill(*B); Er, Ep, Ez = E.compute_emf(G, *B, z, z, z, rho, p, limiter=lim); E.ct_update(G, *B, Er, Ep, Ez, dt)
    g = G.g; I = slice(g, g + nr)
    return dict(nr=nr, steps=n, drift=float(np.abs(B[1][I, g:g + nphi, g] - B0[I, g:g + nphi, g]).sum() / np.abs(B0[I, g:g + nphi, g]).sum()),
                div=float(np.abs(E.divergence(G, *B)[1]).max()))

def C12():
    res = {lim: [zpinch(n, lim) for n in (16, 32, 64)] for lim in ("mc", "minmod")}
    o = {lim: orders([x["drift"] for x in r]) for lim, r in res.items()}
    return dict(conditions="static force-free-in-induction Z-pinch Bphi=r/(1+r^2), p balancing, v=0, eta=0, T=10, disk nphi=8, forward Euler CFL 0.4. "
                           "Quantifies the UCT-HLL numerical diffusion of a static equilibrium (no physical E): a documented method limit",
                limitation="UCT-HLL upwind dissipation ~ c_f * (reconstruction jump) acts on static curved fields; drift converges at 2nd order",
                results=res, orders=o, cls_if_pass="LIMITATION"), \
        [("MC final order", o["mc"][-1], ">=", THRESHOLDS["C12_zpinch_final_order"]), ("minmod final order", o["minmod"][-1], ">=", THRESHOLDS["C12_zpinch_final_order"]),
         ("MC drift nr=64, T=10", res["mc"][-1]["drift"], "<=", THRESHOLDS["C12_zpinch_mc_drift_nr64"])]

def C13():
    r = D.t_lorentz_hall()
    return dict(conditions="Z-pinch Bphi=0.5r with J from UCT_CURL (f_r=-0.5r exact); uniform B, J, rho=2, hall=0.25 (E_hall exact). "
                           "Arithmetic check of the Hall term; C11 is the dynamic, consistent-J Hall test", **r), \
        [("|f_r - exact|", r["force_fr_err"], "<=", THRESHOLDS["C13_force_abs"]), ("transverse force", r["force_transverse"], "<=", THRESHOLDS["C13_force_abs"]),
         ("|E_hall - exact|", r["hall_err"], "<=", THRESHOLDS["C13_hall_abs"])]

def C14():
    rng = np.random.default_rng(105); worst = 0.0
    for (nr, nphi, nz) in ((7, 10, 5), (13, 18, 11), (16, 8, 3), (5, 4, 2)):
        G = E.Grid(nr, nphi, nz, 0.0, 1.0); a = rand_inputs(G, rng); _, _, Ez = call_emf(G, a, eta=0.03, hall=0.2); g = G.g
        ax = Ez[g, g:g + nphi + 1, g:g + nz]; worst = max(worst, float(np.abs(ax - ax[0:1]).max()))
    return dict(conditions="axis grids, random inputs: Ez on the axis edge must be one value for every phi edge", worst_spread=worst), \
        [("max spread of axis Ez over phi", worst, "<=", THRESHOLDS["C14_axis_single_valued_abs"])]

def C15():
    rng = np.random.default_rng(106); rows = []
    for rmin, (nr, nphi, nz), m, kz in ((0.4, (7, 12, 6), 5, 2), (0.0, (8, 16, 6), 3, 1), (0.0, (6, 10, 4), 4, 3)):
        G = E.Grid(nr, nphi, nz, rmin, 1.3); a = rand_inputs(G, rng); g = G.g
        for k in a: E.fill_periodic(G, a[k], kinds=({"Br": "Br", "Bphi": "Bphi", "Bz": "Bz"}.get(k, "cell"),))
        def shift(x, kind):
            y = x.copy(); P = nphi + (1 if kind in ("Bphi", "Er", "Ez") else 0); Z = nz + (1 if kind in ("Bz", "Er", "Ephi") else 0)
            core = x[:, g:g + nphi, g:g + nz]
            y[:, g:g + nphi, g:g + nz] = np.roll(np.roll(core, m, 1), kz, 2)
            E.fill_periodic(G, y, kinds=(kind if kind in ("Br", "Bphi", "Bz") else "cell",)); return y
        b = {k: shift(v, {"Br": "Br", "Bphi": "Bphi", "Bz": "Bz"}.get(k, "cell")) for k, v in a.items()}
        k0 = call_emf(G, a, eta=0.03, hall=0.2); k1 = call_emf(G, b, eta=0.03, hall=0.2)
        err = 0.0
        for x, y in zip(k0, k1):
            xi = np.roll(np.roll(x[g:-g, g:g + nphi, g:g + nz], m, 1), kz, 2); yi = y[g:-g, g:g + nphi, g:g + nz]
            err = max(err, rel(yi, xi))
        rows.append(dict(geom="axis" if rmin == 0 else "annulus", size=[nr, nphi, nz], shift_phi=m, shift_z=kz, rel=err))
    worst = max(x["rel"] for x in rows)
    return dict(conditions="periodic inputs shifted by m cells in phi and kz cells in z: outputs must shift identically (covariance)", rows=rows, worst=worst), \
        [("worst rel", worst, "<=", THRESHOLDS["C15_shift_covariance_rel"])]

def C16():
    rng = np.random.default_rng(107); rows = []
    cases = dict(low_beta=dict(pscale=1e-8), high_beta=dict(pscale=1e4), strong_field=dict(scale=1e3), weak_field=dict(scale=1e-6),
                 density_contrast=dict(rscale=1e-6), hypersonic=dict(vscale=100.0), large_eta_hall=dict(eta=10.0, hall=10.0))
    for name, c in cases.items():
        for rmin in (0.4, 0.0):
            G = E.Grid(9, 12, 6, rmin, 1.3)
            a = rand_inputs(G, rng, scale=c.get("scale", 1.0), pscale=c.get("pscale", 1.0), rscale=c.get("rscale", 1.0))
            if "vscale" in c:
                for k in ("vr", "vp", "vz"): a[k] = a[k] * c["vscale"]
            if name == "density_contrast": a["rho"][: G.nr // 2 + G.g] *= 1e6
            kw = dict(eta=c.get("eta", 0.03), hall=c.get("hall", 0.2)); k = call_emf(G, a, **kw); o = call_oracle(G, a, **kw)
            fin = all(np.isfinite(x).all() for x in k)
            Bk = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; E.ct_update(G, *Bk, *k, 1e-4)
            rows.append(dict(case=name, geom="axis" if rmin == 0 else "annulus", rel=emf_rel(G, k, o), finite=bool(fin and all(np.isfinite(x).all() for x in Bk))))
    worst = max(x["rel"] for x in rows)
    return dict(conditions="random inputs at extreme parameters (p x1e-8 / x1e4, |B| x1e3 / x1e-6, rho contrast 1e6, |v| x100, eta=hall=10), FP64", rows=rows, worst=worst), \
        [("worst rel vs oracle", worst, "<=", THRESHOLDS["C16_extreme_oracle_rel"]), ("all finite", float(all(x["finite"] for x in rows)), "==", 1.0)]

def C17():
    rng = np.random.default_rng(108); worst = 0.0
    for rmin in (0.4, 0.0):
        G = E.Grid(9, 12, 6, rmin, 1.3); a = rand_inputs(G, rng)
        b = dict(a); b.update(Br=0 * a["Br"], Bphi=0 * a["Bphi"], Bz=0 * a["Bz"], Jr=0 * a["Jr"], Jp=0 * a["Jp"], Jz=0 * a["Jz"])
        worst = max(worst, max(float(np.abs(x).max()) for x in call_emf(G, b, eta=0.03, hall=0.2)))          # B = 0, J = 0
        c = dict(a); c.update(vr=0 * a["vr"], vp=0 * a["vp"], vz=0 * a["vz"], Br=0 * a["Br"], Bphi=0 * a["Bphi"], Bz=0 * a["Bz"] + 0.7,
                              Jr=0 * a["Jr"], Jp=0 * a["Jp"], Jz=0 * a["Jz"])
        worst = max(worst, max(float(np.abs(interior(G, x)).max()) for x in call_emf(G, c, eta=0.03, hall=0.2)))  # v = 0, uniform Bz
    return dict(conditions="nulls: B=J=0 with random v -> E=0; v=J=0 with uniform Bz -> E=0 (no spurious jumps)", worst=worst), \
        [("max |E|", worst, "<=", THRESHOLDS["C17_null_abs"])]

def G1():
    out = {}
    for dt_ in (np.float64, np.float32):
        rng = np.random.default_rng(3); worst = 0.0
        for rmin in (0.4, 0.0):
            for (nr, nphi, nz) in SIZES:
                if rmin == 0 and nphi % 2: continue
                G = E.Grid(nr, nphi, nz, rmin, 1.4, dtype=dt_); a = rand_inputs(G, rng, dt_)
                kw = dict(eta=0.01, hall=0.1)
                kc = _emf(G, a["Br"], a["Bphi"], a["Bz"], a["vr"], a["vp"], a["vz"], a["rho"], a["p"], J=(a["Jr"], a["Jp"], a["Jz"]), backend="cpu", **kw)
                kg = call_emf(G, a, **kw)
                Bc = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; _ct(G, *Bc, *kc, 1e-3, backend="cpu")
                Bg = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; E.ct_update(G, *Bg, *kc, 1e-3)
                fc = _force(G, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]), backend="cpu"); fg = E.lorentz_force(G, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]))
                worst = max(worst, max(rel(x, y) for x, y in zip(list(kg) + Bg + list(fg), list(kc) + Bc + list(fc))))
        out[np.dtype(dt_).name] = worst
    return dict(conditions="GPU vs CPU backend, same random inputs, all sizes incl. partial 128-thread blocks (EMF, CT, force)", **out), \
        [("FP64 worst rel", out["float64"], "<=", THRESHOLDS["G1_gpu_cpu_rel_fp64"]), ("FP32 worst rel", out["float32"], "<=", THRESHOLDS["G1_gpu_cpu_rel_fp32"])]

def G2():
    r = C02()[0]; return dict(conditions="C02 executed through the GPU backend", worst=r["worst"]), [("worst rel vs oracle", r["worst"], "<=", THRESHOLDS["G2_gpu_oracle_rel_fp64"])]

def G3():
    rng = np.random.default_rng(9); worst = 0.0
    for dt_ in (np.float64, np.float32):
        G = E.Grid(31, 34, 17, 0.0, 1.0, dtype=dt_); a = rand_inputs(G, rng, dt_)
        r = [call_emf(G, a, eta=0.02, hall=0.3) for _ in range(3)]
        worst = max(worst, max(float(np.abs(x - y).max()) for run in r[1:] for x, y in zip(run, r[0])))
    return dict(conditions="three GPU launches on identical inputs (FP64, FP32): bitwise identical", worst=worst), [("max |run_i - run_0|", worst, "<=", THRESHOLDS["G3_determinism_abs"])]


# ------------------------------------------------------------------ EMF-02 (v02.1): axis closure, regression, bitwise GPU
def _cart_field(G, kind, quad):
    rf, rc, pc, pf = G.r_faces, G.r_centers, G.phi_c, G.phi_f
    R_, P_ = {"Br": (rf, pc), "Bphi": (rc, pf), "Bz": (rc, pc)}[kind]
    R_ = R_[:, None, None]; P_ = P_[None, :, None]; X = R_ * np.cos(P_); Y = R_ * np.sin(P_)
    Bx = 0.7 + 0.3 * X - 0.2 * Y + (0.5 * X * Y + 0.4 * X * X if quad else 0); By = -0.4 + 0.1 * X + 0.6 * Y - (0.3 * Y * Y if quad else 0)
    v = {"Br": Bx * np.cos(P_) + By * np.sin(P_), "Bphi": -Bx * np.sin(P_) + By * np.cos(P_), "Bz": 0.2 + 0 * X}[kind]
    return np.ascontiguousarray(v * np.ones(G.shape(kind)))

def A01():
    """axis closure: exact for fields linear in Cartesian coordinates, second order otherwise"""
    lin = 0.0; errs = []
    for n in (16, 32, 64, 128):
        for quad in (False, True):
            G = E.Grid(n, 16, 4, 0.0, 1.0); g = G.g; Br = _cart_field(G, "Br", quad); ex = Br[g].copy(); Br[g] = 123.0
            E.close_axis(G, Br, backend=BACKEND) if BACKEND == "cpu" else None
            if BACKEND == "cupy":
                Bg = cp.asarray(Br); E.close_axis(_gG(G), Bg, backend="cupy"); Br = Bg.get()
            e = float(np.abs(Br[g, g:g + G.nphi, g:g + G.nz] - ex[g:g + G.nphi, g:g + G.nz]).max())
            if quad: errs.append(e)
            else: lin = max(lin, e)
    o = orders(errs)
    return dict(conditions="axis grids nr = 16..128, nphi 16; B = (Bx, By) linear / quadratic in x, y; axis face overwritten with 123 then closed", linear_max=lin, quadratic_errors=errs, orders=o), \
        [("linear field: max |Br_axis - exact|", lin, "<=", THRESHOLDS["A01_linear_exact"]), ("quadratic field: final order", o[-1], ">=", THRESHOLDS["A01_quadratic_order"])]

def _shear_run(nr, use_closure, T=0.2, s=0.5, By0=1.0):
    """B = (s By0 t, By0, 0) uniform, the exact solution of ideal induction under the shear flow v = (s y, 0, 0)
    (dB/dt = (B.grad) v); axis grid nr x nphi = nr x nr x 4 (the azimuthal resolution is refined with nr), CFL-limited
    forward-Euler CT steps, ghosts refilled with the exact field.  use_closure=False restores the axis face after every
    step (the v02 behaviour: the face is never updated)."""
    G = E.Grid(nr, nr, 4, 0.0, 1.0); g = G.g; sh = G.shape("cell")
    h = min(G.dr, G.r_centers[g] * G.dphi, G.dz); nst = int(np.ceil(T / (0.3 * h / 1.7))); dt = T / nst
    rc, pc = G.r_centers[:, None, None], G.phi_c[None, :, None]; Yc = rc * np.sin(pc)
    vx = s * Yc * np.ones(sh); vr = vx * np.cos(pc); vp = -vx * np.sin(pc); vz = np.zeros(sh); rho = np.ones(sh); p = np.ones(sh)
    def exact(t, kind):
        R_, P_ = {"Br": (G.r_faces, G.phi_c), "Bphi": (G.r_centers, G.phi_f), "Bz": (G.r_centers, G.phi_c)}[kind]; P_ = P_[None, :, None]; bx = s * By0 * t
        v = {"Br": bx * np.cos(P_) + By0 * np.sin(P_), "Bphi": -bx * np.sin(P_) + By0 * np.cos(P_), "Bz": 0 * P_}[kind]
        return np.ascontiguousarray(v * np.ones(G.shape(kind)))
    B = [exact(0, k) for k in ("Br", "Bphi", "Bz")]; div0 = E.divergence(G, *B)[0]
    for n in range(nst):
        Bt = [exact(n * dt, k) for k in ("Br", "Bphi", "Bz")]
        for a, b_ in zip(B, Bt):
            m = np.ones(a.shape, bool); m[g:-g, g:-g, g:-g] = False; a[m] = b_[m]
        Er, Ep, Ez = E.compute_emf(G, *B, vr, vp, vz, rho, p)
        keep = B[0][g].copy(); E.ct_update(G, *B, Er, Ep, Ez, dt)
        if not use_closure: B[0][g] = keep
    ex = exact(T, "Br"); I = (slice(g, -g), slice(g, -g))
    e_axis = float(np.abs(B[0][g][I] - ex[g][I]).max()); e_ring = float(np.abs(B[0][g + 1][I] - ex[g + 1][I]).max())
    ring = B[0][g + 1][I]; ph = (np.arange(G.nphi) + 0.5) * G.dphi
    bx = 2 * (ring * np.cos(ph)[:, None]).sum(0) / G.nphi; by = 2 * (ring * np.sin(ph)[:, None]).sum(0) / G.nphi
    consist = float(np.abs(B[0][g][I] - (bx[None, :] * np.cos(ph)[:, None] + by[None, :] * np.sin(ph)[:, None])).max())
    brc = 0.5 * (B[0][g] + B[0][g + 1])[I]; bpc = 0.5 * (B[1][g][:-1] + B[1][g][1:])[I]
    M = 0.5 * (brc ** 2 + bpc ** 2); Mex = 0.5 * ((s * By0 * T) ** 2 + By0 ** 2); e_M = float(np.abs(M - Mex).max() / Mex)
    ddiv = float(np.abs(E.divergence(G, *B)[0] - div0).max())
    return dict(nr=nr, steps=nst, axis_err=e_axis, ring_err=e_ring, closure_consistency=consist, axis_energy_rel_err=e_M, div_change=ddiv)

def A02():
    """the axis face stays current under an evolution that changes the field at the axis, and converges with the solution"""
    rows = [_shear_run(nr, True) for nr in (16, 32, 64)]; o = orders([r["axis_err"] for r in rows])
    return dict(conditions="uniform B = (s By0 t, By0, 0) under the shear v = (s y, 0, 0), s = 0.5, t = 0.2; axis grids nr = nphi = 16, 32, 64; exact ghosts", rows=rows, axis_orders=o), \
        [("axis face = m = 1 closure of the evolved ring (consistency)", max(r["closure_consistency"] for r in rows), "<=", THRESHOLDS["A02_axis_current"]),
         ("final convergence order of the axis-face error", o[-1], ">=", 1.0), ("max change of the cell divergence", max(r["div_change"] for r in rows), "<=", THRESHOLDS["A02_div"])]

def A03():
    """the v02 defect it repairs: with the face never updated (v02) the axis value stays at its initial field and does not converge"""
    new = _shear_run(64, True); old = _shear_run(64, False)
    ratio = old["axis_err"] / max(new["axis_err"], 1e-300)
    return dict(conditions="as A02 at nr = nphi = 64: v02.1 vs the v02 behaviour (axis face restored after every step)", v021=new, v02=old, improvement=ratio,
                v02_energy_over_v021_energy=old["axis_energy_rel_err"] / max(new["axis_energy_rel_err"], 1e-300)), \
        [("axis-face error reduction factor (v02 / v02.1) at nr = 64", ratio, ">=", THRESHOLDS["A03_energy_improvement"])]

def R00():
    """v02.1 vs the certified v02 on the CPU.  FP64: EMFs, CT (every face except the axis face) and force bit-identical.
    FP32: the same, except the axis-edge EMFs (Ez, Ephi at r = 0), which use cos / sin rounded from double on the host instead
    of the device float cos / sin: there the difference is bounded in ulps of the edge-EMF scale."""
    import importlib.util
    path = os.path.join(HERE, "reference", "uct_emf_v02_certified.py")
    spec = importlib.util.spec_from_file_location("v02ref", path); V = importlib.util.module_from_spec(spec); spec.loader.exec_module(V)
    assert V.SOURCE_SHA256 == V02_CERTIFIED
    rng = np.random.default_rng(500); worst = 0.0; worst_axis_ulps = 0.0
    for dt_ in (np.float64, np.float32):
        for rmin in (0.0, 0.4):
            for (nr, nphi, nz) in SIZES:
                if rmin == 0 and nphi % 2: continue
                G = E.Grid(nr, nphi, nz, rmin, 1.3, dtype=dt_); G2 = V.Grid(nr, nphi, nz, rmin, 1.3, dtype=dt_); a = rand_inputs(G, rng, dt_); g = G.g
                kw = dict(eta=0.01, hall=0.1)
                k1 = _emf(G, a["Br"], a["Bphi"], a["Bz"], a["vr"], a["vp"], a["vz"], a["rho"], a["p"], J=(a["Jr"], a["Jp"], a["Jz"]), backend="cpu", **kw)
                k2 = V.compute_emf(G2, a["Br"], a["Bphi"], a["Bz"], a["vr"], a["vp"], a["vz"], a["rho"], a["p"], J=(a["Jr"], a["Jp"], a["Jz"]), **kw)
                for nm, x, y in zip(("Er", "Ephi", "Ez"), k1, k2):
                    d = np.abs(x - y)
                    if dt_ == np.float32 and G.axis and nm in ("Ephi", "Ez"):
                        sc_ = float(np.abs(y[g]).max()) or 1.0
                        worst_axis_ulps = max(worst_axis_ulps, float(d[g].max()) / (np.finfo(np.float32).eps * sc_)); d = d.copy(); d[g] = 0
                    worst = max(worst, float(d.max()))
                B1 = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; _ct(G, *B1, *k2, 1e-3, backend="cpu")
                B2 = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; V.ct_update(G2, *B2, *k2, 1e-3)
                m = np.ones(B1[0].shape, bool)
                if G.axis: m[g] = False
                worst = max(worst, float(np.abs(B1[0] - B2[0])[m].max()), float(np.abs(B1[1] - B2[1]).max()), float(np.abs(B1[2] - B2[2]).max()))
                f1 = _force(G, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]), backend="cpu"); f2 = V.lorentz_force(G2, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]))
                worst = max(worst, max(float(np.abs(x - y).max()) for x, y in zip(f1, f2)))
    return dict(conditions="all EMF-01 sizes, annulus + axis, FP64 + FP32, eta and hall on; CPU backend both (x86-64: neither build contracts); "
                           "CT compared with the same (v02) EMFs; hash of v02 checked", worst=worst, fp32_axis_edge_ulps=worst_axis_ulps), \
        [("max |v02.1 - v02| (EMF, CT except axis face, force; FP32 axis edges excluded)", worst, "<=", THRESHOLDS["R00_regression_v02"]),
         ("FP32 axis-edge EMF difference, ulps of the axis-edge scale", worst_axis_ulps, "<=", THRESHOLDS["R00_fp32_axis_edge_ulps"])]

def G5():
    """v02.1: GPU and CPU bit-identical (EMF incl. axis edges, CT incl. axis closure, force), FP64 + FP32, normal and subnormal scale"""
    rng = np.random.default_rng(505); diff = 0; tot = 0
    for dt_ in (np.float64, np.float32):
        for rmin, (nr, nphi, nz), scale in ((0.0, (9, 12, 5), 1.0), (0.4, (17, 13, 9), 1.0), (0.0, (40, 32, 17), 1.0), (0.0, (8, 8, 4), 1e-21 if dt_ == np.float32 else 1e-160)):
            G = E.Grid(nr, nphi, nz, rmin, 1.3, dtype=dt_); a = rand_inputs(G, rng, dt_, scale=scale)
            kw = dict(eta=0.01, hall=0.1)
            kc = _emf(G, a["Br"], a["Bphi"], a["Bz"], a["vr"], a["vp"], a["vz"], a["rho"], a["p"], J=(a["Jr"], a["Jp"], a["Jz"]), backend="cpu", **kw)
            kg = call_emf(G, a, **kw)
            Bc = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; _ct(G, *Bc, *kc, 1e-3, backend="cpu")
            Bg = [a[x].copy() for x in ("Br", "Bphi", "Bz")]; E.ct_update(G, *Bg, *kc, 1e-3)
            fc = _force(G, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]), backend="cpu"); fg = E.lorentz_force(G, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]))
            for x, y in zip(list(kg) + Bg + list(fg), list(kc) + Bc + list(fc)):
                d = (x != y) & ~(np.isnan(x) & np.isnan(y)); diff += int(d.sum()); tot += x.size
    return dict(conditions="4 grids incl. partial blocks and a subnormal-scale case (products underflow), eta + hall on; exact comparison", values=tot, differing=diff), \
        [("GPU values differing from CPU", float(diff), "<=", THRESHOLDS["G5_gpu_cpu_bitwise"])]

def G6():
    ok = float(E.gpu_ieee_selftest()); m32 = E._gpu_mod(np.float32); m64 = E._gpu_mod(np.float64)
    return dict(conditions="FP32 subnormal *, +, / bit-identical to IEEE through the kernel's own NVRTC path; PTX free of .ftz", options=list(m32.options)), \
        [("FP32 subnormal arithmetic bit-identical to IEEE", ok, "==", THRESHOLDS["G6_ieee_selftest"]), ("'.ftz' in UCT-EMF PTX", float(m32.ptx_ftz_count + m64.ptx_ftz_count), "<=", 0.0)]

CPU_TESTS = [C01, C02, C03, C04, C05, C06, C07, C08, C09, C10, C11, C12, C13, C14, C15, C16, C17, A01, A02, A03, R00]
GPU_TESTS = [G6, G1, G2, G3, G5]

OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}

def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

def env():
    e = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, deep=DEEP, backend=BACKEND,
             platform=platform.platform(), python=sys.version.split()[0], numpy=np.__version__, cpu_count=os.cpu_count())
    try: e["gxx"] = subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    except Exception as x: e["gxx"] = repr(x)
    try:
        import scipy; e["scipy"] = scipy.__version__
    except Exception: pass
    if BACKEND == "cupy":
        import cupy as cp
        e["cupy"] = cp.__version__; e["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); e["cuda_runtime"] = cp.cuda.runtime.runtimeGetVersion()
    return e

if __name__ == "__main__":
    files = ["uct_emf_v02.py", "numpy_oracle.py", "dev_emf.py", "dev_emf2.py", "uct_curl.py", "campaign_emf02.py", "reference/uct_emf_v02_certified.py"]
    R = dict(campaign="EMF-02", kernel="ALADIN UCT-EMF v02.1", env=env(), kernel_source_sha256=E.SOURCE_SHA256, frozen_sha256=FROZEN_SHA, build_sha256=E.BUILD_SHA256, frozen_build_sha256=FROZEN_BUILD, gpu_options=list(E.GPU_OPTIONS), cpu_flags=list(E.CPU_FLAGS), gpu_loader=E.GPU_LOADER,
             file_sha256={f: sha(os.path.join(HERE, f)) for f in files}, thresholds=THRESHOLDS, tests=[])
    log(f"EMF-02 leg={LEG} backend={BACKEND} deep={DEEP}  kernel sha {E.SOURCE_SHA256} build sha {E.BUILD_SHA256}")
    if E.SOURCE_SHA256 != FROZEN_SHA or E.BUILD_SHA256 != FROZEN_BUILD:
        log("BLOCKER: kernel source does not match the frozen hash"); R["tests"].append(dict(id="FREEZE", cls="BLOCKER", detail="source hash mismatch"))
    tests = list(CPU_TESTS)
    if LEG == "gpu":
        tests += GPU_TESTS if E.has_gpu() else []
    for f in tests:
        t0 = time.time(); rec = dict(id=f.__name__, title=(f.__doc__ or "").strip())
        try:
            data, checks = f(); cls_ok = data.pop("cls_if_pass", "VERIFIED")
            rec["data"] = data
            rec["checks"] = [dict(name=n, measured=float(v), op=op, threshold=float(th), passed=bool(OPS[op](float(v), float(th)))) for n, v, op, th in checks]
            rec["passed"] = all(c["passed"] for c in rec["checks"]); rec["cls"] = cls_ok if rec["passed"] else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["passed"] = False; rec["exception"] = traceback.format_exc()
        rec["seconds"] = round(time.time() - t0, 2); R["tests"].append(rec)
        log(f"{rec['id']:4s} {rec['cls']:10s} {rec['seconds']:8.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec.get("checks", [])))
        if "exception" in rec: log(rec["exception"])
    if LEG == "gpu" and not E.has_gpu():
        for f in GPU_TESTS: R["tests"].append(dict(id=f.__name__, cls="INCONCLUSIVE", passed=None, detail="no GPU on this leg"))
    counts = {}
    for t in R["tests"]: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    R["summary"] = counts; log("SUMMARY", counts)
    json.dump(R, open(os.path.join(HERE, f"emf02_{LEG}_results.json"), "w"), indent=1, default=float)
