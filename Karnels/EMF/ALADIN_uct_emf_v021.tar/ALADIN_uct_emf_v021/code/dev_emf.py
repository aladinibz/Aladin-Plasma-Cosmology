# -*- coding: utf-8 -*-
"""Development study for uct_emf_v02 (CPU; GPU legs when CuPy is present).  Exact references only."""
import sys, os, time, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import uct_emf_v02 as E


def from_Az(G, Az_fn, t=0.0):
    """faces from a z-independent vector potential Az(x, y, t) given at z-edges (point values -> exact face fluxes)."""
    Br, Bp, Bz = G.zeros("Br"), G.zeros("Bphi"), G.zeros("Bz")
    rf = G.r_faces[:, None]; pf = G.phi_f[None, :]
    A = Az_fn(rf * np.cos(pf), rf * np.sin(pf), t)                       # (nr+1+2g, nphi+1+2g) at z-edges
    with np.errstate(divide="ignore", invalid="ignore"):
        br = (A[:, 1:] - A[:, :-1]) / (G.r_faces[:, None] * G.dphi)      # Br on r-faces (I, j)
    bp = -(A[1:, :] - A[:-1, :]) / G.dr                                   # Bphi on phi-faces (i, J)
    Br[...] = np.nan_to_num(br)[:, :, None]; Bp[...] = bp[:, :, None]
    return Br, Bp, Bz


def axis_br(G, Br, Bxy_fn, t):
    """axis face (r = 0) limiting value Br(0, phi) = Bx cos(phi) + By sin(phi) from the exact Cartesian field at the axis."""
    if not G.axis: return
    bx, by = Bxy_fn(0.0, 0.0, t); ph = G.phi_c
    Br[G.g, :, :] = (bx * np.cos(ph) + by * np.sin(ph))[:, None]


def velocity(G, kind, **kw):
    sh = G.shape("cell"); r = G.r_centers[:, None, None] * np.ones(sh); ph = G.phi_c[None, :, None] * np.ones(sh)
    vr, vp, vz = np.zeros(sh), np.zeros(sh), np.zeros(sh)
    if kind == "rotation": vp[...] = kw["Om"] * r
    if kind == "translation":
        Vx, Vy = kw["V"]; vr[...] = Vx * np.cos(ph) + Vy * np.sin(ph); vp[...] = -Vx * np.sin(ph) + Vy * np.cos(ph)
    return vr, vp, vz


def rk2(G, B, v, rho, p, dt, nsteps, fill, **emf_kw):
    Br, Bp, Bz = B
    for n in range(nsteps):
        fill(Br, Bp, Bz, n * dt)
        Er, Ep, Ez = E.compute_emf(G, Br, Bp, Bz, *v, rho, p, **emf_kw)
        B1 = [a.copy() for a in (Br, Bp, Bz)]; E.ct_update(G, *B1, Er, Ep, Ez, dt)
        fill(*B1, (n + 1) * dt)
        Er, Ep, Ez = E.compute_emf(G, *B1, *v, rho, p, **emf_kw)
        B2 = [a.copy() for a in B1]; E.ct_update(G, *B2, Er, Ep, Ez, dt)
        for a, a1 in zip((Br, Bp, Bz), B2): a[...] = 0.5 * (a + a1)
    fill(Br, Bp, Bz, nsteps * dt)
    return Br, Bp, Bz


def l1_err(G, B, Bex):
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz
    sl = [(slice(g + (1 if G.axis else 0), g + n + 1), slice(g, g + P)), (slice(g, g + n), slice(g, g + P + 1))]
    num = den = 0.0
    for a, b, s in zip(B[:2], Bex[:2], sl):
        num += float(np.abs(a[s[0], s[1], g:g + Z] - b[s[0], s[1], g:g + Z]).sum()); den += float(np.abs(b[s[0], s[1], g:g + Z]).sum())
    return num / den


# ---------------------------------------------------------------- tests
def t_divergence(dt_=np.float64, steps=2000):
    """random divergence-free B (from a random vector potential with all three components), random v; CT keeps div B"""
    rng = np.random.default_rng(0)
    G = E.Grid(12, 16, 10, 0.4, 1.6, dtype=dt_)
    # discrete curl of random edge potentials -> exactly divergence-free faces
    Ar, Ap, Az = rng.normal(size=G.shape("Er")), rng.normal(size=G.shape("Ephi")), rng.normal(size=G.shape("Ez"))
    Br, Bp, Bz = G.zeros("Br"), G.zeros("Bphi"), G.zeros("Bz")
    for a in (Br, Bp, Bz): a[...] = 0
    E.ct_update(G, Br, Bp, Bz, Ar.astype(dt_), Ap.astype(dt_), Az.astype(dt_), -1.0)   # B = curl A (sign irrelevant)
    vr, vp, vz = [rng.normal(0, 0.5, G.shape("cell")).astype(dt_) for _ in range(3)]
    rho = rng.uniform(0.5, 2, G.shape("cell")).astype(dt_); p = rng.uniform(0.5, 2, G.shape("cell")).astype(dt_)
    d0 = float(np.abs(E.divergence(G, Br, Bp, Bz)[1]).max())
    worst = d0
    for n in range(steps):
        Er, Ep, Ez = E.compute_emf(G, Br, Bp, Bz, vr, vp, vz, rho, p)
        E.ct_update(G, Br, Bp, Bz, Er, Ep, Ez, 1e-3)
        if n % 200 == 0 or n == steps - 1: worst = max(worst, float(np.abs(E.divergence(G, Br, Bp, Bz)[1]).max()))
    return dict(initial=d0, worst_normalised_div=worst, steps=steps, finite=bool(all(np.isfinite(a).all() for a in (Br, Bp, Bz))))


def t_rotation(nr, dt_=np.float64, limiter="mc", turn=0.25):
    """smooth field loop (Gaussian Az) rigidly rotated on the annulus [0.5, 1.5]: exact solution = rotated loop"""
    nphi = int(round(2 * np.pi / (1.0 / nr))); nphi += nphi % 2
    G = E.Grid(nr, nphi, 1, 0.5, 1.5, dtype=dt_)
    w, Om = 0.12, 1.0
    def Az(x, y, t):
        a = Om * t; xc, yc = np.cos(a), np.sin(a)
        return 1e-2 * np.exp(-((x - xc) ** 2 + (y - yc) ** 2) / w ** 2)
    B = from_Az(G, Az, 0.0); v = velocity(G, "rotation", Om=Om); rho = np.ones(G.shape("cell")); p = np.ones(G.shape("cell"))
    v = [a.astype(dt_) for a in v]; rho = rho.astype(dt_); p = p.astype(dt_)
    cmax = 1.5 * Om + np.sqrt(5 / 3); dx = min(G.dr, 0.5 * G.dphi); T = turn * 2 * np.pi / Om
    nsteps = int(np.ceil(T / (0.4 * dx / cmax))); dt = T / nsteps
    def fill(Br, Bp, Bz, t): E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
    B = [a.astype(dt_) for a in B]
    t0 = time.time(); B = rk2(G, B, v, rho, p, dt, nsteps, fill, limiter=limiter)
    Bex = from_Az(G, Az, T)
    return dict(nr=nr, nphi=nphi, steps=nsteps, l1=l1_err(G, B, Bex), div=float(np.abs(E.divergence(G, *B)[1]).max()), s=time.time() - t0)


def t_axis_translation(nr, dt_=np.float64):
    """smooth loop translated straight across the axis on the full disk r < 1 (reflected axis ghosts): exact = translated loop"""
    nphi = 4 * nr
    G = E.Grid(nr, nphi, 1, 0.0, 1.0, dtype=dt_)
    w, V = 0.15, (0.6, 0.25)
    x0 = (-0.3, -0.125)
    def Az(x, y, t): return 1e-2 * np.exp(-((x - x0[0] - V[0] * t) ** 2 + (y - x0[1] - V[1] * t) ** 2) / w ** 2)
    def Bxy(x, y, t):   # B = curl(Az z) = (dAz/dy, -dAz/dx)
        a = Az(x, y, t); dx_ = x - x0[0] - V[0] * t; dy_ = y - x0[1] - V[1] * t
        return (-2 * dy_ / w ** 2 * a, 2 * dx_ / w ** 2 * a)
    B = list(from_Az(G, Az, 0.0)); axis_br(G, B[0], Bxy, 0.0)
    v = [a.astype(dt_) for a in velocity(G, "translation", V=V)]; rho = np.ones(G.shape("cell"), dt_); p = np.ones(G.shape("cell"), dt_)
    cmax = np.hypot(*V) + np.sqrt(5 / 3); dx = min(G.dr, 0.5 * G.dr * G.dphi); T = 1.0
    nsteps = int(np.ceil(T / (0.4 * dx / cmax))); dt = T / nsteps
    def fill(Br, Bp, Bz, t):
        axis_br(G, Br, Bxy, t)
        E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
        E.fill_axis_ghosts(G, Br=Br, Bphi=Bp, Bz=Bz)
        E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
    vr, vp, vz = v
    E.fill_periodic(G, vr, vp, vz, kinds=("cell",) * 3); E.fill_axis_ghosts(G, cells_vector=[(vr, vp, vz)]); E.fill_periodic(G, vr, vp, vz, kinds=("cell",) * 3)
    B = [a.astype(dt_) for a in B]
    t0 = time.time(); B = rk2(G, B, (vr, vp, vz), rho, p, dt, nsteps, fill)
    Bex = list(from_Az(G, Az, T)); axis_br(G, Bex[0], Bxy, T)
    return dict(nr=nr, nphi=nphi, steps=nsteps, l1=l1_err(G, B, Bex), div=float(np.abs(E.divergence(G, *B)[1]).max()), s=time.time() - t0)


def t_donor():
    """supersonic flow, states constant in each quadrant around one z-edge: UCT must return exactly the upstream corner"""
    out = []
    G = E.Grid(8, 8, 3, 0.5, 1.5)
    for sr in (+1, -1):
        for sp in (+1, -1):
            sh = G.shape("cell"); vr = np.zeros(sh); vp = np.zeros(sh); vz = np.zeros(sh)
            Br, Bp, Bz = G.zeros("Br"), G.zeros("Bphi"), G.zeros("Bz")
            I, J = G.g + 4, G.g + 4
            Ecorner = {}
            for a in (0, 1):
                for b in (0, 1):
                    ri = slice(None, I) if a == 0 else slice(I, None); pj = slice(None, J) if b == 0 else slice(J, None)
                    vr[ri, pj] = sr * (50 + 3 * a + 7 * b); vp[ri, pj] = sp * (40 + 5 * a + 2 * b)
            for a in (0, 1):
                ri = slice(None, I) if a == 0 else slice(I, None); Bp[ri] = 0.3 + 0.2 * a
            for b in (0, 1):
                pj = slice(None, J) if b == 0 else slice(J, None); Br[:, pj] = -0.4 + 0.3 * b
            for a in (0, 1):
                for b in (0, 1):
                    Ecorner[(a, b)] = float(vp[I - 1 + a, J - 1 + b, G.g] * Br[I, J - 1 + b, G.g] - vr[I - 1 + a, J - 1 + b, G.g] * Bp[I - 1 + a, J, G.g])
            rho = np.ones(sh); p = np.full(sh, 1e-6)
            _, _, Ez = E.compute_emf(G, Br, Bp, Bz, vr, vp, vz, rho, p, limiter="minmod")
            up = (0 if sr > 0 else 1, 0 if sp > 0 else 1)
            out.append(dict(vr=sr, vphi=sp, Ez=float(Ez[I, J, G.g + 1]), upstream=Ecorner[up], err=abs(float(Ez[I, J, G.g + 1]) - Ecorner[up])))
    return out




def t_resistive(nr, eta=0.05, T=1.0, dt_=np.float64, hall=0.0, nphi=None, limiter="mc"):
    """Resistive decay of Bphi = J1(k r) on the full disk (axis grid), k = j_{1,1}: exact Bphi = J1(k r) exp(-eta k^2 t).
    J at every stage from the verified UCT_CURL v1.3 (axis mode); E_z = eta J_z through uct_emf_v02; CT update."""
    import uct_curl as UC
    from scipy.special import j0, j1
    k = 3.8317059702075125
    nphi = nphi or max(8, nr)
    G = E.Grid(nr, nphi, 1, 0.0, 1.0, dtype=dt_)
    def exact_bp(t): return (j1(k * G.r_centers) * np.exp(-eta * k * k * t))[:, None, None] * np.ones(G.shape("Bphi"))
    Br, Bp, Bz = G.zeros("Br"), exact_bp(0.0).astype(dt_), G.zeros("Bz")
    sh = G.shape("cell"); z = np.zeros(sh, dt_); rho = np.ones(sh, dt_); p = np.ones(sh, dt_)
    rf = np.ascontiguousarray(G.r_faces, dt_); rc = np.ascontiguousarray(G.r_centers, dt_)
    ghost_outer = slice(G.g + G.nr, None)
    def fill(Br, Bp, Bz, t):
        Bp[ghost_outer] = exact_bp(t)[ghost_outer]
        E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
        E.fill_axis_ghosts(G, Br=Br, Bphi=Bp, Bz=Bz); E.fill_periodic(G, Br, Bp, Bz, kinds=("Br", "Bphi", "Bz"))
    def currents(Br, Bp, Bz, t):
        J, _ = UC.run_curl(Br, Bp, Bz, rf, rc, G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
        Jr, Jp, Jz = [np.ascontiguousarray(a, dt_) for a in J]
        Jz[ghost_outer] = (k * j0(k * G.r_centers) * np.exp(-eta * k * k * t))[ghost_outer][:, None, None]
        E.fill_periodic(G, Jr, Jp, Jz, kinds=("cell",) * 3); E.fill_axis_ghosts(G, cells_vector=[(Jr, Jp, Jz)]); E.fill_periodic(G, Jr, Jp, Jz, kinds=("cell",) * 3)
        return Jr, Jp, Jz
    dx = 0.5 * G.dr * G.dphi; cmax = np.sqrt(5 / 3) + 1.0
    dt = min(0.4 * dx / cmax, 0.2 * dx * dx / eta); nsteps = int(np.ceil(T / dt)); dt = T / nsteps
    B = [Br, Bp, Bz]
    for n in range(nsteps):
        t = n * dt; fill(*B, t); J = currents(*B, t)
        Er, Ep, Ez = E.compute_emf(G, *B, z, z, z, rho, p, J=J, eta=eta, hall=hall, limiter=limiter)
        B1 = [a.copy() for a in B]; E.ct_update(G, *B1, Er, Ep, Ez, dt); fill(*B1, t + dt); J1 = currents(*B1, t + dt)
        Er, Ep, Ez = E.compute_emf(G, *B1, z, z, z, rho, p, J=J1, eta=eta, hall=hall, limiter=limiter)
        B2 = [a.copy() for a in B1]; E.ct_update(G, *B2, Er, Ep, Ez, dt)
        for a, a2 in zip(B, B2): a[...] = 0.5 * (a + a2)
    fill(*B, T)
    g = G.g; I = slice(g, g + G.nr)
    ex = exact_bp(T)[I, g:g + G.nphi, g]; got = B[1][I, g:g + G.nphi, g]
    return dict(nr=nr, nphi=nphi, steps=nsteps, rel_l1=float(np.abs(got - ex).sum() / np.abs(ex).sum()),
                decay_measured=float(np.log(np.abs(got).sum() / np.abs(exact_bp(0)[I, g:g + G.nphi, g]).sum()) / -T), decay_exact=eta * k * k,
                div=float(np.abs(E.divergence(G, *B)[1]).max()))


def t_lorentz_hall():
    """Z-pinch Bphi = 0.5 r on the axis grid: J from UCT_CURL (Jz = 1) -> f_r = -Jz Bphi = -0.5 r;
    Hall: uniform v = 0, eta = 0, hall = h, uniform J and B -> E_hall = h (J x B)/rho exactly on every edge."""
    import uct_curl as UC
    G = E.Grid(16, 24, 4, 0.0, 1.0)
    Br, Bp, Bz = G.zeros("Br"), G.zeros("Bphi"), G.zeros("Bz"); Bp[...] = 0.5 * G.r_centers[:, None, None]
    J, _ = UC.run_curl(Br, Bp, Bz, np.ascontiguousarray(G.r_faces), np.ascontiguousarray(G.r_centers), G.dr, G.dphi, G.dz, G.nr, G.nphi, G.nz, G.g)
    fr, fp, fz = E.lorentz_force(G, Br, Bp, Bz, [np.ascontiguousarray(a) for a in J])
    g = G.g; I = slice(g, g + G.nr)
    err_f = float(np.abs(fr[I, g:g + G.nphi, g:g + G.nz] - (-1.0 * 0.5 * G.r_centers[I, None, None])).max())
    err_t = float(max(np.abs(fp[I, g:g + G.nphi, g:g + G.nz]).max(), np.abs(fz[I, g:g + G.nphi, g:g + G.nz]).max()))
    # Hall, uniform fields on an annulus
    H = E.Grid(6, 8, 5, 0.5, 1.5); sh = H.shape("cell"); z = np.zeros(sh); rho = np.full(sh, 2.0); p = np.ones(sh)
    br, bp, bz, jr, jp, jz, h = 0.3, -0.2, 0.5, 0.7, 0.1, -0.4, 0.25
    Br2, Bp2, Bz2 = np.full(H.shape("Br"), br), np.full(H.shape("Bphi"), bp), np.full(H.shape("Bz"), bz)
    Jx = [np.full(sh, v) for v in (jr, jp, jz)]
    Er, Ep, Ez = E.compute_emf(H, Br2, Bp2, Bz2, z, z, z, rho, p, J=Jx, hall=h)
    ex = dict(Er=h * (jp * bz - jz * bp) / 2, Ephi=h * (jz * br - jr * bz) / 2, Ez=h * (jr * bp - jp * br) / 2)
    gg = H.g
    err_h = max(float(np.abs(Er[gg:gg + H.nr, gg:gg + H.nphi + 1, gg:gg + H.nz + 1] - ex["Er"]).max()),
                float(np.abs(Ep[gg:gg + H.nr + 1, gg:gg + H.nphi, gg:gg + H.nz + 1] - ex["Ephi"]).max()),
                float(np.abs(Ez[gg:gg + H.nr + 1, gg:gg + H.nphi + 1, gg:gg + H.nz] - ex["Ez"]).max()))
    return dict(force_fr_err=err_f, force_transverse=err_t, hall_err=err_h)


def t_gpu_vs_cpu():
    """same random inputs on GPU and CPU (FP64 and FP32): edge EMFs, CT update and Lorentz force"""
    import cupy as cp
    out = {}
    for dt_ in (np.float64, np.float32):
        rng = np.random.default_rng(3)
        for rmin in (0.4, 0.0):
            Gc = E.Grid(13, 18, 11, rmin, 1.4, dtype=dt_); Gg = E.Grid(13, 18, 11, rmin, 1.4, dtype=dt_, xp=cp)
            arrs = {k: rng.normal(size=Gc.shape(s)).astype(dt_) for k, s in (("Br", "Br"), ("Bphi", "Bphi"), ("Bz", "Bz"), ("vr", "cell"), ("vp", "cell"), ("vz", "cell"),
                                                                            ("Jr", "cell"), ("Jp", "cell"), ("Jz", "cell"))}
            arrs["rho"] = rng.uniform(0.5, 2, Gc.shape("cell")).astype(dt_); arrs["p"] = rng.uniform(0.5, 2, Gc.shape("cell")).astype(dt_)
            def go(G, xp, be):
                a = {k: xp.asarray(v) for k, v in arrs.items()}
                Er, Ep, Ez = E.compute_emf(G, a["Br"], a["Bphi"], a["Bz"], a["vr"], a["vp"], a["vz"], a["rho"], a["p"], J=(a["Jr"], a["Jp"], a["Jz"]), eta=0.01, hall=0.1, backend=be)
                B = [a["Br"].copy(), a["Bphi"].copy(), a["Bz"].copy()]; E.ct_update(G, *B, Er, Ep, Ez, 1e-3, backend=be)
                f = E.lorentz_force(G, a["Br"], a["Bphi"], a["Bz"], (a["Jr"], a["Jp"], a["Jz"]), backend=be)
                h = lambda x: x.get() if hasattr(x, "get") else x
                return [h(x) for x in (Er, Ep, Ez, *B, *f)]
            c = go(Gc, np, "cpu"); gg = go(Gg, cp, "cupy")
            out[f"{np.dtype(dt_).name}_{'axis' if rmin == 0 else 'annulus'}"] = float(max(np.abs(x - y).max() / max(np.abs(x).max(), 1e-30) for x, y in zip(c, gg)))
    return out


if __name__ == "__main__":
    import platform, datetime, hashlib
    R = dict(meta=dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), platform=platform.platform(),
                       source_sha256=E.SOURCE_SHA256, file_sha256=hashlib.sha256(open(E.__file__, "rb").read()).hexdigest(), gpu=E.has_gpu()))
    def say(k, v): R[k] = v; print(k, v, flush=True)
    say("D1_donor_limit", t_donor())
    say("D2_div_FP64_2000_steps", t_divergence(np.float64, 2000))
    say("D2_div_FP32_2000_steps", t_divergence(np.float32, 2000))
    say("D3_rotation", [t_rotation(n) for n in (16, 32, 64)])
    say("D4_axis_translation", [t_axis_translation(n) for n in (12, 24, 48)])
    say("D5_resistive_decay_with_UCT_CURL", [t_resistive(n) for n in (8, 16, 32)])
    say("D6_lorentz_and_hall", t_lorentz_hall())
    if E.has_gpu(): say("G1_gpu_vs_cpu_rel", t_gpu_vs_cpu())
    json.dump(R, open(os.path.join(HERE, "dev_emf_results.json"), "w"), indent=1, default=float)
    print("done")
