# -*- coding: utf-8 -*-
"""
eglm_v02.py — ALADIN EGLM v02: the div-B guardian of the native-cylindrical ALADIN Driver.

Successor of the EGLM kernel by Mihai Alexandru Bucurenciu (velocity-Verlet B–psi splitting, damping, EGLM momentum and
energy sources applied once).  v02 is a complete rewrite (new numbered file) to match the certified kernels
(UCT_CURL v1.3, UCT-EMF v02): same grid contract, ghost-extended radii, one CUDA/C++ source for GPU and CPU, FP64/FP32.

ROLE IN A CONSTRAINED-TRANSPORT DRIVER
  UCT-EMF preserves the discrete divergence to round-off at every step, so GLM cleaning has nothing to do inside the
  normal step (and its face correction, a gradient, is not a curl).  EGLM v02 therefore provides:
    monitor()   every step: the exact discrete divergence (net flux out of each cell, the quantity CT preserves) and
                its normalised maximum, for the run log / MakeResults evidence bundle;
    project()   on demand, EXACT: discrete Hodge projection with the kernel's own operators (FFT in phi and z, direct
                tridiagonal solve in r): div B -> round-off in one call, edge circulations unchanged.  Recommended.
    clean()     on demand, iterative (the original GLM design): pseudo-time GLM
                iterations  B <- B - dt/2 grad psi;  psi <- psi - dt ch^2 div B;  psi <- psi exp(-alpha ch dt / h_damp), h_damp = min(dr, dz);
                B <- B - dt/2 grad psi  until the normalised divergence falls below tol;
    glm_step()  one step of the same splitting (the original design), and
    eglm_sources()  the EGLM momentum and energy sources  -(div B) B,  -B . grad psi  (Dedner et al. 2002) for a
                Driver that does run GLM in-step.
  Mimetic structure: the face correction is the discrete gradient of a cell scalar, so it carries zero circulation
  around every edge (discrete curl grad = 0): cleaning changes only the divergent part of B and leaves every edge
  circulation (hence the current from a circulation-based curl) untouched.  div of the face gradient is the standard
  cylindrical 7-point Laplacian, so clean() is a damped discrete wave equation for div B.

GRID CONTRACT (as UCT_CURL v1.3 / UCT-EMF v02; z fastest, C order, one dtype)
    Br (nr+1+2g, nphi+2g, nz+2g)   Bphi (nr+2g, nphi+1+2g, nz+2g)   Bz (nr+2g, nphi+2g, nz+1+2g)   psi, cells (nr+2g, nphi+2g, nz+2g)
    r_faces (nr+1+2g), r_centers (nr+2g) WITH ghosts; uniform dr, dphi, dz; axis grid iff r_faces[g] == 0.
    Faces corrected: all interior faces incl. both periodic phi faces (g and g+nphi, identical when psi ghosts are
    periodic); never the axis Br face (zero area); physical boundary faces (inner r of an annulus, outer r, and the
    z ends) are corrected only if their bit is NOT set in `fixed` (default: r_lo | r_hi fixed, i.e. the boundary
    normal flux belongs to the Driver's BoundaryManager; z periodic).  psi ghosts must be filled before each
    gradient (fill_psi() provides periodic phi/z, axis reflection and zero-gradient outer r).
"""
import os, hashlib, ctypes, subprocess, tempfile
import numpy as np

VERSION = "eglm v02 2026-11-20"
FIX_R_LO, FIX_R_HI, FIX_Z_LO, FIX_Z_HI = 1, 2, 4, 8

SRC = r"""
#ifdef EGLM_GPU
  #define DEV __device__ __forceinline__
#else
  #include <cmath>
  using namespace std;
  #define DEV static inline
#endif
typedef REAL R;

struct Grid { int nr, nphi, nz, g; R dr, dphi, dz; };
#define S_C(a,b,c)   (((a)*(G.nphi+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BR(a,b,c)  (((a)*(G.nphi+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BP(a,b,c)  (((a)*(G.nphi+1+2*G.g) + (b))*(G.nz+2*G.g) + (c))
#define S_BZ(a,b,c)  (((a)*(G.nphi+2*G.g) + (b))*(G.nz+1+2*G.g) + (c))

DEV void decode(long t, int n0, int n1, int n2, int* a, int* b, int* c) { *c = int(t % n2); t /= n2; *b = int(t % n1); *a = int(t / n1); }

// net magnetic flux out of cell (i,j,k), its volume, and the largest |face flux| of the cell
DEV void cell_flux(const R* Br, const R* Bp, const R* Bz, const R* rf, const Grid& G, int i, int j, int k, R* net, R* vol, R* fmx) {
    R r0 = rf[i], r1 = rf[i+1], area = R(0.5)*(r1*r1 - r0*r0)*G.dphi;
    R f[6];
    f[0] = r1*Br[S_BR(i+1,j,k)]*G.dphi*G.dz; f[1] = r0*Br[S_BR(i,j,k)]*G.dphi*G.dz;
    f[2] = Bp[S_BP(i,j+1,k)]*G.dr*G.dz;      f[3] = Bp[S_BP(i,j,k)]*G.dr*G.dz;
    f[4] = Bz[S_BZ(i,j,k+1)]*area;           f[5] = Bz[S_BZ(i,j,k)]*area;
    *net = (f[0] - f[1]) + (f[2] - f[3]) + (f[4] - f[5]);
    *vol = area*G.dz;
    R m = R(0); for (int q = 0; q < 6; ++q) m = fmax(m, fabs(f[q])); *fmx = m;
}

DEV void div_one(long t, const R* Br, const R* Bp, const R* Bz, const R* rf, const Grid& G, R* div, R* net, R* fm) {
    int a, b, c; decode(t, G.nr, G.nphi, G.nz, &a, &b, &c); int i = a+G.g, j = b+G.g, k = c+G.g;
    R n, v, m; cell_flux(Br, Bp, Bz, rf, G, i, j, k, &n, &v, &m);
    div[S_C(i,j,k)] = n/v; net[S_C(i,j,k)] = n; fm[S_C(i,j,k)] = m;
}

DEV void psi_one(long t, const R* Br, const R* Bp, const R* Bz, const R* rf, const Grid& G, R* psi, R dt, R ch2) {
    int a, b, c; decode(t, G.nr, G.nphi, G.nz, &a, &b, &c); int i = a+G.g, j = b+G.g, k = c+G.g;
    R n, v, m; cell_flux(Br, Bp, Bz, rf, G, i, j, k, &n, &v, &m);
    psi[S_C(i,j,k)] -= dt*ch2*(n/v);
}

// B_face -= h * (discrete gradient of psi) on face t
DEV void grad_one(long t, R* Br, R* Bp, R* Bz, const R* psi, const R* rf, const R* rc, const Grid& G, R h, int fixed) {
    long nBr = long(G.nr+1)*G.nphi*G.nz, nBp = long(G.nr)*(G.nphi+1)*G.nz, nBz = long(G.nr)*G.nphi*(G.nz+1);
    int a, b, c;
    if (t < nBr) {
        decode(t, G.nr+1, G.nphi, G.nz, &a, &b, &c); int I = a+G.g, j = b+G.g, k = c+G.g;
        if (rf[I] == R(0)) return;                                   // axis face
        if (a == 0 && (fixed & 1)) return; if (a == G.nr && (fixed & 2)) return;
        Br[S_BR(I,j,k)] -= h*(psi[S_C(I,j,k)] - psi[S_C(I-1,j,k)])/G.dr; return;
    }
    t -= nBr;
    if (t < nBp) {
        decode(t, G.nr, G.nphi+1, G.nz, &a, &b, &c); int i = a+G.g, J = b+G.g, k = c+G.g;
        Bp[S_BP(i,J,k)] -= h*(psi[S_C(i,J,k)] - psi[S_C(i,J-1,k)])/(rc[i]*G.dphi); return;
    }
    t -= nBp;
    if (t < nBz) {
        decode(t, G.nr, G.nphi, G.nz+1, &a, &b, &c); int i = a+G.g, j = b+G.g, K = c+G.g;
        if (c == 0 && (fixed & 4)) return; if (c == G.nz && (fixed & 8)) return;
        Bz[S_BZ(i,j,K)] -= h*(psi[S_C(i,j,K)] - psi[S_C(i,j,K-1)])/G.dz;
    }
}

// EGLM sources (Dedner et al. 2002): d(rho v) = -dt (div B) B_c ;  dE = -dt B_c . grad psi  (centred gradient)
DEV void src_one(long t, const R* Br, const R* Bp, const R* Bz, const R* psi, const R* rf, const R* rc, const Grid& G, R dt,
                 R* dmr, R* dmp, R* dmz, R* de) {
    int a, b, c; decode(t, G.nr, G.nphi, G.nz, &a, &b, &c); int i = a+G.g, j = b+G.g, k = c+G.g;
    R n, v, m; cell_flux(Br, Bp, Bz, rf, G, i, j, k, &n, &v, &m); R d = n/v;
    R br = R(0.5)*(Br[S_BR(i,j,k)] + Br[S_BR(i+1,j,k)]), bp = R(0.5)*(Bp[S_BP(i,j,k)] + Bp[S_BP(i,j+1,k)]),
      bz = R(0.5)*(Bz[S_BZ(i,j,k)] + Bz[S_BZ(i,j,k+1)]);
    R gr = (psi[S_C(i+1,j,k)] - psi[S_C(i-1,j,k)])/(R(2)*G.dr);
    R gp = (psi[S_C(i,j+1,k)] - psi[S_C(i,j-1,k)])/(R(2)*rc[i]*G.dphi);
    R gz = (psi[S_C(i,j,k+1)] - psi[S_C(i,j,k-1)])/(R(2)*G.dz);
    dmr[S_C(i,j,k)] = -dt*d*br; dmp[S_C(i,j,k)] = -dt*d*bp; dmz[S_C(i,j,k)] = -dt*d*bz;
    de[S_C(i,j,k)] = -dt*(br*gr + bp*gp + bz*gz);
}

#define GA int nr, int nphi, int nz, int g, R dr, R dphi, R dz
#define MAKE_G Grid G; G.nr = nr; G.nphi = nphi; G.nz = nz; G.g = g; G.dr = dr; G.dphi = dphi; G.dz = dz;

#ifdef EGLM_GPU
#define TID long t = long(blockIdx.x)*blockDim.x + threadIdx.x; if (t >= ntot) return; MAKE_G
extern "C" __global__ void div_kernel(const R* Br, const R* Bp, const R* Bz, const R* rf, GA, R* div, R* net, R* fm, long ntot) { TID div_one(t, Br, Bp, Bz, rf, G, div, net, fm); }
extern "C" __global__ void psi_kernel(const R* Br, const R* Bp, const R* Bz, const R* rf, GA, R* psi, R dt, R ch2, long ntot) { TID psi_one(t, Br, Bp, Bz, rf, G, psi, dt, ch2); }
extern "C" __global__ void grad_kernel(R* Br, R* Bp, R* Bz, const R* psi, const R* rf, const R* rc, GA, R h, int fixed, long ntot) { TID grad_one(t, Br, Bp, Bz, psi, rf, rc, G, h, fixed); }
extern "C" __global__ void src_kernel(const R* Br, const R* Bp, const R* Bz, const R* psi, const R* rf, const R* rc, GA, R dt,
                                      R* dmr, R* dmp, R* dmz, R* de, long ntot) { TID src_one(t, Br, Bp, Bz, psi, rf, rc, G, dt, dmr, dmp, dmz, de); }
#else
#define LOOP MAKE_G _Pragma("omp parallel for schedule(static)") for (long t = 0; t < ntot; ++t)
extern "C" void div_cpu(const R* Br, const R* Bp, const R* Bz, const R* rf, GA, R* div, R* net, R* fm, long ntot) { LOOP div_one(t, Br, Bp, Bz, rf, G, div, net, fm); }
extern "C" void psi_cpu(const R* Br, const R* Bp, const R* Bz, const R* rf, GA, R* psi, R dt, R ch2, long ntot) { LOOP psi_one(t, Br, Bp, Bz, rf, G, psi, dt, ch2); }
extern "C" void grad_cpu(R* Br, R* Bp, R* Bz, const R* psi, const R* rf, const R* rc, GA, R h, int fixed, long ntot) { LOOP grad_one(t, Br, Bp, Bz, psi, rf, rc, G, h, fixed); }
extern "C" void src_cpu(const R* Br, const R* Bp, const R* Bz, const R* psi, const R* rf, const R* rc, GA, R dt,
                        R* dmr, R* dmp, R* dmz, R* de, long ntot) { LOOP src_one(t, Br, Bp, Bz, psi, rf, rc, G, dt, dmr, dmp, dmz, de); }
#endif
"""

SOURCE_SHA256 = hashlib.sha256(SRC.encode()).hexdigest()
_cache = {}


def has_gpu():
    try:
        import cupy as cp
        return cp.cuda.runtime.getDeviceCount() > 0
    except Exception:
        return False


def _cpu_lib(dtype):
    real = "double" if dtype == np.float64 else "float"
    if ("cpu", real) in _cache: return _cache[("cpu", real)]
    d = os.path.join(tempfile.gettempdir(), "eglm_v02_" + hashlib.sha256((SRC + real).encode()).hexdigest()[:16])
    os.makedirs(d, exist_ok=True); so = os.path.join(d, "eglm.so")
    if not os.path.exists(so):
        open(os.path.join(d, "eglm.cpp"), "w").write(SRC)
        cmd = ["g++", "-O2", "-shared", "-fPIC", "-fopenmp", f"-DREAL={real}", "-o", so, os.path.join(d, "eglm.cpp")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            cmd.remove("-fopenmp"); r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: raise RuntimeError(r.stderr)
    lib = ctypes.CDLL(so); _cache[("cpu", real)] = lib; return lib


def _gpu_mod(dtype):
    import cupy as cp
    real = "double" if dtype == np.float64 else "float"
    if ("gpu", real) not in _cache:
        _cache[("gpu", real)] = cp.RawModule(code=SRC, options=("-DEGLM_GPU", f"-DREAL={real}", "-std=c++14"))
    return _cache[("gpu", real)]


class Grid:
    """Identical to uct_emf_v02.Grid: ghost-extended r_faces / r_centers (axis grid: r_faces[g] == 0)."""

    def __init__(self, nr, nphi, nz, rmin, rmax, zlen=1.0, g=2, dtype=np.float64, xp=np):
        self.nr, self.nphi, self.nz, self.g, self.dtype, self.xp = nr, nphi, nz, g, dtype, xp
        self.dr = (rmax - rmin) / nr; self.dphi = 2 * np.pi / nphi; self.dz = zlen / nz; self.rmin = rmin
        rf = rmin + (np.arange(nr + 1 + 2 * g) - g) * self.dr
        if rmin == 0: rf[g] = 0.0
        self.r_faces = rf; self.r_centers = 0.5 * (rf[:-1] + rf[1:])
        self.phi_c = (np.arange(nphi + 2 * g) - g + 0.5) * self.dphi; self.phi_f = (np.arange(nphi + 1 + 2 * g) - g) * self.dphi
        self.z_c = (np.arange(nz + 2 * g) - g + 0.5) * self.dz; self.z_f = (np.arange(nz + 1 + 2 * g) - g) * self.dz
        self.axis = rmin == 0
        self.h_min = min(self.dr, self.r_centers[g] * self.dphi, self.dz)      # CFL length (smallest cell edge)
        self.h_damp = min(self.dr, self.dz)                                     # damping length (axis-independent)

    def shape(self, kind):
        n, p, z, g = self.nr, self.nphi, self.nz, self.g
        return dict(cell=(n + 2 * g, p + 2 * g, z + 2 * g), Br=(n + 1 + 2 * g, p + 2 * g, z + 2 * g), Bphi=(n + 2 * g, p + 1 + 2 * g, z + 2 * g),
                    Bz=(n + 2 * g, p + 2 * g, z + 1 + 2 * g))[kind]

    def zeros(self, kind):
        return self.xp.zeros(self.shape(kind), dtype=self.dtype)


def _common(G):
    dt = G.dtype; xp = G.xp; sc = np.float64 if dt == np.float64 else np.float32
    return dt, xp, sc, xp.asarray(G.r_faces, dtype=dt), xp.asarray(G.r_centers, dtype=dt)


def _launch(G, name, backend, arrays, scal, ntot):
    dt = G.dtype
    if backend == "cupy":
        _gpu_mod(dt).get_function(name + "_kernel")(((ntot + 127) // 128,), (128,), tuple(arrays) + tuple(scal) + (np.int64(ntot),))
    else:
        lib = _cpu_lib(dt)
        def cv(x):
            if isinstance(x, np.ndarray):
                assert x.flags.c_contiguous and x.dtype == dt; return x.ctypes.data_as(ctypes.c_void_p)
            if isinstance(x, (np.float64, np.float32)): return (ctypes.c_double if dt == np.float64 else ctypes.c_float)(float(x))
            return ctypes.c_int(int(x))
        getattr(lib, name + "_cpu")(*[cv(a) for a in arrays], *[cv(s) for s in scal], ctypes.c_long(ntot))


def _ga(G, sc):
    return [np.int32(G.nr), np.int32(G.nphi), np.int32(G.nz), np.int32(G.g), sc(G.dr), sc(G.dphi), sc(G.dz)]


def divergence(G, Br, Bphi, Bz, backend="cpu"):
    """(div, net, face_max) cell arrays: div = net flux / volume (the discrete divergence CT preserves), net = net flux,
    face_max = largest |face flux| of the cell.  Interior cells only; ghosts are zero."""
    dt, xp, sc, rf, rc = _common(G)
    div, net, fm = G.zeros("cell"), G.zeros("cell"), G.zeros("cell")
    n = G.nr * G.nphi * G.nz
    _launch(G, "div", backend, [Br, Bphi, Bz, rf], _ga(G, sc) + [div, net, fm], n)
    return div, net, fm


def monitor(G, Br, Bphi, Bz, backend="cpu"):
    """Every-step div-B monitor: max |net flux| / max |face flux| on the grid (scale-free, as uct_emf_v02.divergence),
    max |div B| and its volume-weighted RMS."""
    div, net, fm = divergence(G, Br, Bphi, Bz, backend)
    g = G.g; s = (slice(g, g + G.nr), slice(g, g + G.nphi), slice(g, g + G.nz)); xp = G.xp
    vol = xp.asarray(0.5 * (G.r_faces[g + 1:g + G.nr + 1] ** 2 - G.r_faces[g:g + G.nr] ** 2) * G.dphi * G.dz)[:, None, None]
    scale = float(xp.abs(fm[s]).max())
    return dict(max_norm=float(xp.abs(net[s]).max()) / max(scale, 1e-300), max_abs_div=float(xp.abs(div[s]).max()),
                rms_div=float(xp.sqrt((vol * div[s].astype(np.float64) ** 2).sum() / (float(vol.sum()) * G.nphi * G.nz))))


def psi_update(G, Br, Bphi, Bz, psi, dt_step, ch, backend="cpu"):
    """psi <- psi - dt ch^2 div B on interior cells."""
    dt, xp, sc, rf, rc = _common(G)
    _launch(G, "psi", backend, [Br, Bphi, Bz, rf], _ga(G, sc) + [psi, sc(dt_step), sc(ch * ch)], G.nr * G.nphi * G.nz)


def grad_correct(G, Br, Bphi, Bz, psi, h, fixed=FIX_R_LO | FIX_R_HI, backend="cpu"):
    """B_face <- B_face - h grad psi on every correctable face (psi ghosts must be filled)."""
    dt, xp, sc, rf, rc = _common(G)
    n = (G.nr + 1) * G.nphi * G.nz + G.nr * (G.nphi + 1) * G.nz + G.nr * G.nphi * (G.nz + 1)
    _launch(G, "grad", backend, [Br, Bphi, Bz, psi, rf, rc], _ga(G, sc) + [sc(h), np.int32(fixed)], n)


def eglm_sources(G, Br, Bphi, Bz, psi, dt_step, backend="cpu"):
    """EGLM sources (Dedner et al. 2002) at interior cells: returns (d(rho v_r), d(rho v_phi), d(rho v_z), dE) =
    -dt (div B) B_c  and  -dt B_c . grad psi.  psi ghosts must be filled.  Not used in a CT Driver's normal step."""
    dt, xp, sc, rf, rc = _common(G)
    out = [G.zeros("cell") for _ in range(4)]
    _launch(G, "src", backend, [Br, Bphi, Bz, psi, rf, rc], _ga(G, sc) + [sc(dt_step)] + out, G.nr * G.nphi * G.nz)
    return tuple(out)


def fill_psi(G, psi, outer="neumann"):
    """psi ghosts: periodic phi and z; axis grid: reflection through r = 0 (scalar, nphi even); annulus inner and outer r:
    zero gradient ('neumann') or psi = 0 at the boundary face ('dirichlet').  Test helper for the BoundaryManager."""
    g, P, Z, n = G.g, G.nphi, G.nz, G.nr; xp = G.xp
    psi[:, :g, :] = psi[:, P:P + g, :]; psi[:, g + P:, :] = psi[:, g:g + g, :]
    psi[:, :, :g] = psi[:, :, Z:Z + g]; psi[:, :, g + Z:] = psi[:, :, g:g + g]
    sgn = -1.0 if outer == "dirichlet" else 1.0
    for m in range(g):
        psi[g + n + m] = sgn * psi[g + n - 1 - m]
        if G.axis:
            inner = psi[g + m, g:g + P]; h = P // 2
            psi[g - 1 - m, g:g + P] = xp.concatenate([inner[h:], inner[:h]], axis=0)
        else:
            psi[g - 1 - m] = sgn * psi[g + m]
    psi[:, :g, :] = psi[:, P:P + g, :]; psi[:, g + P:, :] = psi[:, g:g + g, :]


def glm_step(G, Br, Bphi, Bz, psi, dt_step, ch=1.0, alpha=0.4, fixed=FIX_R_LO | FIX_R_HI, backend="cpu", fill=None):
    """One B-psi step (the original EGLM splitting, corrected): fill; B -= dt/2 grad psi; psi -= dt ch^2 div B;
    psi *= exp(-alpha ch dt / h_damp); fill; B -= dt/2 grad psi.  Stable for ch dt <= ~0.5 h_min."""
    fill = fill or (lambda q: fill_psi(G, q))
    fill(psi); grad_correct(G, Br, Bphi, Bz, psi, 0.5 * dt_step, fixed, backend)
    psi_update(G, Br, Bphi, Bz, psi, dt_step, ch, backend)
    if alpha > 0: psi *= G.dtype(np.exp(-alpha * ch * dt_step / G.h_damp))
    fill(psi); grad_correct(G, Br, Bphi, Bz, psi, 0.5 * dt_step, fixed, backend)


def clean(G, Br, Bphi, Bz, tol=None, max_iter=20000, cfl=0.4, alpha=0.4, fixed=FIX_R_LO | FIX_R_HI, backend="cpu", fill=None, every=10):
    """On-demand cleaning in pseudo-time (ch = 1, dt = cfl h_min) until monitor().max_norm <= tol
    (default 1e-12 FP64, 1e-5 FP32).  Faces are modified in place; returns a report dict with the history."""
    tol = tol if tol is not None else (1e-12 if G.dtype == np.float64 else 1e-5)
    psi = G.zeros("cell"); dt_step = cfl * G.h_min
    hist = [monitor(G, Br, Bphi, Bz, backend)["max_norm"]]; it = 0
    while hist[-1] > tol and it < max_iter:
        for _ in range(every):
            glm_step(G, Br, Bphi, Bz, psi, dt_step, 1.0, alpha, fixed, backend, fill); it += 1
        hist.append(monitor(G, Br, Bphi, Bz, backend)["max_norm"])
    return dict(converged=hist[-1] <= tol, iterations=it, final_max_norm=hist[-1], initial_max_norm=hist[0], history=hist, dt=dt_step, tol=tol)


def project(G, Br, Bphi, Bz, backend="cpu"):
    """On-demand EXACT cleaning by discrete Hodge projection: solve  div(grad psi) = div B  with the kernel's own
    discrete operators (so the result is mimetic: div B -> round-off, every edge circulation unchanged), then
    B <- B - grad psi.  Periodic phi and z (FFT), radial boundary faces fixed (Neumann; the axis face has zero area);
    direct tridiagonal solve in r for every (m, k_z) mode.  The divergence that the fixed boundary flux forces
    (total net flux != 0) cannot be removed by any cleaner and is reported.  Returns a report dict."""
    xp = G.xp; g, n, P, Z = G.g, G.nr, G.nphi, G.nz
    before = monitor(G, Br, Bphi, Bz, backend)
    div, net, _ = divergence(G, Br, Bphi, Bz, backend)
    rf = np.asarray(G.r_faces, np.float64); rc = np.asarray(G.r_centers, np.float64)
    r0, r1, rcc = rf[g:g + n], rf[g + 1:g + n + 1], rc[g:g + n]
    vol = 0.5 * (r1 ** 2 - r0 ** 2) * G.dphi * G.dz
    lo = r0 * G.dphi * G.dz / G.dr; hi = r1 * G.dphi * G.dz / G.dr          # radial couplings (flux per unit psi jump)
    lo[0] = 0.0; hi[-1] = 0.0                                               # fixed boundary faces / axis
    m = np.arange(P); kz = np.arange(Z)
    lam_p = (2 - 2 * np.cos(2 * np.pi * m / P))[None, :, None] * (G.dr * G.dz / (rcc * G.dphi))[:, None, None]
    lam_z = (2 - 2 * np.cos(2 * np.pi * kz / Z))[None, None, :] * (0.5 * (r1 ** 2 - r0 ** 2) * G.dphi / G.dz)[:, None, None]
    diag = -(lo + hi)[:, None, None] - lam_p - lam_z                       # (n, P, Z) operator (times volume)
    rhs = np.fft.fft2(np.asarray(net[g:g + n, g:g + P, g:g + Z].get() if hasattr(net, "get") else net[g:g + n, g:g + P, g:g + Z], np.float64), axes=(1, 2))
    total_net = float(np.real(rhs[:, 0, 0]).sum())
    rhs[:, 0, 0] -= (vol / vol.sum()) * total_net                           # remove the irreducible (boundary-forced) part
    diag = diag.astype(complex); a = lo.astype(complex); c = hi.astype(complex)
    diag[0, 0, 0] -= 1.0                   # pin the constant null mode of (m, kz) = (0, 0)
    # Thomas algorithm, vectorised over modes: a_i psi_{i-1} + d_i psi_i + c_i psi_{i+1} = rhs_i
    cp_ = np.zeros((n, P, Z), complex); dp = np.zeros((n, P, Z), complex)
    cp_[0] = c[0] / diag[0]; dp[0] = rhs[0] / diag[0]
    for i in range(1, n):
        den = diag[i] - a[i] * cp_[i - 1]; cp_[i] = c[i] / den; dp[i] = (rhs[i] - a[i] * dp[i - 1]) / den
    psi_hat = np.zeros((n, P, Z), complex); psi_hat[-1] = dp[-1]
    for i in range(n - 2, -1, -1): psi_hat[i] = dp[i] - cp_[i] * psi_hat[i + 1]
    psi_hat[:, 0, 0] -= psi_hat[:, 0, 0].mean()
    psi = G.zeros("cell"); psi[g:g + n, g:g + P, g:g + Z] = xp.asarray(np.real(np.fft.ifft2(psi_hat, axes=(1, 2))).astype(G.dtype))
    fill_psi(G, psi)
    grad_correct(G, Br, Bphi, Bz, psi, 1.0, FIX_R_LO | FIX_R_HI, backend)
    after = monitor(G, Br, Bphi, Bz, backend)
    return dict(before=before["max_norm"], after=after["max_norm"], irreducible_total_net_flux=total_net)
