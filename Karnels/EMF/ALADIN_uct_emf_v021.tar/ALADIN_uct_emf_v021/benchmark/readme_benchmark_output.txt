kernel hashes: UCT_CURL file e7b25907f2d4 | UCT-EMF 341ebaf6c267 | EGLM d4753fd84a07 | HLLD 16f555aea331 | PRIM 1557231bd1c4 | RESIDUAL 51a243e9038e

grid 16x8x4 (axis grid, r in [0,1]):
  B_phi = 0.5 r          : set on the CT faces
  PRIM: conserved -> p   : max |p - (P0 - r^2/4)| = 1.1e-16, max |v| = 0.0e+00, flagged cells 0 (bound <= 1.1e-15)
  J_z = 1                : max |J_z - 1| = 4.4e-16   (J_r, J_phi max 0.0e+00)
  f_r = -0.5 r           : max |f_r + 0.5 r| = 2.2e-16   (f_phi, f_z max 0.0e+00)
  div B = 0              : max |div B| = 0.0e+00
  P = P0 - r^2/4         : max |P_face - exact| = 1.1e-16   (HLLD mass flux 0.0e+00, energy flux 0.0e+00: static)
  dP/dr = -0.5 r         : max |dP/dr + 0.5 r| = 1.8e-15
  force balance dP/dr - f_r = 1.9e-15
  RESIDUAL dU/dt         : d(m_r)/dt - dr^2/(32 r_c) = 2.0e-15 (truncation, max 3.9e-03); rho, m_phi, m_z, E: 0.0e+00; well-balanced: max |dU| = 0.0e+00

grid 64x32x8 (axis grid, r in [0,1]):
  B_phi = 0.5 r          : set on the CT faces
  PRIM: conserved -> p   : max |p - (P0 - r^2/4)| = 1.1e-16, max |v| = 0.0e+00, flagged cells 0 (bound <= 1.1e-15)
  J_z = 1                : max |J_z - 1| = 2.0e-15   (J_r, J_phi max 0.0e+00)
  f_r = -0.5 r           : max |f_r + 0.5 r| = 1.0e-15   (f_phi, f_z max 0.0e+00)
  div B = 0              : max |div B| = 0.0e+00
  P = P0 - r^2/4         : max |P_face - exact| = 1.1e-16   (HLLD mass flux 0.0e+00, energy flux 0.0e+00: static)
  dP/dr = -0.5 r         : max |dP/dr + 0.5 r| = 7.1e-15
  force balance dP/dr - f_r = 7.7e-15
  RESIDUAL dU/dt         : d(m_r)/dt - dr^2/(32 r_c) = 8.5e-15 (truncation, max 9.8e-04); rho, m_phi, m_z, E: 0.0e+00; well-balanced: max |dU| = 0.0e+00
