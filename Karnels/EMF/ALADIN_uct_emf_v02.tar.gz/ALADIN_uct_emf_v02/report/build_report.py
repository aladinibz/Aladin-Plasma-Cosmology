# -*- coding: utf-8 -*-
"""Builds report.html for ALADIN UCT-EMF v02 from EMF01_RESULTS.json (every number in the tables comes from the JSON)."""
import json, html, re
R = json.load(open("/home/claude/emf01/EMF01_RESULTS.json"))
LEG = R["legs_verbatim"]; CPU = {t["id"]: t for t in LEG["cpu"]["tests"]}; GPU = {t["id"]: t for t in LEG["gpu"]["tests"]}
SAN = R["sanitizer_verbatim"]; SHA = R["hashes"]["gpu"]["kernel"]; FILES = R["hashes"]["gpu"]["files"]
css = open("/home/claude/gyropdf/report.html").read().split("<style>")[1].split("</style>")[0]
e = html.escape
def f(x, d=2):
    if x == 0: return "0"
    return f"{x:.{d}e}".replace("e-0", "e-").replace("e+0", "e+").replace("e+", "e")
def chk(t, i): return t["checks"][i]["measured"]

TITLES = dict(
    C01=("Upwind (donor) limit", "supersonic quadrant states around one z-edge, 4 flow-sign combinations: UCT must return exactly the upstream corner EMF"),
    C02=("Edge EMFs vs independent oracle", "random B, v, J, rho, p; annulus + axis; 7 sizes incl. awkward ones; MC and minmod; eta, Hall on; FP64"),
    C03=("CT Faraday update vs oracle", "random faces and edge EMFs; every face incl. ghosts"),
    C04=("Lorentz force J × B vs oracle", "random B and J, interior cells"),
    C05=("FP32 kernel vs FP64 oracle", "same FP32-rounded inputs, annulus + axis"),
    C06=("div B, random field (robustness)", "grid-scale random div-free B, random v, 2000 steps, FP64 + FP32"),
    C07=("div B, smooth evolving 3-D field", "resolved B, compressive 3-D flow, T = 2, RK2 CFL 0.4; B must change substantially"),
    C08=("Field-loop rotation (annulus)", "Gaussian loop, rigid rotation, quarter turn; refinement"),
    C09=("Field loop translated across the axis", "full disk, reflected axis ghosts, T = 1; refinement"),
    C10=("Resistive decay with J from UCT_CURL", "Bphi = J1(kr), eta = 0.05, exact decay; MC and minmod"),
    C11=("Whistler wave (Hall, dynamic)", "exact nonlinear helical Hall-MHD wave, J from UCT_CURL each stage; refinement"),
    C12=("Static Z-pinch equilibrium drift", "v = 0, eta = 0, T = 10: numerical diffusion of a static curved field"),
    C13=("Z-pinch J × B and Hall arithmetic", "Bphi = 0.5 r (f_r exact); uniform fields (E_Hall exact)"),
    C14=("Axis single-valuedness", "Ez on the axis edge must be one value for all phi"),
    C15=("Shift covariance", "inputs rolled in phi and z: outputs roll identically"),
    C16=("Extreme parameters", "beta 1e-8..1e4, |B| 1e-6..1e3, rho contrast 1e6, |v| x100, eta = hall = 10"),
    C17=("Exact nulls", "B = J = 0 gives E = 0; v = J = 0 with uniform Bz gives E = 0"),
    G1=("GPU vs CPU backend", "EMF, CT and force on all sizes incl. partial 128-thread blocks; FP64 + FP32"),
    G2=("GPU vs oracle", "C02 run through the CUDA backend"),
    G3=("GPU determinism", "three launches, identical inputs: bitwise identical"))

def pill(c):
    k = {"VERIFIED": "", "LIMITATION": "gold", "BLOCKER": "red", "INCONCLUSIVE": "navy"}[c]
    return f'<span class="pill {k}">{c}</span>'

def checks_txt(t):
    return "<br>".join(f"{e(c['name'])}: <b>{f(c['measured'])}</b> {e(c['op'])} {f(c['threshold'],0)}" for c in t["checks"])

rows = []
for i in R["final_class"]:
    if i.startswith("G4") or i.startswith("G5"): continue
    ti, cond = TITLES[i]; c = CPU.get(i); g = GPU.get(i)
    rows.append(f"<tr><td>{i}</td><td><b>{e(ti)}</b><br><span class='note'>{e(cond)}</span></td><td class='mono'>{checks_txt(c) if c else '— (GPU only)'}</td>"
                f"<td class='mono'>{checks_txt(g)}</td><td>{pill(R['final_class'][i])}</td></tr>")
for k, nm in (("G4_memcheck", "compute-sanitizer memcheck"), ("G5_racecheck", "compute-sanitizer racecheck")):
    s = SAN[k]; line = [l for l in s["summary_lines"] if "SUMMARY" in l][-1].replace("=========", "").strip()
    rows.append(f"<tr><td>{k.split('_')[0]}</td><td><b>{nm}</b><br><span class='note'>EMF, CT, force kernels; FP64 + FP32; annulus + axis; partial blocks</span></td>"
                f"<td class='mono'>—</td><td class='mono'>{e(line)}</td><td>{pill(R['final_class'][k])}</td></tr>")
RESULTS_TABLE = "\n".join(rows)

def conv_table(tid, key_n, key_e, label_n):
    rc = CPU[tid]["data"]; rg = GPU[tid]["data"]; out = []
    oc = [None] + rc["orders"]; og = [None] + rg["orders"]
    for j, r in enumerate(rg["rows"]):
        c = rc["rows"][j] if j < len(rc["rows"]) else None
        out.append(f"<tr><td class='num'>{r[key_n]}</td><td class='num'>{r.get('nphi', r.get('grid',''))}</td><td class='num'>{r['steps']}</td>"
                   f"<td class='num'>{f(c[key_e],4) if c else '— (deep, GPU only)'}</td><td class='num'>{'' if c is None or oc[j] is None else f'{oc[j]:.2f}'}</td>"
                   f"<td class='num'>{f(r[key_e],4)}</td><td class='num'>{'' if og[j] is None else f'{og[j]:.2f}'}</td><td class='num'>{f(r['div'],1)}</td></tr>")
    return (f"<table><tr><th>{label_n}</th><th>n&phi; / grid</th><th>steps</th><th>CPU error</th><th>CPU order</th><th>GPU error</th><th>GPU order</th><th>div B</th></tr>"
            + "".join(out) + "</table>")

def c10_table():
    out = []
    for lim in ("mc", "minmod"):
        rr = GPU["C10"]["data"]["results"][lim]; o = [None] + rr["orders"]
        for j, r in enumerate(rr["rows"]):
            out.append(f"<tr><td>{lim}</td><td class='num'>{r['nr']}</td><td class='num'>{r['steps']}</td><td class='num'>{f(r['rel_l1'],4)}</td>"
                       f"<td class='num'>{'' if o[j] is None else f'{o[j]:.2f}'}</td><td class='num'>{r['decay_measured']:.5f}</td><td class='num'>{r['decay_exact']:.5f}</td></tr>")
    return "<table><tr><th>limiter</th><th>nr</th><th>steps</th><th>rel L1</th><th>order</th><th>decay rate</th><th>exact</th></tr>" + "".join(out) + "</table>"

def c12_table():
    out = []
    for lim in ("mc", "minmod"):
        rr = GPU["C12"]["data"]["results"][lim]; o = [None] + GPU["C12"]["data"]["orders"][lim]
        for j, r in enumerate(rr):
            out.append(f"<tr><td>{lim}</td><td class='num'>{r['nr']}</td><td class='num'>{r['steps']}</td><td class='num'>{f(r['drift'],3)}</td><td class='num'>{'' if o[j] is None else f'{o[j]:.2f}'}</td></tr>")
    return "<table><tr><th>limiter</th><th>nr</th><th>steps</th><th>drift at t = 10</th><th>order</th></tr>" + "".join(out) + "</table>"

C07 = GPU["C07"]["data"]["fp64"]; C07c = CPU["C07"]["data"]["fp64"]; C11 = GPU["C11"]["data"]
o8, o9, o11 = GPU["C08"]["data"]["orders"][-1], GPU["C09"]["data"]["orders"][-1], GPU["C11"]["data"]["orders"][-1]
genv, cenv = LEG["gpu"]["env"], LEG["cpu"]["env"]
filerows = "".join(f"<tr><td class='mono'>{k}</td><td class='hash'>{v}</td></tr>" for k, v in FILES.items())
maxdiv = max(chk(GPU[i], [j for j, c in enumerate(GPU[i]["checks"]) if "div" in c["name"]][0]) for i in ("C07", "C08", "C09", "C10", "C11"))
oracle_worst = max(chk(CPU["C02"], 0), chk(GPU["C02"], 0))

body = f"""
<section class="cover">
  <div class="kicker">ALADIN Plasma Cosmology · Kernel · UCT-EMF slot</div>
  <h1>ALADIN UCT-EMF v02</h1>
  <div class="subtitle">Upwind constrained-transport edge EMFs, Faraday update and J × B for the native-cylindrical ALADIN Driver: divergence-free by construction, with an axis that is single-valued and Hall and resistive terms consistent with UCT_CURL. Verified on CPU and GPU against an independent oracle and exact solutions</div>
  <div class="rule"></div>
  <div class="meta">
    <b>Author:</b> Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X<br>
    <b>System:</b> ALADIN native-cylindrical GPU MHD Driver: Z-pinch and J × B research<br>
    <b>Release:</b> UCT-EMF v02 · campaign EMF-01 · 20 November 2026<br>
    <b>Kernel source SHA-256:</b> <span class="hash">{SHA}</span><br>
    <b>Legs:</b> CPU (g++ / OpenMP, FP64 + FP32) and GPU ({e(genv['gpu'])}, CUDA runtime {genv['cuda_runtime']}, CuPy {genv['cupy']}); one CUDA/C++ source for both
  </div>
  <div class="hero">
    <div class="lbl">What the kernel computes on every cell edge</div>
    <div class="eq">E = −v × B + η J + h (J × B) / ρ  &nbsp;·&nbsp;  ∂B/∂t = −∇ × E  &nbsp;·&nbsp;  ∇ · B = 0</div>
    <div class="cap">UCT-HLL edge EMFs (Londrillo &amp; Del Zanna 2004; Del Zanna et al. 2007) with limited reconstruction, an integral-form CT update on the cylindrical staggered grid, and the Lorentz force J × B with J from the verified UCT_CURL v1.3</div>
  </div>
  <div class="cards">
    <div class="card"><div class="big">19 + 1</div><div class="t">20 tests: 19 VERIFIED, 1 LIMITATION by design, 0 BLOCKER, all thresholds predeclared</div></div>
    <div class="card"><div class="big">{f(oracle_worst,1)}</div><div class="t">worst relative difference from the independent NumPy oracle, every edge, every size</div></div>
    <div class="card"><div class="big">{o8:.2f} · {o9:.2f} · {o11:.2f}</div><div class="t">observed orders at the finest level: rotation, translation across the axis, Hall whistler</div></div>
    <div class="card gold"><div class="big">0 · 0</div><div class="t">compute-sanitizer: memcheck errors, racecheck hazards</div></div>
  </div>
  <div class="cover-foot">Every number in this report is generated from EMF01_RESULTS.json, which embeds both campaign legs verbatim (measured values, conditions, thresholds, timings, environments, file hashes) and the sanitizer logs.</div>
</section>

<h2 class="pb">1. What the kernel does</h2>
<p>UCT-EMF is the induction core of the Driver. For the three edge families of the cylindrical staggered grid it computes the electric field and advances the face-centred magnetic field:</p>
<ul>
<li><b>E<sub>z</sub></b> on (r-face, &phi;-face, z-centre), <b>E<sub>r</sub></b> on (r-centre, &phi;-face, z-face), <b>E<sub>&phi;</sub></b> on (r-face, &phi;-centre, z-face).</li>
<li><b>Ideal term −v × B</b> by the UCT-HLL combination. Velocities are reconstructed to the four cells around the edge with a limited linear slope (MC by default, minmod optional), and the face-normal B is reconstructed along the edge's transverse direction. Wave speeds a<sup>±</sup> come from the fast speed; the upwind dissipation terms use the jumps of the reconstructed face fields.</li>
<li><b>Resistive and Hall terms</b> η J + h (J × B)/ρ. Here J is the cell-centred current from UCT_CURL v1.3, the kernel already verified for the Driver, averaged to the edge. The induction equation and the Lorentz force therefore use the same discrete current.</li>
<li><b>Axis.</b> On an axis grid (r<sub>face</sub> = 0) the axis E<sub>z</sub> is one value built from the Cartesian average of the first ring, and E<sub>&phi;</sub> on the axis is its azimuthal projection. Inner ghosts are filled by reflection through r = 0 (n&phi; even).</li>
<li><b>CT Faraday update</b> in integral form (Stokes on every face, with exact cylindrical face areas), plus <b>J × B</b> at cell centres for the momentum equation.</li>
</ul>
<p>A single CUDA/C++ source is compiled by NVRTC for the GPU (CuPy RawModule) and by g++ for the CPU (OpenMP, ctypes), in FP64 or FP32 through one REAL macro. The kernel's grid convention is that of UCT_CURL v1.3: z fastest, two ghost layers, and ghost-extended r<sub>faces</sub> / r<sub>centres</sub>.</p>

<h2>2. Guarantees by construction</h2>
<div class="callout"><b>Divergence-free.</b> The update of each face is minus the circulation of E around that face, and every edge is shared by exactly the faces it bounds. The net flux out of any cell therefore changes by a sum of edge terms that cancel identically, whatever E is. ∇ · B is preserved to round-off, which C06, C07 and every dynamic test confirm: worst normalised div B is {f(maxdiv,1)} in FP64.</div>
<div class="callout"><b>Single-valued axis.</b> All &phi;-edges on the axis carry one E<sub>z</sub> (C14: spread exactly 0). No 1/r singularity is evaluated, and the axis B<sub>r</sub> face (zero area) is never updated.</div>
<div class="callout"><b>Upwind limit.</b> For supersonic flow the HLL weights collapse to the upstream corner, and UCT reproduces the donor-cell EMF exactly (C01: error 0). This is the property the original prototype checks (donor_kernel / donor_corrected) were testing.</div>
<div class="callout"><b>One current.</b> Ohmic and Hall EMFs and the Lorentz force all use the UCT_CURL v1.3 current, so the induction and momentum equations see the same J.</div>

<h2>3. How it was verified</h2>
<ul>
<li><b>Frozen source.</b> The campaign checks the kernel SHA-256 at start; both legs ran the identical hash.</li>
<li><b>Independent oracle.</b> numpy_oracle.py re-implements the edge EMFs, the axis treatment, the CT update and J × B directly from the equations, as vectorised array algebra over whole edge sets. It shares no code with the CUDA/C++ source. It was written by the same development team, so it is independent in implementation, not in authorship.</li>
<li><b>Exact solutions.</b> Upwind limit, rigid rotation, translation across the axis, Bessel resistive decay and an exact nonlinear whistler. Faces are set from an exact discrete projection (curl of an edge potential), so the reference is exact to round-off.</li>
<li><b>Predeclared thresholds</b>, fixed in campaign_emf01.py before either leg ran. Classes: VERIFIED (all thresholds met), LIMITATION (the test quantifies a documented method limit and its bound is met), INCONCLUSIVE, BLOCKER.</li>
<li><b>Two legs.</b> CPU here ({e(cenv['platform'][:40])}, {cenv['cpu_count']} cores); GPU on {e(genv['gpu'])} with <code>--deep</code> (extra refinement levels). The GPU leg runs every C-test through the CUDA backend, plus G1–G3 and compute-sanitizer.</li>
</ul>

<h2 class="pb">4. Results: all tests, both legs</h2>
<table class="camp"><tr><th>ID</th><th>Test and conditions</th><th>CPU leg: measured vs threshold</th><th>GPU leg: measured vs threshold</th><th>Final</th></tr>
{RESULTS_TABLE}
</table>
<p class="note">Final class: BLOCKER if any leg is BLOCKER; LIMITATION if any leg reports the designed limitation; otherwise VERIFIED. C03 is 0 on CPU and 5.8e-16 on GPU: the GPU contracts multiply-adds into FMAs, a round-off-level difference well inside the threshold.</p>

<h2 class="pb">5. Convergence</h2>
<figure><img src="convergence.png"><figcaption>Figure 1. Left: dynamic problems on the GPU leg with the deep refinement levels. Right: axis problems with the current from UCT_CURL at every RK2 stage (C10) and the static Z-pinch drift (C12).</figcaption></figure>
<h3>C08: Gaussian field loop, rigid rotation (annulus [0.5, 1.5], quarter turn, MC)</h3>
{conv_table("C08", "nr", "l1", "nr")}
<h3>C09: field loop translated straight across the axis (disk, n&phi; = 4 nr, T = 1, MC)</h3>
{conv_table("C09", "nr", "l1", "nr")}
<h3>C11: exact nonlinear whistler (Hall coefficient 0.1, B<sub>0</sub> = 1, ε = 0.1, k = 2π, quarter period)</h3>
{conv_table("C11", "nz", "rel_l1", "nz")}
<p>A field that did not rotate would have error {C11['rows'][1]['rel_l1_if_static']:.3f} here. The measured {f(C11['rows'][1]['rel_l1'],3)} at nz = 32 confirms the rotation rate ω = −h k² B<sub>0</sub>/ρ and its direction. The peak Hall E<sub>r</sub> is {C11['rows'][1]['peak_hall_Er']:.4f}, against h k ε B<sub>0</sub> = {C11['analytic_hall_Er_amplitude']:.4f}.</p>
<h3>C10: resistive decay of B<sub>&phi;</sub> = J<sub>1</sub>(kr), J from UCT_CURL each stage (disk, n&phi; = 8)</h3>
{c10_table()}
<p>With MC the order rises with resolution (1.02 → 1.70). The largest error sits near the J<sub>1</sub> extremum, where the limiter clips. A development run to nr = 128 reached 1.87, so this is pre-asymptotic limiter behaviour, not a defect. Minmod is cleanly second order with larger errors.</p>

<h2>6. Answers to the reviewer's pre-freeze questions</h2>
<table><tr><th>Question</th><th>Answer and evidence</th></tr>
<tr><td>Full refinement tables and observed orders for rotation, translation and resistive decay</td><td>Section 5, every level on both legs. Finest-level orders: {o8:.2f} (C08), {o9:.2f} (C09), {GPU['C10']['data']['results']['mc']['orders'][-1]:.2f} MC / {GPU['C10']['data']['results']['minmod']['orders'][-1]:.2f} minmod (C10).</td></tr>
<tr><td>Does the Hall test exercise a genuinely nonzero Hall EMF?</td><td>The development Hall test was arithmetic only: static, with J ≠ curl B. It is kept as C13 and labelled as such. The dynamic test is C11: a travelling whistler driven by the Hall term alone (v = 0, η = 0), with J = curl B from UCT_CURL at every stage. It has a nonzero, time-varying Hall E<sub>r</sub>, E<sub>&phi;</sub> of amplitude {C11['analytic_hall_Er_amplitude']:.3f} and converges at {o11:.2f}.</td></tr>
<tr><td>Does the divergence test use a nontrivial evolving field?</td><td>The development D2 did not: its grid-scale random field decays to 5 % within 100 steps. It is kept as C06 (robustness only). C07 is a smooth resolved 3-D field under a compressive 3-D flow. B changes by {C07['rel_L2_change_of_B']:.2f} in relative L2 norm and the transverse energy grows ×{C07['transverse_energy_ratio']:.1f}, while div B stays at {f(C07['worst_normalised_div'],1)}.</td></tr>
<tr><td>Is the CPU reference independent of the GPU implementation?</td><td>The CPU backend is not: it is the same source by design, and G1 only checks compilation and hardware consistency. Independence comes from numpy_oracle.py (C02–C05, C16, G2), which agrees to {f(oracle_worst,1)}, and from the exact solutions.</td></tr>
<tr><td>MakeReport must preserve all results, hashes, failures and conditions</td><td>EMF01_RESULTS.json embeds both legs verbatim, including any exceptions and per-test timings, the environments, all file hashes and the full sanitizer logs. This report is generated from it.</td></tr></table>

<h2 class="pb">7. Limitations and open regimes</h2>
<h3>Measured limitation (C12)</h3>
<p>The UCT-HLL upwind dissipation (~ c<sub>f</sub> × reconstruction jump) also acts on a <i>static</i> curved field, so a Z-pinch equilibrium at v = 0 drifts slowly although no physical E exists. The drift is a result for this regime, measured and converging:</p>
{c12_table()}
<p>For long equilibrium runs this sets the resolution needed. With MC at nr = 64 the drift is 1.9 × 10⁻⁴ after 10 time units. It is not a stability or conservation issue: div B is 0 throughout.</p>
<h3>Not tested in EMF-01 (open)</h3>
<ul>
<li>Non-uniform radial grids; n&phi; odd on axis grids (not supported: reflection needs n&phi; even).</li>
<li>Physical boundary conditions, which the Driver's BoundaryManager owns. The campaign uses periodic &phi;/z and exact or frozen radial ghosts.</li>
<li>Coupled MHD with the HLLD fluxes, residual and primitive recovery, which belong to the remaining kernels and the Driver campaign. Long nonlinear turbulence.</li>
<li>Explicit Hall stability. C11 uses dt ≤ 0.25 dz²/(π h B<sub>0</sub>); choosing that dispersive-whistler time-step limit is the Driver's responsibility.</li>
<li>Multi-GPU. The kernels are single-device; the launch geometry is a 1-D 128-thread grid over all edges.</li>
</ul>

<h2>8. Development history</h2>
<ul>
<li><b>Prototype (author).</b> aladin_uct_emf_production.py with validation scripts: round1_jxb_validation, confirm_round2, final_emf_checks, and donor_kernel / donor_corrected, which fixed the upstream donor convention. fixed_left_term.py made the r-face left term annulus-safe. The production file was incomplete: placeholder blocks, E<sub>z</sub> only, no CT update.</li>
<li><b>v02.</b> Complete rewrite: all three edge EMFs, UCT-HLL with limited reconstruction, axis treatment, CT update, J × B, a single CPU/GPU source, and the Hall and resistive terms taking J from UCT_CURL v1.3.</li>
<li><b>Development study.</b> Identical results on CPU and on the author's L4. The test-helper divergence norm was changed from per-cell to global normalisation (the per-cell norm reported a spurious 1.0). The first-order D5 result was investigated and found to be pre-asymptotic MC behaviour. D2 was redesigned (C07), and the oracle and whistler were added after the reviewer's questions.</li>
<li><b>No kernel change was needed after the development study.</b> v02 was frozen at the hash above and passed EMF-01 at its first run.</li>
</ul>

<h2>9. Integrity and reproduction</h2>
<table><tr><th>File</th><th>SHA-256 (identical on both legs)</th></tr>{filerows}</table>
<p class="note">Kernel source hash (the CUDA/C++ text inside uct_emf_v02.py): <span class="hash">{SHA}</span>. Environments: CPU leg {e(cenv['utc'])}, Python {cenv['python']}, NumPy {cenv['numpy']}, {e(cenv['gxx'])}. GPU leg {e(genv['utc'])}, {e(genv['gpu'])}, CuPy {genv['cupy']}, NumPy {genv['numpy']}.</p>
<div class="eqblock" style="font-family:'DejaVu Sans Mono',monospace;font-size:9pt;text-align:left">sha256sum -c SHA256SUMS.txt<br>cd code &amp;&amp; python campaign_emf01.py cpu<br>cd code &amp;&amp; python campaign_emf01.py gpu --deep<br>compute-sanitizer --tool memcheck  python sanitizer_target_emf.py<br>compute-sanitizer --tool racecheck python sanitizer_target_emf.py<br>python make_results_emf.py</div>

<h2>10. Plugging into the Driver</h2>
<p><code>compute_emf(G, Br, Bphi, Bz, vr, vphi, vz, rho, p, J, gamma, eta, hall, limiter, backend)</code> returns (E<sub>r</sub>, E<sub>&phi;</sub>, E<sub>z</sub>) on the edges. <code>ct_update(G, Br, Bphi, Bz, Er, Ephi, Ez, dt, backend)</code> advances the faces in place. <code>lorentz_force(G, Br, Bphi, Bz, J, backend)</code> returns J × B at cell centres.</p>
<p>The Driver fills ghosts before each call (periodic &phi;/z and axis reflection are provided as test helpers) and passes J from UCT_CURL whenever η or h is nonzero. For RK stages it calls compute_emf once and ct_update once per stage.</p>
<p class="note">Credits: Mihai Alexandru Bucurenciu (ALADIN): kernel concept, the UCT-EMF prototype and its J × B, donor and left-term validation scripts, and the GPU campaign runs. v02 rewrite, independent oracle, development study, EMF-01 campaign and evidence tooling developed with AI assistance (Claude, Anthropic). The pre-freeze questions on refinement, Hall, divergence, independence and reporting were raised in review by ChatGPT (OpenAI); independent review by a human third party is pending.</p>
<p class="note"><b>AI assistant Team:</b> SuperGrok, Claude, ChatGPT</p>
"""
css += "\n.hero .eq{font-size:14pt} .pill.red{background:#a33b3b} .camp td{font-size:8pt} .camp td.mono{font-size:7.4pt;line-height:1.35}"
open("/home/claude/emfpdf/report.html", "w").write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>ALADIN UCT-EMF v02</title><style>{css}</style></head><body>{body}</body></html>')
print("ok")
