import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
R = json.load(open("/home/claude/emf01/EMF01_RESULTS.json")); T = {t["id"]: t for t in R["legs_verbatim"]["gpu"]["tests"]}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.6))
navy, teal, gold, grey, red = "#13233f", "#0f7d82", "#b8892b", "#5b6475", "#a33b3b"
def series(a, x, y, key_n, key_e, lab, c, m):
    n = np.array([r[key_n] for r in x]); e = np.array([r[key_e] for r in x]); a.loglog(n, e, m + "-", color=c, label=lab, lw=1.6, ms=5); return n, e
n, e = series(ax[0], T["C08"]["data"]["rows"], None, "nr", "l1", "C08 field-loop rotation", navy, "o")
series(ax[0], T["C09"]["data"]["rows"], None, "nr", "l1", "C09 translation across axis", teal, "s")
series(ax[0], T["C11"]["data"]["rows"], None, "nz", "rel_l1", "C11 whistler (Hall)", gold, "^")
ref = np.array([12, 128.]); ax[0].loglog(ref, 0.6 * (ref / 12) ** -2, "--", color=grey, lw=1, label="slope 2")
ax[0].set_xlabel("resolution (nr, or nz for C11)"); ax[0].set_ylabel("relative L1 error"); ax[0].legend(fontsize=7.5, frameon=False); ax[0].grid(alpha=.3, which="both")
ax[0].set_title("Dynamic convergence (GPU leg, --deep)", fontsize=9.5)
for lim, c, m in (("mc", navy, "o"), ("minmod", teal, "s")):
    rows = T["C10"]["data"]["results"][lim]["rows"]; ax[1].loglog([r["nr"] for r in rows], [r["rel_l1"] for r in rows], m + "-", color=c, lw=1.6, ms=5, label=f"C10 resistive decay, {lim}")
    rows = T["C12"]["data"]["results"][lim]; ax[1].loglog([r["nr"] for r in rows], [r["drift"] for r in rows], m + ":", color=c, lw=1.4, ms=5, mfc="white", label=f"C12 Z-pinch drift t=10, {lim}")
ref = np.array([16, 64.]); ax[1].loglog(ref, 3e-2 * (ref / 16) ** -2, "--", color=grey, lw=1, label="slope 2")
ax[1].set_xlabel("nr (disk, nphi = 8)"); ax[1].set_ylabel("relative L1 error / drift"); ax[1].legend(fontsize=7, frameon=False); ax[1].grid(alpha=.3, which="both")
ax[1].set_title("Axis problems with J from UCT_CURL", fontsize=9.5)
from matplotlib.ticker import FixedLocator, NullLocator, FixedFormatter
for a, t in ((ax[0], [12, 16, 24, 32, 48, 64, 96, 128]), (ax[1], [16, 32, 64])):
    a.xaxis.set_major_locator(FixedLocator(t)); a.xaxis.set_major_formatter(FixedFormatter([str(v) for v in t])); a.xaxis.set_minor_locator(NullLocator())
plt.tight_layout(); plt.savefig("convergence.png", dpi=200)
