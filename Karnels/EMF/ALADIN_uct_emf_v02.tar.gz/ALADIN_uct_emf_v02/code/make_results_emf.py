# -*- coding: utf-8 -*-
"""
MakeResults for EMF-01.  Merges the CPU and GPU legs and the compute-sanitizer logs into one bundle WITHOUT dropping
anything: every leg's JSON is embedded verbatim (all measured values, conditions, thresholds, exceptions, timings,
environment and file hashes), plus a cross-leg table and the final per-test class.
  python make_results_emf.py            -> EMF01_RESULTS.json, EMF01_RESULTS.md
Final class per test: BLOCKER if any leg is BLOCKER; else LIMITATION if any leg says so; else VERIFIED if every leg that
ran it is VERIFIED; INCONCLUSIVE if no leg could evaluate it.
"""
import os, re, json, hashlib, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
P = lambda f: os.path.join(HERE, f)


def load(f):
    return json.load(open(P(f))) if os.path.exists(P(f)) else None


def sanitizer(f, pattern):
    if not os.path.exists(P(f)): return dict(file=f, present=False, cls="INCONCLUSIVE")
    txt = open(P(f), errors="replace").read()
    ok = re.search(pattern, txt) is not None and "SANITIZER TARGET DONE" in txt
    summ = [l.strip() for l in txt.splitlines() if "SUMMARY" in l]
    return dict(file=f, present=True, sha256=hashlib.sha256(txt.encode()).hexdigest(), summary_lines=summ, target_completed="SANITIZER TARGET DONE" in txt,
                cls="VERIFIED" if ok else "BLOCKER", log=txt)


def main():
    legs = {k: load(f"emf01_{k}_results.json") for k in ("cpu", "gpu")}
    legs = {k: v for k, v in legs.items() if v is not None}
    san = dict(G4_memcheck=sanitizer("emf01_memcheck.log", r"ERROR SUMMARY: 0 errors"),
               G5_racecheck=sanitizer("emf01_racecheck.log", r"RACECHECK SUMMARY: 0 hazards displayed \(0 errors, 0 warnings\)"))
    ids = []
    for L in legs.values():
        for t in L["tests"]:
            if t["id"] not in ids: ids.append(t["id"])
    final, table = {}, []
    for i in ids:
        per = {k: next((t for t in L["tests"] if t["id"] == i), None) for k, L in legs.items()}
        cl = [t["cls"] for t in per.values() if t is not None]
        ran = [c for c in cl if c != "INCONCLUSIVE"]
        f = "BLOCKER" if "BLOCKER" in cl else "LIMITATION" if "LIMITATION" in ran else "VERIFIED" if ran else "INCONCLUSIVE"
        final[i] = f
        row = dict(id=i, final=f)
        for k, t in per.items():
            row[k] = None if t is None else dict(cls=t["cls"], checks=t.get("checks", []), seconds=t.get("seconds"), exception=t.get("exception"))
        table.append(row)
    for k, s in san.items():
        final[k] = s["cls"]; table.append(dict(id=k, final=s["cls"], sanitizer={x: y for x, y in s.items() if x != "log"}))
    hashes = {k: dict(kernel=L["kernel_source_sha256"], frozen=L["frozen_sha256"], files=L["file_sha256"]) for k, L in legs.items()}
    consistent = len({h["kernel"] for h in hashes.values()}) <= 1 and all(h["kernel"] == h["frozen"] for h in hashes.values())
    counts = {}
    for v in final.values(): counts[v] = counts.get(v, 0) + 1
    out = dict(campaign="EMF-01", kernel="ALADIN UCT-EMF v02", made=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
               source_hash_consistent_and_frozen=consistent, hashes=hashes, final_class=final, final_counts=counts, table=table,
               legs_verbatim=legs, sanitizer_verbatim=san)
    json.dump(out, open(P("EMF01_RESULTS.json"), "w"), indent=1, default=float)

    md = [f"# EMF-01 results: ALADIN UCT-EMF v02", "", f"Made {out['made']}.  Source hash frozen and identical on all legs: **{consistent}**", ""]
    for k, h in hashes.items(): md.append(f"- {k} leg kernel sha256 `{h['kernel']}`")
    md += ["", "| Test | Final | " + " | ".join(legs) + " |", "|---|---|" + "---|" * len(legs)]
    for r in table:
        if "sanitizer" in r:
            md.append(f"| {r['id']} | {r['final']} | " + " | ".join("" for _ in legs) + " |"); continue
        md.append(f"| {r['id']} | {r['final']} | " + " | ".join("—" if r[k] is None else r[k]["cls"] for k in legs) + " |")
    md += ["", f"Counts: {counts}", "", "## Checks (measured vs predeclared threshold)", ""]
    for r in table:
        for k in legs:
            t = r.get(k)
            if not t: continue
            for c in t["checks"]:
                md.append(f"- {r['id']} [{k}] {c['name']}: {c['measured']:.4e} {c['op']} {c['threshold']:.1e} -> {'pass' if c['passed'] else 'FAIL'}")
            if t.get("exception"): md.append(f"- {r['id']} [{k}] EXCEPTION:\n```\n{t['exception']}\n```")
    for k, s in san.items(): md.append(f"- {k}: {s['cls']} " + "; ".join(s.get("summary_lines", [])))
    open(P("EMF01_RESULTS.md"), "w").write("\n".join(md) + "\n")
    print("\n".join(md[:len(table) + 8])); print("counts", counts)


if __name__ == "__main__":
    main()
