# -*- coding: utf-8 -*-
"""Small GPU workload for compute-sanitizer (memcheck / racecheck): EMF, CT and force kernels, FP64 and FP32,
annulus and axis grids, sizes that leave partial 128-thread blocks."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cupy as cp, uct_emf_v02 as E
rng = np.random.default_rng(5)
for dt_ in (np.float64, np.float32):
    for rmin, (nr, nphi, nz) in ((0.4, (7, 10, 5)), (0.0, (13, 18, 11)), (0.0, (1, 4, 2)), (0.4, (31, 6, 9))):
        G = E.Grid(nr, nphi, nz, rmin, 1.3, dtype=dt_, xp=cp)
        B = [cp.asarray(rng.normal(size=G.shape(k)).astype(dt_)) for k in ("Br", "Bphi", "Bz")]
        c = [cp.asarray(rng.normal(size=G.shape("cell")).astype(dt_)) for _ in range(6)]
        rho = cp.asarray(rng.uniform(0.5, 2, G.shape("cell")).astype(dt_)); p = cp.asarray(rng.uniform(0.5, 2, G.shape("cell")).astype(dt_))
        for lim in ("mc", "minmod"):
            Em = E.compute_emf(G, *B, *c[:3], rho, p, J=c[3:], eta=0.02, hall=0.3, limiter=lim, backend="cupy")
            E.ct_update(G, *B, *Em, 1e-3, backend="cupy")
        f = E.lorentz_force(G, *B, c[3:], backend="cupy")
        cp.cuda.Device().synchronize()
        print(np.dtype(dt_).name, rmin, (nr, nphi, nz), "finite", bool(all(bool(cp.isfinite(x).all()) for x in (*Em, *B, *f))), flush=True)
print("SANITIZER TARGET DONE")
