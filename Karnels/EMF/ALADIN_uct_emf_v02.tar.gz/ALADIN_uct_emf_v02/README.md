# ALADIN UCT-EMF v02

Upwind constrained-transport (UCT-HLL) edge EMFs, the CT Faraday update and the J × B force for the native-cylindrical ALADIN GPU MHD Driver.

- **Author:** Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X
- **Kernel source SHA-256:** `707c4d9ab723109bfca9b543a0956f69f7534367f905eda2cae8adad8b1b296d`
- **Campaign:** EMF-01. 20 tests plus compute-sanitizer: 19 VERIFIED, 1 LIMITATION (by design: C12, numerical diffusion of a static Z-pinch equilibrium, converging at 2nd order), 0 BLOCKER. Memcheck 0 errors, racecheck 0 hazards.
- **Legs:** CPU (g++/OpenMP) and GPU (NVIDIA L4, CuPy 14), FP64 and FP32. One CUDA/C++ source serves both.

## Contents
- `code/`: kernel (`uct_emf_v02.py`), independent NumPy oracle, test drivers, the UCT_CURL v1.3 dependency, the campaign, the sanitizer target and MakeResults.
- `results/`: both campaign legs verbatim (JSON and log), sanitizer logs, the merged `EMF01_RESULTS.json` / `.md`, and the development-study results.
- `report/`: the verification report PDF, plus its HTML, figure and generators (built from `EMF01_RESULTS.json`).
- `predecessor/`: the author's original prototype and validation scripts.

## Reproduce
```
sha256sum -c SHA256SUMS.txt
cd code
python campaign_emf01.py cpu
python campaign_emf01.py gpu --deep
compute-sanitizer --tool memcheck  python sanitizer_target_emf.py > emf01_memcheck.log 2>&1
compute-sanitizer --tool racecheck python sanitizer_target_emf.py > emf01_racecheck.log 2>&1
python make_results_emf.py
```

AI assistant Team: SuperGrok, Claude, ChatGPT
