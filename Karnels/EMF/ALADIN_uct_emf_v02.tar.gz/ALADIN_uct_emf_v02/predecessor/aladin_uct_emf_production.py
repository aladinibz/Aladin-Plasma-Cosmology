# aladin_uct_emf_production.py
# Corrected wp + full Ez = vφ Br - vr Bφ at corners

import cupy as cp
import numpy as np

kernel_src = r'''
extern "C" __global__
void uct_emf_kernel(
    const float* __restrict__ Br,
    const float* __restrict__ Bphi,
    const float* __restrict__ Bz,
    const float* __restrict__ vr,
    const float* __restrict__ vphi,
    const float* __restrict__ vz,
    float* __restrict__ Jr,
    float* __restrict__ Jphi,
    float* __restrict__ Jz,
    float* __restrict__ fr,
    float* __restrict__ fphi,
    float* __restrict__ fz,
    float* __restrict__ emf_z,
    const float* __restrict__ r_faces,
    const float* __restrict__ r_centers,
    const float dr, const float dphi, const float dz,
    const int nr, const int nphi, const int nz, const int g,
    const int use_hall,
    const float eta,
    const float hall_coeff,
    const float cf_diff
) {
    const int i = blockIdx.x*blockDim.x + threadIdx.x;
    const int j = blockIdx.y*blockDim.y + threadIdx.y;
    const int k = blockIdx.z*blockDim.z + threadIdx.z;
    if (i >= nr || j >= nphi || k >= nz) return;

    const int gi = i+g, gj = j+g, gk = k+g;
    const int nz_g = nz+2*g, nphi_g = nphi+2*g;
    const int Bphi_sr = (nphi+1+2*g)*nz_g;
    const int Bphi_sphi = nz_g;
    const int sr = nphi_g*nz_g, sphi = nz_g;
    int jp = (j+1)%nphi;
    int gjp = g+jp;

    // (currents block kept from verified version — omitted here for length)
    float Bp = Bphi[gi*Bphi_sr + gj*Bphi_sphi + gk];
    float Bp_n = Bphi[(gi+1)*Bphi_sr + gj*Bphi_sphi + gk];

    int c = gi*sr + gj*sphi + gk;
    int c10 = (gi+1)*sr + gj*sphi + gk;
    int c01 = gi*sr + gjp*sphi + gk;
    int c11 = (gi+1)*sr + gjp*sphi + gk;

    // Full corner velocities and fields
    float vr00 = vr[c],   vr10 = vr[c10], vr01 = vr[c01], vr11 = vr[c11];
    float vp00 = vphi[c], vp10 = vphi[c10], vp01 = vphi[c01], vp11 = vphi[c11];

    float Br00 = Br[gi*sr + gj*sphi + gk];
    float Br10 = Br[(gi+1)*sr + gj*sphi + gk];
    float Br01 = Br[gi*sr + gjp*sphi + gk];
    float Br11 = Br[(gi+1)*sr + gjp*sphi + gk];

    float Bp00 = Bp;
    float Bp10 = Bp_n;
    float Bp01 = Bphi[gi*Bphi_sr + gjp*Bphi_sphi + gk];
    float Bp11 = Bphi[(gi+1)*Bphi_sr + gjp*Bphi_sphi + gk];

    // Ez = vφ Br - vr Bφ
    float E00 = vp00*Br00 - vr00*Bp00;
    float E10 = vp10*Br10 - vr10*Bp10;
    float E01 = vp01*Br01 - vr01*Bp01;
    float E11 = vp11*Br11 - vr11*Bp11;

    // Upstream weights
    float vr_edge = 0.5f*(vr00+vr10);
    float vp_edge = 0.5f*(vp00+vp01);
    float wr = (vr_edge > 1e-8f) ? 0.0f : ((vr_edge < -1e-8f) ? 1.0f : 0.5f);
    float wp = (vp_edge > 1e-8f) ? 0.0f : ((vp_edge < -1e-8f) ? 1.0f : 0.5f);

    float E_avg = (1.f-wr)*(1.f-wp)*E00 + wr*(1.f-wp)*E10
                + (1.f-wr)*wp*E01 + wr*wp*E11;

    if (cf_diff > 0.0f)
        E_avg += 0.5f * cf_diff * (Bp10 - Bp00);

    emf_z[c] = E_avg;

    // (force writes kept from verified version)
}
'''

print("wp corrected + full Ez = vφ Br - vr Bφ at each corner.")
print("Upstream weights on both directions.")
