# round1_jxb_validation.py
# ALADIN uct_emf – Round 1: J×B force operator validation

import cupy as cp
import numpy as np

kernel_src = r'''
extern "C" __global__
void uct_emf_kernel(
    const float* __restrict__ Br,
    const float* __restrict__ Bphi,
    const float* __restrict__ Bz,
    float* __restrict__ Jr,
    float* __restrict__ Jphi,
    float* __restrict__ Jz_out,
    float* __restrict__ fr,
    float* __restrict__ fphi,
    float* __restrict__ fz,
    const float* __restrict__ r_faces,
    const float* __restrict__ r_centers,
    const float dr,
    const int nr, const int nphi, const int nz, const int g
) {
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    const int j = blockIdx.y * blockDim.y + threadIdx.y;
    const int k = blockIdx.z * blockDim.z + threadIdx.z;
    if (i >= nr || j >= nphi || k >= nz) return;

    const int gi = i + g, gj = j + g, gk = k + g;
    const int nz_g = nz + 2*g;
    const int nphi_g = nphi + 2*g;
    const int Bphi_sr = (nphi + 1 + 2*g) * nz_g;
    const int Bphi_sphi = nz_g;
    const int c_sr = nphi_g * nz_g;
    const int c_sphi = nz_g;

    const float rc = r_centers[i];
    const float inv_rc = (rc > 1e-8f) ? 1.0f/rc : 0.0f;
    const float rf_l = r_faces[i];
    const float rf_r = r_faces[i+1];
    const float inv_dr = 1.0f / dr;

    float Bp = Bphi[gi*Bphi_sr + gj*Bphi_sphi + gk];
    float Bp_n = Bphi[(gi+1)*Bphi_sr + gj*Bphi_sphi + gk];
    float rB_r = rf_r * 0.5f * (Bp + Bp_n);
    float rB_l = 0.0f;
    if (i > 0) {
        float Bp_p = Bphi[(gi-1)*Bphi_sr + gj*Bphi_sphi + gk];
        rB_l = rf_l * 0.5f * (Bp_p + Bp);
    }
    float jz_val = inv_rc * (rB_r - rB_l) * inv_dr;

    int c = gi*c_sr + gj*c_sphi + gk;
    Jr[c] = 0.0f;
    Jphi[c] = 0.0f;
    Jz_out[c] = jz_val;
    fr[c] = -jz_val * Bp;
    fphi[c] = 0.0f;
    fz[c] = 0.0f;
}
'''
kern = cp.RawKernel(kernel_src, 'uct_emf_kernel')

def launch(Br, Bphi, Bz, Jr, Jphi, Jz, fr, fphi, fz, r_faces, r_centers, dr, nr, nphi, nz, g):
    threads = (8, 8, 4)
    blocks = ((nr+7)//8, (nphi+7)//8, (nz+3)//4)
    kern(blocks, threads, (
        Br, Bphi, Bz, Jr, Jphi, Jz, fr, fphi, fz,
        r_faces, r_centers, np.float32(dr),
        np.int32(nr), np.int32(nphi), np.int32(nz), np.int32(g)
    ))
    cp.cuda.Stream.null.synchronize()

def set_zpinch_B(Bphi, r_centers, nr, nphi, nz, g, dr):
    for ii in range(Bphi.shape[0]):
        cell = ii - g
        if 0 <= cell < nr:
            rval = float(r_centers[cell])
        elif cell < 0:
            rval = float(r_centers[0]) + cell * dr
        else:
            rval = float(r_centers[-1]) + (cell - nr + 1) * dr
        Bphi[ii, g:g+nphi, g:g+nz] = np.float32(0.5 * rval)

print("=" * 60)
print("ROUND 1 — J×B VALIDATION")
print("=" * 60)
all_pass = True
g = 2

# 1. Six-output write check
print("\n[1] Six-output write check (NaN → finite)")
nr, nphi, nz = 16, 8, 4
dr = 1.0 / nr
r_faces = cp.linspace(0, 1, nr+1, dtype=cp.float32)
r_centers = 0.5 * (r_faces[:-1] + r_faces[1:])
shape_c = (nr+2*g, nphi+2*g, nz+2*g)
Br = cp.zeros((nr+1+2*g, nphi+2*g, nz+2*g), dtype=cp.float32)
Bphi = cp.zeros((nr+2*g, nphi+1+2*g, nz+2*g), dtype=cp.float32)
Bz = cp.zeros((nr+2*g, nphi+2*g, nz+1+2*g), dtype=cp.float32)
Jr, Jphi, Jz, fr, fphi, fz = [cp.full(shape_c, cp.nan, dtype=cp.float32) for _ in range(6)]
set_zpinch_B(Bphi, r_centers, nr, nphi, nz, g, dr)
launch(Br, Bphi, Bz, Jr, Jphi, Jz, fr, fphi, fz, r_faces, r_centers, dr, nr, nphi, nz, g)
finite_ok = all(cp.all(cp.isfinite(a[g:g+nr, g:g+nphi, g:g+nz])) for a in [Jr, Jphi, Jz, fr, fphi, fz])
print("  PASS" if finite_ok else "  FAIL")
all_pass &= finite_ok

# 2. Zero field
print("\n[2] Zero field (17×11×9)")
nr, nphi, nz = 17, 11, 9
dr = 1.0 / nr
r_faces = cp.linspace(0, 1, nr+1, dtype=cp.float32)
r_centers = 0.5 * (r_faces[:-1] + r_faces[1:])
shape_c = (nr+2*g, nphi+2*g, nz+2*g)
Br = cp.zeros((nr+1+2*g, nphi+2*g, nz+2*g), dtype=cp.float32)
Bphi = cp.zeros((nr+2*g, nphi+1+2*g, nz+2*g), dtype=cp.float32)
Bz = cp.zeros((nr+2*g, nphi+2*g, nz+1+2*g), dtype=cp.float32)
Jr, Jphi, Jz, fr, fphi, fz = [cp.zeros(shape_c, dtype=cp.float32) for _ in range(6)]
launch(Br, Bphi, Bz, Jr, Jphi, Jz, fr, fphi, fz, r_faces, r_centers, dr, nr, nphi, nz, g)
zero_ok = all(float(cp.max(cp.abs(a[g:g+nr, g:g+nphi, g:g+nz]))) < 1e-12 for a in [Jr, Jphi, Jz, fr, fphi, fz])
print("  PASS" if zero_ok else "  FAIL")
all_pass &= zero_ok

# 3 & 4. Z-pinch grids
def run_zpinch(nr, nphi, nz, label):
    print(f"\n[Z-pinch] {label} ({nr}×{nphi}×{nz})")
    dr = 1.0 / nr
    r_faces = cp.linspace(0, 1, nr+1, dtype=cp.float32)
    r_centers = 0.5 * (r_faces[:-1] + r_faces[1:])
    shape_c = (nr+2*g, nphi+2*g, nz+2*g)
    Br = cp.zeros((nr+1+2*g, nphi+2*g, nz+2*g), dtype=cp.float32)
    Bphi = cp.zeros((nr+2*g, nphi+1+2*g, nz+2*g), dtype=cp.float32)
    Bz = cp.zeros((nr+2*g, nphi+2*g, nz+1+2*g), dtype=cp.float32)
    Jr, Jphi, Jz, fr, fphi, fz = [cp.zeros(shape_c, dtype=cp.float32) for _ in range(6)]
    r_faces_save = r_faces.copy()
    r_centers_save = r_centers.copy()
    set_zpinch_B(Bphi, r_centers, nr, nphi, nz, g, dr)
    launch(Br, Bphi, Bz, Jr, Jphi, Jz, fr, fphi, fz, r_faces, r_centers, dr, nr, nphi, nz, g)

    Jz_i = Jz[g:g+nr, g:g+nphi, g:g+nz]
    fr_i = fr[g:g+nr, g:g+nphi, g:g+nz]
    err_Jz = float(cp.max(cp.abs(Jz_i - 1.0)))
    err_fr = float(cp.max(cp.abs(fr_i + 0.5 * r_centers.reshape(-1, 1, 1))))
    err_trans = max(
        float(cp.max(cp.abs(Jr[g:g+nr, g:g+nphi, g:g+nz]))),
        float(cp.max(cp.abs(Jphi[g:g+nr, g:g+nphi, g:g+nz]))),
        float(cp.max(cp.abs(fphi[g:g+nr, g:g+nphi, g:g+nz]))),
        float(cp.max(cp.abs(fz[g:g+nr, g:g+nphi, g:g+nz])))
    )
    first_fr = float(fr[g, g, g])
    last_fr = float(fr[g+nr-1, g, g])
    inputs_unchanged = cp.allclose(r_faces, r_faces_save) and cp.allclose(r_centers, r_centers_save)
    print(f"  |Jz-1| = {err_Jz:.2e}")
    print(f"  |fr err| = {err_fr:.2e}")
    print(f"  transverse = {err_trans:.2e}")
    print(f"  first fr = {first_fr:.7f}  (expect {-0.5*float(r_centers[0]):.7f})")
    print(f"  last  fr = {last_fr:.7f}  (expect {-0.5*float(r_centers[-1]):.7f})")
    print(f"  inputs unchanged: {inputs_unchanged}")
    ok = err_Jz < 1e-5 and err_fr < 1e-5 and err_trans < 1e-5 and inputs_unchanged
    print("  PASS" if ok else "  FAIL")
    return ok

all_pass &= run_zpinch(32, 8, 4, "standard")
all_pass &= run_zpinch(17, 11, 9, "awkward")

print("\n" + "=" * 60)
print("ROUND 1:", "ALL PASS" if all_pass else "FAILED")
print("=" * 60)
