# fixed_left_term.py
# rB_left uses inner ghost unless the face is truly at r=0

import cupy as cp
import numpy as np

kernel_src = r'''
extern "C" __global__
void uct_emf_kernel(
    const float* __restrict__ Br,
    const float* __restrict__ Bphi,
    float* __restrict__ Jz,
    const float* __restrict__ r_faces,
    const float* __restrict__ r_centers,
    const float dr, const float dphi,
    const int nr, const int nphi, const int nz, const int g
) {
    const int i = blockIdx.x*blockDim.x+threadIdx.x;
    const int j = blockIdx.y*blockDim.y+threadIdx.y;
    const int k = blockIdx.z*blockDim.z+threadIdx.z;
    if (i>=nr||j>=nphi||k>=nz) return;
    const int gi=i+g, gj=j+g, gk=k+g;
    const int nz_g=nz+2*g;
    const int Bphi_sr=(nphi+1+2*g)*nz_g;
    const int Bphi_sphi=nz_g;
    const int Br_sr=(nphi+2*g)*nz_g;
    const int Br_sphi=nz_g;
    const int c_sr=(nphi+2*g)*nz_g;
    const int c_sphi=nz_g;
    const float inv_rc=(r_centers[i]>1e-8f)?1.f/r_centers[i]:0.f;
    const float inv_dr=1.f/dr, inv_dphi=1.f/dphi;
    int jp=(j+1)%nphi, jm=(j-1+nphi)%nphi;

    float Bp=Bphi[gi*Bphi_sr+gj*Bphi_sphi+gk];
    float Bp_n=Bphi[(gi+1)*Bphi_sr+gj*Bphi_sphi+gk];
    float Bp_p=Bphi[(gi-1)*Bphi_sr+gj*Bphi_sphi+gk];   // always read ghost
    float rB_r = r_faces[i+1]*0.5f*(Bp+Bp_n);
    // only zero when the face is truly at the axis
    float rB_l = (r_faces[i] > 1e-8f) ? r_faces[i]*0.5f*(Bp_p+Bp) : 0.f;
    float Tr = inv_rc*(rB_r - rB_l)*inv_dr;

    float Br_jp=Br[gi*Br_sr+(g+jp)*Br_sphi+gk];
    float Br_jm=Br[gi*Br_sr+(g+jm)*Br_sphi+gk];
    float Tphi=inv_rc*(Br_jp-Br_jm)*0.5f*inv_dphi;

    Jz[gi*c_sr+gj*c_sphi+gk] = Tr - Tphi;
}
'''
kern = cp.RawKernel(kernel_src, 'uct_emf_kernel')

def test(nphi, nr=32, nz=4):
    g=2
    rmin,rmax=0.5,1.5
    dr=(rmax-rmin)/nr
    dphi=2*np.pi/nphi
    r_faces=np.linspace(rmin,rmax,nr+1,dtype=np.float32)
    r_centers=0.5*(r_faces[:-1]+r_faces[1:])
    phi=(np.arange(nphi)+0.5)*dphi
    Br=np.zeros((nr+2*g,nphi+2*g,nz+2*g),np.float32)
    Bphi=np.zeros((nr+2*g,nphi+1+2*g,nz+2*g),np.float32)
    for ii in range(nr+2*g):
        cell=ii-g
        r=r_centers[cell] if 0<=cell<nr else (r_centers[0]+cell*dr if cell<0 else r_centers[-1]+(cell-nr+1)*dr)
        for j in range(nphi):
            Br[ii,j+g,g:g+nz]=r*np.sin(phi[j])*np.cos(phi[j])
            Bphi[ii,j+g,g:g+nz]=-r*np.sin(phi[j])**2
    Jz=cp.zeros((nr+2*g,nphi+2*g,nz+2*g),np.float32)
    blocks=((nr+7)//8,(nphi+7)//8,(nz+3)//4)
    kern(blocks,(8,8,4),(cp.asarray(Br),cp.asarray(Bphi),Jz,
                         cp.asarray(r_faces),cp.asarray(r_centers),
                         np.float32(dr),np.float32(dphi),
                         np.int32(nr),np.int32(nphi),np.int32(nz),np.int32(g)))
    cp.cuda.Stream.null.synchronize()
    err=float(cp.max(cp.abs(Jz[g:g+nr,g:g+nphi,g:g+nz]+1)))
    print(f"nphi={nphi:3d}   max|Jz+1| = {err:.3e}")

print("Fixed left term (annulus-safe)")
test(64)
test(128)
