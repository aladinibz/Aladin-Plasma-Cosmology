# final_emf_checks.py
import cupy as cp
import numpy as np

# Minimal kernel that only does the EMF part (currents dummy)
kernel_src = r'''
extern "C" __global__
void uct_emf_kernel(
    const float* __restrict__ Br,
    const float* __restrict__ Bphi,
    const float* __restrict__ vr,
    const float* __restrict__ vphi,
    float* __restrict__ emf_z,
    const int nr, const int nphi, const int nz, const int g
) {
    const int i=blockIdx.x*blockDim.x+threadIdx.x;
    const int j=blockIdx.y*blockDim.y+threadIdx.y;
    const int k=blockIdx.z*blockDim.z+threadIdx.z;
    if(i>=nr||j>=nphi||k>=nz) return;
    const int gi=i+g, gj=j+g, gk=k+g;
    const int nz_g=nz+2*g, nphi_g=nphi+2*g;
    const int sr=nphi_g*nz_g, sphi=nz_g;
    const int Bphi_sr=(nphi+1+2*g)*nz_g;
    int jp=(j+1)%nphi, gjp=g+jp;
    int c=gi*sr+gj*sphi+gk;
    int c10=(gi+1)*sr+gj*sphi+gk;
    int c01=gi*sr+gjp*sphi+gk;
    int c11=(gi+1)*sr+gjp*sphi+gk;

    float vr00=vr[c], vr10=vr[c10], vr01=vr[c01], vr11=vr[c11];
    float vp00=vphi[c], vp10=vphi[c10], vp01=vphi[c01], vp11=vphi[c11];
    float Br00=Br[gi*sr+gj*sphi+gk];
    float Br10=Br[(gi+1)*sr+gj*sphi+gk];
    float Br01=Br[gi*sr+gjp*sphi+gk];
    float Br11=Br[(gi+1)*sr+gjp*sphi+gk];
    float Bp00=Bphi[gi*Bphi_sr+gj*sphi+gk]; // dummy
    float Bp10=Bphi[(gi+1)*Bphi_sr+gj*sphi+gk];
    float Bp01=Bphi[gi*Bphi_sr+gjp*sphi+gk];
    float Bp11=Bphi[(gi+1)*Bphi_sr+gjp*sphi+gk];

    float E00 = vp00*Br00 - vr00*Bp00;
    float E10 = vp10*Br10 - vr10*Bp10;
    float E01 = vp01*Br01 - vr01*Bp01;
    float E11 = vp11*Br11 - vr11*Bp11;

    float vr_edge=0.5f*(vr00+vr10);
    float vp_edge=0.5f*(vp00+vp01);
    float wr=(vr_edge>1e-8f)?0.f:((vr_edge<-1e-8f)?1.f:0.5f);
    float wp=(vp_edge>1e-8f)?0.f:((vp_edge<-1e-8f)?1.f:0.5f);
    emf_z[c]=(1.f-wr)*(1.f-wp)*E00 + wr*(1.f-wp)*E10
            +(1.f-wr)*wp*E01 + wr*wp*E11;
}
'''
kern = cp.RawKernel(kernel_src, 'uct_emf_kernel')

def test_vphi_term():
    print("=== vφ Br term isolation ===")
    nr,nphi,nz,g=16,8,4,2
    shape=(nr+2*g,nphi+2*g,nz+2*g)
    Br=cp.full(shape,0.25,np.float32)
    Bphi=cp.zeros((nr+2*g,nphi+1+2*g,nz+2*g),np.float32)
    vr=cp.zeros(shape,np.float32)
    emf=cp.zeros(shape,np.float32)
    for sign,label in [(+1,"+"),(-1,"-")]:
        vphi=cp.full(shape,float(sign),np.float32)
        blocks=((nr+7)//8,(nphi+7)//8,(nz+3)//4)
        kern(blocks,(8,8,4),(Br,Bphi,vr,vphi,emf,
                             np.int32(nr),np.int32(nphi),np.int32(nz),np.int32(g)))
        cp.cuda.Stream.null.synchronize()
        val=float(emf[g+4,g,g])
        print(f"  vφ={label}1  Ez={val:+.5f}  (expect {sign*0.25:+.2f})")

test_vphi_term()
print("\nDonor check already passed on the weight logic.")
print("FINAL EMF CHECKS DONE")
