# donor_corrected.py
# Corrected φ weight + expected donors 1,3,2,4

import cupy as cp

kernel_src = r'''
extern "C" __global__
void donor_kernel(
    const float* __restrict__ vr,
    const float* __restrict__ vphi,
    const float* __restrict__ Ecorners,
    float* __restrict__ emf_out
) {
    if (threadIdx.x|blockIdx.x) return;
    float vr_e = vr[0];
    float vp_e = vphi[0];
    // upstream convention (positive flow selects lower index)
    float wr = (vr_e > 1e-8f) ? 0.0f : ((vr_e < -1e-8f) ? 1.0f : 0.5f);
    float wp = (vp_e > 1e-8f) ? 0.0f : ((vp_e < -1e-8f) ? 1.0f : 0.5f);
    float E00=Ecorners[0], E10=Ecorners[1], E01=Ecorners[2], E11=Ecorners[3];
    emf_out[0] = (1.f-wr)*(1.f-wp)*E00 + wr*(1.f-wp)*E10
               + (1.f-wr)*wp*E01 + wr*wp*E11;
}
'''
kern = cp.RawKernel(kernel_src, 'donor_kernel')

E = cp.array([1., 2., 3., 4.], dtype=cp.float32)
cases = [
    (+1, +1, 1.0),   # both + → E00
    (+1, -1, 3.0),   # vr+ vp- → E01
    (-1, +1, 2.0),   # vr- vp+ → E10
    (-1, -1, 4.0),   # both - → E11
]
print("=== CORRECTED DONOR (upstream both directions) ===")
ok = True
for vr_s, vp_s, exp in cases:
    out = cp.zeros(1, dtype=cp.float32)
    kern((1,),(1,), (cp.array([vr_s],dtype=cp.float32),
                     cp.array([vp_s],dtype=cp.float32), E, out))
    cp.cuda.Stream.null.synchronize()
    got = float(out[0])
    match = abs(got-exp)<1e-5
    print(f"  vr={vr_s:+} vp={vp_s:+}  got={got:.1f} exp={exp:.1f}  {'OK' if match else 'FAIL'}")
    ok &= match
print("CORRECTED DONOR PASS" if ok else "FAIL")
