# donor_kernel.py
import cupy as cp
import numpy as np

kernel_src = r'''
extern "C" __global__
void donor_kernel(
    const float* __restrict__ vr,
    const float* __restrict__ vphi,
    const float* __restrict__ Ecorners,  // 4 values
    float* __restrict__ emf_out
) {
    if (threadIdx.x|blockIdx.x) return;
    float vr_s = vr[0];
    float vp_s = vphi[0];
    float wr = (vr_s > 1e-8f) ? 1.f : ((vr_s < -1e-8f) ? 0.f : 0.5f);
    float wp = (vp_s > 1e-8f) ? 1.f : ((vp_s < -1e-8f) ? 0.f : 0.5f);
    float E00=Ecorners[0], E10=Ecorners[1], E01=Ecorners[2], E11=Ecorners[3];
    emf_out[0] = (1.f-wr)*(1.f-wp)*E00 + wr*(1.f-wp)*E10
               + (1.f-wr)*wp*E01 + wr*wp*E11;
}
'''
kern = cp.RawKernel(kernel_src, 'donor_kernel')

E = cp.array([1.,2.,3.,4.], dtype=cp.float32)
cases = [(+1,+1,4.), (+1,-1,2.), (-1,+1,3.), (-1,-1,1.)]
print("=== KERNEL DONOR CHECK ===")
ok = True
for vr_s, vp_s, expected in cases:
    vr = cp.array([vr_s], dtype=cp.float32)
    vp = cp.array([vp_s], dtype=cp.float32)
    out = cp.zeros(1, dtype=cp.float32)
    kern((1,),(1,), (vr, vp, E, out))
    cp.cuda.Stream.null.synchronize()
    got = float(out[0])
    match = abs(got - expected) < 1e-5
    print(f"  vr={vr_s:+} vφ={vp_s:+}  got={got:.1f}  exp={expected:.1f}  {'OK' if match else 'FAIL'}")
    ok &= match
print("KERNEL DONOR PASS" if ok else "KERNEL DONOR FAIL")
