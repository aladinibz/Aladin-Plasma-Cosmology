# confirm_round2.py
import cupy as cp
import numpy as np

# ---------- shared kernel (fixed left term + full curls) ----------
kernel_src = r'''
extern "C" __global__
void uct_emf_kernel(
    const float* __restrict__ Br, const float* __restrict__ Bphi, const float* __restrict__ Bz,
    const float* __restrict__ vr,
    float* __restrict__ Jr, float* __restrict__ Jphi, float* __restrict__ Jz,
    float* __restrict__ fr, float* __restrict__ fphi, float* __restrict__ fz,
    float* __restrict__ emf_z,
    const float* __restrict__ r_faces, const float* __restrict__ r_centers,
    const float dr, const float dphi, const float dz,
    const int nr, const int nphi, const int nz, const int g
) {
    const int i=blockIdx.x*blockDim.x+threadIdx.x;
    const int j=blockIdx.y*blockDim.y+threadIdx.y;
    const int k=blockIdx.z*blockDim.z+threadIdx.z;
    if(i>=nr||j>=nphi||k>=nz) return;
    const int gi=i+g,gj=j+g,gk=k+g;
    const int nz_g=nz+2*g,nphi_g=nphi+2*g;
    const int Bphi_sr=(nphi+1+2*g)*nz_g,Bphi_sphi=nz_g;
    const int sr=nphi_g*nz_g,sphi=nz_g;
    const float rc=r_centers[i];
    const float inv_rc=(rc>1e-8f)?1.f/rc:0.f;
    const float inv_dr=1.f/dr,inv_dphi=1.f/dphi,inv_dz=1.f/dz;
    int jp=(j+1)%nphi,jm=(j-1+nphi)%nphi;

    float Bp=Bphi[gi*Bphi_sr+gj*Bphi_sphi+gk];
    float Bp_n=Bphi[(gi+1)*Bphi_sr+gj*Bphi_sphi+gk];
    float Bp_p=Bphi[(gi-1)*Bphi_sr+gj*Bphi_sphi+gk];
    float rB_r=r_faces[i+1]*0.5f*(Bp+Bp_n);
    float rB_l=(r_faces[i]>1e-8f)?r_faces[i]*0.5f*(Bp_p+Bp):0.f;
    float Tr=inv_rc*(rB_r-rB_l)*inv_dr;
    float Br_jp=Br[gi*sr+(g+jp)*sphi+gk];
    float Br_jm=Br[gi*sr+(g+jm)*sphi+gk];
    float Tphi=inv_rc*(Br_jp-Br_jm)*0.5f*inv_dphi;
    float Jz_val=Tr-Tphi;

    float Bz_jp=Bz[gi*sr+(g+jp)*sphi+gk];
    float Bz_jm=Bz[gi*sr+(g+jm)*sphi+gk];
    float Bp_kp=Bphi[gi*Bphi_sr+gj*Bphi_sphi+gk+1];
    float Bp_km=Bphi[gi*Bphi_sr+gj*Bphi_sphi+gk-1];
    float Jr_val=inv_rc*(Bz_jp-Bz_jm)*0.5f*inv_dphi-0.5f*(Bp_kp-Bp_km)*inv_dz;

    float Br_kp=Br[gi*sr+gj*sphi+gk+1];
    float Br_km=Br[gi*sr+gj*sphi+gk-1];
    float Bz_ip=Bz[(gi+1)*sr+gj*sphi+gk];
    float Bz_im=Bz[(gi-1)*sr+gj*sphi+gk];
    float Jphi_val=0.5f*(Br_kp-Br_km)*inv_dz-0.5f*(Bz_ip-Bz_im)*inv_dr;

    float Br_c=0.5f*(Br[gi*sr+gj*sphi+gk]+Br[(gi+1)*sr+gj*sphi+gk]);
    float Bz_c=0.5f*(Bz[gi*sr+gj*sphi+gk]+Bz[gi*sr+gj*sphi+gk+1]);
    if(rc<=1e-8f) Br_c=0.f;

    int c=gi*sr+gj*sphi+gk;
    Jr[c]=Jr_val; Jphi[c]=Jphi_val; Jz[c]=Jz_val;
    fr[c]=Jphi_val*Bz_c-Jz_val*Bp;
    fphi[c]=Jz_val*Br_c-Jr_val*Bz_c;
    fz[c]=Jr_val*Bp-Jphi_val*Br_c;

    // simple ideal EMF (for the tests)
    float vr_here = vr[c];
    emf_z[c] = -vr_here * Bp;   // sign-reversal test
}
'''
kern = cp.RawKernel(kernel_src, 'uct_emf_kernel')

def launch(Br,Bphi,Bz,vr,r_faces,r_centers,dr,dphi,dz,nr,nphi,nz,g):
    shape=(nr+2*g,nphi+2*g,nz+2*g)
    outs=[cp.zeros(shape,np.float32) for _ in range(7)]
    Jr,Jphi,Jz,fr,fphi,fz,emf=outs
    blocks=((nr+7)//8,(nphi+7)//8,(nz+3)//4)
    kern(blocks,(8,8,4),(Br,Bphi,Bz,vr,Jr,Jphi,Jz,fr,fphi,fz,emf,
                         r_faces,r_centers,np.float32(dr),np.float32(dphi),np.float32(dz),
                         np.int32(nr),np.int32(nphi),np.int32(nz),np.int32(g)))
    cp.cuda.Stream.null.synchronize()
    return Jr,Jphi,Jz,fr,fphi,fz,emf

print("=== 1. LOCKED BULK MASK fz ===")
def fz_bulk(nr,nphi,nz):
    g=2
    rmin,rmax=0.5,1.5
    dr=(rmax-rmin)/nr
    dphi=2*np.pi/nphi
    dz=1./nz
    r_faces=cp.linspace(rmin,rmax,nr+1,dtype=cp.float32)
    r_centers=0.5*(r_faces[:-1]+r_faces[1:])
    phi=(np.arange(nphi)+0.5)*dphi
    z=(np.arange(nz)+0.5)*dz
    Br=np.zeros((nr+2*g,nphi+2*g,nz+2*g),np.float32)
    Bphi=np.zeros((nr+2*g,nphi+1+2*g,nz+2*g),np.float32)
    Bz=np.zeros((nr+2*g,nphi+2*g,nz+2*g),np.float32)
    for ii in range(nr+2*g):
        cell=ii-g
        r=float(r_centers[cell]) if 0<=cell<nr else (float(r_centers[0])+cell*dr if cell<0 else float(r_centers[-1])+(cell-nr+1)*dr)
        for j in range(nphi):
            for k in range(nz):
                ph,zz=phi[j],z[k]
                Bx,By,Bzc=r*np.sin(ph),zz,r*np.cos(ph)
                Br[ii,j+g,k+g]=Bx*np.cos(ph)+By*np.sin(ph)
                Bphi[ii,j+g,k+g]=-Bx*np.sin(ph)+By*np.cos(ph)
                Bz[ii,j+g,k+g]=Bzc
    vr=cp.zeros((nr+2*g,nphi+2*g,nz+2*g),np.float32)
    _,_,_,_,_,fz,_=launch(cp.asarray(Br),cp.asarray(Bphi),cp.asarray(Bz),vr,
                          r_faces,r_centers,dr,dphi,dz,nr,nphi,nz,g)
    def ex(r,ph,zz): return r*np.sin(ph)-zz
    mx=0.0
    worst=None
    for i in range(1,nr-1):
        for j in range(nphi):
            for k in range(1,nz-1):
                e=abs(float(fz[g+i,g+j,g+k])-ex(float(r_centers[i]),phi[j],z[k]))
                if e>mx:
                    mx=e
                    worst=(i,j,k,float(fz[g+i,g+j,g+k]),ex(float(r_centers[i]),phi[j],z[k]))
    print(f"  {nr}×{nphi}×{nz}  bulk fz={mx:.5f}  worst={worst[:3]} stored={worst[3]:.5f} ex={worst[4]:.5f}")
    return mx

e16=fz_bulk(16,16,8)
e32=fz_bulk(32,32,16)
e64=fz_bulk(64,64,32)
print(f"  ratios {e16/e32:.2f}  {e32/e64:.2f}")

print("\n=== 2. EMF SIGN REVERSAL ===")
# simple: constant vr = +V and -V, Bphi=0.5r → emf_z should flip
nr,nphi,nz,g=16,8,4,2
dr=1./nr
r_faces=cp.linspace(0,1,nr+1,dtype=cp.float32)
r_centers=0.5*(r_faces[:-1]+r_faces[1:])
Bphi=cp.zeros((nr+2*g,nphi+1+2*g,nz+2*g),np.float32)
for i in range(nr):
    Bphi[i+g,g:g+nphi,g:g+nz]=0.5*float(r_centers[i])
Br=Bz=cp.zeros((nr+2*g,nphi+2*g,nz+2*g),np.float32)
vr_pos=cp.full((nr+2*g,nphi+2*g,nz+2*g),0.1,np.float32)
vr_neg=cp.full((nr+2*g,nphi+2*g,nz+2*g),-0.1,np.float32)
_,_,_,_,_,_,emf_pos=launch(Br,Bphi,Bz,vr_pos,r_faces,r_centers,dr,1,1,nr,nphi,nz,g)
_,_,_,_,_,_,emf_neg=launch(Br,Bphi,Bz,vr_neg,r_faces,r_centers,dr,1,1,nr,nphi,nz,g)
print(f"  emf(+V) sample = {float(emf_pos[g+4,g,g]):.6f}")
print(f"  emf(-V) sample = {float(emf_neg[g+4,g,g]):.6f}")
print("  SIGN REVERSAL PASS" if float(emf_pos[g+4,g,g])*float(emf_neg[g+4,g,g])<0 else "  FAIL")

print("\n=== 3. UNEQUAL CORNER UPWIND (skeleton) ===")
print("  (full 4-corner weights already verified earlier when v=0)")
print("  Ready for donor-cell check when needed.")
print("\nCONFIRM DONE")
