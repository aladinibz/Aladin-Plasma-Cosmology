# EMF-01 results: ALADIN UCT-EMF v02

Made 2026-11-20 03:40 UTC.  Source hash frozen and identical on all legs: **True**

- cpu leg kernel sha256 `707c4d9ab723109bfca9b543a0956f69f7534367f905eda2cae8adad8b1b296d`
- gpu leg kernel sha256 `707c4d9ab723109bfca9b543a0956f69f7534367f905eda2cae8adad8b1b296d`

| Test | Final | cpu | gpu |
|---|---|---|---|
| C01 | VERIFIED | VERIFIED | VERIFIED |
| C02 | VERIFIED | VERIFIED | VERIFIED |
| C03 | VERIFIED | VERIFIED | VERIFIED |
| C04 | VERIFIED | VERIFIED | VERIFIED |
| C05 | VERIFIED | VERIFIED | VERIFIED |
| C06 | VERIFIED | VERIFIED | VERIFIED |
| C07 | VERIFIED | VERIFIED | VERIFIED |
| C08 | VERIFIED | VERIFIED | VERIFIED |
| C09 | VERIFIED | VERIFIED | VERIFIED |
| C10 | VERIFIED | VERIFIED | VERIFIED |
| C11 | VERIFIED | VERIFIED | VERIFIED |
| C12 | LIMITATION | LIMITATION | LIMITATION |
| C13 | VERIFIED | VERIFIED | VERIFIED |
| C14 | VERIFIED | VERIFIED | VERIFIED |
| C15 | VERIFIED | VERIFIED | VERIFIED |
| C16 | VERIFIED | VERIFIED | VERIFIED |
| C17 | VERIFIED | VERIFIED | VERIFIED |
| G1 | VERIFIED | — | VERIFIED |
| G2 | VERIFIED | — | VERIFIED |
| G3 | VERIFIED | — | VERIFIED |
| G4_memcheck | VERIFIED |  |  |
| G5_racecheck | VERIFIED |  |  |

Counts: {'VERIFIED': 21, 'LIMITATION': 1}

## Checks (measured vs predeclared threshold)

- C01 [cpu] worst |Ez - upstream corner|: 0.0000e+00 <= 1.0e-12 -> pass
- C01 [gpu] worst |Ez - upstream corner|: 0.0000e+00 <= 1.0e-12 -> pass
- C02 [cpu] worst rel |EMF - oracle|: 3.0551e-16 <= 1.0e-13 -> pass
- C02 [gpu] worst rel |EMF - oracle|: 3.2947e-16 <= 1.0e-13 -> pass
- C03 [cpu] worst rel |CT - oracle|: 0.0000e+00 <= 1.0e-14 -> pass
- C03 [gpu] worst rel |CT - oracle|: 5.7843e-16 <= 1.0e-14 -> pass
- C04 [cpu] worst |JxB - oracle|: 0.0000e+00 <= 1.0e-14 -> pass
- C04 [gpu] worst |JxB - oracle|: 8.8818e-16 <= 1.0e-14 -> pass
- C05 [cpu] worst rel: 1.5845e-07 <= 2.0e-05 -> pass
- C05 [gpu] worst rel: 1.7709e-07 <= 2.0e-05 -> pass
- C06 [cpu] FP64 worst normalised div: 2.7628e-14 <= 1.0e-12 -> pass
- C06 [cpu] FP32 worst normalised div: 2.0215e-05 <= 5.0e-05 -> pass
- C06 [cpu] finite: 1.0000e+00 == 1.0e+00 -> pass
- C06 [gpu] FP64 worst normalised div: 2.5043e-14 <= 1.0e-12 -> pass
- C06 [gpu] FP32 worst normalised div: 1.5405e-05 <= 5.0e-05 -> pass
- C06 [gpu] finite: 1.0000e+00 == 1.0e+00 -> pass
- C07 [cpu] FP64 worst normalised div: 3.4205e-15 <= 1.0e-12 -> pass
- C07 [cpu] FP32 worst normalised div: 2.0050e-06 <= 1.0e-05 -> pass
- C07 [cpu] relative L2 change of B: 1.4774e+00 >= 5.0e-01 -> pass
- C07 [gpu] FP64 worst normalised div: 2.5976e-15 <= 1.0e-12 -> pass
- C07 [gpu] FP32 worst normalised div: 1.7853e-06 <= 1.0e-05 -> pass
- C07 [gpu] relative L2 change of B: 1.4774e+00 >= 5.0e-01 -> pass
- C08 [cpu] final observed order: 1.7734e+00 >= 1.6e+00 -> pass
- C08 [cpu] worst div: 5.6063e-15 <= 1.0e-12 -> pass
- C08 [gpu] final observed order: 1.9974e+00 >= 1.6e+00 -> pass
- C08 [gpu] worst div: 8.1546e-15 <= 1.0e-12 -> pass
- C09 [cpu] final observed order: 2.1238e+00 >= 1.8e+00 -> pass
- C09 [cpu] worst div: 2.0506e-14 <= 1.0e-12 -> pass
- C09 [gpu] final observed order: 2.3740e+00 >= 1.8e+00 -> pass
- C09 [gpu] worst div: 4.5523e-14 <= 1.0e-12 -> pass
- C10 [cpu] MC final order: 1.7021e+00 >= 1.5e+00 -> pass
- C10 [cpu] minmod final order: 2.0667e+00 >= 1.9e+00 -> pass
- C10 [cpu] decay-rate rel err (MC, nr=32): 1.8942e-03 <= 5.0e-03 -> pass
- C10 [cpu] worst div: 9.7374e-15 <= 1.0e-12 -> pass
- C10 [gpu] MC final order: 1.7021e+00 >= 1.5e+00 -> pass
- C10 [gpu] minmod final order: 2.0667e+00 >= 1.9e+00 -> pass
- C10 [gpu] decay-rate rel err (MC, nr=32): 1.8942e-03 <= 5.0e-03 -> pass
- C10 [gpu] worst div: 7.7502e-15 <= 1.0e-12 -> pass
- C11 [cpu] final observed order: 1.9131e+00 >= 1.7e+00 -> pass
- C11 [cpu] rel L1 error nz=32: 4.6132e-02 <= 1.0e-01 -> pass
- C11 [cpu] error a static field would have: 1.4142e+00 >= 1.0e+00 -> pass
- C11 [cpu] peak Hall Er vs h k eps B0 (rel): 3.1178e-02 <= 1.0e-01 -> pass
- C11 [cpu] worst div: 7.8563e-15 <= 1.0e-12 -> pass
- C11 [gpu] final observed order: 1.9641e+00 >= 1.7e+00 -> pass
- C11 [gpu] rel L1 error nz=32: 4.6132e-02 <= 1.0e-01 -> pass
- C11 [gpu] error a static field would have: 1.4142e+00 >= 1.0e+00 -> pass
- C11 [gpu] peak Hall Er vs h k eps B0 (rel): 3.1178e-02 <= 1.0e-01 -> pass
- C11 [gpu] worst div: 1.6163e-14 <= 1.0e-12 -> pass
- C12 [cpu] MC final order: 2.6922e+00 >= 1.5e+00 -> pass
- C12 [cpu] minmod final order: 1.9353e+00 >= 1.5e+00 -> pass
- C12 [cpu] MC drift nr=64, T=10: 1.8817e-04 <= 1.0e-03 -> pass
- C12 [gpu] MC final order: 2.6922e+00 >= 1.5e+00 -> pass
- C12 [gpu] minmod final order: 1.9353e+00 >= 1.5e+00 -> pass
- C12 [gpu] MC drift nr=64, T=10: 1.8817e-04 <= 1.0e-03 -> pass
- C13 [cpu] |f_r - exact|: 4.4409e-16 <= 1.0e-12 -> pass
- C13 [cpu] transverse force: 0.0000e+00 <= 1.0e-12 -> pass
- C13 [cpu] |E_hall - exact|: 0.0000e+00 <= 1.0e-14 -> pass
- C13 [gpu] |f_r - exact|: 4.4409e-16 <= 1.0e-12 -> pass
- C13 [gpu] transverse force: 0.0000e+00 <= 1.0e-12 -> pass
- C13 [gpu] |E_hall - exact|: 0.0000e+00 <= 1.0e-14 -> pass
- C14 [cpu] max spread of axis Ez over phi: 0.0000e+00 <= 0.0e+00 -> pass
- C14 [gpu] max spread of axis Ez over phi: 0.0000e+00 <= 0.0e+00 -> pass
- C15 [cpu] worst rel: 4.6268e-18 <= 1.0e-14 -> pass
- C15 [gpu] worst rel: 3.9459e-18 <= 1.0e-14 -> pass
- C16 [cpu] worst rel vs oracle: 2.4474e-16 <= 1.0e-12 -> pass
- C16 [cpu] all finite: 1.0000e+00 == 1.0e+00 -> pass
- C16 [gpu] worst rel vs oracle: 2.4697e-16 <= 1.0e-12 -> pass
- C16 [gpu] all finite: 1.0000e+00 == 1.0e+00 -> pass
- C17 [cpu] max |E|: 0.0000e+00 <= 0.0e+00 -> pass
- C17 [gpu] max |E|: 0.0000e+00 <= 0.0e+00 -> pass
- G1 [gpu] FP64 worst rel: 3.1415e-16 <= 1.0e-12 -> pass
- G1 [gpu] FP32 worst rel: 2.3400e-07 <= 1.0e-05 -> pass
- G2 [gpu] worst rel vs oracle: 3.2947e-16 <= 1.0e-13 -> pass
- G3 [gpu] max |run_i - run_0|: 0.0000e+00 <= 0.0e+00 -> pass
- G4_memcheck: VERIFIED ========= ERROR SUMMARY: 0 errors
- G5_racecheck: VERIFIED ========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)
