# -*- coding: utf-8 -*-
"""
ALADIN EGLM v02 -- certification campaign EGLM-01.   python campaign_eglm01.py cpu | gpu
Frozen kernel (SOURCE_SHA256 checked).  Thresholds PREDECLARED in THRESHOLDS.  Classes VERIFIED / LIMITATION /
INCONCLUSIVE / BLOCKER as in EMF-01.  Writes eglm01_<leg>_results.json and eglm01_<leg>.log.
"""
import sys, os, time, json, copy, hashlib, platform, datetime, traceback, subprocess
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import eglm_v02 as GL
import numpy_oracle_eglm as N
import uct_emf_v02 as E

FROZEN_SHA = "d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713"

THRESHOLDS = dict(
    E01_div_oracle_rel=1e-13, E01_div_vs_uct_emf_abs=1e-15,
    E02_ct_field_fp64=1e-14, E02_ct_field_fp32=2e-5,
    E03_psi_oracle_rel=1e-14,
    E04_grad_oracle_rel=1e-14, E04_untouched_abs=0.0,
    E05_sources_oracle_rel=1e-13,
    E06_curl_grad_rel=1e-13,
    E07_div_grad_laplacian_rel=1e-13,
    E08_project_fp64=1e-14, E08_project_fp32=1e-6,
    E09_recover_rel=1e-12,
    E10_clean_untouched_rel=1e-14,
    E11_circulation_kept_rel=1e-12,
    E12_glm_clean_converged=1.0,
    E13_damping_rel=1e-12,
    E14_verlet_dispersion_rel=1e-10,
    E15_extreme_project=1e-14,
    G1_gpu_cpu_rel_fp64=1e-13, G1_gpu_cpu_rel_fp32=1e-5,
    G2_determinism_abs=0.0,
    G3_gpu_project=1e-14,
)

LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"
BACKEND = "cupy" if LEG == "gpu" else "cpu"
LOG = open(os.path.join(HERE, f"eglm01_{LEG}.log"), "w")
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); LOG.write(s + "\n"); LOG.flush()

if BACKEND == "cupy":
    import cupy as cp
def dev(G):
    """grid on the leg's device"""
    if BACKEND != "cupy": return G
    H = copy.copy(G); H.xp = cp; return H
def to(x): return cp.asarray(x) if BACKEND == "cupy" else x
def host(x): return x.get() if hasattr(x, "get") else x

def rel(a, b): return float(np.abs(a - b).max() / max(float(np.abs(b).max()), 1e-300))
SIZES = [(9, 12, 7), (16, 8, 3), (3, 6, 1), (1, 4, 2), (31, 6, 9), (17, 34, 5), (24, 32, 16)]
GEOMS = (0.4, 0.0)

def ct_field(H, rng, dt_=np.float64):
    """exactly div-free faces: discrete curl of a random edge potential (single-valued axis Ez)"""
    A = [rng.normal(size=H.shape(k)) for k in ("Er", "Ephi", "Ez")]
    if H.axis: A[2][H.g] = A[2][H.g, H.g:H.g + 1].copy()
    g, P, Z = H.g, H.nphi, H.nz                     # periodic potential -> periodic, exactly div-free faces
    A[0][:, g + P] = A[0][:, g]; A[2][:, g + P] = A[2][:, g]; A[0][:, :, g + Z] = A[0][:, :, g]; A[1][:, :, g + Z] = A[1][:, :, g]
    C = [H.zeros(k) for k in ("Br", "Bphi", "Bz")]; E.ct_update(H, *C, *A, -1.0)
    return [c.astype(dt_) for c in C]

def make_periodic(G, B):
    g, P, Z = G.g, G.nphi, G.nz
    E.fill_periodic(G, *B, kinds=("Br", "Bphi", "Bz"))
    return B

def corrupt(G, B, rng, amp=0.3):
    """charge-neutral random corruption of interior faces (periodic-consistent)"""
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz; D = [b.copy() for b in B]
    if n > 1: D[0][g + 1:g + n, g:g + P, g:g + Z] += amp * rng.normal(size=(n - 1, P, Z))
    n1 = amp * rng.normal(size=(n, P, Z)); D[1][g:g + n, g:g + P, g:g + Z] += n1; D[1][g:g + n, g + P, g:g + Z] += n1[:, 0]
    n2 = amp * rng.normal(size=(n, P, Z)); D[2][g:g + n, g:g + P, g:g + Z] += n2; D[2][g:g + n, g:g + P, g + Z] += n2[:, :, 0]
    return D

def grids(dt_=np.float64, sizes=SIZES):
    for rmin in GEOMS:
        for (nr, nphi, nz) in sizes:
            if rmin == 0 and nphi % 2: continue
            yield rmin, (nr, nphi, nz), GL.Grid(nr, nphi, nz, rmin, 1.3, dtype=dt_), E.Grid(nr, nphi, nz, rmin, 1.3)

def tag(rmin, s): return f"{'axis' if rmin == 0 else 'annulus'} {s[0]}x{s[1]}x{s[2]}"

# ------------------------------------------------------------------ tests
def E01():
    rng = np.random.default_rng(201); rows = []; worst_x = 0.0
    for rmin, s, G, H in grids():
        B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]
        d, net, fm = GL.divergence(dev(G), *[to(b) for b in B], backend=BACKEND); g = G.g
        rows.append(dict(grid=tag(rmin, s), rel=rel(host(d)[g:g + s[0], g:g + s[1], g:g + s[2]], N.div(G, *B))))
        worst_x = max(worst_x, abs(GL.monitor(dev(G), *[to(b) for b in B], backend=BACKEND)["max_norm"] - float(np.abs(E.divergence(H, *B)[1]).max())))
    w = max(r["rel"] for r in rows)
    return dict(conditions="random faces, all sizes, annulus + axis; div = net flux / volume vs oracle; monitor() vs uct_emf_v02.divergence()", rows=rows, worst=w, cross_kernel=worst_x), \
        [("worst rel vs oracle", w, "<=", THRESHOLDS["E01_div_oracle_rel"]), ("|monitor - UCT-EMF divergence|", worst_x, "<=", THRESHOLDS["E01_div_vs_uct_emf_abs"])]

def E02():
    rng = np.random.default_rng(202); w64 = w32 = 0.0
    for rmin, s, G, H in grids():
        C = ct_field(H, rng)
        w64 = max(w64, GL.monitor(dev(G), *[to(c) for c in C], backend=BACKEND)["max_norm"])
        G32 = GL.Grid(*s, rmin, 1.3, dtype=np.float32); w32 = max(w32, GL.monitor(dev(G32), *[to(c.astype(np.float32)) for c in C], backend=BACKEND)["max_norm"])
    return dict(conditions="faces = discrete curl of random edge potentials (what CT produces): the monitor must read round-off", fp64=w64, fp32=w32), \
        [("FP64 max_norm", w64, "<=", THRESHOLDS["E02_ct_field_fp64"]), ("FP32 max_norm", w32, "<=", THRESHOLDS["E02_ct_field_fp32"])]

def E03():
    rng = np.random.default_rng(203); w = 0.0
    for rmin, s, G, H in grids():
        B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]; psi = rng.normal(size=G.shape("cell"))
        q = to(psi.copy()); GL.psi_update(dev(G), *[to(b) for b in B], q, 0.013, 1.7, backend=BACKEND)
        w = max(w, rel(host(q), N.psi_update(G, *B, psi, 0.013, 1.7)))
    return dict(conditions="random B and psi, dt=0.013, ch=1.7", worst=w), [("worst rel", w, "<=", THRESHOLDS["E03_psi_oracle_rel"])]

def E04():
    rng = np.random.default_rng(204); w = 0.0; untouched = 0.0
    for rmin, s, G, H in grids():
        for fixed in (0, 3, 15, 5):
            B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]; psi = rng.normal(size=G.shape("cell"))
            Bk = [to(b.copy()) for b in B]; GL.grad_correct(dev(G), *Bk, to(psi), 0.37, fixed, backend=BACKEND); Bk = [host(b) for b in Bk]
            Bo = N.grad_correct(G, *B, psi, 0.37, fixed)
            w = max(w, max(rel(x, y) for x, y in zip(Bk, Bo)))
            g = G.g
            if fixed & 1 or G.axis: untouched = max(untouched, float(np.abs(Bk[0][g] - B[0][g]).max()))
            if fixed & 2: untouched = max(untouched, float(np.abs(Bk[0][g + s[0]] - B[0][g + s[0]]).max()))
            if fixed & 4: untouched = max(untouched, float(np.abs(Bk[2][:, :, g] - B[2][:, :, g]).max()))
            if fixed & 8: untouched = max(untouched, float(np.abs(Bk[2][:, :, g + s[2]] - B[2][:, :, g + s[2]]).max()))
    return dict(conditions="random B, psi; h=0.37; fixed-face masks 0, r, r+z, r_lo+z_lo; every face incl. ghosts compared", worst=w, fixed_faces_change=untouched), \
        [("worst rel vs oracle", w, "<=", THRESHOLDS["E04_grad_oracle_rel"]), ("max change of fixed / axis faces", untouched, "<=", THRESHOLDS["E04_untouched_abs"])]

def E05():
    rng = np.random.default_rng(205); w = 0.0
    for rmin, s, G, H in grids():
        B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]; psi = rng.normal(size=G.shape("cell"))
        k = GL.eglm_sources(dev(G), *[to(b) for b in B], to(psi), 0.01, backend=BACKEND); o = N.sources(G, *B, psi, 0.01); g = G.g
        w = max(w, max(rel(host(x)[g:g + s[0], g:g + s[1], g:g + s[2]], y) for x, y in zip(k, o)))
    return dict(conditions="random B, psi: -dt (div B) B_c and -dt B_c . grad psi (Dedner et al. 2002)", worst=w), [("worst rel", w, "<=", THRESHOLDS["E05_sources_oracle_rel"])]

def E06():
    rng = np.random.default_rng(206); w = 0.0
    for rmin, s, G, H in grids():
        if min(s) < 2: continue
        B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]; psi = rng.normal(size=G.shape("cell"))
        Bk = [to(b.copy()) for b in B]; GL.grad_correct(dev(G), *Bk, to(psi), 0.9, 3, backend=BACKEND); Bk = [host(b) for b in Bk]
        c0 = N.edge_circulations(G, *B); c1 = N.edge_circulations(G, *Bk)
        w = max(w, max(rel(x, y) for x, y in zip(c1, c0)))
    return dict(conditions="random B; correction with random psi; every interior edge circulation (discrete curl) must be unchanged", worst=w), \
        [("worst rel change of circulations", w, "<=", THRESHOLDS["E06_curl_grad_rel"])]

def E07():
    rng = np.random.default_rng(207); w = 0.0
    for rmin, s, G, H in grids():
        psi = rng.normal(size=G.shape("cell")); GL.fill_psi(G, psi)
        Z = [G.zeros(k) for k in ("Br", "Bphi", "Bz")]; Zk = [to(z) for z in Z]
        GL.grad_correct(dev(G), *Zk, to(psi), -1.0, 3, backend=BACKEND)
        d, _, _ = GL.divergence(dev(G), *Zk, backend=BACKEND); g = G.g
        w = max(w, rel(host(d)[g:g + s[0], g:g + s[1], g:g + s[2]], N.laplacian(G, psi)))
    return dict(conditions="div(grad psi) through the kernel vs the oracle's 7-point cylindrical Laplacian (radial faces fixed)", worst=w), \
        [("worst rel", w, "<=", THRESHOLDS["E07_div_grad_laplacian_rel"])]

def E08():
    rng = np.random.default_rng(208); rows = []
    for dt_ in (np.float64, np.float32):
        for rmin, s, G, H in grids(dt_):
            D = corrupt(G, ct_field(H, rng), rng); Dk = [to(d.astype(dt_)) for d in D]
            r = GL.project(dev(G), *Dk, backend=BACKEND); rows.append(dict(dtype=np.dtype(dt_).name, grid=tag(rmin, s), **r))
    w64 = max(r["after"] for r in rows if r["dtype"] == "float64"); w32 = max(r["after"] for r in rows if r["dtype"] == "float32")
    return dict(conditions="CT field + charge-neutral random corruption of interior faces; project() once", rows=rows), \
        [("FP64 max_norm after", w64, "<=", THRESHOLDS["E08_project_fp64"]), ("FP32 max_norm after", w32, "<=", THRESHOLDS["E08_project_fp32"]),
         ("min reduction factor (FP64)", min(r["before"] / max(r["after"], 1e-300) for r in rows if r["dtype"] == "float64"), ">=", 1e10)]

def E09():
    rng = np.random.default_rng(209); w = 0.0
    for rmin, s, G, H in grids():
        C = make_periodic(G, ct_field(H, rng)); chi = rng.normal(size=G.shape("cell")); GL.fill_psi(G, chi)
        D = N.grad_correct(G, *C, chi, -1.0, 3)          # B0 + grad chi (pure gradient corruption)
        Dk = [to(d) for d in D]; GL.project(dev(G), *Dk, backend=BACKEND); Dk = [host(d) for d in Dk]; g = G.g
        num = max(float(np.abs(x[g:-g, g:-g, g:-g] - y[g:-g, g:-g, g:-g]).max()) for x, y in zip(Dk, C))
        w = max(w, num / max(float(np.abs(c[g:-g, g:-g, g:-g]).max()) for c in C))
    return dict(conditions="B0 (CT field, periodic) + grad(chi) with random chi: projection must return B0", worst=w), [("worst rel |B - B0|", w, "<=", THRESHOLDS["E09_recover_rel"])]

def E10():
    rng = np.random.default_rng(210); w = 0.0
    for rmin, s, G, H in grids():
        C = make_periodic(G, ct_field(H, rng)); Ck = [to(c.copy()) for c in C]; GL.project(dev(G), *Ck, backend=BACKEND)
        w = max(w, max(rel(host(x), y) for x, y in zip(Ck, C)))
    return dict(conditions="already div-free field: projection must leave it unchanged", worst=w), [("worst rel change", w, "<=", THRESHOLDS["E10_clean_untouched_rel"])]

def E11():
    rng = np.random.default_rng(211); w = 0.0
    for rmin, s, G, H in grids():
        if min(s) < 2: continue
        D = corrupt(G, make_periodic(G, ct_field(H, rng)), rng); c0 = N.edge_circulations(G, *D)
        Dk = [to(d) for d in D]; GL.project(dev(G), *Dk, backend=BACKEND); c1 = N.edge_circulations(G, *[host(d) for d in Dk])
        w = max(w, max(rel(x, y) for x, y in zip(c1, c0)))
    return dict(conditions="corrupted field: projection must not change any interior edge circulation (the current is preserved)", worst=w), \
        [("worst rel change of circulations", w, "<=", THRESHOLDS["E11_circulation_kept_rel"])]

def E12():
    rng = np.random.default_rng(212); rows = []
    for rmin, s in ((0.4, (9, 12, 7)), (0.0, (9, 12, 7)), (0.4, (24, 32, 16)), (0.0, (24, 32, 16)), (0.0, (48, 64, 8))):
        G = GL.Grid(*s, rmin, 1.3); H = E.Grid(*s, rmin, 1.3); D = corrupt(G, ct_field(H, rng), rng)
        t = time.time(); r = GL.clean(dev(G), *[to(d) for d in D], alpha=0.2, max_iter=30000, fixed=3, backend=BACKEND)
        rows.append(dict(grid=tag(rmin, s), converged=r["converged"], iterations=r["iterations"], initial=r["initial_max_norm"], final=r["final_max_norm"], seconds=round(time.time() - t, 1)))
    small = [r for r in rows if "9x12x7" in r["grid"]]
    return dict(conditions="iterative GLM cleaning (original design), alpha=0.2, CFL 0.4, tol 1e-12, max 30000 iterations. "
                           "Quantifies the iteration count growth with grid size; project() is the exact alternative",
                limitation="explicit GLM needs O(N) crossings at dt ~ h_min (tiny on the axis): iteration count grows with resolution; "
                           "use project() for on-demand cleaning", rows=rows, cls_if_pass="LIMITATION"), \
        [("small grids converged", float(all(r["converged"] for r in small)), "==", THRESHOLDS["E12_glm_clean_converged"])]

def E13():
    G = GL.Grid(8, 12, 6, 0.4, 1.3); H = E.Grid(8, 12, 6, 0.4, 1.3); rng = np.random.default_rng(213)
    C = make_periodic(G, ct_field(H, rng)); psi = np.full(G.shape("cell"), 0.7)
    Ck = [to(c) for c in C]; q = to(psi); dts = 0.01
    for _ in range(25): GL.glm_step(dev(G), *Ck, q, dts, 1.3, 0.5, 3, BACKEND)
    exact = 0.7 * np.exp(-0.5 * 1.3 * dts / G.h_damp) ** 25 * np.ones_like(psi); g = G.g
    w = rel(host(q)[g:-g, g:-g, g:-g], exact[g:-g, g:-g, g:-g]) if True else 0
    return dict(conditions="div-free field, uniform psi=0.7 (zero gradient): 25 GLM steps must decay psi by exp(-alpha ch dt / h_damp) per step exactly", worst=w), \
        [("worst rel vs exact decay", w, "<=", THRESHOLDS["E13_damping_rel"])]

def E14():
    """single z-mode, no damping: (div B, psi) must follow the Stormer-Verlet map with cos(theta) = 1 - (ch dt s)^2 / 2"""
    G = GL.Grid(4, 8, 32, 0.5, 1.5, zlen=1.0); g = G.g; kz = 3; k = 2 * np.pi * kz; ch, dts, nsteps = 1.0, 0.4 * G.dz, 60
    Br, Bp, Bz = G.zeros("Br"), G.zeros("Bphi"), G.zeros("Bz")
    Bz[...] = (0.1 * np.cos(k * G.z_f))[None, None, :]
    psi = G.zeros("cell"); Bk = [to(Br), to(Bp), to(Bz)]; q = to(psi)
    s2 = (2 - 2 * np.cos(k * G.dz)) / G.dz ** 2; h = 0.5 * dts
    def dz_mode(div_cells):   # amplitude of the sin/cos structure: project on exp(i k z_c)
        zc = G.z_c[g:g + G.nz]; return np.sum(div_cells * np.exp(-1j * k * zc)) * 2 / G.nz
    d0 = dz_mode(host(GL.divergence(dev(G), *Bk, backend=BACKEND)[0])[g + 1, g + 2, g:g + G.nz])
    M = np.array([[1, h * s2], [0, 1]]) @ np.array([[1, 0], [-dts * ch * ch, 1]]) @ np.array([[1, h * s2], [0, 1]])
    st = np.array([d0, 0j]); worst = 0.0
    for n in range(nsteps):
        GL.glm_step(dev(G), *Bk, q, dts, ch, 0.0, 3, BACKEND); st = M @ st
        dn = dz_mode(host(GL.divergence(dev(G), *Bk, backend=BACKEND)[0])[g + 1, g + 2, g:g + G.nz])
        worst = max(worst, abs(dn - st[0]) / abs(d0))
    theta = np.arccos(1 - (ch * dts) ** 2 * s2 / 2)
    return dict(conditions=f"Bz = 0.1 cos(2 pi {kz} z), annulus 4x8x32, ch dt = 0.4 dz, alpha = 0, {nsteps} steps; discrete GLM wave must follow the "
                           "Stormer-Verlet 2x2 map derived independently (phase speed / ch = " + f"{theta / (k * dts):.6f})", worst=worst, phase_speed_ratio=theta / (k * dts)), \
        [("worst rel deviation of the div-B mode", worst, "<=", THRESHOLDS["E14_verlet_dispersion_rel"])]

def E15():
    rng = np.random.default_rng(215); w = 0.0; rows = []
    for scale in (1e-8, 1e8):
        for rmin, s, G, H in grids(sizes=[(13, 18, 11)]):
            D = [scale * d for d in corrupt(G, ct_field(H, rng), rng)]; r = GL.project(dev(G), *[to(d) for d in D], backend=BACKEND)
            rows.append(dict(scale=scale, grid=tag(rmin, s), **r)); w = max(w, r["after"])
    return dict(conditions="field scaled by 1e-8 and 1e8", rows=rows), [("worst max_norm after", w, "<=", THRESHOLDS["E15_extreme_project"])]

def G1():
    out = {}
    for dt_ in (np.float64, np.float32):
        rng = np.random.default_rng(31); w = 0.0
        for rmin, s, G, H in grids(dt_):
            B = [rng.normal(size=G.shape(k)).astype(dt_) for k in ("Br", "Bphi", "Bz")]; psi = rng.normal(size=G.shape("cell")).astype(dt_)
            Gg = dev(G)
            res_c = list(GL.divergence(G, *B, backend="cpu")) + list(GL.eglm_sources(G, *B, psi, 0.01, backend="cpu"))
            res_g = list(GL.divergence(Gg, *[to(b) for b in B], backend="cupy")) + list(GL.eglm_sources(Gg, *[to(b) for b in B], to(psi), 0.01, backend="cupy"))
            Bc = [b.copy() for b in B]; GL.grad_correct(G, *Bc, psi, 0.3, 3, backend="cpu")
            Bg = [to(b) for b in B]; GL.grad_correct(Gg, *Bg, to(psi), 0.3, 3, backend="cupy")
            qc = psi.copy(); GL.psi_update(G, *B, qc, 0.01, 1.2, backend="cpu"); qg = to(psi); GL.psi_update(Gg, *[to(b) for b in B], qg, 0.01, 1.2, backend="cupy")
            w = max(w, max(rel(host(y), x) for x, y in zip(res_c + Bc + [qc], res_g + Bg + [qg])))
        out[np.dtype(dt_).name] = w
    return dict(conditions="all four kernels, GPU vs CPU backend, all sizes (partial 128-thread blocks)", **out), \
        [("FP64", out["float64"], "<=", THRESHOLDS["G1_gpu_cpu_rel_fp64"]), ("FP32", out["float32"], "<=", THRESHOLDS["G1_gpu_cpu_rel_fp32"])]

def G2():
    rng = np.random.default_rng(32); w = 0.0
    G = GL.Grid(31, 34, 17, 0.0, 1.0); B = [rng.normal(size=G.shape(k)) for k in ("Br", "Bphi", "Bz")]; psi = rng.normal(size=G.shape("cell"))
    runs = []
    for _ in range(3):
        Bg = [to(b) for b in B]; GL.grad_correct(dev(G), *Bg, to(psi), 0.3, 3, backend="cupy")
        runs.append([host(b) for b in Bg] + [host(x) for x in GL.divergence(dev(G), *[to(b) for b in B], backend="cupy")])
    w = max(float(np.abs(x - y).max()) for r in runs[1:] for x, y in zip(r, runs[0]))
    return dict(conditions="three GPU launches on identical inputs: bitwise identical", worst=w), [("max |run_i - run_0|", w, "<=", THRESHOLDS["G2_determinism_abs"])]

def G3():
    r = E08()[0]; w = max(x["after"] for x in r["rows"] if x["dtype"] == "float64")
    return dict(conditions="E08 projection with the GPU backend (div and grad on GPU)", worst=w), [("FP64 max_norm after", w, "<=", THRESHOLDS["G3_gpu_project"])]

CPU_TESTS = [E01, E02, E03, E04, E05, E06, E07, E08, E09, E10, E11, E12, E13, E14, E15]
GPU_TESTS = [G1, G2, G3]
OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "==": lambda a, b: a == b}

def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()

def env():
    e = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, backend=BACKEND, platform=platform.platform(),
             python=sys.version.split()[0], numpy=np.__version__, cpu_count=os.cpu_count())
    try: e["gxx"] = subprocess.run(["g++", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    except Exception as x: e["gxx"] = repr(x)
    if BACKEND == "cupy":
        e["cupy"] = cp.__version__; e["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); e["cuda_runtime"] = cp.cuda.runtime.runtimeGetVersion()
    return e

if __name__ == "__main__":
    files = ["eglm_v02.py", "numpy_oracle_eglm.py", "uct_emf_v02.py", "campaign_eglm01.py"]
    R = dict(campaign="EGLM-01", kernel="ALADIN EGLM v02", env=env(), kernel_source_sha256=GL.SOURCE_SHA256, frozen_sha256=FROZEN_SHA,
             file_sha256={f: sha(os.path.join(HERE, f)) for f in files}, thresholds=THRESHOLDS, tests=[])
    log(f"EGLM-01 leg={LEG} backend={BACKEND} kernel sha {GL.SOURCE_SHA256}")
    if GL.SOURCE_SHA256 != FROZEN_SHA:
        log("BLOCKER: kernel source does not match the frozen hash"); R["tests"].append(dict(id="FREEZE", cls="BLOCKER", passed=False, detail="source hash mismatch"))
    tests = CPU_TESTS + (GPU_TESTS if LEG == "gpu" and GL.has_gpu() else [])
    for f in tests:
        t0 = time.time(); rec = dict(id=f.__name__)
        try:
            data, checks = f(); cls_ok = data.pop("cls_if_pass", "VERIFIED"); rec["data"] = data
            rec["checks"] = [dict(name=n, measured=float(v), op=op, threshold=float(th), passed=bool(OPS[op](float(v), float(th)))) for n, v, op, th in checks]
            rec["passed"] = all(c["passed"] for c in rec["checks"]); rec["cls"] = cls_ok if rec["passed"] else "BLOCKER"
        except Exception:
            rec["cls"] = "BLOCKER"; rec["passed"] = False; rec["exception"] = traceback.format_exc()
        rec["seconds"] = round(time.time() - t0, 2); R["tests"].append(rec)
        log(f"{rec['id']:4s} {rec['cls']:10s} {rec['seconds']:8.1f}s  " + "; ".join(f"{c['name']}={c['measured']:.3e} {c['op']} {c['threshold']:.1e} {'ok' if c['passed'] else 'FAIL'}" for c in rec.get("checks", [])))
        if "exception" in rec: log(rec["exception"])
    if LEG == "gpu" and not GL.has_gpu():
        for f in GPU_TESTS: R["tests"].append(dict(id=f.__name__, cls="INCONCLUSIVE", passed=None, detail="no GPU on this leg"))
    counts = {}
    for t in R["tests"]: counts[t["cls"]] = counts.get(t["cls"], 0) + 1
    R["summary"] = counts; log("SUMMARY", counts)
    json.dump(R, open(os.path.join(HERE, f"eglm01_{LEG}_results.json"), "w"), indent=1, default=float)
