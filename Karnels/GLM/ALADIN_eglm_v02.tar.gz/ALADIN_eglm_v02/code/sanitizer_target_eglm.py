# -*- coding: utf-8 -*-
"""Small GPU workload for compute-sanitizer (memcheck / racecheck): all EGLM v02 kernels, FP64 + FP32, annulus + axis,
sizes leaving partial 128-thread blocks."""
import sys, os, copy, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cupy as cp, eglm_v02 as GL
rng = np.random.default_rng(5)
for dt_ in (np.float64, np.float32):
    for rmin, s in ((0.4, (7, 10, 5)), (0.0, (13, 18, 11)), (0.0, (1, 4, 2)), (0.4, (31, 6, 9))):
        G = GL.Grid(*s, rmin, 1.3, dtype=dt_, xp=cp)
        B = [cp.asarray(rng.normal(size=G.shape(k)).astype(dt_)) for k in ("Br", "Bphi", "Bz")]
        psi = cp.asarray(rng.normal(size=G.shape("cell")).astype(dt_))
        GL.monitor(G, *B, backend="cupy"); GL.psi_update(G, *B, psi, 1e-3, 1.0, backend="cupy")
        GL.fill_psi(G, psi); GL.grad_correct(G, *B, psi, 1e-3, 3, backend="cupy"); src = GL.eglm_sources(G, *B, psi, 1e-3, backend="cupy")
        GL.glm_step(G, *B, psi, 1e-3, 1.0, 0.2, 3, "cupy"); r = GL.project(G, *B, backend="cupy")
        cp.cuda.Device().synchronize()
        print(np.dtype(dt_).name, rmin, s, "finite", bool(all(bool(cp.isfinite(x).all()) for x in (*B, psi, *src))), "project after", f"{r['after']:.1e}", flush=True)
print("SANITIZER TARGET DONE")
