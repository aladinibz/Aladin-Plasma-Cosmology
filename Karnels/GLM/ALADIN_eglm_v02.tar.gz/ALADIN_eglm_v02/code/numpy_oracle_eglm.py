# -*- coding: utf-8 -*-
"""Independent NumPy oracle for eglm_v02 (written from the formulas, loops over index sets; no shared code)."""
import numpy as np


def _geom(G):
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz
    rf = np.asarray(G.r_faces, np.float64); rc = np.asarray(G.r_centers, np.float64)
    return g, n, P, Z, rf, rc


def net_flux(G, Br, Bp, Bz):
    """net flux out of every interior cell, cell volume"""
    g, n, P, Z, rf, rc = _geom(G); out = np.zeros((n, P, Z)); vol = np.zeros(n)
    for a in range(n):
        i = g + a; r0, r1 = rf[i], rf[i + 1]; area = 0.5 * (r1 * r1 - r0 * r0) * G.dphi; vol[a] = area * G.dz
        out[a] = ((r1 * Br[i + 1, g:g + P, g:g + Z] - r0 * Br[i, g:g + P, g:g + Z]) * G.dphi * G.dz
                  + (Bp[i, g + 1:g + P + 1, g:g + Z] - Bp[i, g:g + P, g:g + Z]) * G.dr * G.dz
                  + (Bz[i, g:g + P, g + 1:g + Z + 1] - Bz[i, g:g + P, g:g + Z]) * area)
    return out, vol


def div(G, Br, Bp, Bz):
    f, v = net_flux(G, Br, Bp, Bz); return f / v[:, None, None]


def psi_update(G, Br, Bp, Bz, psi, dt, ch):
    g, n, P, Z, rf, rc = _geom(G); q = psi.copy(); q[g:g + n, g:g + P, g:g + Z] -= dt * ch * ch * div(G, Br, Bp, Bz); return q


def grad_correct(G, Br, Bp, Bz, psi, h, fixed):
    g, n, P, Z, rf, rc = _geom(G); Br, Bp, Bz = Br.copy(), Bp.copy(), Bz.copy()
    for a in range(n + 1):
        I = g + a
        if rf[I] == 0 or (a == 0 and fixed & 1) or (a == n and fixed & 2): continue
        Br[I, g:g + P, g:g + Z] -= h * (psi[I, g:g + P, g:g + Z] - psi[I - 1, g:g + P, g:g + Z]) / G.dr
    for a in range(n):
        i = g + a
        for b in range(P + 1):
            J = g + b; Bp[i, J, g:g + Z] -= h * (psi[i, J, g:g + Z] - psi[i, J - 1, g:g + Z]) / (rc[i] * G.dphi)
    for c in range(Z + 1):
        K = g + c
        if (c == 0 and fixed & 4) or (c == Z and fixed & 8): continue
        Bz[g:g + n, g:g + P, K] -= h * (psi[g:g + n, g:g + P, K] - psi[g:g + n, g:g + P, K - 1]) / G.dz
    return Br, Bp, Bz


def sources(G, Br, Bp, Bz, psi, dt):
    g, n, P, Z, rf, rc = _geom(G); d = div(G, Br, Bp, Bz); s = (slice(g, g + n), slice(g, g + P), slice(g, g + Z))
    br = 0.5 * (Br[g:g + n, g:g + P, g:g + Z] + Br[g + 1:g + n + 1, g:g + P, g:g + Z])
    bp = 0.5 * (Bp[g:g + n, g:g + P, g:g + Z] + Bp[g:g + n, g + 1:g + P + 1, g:g + Z])
    bz = 0.5 * (Bz[g:g + n, g:g + P, g:g + Z] + Bz[g:g + n, g:g + P, g + 1:g + Z + 1])
    gr = (psi[g + 1:g + n + 1, g:g + P, g:g + Z] - psi[g - 1:g + n - 1, g:g + P, g:g + Z]) / (2 * G.dr)
    gp = (psi[g:g + n, g + 1:g + P + 1, g:g + Z] - psi[g:g + n, g - 1:g + P - 1, g:g + Z]) / (2 * rc[g:g + n, None, None] * G.dphi)
    gz = (psi[g:g + n, g:g + P, g + 1:g + Z + 1] - psi[g:g + n, g:g + P, g - 1:g + Z - 1]) / (2 * G.dz)
    return -dt * d * br, -dt * d * bp, -dt * d * bz, -dt * (br * gr + bp * gp + bz * gz)


def edge_circulations(G, Br, Bp, Bz):
    """line integral of B around every interior edge-dual loop, i.e. the CT curl: for each face family the
    circulation that defines (curl B) . n on the dual grid.  Returned as the three edge-curl arrays
    Cz (z-edges: around the (r,phi) face patch), Cr (r-edges), Cphi (phi-edges), interior edges only."""
    g, n, P, Z, rf, rc = _geom(G)
    # tangential B on the dual grid lives on faces; circulation around a z-edge at r-face I, phi-face J:
    I = np.arange(g + 1, g + n)[:, None, None]; J = np.arange(g + 1, g + P)[None, :, None]; K = np.arange(g, g + Z)[None, None, :]
    Cz = (rc[I] * Bp[I, J, K] - rc[I - 1] * Bp[I - 1, J, K]) * G.dphi - (Br[I, J, K] - Br[I, J - 1, K]) * G.dr
    I = np.arange(g, g + n)[:, None, None]; J = np.arange(g + 1, g + P)[None, :, None]; K = np.arange(g + 1, g + Z)[None, None, :]
    Cr = (Bz[I, J, K] - Bz[I, J - 1, K]) * G.dz - (Bp[I, J, K] - Bp[I, J, K - 1]) * rc[I] * G.dphi
    I = np.arange(g + 1, g + n)[:, None, None]; J = np.arange(g, g + P)[None, :, None]; K = np.arange(g + 1, g + Z)[None, None, :]
    Cp = (Br[I, J, K] - Br[I, J, K - 1]) * G.dr - (Bz[I, J, K] - Bz[I - 1, J, K]) * G.dz
    return Cz, Cr, Cp


def laplacian(G, psi):
    """div(grad psi) with the radial boundary faces fixed (the operator project() inverts), interior cells"""
    g, n, P, Z, rf, rc = _geom(G)
    zero = [np.zeros((n + 1 + 2 * g, P + 2 * g, Z + 2 * g)), np.zeros((n + 2 * g, P + 1 + 2 * g, Z + 2 * g)), np.zeros((n + 2 * g, P + 2 * g, Z + 1 + 2 * g))]
    B = grad_correct(G, *zero, psi, -1.0, 3)
    return div(G, *B)
