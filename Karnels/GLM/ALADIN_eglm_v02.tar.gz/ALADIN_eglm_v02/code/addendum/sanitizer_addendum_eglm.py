# -*- coding: utf-8 -*-
"""EGLM-01 addendum A3: compute-sanitizer workload on LARGE and ODD grids (frozen kernel unchanged).
Every kernel incl. project() and glm_step(); FP64 + FP32; annulus (odd nphi allowed) and axis (nphi even)."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cupy as cp, eglm_v02 as GL
assert GL.SOURCE_SHA256 == "d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713"
rng = np.random.default_rng(7)
CASES = [(0.4, (64, 96, 32)), (0.0, (33, 18, 17)), (0.4, (17, 7, 13)), (0.0, (5, 2, 3)), (0.0, (48, 64, 8)), (0.3, (129, 3, 1))]
for dt_ in (np.float64, np.float32):
    for rmin, s in CASES:
        G = GL.Grid(*s, rmin, 1.3, dtype=dt_, xp=cp)
        B = [cp.asarray(rng.normal(size=G.shape(k)).astype(dt_)) for k in ("Br", "Bphi", "Bz")]
        psi = cp.asarray(rng.normal(size=G.shape("cell")).astype(dt_))
        GL.monitor(G, *B, backend="cupy"); GL.psi_update(G, *B, psi, 1e-3, 1.0, backend="cupy")
        GL.fill_psi(G, psi); GL.grad_correct(G, *B, psi, 1e-3, 3, backend="cupy"); src = GL.eglm_sources(G, *B, psi, 1e-3, backend="cupy")
        GL.glm_step(G, *B, psi, 1e-3, 1.0, 0.2, 3, "cupy"); r = GL.project(G, *B, backend="cupy")
        cp.cuda.Device().synchronize()
        print(np.dtype(dt_).name, "axis" if rmin == 0 else "annulus", s, "finite", bool(all(bool(cp.isfinite(x).all()) for x in (*B, psi, *src))), flush=True)
print("SANITIZER TARGET DONE")
