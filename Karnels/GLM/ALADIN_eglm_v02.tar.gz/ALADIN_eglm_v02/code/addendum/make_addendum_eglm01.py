# -*- coding: utf-8 -*-
"""Merge the EGLM-01 addendum legs and the addendum sanitizer logs into EGLM01_ADDENDUM.json / .md (verbatim)."""
import os, re, json, datetime
HERE = os.path.dirname(os.path.abspath(__file__)); P = lambda f: os.path.join(HERE, f)
legs = {k: json.load(open(P(f"eglm01_addendum_{k}.json"))) for k in ("cpu", "gpu") if os.path.exists(P(f"eglm01_addendum_{k}.json"))}
def san(f, pat):
    if not os.path.exists(P(f)): return dict(file=f, present=False, cls="INCONCLUSIVE")
    t = open(P(f), errors="replace").read(); ok = re.search(pat, t) is not None and "SANITIZER TARGET DONE" in t
    return dict(file=f, present=True, cls="VERIFIED" if ok else "BLOCKER", summary=[l.strip() for l in t.splitlines() if "SUMMARY" in l],
                workload=[l.strip() for l in t.splitlines() if l.startswith(("float64", "float32"))], log=t)
S = dict(A3_memcheck=san("eglm01_add_memcheck.log", r"ERROR SUMMARY: 0 errors"),
         A3_racecheck=san("eglm01_add_racecheck.log", r"RACECHECK SUMMARY: 0 hazards displayed \(0 errors, 0 warnings\)"))
out = dict(addendum="EGLM-01 addendum", made=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
           kernel_hashes={k: v["kernel_source_sha256"] for k, v in legs.items()},
           classes=dict(A1_E12="LIMITATION (restated)", A2={k: v["A2_class"] for k, v in legs.items()}, **{k: v["cls"] for k, v in S.items()}),
           legs_verbatim=legs, sanitizer_verbatim=S)
json.dump(out, open(P("EGLM01_ADDENDUM.json"), "w"), indent=1, default=float)
md = ["# EGLM-01 addendum (frozen kernel unchanged)", "", f"Made {out['made']}. Kernel hashes: {out['kernel_hashes']}", "", "## A1 E12 restated", ""]
for k, v in legs.items(): md += [f"**{k} leg:** {v['A1_E12_restated']['statement']}", ""]
md += ["## A2 project() on large grids", ""]
for k, v in legs.items():
    md += [f"**{k} leg: {v['A2_class']}**", "", "| dtype | grid | before | after | circ change | s |", "|---|---|---|---|---|---|"]
    md += [f"| {r['dtype']} | {r['grid']} | {r['before']:.2e} | {r['after']:.2e} | {r.get('circ_rel', float('nan')):.1e} | {r['seconds']} |" for r in v["A2_project_large"]["rows"]]
    md += [""] + [f"- {c['name']}: {c['measured']:.3e} {c['op']} {c['threshold']:.0e} -> {'pass' if c['passed'] else 'FAIL'}" for c in v["A2_project_large"]["checks"]] + [""]
md += ["## A3 compute-sanitizer, large and odd grids", ""]
for k, s in S.items(): md += [f"- {k}: **{s['cls']}** " + "; ".join(s.get("summary", [])), f"  workload: {len(s.get('workload', []))} configurations"]
open(P("EGLM01_ADDENDUM.md"), "w").write("\n".join(md) + "\n"); print("\n".join(md))
