# -*- coding: utf-8 -*-
"""
EGLM-01 ADDENDUM (frozen kernel unchanged; the frozen EGLM-01 run is not modified).  python addendum_eglm01.py cpu|gpu
Answers the review of E12 and of the sanitizer scope:
  A1  E12 restated per grid from the frozen results (both legs): which grids converged, which did not, iteration scaling.
  A2  project() on LARGE grids (beyond E08's largest 24x32x16): div after <= 1e-14 (FP64) / 1e-6 (FP32), circulations kept.
  A3  compute-sanitizer on large and odd grids: run separately (sanitizer_addendum_eglm.py), parsed by make_addendum.
Thresholds predeclared below.  Writes eglm01_addendum_<leg>.json.
"""
import sys, os, json, time, copy, datetime, platform, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import eglm_v02 as GL, numpy_oracle_eglm as N, uct_emf_v02 as E
FROZEN = "d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713"
TH = dict(A2_fp64=1e-14, A2_fp32=1e-6, A2_circ_rel=1e-12)
LEG = sys.argv[1] if len(sys.argv) > 1 else "cpu"; BACKEND = "cupy" if LEG == "gpu" else "cpu"
if BACKEND == "cupy": import cupy as cp
def dev(G):
    if BACKEND != "cupy": return G
    H = copy.copy(G); H.xp = cp; return H
to = (lambda x: cp.asarray(x)) if BACKEND == "cupy" else (lambda x: x)
host = lambda x: x.get() if hasattr(x, "get") else x

def ct_field(H, rng):
    A = [rng.normal(size=H.shape(k)) for k in ("Er", "Ephi", "Ez")]
    if H.axis: A[2][H.g] = A[2][H.g, H.g:H.g + 1].copy()
    g, P, Z = H.g, H.nphi, H.nz
    A[0][:, g + P] = A[0][:, g]; A[2][:, g + P] = A[2][:, g]; A[0][:, :, g + Z] = A[0][:, :, g]; A[1][:, :, g + Z] = A[1][:, :, g]
    C = [H.zeros(k) for k in ("Br", "Bphi", "Bz")]; E.ct_update(H, *C, *A, -1.0); return C

def corrupt(G, B, rng, amp=0.3):
    g, n, P, Z = G.g, G.nr, G.nphi, G.nz; D = [b.copy() for b in B]
    if n > 1: D[0][g + 1:g + n, g:g + P, g:g + Z] += amp * rng.normal(size=(n - 1, P, Z))
    n1 = amp * rng.normal(size=(n, P, Z)); D[1][g:g + n, g:g + P, g:g + Z] += n1; D[1][g:g + n, g + P, g:g + Z] += n1[:, 0]
    n2 = amp * rng.normal(size=(n, P, Z)); D[2][g:g + n, g:g + P, g:g + Z] += n2; D[2][g:g + n, g:g + P, g + Z] += n2[:, :, 0]
    return D

def A1():
    out = {}
    for leg in ("cpu", "gpu"):
        p = os.path.join(HERE, f"eglm01_{leg}_results.json")
        if not os.path.exists(p): continue
        rows = next(t for t in json.load(open(p))["tests"] if t["id"] == "E12")["data"]["rows"]
        out[leg] = rows
    rows = out.get("gpu") or out.get("cpu")
    conv = [r["grid"] for r in rows if r["converged"]]; notc = [r for r in rows if not r["converged"]]
    def it(gr): return next(r["iterations"] for r in rows if r["grid"] == gr)
    scal = dict(annulus_exponent=float(np.log(it("annulus 24x32x16") / it("annulus 9x12x7")) / np.log(24 / 9)),
                axis_exponent=float(np.log(it("axis 24x32x16") / it("axis 9x12x7")) / np.log(24 / 9)))
    # re-run the five E12 cases on this leg keeping the full history (every 10 iterations) to check monotone reduction
    rng = np.random.default_rng(212); hist = []
    for rmin, sz in ((0.4, (9, 12, 7)), (0.0, (9, 12, 7)), (0.4, (24, 32, 16)), (0.0, (24, 32, 16)), (0.0, (48, 64, 8))):
        G = GL.Grid(*sz, rmin, 1.3); H = E.Grid(*sz, rmin, 1.3); D = corrupt(G, ct_field(H, rng), rng)
        r = GL.clean(dev(G), *[to(d) for d in D], alpha=0.2, max_iter=30000, fixed=3, backend=BACKEND)
        h = np.array(r["history"]); inc = np.diff(h) > 0
        hist.append(dict(grid=f"{'axis' if rmin == 0 else 'annulus'} {sz[0]}x{sz[1]}x{sz[2]}", iterations=r["iterations"], converged=r["converged"],
                         final=r["final_max_norm"], checks=len(h), increases=int(inc.sum()), max_increase_ratio=float((h[1:] / h[:-1]).max()),
                         history_every_10=[float(x) for x in h]))
    monotone = all(x["increases"] == 0 for x in hist)
    statement = (f"Iterative GLM clean() (alpha=0.2, CFL 0.4, tol 1e-12, cap 30000): converged on {', '.join(conv)}; "
                 + "; ".join(f"NOT converged on {r['grid']} within {r['iterations']} iterations ({r['initial']:.2e} -> {r['final']:.2e})" for r in notc)
                 + f". Measured iteration growth from 9 to 24 radial cells: annulus ~N^{scal['annulus_exponent']:.2f}, axis ~N^{scal['axis_exponent']:.2f}. "
                 "Classification: convergence-rate scaling restriction of explicit GLM used as a standalone cleaner (pseudo-time step set by the "
                 "smallest cell, 0.5 dr dphi at the axis); not a correctness failure (all runs finite; " + ("divergence decreased at every 10-iteration check" if monotone else
                 "divergence decreased overall but not at every check: " + ", ".join(f"{x['grid']} {x['increases']} increases of {x['checks']} checks, max ratio {x['max_increase_ratio']:.3f}" for x in hist if x["increases"])) + "). Production guidance: on-demand cleaning uses project(); clean() is not recommended on large or axis grids.")
    return dict(per_leg=out, scaling=scal, statement=statement, rerun_with_history=hist, monotone=monotone, legs_identical=bool(len(out) < 2 or [ (r["grid"], r["iterations"], r["converged"]) for r in out["cpu"]] == [(r["grid"], r["iterations"], r["converged"]) for r in out["gpu"]]))

def A2():
    rng = np.random.default_rng(301); rows = []
    cases = [(0.0, (48, 64, 8)), (0.4, (64, 96, 32)), (0.0, (96, 128, 16)), (0.0, (33, 18, 17)), (0.3, (128, 64, 64))]
    for dt_ in (np.float64, np.float32):
        for rmin, s in cases:
            G = GL.Grid(*s, rmin, 1.3, dtype=dt_); H = E.Grid(*s, rmin, 1.3)
            D = corrupt(G, ct_field(H, rng), rng); c0 = N.edge_circulations(G, *D) if dt_ == np.float64 else None
            Dk = [to(d.astype(dt_)) for d in D]; t = time.time(); r = GL.project(dev(G), *Dk, backend=BACKEND); sec = time.time() - t
            row = dict(dtype=np.dtype(dt_).name, grid=f"{'axis' if rmin == 0 else 'annulus'} {s[0]}x{s[1]}x{s[2]}", seconds=round(sec, 3), **r)
            if c0 is not None:
                c1 = N.edge_circulations(G, *[host(d) for d in Dk])
                row["circ_rel"] = max(float(np.abs(x - y).max() / np.abs(y).max()) for x, y in zip(c1, c0))
            rows.append(row); print(row, flush=True)
    w64 = max(r["after"] for r in rows if r["dtype"] == "float64"); w32 = max(r["after"] for r in rows if r["dtype"] == "float32")
    wc = max(r["circ_rel"] for r in rows if "circ_rel" in r)
    checks = [("FP64 max_norm after", w64, "<=", TH["A2_fp64"]), ("FP32 max_norm after", w32, "<=", TH["A2_fp32"]), ("circulation change (FP64)", wc, "<=", TH["A2_circ_rel"])]
    return dict(rows=rows, checks=[dict(name=n, measured=v, op=o, threshold=t, passed=bool(v <= t)) for n, v, o, t in checks])

if __name__ == "__main__":
    assert GL.SOURCE_SHA256 == FROZEN, "kernel hash mismatch"
    env = dict(utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"), leg=LEG, platform=platform.platform(), numpy=np.__version__)
    if BACKEND == "cupy": env["gpu"] = cp.cuda.runtime.getDeviceProperties(0)["name"].decode(); env["cupy"] = cp.__version__
    R = dict(addendum="EGLM-01 addendum", kernel_source_sha256=GL.SOURCE_SHA256, env=env, thresholds=TH,
             file_sha256={f: hashlib.sha256(open(os.path.join(HERE, f), "rb").read()).hexdigest() for f in ("eglm_v02.py", "addendum_eglm01.py", "sanitizer_addendum_eglm.py")})
    R["A1_E12_restated"] = A1(); print(R["A1_E12_restated"]["statement"], flush=True)
    R["A2_project_large"] = A2()
    for c in R["A2_project_large"]["checks"]: print("A2", c, flush=True)
    R["A2_class"] = "VERIFIED" if all(c["passed"] for c in R["A2_project_large"]["checks"]) else "BLOCKER"
    print("A2", R["A2_class"])
    json.dump(R, open(os.path.join(HERE, f"eglm01_addendum_{LEG}.json"), "w"), indent=1, default=float)
