import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
R = json.load(open("/home/claude/eglm01/EGLM01_RESULTS.json")); T = {t["id"]: t for t in R["legs_verbatim"]["gpu"]["tests"]}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9}); navy, teal, gold, grey = "#13233f", "#0f7d82", "#b8892b", "#5b6475"
fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.5))
rows = [r for r in T["E08"]["data"]["rows"] if r["dtype"] == "float64"]
x = np.arange(len(rows)); ax[0].semilogy(x, [r["before"] for r in rows], "o", color=gold, label="before project()")
ax[0].semilogy(x, [r["after"] for r in rows], "s", color=navy, label="after one project() call")
ax[0].set_xticks(x); ax[0].set_xticklabels([r["grid"].replace("annulus ", "a ").replace("axis ", "x ") for r in rows], rotation=60, fontsize=6.5)
ax[0].set_ylabel("max |net flux| / max |face flux|"); ax[0].set_title("E08: exact projection, FP64 (GPU leg)", fontsize=9.5); ax[0].legend(fontsize=7.5, frameon=False); ax[0].grid(alpha=.3)
r12 = T["E12"]["data"]["rows"]; lab = [r["grid"] for r in r12]; it = [r["iterations"] for r in r12]
cols = [teal if r["converged"] else "#a33b3b" for r in r12]
ax[1].bar(range(len(r12)), it, color=cols); ax[1].set_yscale("log"); ax[1].set_xticks(range(len(r12))); ax[1].set_xticklabels(lab, rotation=30, fontsize=7, ha="right")
for i, r in enumerate(r12): ax[1].text(i, r["iterations"] * 1.15, ("" if r["converged"] else "not conv.\n") + f"{r['iterations']}", ha="center", fontsize=7)
ax[1].set_ylabel("GLM iterations to 1e-12"); ax[1].set_title("E12: iterative GLM clean() (LIMITATION)", fontsize=9.5); ax[1].set_ylim(100, 2e5); ax[1].grid(alpha=.3, axis="y")
plt.tight_layout(); plt.savefig("eglm_fig.png", dpi=200)
