# EGLM-01 addendum

Frozen kernel `d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713` unchanged; the frozen EGLM-01 run is not modified.
CPU leg: raw JSON. GPU leg (NVIDIA L4): console transcript, because the raw JSON and full sanitizer logs were not exported.

## A1 E12 restated (identical on CPU and GPU)

Iterative GLM clean() (alpha=0.2, CFL 0.4, tol 1e-12, cap 30000): converged on annulus 9x12x7, axis 9x12x7, annulus 24x32x16, axis 24x32x16; NOT converged on axis 48x64x8 within 30000 iterations (2.43e-02 -> 2.78e-08). Measured iteration growth from 9 to 24 radial cells: annulus ~N^1.87, axis ~N^1.64. Classification: convergence-rate scaling restriction of explicit GLM used as a standalone cleaner (pseudo-time step set by the smallest cell, 0.5 dr dphi at the axis); not a correctness failure (all runs finite; divergence decreased overall but not at every check: annulus 9x12x7 1 increases of 62 checks, max ratio 1.027, axis 9x12x7 56 increases of 231 checks, max ratio 1.409, axis 24x32x16 126 increases of 1147 checks, max ratio 2.518, axis 48x64x8 241 increases of 3001 checks, max ratio 1.629). Production guidance: on-demand cleaning uses project(); clean() is not recommended on large or axis grids.

| grid | iterations | converged | final | checks with an increase | max rise |
|---|---|---|---|---|---|
| annulus 9x12x7 | 610 | True | 7.48e-13 | 1 of 62 | x1.027 |
| axis 9x12x7 | 2300 | True | 9.33e-13 | 56 of 231 | x1.409 |
| annulus 24x32x16 | 3800 | True | 9.98e-13 | 0 of 381 | x0.965 |
| axis 24x32x16 | 11460 | True | 9.93e-13 | 126 of 1147 | x2.518 |
| axis 48x64x8 | 30000 | False | 2.78e-08 | 241 of 3001 | x1.629 |

## A2 project() on large grids: VERIFIED on CPU and GPU

| dtype | grid | before | after (CPU) | circ change | s (CPU) |
|---|---|---|---|---|---|
| float64 | axis 48x64x8 | 3.04e-02 | 3.89e-16 | 2.9e-16 | 0.009 |
| float64 | annulus 64x96x32 | 9.12e-03 | 4.35e-16 | 3.5e-16 | 0.041 |
| float64 | axis 96x128x16 | 1.37e-02 | 5.64e-16 | 2.9e-16 | 0.034 |
| float64 | axis 33x18x17 | 1.78e-02 | 3.81e-16 | 2.7e-16 | 0.002 |
| float64 | annulus 128x64x64 | 5.44e-03 | 5.83e-16 | 3.2e-16 | 0.086 |
| float32 | axis 48x64x8 | 2.89e-02 | 2.04e-07 | nan | 0.003 |
| float32 | annulus 64x96x32 | 9.64e-03 | 2.39e-07 | nan | 0.021 |
| float32 | axis 96x128x16 | 1.46e-02 | 2.86e-07 | nan | 0.025 |
| float32 | axis 33x18x17 | 2.06e-02 | 2.22e-07 | nan | 0.002 |
| float32 | annulus 128x64x64 | 4.75e-03 | 2.21e-07 | nan | 0.064 |

GPU worst: FP64 6.2e-16, FP32 2.9e-7, circulation change 3.5e-16 (thresholds 1e-14, 1e-6, 1e-12).

## A3 compute-sanitizer, large and odd grids (GPU)

12 configurations (FP64 + FP32 x annulus 64x96x32, axis 33x18x17, annulus 17x7x13 (odd nphi), axis 5x2x3, axis 48x64x8, annulus 129x3x1), every kernel incl. project() and glm_step():
memcheck `ERROR SUMMARY: 0 errors`; racecheck `RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)`. Scope: the executed workload.
