# EGLM-01 results: ALADIN EGLM v02

Made 2026-11-20 11:38 UTC.  Source hash frozen and identical on all legs: **True**

- cpu leg kernel sha256 `d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713`
- gpu leg kernel sha256 `d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713`

| Test | Final | cpu | gpu |
|---|---|---|---|
| E01 | VERIFIED | VERIFIED | VERIFIED |
| E02 | VERIFIED | VERIFIED | VERIFIED |
| E03 | VERIFIED | VERIFIED | VERIFIED |
| E04 | VERIFIED | VERIFIED | VERIFIED |
| E05 | VERIFIED | VERIFIED | VERIFIED |
| E06 | VERIFIED | VERIFIED | VERIFIED |
| E07 | VERIFIED | VERIFIED | VERIFIED |
| E08 | VERIFIED | VERIFIED | VERIFIED |
| E09 | VERIFIED | VERIFIED | VERIFIED |
| E10 | VERIFIED | VERIFIED | VERIFIED |
| E11 | VERIFIED | VERIFIED | VERIFIED |
| E12 | LIMITATION | LIMITATION | LIMITATION |
| E13 | VERIFIED | VERIFIED | VERIFIED |
| E14 | VERIFIED | VERIFIED | VERIFIED |
| E15 | VERIFIED | VERIFIED | VERIFIED |
| G1 | VERIFIED | — | VERIFIED |
| G2 | VERIFIED | — | VERIFIED |
| G3 | VERIFIED | — | VERIFIED |
| G4_memcheck | VERIFIED |  |  |
| G5_racecheck | VERIFIED |  |  |

Counts: {'VERIFIED': 19, 'LIMITATION': 1}

## Checks (measured vs predeclared threshold)

- E01 [cpu] worst rel vs oracle: 3.6164e-16 <= 1.0e-13 -> pass
- E01 [cpu] |monitor - UCT-EMF divergence|: 2.2204e-16 <= 1.0e-15 -> pass
- E01 [gpu] worst rel vs oracle: 1.1045e-15 <= 1.0e-13 -> pass
- E01 [gpu] |monitor - UCT-EMF divergence|: 4.4409e-16 <= 1.0e-15 -> pass
- E02 [cpu] FP64 max_norm: 3.7759e-16 <= 1.0e-14 -> pass
- E02 [cpu] FP32 max_norm: 4.1065e-06 <= 2.0e-05 -> pass
- E02 [gpu] FP64 max_norm: 1.6788e-15 <= 1.0e-14 -> pass
- E02 [gpu] FP32 max_norm: 4.0148e-06 <= 2.0e-05 -> pass
- E03 [cpu] worst rel: 4.0299e-16 <= 1.0e-14 -> pass
- E03 [gpu] worst rel: 8.0598e-16 <= 1.0e-14 -> pass
- E04 [cpu] worst rel vs oracle: 0.0000e+00 <= 1.0e-14 -> pass
- E04 [cpu] max change of fixed / axis faces: 0.0000e+00 <= 0.0e+00 -> pass
- E04 [gpu] worst rel vs oracle: 0.0000e+00 <= 1.0e-14 -> pass
- E04 [gpu] max change of fixed / axis faces: 0.0000e+00 <= 0.0e+00 -> pass
- E05 [cpu] worst rel: 4.3222e-16 <= 1.0e-13 -> pass
- E05 [gpu] worst rel: 1.1873e-15 <= 1.0e-13 -> pass
- E06 [cpu] worst rel change of circulations: 5.5511e-15 <= 1.0e-13 -> pass
- E06 [gpu] worst rel change of circulations: 5.5511e-15 <= 1.0e-13 -> pass
- E07 [cpu] worst rel: 3.1609e-16 <= 1.0e-13 -> pass
- E07 [gpu] worst rel: 1.2023e-15 <= 1.0e-13 -> pass
- E08 [cpu] FP64 max_norm after: 5.0330e-16 <= 1.0e-14 -> pass
- E08 [cpu] FP32 max_norm after: 3.0435e-07 <= 1.0e-06 -> pass
- E08 [cpu] min reduction factor (FP64): 5.7714e+13 >= 1.0e+10 -> pass
- E08 [gpu] FP64 max_norm after: 4.6740e-16 <= 1.0e-14 -> pass
- E08 [gpu] FP32 max_norm after: 2.7686e-07 <= 1.0e-06 -> pass
- E08 [gpu] min reduction factor (FP64): 3.8948e+13 >= 1.0e+10 -> pass
- E09 [cpu] worst rel |B - B0|: 6.1260e-16 <= 1.0e-12 -> pass
- E09 [gpu] worst rel |B - B0|: 6.3407e-16 <= 1.0e-12 -> pass
- E10 [cpu] worst rel change: 3.0321e-16 <= 1.0e-14 -> pass
- E10 [gpu] worst rel change: 1.2129e-15 <= 1.0e-14 -> pass
- E11 [cpu] worst rel change of circulations: 4.1285e-16 <= 1.0e-12 -> pass
- E11 [gpu] worst rel change of circulations: 4.1285e-16 <= 1.0e-12 -> pass
- E12 [cpu] small grids converged: 1.0000e+00 == 1.0e+00 -> pass
- E12 [gpu] small grids converged: 1.0000e+00 == 1.0e+00 -> pass
- E13 [cpu] worst rel vs exact decay: 1.0389e-13 <= 1.0e-12 -> pass
- E13 [gpu] worst rel vs exact decay: 1.2960e-13 <= 1.0e-12 -> pass
- E14 [cpu] worst rel deviation of the div-B mode: 5.9813e-16 <= 1.0e-10 -> pass
- E14 [gpu] worst rel deviation of the div-B mode: 5.9770e-16 <= 1.0e-10 -> pass
- E15 [cpu] worst max_norm after: 4.4437e-16 <= 1.0e-14 -> pass
- E15 [gpu] worst max_norm after: 4.8809e-16 <= 1.0e-14 -> pass
- G1 [gpu] FP64: 1.2246e-15 <= 1.0e-13 -> pass
- G1 [gpu] FP32: 6.8559e-07 <= 1.0e-05 -> pass
- G2 [gpu] max |run_i - run_0|: 0.0000e+00 <= 0.0e+00 -> pass
- G3 [gpu] FP64 max_norm after: 4.6740e-16 <= 1.0e-14 -> pass
- G4_memcheck: VERIFIED ========= ERROR SUMMARY: 0 errors
- G5_racecheck: VERIFIED ========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)
