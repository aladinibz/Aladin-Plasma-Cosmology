# ALADIN EGLM v02

The div-B guardian of the native-cylindrical ALADIN GPU MHD Driver.

- **Author:** Mihai Alexandru Bucurenciu (ALADIN) · ORCID 0009-0006-4457-557X
- **Kernel source SHA-256:** `d4753fd84a078a70fd53c0b0095eb3d96086b7cdad51073f33c0e132db854713`
- **Campaign EGLM-01:** 18 tests plus compute-sanitizer. 17 VERIFIED, 1 LIMITATION by design, 0 BLOCKER. Memcheck 0 errors, racecheck 0 hazards.
  - The LIMITATION is E12: the iteration count of the iterative GLM cleaner grows with resolution.
- **Legs:** CPU (g++/OpenMP) and GPU (NVIDIA L4, CuPy 14), FP64 + FP32. One CUDA/C++ source.

## Functions
- `monitor()`, every step: the exact constrained-transport divergence, identical to UCT-EMF's.
- `project()`, on demand: exact discrete Hodge projection. One call takes div B to round-off and leaves edge circulations (the current) unchanged.
- `clean()` / `glm_step()`: the author's GLM splitting, for iterative cleaning.
- `eglm_sources()`: the Dedner EGLM momentum and energy sources.

## Addendum (after review; kernel and frozen run unchanged)
`results/addendum/`, report section 10:
- **A1:** E12 restated per grid. The iterative GLM clean() converged up to 24×32×16 but not on the 48×64×8 axis grid within 30 000 iterations (2.8e-8). Its iterations grow about N^1.6–1.9, and its divergence history is non-monotone. Use project() for on-demand cleaning.
- **A2:** project() on grids up to 128×64×64 is VERIFIED on CPU and GPU: FP64 ≤ 6.2e-16, FP32 ≤ 2.9e-7, circulations kept to 3.5e-16.
- **A3:** compute-sanitizer on 12 large and odd grid configurations: memcheck 0 errors, racecheck 0 hazards.

The GPU leg of the addendum is a verbatim console transcript; the CPU leg is raw JSON.

`code/uct_emf_v02.py` is an unmodified copy of UCT-EMF v02 (Zenodo 24394846), included only as a test dependency. `predecessor/` holds the original EGLM (Zenodo 24291219).

## Reproduce
```
sha256sum -c SHA256SUMS.txt
cd code && python campaign_eglm01.py cpu && python campaign_eglm01.py gpu
compute-sanitizer --tool memcheck  python sanitizer_target_eglm.py
compute-sanitizer --tool racecheck python sanitizer_target_eglm.py
python make_results_eglm.py
```

AI assistant Team: SuperGrok, Claude, ChatGPT
