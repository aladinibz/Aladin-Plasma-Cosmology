# -*- coding: utf-8 -*-
"""
MakeResults for the ALADIN G2 kernel v01 release.

    python make_results_g2.py            # build RESULTS_REPORT.md + results_plots/ from the logs and JSON in this package
    python make_results_g2.py --run      # first re-run the kernel self-test here (CPU; adds GPU legs on a CUDA machine)
    python make_results_g2.py --verify   # only check every file against SHA256SUMS.txt -> verification/checksum_verification.log

Every number in the report is read from files in this package (selftest/*.log, study/results/*.json); nothing is
typed in by hand.  The report states what each result shows and what it does not.
"""
import hashlib, json, os, re, subprocess, sys, datetime, platform

HERE = os.path.dirname(os.path.abspath(__file__))
P = lambda *a: os.path.join(HERE, *a)


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""): h.update(blk)
    return h.hexdigest()


def parse_selftest(path):
    rows, head, summary = [], None, None
    for line in open(path, encoding="utf-8", errors="replace"):
        m = re.match(r"\s+(\S+.*?)\s{2,}([-+0-9.eE]+)\s+\(limit ([-+0-9.eE]+)\)\s+(PASS|FAIL)", line)
        if m: rows.append(dict(name=m.group(1).strip(), value=float(m.group(2)), limit=float(m.group(3)), verdict=m.group(4)))
        if "kernel source SHA-256" in line: head = line.split("SHA-256")[-1].strip()
        if line.startswith("SELF-TEST:"): summary = line.strip()
    return dict(rows=rows, kernel_sha=head, summary=summary)


def verify_manifest():
    os.makedirs(P("verification"), exist_ok=True)
    lines, ok, bad = [], 0, 0
    for ln in open(P("SHA256SUMS.txt")):
        want, name = ln.split(None, 1); name = name.strip()
        fp = P(name[2:] if name.startswith("./") else name)
        got = sha(fp) if os.path.exists(fp) else "MISSING"
        res = "OK" if got == want else "FAILED"; ok += res == "OK"; bad += res != "OK"
        lines.append(f"{name}: {res}")
    log = "\n".join(lines) + f"\n\n{ok} OK, {bad} FAILED  ({datetime.datetime.utcnow().isoformat()}Z, {platform.platform()})\n"
    open(P("verification", "checksum_verification.log"), "w").write(log)
    return ok, bad


def plots(study):
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except Exception:
        return []
    out = []; d = P("results_plots"); os.makedirs(d, exist_ok=True)
    k_un, k_st = study.get("kink_N64.json"), study.get("kink_N64_stab.json")
    if k_un and k_st:
        fig, ax = plt.subplots(1, 2, figsize=(11, 4))
        for key, lab in (("u_rms", "u_rms (classical, order eps)"), ("kink_disp", "kink displacement (order eps)"), ("absReOmega", "<|Re Omega|> (G2, order eps)"), ("Ek", "E_k (order eps^2)")):
            t = [h["t"] for h in k_un["history"]]; v = [h[key] for h in k_un["history"]]
            ax[0].semilogy(t, v, label=lab)
        ax[0].set_xlabel("t"); ax[0].set_title("Unstable Z-pinch: kink growth"); ax[0].legend(fontsize=7)
        for r, lab in ((k_un, "unstable pinch"), (k_st, "stabilised control (B_z = 3)")):
            ax[1].plot([h["t"] for h in r["history"]], [h["calib_mean"] for h in r["history"]], label=lab)
        ax[1].axhline(0.374, color="k", ls=":", lw=1, label="random-gradient baseline")
        ax[1].set_xlabel("t"); ax[1].set_ylabel("<|calib|>"); ax[1].set_title("calib: unstable vs stabilised"); ax[1].legend(fontsize=7)
        fig.tight_layout(); f = os.path.join(d, "kink_precursor_test.png"); fig.savefig(f, dpi=130); plt.close(fig); out.append(f)
    runs = [(n, study[n]) for n in sorted(study) if n.endswith("_g2_results.json")]
    if runs:
        labs, cls, plus_om, plus_cv = [], [], [], []
        for n, r in runs:
            for s in r["scales"]:
                labs.append(f"{n.replace('mhd_', '').replace('_g2_results.json', '')}\nk_l={s['k_l']}")
                cv = s["cv_auc"]; cls.append(cv["classical (Q,R of u, b, z+, z-)"][0]); plus_om.append(cv["classical + Re/Im Omega"][0]); plus_cv.append(cv["classical + calib + vol"][0])
        import numpy as np
        x = np.arange(len(labs)); w = 0.27
        fig, ax = plt.subplots(figsize=(11, 4))
        ax.bar(x - w, cls, w, label="classical invariants"); ax.bar(x, plus_om, w, label="+ Re/Im Omega"); ax.bar(x + w, plus_cv, w, label="+ calib + vol")
        ax.axhline(0.5, color="k", lw=0.8, ls=":"); ax.set_ylim(0.45, 0.7); ax.set_xticks(x); ax.set_xticklabels(labs, fontsize=7)
        ax.set_ylabel("cross-validated AUC, sign of energy flux"); ax.set_title("H1: does G2 add predictive information? (vol gain = gradient magnitude, see report)")
        ax.legend(fontsize=8); fig.tight_layout(); f = os.path.join(d, "H1_energy_flux_prediction.png"); fig.savefig(f, dpi=130); plt.close(fig); out.append(f)
    return out


def table(head, rows):
    return "\n".join(["| " + " | ".join(head) + " |", "|" + "|".join("---" for _ in head) + "|"] + ["| " + " | ".join(str(c) for c in r) + " |" for r in rows])


def main():
    if "--verify" in sys.argv:          # integrity check only: never rewrites files covered by the manifest
        ok, bad = verify_manifest()
        print(open(P("verification", "checksum_verification.log")).read()); sys.exit(0 if bad == 0 else 1)
    if "--run" in sys.argv:
        log = subprocess.run([sys.executable, P("kernel", "g2_karnel_v01.py")], capture_output=True, text=True, cwd=P("kernel"))
        open(P("selftest", "selftest_rerun_here.log"), "w").write(log.stdout + log.stderr)
    logs = {f: parse_selftest(P("selftest", f)) for f in sorted(os.listdir(P("selftest"))) if f.endswith(".log")}
    study = {f: json.load(open(P("study", "results", f))) for f in sorted(os.listdir(P("study", "results"))) if f.endswith(".json")}
    kfile = P("kernel", "g2_karnel_v01.py")
    sys.path.insert(0, P("kernel"))
    try:
        import g2_karnel_v01 as G; ksrc = G.KERNEL_SHA256
    except SystemExit:
        ksrc = "unavailable (import failed)"
    L = []; A = L.append
    A("# ALADIN G2 kernel v01 — Results report")
    A(f"*Generated by `make_results_g2.py` on {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M')} UTC from the files in this package.*\n")
    A("**Status: Experimental diagnostic kernel · implementation verified · diagnostic only (adds no force) · not yet run inside the coupled ALADIN Driver.**\n")
    A("## 1. Identity of the code")
    A(table(["item", "SHA-256", "what it covers"], [
        ["kernel source (CUDA/C++ string `_SRC`)", f"`{ksrc}`", "the arithmetic executed on CPU and GPU; printed by every self-test"],
        ["kernel file `kernel/g2_karnel_v01.py`", f"`{sha(kfile)}`", "the whole Python file: launcher, reference implementation, tests"]]))
    A("\nThe two hashes differ by design: they hash different things.  A self-test log is valid for this release when its printed kernel-source hash equals the first value.\n")
    A("## 2. Self-test results")
    rows = []
    for f, s in logs.items():
        n_pass = sum(r["verdict"] == "PASS" for r in s["rows"]); legs = sorted({m for r in s["rows"] for m in re.findall(r"\[(host|gpu) ", r["name"])})
        rows.append([f, s["summary"] or "no summary line", n_pass, len(s["rows"]) - n_pass, ", ".join(legs) or "algebra only",
                     "matches" if s["kernel_sha"] == ksrc else f"DIFFERS ({s['kernel_sha']})"])
    A(table(["log", "summary", "PASS", "FAIL", "execution legs", "kernel-source hash"], rows))
    main_log = next((s for f, s in logs.items() if "gpu" in f.lower() or "colab" in f.lower()), next(iter(logs.values())))
    groups = {}
    for r in main_log["rows"]:
        g = r["name"].split()[0].rstrip("n"); groups.setdefault(g[0], []).append(r)
    names = dict(A="algebra (octonion identities, G2 3-form, rotation symmetry)", B="Z-pinch reference state", C="helical fields vs independent NumPy reference",
                 D="convergence vs analytic Cartesian oracle", E="gradient-tensor invariants and exact identities", F="invariance, scaling, negative controls")
    A("\nBy group (largest log):\n")
    A(table(["group", "content", "checks", "PASS"], [[g, names.get(g, ""), len(v), sum(x["verdict"] == "PASS" for x in v)] for g, v in sorted(groups.items())]))
    neg = [r for r in main_log["rows"] if "negative control" in r["name"]]
    if neg:
        A("\nNegative controls (must FIRE, i.e. exceed their limit, for the test suite to be able to fail):\n")
        A(table(["check", "measured", "must be >=", "result"], [[r["name"], f"{r['value']:.3e}", f"{r['limit']:.1e}", r["verdict"]] for r in neg]))
    A("\n**What the self-test shows:** the kernel computes what its definitions say, on CPU and GPU, in FP32 and FP64, against references that do not share its code.  "
      "**What it does not show:** it is not a full adversarial campaign; kernel and tests come from the same development team; Driver integration is untested.\n")
    A("## 3. Physics study (independent incompressible pseudo-spectral MHD)")
    mrows = []
    for n, r in study.items():
        if n.endswith("_meta.json"):
            mrows.append([n.replace("_meta.json", ""), r["N"], r["nu"], f"{r['energy_budget_rel_error']:.1e}", f"{max(r['max_div_u'], r['max_div_b']):.1e}", f"{r['snapshot_t']:.3f}"])
    A("Reference simulations (quality checks):\n")
    A(table(["run", "N", "nu = eta", "energy-budget rel. error", "max abs(div)", "snapshot t"], mrows))
    trows = []
    for n, r in study.items():
        if not n.endswith("_g2_results.json"): continue
        for s in r["scales"]:
            cv = s["cv_auc"]; h3 = s["H3_spearman_abs_calib_vs"]; cd = s["calib_distribution"]
            trows.append([n.replace("_g2_results.json", ""), s["k_l"], f"{s['phi_equals_ReOmega']:.0e}", f"{cv['classical (Q,R of u, b, z+, z-)'][0]:.3f}",
                          f"{cv['classical + Re/Im Omega'][0]:.3f}", f"{cv['classical + calib + vol'][0]:.3f}", f"{h3['|j| (current sheets)']:+.3f}", f"{cd['mean |calib|']:.3f}"])
    A("\nH1 / H3 on turbulence (cross-validated AUC for the sign of the local energy flux; random-gradient baseline for mean abs(calib) = 0.374):\n")
    A(table(["run", "k_l", "max abs(Phi - Re Omega)", "AUC classical", "+ Re/Im Omega", "+ calib + vol", "rho(abs calib, abs j)", "mean abs(calib)"], trows))
    ku, ks = study.get("kink_N64.json"), study.get("kink_N64_stab.json")
    if ku and ks:
        tr = ku["t_reach_fraction_of_max"]
        A("\nP1 kink precursor (unstable pure Z-pinch vs stabilised control):\n")
        A(table(["quantity (order eps)", "t to 1 % of max", "t to 10 % of max"], [[k, f"{tr[k]['1%']:.2f}", f"{tr[k]['10%']:.2f}"] for k in ("u_rms", "kink_disp", "absReOmega", "absImOmega")]))
        A(f"\nLinear growth rate (u_rms): {ku['growth_rate_linear_phase']['u_rms']:.2f}; E_k: {ku['growth_rate_linear_phase']['Ek']:.2f} (expected 2x).  "
          f"Early calib shift: unstable run t = {ku['calib_shift_onset_3sigma']:.2f}, stabilised control t = {ks['calib_shift_onset_3sigma']:.2f} (also present without a kink).")
    A("\n| Hypothesis | Outcome |\n|---|---|\n| H1: Re/Im Omega predict energy-transfer direction beyond classical invariants | negative |\n"
      "| H1b: vol / calib add information | negative (vol's gain equals plain gradient magnitude) |\n| H3: calib marks current sheets / vortices / alignment | negative |\n"
      "| P1: G2 is an early kink precursor | negative |\n")
    A("**Reading.** In the regimes tested the G2 diagnostics are an exact, frame-independent geometric re-expression of known MHD gradient invariants. "
      "Untested: compressible MHD, forced high-Reynolds turbulence, Hall MHD, coupled ALADIN Driver runs.\n")
    figs = plots(study)
    if figs:
        A("## 4. Figures")
        for f in figs: A(f"![{os.path.basename(f)}](results_plots/{os.path.basename(f)})")
    A("\n## 5. Integrity")
    A("`SHA256SUMS.txt` covers every file of the package except itself and the `verification/` folder (which records the check of the other files, so it cannot be listed without circularity).  Verify with `sha256sum -c SHA256SUMS.txt` or `python make_results_g2.py --verify`.\n")
    open(P("RESULTS_REPORT.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
