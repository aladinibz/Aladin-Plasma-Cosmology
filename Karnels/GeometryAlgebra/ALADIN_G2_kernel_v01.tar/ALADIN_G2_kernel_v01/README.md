# ALADIN G2 kernel v01 — geometry / octonion-algebra diagnostics for the cylindrical Z-pinch Driver

**Kernel 03 of the ALADIN Driver.  Status: Experimental · implementation verified (self-test 122/122, CPU + GPU).**

| | |
|---|---|
| File | `kernel/g2_karnel_v01.py` |
| Kernel source SHA-256 | `f96128b54a8e4fcc913f171fc386171028a8e40a2ee1f9a6d8f694c2243fab5f` (printed by the self-test) |
| File SHA-256 | `98c8680baaf318d4461602f6ab927a87693a6e525eab35dfcda4eff4c0ddf823` |
| Language / backends | Python 3 + one CUDA/C++ source compiled with CuPy NVRTC (GPU) and g++ (CPU); FP32 and FP64 |
| Grid | ALADIN staggered cylindrical Z-pinch grid (identical contract to `uct_curl.py` v1.3) |
| Role | **Diagnostic only.** Reads the plasma state, writes diagnostic fields; adds no force and changes no state |
| License | MIT |

---

## 1. What the kernel computes

Each cell's state is mapped to a unit-free imaginary octonion with a **G2-covariant embedding**
(velocity `u = v / v_ref` in Im H, Alfvén field `b = B / (sqrt(rho) v_ref)` in Im(H)·ℓ, normalised cross helicity on ℓ).
Spatial rotations then act as a subgroup of G2, so every φ-based output is independent of how the axes are oriented.

Outputs (cell-centred, interior only; select with `run_g2(..., outputs=(...))`):

| Output | Meaning |
|---|---|
| `Phi` | pull-back of the G2 3-form φ to physical space, φ(∂_r o, r⁻¹∂_φ o, ∂_z o) |
| `vol`, `calib` | 3-volume of the gradient frame in the 7-d state space; `calib = Phi / vol` ∈ [−1, 1] (±1 = associative 3-plane, Harvey & Lawson 1982) |
| `ident`, `decomp` | built-in consistency checks in every cell (Harvey–Lawson identity; SU(3) split) — must be round-off |
| `P_u Q_u R_u`, `P_b Q_b R_b` | standard gradient-tensor invariants of ∇u and ∇b (connection terms of the cylindrical geometry included) |
| `R_zp`, `R_zm` | third invariants of the Elsässer gradients ∇(u ± b) |
| `Re_Omega`, `Im_Omega` | Re / Im det ∇(u + i b) (holomorphic volume form of C³) |
| `omega_sigma`, `sigma`, `divB` | Kähler-form term; normalised cross helicity σ_c; staggered finite-volume ∇·B (same discretisation as CT / E-GLM) |

`galilean=True` (default) removes σ_c from the gradients: every output is then invariant under a constant velocity boost and
scales exactly with `v_ref`. `galilean=False` keeps the full 7-slot form (frame-dependent; kept for comparison).

## 2. Exact results (proved numerically to round-off, checked on every run)

* φ is evaluated on genuine octonions: alternativity, Moufang, norm composition, inverse — all to ~4e-16.
* **Φ = Re Ω − ω_σ** (the SU(3) ⊂ G2 decomposition φ = Re Ω + dt∧ω, realised in the plasma state).
* **Re Ω = ½(R_z+ + R_z−) − 2 R_u**, **Im Ω = −½(R_z+ − R_z−) + 2 R_b**.
* In the Galilean mode **Φ = Re Ω**: the G2 3-form is exactly a specific combination of the Elsässer third invariants.
* Pure flow: Φ = det ∇u = −R_u. Pure magnetic field (u = 0): Φ = 0. Axisymmetric z-independent states (a pure Z-pinch): Φ = vol = 0.

## 3. Verification — what was tested

`python kernel/g2_karnel_v01.py` runs the full self-test (CPU always; GPU legs when CuPy + a CUDA device are present).
Logs: `selftest/selftest_CPU_GPU_Colab.log` (**122/122**, NVIDIA GPU on Google Colab), `selftest/selftest_host_CPU.log` (67/67, CPU only).

| Group | Checks | Reference (independent of the kernel) |
|---|---|---|
| A — algebra | alternativity, Moufang, norm composition, inverse, φ alternating, calibration bound, Harvey–Lawson identity, associative plane, rotation = G2 symmetry | random octonions; exact identities |
| B — Z-pinch | ∇·B = 0, Φ = vol = 0, σ = 0, ghost cells untouched | analytic Z-pinch B_φ = a r |
| C — helical fields (axis and annulus grids) | ∇·B to round-off; Φ, vol, σ, calib vs a separate vectorised NumPy implementation; calib ≤ 1; identity per cell | edge vector potential (exact discrete ∇·B = 0); independent float64 reference |
| D — convergence | Φ vs an analytic oracle computed in Cartesian coordinates: observed order **1.97** | 6th-order derivatives of the closed-form fields |
| E — invariants | 11 invariants vs reference; SU(3) split; Elsässer forms; linear fields → exact constants (order 1.95) | independent NumPy; analytic constants |
| F — invariance & controls | exact v_ref scaling; constant-boost invariance (1.4e-13); density ×1e−8 … ×1e8; output selection; **negative controls**: full mode fails boost (18 %) and scaling (9 %); the old v55 table is detected as non-octonion | analytic transformations |

Every check has a threshold fixed in the source; the negative controls show the tests do fail when the property is absent.

**What the self-test does NOT establish:** it is not a full adversarial campaign (the standard applied to UCT-CURL);
the kernel and its tests were written by the same development team (no independent review yet); the kernel has not yet been run
inside the coupled ALADIN Driver.

## 4. Physics study (study/)

The G2 diagnostics were tested on turbulence and on a kinking Z-pinch produced by an independent incompressible
pseudo-spectral MHD code (`study/code/mhd_spectral.py`, `kink_test.py`; energy budgets closed to ≤ 1.3e-6, ∇·u, ∇·b ≤ 2e-14).
Full results: `study/README_G2_STUDY.md` and `study/results/*.json`.

| Hypothesis | Outcome |
|---|---|
| H1 — sign of Re/Im Ω predicts local energy-transfer direction beyond the classical invariants | **Negative** (adds ≤ 0.004 cross-validated AUC; 64³, 128³, three regimes) |
| H1b — vol / calib add predictive information | **Negative** (vol's gain = gradient magnitude; calib ≤ 0.003) |
| H3 — calib marks current sheets / vortices / Alfvénic alignment | **Negative** (balanced turbulence: calib ≡ random-gradient baseline; high-σ_c excess ~97 % explained by u–b alignment) |
| P1 — G2 is an early precursor of the m = 1 kink | **Negative** (G2 signals cross thresholds after u_rms; the early calib shift also appears in a stabilised control) |

Positive observation: calib drops sharply (0.62 → 0.41) at the kink's transition to nonlinear saturation, simultaneously
with the classical signals.

**Interpretation.** In the regimes tested, the G2 diagnostics are a correct, frame-independent and exact geometric
re-expression of known MHD gradient invariants; they did not reveal additional physics. Not ruled out: compressible MHD,
forced high-Reynolds-number turbulence, Hall MHD, and coupled ALADIN Driver runs.

## 5. Use

```python
import g2_karnel_v01 as G2
out = G2.run_g2(F, r_faces, r_centers, dr, dphi, dz, nr, nphi, nz, g=2, v_ref=1.0,
                backend="auto", outputs=("Re_Omega", "Im_Omega", "calib"), galilean=True)
```
`F` holds `rho, vr, vphi, vz` (cell centres) and `Br, Bphi, Bz` (staggered faces); see the module docstring for the exact
shapes. The kernel reads no ghost values (φ wraps periodically; r and z use one-sided differences on the boundary layers).
FP32 is adequate for maps; use FP64 for invariant statistics (cubic invariants: ~5e-4 relative in FP32).

## 6. Changes relative to the previous G2 kernel (v55)

1. The v55 Fano-plane orientation was not an octonion algebra (alternativity violated by up to 43, Moufang by up to 159).
2. v55 evaluated φ(o, o, o), which is identically zero; its reported "φ reduction" compared two different quantities.
3. v55 combined velocity and magnetic field with different units; v01 is unit-free (Alfvénic).
4. v55's energy source was 90 % unbalanced by construction; v01 adds no source.
5. v55's (v_φ² − B_φ²)/r terms are the standard MHD geometric sources (belonging to the RESIDUAL kernel); removed.
6. v55 used a collocated grid starting at r = 0.05; v01 uses the ALADIN staggered Z-pinch grid, including the axis.
7. v55 placed (v, B) in octonion slots in an arbitrary order, so φ changed by up to ~15 under a rotation of the axes; v01 is rotation invariant.
8. New: Galilean mode, gradient-tensor invariants, output selection, per-cell consistency checks, full self-test.

**Results obtained with v55 should not be relied on.**

## 7. Reproduce

```bash
cd kernel && python g2_karnel_v01.py                       # self-test (adds GPU legs automatically on a CUDA machine)
cd study/code && python mhd_spectral.py 64 6e-3 1.6 && python g2_turbulence_test.py mhd_N64_snapshot.npz 4 8
# full list of study commands: study/README_G2_STUDY.md
```
`SHA256SUMS.txt` lists every file in this release.

## 8. Results report and integrity

* `RESULTS_REPORT.md` and `results_plots/` are generated by `python make_results_g2.py` from the logs and JSON files in
  this package (no hand-typed numbers). `python make_results_g2.py --run` re-runs the self-test first.
* Two hashes identify the kernel: the **kernel-source** hash (`f96128b5...`, the CUDA/C++ arithmetic, printed by every
  self-test) and the **file** hash (`98c8680b...`, the whole `.py`). They differ by design.
* `SHA256SUMS.txt` covers every file except itself and the `verification/` folder (which records the check of the
  other files and therefore cannot be listed without circularity). Verify with `sha256sum -c SHA256SUMS.txt` or
  `python make_results_g2.py --verify`; all entries must report `OK`.
  `verification/checksum_verification.log` is the check made when this archive was built.
* Checksums show that files are unchanged; they do not by themselves show that the computations or conclusions are correct.

## 9. Credits

Mihai Alexandru Bucurenciu (ALADIN) — research direction, ALADIN Driver, GPU execution of the verification runs.
Kernel rewrite, verification suite and physics study developed with AI assistance (Claude, Anthropic).
Part of the ALADIN Plasma Cosmology project: https://github.com/aladinibz/Aladin-Plasma-Cosmology
