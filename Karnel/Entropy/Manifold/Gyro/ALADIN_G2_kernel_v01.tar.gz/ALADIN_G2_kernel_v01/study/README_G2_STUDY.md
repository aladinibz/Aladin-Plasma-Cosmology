# G2 diagnostics on MHD turbulence and a kinking Z-pinch — evidence bundle (2026-11-19)

Kernel under study: `kernel/g2_karnel_v01.py`, kernel source SHA-256 `f96128b54a8e4fcc913f171fc386171028a8e40a2ee1f9a6d8f694c2243fab5f`
(self-test 122/122 on CPU + GPU, run by the author on Colab).  Reference simulations: `mhd_spectral.py` and `kink_test.py`,
an incompressible pseudo-spectral MHD code written for this study, independent of ALADIN.

## Exact results (algebra, verified to round-off on every snapshot)
* Galilean mode: Phi = Re Omega = Re det grad(u + i b) = (R_z+ + R_z-)/2 - 2 R_u ;  Im Omega = -(R_z+ - R_z-)/2 + 2 R_b
* measured |Phi - Re Omega| / max|Re Omega| <= 7e-16 on all turbulence snapshots

## Hypotheses tested and outcomes
| # | Hypothesis | Data | Outcome |
|---|---|---|---|
| H1 | sign of Re/Im Omega predicts local energy-transfer direction beyond classical invariants | 64^3 (balanced, guide field B0=1, sigma_c=0.8), 128^3, filter scales k_l = 4, 8, 16 | **Negative.** classical CV-AUC ~0.60; + Re/Im Omega changes by <= 0.004 (expected: exact linear combinations) |
| H1b | vol / calib add information | same | **Negative.** vol's gain equals plain gradient magnitude abs(grad)^3 (0.653 vs 0.657); calib adds <= 0.003 |
| H3 | abs(calib) marks current sheets / vortices / Alfvenic alignment | same | **Negative.** abs(rho) < 0.04 (balanced). Balanced turbulence: calib distribution = random-gradient baseline (mean 0.377 vs 0.374). sigma_c=0.8: excess (0.504) is ~97 % explained by grad-u / grad-b alignment (random baseline at the measured alignment 0.90: 0.490) |
| P1 | G2 quantity is a precursor of the m=1 kink | pure Z-pinch (unstable, gamma ~ 2.3) vs Bz=3 (stable control) | **Negative.** Linear-order G2 quantities reach 1 % / 10 % of their maximum *later* than u_rms (2.66 / 3.48 vs 2.33 / 3.16). The early calib shift (t ~ 0.2) also occurs, larger, in the stable control: it is noise reorganisation, not a precursor |

Positive observations: calib drops sharply (0.62 -> 0.41) exactly at the kink's transition to nonlinear saturation, but
simultaneously with the classical signals, not before.  When grad u = grad b exactly, calib = 1/sqrt(2) (fixed G2 angle).

## Caveats (what is NOT ruled out)
Incompressible, decaying, moderate Reynolds number (64^3, 128^3), single snapshots per run, one kink configuration.
Compressible MHD, forced stationary turbulence, much higher Reynolds numbers, Hall MHD and real ALADIN Driver runs are untested.

## Quality checks of the reference simulations
Energy budget closure 4e-7 .. 1.3e-6 relative; max abs(div u), abs(div b) <= 1.8e-14; kink growth: E_k grows at 2 gamma (5.46 vs 2 x 2.31).

## Reproduce (run from study/code; the kernel is found in ../../kernel)
    python mhd_spectral.py 64 6e-3 1.6 ;  B0=1.0 TAG=_B0 python mhd_spectral.py 64 6e-3 1.6 ;  SIGC=0.8 TAG=_sig08 python mhd_spectral.py 64 6e-3 1.6
    python mhd_spectral.py 128 2.5e-3 1.4
    python g2_turbulence_test.py mhd_N64_snapshot.npz 4 8      (and the other snapshots; 128: k_l = 8 16)
    python controls.py ;  python align_base.py
    python kink_test.py 64 3e-3 14 ;  BZ=3 TAG=_stab python kink_test.py 64 3e-3 14
Snapshots (.npz) are not included (size); they are regenerated bit-for-bit by the commands above (fixed seeds).
