# -*- coding: utf-8 -*-
"""
Independent reference simulation for the G2 study: incompressible MHD, pseudo-spectral, triply periodic
box [0, 2pi)^3, 2/3 de-aliasing, RK4 with exact integrating factor for viscosity / resistivity.
Units: mu0 = 1, rho = 1, so b = B is already in Alfven-speed units.

    du/dt = P[ u x w + j x b ] + nu lap u          (w = curl u, j = curl b, P = Leray projector)
    db/dt = curl(u x b)        + eta lap b

Self-checks printed at the end: div u, div b (spectral, round-off), and the energy budget
dE/dt = -nu <|w|^2> - eta <|j|^2> integrated over the run (ideal invariants conserved up to dissipation).
This code is NOT part of ALADIN; it exists so the G2 diagnostics can be tested on turbulence that
ALADIN did not produce.
"""
import numpy as np, scipy.fft as sf, json, sys, time

N = int(sys.argv[1]) if len(sys.argv) > 1 else 64
NU = ETA = float(sys.argv[2]) if len(sys.argv) > 2 else 6e-3
T_END = float(sys.argv[3]) if len(sys.argv) > 3 else 1.6
SEED = 20261119
import os
B0 = float(os.environ.get("B0", "0"))            # uniform guide field along z (Alfven units)
SIGC = float(os.environ.get("SIGC", "0"))        # target initial cross helicity sigma_c = 2<u.b>/<u^2+b^2>
TAG = os.environ.get("TAG", "")
W = 2  # fft workers

k1 = np.fft.fftfreq(N, 1.0/N); kz = np.fft.rfftfreq(N, 1.0/N)
KX, KY, KZ = np.meshgrid(k1, k1, kz, indexing="ij")
K = np.stack([KX, KY, KZ]); K2 = KX**2 + KY**2 + KZ**2; K2i = np.where(K2 > 0, 1.0/np.where(K2 > 0, K2, 1), 0.0)
DEAL = (np.abs(KX) < N/3) & (np.abs(KY) < N/3) & (np.abs(KZ) < N/3)
fwd = lambda a: sf.rfftn(a, axes=(-3, -2, -1), workers=W)
inv = lambda a: sf.irfftn(a, s=(N, N, N), axes=(-3, -2, -1), workers=W)

def proj(F):
    return F - K*np.sum(K*F, 0)*K2i

def curl_hat(F):
    return 1j*np.stack([K[1]*F[2] - K[2]*F[1], K[2]*F[0] - K[0]*F[2], K[0]*F[1] - K[1]*F[0]])

def cross(a, b):
    return np.stack([a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0]])

def init(rng, k0=3.0, E0=0.5):
    def field():
        F = (rng.normal(size=(3,) + K2.shape) + 1j*rng.normal(size=(3,) + K2.shape))
        kk = np.sqrt(K2); amp = kk**2*np.exp(-(kk/k0)**2)         # E(k) ~ k^4 exp(-2 k^2/k0^2)
        F = proj(F*amp)*DEAL; f = inv(F); f *= np.sqrt(2*E0/np.mean(np.sum(f**2, 0))); return fwd(f)
    return field(), field()

def rhs(U, B):
    u, b = inv(U), inv(B); w, j = inv(curl_hat(U)), inv(curl_hat(B))
    bt = b.copy(); bt[2] += B0                                       # total field = guide + fluctuation
    NU_ = proj(fwd(cross(u, w) + cross(j, bt)))*DEAL
    NB_ = curl_hat(fwd(cross(u, bt)))*DEAL
    return NU_, NB_

def energy(U, B):
    u, b = inv(U), inv(B); return 0.5*np.mean(np.sum(u*u, 0)), 0.5*np.mean(np.sum(b*b, 0))

def dissipation(U, B):
    w, j = inv(curl_hat(U)), inv(curl_hat(B)); return NU*np.mean(np.sum(w*w, 0)) + ETA*np.mean(np.sum(j*j, 0))

def main():
    rng = np.random.default_rng(SEED); U, B = init(rng)
    if SIGC != 0:                                                    # b = cos(t) u + sin(t) b_indep  ->  sigma_c ~ cos(t)
        th = np.arccos(np.clip(SIGC, -1, 1)); B = np.cos(th)*U + np.sin(th)*B
    t, hist = 0.0, []
    E0 = sum(energy(U, B)); diss_int = 0.0; eps_prev = dissipation(U, B)
    t0 = time.time(); best = (-1, None)
    while t < T_END - 1e-12:
        u, b = inv(U), inv(B); vmax = np.max(np.sqrt(np.sum(u*u, 0))) + np.max(np.sqrt(np.sum(b*b, 0))) + abs(B0)
        dt = min(0.4*(2*np.pi/N)/vmax, T_END - t)
        E1 = np.exp(-NU*K2*dt/2); E2 = E1*E1
        a1 = rhs(U, B)
        a2 = rhs(E1*(U + 0.5*dt*a1[0]), E1*(B + 0.5*dt*a1[1]))
        a3 = rhs(E1*U + 0.5*dt*a2[0], E1*B + 0.5*dt*a2[1])
        a4 = rhs(E2*U + dt*E1*a3[0], E2*B + dt*E1*a3[1])
        U = E2*U + dt/6*(E2*a1[0] + 2*E1*(a2[0] + a3[0]) + a4[0])
        B = E2*B + dt/6*(E2*a1[1] + 2*E1*(a2[1] + a3[1]) + a4[1])
        eps = dissipation(U, B); diss_int += 0.5*(eps + eps_prev)*dt; eps_prev = eps; t += dt
        Eu, Eb = energy(U, B); hist.append((t, Eu, Eb, eps))
        if eps > best[0]: best = (eps, t, U.copy(), B.copy())
    Ef = sum(energy(U, B))
    eps_max, t_max, Us, Bs = best
    divu = np.max(np.abs(inv(1j*np.sum(K*Us, 0)))); divb = np.max(np.abs(inv(1j*np.sum(K*Bs, 0))))
    budget = abs((E0 - Ef) - diss_int)/(E0 - Ef)
    np.savez_compressed(f"mhd_N{N}{TAG}_snapshot.npz", u=inv(Us).astype(np.float64), b=inv(Bs).astype(np.float64), t=t_max, nu=NU, eta=ETA)
    meta = dict(N=N, nu=NU, eta=ETA, seed=SEED, t_end=T_END, steps=len(hist), wall_s=round(time.time() - t0, 1),
                snapshot_t=t_max, snapshot_dissipation=eps_max, energy_budget_rel_error=budget,
                max_div_u=float(divu), max_div_b=float(divb), history=hist[::max(1, len(hist)//60)])
    json.dump(meta, open(f"mhd_N{N}{TAG}_meta.json", "w"), indent=1)
    print(f"N={N} nu=eta={NU} steps={len(hist)} wall={meta['wall_s']}s  snapshot at peak dissipation t={t_max:.3f}")
    print(f"energy budget rel. error {budget:.2e}   max|div u| {divu:.1e}   max|div b| {divb:.1e}")

if __name__ == "__main__":
    main()
