import json,sys
for f in sys.argv[1:]:
    r=json.load(open(f))
    for s in r['scales']:
        cv=s['cv_auc']; h=s['H3_spearman_abs_calib_vs']; c=s['calib_distribution']
        print(f"{f.split('_g2')[0]:16s} k_l={s['k_l']}: fwd {s['frac_forward']:.2f} | phi=ReO {s['phi_equals_ReOmega']:.0e} | AUC classical {cv['classical (Q,R of u, b, z+, z-)'][0]:.3f}  +ReIm {cv['classical + Re/Im Omega'][0]:.3f}  +calib,vol {cv['classical + calib + vol'][0]:.3f}  calib+vol only {cv['calib + vol only'][0]:.3f}"
              f" | rho(|calib|,|j|) {h['|j| (current sheets)']:+.3f} (|w|) {h['|omega| (vortices)']:+.3f} (align) {h['|cos(u,b)| (Alfvenic alignment)']:+.3f} | mean|calib| {c['mean |calib|']:.3f} q90 {c['q90']:.3f}")
