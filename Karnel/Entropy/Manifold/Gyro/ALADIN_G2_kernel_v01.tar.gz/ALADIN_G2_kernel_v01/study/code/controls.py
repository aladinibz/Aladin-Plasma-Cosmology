import numpy as np, sys, json
import os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "kernel")); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.argv=['x','mhd_N64_snapshot.npz']
import g2_turbulence_test as M
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
import scipy.stats as st
G2=M.G2; T=G2._struct_tensor(); rng=np.random.default_rng(11)
# (1) random-frame baseline for calib: Gaussian random gradient tensors A, B
A=rng.normal(size=(200000,3,3)); B=rng.normal(size=(200000,3,3))
Dv=np.stack([G2.embed(A[:,:,j],B[:,:,j],np.zeros(len(A))) for j in range(3)],-1)
vol=np.prod(np.linalg.svd(Dv,compute_uv=False),-1); phi=np.einsum('ni,nj,nk,ijk->n',Dv[...,0],Dv[...,1],Dv[...,2],T)
ac=np.abs(phi/vol); print("random Gaussian gradients: mean|calib| %.3f q50 %.3f q90 %.3f q99 %.3f"%(ac.mean(),*np.quantile(ac,[.5,.9,.99])))
# (2) is vol's predictive gain just gradient magnitude?
u,b,K,N=M.u,M.b,M.K,M.N
for kl in (4,8):
    ell=2*np.pi/kl; zp,zm=u+b,u-b; zpb,zmb=M.filt(zp,ell),M.filt(zm,ell); Gp,Gm=M.grad(zpb),M.grad(zmb)
    Pp=0;Pm=0
    for i in range(3):
        for j in range(3):
            Pp=Pp-(M.filt(zm[j]*zp[i],ell)-zmb[j]*zpb[i])*Gp[i,j]; Pm=Pm-(M.filt(zp[j]*zm[i],ell)-zpb[j]*zmb[i])*Gm[i,j]
    Pi=0.5*(Pp+Pm); A=0.5*(Gp+Gm); B=0.5*(Gp-Gm)
    idx=rng.choice(Pi.size,120000,replace=False); y=Pi.reshape(-1)[idx]; cls=(y>0).astype(int)
    feats={}
    for nm,Mx in (('u',A),('b',B),('zp',A+B),('zm',A-B)):
        Q,R=M.QR(Mx); feats['Q_'+nm]=Q.reshape(-1)[idx]; feats['R_'+nm]=R.reshape(-1)[idx]
    Af=A.reshape(3,3,-1)[:,:,idx]; Bf=B.reshape(3,3,-1)[:,:,idx]
    Dv=np.stack([G2.embed(Af[:,j].T,Bf[:,j].T,np.zeros(len(idx))) for j in range(3)],-1)
    sv=np.linalg.svd(Dv,compute_uv=False); vol=np.prod(sv,-1); phi=np.einsum('ni,nj,nk,ijk->n',Dv[...,0],Dv[...,1],Dv[...,2],T)
    feats['vol']=vol; feats['calib']=phi/vol
    gnorm=np.sqrt(np.sum(Af**2,(0,1))+np.sum(Bf**2,(0,1))); feats['gradnorm3']=gnorm**3
    feats['Su2']=np.sum((0.5*(Af+np.transpose(Af,(1,0,2))))**2,(0,1)); feats['Sb2']=np.sum((0.5*(Bf+np.transpose(Bf,(1,0,2))))**2,(0,1))
    groups=((idx//(N*N))*5)//N
    tf=lambda v,k: np.cbrt(v) if k[0] in 'Rvg' else (np.sign(v)*np.sqrt(np.abs(v)) if k[0] in 'QS' else v)
    def cv(keys):
        Mx=np.stack([tf(feats[k],k) for k in keys],1); a=[]
        for g in range(5):
            tr,te=groups!=g,groups==g; sc=StandardScaler().fit(Mx[tr]); m=LogisticRegression(max_iter=3000).fit(sc.transform(Mx[tr]),cls[tr])
            a.append(roc_auc_score(cls[te],m.predict_proba(sc.transform(Mx[te]))[:,1]))
        return '%.3f +- %.3f'%(np.mean(a),np.std(a))
    base=['Q_u','R_u','Q_b','R_b','Q_zp','R_zp','Q_zm','R_zm']
    print(f"\nk_l={kl}: spearman(vol, gradnorm^3) = {st.spearmanr(vol,feats['gradnorm3'])[0]:.3f}")
    for lab,keys in (('classical',base),('classical + vol',base+['vol']),('classical + |grad|^3',base+['gradnorm3']),
                     ('classical + strain mags |S_u|^2,|S_b|^2',base+['Su2','Sb2']),
                     ('classical + strain mags + vol',base+['Su2','Sb2','vol']),('classical + strain mags + vol + calib',base+['Su2','Sb2','vol','calib'])):
        print('  ',lab,cv(keys))
