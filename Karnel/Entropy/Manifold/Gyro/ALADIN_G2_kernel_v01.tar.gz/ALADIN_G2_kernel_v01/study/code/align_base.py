import numpy as np, sys
import os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "kernel")); import g2_karnel_v01 as G2
T=G2._struct_tensor(); rng=np.random.default_rng(3)
def calib_stats(A,B):
    Dv=np.stack([G2.embed(A[:,:,j],B[:,:,j],np.zeros(len(A))) for j in range(3)],-1)
    vol=np.prod(np.linalg.svd(Dv,compute_uv=False),-1); phi=np.einsum('ni,nj,nk,ijk->n',Dv[...,0],Dv[...,1],Dv[...,2],T)
    return np.abs(phi/vol)
n=200000; A=rng.normal(size=(n,3,3)); C=rng.normal(size=(n,3,3))
for c in (0.0,0.5,0.7,0.8,0.9,1.0):
    B=c*A+np.sqrt(1-c*c)*C; ac=calib_stats(A,B)
    print(f"random gradients, corr(grad u, grad b) = {c:.1f}: mean|calib| {ac.mean():.3f}  q90 {np.quantile(ac,.9):.3f}")
# the turbulence snapshot: measured gradient correlation at k_l = 8
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.argv=['x','mhd_N64_sig08_snapshot.npz']
import g2_turbulence_test as M
ell=2*np.pi/8; ub=M.filt(M.u,ell); bb=M.filt(M.b,ell); A=M.grad(ub).reshape(9,-1); B=M.grad(bb).reshape(9,-1)
print("turbulence (sigma_c = 0.8 run): pointwise corr of grad u and grad b entries =", round(float(np.sum(A*B)/np.sqrt(np.sum(A*A)*np.sum(B*B))),3))
idx=rng.choice(A.shape[1],100000,replace=False); At=A[:,idx].T.reshape(-1,3,3); Bt=B[:,idx].T.reshape(-1,3,3)
# local alignment of the two gradient tensors vs |calib|
loc=np.sum(At*Bt,(1,2))/np.sqrt(np.sum(At*At,(1,2))*np.sum(Bt*Bt,(1,2))); ac=calib_stats(At,Bt)
import scipy.stats as st; print("spearman(|calib|, |local grad-u/grad-b alignment|) =", round(st.spearmanr(ac,np.abs(loc))[0],3))
