# -*- coding: utf-8 -*-
"""
Z-pinch kink test for the G2 diagnostics (independent of ALADIN; incompressible pseudo-spectral MHD).

Equilibrium: current column along z at the box centre, flux function A_z = A0 exp(-r^2/a^2)
(B = curl(A_z z_hat) is purely azimuthal, B_z = 0: a pure Z-pinch).  J x B is radial, so the
incompressible pressure balances it exactly: the column starts in equilibrium (net current is zero in
the periodic box: the Gaussian core carries +I, a weak return current flows outside).
A pure Z-pinch is ideal-MHD unstable to the m = 1 kink.  A random solenoidal velocity of amplitude
1e-4 seeds it.

Diagnostics vs time, grouped by their ORDER in the perturbation amplitude eps (fair comparison):
  order eps  : u_rms, kink displacement (rms over z of the current-centroid offset),
               <|Re Omega|>, <|Im Omega|>  (G2: linear in eps via tr(grad u cof(grad b0)))
  order eps^2: kinetic energy E_k, enstrophy
  order eps^0: <|calib|> (amplitude-free: it measures only the SHAPE of the gradient frame)
A G2 precursor would mean: a G2 quantity leaves its noise floor earlier than the classical quantity of
the same order.  The test reports onset times (first time a quantity exceeds 10x its initial value,
or for calib a 3-sigma shift from its initial distribution) and linear growth rates.
"""
import numpy as np, scipy.fft as sf, json, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "kernel"))
import g2_karnel_v01 as G2

N = int(sys.argv[1]) if len(sys.argv) > 1 else 64
NU = ETA = float(sys.argv[2]) if len(sys.argv) > 2 else 3e-3
T_END = float(sys.argv[3]) if len(sys.argv) > 3 else 14.0
import os
A0, AW, EPS = 1.2, 0.7, 1e-4
BZ = float(os.environ.get("BZ", "0"))   # uniform axial field: BZ = 3 gives q ~ 1.4 > 1 (Kruskal-Shafranov stable)
TAG = os.environ.get("TAG", "")
W = 2; SEED = 4242
k1 = np.fft.fftfreq(N, 1.0/N); kz = np.fft.rfftfreq(N, 1.0/N)
K = np.stack(np.meshgrid(k1, k1, kz, indexing="ij")); K2 = np.sum(K**2, 0); K2i = np.where(K2 > 0, 1/np.where(K2 > 0, K2, 1), 0)
DEAL = (np.abs(K[0]) < N/3) & (np.abs(K[1]) < N/3) & (np.abs(K[2]) < N/3)
fwd = lambda a: sf.rfftn(a, axes=(-3, -2, -1), workers=W)
inv = lambda a: sf.irfftn(a, s=(N, N, N), axes=(-3, -2, -1), workers=W)
proj = lambda F: F - K*np.sum(K*F, 0)*K2i
curl_hat = lambda F: 1j*np.stack([K[1]*F[2] - K[2]*F[1], K[2]*F[0] - K[0]*F[2], K[0]*F[1] - K[1]*F[0]])
cross = lambda a, b: np.stack([a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0]])
x = np.arange(N)*2*np.pi/N; X, Y, Z = np.meshgrid(x, x, x, indexing="ij"); Rr2 = (X - np.pi)**2 + (Y - np.pi)**2
T7 = G2._struct_tensor(); rng = np.random.default_rng(SEED)

def rhs(U, B):
    u, b = inv(U), inv(B); w, j = inv(curl_hat(U)), inv(curl_hat(B)); b[2] += BZ
    return proj(fwd(cross(u, w) + cross(j, b)))*DEAL, curl_hat(fwd(cross(u, b)))*DEAL

def grad(V):
    return np.stack([np.stack([inv(1j*K[jj]*V[ii]) for jj in range(3)]) for ii in range(3)])

SUB = rng.choice(N**3, 40000, replace=False)
def diagnostics(U, B, t):
    u, b = inv(U), inv(B); A, Bg = grad(U), grad(B)
    Am = np.moveaxis(A, (0, 1), (-2, -1)).reshape(-1, 3, 3); Bm = np.moveaxis(Bg, (0, 1), (-2, -1)).reshape(-1, 3, 3)
    cd = np.linalg.det(Am + 1j*Bm)
    Pu = -np.trace(Am, axis1=1, axis2=2); Qu = 0.5*(Pu**2 - np.einsum("nab,nba->n", Am, Am)); Ru = -np.linalg.det(Am)
    w = inv(curl_hat(U)); jz = inv(curl_hat(B))[2]
    # kink displacement: centroid of the positive core current in each z slice
    wgt = np.where((jz > 0) & (Rr2 < 1.8**2), jz, 0.0); sw = wgt.sum((0, 1))
    cx = (wgt*(X - np.pi)).sum((0, 1))/sw; cy = (wgt*(Y - np.pi)).sum((0, 1))/sw
    disp = float(np.sqrt(np.mean(cx**2 + cy**2)))
    # calib on a fixed random subsample inside the column region
    As, Bs = Am[SUB], Bm[SUB]
    Dv = np.stack([G2.embed(As[:, :, jj], Bs[:, :, jj], np.zeros(len(SUB))) for jj in range(3)], -1)
    vol = np.prod(np.linalg.svd(Dv, compute_uv=False), -1); phi = np.einsum("ni,nj,nk,ijk->n", Dv[..., 0], Dv[..., 1], Dv[..., 2], T7)
    scale = np.prod(np.linalg.norm(Dv, axis=1), -1); ok = vol > 1e-9*scale; ac = np.abs(np.where(ok, phi/np.where(ok, vol, 1), 0))
    E_spec = np.sum(np.abs(U)**2, 0)*np.where(K[2] == 0, 1.0, 2.0)
    frac_kz1 = float(E_spec[np.abs(K[2]) == 1].sum()/E_spec.sum())
    return dict(t=t, frac_kz1=frac_kz1, u_rms=float(np.sqrt(np.mean(np.sum(u*u, 0)))), kink_disp=disp,
                Ek=float(0.5*np.mean(np.sum(u*u, 0))), enstrophy=float(np.mean(np.sum(w*w, 0))),
                absReOmega=float(np.mean(np.abs(cd.real))), absImOmega=float(np.mean(np.abs(cd.imag))),
                absRu=float(np.mean(np.abs(Ru))), absQu=float(np.mean(np.abs(Qu))),
                calib_mean=float(ac[ok].mean()), calib_sem=float(ac[ok].std()/np.sqrt(ok.sum())), calib_q90=float(np.quantile(ac[ok], 0.9)),
                Eb=float(0.5*np.mean(np.sum(b*b, 0))))

def main():
    Az = A0*np.exp(-Rr2/AW**2); Ahat = fwd(Az)
    B = np.stack([1j*K[1]*Ahat, -1j*K[0]*Ahat, 0*Ahat])*DEAL            # B = curl(Az z_hat)
    u0 = rng.normal(size=(3, N, N, N)); U = proj(fwd(u0))*DEAL*np.exp(-K2/64.0)
    U *= EPS/np.sqrt(np.mean(np.sum(inv(U)**2, 0)))
    b0max = float(np.max(np.sqrt(np.sum(inv(B)**2, 0))))
    t, hist, step, t0 = 0.0, [], 0, time.time()
    hist.append(diagnostics(U, B, t))
    while t < T_END - 1e-12:
        u, b = inv(U), inv(B); vmax = np.max(np.sqrt(np.sum(u*u, 0))) + np.max(np.sqrt(np.sum(b*b, 0))) + abs(BZ)
        dt = min(0.4*(2*np.pi/N)/vmax, T_END - t); E1 = np.exp(-NU*K2*dt/2); E2 = E1*E1
        a1 = rhs(U, B); a2 = rhs(E1*(U + 0.5*dt*a1[0]), E1*(B + 0.5*dt*a1[1]))
        a3 = rhs(E1*U + 0.5*dt*a2[0], E1*B + 0.5*dt*a2[1]); a4 = rhs(E2*U + dt*E1*a3[0], E2*B + dt*E1*a3[1])
        U = E2*U + dt/6*(E2*a1[0] + 2*E1*(a2[0] + a3[0]) + a4[0]); B = E2*B + dt/6*(E2*a1[1] + 2*E1*(a2[1] + a3[1]) + a4[1])
        t += dt; step += 1
        if step % 4 == 0: hist.append(diagnostics(U, B, t))
    hist.append(diagnostics(U, B, t))
    # ---- onset times and growth rates
    tt = np.array([h["t"] for h in hist])
    def onset(key, factor=10.0):
        v = np.array([h[key] for h in hist]); i = np.where(v > factor*v[0])[0]; return float(tt[i[0]]) if len(i) else None
    def rate(key, lo, hi):          # exponential growth rate between two onset-relative thresholds
        v = np.array([h[key] for h in hist]); m = (v > lo*v[0]) & (v < hi*v[0]) & (tt < tt[np.argmax(v)])
        return float(np.polyfit(tt[m], np.log(v[m]), 1)[0]) if m.sum() >= 4 else None
    c0 = hist[0]["calib_mean"]; s0 = hist[0]["calib_sem"]*np.sqrt(40000)/np.sqrt(40000)
    ci = [k for k, h in enumerate(hist) if abs(h["calib_mean"] - c0) > 3*np.hypot(h["calib_sem"], hist[0]["calib_sem"])]
    res = dict(N=N, nu=NU, A0=A0, a=AW, eps=EPS, B0max=b0max, steps=step, wall_s=round(time.time() - t0, 1),
               onset_10x={k: onset(k) for k in ("u_rms", "kink_disp", "absReOmega", "absImOmega", "Ek", "enstrophy", "absRu", "absQu")},
               growth_rate_linear_phase={k: rate(k, 10, 1e3) for k in ("u_rms", "kink_disp", "absReOmega", "absImOmega")} |
                                        {k: rate(k, 100, 1e5) for k in ("Ek", "enstrophy", "absQu", "absRu")},
               calib_initial=c0, calib_shift_onset_3sigma=(float(tt[ci[0]]) if ci else None),
               calib_final=hist[-1]["calib_mean"], history=hist)
    def t_frac(key, f):
        v = np.array([h[key] for h in hist]); i = np.where(v >= f*v.max())[0]; return float(tt[i[0]]) if len(i) else None
    res["t_reach_fraction_of_max"] = {k: {"1%": t_frac(k, 0.01), "10%": t_frac(k, 0.1)} for k in ("u_rms", "kink_disp", "absReOmega", "absImOmega", "Ek", "absRu")}
    res["BZ"] = BZ
    json.dump(res, open(f"kink_N{N}{TAG}.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in res.items() if k != "history"}, indent=1))
    for h in hist[::max(1, len(hist)//25)]:
        print(f"t={h['t']:6.2f}  u_rms={h['u_rms']:.2e}  disp={h['kink_disp']:.2e}  |ReO|={h['absReOmega']:.2e}  |ImO|={h['absImOmega']:.2e}  Ek={h['Ek']:.2e}  |Ru|={h['absRu']:.2e}  calib={h['calib_mean']:.4f}+-{h['calib_sem']:.4f}  f_kz1={h['frac_kz1']:.3f}")

if __name__ == "__main__":
    main()
