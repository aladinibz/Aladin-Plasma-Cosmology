# -*- coding: utf-8 -*-
"""
G2 hypothesis test on independent MHD turbulence (snapshot from mhd_spectral.py).

Local inter-scale energy flux (coarse-graining, Elsasser form; Aluie, Eyink & co.):
    zbar = G_l * z,   tau^+-_ij = bar(z^-+_j z^+-_i) - zbar^-+_j zbar^+-_i,   Pi^+- = - tau^+-_ij d_j zbar^+-_i
    Pi = (Pi^+ + Pi^-)/2  > 0 : energy going to smaller scales at scale l (forward), < 0 : backscatter
Predictors from the FILTERED gradients A = grad ubar, B = grad bbar (same scale l):
    classical : Q, R of A, B, A+B, A-B                        (Q-R / Elsasser invariants)
    G2        : Re_Omega, Im_Omega = Re/Im det(A + iB)        (exactly linear in the R's: identity checked)
                vol  = |D_x ^ D_y ^ D_z| in the 7-d (u, b) space (galilean embedding, sigma slot off)
                calib = phi(D_x, D_y, D_z) / vol              (the part that is NOT a classical invariant)
Questions
  H1  does sign(Pi) follow Re/Im Omega, and do the G2 quantities add predictive power beyond the classical set?
  H3  where is |calib| large: current sheets, vortices, Alfvenic alignment?
Statistics: Spearman rank correlations; ROC-AUC for sign(Pi); logistic regression with spatially blocked
5-fold cross-validation (slabs in x) so neighbouring correlated points never sit on both sides of a split.
"""
import numpy as np, scipy.fft as sf, scipy.stats as st, json, sys, math, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "kernel"))
import g2_karnel_v01 as G2
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler

snap = sys.argv[1] if len(sys.argv) > 1 else "mhd_N64_snapshot.npz"
D = np.load(snap); u, b = D["u"], D["b"]; N = u.shape[-1]; W = 2
k1 = np.fft.fftfreq(N, 1.0/N); kz = np.fft.rfftfreq(N, 1.0/N)
K = np.stack(np.meshgrid(k1, k1, kz, indexing="ij")); K2 = np.sum(K**2, 0)
fwd = lambda a: sf.rfftn(a, axes=(-3, -2, -1), workers=W)
inv = lambda a: sf.irfftn(a, s=(N, N, N), axes=(-3, -2, -1), workers=W)
T = G2._struct_tensor()

def filt(a, ell):
    return inv(fwd(a)*np.exp(-K2*ell**2/24.0))

def grad(v):                                   # v (3, N, N, N) -> A[i, j] = d_j v_i
    V = fwd(v); return np.stack([np.stack([inv(1j*K[jj]*V[ii]) for jj in range(3)]) for ii in range(3)])

def QR(M):                                     # M (3,3,...) -> Q, R
    P = -np.einsum("ii...->...", M); tr2 = np.einsum("ij...,ji...->...", M, M)
    return 0.5*(P**2 - tr2), -np.linalg.det(np.moveaxis(M, (0, 1), (-2, -1)))

def analyse(kl, rng):
    ell = 2*np.pi/kl
    zp, zm = u + b, u - b; zpb, zmb = filt(zp, ell), filt(zm, ell)
    Gp, Gm = grad(zpb), grad(zmb)
    Pp = np.zeros_like(zp[0]); Pm = np.zeros_like(zp[0])
    for i in range(3):
        for j in range(3):
            tp = filt(zm[j]*zp[i], ell) - zmb[j]*zpb[i]; tm = filt(zp[j]*zm[i], ell) - zpb[j]*zmb[i]
            Pp -= tp*Gp[i, j]; Pm -= tm*Gm[i, j]
    Pi = 0.5*(Pp + Pm)
    A, B = 0.5*(Gp + Gm), 0.5*(Gp - Gm)       # grad ubar, grad bbar
    Qu, Ru = QR(A); Qb, Rb = QR(B); Qp, Rp = QR(A + B); Qm, Rm = QR(A - B)
    cd = np.linalg.det(np.moveaxis(A + 1j*B, (0, 1), (-2, -1))); ReO, ImO = cd.real, cd.imag
    ident = max(float(np.abs(ReO - (0.5*(Rp + Rm) - 2*Ru)).max()), float(np.abs(ImO - (-0.5*(Rp - Rm) + 2*Rb)).max()))/float(np.abs(Ru).max())
    # 7-d gradient frame of the galilean embedding (sigma slot = 0), on a random subsample
    n_all = Pi.size; idx = rng.choice(n_all, size=min(n_all, 120000), replace=False)
    Af = A.reshape(3, 3, -1)[:, :, idx]; Bf = B.reshape(3, 3, -1)[:, :, idx]
    Dv = np.stack([G2.embed(Af[:, jj].T, Bf[:, jj].T, np.zeros(len(idx))) for jj in range(3)], -1)   # (n, 7, 3)
    vol = np.prod(np.linalg.svd(Dv, compute_uv=False), -1)
    phi = np.einsum("ni,nj,nk,ijk->n", Dv[..., 0], Dv[..., 1], Dv[..., 2], T)
    phi_vs_ReO = float(np.abs(phi - ReO.reshape(-1)[idx]).max()/np.abs(ReO).max())
    scale = np.prod(np.linalg.norm(Dv, axis=1), -1); ok = vol > 1e-6*scale
    calib = np.where(ok, phi/np.where(ok, vol, 1), 0.0)
    # local structure indicators (filtered)
    ub, bb = 0.5*(zpb + zmb), 0.5*(zpb - zmb)
    jv = np.stack([B[2, 1] - B[1, 2], B[0, 2] - B[2, 0], B[1, 0] - B[0, 1]]); wv = np.stack([A[2, 1] - A[1, 2], A[0, 2] - A[2, 0], A[1, 0] - A[0, 1]])
    nrm = lambda v: np.sqrt(np.sum(v*v, 0))
    absj, absw = nrm(jv), nrm(wv); align_ub = np.abs(np.sum(ub*bb, 0))/(nrm(ub)*nrm(bb) + 1e-300)
    sel = lambda X: X.reshape(-1)[idx]
    feats = dict(Q_u=Qu, R_u=Ru, Q_b=Qb, R_b=Rb, Q_zp=Qp, R_zp=Rp, Q_zm=Qm, R_zm=Rm, Re_Omega=ReO, Im_Omega=ImO)
    X = {k: sel(v) for k, v in feats.items()}; X["vol"] = vol; X["calib"] = calib
    y = sel(Pi); cls = (y > 0).astype(int)
    out = dict(k_l=kl, ell=ell, mean_Pi=float(Pi.mean()), frac_forward=float((Pi > 0).mean()),
               identity_check_ReIm_Omega=ident, phi_equals_ReOmega=phi_vs_ReO, calib_defined_frac=float(ok.mean()))
    out["spearman_vs_Pi"] = {k: float(st.spearmanr(v, y)[0]) for k, v in X.items()}
    out["auc_sign_Pi"] = {k: float(max(roc_auc_score(cls, v), 1 - roc_auc_score(cls, v))) for k, v in X.items()}
    # cross-validated logistic regression with spatial blocks (x slabs)
    xs = (idx // (N*N)); groups = (xs*5)//N
    tf = lambda v, k: np.cbrt(v) if k.startswith(("R_", "Re_", "Im_", "vol")) else (np.sign(v)*np.sqrt(np.abs(v)) if k.startswith("Q_") else v)
    def cv_auc(keys):
        M = np.stack([tf(X[k], k) for k in keys], 1); aucs = []
        for gtest in range(5):
            tr, te = groups != gtest, groups == gtest
            sc = StandardScaler().fit(M[tr]); m = LogisticRegression(max_iter=2000).fit(sc.transform(M[tr]), cls[tr])
            aucs.append(roc_auc_score(cls[te], m.predict_proba(sc.transform(M[te]))[:, 1]))
        return float(np.mean(aucs)), float(np.std(aucs))
    base = ["Q_u", "R_u", "Q_b", "R_b", "Q_zp", "R_zp", "Q_zm", "R_zm"]
    out["cv_auc"] = {"classical (Q,R of u, b, z+, z-)": cv_auc(base),
                     "classical + Re/Im Omega": cv_auc(base + ["Re_Omega", "Im_Omega"]),
                     "classical + calib + vol": cv_auc(base + ["calib", "vol"]),
                     "Re/Im Omega only": cv_auc(["Re_Omega", "Im_Omega"]),
                     "calib + vol only": cv_auc(["calib", "vol"]),
                     "R_u only": cv_auc(["R_u"]), "R_b only": cv_auc(["R_b"])}
    # H3: where is |calib| large?
    ac = np.abs(calib)
    out["H3_spearman_abs_calib_vs"] = {"|j| (current sheets)": float(st.spearmanr(ac, sel(absj))[0]),
                                       "|omega| (vortices)": float(st.spearmanr(ac, sel(absw))[0]),
                                       "|cos(u,b)| (Alfvenic alignment)": float(st.spearmanr(ac, sel(align_ub))[0]),
                                       "|Pi| (flux magnitude)": float(st.spearmanr(ac, np.abs(y))[0])}
    q90 = ac > np.quantile(ac, 0.9); q10 = ac < np.quantile(ac, 0.1)
    out["H3_top10_vs_bottom10_calib"] = {"mean |j|": [float(sel(absj)[q90].mean()), float(sel(absj)[q10].mean())],
                                         "mean |omega|": [float(sel(absw)[q90].mean()), float(sel(absw)[q10].mean())],
                                         "mean |cos(u,b)|": [float(sel(align_ub)[q90].mean()), float(sel(align_ub)[q10].mean())],
                                         "mean Pi": [float(y[q90].mean()), float(y[q10].mean())],
                                         "frac Pi>0": [float((y[q90] > 0).mean()), float((y[q10] > 0).mean())]}
    out["calib_distribution"] = {"mean |calib|": float(ac.mean()), "q50": float(np.quantile(ac, 0.5)), "q90": float(np.quantile(ac, 0.9)),
                                 "q99": float(np.quantile(ac, 0.99)), "mean calib (signed)": float(calib.mean())}
    return out

if __name__ == "__main__":
    rng = np.random.default_rng(7)
    E = np.mean(np.sum(u*u, 0))/2 + np.mean(np.sum(b*b, 0))/2
    Ek = np.zeros(N//2); U = fwd(u); Bh = fwd(b); kk = np.sqrt(K2).astype(int)
    wgt = np.where(K[2] == 0, 1.0, 2.0)/N**6
    for F in (U, Bh):
        np.add.at(Ek, np.clip(kk, 0, N//2 - 1), 0.5*np.sum(np.abs(F)**2, 0)*wgt)
    res = dict(snapshot=snap, N=N, energy=float(E), spectrum_k1_to_20=[float(x) for x in Ek[1:21]])
    kls = [int(x) for x in sys.argv[2:]] if len(sys.argv) > 2 else [4, 8]
    res["scales"] = [analyse(kl, rng) for kl in kls]
    json.dump(res, open(snap.replace("_snapshot.npz", "_g2_results.json"), "w"), indent=1)
    print(json.dumps(res, indent=1))
